<?php
                  $i = 1;
                  if ($list) {
                    
                  
                        $wh = '(cab_service_request_id = "'. $list['description'] . '")';
                        // print_r($wh);die;
                      
                  ?>
                        
                             

                             <?php echo $list['description']?>
                           
                          
                  <?php
                     }
             
                  ?>