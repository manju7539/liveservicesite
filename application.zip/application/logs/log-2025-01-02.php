<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-02 20:10:01 --> Config Class Initialized
INFO - 2025-01-02 20:10:01 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:10:01 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:10:01 --> Utf8 Class Initialized
INFO - 2025-01-02 20:10:01 --> URI Class Initialized
INFO - 2025-01-02 20:10:02 --> Router Class Initialized
INFO - 2025-01-02 20:10:02 --> Output Class Initialized
INFO - 2025-01-02 20:10:02 --> Security Class Initialized
DEBUG - 2025-01-02 20:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:10:02 --> Input Class Initialized
INFO - 2025-01-02 20:10:02 --> Language Class Initialized
ERROR - 2025-01-02 20:10:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2025-01-02 20:10:03 --> Config Class Initialized
INFO - 2025-01-02 20:10:03 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:10:03 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:10:03 --> Utf8 Class Initialized
INFO - 2025-01-02 20:10:03 --> URI Class Initialized
DEBUG - 2025-01-02 20:10:03 --> No URI present. Default controller set.
INFO - 2025-01-02 20:10:03 --> Router Class Initialized
INFO - 2025-01-02 20:10:03 --> Output Class Initialized
INFO - 2025-01-02 20:10:03 --> Security Class Initialized
DEBUG - 2025-01-02 20:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:10:03 --> Input Class Initialized
INFO - 2025-01-02 20:10:03 --> Language Class Initialized
INFO - 2025-01-02 20:10:03 --> Loader Class Initialized
INFO - 2025-01-02 20:10:03 --> Helper loaded: url_helper
INFO - 2025-01-02 20:10:03 --> Helper loaded: html_helper
INFO - 2025-01-02 20:10:03 --> Helper loaded: file_helper
INFO - 2025-01-02 20:10:03 --> Helper loaded: string_helper
INFO - 2025-01-02 20:10:03 --> Helper loaded: form_helper
INFO - 2025-01-02 20:10:03 --> Helper loaded: my_helper
INFO - 2025-01-02 20:10:03 --> Database Driver Class Initialized
INFO - 2025-01-02 20:10:05 --> Upload Class Initialized
INFO - 2025-01-02 20:10:05 --> Email Class Initialized
INFO - 2025-01-02 20:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-02 20:10:06 --> Form Validation Class Initialized
INFO - 2025-01-02 20:10:06 --> Controller Class Initialized
INFO - 2025-01-02 20:50:44 --> Config Class Initialized
INFO - 2025-01-02 20:50:44 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:44 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:44 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:44 --> URI Class Initialized
INFO - 2025-01-02 20:50:44 --> Router Class Initialized
INFO - 2025-01-02 20:50:44 --> Output Class Initialized
INFO - 2025-01-02 20:50:44 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:44 --> Input Class Initialized
INFO - 2025-01-02 20:50:44 --> Language Class Initialized
ERROR - 2025-01-02 20:50:44 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:50:44 --> Config Class Initialized
INFO - 2025-01-02 20:50:44 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:44 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:44 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:44 --> URI Class Initialized
INFO - 2025-01-02 20:50:44 --> Router Class Initialized
INFO - 2025-01-02 20:50:44 --> Output Class Initialized
INFO - 2025-01-02 20:50:44 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:44 --> Input Class Initialized
INFO - 2025-01-02 20:50:44 --> Language Class Initialized
ERROR - 2025-01-02 20:50:44 --> 404 Page Not Found: 403php/index
INFO - 2025-01-02 20:50:45 --> Config Class Initialized
INFO - 2025-01-02 20:50:45 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:45 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:45 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:45 --> URI Class Initialized
INFO - 2025-01-02 20:50:45 --> Router Class Initialized
INFO - 2025-01-02 20:50:45 --> Output Class Initialized
INFO - 2025-01-02 20:50:45 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:45 --> Input Class Initialized
INFO - 2025-01-02 20:50:45 --> Language Class Initialized
ERROR - 2025-01-02 20:50:45 --> 404 Page Not Found: Contentphp/index
INFO - 2025-01-02 20:50:45 --> Config Class Initialized
INFO - 2025-01-02 20:50:45 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:45 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:45 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:45 --> URI Class Initialized
INFO - 2025-01-02 20:50:45 --> Router Class Initialized
INFO - 2025-01-02 20:50:45 --> Output Class Initialized
INFO - 2025-01-02 20:50:45 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:45 --> Input Class Initialized
INFO - 2025-01-02 20:50:45 --> Language Class Initialized
ERROR - 2025-01-02 20:50:45 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:50:45 --> Config Class Initialized
INFO - 2025-01-02 20:50:45 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:45 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:45 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:46 --> URI Class Initialized
INFO - 2025-01-02 20:50:46 --> Router Class Initialized
INFO - 2025-01-02 20:50:46 --> Output Class Initialized
INFO - 2025-01-02 20:50:46 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:46 --> Input Class Initialized
INFO - 2025-01-02 20:50:46 --> Language Class Initialized
ERROR - 2025-01-02 20:50:46 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:50:46 --> Config Class Initialized
INFO - 2025-01-02 20:50:46 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:46 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:46 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:46 --> URI Class Initialized
INFO - 2025-01-02 20:50:46 --> Router Class Initialized
INFO - 2025-01-02 20:50:46 --> Output Class Initialized
INFO - 2025-01-02 20:50:46 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:46 --> Input Class Initialized
INFO - 2025-01-02 20:50:46 --> Language Class Initialized
ERROR - 2025-01-02 20:50:46 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:50:46 --> Config Class Initialized
INFO - 2025-01-02 20:50:46 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:46 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:46 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:46 --> URI Class Initialized
INFO - 2025-01-02 20:50:46 --> Router Class Initialized
INFO - 2025-01-02 20:50:46 --> Output Class Initialized
INFO - 2025-01-02 20:50:46 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:46 --> Input Class Initialized
INFO - 2025-01-02 20:50:46 --> Language Class Initialized
ERROR - 2025-01-02 20:50:46 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:50:47 --> Config Class Initialized
INFO - 2025-01-02 20:50:47 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:47 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:47 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:47 --> URI Class Initialized
INFO - 2025-01-02 20:50:47 --> Router Class Initialized
INFO - 2025-01-02 20:50:47 --> Output Class Initialized
INFO - 2025-01-02 20:50:47 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:47 --> Input Class Initialized
INFO - 2025-01-02 20:50:47 --> Language Class Initialized
ERROR - 2025-01-02 20:50:47 --> 404 Page Not Found: Adminphp/index
INFO - 2025-01-02 20:50:47 --> Config Class Initialized
INFO - 2025-01-02 20:50:47 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:47 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:47 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:47 --> URI Class Initialized
INFO - 2025-01-02 20:50:47 --> Router Class Initialized
INFO - 2025-01-02 20:50:47 --> Output Class Initialized
INFO - 2025-01-02 20:50:47 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:47 --> Input Class Initialized
INFO - 2025-01-02 20:50:47 --> Language Class Initialized
ERROR - 2025-01-02 20:50:47 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:50:48 --> Config Class Initialized
INFO - 2025-01-02 20:50:48 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:48 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:48 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:48 --> URI Class Initialized
INFO - 2025-01-02 20:50:48 --> Router Class Initialized
INFO - 2025-01-02 20:50:48 --> Output Class Initialized
INFO - 2025-01-02 20:50:48 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:48 --> Input Class Initialized
INFO - 2025-01-02 20:50:48 --> Language Class Initialized
ERROR - 2025-01-02 20:50:48 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:50:48 --> Config Class Initialized
INFO - 2025-01-02 20:50:48 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:48 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:48 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:48 --> URI Class Initialized
INFO - 2025-01-02 20:50:48 --> Router Class Initialized
INFO - 2025-01-02 20:50:48 --> Output Class Initialized
INFO - 2025-01-02 20:50:48 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:48 --> Input Class Initialized
INFO - 2025-01-02 20:50:48 --> Language Class Initialized
ERROR - 2025-01-02 20:50:48 --> 404 Page Not Found: Berlinphp/index
INFO - 2025-01-02 20:50:49 --> Config Class Initialized
INFO - 2025-01-02 20:50:49 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:49 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:49 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:49 --> URI Class Initialized
INFO - 2025-01-02 20:50:49 --> Router Class Initialized
INFO - 2025-01-02 20:50:49 --> Output Class Initialized
INFO - 2025-01-02 20:50:49 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:49 --> Input Class Initialized
INFO - 2025-01-02 20:50:49 --> Language Class Initialized
ERROR - 2025-01-02 20:50:49 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2025-01-02 20:50:49 --> Config Class Initialized
INFO - 2025-01-02 20:50:49 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:49 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:49 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:49 --> URI Class Initialized
INFO - 2025-01-02 20:50:49 --> Router Class Initialized
INFO - 2025-01-02 20:50:49 --> Output Class Initialized
INFO - 2025-01-02 20:50:49 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:49 --> Input Class Initialized
INFO - 2025-01-02 20:50:49 --> Language Class Initialized
ERROR - 2025-01-02 20:50:49 --> 404 Page Not Found: Wp-includes/style-engine
INFO - 2025-01-02 20:50:50 --> Config Class Initialized
INFO - 2025-01-02 20:50:50 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:50 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:50 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:50 --> URI Class Initialized
INFO - 2025-01-02 20:50:50 --> Router Class Initialized
INFO - 2025-01-02 20:50:50 --> Output Class Initialized
INFO - 2025-01-02 20:50:50 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:50 --> Input Class Initialized
INFO - 2025-01-02 20:50:50 --> Language Class Initialized
ERROR - 2025-01-02 20:50:50 --> 404 Page Not Found: Wp-includes/rest-api
INFO - 2025-01-02 20:50:50 --> Config Class Initialized
INFO - 2025-01-02 20:50:50 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:50 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:50 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:50 --> URI Class Initialized
INFO - 2025-01-02 20:50:50 --> Router Class Initialized
INFO - 2025-01-02 20:50:50 --> Output Class Initialized
INFO - 2025-01-02 20:50:50 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:50 --> Input Class Initialized
INFO - 2025-01-02 20:50:50 --> Language Class Initialized
ERROR - 2025-01-02 20:50:50 --> 404 Page Not Found: Wp-includes/SimplePie
INFO - 2025-01-02 20:50:51 --> Config Class Initialized
INFO - 2025-01-02 20:50:51 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:51 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:51 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:51 --> URI Class Initialized
INFO - 2025-01-02 20:50:51 --> Router Class Initialized
INFO - 2025-01-02 20:50:51 --> Output Class Initialized
INFO - 2025-01-02 20:50:51 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:51 --> Input Class Initialized
INFO - 2025-01-02 20:50:51 --> Language Class Initialized
ERROR - 2025-01-02 20:50:51 --> 404 Page Not Found: Wp-content/banners
INFO - 2025-01-02 20:50:51 --> Config Class Initialized
INFO - 2025-01-02 20:50:51 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:51 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:51 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:51 --> URI Class Initialized
INFO - 2025-01-02 20:50:51 --> Router Class Initialized
INFO - 2025-01-02 20:50:51 --> Output Class Initialized
INFO - 2025-01-02 20:50:51 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:51 --> Input Class Initialized
INFO - 2025-01-02 20:50:51 --> Language Class Initialized
ERROR - 2025-01-02 20:50:51 --> 404 Page Not Found: Wp-content/about.php
INFO - 2025-01-02 20:50:52 --> Config Class Initialized
INFO - 2025-01-02 20:50:52 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:52 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:52 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:52 --> URI Class Initialized
INFO - 2025-01-02 20:50:52 --> Router Class Initialized
INFO - 2025-01-02 20:50:52 --> Output Class Initialized
INFO - 2025-01-02 20:50:52 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:52 --> Input Class Initialized
INFO - 2025-01-02 20:50:52 --> Language Class Initialized
ERROR - 2025-01-02 20:50:52 --> 404 Page Not Found: Well-known/about.php
INFO - 2025-01-02 20:50:52 --> Config Class Initialized
INFO - 2025-01-02 20:50:52 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:52 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:52 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:52 --> URI Class Initialized
INFO - 2025-01-02 20:50:52 --> Router Class Initialized
INFO - 2025-01-02 20:50:52 --> Output Class Initialized
INFO - 2025-01-02 20:50:52 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:52 --> Input Class Initialized
INFO - 2025-01-02 20:50:52 --> Language Class Initialized
ERROR - 2025-01-02 20:50:52 --> 404 Page Not Found: Wp-includes/Text
INFO - 2025-01-02 20:50:52 --> Config Class Initialized
INFO - 2025-01-02 20:50:52 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:52 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:52 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:52 --> URI Class Initialized
INFO - 2025-01-02 20:50:52 --> Router Class Initialized
INFO - 2025-01-02 20:50:52 --> Output Class Initialized
INFO - 2025-01-02 20:50:52 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:52 --> Input Class Initialized
INFO - 2025-01-02 20:50:52 --> Language Class Initialized
ERROR - 2025-01-02 20:50:52 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2025-01-02 20:50:53 --> Config Class Initialized
INFO - 2025-01-02 20:50:53 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:53 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:53 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:53 --> URI Class Initialized
INFO - 2025-01-02 20:50:53 --> Router Class Initialized
INFO - 2025-01-02 20:50:53 --> Output Class Initialized
INFO - 2025-01-02 20:50:53 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:53 --> Input Class Initialized
INFO - 2025-01-02 20:50:53 --> Language Class Initialized
ERROR - 2025-01-02 20:50:53 --> 404 Page Not Found: Img/about.php
INFO - 2025-01-02 20:50:53 --> Config Class Initialized
INFO - 2025-01-02 20:50:53 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:53 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:53 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:53 --> URI Class Initialized
INFO - 2025-01-02 20:50:53 --> Router Class Initialized
INFO - 2025-01-02 20:50:53 --> Output Class Initialized
INFO - 2025-01-02 20:50:53 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:53 --> Input Class Initialized
INFO - 2025-01-02 20:50:53 --> Language Class Initialized
ERROR - 2025-01-02 20:50:53 --> 404 Page Not Found: Wp-content/languages
INFO - 2025-01-02 20:50:54 --> Config Class Initialized
INFO - 2025-01-02 20:50:54 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:54 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:54 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:54 --> URI Class Initialized
INFO - 2025-01-02 20:50:54 --> Router Class Initialized
INFO - 2025-01-02 20:50:54 --> Output Class Initialized
INFO - 2025-01-02 20:50:54 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:54 --> Input Class Initialized
INFO - 2025-01-02 20:50:54 --> Language Class Initialized
ERROR - 2025-01-02 20:50:54 --> 404 Page Not Found: Wp-includes/customize
INFO - 2025-01-02 20:50:54 --> Config Class Initialized
INFO - 2025-01-02 20:50:54 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:54 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:54 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:54 --> URI Class Initialized
INFO - 2025-01-02 20:50:54 --> Router Class Initialized
INFO - 2025-01-02 20:50:54 --> Output Class Initialized
INFO - 2025-01-02 20:50:54 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:54 --> Input Class Initialized
INFO - 2025-01-02 20:50:54 --> Language Class Initialized
ERROR - 2025-01-02 20:50:54 --> 404 Page Not Found: Wp-includesbak/html-api
INFO - 2025-01-02 20:50:55 --> Config Class Initialized
INFO - 2025-01-02 20:50:55 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:55 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:55 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:55 --> URI Class Initialized
INFO - 2025-01-02 20:50:55 --> Router Class Initialized
INFO - 2025-01-02 20:50:55 --> Output Class Initialized
INFO - 2025-01-02 20:50:55 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:55 --> Input Class Initialized
INFO - 2025-01-02 20:50:55 --> Language Class Initialized
ERROR - 2025-01-02 20:50:55 --> 404 Page Not Found: Wp-includes/widgets
INFO - 2025-01-02 20:50:55 --> Config Class Initialized
INFO - 2025-01-02 20:50:55 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:55 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:55 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:55 --> URI Class Initialized
INFO - 2025-01-02 20:50:55 --> Router Class Initialized
INFO - 2025-01-02 20:50:55 --> Output Class Initialized
INFO - 2025-01-02 20:50:55 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:55 --> Input Class Initialized
INFO - 2025-01-02 20:50:55 --> Language Class Initialized
ERROR - 2025-01-02 20:50:55 --> 404 Page Not Found: Wp-includes/IXR
INFO - 2025-01-02 20:50:56 --> Config Class Initialized
INFO - 2025-01-02 20:50:56 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:56 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:56 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:56 --> URI Class Initialized
INFO - 2025-01-02 20:50:56 --> Router Class Initialized
INFO - 2025-01-02 20:50:56 --> Output Class Initialized
INFO - 2025-01-02 20:50:56 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:56 --> Input Class Initialized
INFO - 2025-01-02 20:50:56 --> Language Class Initialized
ERROR - 2025-01-02 20:50:56 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:50:56 --> Config Class Initialized
INFO - 2025-01-02 20:50:56 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:56 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:56 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:56 --> URI Class Initialized
INFO - 2025-01-02 20:50:56 --> Router Class Initialized
INFO - 2025-01-02 20:50:56 --> Output Class Initialized
INFO - 2025-01-02 20:50:56 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:56 --> Input Class Initialized
INFO - 2025-01-02 20:50:56 --> Language Class Initialized
ERROR - 2025-01-02 20:50:56 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2025-01-02 20:50:57 --> Config Class Initialized
INFO - 2025-01-02 20:50:57 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:57 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:57 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:57 --> URI Class Initialized
INFO - 2025-01-02 20:50:57 --> Router Class Initialized
INFO - 2025-01-02 20:50:57 --> Output Class Initialized
INFO - 2025-01-02 20:50:57 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:57 --> Input Class Initialized
INFO - 2025-01-02 20:50:57 --> Language Class Initialized
ERROR - 2025-01-02 20:50:57 --> 404 Page Not Found: Wp-includes/pomo
INFO - 2025-01-02 20:50:57 --> Config Class Initialized
INFO - 2025-01-02 20:50:57 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:57 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:57 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:57 --> URI Class Initialized
INFO - 2025-01-02 20:50:57 --> Router Class Initialized
INFO - 2025-01-02 20:50:57 --> Output Class Initialized
INFO - 2025-01-02 20:50:57 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:57 --> Input Class Initialized
INFO - 2025-01-02 20:50:57 --> Language Class Initialized
ERROR - 2025-01-02 20:50:57 --> 404 Page Not Found: Wp-includes/block-patterns
INFO - 2025-01-02 20:50:58 --> Config Class Initialized
INFO - 2025-01-02 20:50:58 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:58 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:58 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:58 --> URI Class Initialized
INFO - 2025-01-02 20:50:58 --> Router Class Initialized
INFO - 2025-01-02 20:50:58 --> Output Class Initialized
INFO - 2025-01-02 20:50:58 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:58 --> Input Class Initialized
INFO - 2025-01-02 20:50:58 --> Language Class Initialized
ERROR - 2025-01-02 20:50:58 --> 404 Page Not Found: Wp-content/updraft
INFO - 2025-01-02 20:50:58 --> Config Class Initialized
INFO - 2025-01-02 20:50:58 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:58 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:58 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:58 --> URI Class Initialized
INFO - 2025-01-02 20:50:58 --> Router Class Initialized
INFO - 2025-01-02 20:50:58 --> Output Class Initialized
INFO - 2025-01-02 20:50:58 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:58 --> Input Class Initialized
INFO - 2025-01-02 20:50:58 --> Language Class Initialized
ERROR - 2025-01-02 20:50:58 --> 404 Page Not Found: Wp-content/upgrade-temp-backup
INFO - 2025-01-02 20:50:58 --> Config Class Initialized
INFO - 2025-01-02 20:50:58 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:58 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:58 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:58 --> URI Class Initialized
INFO - 2025-01-02 20:50:58 --> Router Class Initialized
INFO - 2025-01-02 20:50:58 --> Output Class Initialized
INFO - 2025-01-02 20:50:58 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:58 --> Input Class Initialized
INFO - 2025-01-02 20:50:58 --> Language Class Initialized
ERROR - 2025-01-02 20:50:58 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:50:59 --> Config Class Initialized
INFO - 2025-01-02 20:50:59 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:59 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:59 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:59 --> URI Class Initialized
INFO - 2025-01-02 20:50:59 --> Router Class Initialized
INFO - 2025-01-02 20:50:59 --> Output Class Initialized
INFO - 2025-01-02 20:50:59 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:59 --> Input Class Initialized
INFO - 2025-01-02 20:50:59 --> Language Class Initialized
ERROR - 2025-01-02 20:50:59 --> 404 Page Not Found: Wp-admin/includes
INFO - 2025-01-02 20:50:59 --> Config Class Initialized
INFO - 2025-01-02 20:50:59 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:50:59 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:50:59 --> Utf8 Class Initialized
INFO - 2025-01-02 20:50:59 --> URI Class Initialized
INFO - 2025-01-02 20:50:59 --> Router Class Initialized
INFO - 2025-01-02 20:50:59 --> Output Class Initialized
INFO - 2025-01-02 20:50:59 --> Security Class Initialized
DEBUG - 2025-01-02 20:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:50:59 --> Input Class Initialized
INFO - 2025-01-02 20:50:59 --> Language Class Initialized
ERROR - 2025-01-02 20:50:59 --> 404 Page Not Found: Images/about.php
INFO - 2025-01-02 20:51:00 --> Config Class Initialized
INFO - 2025-01-02 20:51:00 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:00 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:00 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:00 --> URI Class Initialized
INFO - 2025-01-02 20:51:00 --> Router Class Initialized
INFO - 2025-01-02 20:51:00 --> Output Class Initialized
INFO - 2025-01-02 20:51:00 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:00 --> Input Class Initialized
INFO - 2025-01-02 20:51:00 --> Language Class Initialized
ERROR - 2025-01-02 20:51:00 --> 404 Page Not Found: Wp-content/blogs.dir
INFO - 2025-01-02 20:51:00 --> Config Class Initialized
INFO - 2025-01-02 20:51:00 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:00 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:00 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:00 --> URI Class Initialized
INFO - 2025-01-02 20:51:00 --> Router Class Initialized
INFO - 2025-01-02 20:51:00 --> Output Class Initialized
INFO - 2025-01-02 20:51:00 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:00 --> Input Class Initialized
INFO - 2025-01-02 20:51:00 --> Language Class Initialized
ERROR - 2025-01-02 20:51:00 --> 404 Page Not Found: Wp-includes/images
INFO - 2025-01-02 20:51:01 --> Config Class Initialized
INFO - 2025-01-02 20:51:01 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:01 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:01 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:01 --> URI Class Initialized
INFO - 2025-01-02 20:51:01 --> Router Class Initialized
INFO - 2025-01-02 20:51:01 --> Output Class Initialized
INFO - 2025-01-02 20:51:01 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:01 --> Input Class Initialized
INFO - 2025-01-02 20:51:01 --> Language Class Initialized
ERROR - 2025-01-02 20:51:01 --> 404 Page Not Found: Wp-includes/about.php
INFO - 2025-01-02 20:51:01 --> Config Class Initialized
INFO - 2025-01-02 20:51:01 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:01 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:01 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:01 --> URI Class Initialized
INFO - 2025-01-02 20:51:01 --> Router Class Initialized
INFO - 2025-01-02 20:51:01 --> Output Class Initialized
INFO - 2025-01-02 20:51:01 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:01 --> Input Class Initialized
INFO - 2025-01-02 20:51:01 --> Language Class Initialized
ERROR - 2025-01-02 20:51:01 --> 404 Page Not Found: Cgi-bin/about.php
INFO - 2025-01-02 20:51:02 --> Config Class Initialized
INFO - 2025-01-02 20:51:02 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:02 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:02 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:02 --> URI Class Initialized
INFO - 2025-01-02 20:51:02 --> Router Class Initialized
INFO - 2025-01-02 20:51:02 --> Output Class Initialized
INFO - 2025-01-02 20:51:02 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:02 --> Input Class Initialized
INFO - 2025-01-02 20:51:02 --> Language Class Initialized
ERROR - 2025-01-02 20:51:02 --> 404 Page Not Found: Wp-content/gallery
INFO - 2025-01-02 20:51:02 --> Config Class Initialized
INFO - 2025-01-02 20:51:02 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:02 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:02 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:02 --> URI Class Initialized
INFO - 2025-01-02 20:51:02 --> Router Class Initialized
INFO - 2025-01-02 20:51:02 --> Output Class Initialized
INFO - 2025-01-02 20:51:02 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:02 --> Input Class Initialized
INFO - 2025-01-02 20:51:02 --> Language Class Initialized
ERROR - 2025-01-02 20:51:02 --> 404 Page Not Found: Wp-includes/blocks
INFO - 2025-01-02 20:51:03 --> Config Class Initialized
INFO - 2025-01-02 20:51:03 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:03 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:03 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:03 --> URI Class Initialized
INFO - 2025-01-02 20:51:03 --> Router Class Initialized
INFO - 2025-01-02 20:51:03 --> Output Class Initialized
INFO - 2025-01-02 20:51:03 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:03 --> Input Class Initialized
INFO - 2025-01-02 20:51:03 --> Language Class Initialized
ERROR - 2025-01-02 20:51:03 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:03 --> Config Class Initialized
INFO - 2025-01-02 20:51:03 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:03 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:03 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:03 --> URI Class Initialized
INFO - 2025-01-02 20:51:03 --> Router Class Initialized
INFO - 2025-01-02 20:51:03 --> Output Class Initialized
INFO - 2025-01-02 20:51:03 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:03 --> Input Class Initialized
INFO - 2025-01-02 20:51:03 --> Language Class Initialized
ERROR - 2025-01-02 20:51:03 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:51:04 --> Config Class Initialized
INFO - 2025-01-02 20:51:04 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:04 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:04 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:04 --> URI Class Initialized
INFO - 2025-01-02 20:51:04 --> Router Class Initialized
INFO - 2025-01-02 20:51:04 --> Output Class Initialized
INFO - 2025-01-02 20:51:04 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:04 --> Input Class Initialized
INFO - 2025-01-02 20:51:04 --> Language Class Initialized
ERROR - 2025-01-02 20:51:04 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2025-01-02 20:51:04 --> Config Class Initialized
INFO - 2025-01-02 20:51:04 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:04 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:04 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:04 --> URI Class Initialized
INFO - 2025-01-02 20:51:04 --> Router Class Initialized
INFO - 2025-01-02 20:51:04 --> Output Class Initialized
INFO - 2025-01-02 20:51:04 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:04 --> Input Class Initialized
INFO - 2025-01-02 20:51:04 --> Language Class Initialized
ERROR - 2025-01-02 20:51:04 --> 404 Page Not Found: Wp-admin/network
INFO - 2025-01-02 20:51:05 --> Config Class Initialized
INFO - 2025-01-02 20:51:05 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:05 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:05 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:05 --> URI Class Initialized
INFO - 2025-01-02 20:51:05 --> Router Class Initialized
INFO - 2025-01-02 20:51:05 --> Output Class Initialized
INFO - 2025-01-02 20:51:05 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:05 --> Input Class Initialized
INFO - 2025-01-02 20:51:05 --> Language Class Initialized
ERROR - 2025-01-02 20:51:05 --> 404 Page Not Found: Cloudphp/index
INFO - 2025-01-02 20:51:05 --> Config Class Initialized
INFO - 2025-01-02 20:51:05 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:05 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:05 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:05 --> URI Class Initialized
INFO - 2025-01-02 20:51:05 --> Router Class Initialized
INFO - 2025-01-02 20:51:05 --> Output Class Initialized
INFO - 2025-01-02 20:51:05 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:05 --> Input Class Initialized
INFO - 2025-01-02 20:51:05 --> Language Class Initialized
ERROR - 2025-01-02 20:51:05 --> 404 Page Not Found: Cgi-bin/cloud.php
INFO - 2025-01-02 20:51:06 --> Config Class Initialized
INFO - 2025-01-02 20:51:06 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:06 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:06 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:06 --> URI Class Initialized
INFO - 2025-01-02 20:51:06 --> Router Class Initialized
INFO - 2025-01-02 20:51:06 --> Output Class Initialized
INFO - 2025-01-02 20:51:06 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:06 --> Input Class Initialized
INFO - 2025-01-02 20:51:06 --> Language Class Initialized
ERROR - 2025-01-02 20:51:06 --> 404 Page Not Found: Wp-content/updates.php
INFO - 2025-01-02 20:51:06 --> Config Class Initialized
INFO - 2025-01-02 20:51:06 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:06 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:06 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:06 --> URI Class Initialized
INFO - 2025-01-02 20:51:06 --> Router Class Initialized
INFO - 2025-01-02 20:51:06 --> Output Class Initialized
INFO - 2025-01-02 20:51:06 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:06 --> Input Class Initialized
INFO - 2025-01-02 20:51:06 --> Language Class Initialized
ERROR - 2025-01-02 20:51:06 --> 404 Page Not Found: Css/cloud.php
INFO - 2025-01-02 20:51:07 --> Config Class Initialized
INFO - 2025-01-02 20:51:07 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:07 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:07 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:07 --> URI Class Initialized
INFO - 2025-01-02 20:51:07 --> Router Class Initialized
INFO - 2025-01-02 20:51:07 --> Output Class Initialized
INFO - 2025-01-02 20:51:07 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:07 --> Input Class Initialized
INFO - 2025-01-02 20:51:07 --> Language Class Initialized
ERROR - 2025-01-02 20:51:07 --> 404 Page Not Found: Wp-admin/user
INFO - 2025-01-02 20:51:07 --> Config Class Initialized
INFO - 2025-01-02 20:51:07 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:07 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:07 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:07 --> URI Class Initialized
INFO - 2025-01-02 20:51:07 --> Router Class Initialized
INFO - 2025-01-02 20:51:07 --> Output Class Initialized
INFO - 2025-01-02 20:51:07 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:07 --> Input Class Initialized
INFO - 2025-01-02 20:51:07 --> Language Class Initialized
ERROR - 2025-01-02 20:51:07 --> 404 Page Not Found: Img/cloud.php
INFO - 2025-01-02 20:51:07 --> Config Class Initialized
INFO - 2025-01-02 20:51:07 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:07 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:07 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:07 --> URI Class Initialized
INFO - 2025-01-02 20:51:07 --> Router Class Initialized
INFO - 2025-01-02 20:51:07 --> Output Class Initialized
INFO - 2025-01-02 20:51:07 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:07 --> Input Class Initialized
INFO - 2025-01-02 20:51:07 --> Language Class Initialized
ERROR - 2025-01-02 20:51:07 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:08 --> Config Class Initialized
INFO - 2025-01-02 20:51:08 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:08 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:08 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:08 --> URI Class Initialized
INFO - 2025-01-02 20:51:08 --> Router Class Initialized
INFO - 2025-01-02 20:51:08 --> Output Class Initialized
INFO - 2025-01-02 20:51:08 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:08 --> Input Class Initialized
INFO - 2025-01-02 20:51:08 --> Language Class Initialized
ERROR - 2025-01-02 20:51:08 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:51:08 --> Config Class Initialized
INFO - 2025-01-02 20:51:08 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:08 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:08 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:08 --> URI Class Initialized
INFO - 2025-01-02 20:51:08 --> Router Class Initialized
INFO - 2025-01-02 20:51:08 --> Output Class Initialized
INFO - 2025-01-02 20:51:08 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:08 --> Input Class Initialized
INFO - 2025-01-02 20:51:08 --> Language Class Initialized
ERROR - 2025-01-02 20:51:08 --> 404 Page Not Found: Avaaphp/index
INFO - 2025-01-02 20:51:09 --> Config Class Initialized
INFO - 2025-01-02 20:51:09 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:09 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:09 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:09 --> URI Class Initialized
INFO - 2025-01-02 20:51:09 --> Router Class Initialized
INFO - 2025-01-02 20:51:09 --> Output Class Initialized
INFO - 2025-01-02 20:51:09 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:09 --> Input Class Initialized
INFO - 2025-01-02 20:51:09 --> Language Class Initialized
ERROR - 2025-01-02 20:51:09 --> 404 Page Not Found: Images/cloud.php
INFO - 2025-01-02 20:51:09 --> Config Class Initialized
INFO - 2025-01-02 20:51:09 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:09 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:09 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:09 --> URI Class Initialized
INFO - 2025-01-02 20:51:09 --> Router Class Initialized
INFO - 2025-01-02 20:51:09 --> Output Class Initialized
INFO - 2025-01-02 20:51:09 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:09 --> Input Class Initialized
INFO - 2025-01-02 20:51:09 --> Language Class Initialized
ERROR - 2025-01-02 20:51:09 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:51:10 --> Config Class Initialized
INFO - 2025-01-02 20:51:10 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:10 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:10 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:10 --> URI Class Initialized
INFO - 2025-01-02 20:51:10 --> Router Class Initialized
INFO - 2025-01-02 20:51:10 --> Output Class Initialized
INFO - 2025-01-02 20:51:10 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:10 --> Input Class Initialized
INFO - 2025-01-02 20:51:10 --> Language Class Initialized
ERROR - 2025-01-02 20:51:10 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2025-01-02 20:51:10 --> Config Class Initialized
INFO - 2025-01-02 20:51:10 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:10 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:10 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:10 --> URI Class Initialized
INFO - 2025-01-02 20:51:10 --> Router Class Initialized
INFO - 2025-01-02 20:51:10 --> Output Class Initialized
INFO - 2025-01-02 20:51:10 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:10 --> Input Class Initialized
INFO - 2025-01-02 20:51:10 --> Language Class Initialized
ERROR - 2025-01-02 20:51:10 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:11 --> Config Class Initialized
INFO - 2025-01-02 20:51:11 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:11 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:11 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:11 --> URI Class Initialized
INFO - 2025-01-02 20:51:11 --> Router Class Initialized
INFO - 2025-01-02 20:51:11 --> Output Class Initialized
INFO - 2025-01-02 20:51:11 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:11 --> Input Class Initialized
INFO - 2025-01-02 20:51:11 --> Language Class Initialized
ERROR - 2025-01-02 20:51:11 --> 404 Page Not Found: Wp-admin/includes
INFO - 2025-01-02 20:51:11 --> Config Class Initialized
INFO - 2025-01-02 20:51:11 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:11 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:11 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:11 --> URI Class Initialized
INFO - 2025-01-02 20:51:11 --> Router Class Initialized
INFO - 2025-01-02 20:51:11 --> Output Class Initialized
INFO - 2025-01-02 20:51:11 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:11 --> Input Class Initialized
INFO - 2025-01-02 20:51:11 --> Language Class Initialized
ERROR - 2025-01-02 20:51:11 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:12 --> Config Class Initialized
INFO - 2025-01-02 20:51:12 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:12 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:12 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:12 --> URI Class Initialized
INFO - 2025-01-02 20:51:12 --> Router Class Initialized
INFO - 2025-01-02 20:51:12 --> Output Class Initialized
INFO - 2025-01-02 20:51:12 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:12 --> Input Class Initialized
INFO - 2025-01-02 20:51:12 --> Language Class Initialized
ERROR - 2025-01-02 20:51:12 --> 404 Page Not Found: Wp-admin/cloud.php
INFO - 2025-01-02 20:51:12 --> Config Class Initialized
INFO - 2025-01-02 20:51:12 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:12 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:12 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:12 --> URI Class Initialized
INFO - 2025-01-02 20:51:12 --> Router Class Initialized
INFO - 2025-01-02 20:51:12 --> Output Class Initialized
INFO - 2025-01-02 20:51:12 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:12 --> Input Class Initialized
INFO - 2025-01-02 20:51:12 --> Language Class Initialized
ERROR - 2025-01-02 20:51:12 --> 404 Page Not Found: Updatesphp/index
INFO - 2025-01-02 20:51:13 --> Config Class Initialized
INFO - 2025-01-02 20:51:13 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:13 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:13 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:13 --> URI Class Initialized
INFO - 2025-01-02 20:51:13 --> Router Class Initialized
INFO - 2025-01-02 20:51:13 --> Output Class Initialized
INFO - 2025-01-02 20:51:13 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:13 --> Input Class Initialized
INFO - 2025-01-02 20:51:13 --> Language Class Initialized
ERROR - 2025-01-02 20:51:13 --> 404 Page Not Found: Libraries/legacy
INFO - 2025-01-02 20:51:13 --> Config Class Initialized
INFO - 2025-01-02 20:51:13 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:13 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:13 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:13 --> URI Class Initialized
INFO - 2025-01-02 20:51:13 --> Router Class Initialized
INFO - 2025-01-02 20:51:13 --> Output Class Initialized
INFO - 2025-01-02 20:51:13 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:13 --> Input Class Initialized
INFO - 2025-01-02 20:51:13 --> Language Class Initialized
ERROR - 2025-01-02 20:51:13 --> 404 Page Not Found: Libraries/phpmailer
INFO - 2025-01-02 20:51:13 --> Config Class Initialized
INFO - 2025-01-02 20:51:13 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:13 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:13 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:13 --> URI Class Initialized
INFO - 2025-01-02 20:51:13 --> Router Class Initialized
INFO - 2025-01-02 20:51:14 --> Output Class Initialized
INFO - 2025-01-02 20:51:14 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:14 --> Input Class Initialized
INFO - 2025-01-02 20:51:14 --> Language Class Initialized
ERROR - 2025-01-02 20:51:14 --> 404 Page Not Found: Libraries/vendor
INFO - 2025-01-02 20:51:14 --> Config Class Initialized
INFO - 2025-01-02 20:51:14 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:14 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:14 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:14 --> URI Class Initialized
INFO - 2025-01-02 20:51:14 --> Router Class Initialized
INFO - 2025-01-02 20:51:14 --> Output Class Initialized
INFO - 2025-01-02 20:51:14 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:14 --> Input Class Initialized
INFO - 2025-01-02 20:51:14 --> Language Class Initialized
ERROR - 2025-01-02 20:51:14 --> 404 Page Not Found: Alfa-rexphp7/index
INFO - 2025-01-02 20:51:14 --> Config Class Initialized
INFO - 2025-01-02 20:51:14 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:14 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:14 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:14 --> URI Class Initialized
INFO - 2025-01-02 20:51:14 --> Router Class Initialized
INFO - 2025-01-02 20:51:14 --> Output Class Initialized
INFO - 2025-01-02 20:51:14 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:14 --> Input Class Initialized
INFO - 2025-01-02 20:51:14 --> Language Class Initialized
ERROR - 2025-01-02 20:51:14 --> 404 Page Not Found: Alfanewphp/index
INFO - 2025-01-02 20:51:15 --> Config Class Initialized
INFO - 2025-01-02 20:51:15 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:15 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:15 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:15 --> URI Class Initialized
INFO - 2025-01-02 20:51:15 --> Router Class Initialized
INFO - 2025-01-02 20:51:15 --> Output Class Initialized
INFO - 2025-01-02 20:51:15 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:15 --> Input Class Initialized
INFO - 2025-01-02 20:51:15 --> Language Class Initialized
ERROR - 2025-01-02 20:51:15 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:15 --> Config Class Initialized
INFO - 2025-01-02 20:51:15 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:15 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:15 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:15 --> URI Class Initialized
INFO - 2025-01-02 20:51:15 --> Router Class Initialized
INFO - 2025-01-02 20:51:15 --> Output Class Initialized
INFO - 2025-01-02 20:51:15 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:15 --> Input Class Initialized
INFO - 2025-01-02 20:51:15 --> Language Class Initialized
ERROR - 2025-01-02 20:51:15 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:51:16 --> Config Class Initialized
INFO - 2025-01-02 20:51:16 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:16 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:16 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:16 --> URI Class Initialized
INFO - 2025-01-02 20:51:16 --> Router Class Initialized
INFO - 2025-01-02 20:51:16 --> Output Class Initialized
INFO - 2025-01-02 20:51:16 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:16 --> Input Class Initialized
INFO - 2025-01-02 20:51:16 --> Language Class Initialized
ERROR - 2025-01-02 20:51:16 --> 404 Page Not Found: Wp-pphp7/index
INFO - 2025-01-02 20:51:17 --> Config Class Initialized
INFO - 2025-01-02 20:51:17 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:17 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:17 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:17 --> URI Class Initialized
INFO - 2025-01-02 20:51:17 --> Router Class Initialized
INFO - 2025-01-02 20:51:17 --> Output Class Initialized
INFO - 2025-01-02 20:51:17 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:17 --> Input Class Initialized
INFO - 2025-01-02 20:51:17 --> Language Class Initialized
ERROR - 2025-01-02 20:51:17 --> 404 Page Not Found: Wp-admin/repeater.php
INFO - 2025-01-02 20:51:17 --> Config Class Initialized
INFO - 2025-01-02 20:51:17 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:17 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:17 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:17 --> URI Class Initialized
INFO - 2025-01-02 20:51:17 --> Router Class Initialized
INFO - 2025-01-02 20:51:17 --> Output Class Initialized
INFO - 2025-01-02 20:51:17 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:17 --> Input Class Initialized
INFO - 2025-01-02 20:51:17 --> Language Class Initialized
ERROR - 2025-01-02 20:51:17 --> 404 Page Not Found: Wp-includes/repeater.php
INFO - 2025-01-02 20:51:18 --> Config Class Initialized
INFO - 2025-01-02 20:51:18 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:18 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:18 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:18 --> URI Class Initialized
INFO - 2025-01-02 20:51:18 --> Router Class Initialized
INFO - 2025-01-02 20:51:18 --> Output Class Initialized
INFO - 2025-01-02 20:51:18 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:18 --> Input Class Initialized
INFO - 2025-01-02 20:51:18 --> Language Class Initialized
ERROR - 2025-01-02 20:51:18 --> 404 Page Not Found: Wp-content/repeater.php
INFO - 2025-01-02 20:51:18 --> Config Class Initialized
INFO - 2025-01-02 20:51:18 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:18 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:18 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:18 --> URI Class Initialized
INFO - 2025-01-02 20:51:18 --> Router Class Initialized
INFO - 2025-01-02 20:51:18 --> Output Class Initialized
INFO - 2025-01-02 20:51:18 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:18 --> Input Class Initialized
INFO - 2025-01-02 20:51:18 --> Language Class Initialized
ERROR - 2025-01-02 20:51:18 --> 404 Page Not Found: Wsoyanzphp/index
INFO - 2025-01-02 20:51:18 --> Config Class Initialized
INFO - 2025-01-02 20:51:18 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:18 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:18 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:18 --> URI Class Initialized
INFO - 2025-01-02 20:51:18 --> Router Class Initialized
INFO - 2025-01-02 20:51:18 --> Output Class Initialized
INFO - 2025-01-02 20:51:19 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:19 --> Input Class Initialized
INFO - 2025-01-02 20:51:19 --> Language Class Initialized
ERROR - 2025-01-02 20:51:19 --> 404 Page Not Found: Yanzphp/index
INFO - 2025-01-02 20:51:19 --> Config Class Initialized
INFO - 2025-01-02 20:51:19 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:19 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:19 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:19 --> URI Class Initialized
INFO - 2025-01-02 20:51:19 --> Router Class Initialized
INFO - 2025-01-02 20:51:19 --> Output Class Initialized
INFO - 2025-01-02 20:51:19 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:19 --> Input Class Initialized
INFO - 2025-01-02 20:51:19 --> Language Class Initialized
ERROR - 2025-01-02 20:51:19 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:51:19 --> Config Class Initialized
INFO - 2025-01-02 20:51:19 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:19 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:19 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:19 --> URI Class Initialized
INFO - 2025-01-02 20:51:19 --> Router Class Initialized
INFO - 2025-01-02 20:51:19 --> Output Class Initialized
INFO - 2025-01-02 20:51:19 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:19 --> Input Class Initialized
INFO - 2025-01-02 20:51:19 --> Language Class Initialized
ERROR - 2025-01-02 20:51:19 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:20 --> Config Class Initialized
INFO - 2025-01-02 20:51:20 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:20 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:20 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:20 --> URI Class Initialized
INFO - 2025-01-02 20:51:20 --> Router Class Initialized
INFO - 2025-01-02 20:51:20 --> Output Class Initialized
INFO - 2025-01-02 20:51:20 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:20 --> Input Class Initialized
INFO - 2025-01-02 20:51:20 --> Language Class Initialized
ERROR - 2025-01-02 20:51:20 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:20 --> Config Class Initialized
INFO - 2025-01-02 20:51:20 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:20 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:20 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:20 --> URI Class Initialized
INFO - 2025-01-02 20:51:20 --> Router Class Initialized
INFO - 2025-01-02 20:51:20 --> Output Class Initialized
INFO - 2025-01-02 20:51:20 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:20 --> Input Class Initialized
INFO - 2025-01-02 20:51:20 --> Language Class Initialized
ERROR - 2025-01-02 20:51:20 --> 404 Page Not Found: Cache-compatphp/index
INFO - 2025-01-02 20:51:21 --> Config Class Initialized
INFO - 2025-01-02 20:51:21 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:21 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:21 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:21 --> URI Class Initialized
INFO - 2025-01-02 20:51:21 --> Router Class Initialized
INFO - 2025-01-02 20:51:21 --> Output Class Initialized
INFO - 2025-01-02 20:51:21 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:21 --> Input Class Initialized
INFO - 2025-01-02 20:51:21 --> Language Class Initialized
ERROR - 2025-01-02 20:51:21 --> 404 Page Not Found: Ajax-actionsphp/index
INFO - 2025-01-02 20:51:21 --> Config Class Initialized
INFO - 2025-01-02 20:51:21 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:21 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:21 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:21 --> URI Class Initialized
INFO - 2025-01-02 20:51:21 --> Router Class Initialized
INFO - 2025-01-02 20:51:21 --> Output Class Initialized
INFO - 2025-01-02 20:51:21 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:21 --> Input Class Initialized
INFO - 2025-01-02 20:51:21 --> Language Class Initialized
ERROR - 2025-01-02 20:51:21 --> 404 Page Not Found: Wp-admin/ajax-actions.php
INFO - 2025-01-02 20:51:22 --> Config Class Initialized
INFO - 2025-01-02 20:51:22 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:22 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:22 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:22 --> URI Class Initialized
INFO - 2025-01-02 20:51:22 --> Router Class Initialized
INFO - 2025-01-02 20:51:22 --> Output Class Initialized
INFO - 2025-01-02 20:51:22 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:22 --> Input Class Initialized
INFO - 2025-01-02 20:51:22 --> Language Class Initialized
ERROR - 2025-01-02 20:51:22 --> 404 Page Not Found: Wp-consarphp/index
INFO - 2025-01-02 20:51:22 --> Config Class Initialized
INFO - 2025-01-02 20:51:22 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:22 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:22 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:22 --> URI Class Initialized
INFO - 2025-01-02 20:51:22 --> Router Class Initialized
INFO - 2025-01-02 20:51:22 --> Output Class Initialized
INFO - 2025-01-02 20:51:22 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:22 --> Input Class Initialized
INFO - 2025-01-02 20:51:22 --> Language Class Initialized
ERROR - 2025-01-02 20:51:22 --> 404 Page Not Found: Repeaterphp/index
INFO - 2025-01-02 20:51:23 --> Config Class Initialized
INFO - 2025-01-02 20:51:23 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:23 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:23 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:23 --> URI Class Initialized
INFO - 2025-01-02 20:51:23 --> Router Class Initialized
INFO - 2025-01-02 20:51:23 --> Output Class Initialized
INFO - 2025-01-02 20:51:23 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:23 --> Input Class Initialized
INFO - 2025-01-02 20:51:23 --> Language Class Initialized
ERROR - 2025-01-02 20:51:23 --> 404 Page Not Found: Admin-postphp/index
INFO - 2025-01-02 20:51:23 --> Config Class Initialized
INFO - 2025-01-02 20:51:23 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:23 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:23 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:23 --> URI Class Initialized
INFO - 2025-01-02 20:51:23 --> Router Class Initialized
INFO - 2025-01-02 20:51:23 --> Output Class Initialized
INFO - 2025-01-02 20:51:23 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:23 --> Input Class Initialized
INFO - 2025-01-02 20:51:23 --> Language Class Initialized
ERROR - 2025-01-02 20:51:23 --> 404 Page Not Found: Wp-admin/maint
INFO - 2025-01-02 20:51:24 --> Config Class Initialized
INFO - 2025-01-02 20:51:24 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:24 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:24 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:24 --> URI Class Initialized
INFO - 2025-01-02 20:51:24 --> Router Class Initialized
INFO - 2025-01-02 20:51:24 --> Output Class Initialized
INFO - 2025-01-02 20:51:24 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:24 --> Input Class Initialized
INFO - 2025-01-02 20:51:24 --> Language Class Initialized
ERROR - 2025-01-02 20:51:24 --> 404 Page Not Found: Wp-admin/dropdown.php
INFO - 2025-01-02 20:51:24 --> Config Class Initialized
INFO - 2025-01-02 20:51:24 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:24 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:24 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:24 --> URI Class Initialized
INFO - 2025-01-02 20:51:24 --> Router Class Initialized
INFO - 2025-01-02 20:51:24 --> Output Class Initialized
INFO - 2025-01-02 20:51:24 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:24 --> Input Class Initialized
INFO - 2025-01-02 20:51:24 --> Language Class Initialized
ERROR - 2025-01-02 20:51:24 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:25 --> Config Class Initialized
INFO - 2025-01-02 20:51:25 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:25 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:25 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:25 --> URI Class Initialized
INFO - 2025-01-02 20:51:25 --> Router Class Initialized
INFO - 2025-01-02 20:51:25 --> Output Class Initialized
INFO - 2025-01-02 20:51:25 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:25 --> Input Class Initialized
INFO - 2025-01-02 20:51:25 --> Language Class Initialized
ERROR - 2025-01-02 20:51:25 --> 404 Page Not Found: Dropdownphp/index
INFO - 2025-01-02 20:51:25 --> Config Class Initialized
INFO - 2025-01-02 20:51:25 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:25 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:25 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:25 --> URI Class Initialized
INFO - 2025-01-02 20:51:25 --> Router Class Initialized
INFO - 2025-01-02 20:51:25 --> Output Class Initialized
INFO - 2025-01-02 20:51:25 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:25 --> Input Class Initialized
INFO - 2025-01-02 20:51:25 --> Language Class Initialized
ERROR - 2025-01-02 20:51:25 --> 404 Page Not Found: Aboutphp/index
INFO - 2025-01-02 20:51:26 --> Config Class Initialized
INFO - 2025-01-02 20:51:26 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:26 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:26 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:26 --> URI Class Initialized
INFO - 2025-01-02 20:51:26 --> Router Class Initialized
INFO - 2025-01-02 20:51:26 --> Output Class Initialized
INFO - 2025-01-02 20:51:26 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:26 --> Input Class Initialized
INFO - 2025-01-02 20:51:26 --> Language Class Initialized
ERROR - 2025-01-02 20:51:26 --> 404 Page Not Found: Adminphp/index
INFO - 2025-01-02 20:51:26 --> Config Class Initialized
INFO - 2025-01-02 20:51:26 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:26 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:26 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:26 --> URI Class Initialized
INFO - 2025-01-02 20:51:26 --> Router Class Initialized
INFO - 2025-01-02 20:51:26 --> Output Class Initialized
INFO - 2025-01-02 20:51:26 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:26 --> Input Class Initialized
INFO - 2025-01-02 20:51:26 --> Language Class Initialized
ERROR - 2025-01-02 20:51:26 --> 404 Page Not Found: Aboutphp7/index
INFO - 2025-01-02 20:51:26 --> Config Class Initialized
INFO - 2025-01-02 20:51:26 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:26 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:26 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:26 --> URI Class Initialized
INFO - 2025-01-02 20:51:26 --> Router Class Initialized
INFO - 2025-01-02 20:51:26 --> Output Class Initialized
INFO - 2025-01-02 20:51:26 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:26 --> Input Class Initialized
INFO - 2025-01-02 20:51:26 --> Language Class Initialized
ERROR - 2025-01-02 20:51:26 --> 404 Page Not Found: Alfanewphp7/index
INFO - 2025-01-02 20:51:27 --> Config Class Initialized
INFO - 2025-01-02 20:51:27 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:27 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:27 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:27 --> URI Class Initialized
INFO - 2025-01-02 20:51:27 --> Router Class Initialized
INFO - 2025-01-02 20:51:27 --> Output Class Initialized
INFO - 2025-01-02 20:51:27 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:27 --> Input Class Initialized
INFO - 2025-01-02 20:51:27 --> Language Class Initialized
ERROR - 2025-01-02 20:51:27 --> 404 Page Not Found: Adminfunsphp7/index
INFO - 2025-01-02 20:51:27 --> Config Class Initialized
INFO - 2025-01-02 20:51:27 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:27 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:27 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:27 --> URI Class Initialized
INFO - 2025-01-02 20:51:27 --> Router Class Initialized
INFO - 2025-01-02 20:51:27 --> Output Class Initialized
INFO - 2025-01-02 20:51:27 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:27 --> Input Class Initialized
INFO - 2025-01-02 20:51:27 --> Language Class Initialized
ERROR - 2025-01-02 20:51:27 --> 404 Page Not Found: Ebsphp7/index
INFO - 2025-01-02 20:51:28 --> Config Class Initialized
INFO - 2025-01-02 20:51:28 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:28 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:28 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:28 --> URI Class Initialized
INFO - 2025-01-02 20:51:28 --> Router Class Initialized
INFO - 2025-01-02 20:51:28 --> Output Class Initialized
INFO - 2025-01-02 20:51:28 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:28 --> Input Class Initialized
INFO - 2025-01-02 20:51:28 --> Language Class Initialized
ERROR - 2025-01-02 20:51:28 --> 404 Page Not Found: Wsphp7/index
INFO - 2025-01-02 20:51:28 --> Config Class Initialized
INFO - 2025-01-02 20:51:28 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:28 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:28 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:28 --> URI Class Initialized
INFO - 2025-01-02 20:51:28 --> Router Class Initialized
INFO - 2025-01-02 20:51:28 --> Output Class Initialized
INFO - 2025-01-02 20:51:28 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:28 --> Input Class Initialized
INFO - 2025-01-02 20:51:28 --> Language Class Initialized
ERROR - 2025-01-02 20:51:28 --> 404 Page Not Found: Alfanew2php7/index
INFO - 2025-01-02 20:51:29 --> Config Class Initialized
INFO - 2025-01-02 20:51:29 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:29 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:29 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:29 --> URI Class Initialized
INFO - 2025-01-02 20:51:29 --> Router Class Initialized
INFO - 2025-01-02 20:51:29 --> Output Class Initialized
INFO - 2025-01-02 20:51:29 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:29 --> Input Class Initialized
INFO - 2025-01-02 20:51:29 --> Language Class Initialized
ERROR - 2025-01-02 20:51:29 --> 404 Page Not Found: Alfa-rex2php7/index
INFO - 2025-01-02 20:51:29 --> Config Class Initialized
INFO - 2025-01-02 20:51:29 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:29 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:29 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:29 --> URI Class Initialized
INFO - 2025-01-02 20:51:29 --> Router Class Initialized
INFO - 2025-01-02 20:51:29 --> Output Class Initialized
INFO - 2025-01-02 20:51:29 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:29 --> Input Class Initialized
INFO - 2025-01-02 20:51:29 --> Language Class Initialized
ERROR - 2025-01-02 20:51:29 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:51:30 --> Config Class Initialized
INFO - 2025-01-02 20:51:30 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:30 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:30 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:30 --> URI Class Initialized
INFO - 2025-01-02 20:51:30 --> Router Class Initialized
INFO - 2025-01-02 20:51:30 --> Output Class Initialized
INFO - 2025-01-02 20:51:30 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:30 --> Input Class Initialized
INFO - 2025-01-02 20:51:30 --> Language Class Initialized
ERROR - 2025-01-02 20:51:30 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:30 --> Config Class Initialized
INFO - 2025-01-02 20:51:30 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:30 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:30 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:30 --> URI Class Initialized
INFO - 2025-01-02 20:51:30 --> Router Class Initialized
INFO - 2025-01-02 20:51:30 --> Output Class Initialized
INFO - 2025-01-02 20:51:30 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:30 --> Input Class Initialized
INFO - 2025-01-02 20:51:30 --> Language Class Initialized
ERROR - 2025-01-02 20:51:30 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:51:31 --> Config Class Initialized
INFO - 2025-01-02 20:51:31 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:31 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:31 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:31 --> URI Class Initialized
INFO - 2025-01-02 20:51:31 --> Router Class Initialized
INFO - 2025-01-02 20:51:31 --> Output Class Initialized
INFO - 2025-01-02 20:51:31 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:31 --> Input Class Initialized
INFO - 2025-01-02 20:51:31 --> Language Class Initialized
ERROR - 2025-01-02 20:51:31 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:51:31 --> Config Class Initialized
INFO - 2025-01-02 20:51:31 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:31 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:31 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:31 --> URI Class Initialized
INFO - 2025-01-02 20:51:31 --> Router Class Initialized
INFO - 2025-01-02 20:51:31 --> Output Class Initialized
INFO - 2025-01-02 20:51:31 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:31 --> Input Class Initialized
INFO - 2025-01-02 20:51:31 --> Language Class Initialized
ERROR - 2025-01-02 20:51:31 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:32 --> Config Class Initialized
INFO - 2025-01-02 20:51:32 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:32 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:32 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:32 --> URI Class Initialized
INFO - 2025-01-02 20:51:32 --> Router Class Initialized
INFO - 2025-01-02 20:51:32 --> Output Class Initialized
INFO - 2025-01-02 20:51:32 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:32 --> Input Class Initialized
INFO - 2025-01-02 20:51:32 --> Language Class Initialized
ERROR - 2025-01-02 20:51:32 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:51:32 --> Config Class Initialized
INFO - 2025-01-02 20:51:32 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:32 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:32 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:32 --> URI Class Initialized
INFO - 2025-01-02 20:51:32 --> Router Class Initialized
INFO - 2025-01-02 20:51:32 --> Output Class Initialized
INFO - 2025-01-02 20:51:32 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:32 --> Input Class Initialized
INFO - 2025-01-02 20:51:32 --> Language Class Initialized
ERROR - 2025-01-02 20:51:32 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:33 --> Config Class Initialized
INFO - 2025-01-02 20:51:33 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:33 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:33 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:33 --> URI Class Initialized
INFO - 2025-01-02 20:51:33 --> Router Class Initialized
INFO - 2025-01-02 20:51:33 --> Output Class Initialized
INFO - 2025-01-02 20:51:33 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:33 --> Input Class Initialized
INFO - 2025-01-02 20:51:33 --> Language Class Initialized
ERROR - 2025-01-02 20:51:33 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:33 --> Config Class Initialized
INFO - 2025-01-02 20:51:33 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:33 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:33 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:33 --> URI Class Initialized
INFO - 2025-01-02 20:51:33 --> Router Class Initialized
INFO - 2025-01-02 20:51:33 --> Output Class Initialized
INFO - 2025-01-02 20:51:33 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:33 --> Input Class Initialized
INFO - 2025-01-02 20:51:33 --> Language Class Initialized
ERROR - 2025-01-02 20:51:33 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2025-01-02 20:51:34 --> Config Class Initialized
INFO - 2025-01-02 20:51:34 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:34 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:34 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:34 --> URI Class Initialized
INFO - 2025-01-02 20:51:34 --> Router Class Initialized
INFO - 2025-01-02 20:51:34 --> Output Class Initialized
INFO - 2025-01-02 20:51:34 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:34 --> Input Class Initialized
INFO - 2025-01-02 20:51:34 --> Language Class Initialized
ERROR - 2025-01-02 20:51:34 --> 404 Page Not Found: Wp-admin/network
INFO - 2025-01-02 20:51:34 --> Config Class Initialized
INFO - 2025-01-02 20:51:34 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:34 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:34 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:34 --> URI Class Initialized
INFO - 2025-01-02 20:51:34 --> Router Class Initialized
INFO - 2025-01-02 20:51:34 --> Output Class Initialized
INFO - 2025-01-02 20:51:34 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:34 --> Input Class Initialized
INFO - 2025-01-02 20:51:34 --> Language Class Initialized
ERROR - 2025-01-02 20:51:34 --> 404 Page Not Found: Xmrlpcphp/index
INFO - 2025-01-02 20:51:35 --> Config Class Initialized
INFO - 2025-01-02 20:51:35 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:35 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:35 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:35 --> URI Class Initialized
INFO - 2025-01-02 20:51:35 --> Router Class Initialized
INFO - 2025-01-02 20:51:35 --> Output Class Initialized
INFO - 2025-01-02 20:51:35 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:35 --> Input Class Initialized
INFO - 2025-01-02 20:51:35 --> Language Class Initialized
ERROR - 2025-01-02 20:51:35 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
INFO - 2025-01-02 20:51:35 --> Config Class Initialized
INFO - 2025-01-02 20:51:35 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:35 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:35 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:35 --> URI Class Initialized
INFO - 2025-01-02 20:51:35 --> Router Class Initialized
INFO - 2025-01-02 20:51:35 --> Output Class Initialized
INFO - 2025-01-02 20:51:35 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:35 --> Input Class Initialized
INFO - 2025-01-02 20:51:35 --> Language Class Initialized
ERROR - 2025-01-02 20:51:35 --> 404 Page Not Found: Css/xmrlpc.php
INFO - 2025-01-02 20:51:36 --> Config Class Initialized
INFO - 2025-01-02 20:51:36 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:36 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:36 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:36 --> URI Class Initialized
INFO - 2025-01-02 20:51:36 --> Router Class Initialized
INFO - 2025-01-02 20:51:36 --> Output Class Initialized
INFO - 2025-01-02 20:51:36 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:36 --> Input Class Initialized
INFO - 2025-01-02 20:51:36 --> Language Class Initialized
ERROR - 2025-01-02 20:51:36 --> 404 Page Not Found: Wp-admin/user
INFO - 2025-01-02 20:51:36 --> Config Class Initialized
INFO - 2025-01-02 20:51:36 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:36 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:36 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:36 --> URI Class Initialized
INFO - 2025-01-02 20:51:36 --> Router Class Initialized
INFO - 2025-01-02 20:51:36 --> Output Class Initialized
INFO - 2025-01-02 20:51:36 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:36 --> Input Class Initialized
INFO - 2025-01-02 20:51:36 --> Language Class Initialized
ERROR - 2025-01-02 20:51:36 --> 404 Page Not Found: Img/xmrlpc.php
INFO - 2025-01-02 20:51:37 --> Config Class Initialized
INFO - 2025-01-02 20:51:37 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:37 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:37 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:37 --> URI Class Initialized
INFO - 2025-01-02 20:51:37 --> Router Class Initialized
INFO - 2025-01-02 20:51:37 --> Output Class Initialized
INFO - 2025-01-02 20:51:37 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:37 --> Input Class Initialized
INFO - 2025-01-02 20:51:37 --> Language Class Initialized
ERROR - 2025-01-02 20:51:37 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:37 --> Config Class Initialized
INFO - 2025-01-02 20:51:37 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:37 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:37 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:37 --> URI Class Initialized
INFO - 2025-01-02 20:51:37 --> Router Class Initialized
INFO - 2025-01-02 20:51:37 --> Output Class Initialized
INFO - 2025-01-02 20:51:37 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:37 --> Input Class Initialized
INFO - 2025-01-02 20:51:37 --> Language Class Initialized
ERROR - 2025-01-02 20:51:37 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:51:38 --> Config Class Initialized
INFO - 2025-01-02 20:51:38 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:38 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:38 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:38 --> URI Class Initialized
INFO - 2025-01-02 20:51:38 --> Router Class Initialized
INFO - 2025-01-02 20:51:38 --> Output Class Initialized
INFO - 2025-01-02 20:51:38 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:38 --> Input Class Initialized
INFO - 2025-01-02 20:51:38 --> Language Class Initialized
ERROR - 2025-01-02 20:51:38 --> 404 Page Not Found: Images/xmrlpc.php
INFO - 2025-01-02 20:51:38 --> Config Class Initialized
INFO - 2025-01-02 20:51:38 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:38 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:38 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:38 --> URI Class Initialized
INFO - 2025-01-02 20:51:38 --> Router Class Initialized
INFO - 2025-01-02 20:51:38 --> Output Class Initialized
INFO - 2025-01-02 20:51:38 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:38 --> Input Class Initialized
INFO - 2025-01-02 20:51:38 --> Language Class Initialized
ERROR - 2025-01-02 20:51:38 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:51:39 --> Config Class Initialized
INFO - 2025-01-02 20:51:39 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:39 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:39 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:39 --> URI Class Initialized
INFO - 2025-01-02 20:51:39 --> Router Class Initialized
INFO - 2025-01-02 20:51:39 --> Output Class Initialized
INFO - 2025-01-02 20:51:39 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:39 --> Input Class Initialized
INFO - 2025-01-02 20:51:39 --> Language Class Initialized
ERROR - 2025-01-02 20:51:39 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:39 --> Config Class Initialized
INFO - 2025-01-02 20:51:39 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:39 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:39 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:39 --> URI Class Initialized
INFO - 2025-01-02 20:51:39 --> Router Class Initialized
INFO - 2025-01-02 20:51:39 --> Output Class Initialized
INFO - 2025-01-02 20:51:39 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:39 --> Input Class Initialized
INFO - 2025-01-02 20:51:39 --> Language Class Initialized
ERROR - 2025-01-02 20:51:39 --> 404 Page Not Found: Wp-admin/includes
INFO - 2025-01-02 20:51:40 --> Config Class Initialized
INFO - 2025-01-02 20:51:40 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:40 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:40 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:40 --> URI Class Initialized
INFO - 2025-01-02 20:51:40 --> Router Class Initialized
INFO - 2025-01-02 20:51:40 --> Output Class Initialized
INFO - 2025-01-02 20:51:40 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:40 --> Input Class Initialized
INFO - 2025-01-02 20:51:40 --> Language Class Initialized
ERROR - 2025-01-02 20:51:40 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:51:40 --> Config Class Initialized
INFO - 2025-01-02 20:51:40 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:40 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:40 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:40 --> URI Class Initialized
INFO - 2025-01-02 20:51:40 --> Router Class Initialized
INFO - 2025-01-02 20:51:40 --> Output Class Initialized
INFO - 2025-01-02 20:51:40 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:40 --> Input Class Initialized
INFO - 2025-01-02 20:51:40 --> Language Class Initialized
ERROR - 2025-01-02 20:51:40 --> 404 Page Not Found: Wp-admin/xmrlpc.php
INFO - 2025-01-02 20:51:40 --> Config Class Initialized
INFO - 2025-01-02 20:51:40 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:40 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:40 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:41 --> URI Class Initialized
INFO - 2025-01-02 20:51:41 --> Router Class Initialized
INFO - 2025-01-02 20:51:41 --> Output Class Initialized
INFO - 2025-01-02 20:51:41 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:41 --> Input Class Initialized
INFO - 2025-01-02 20:51:41 --> Language Class Initialized
ERROR - 2025-01-02 20:51:41 --> 404 Page Not Found: 403php/index
INFO - 2025-01-02 20:51:41 --> Config Class Initialized
INFO - 2025-01-02 20:51:41 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:41 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:41 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:41 --> URI Class Initialized
INFO - 2025-01-02 20:51:41 --> Router Class Initialized
INFO - 2025-01-02 20:51:41 --> Output Class Initialized
INFO - 2025-01-02 20:51:41 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:41 --> Input Class Initialized
INFO - 2025-01-02 20:51:41 --> Language Class Initialized
ERROR - 2025-01-02 20:51:41 --> 404 Page Not Found: Contentphp/index
INFO - 2025-01-02 20:51:41 --> Config Class Initialized
INFO - 2025-01-02 20:51:41 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:41 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:41 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:41 --> URI Class Initialized
INFO - 2025-01-02 20:51:41 --> Router Class Initialized
INFO - 2025-01-02 20:51:41 --> Output Class Initialized
INFO - 2025-01-02 20:51:41 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:41 --> Input Class Initialized
INFO - 2025-01-02 20:51:41 --> Language Class Initialized
ERROR - 2025-01-02 20:51:41 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:42 --> Config Class Initialized
INFO - 2025-01-02 20:51:42 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:42 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:42 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:42 --> URI Class Initialized
INFO - 2025-01-02 20:51:42 --> Router Class Initialized
INFO - 2025-01-02 20:51:42 --> Output Class Initialized
INFO - 2025-01-02 20:51:42 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:42 --> Input Class Initialized
INFO - 2025-01-02 20:51:42 --> Language Class Initialized
ERROR - 2025-01-02 20:51:42 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:42 --> Config Class Initialized
INFO - 2025-01-02 20:51:42 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:42 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:42 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:42 --> URI Class Initialized
INFO - 2025-01-02 20:51:42 --> Router Class Initialized
INFO - 2025-01-02 20:51:42 --> Output Class Initialized
INFO - 2025-01-02 20:51:42 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:42 --> Input Class Initialized
INFO - 2025-01-02 20:51:42 --> Language Class Initialized
ERROR - 2025-01-02 20:51:42 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:43 --> Config Class Initialized
INFO - 2025-01-02 20:51:43 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:43 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:43 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:43 --> URI Class Initialized
INFO - 2025-01-02 20:51:43 --> Router Class Initialized
INFO - 2025-01-02 20:51:43 --> Output Class Initialized
INFO - 2025-01-02 20:51:43 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:43 --> Input Class Initialized
INFO - 2025-01-02 20:51:43 --> Language Class Initialized
ERROR - 2025-01-02 20:51:43 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:51:43 --> Config Class Initialized
INFO - 2025-01-02 20:51:43 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:43 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:43 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:43 --> URI Class Initialized
INFO - 2025-01-02 20:51:43 --> Router Class Initialized
INFO - 2025-01-02 20:51:43 --> Output Class Initialized
INFO - 2025-01-02 20:51:43 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:43 --> Input Class Initialized
INFO - 2025-01-02 20:51:43 --> Language Class Initialized
ERROR - 2025-01-02 20:51:43 --> 404 Page Not Found: Adminphp/index
INFO - 2025-01-02 20:51:44 --> Config Class Initialized
INFO - 2025-01-02 20:51:44 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:44 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:44 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:44 --> URI Class Initialized
INFO - 2025-01-02 20:51:44 --> Router Class Initialized
INFO - 2025-01-02 20:51:44 --> Output Class Initialized
INFO - 2025-01-02 20:51:44 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:44 --> Input Class Initialized
INFO - 2025-01-02 20:51:44 --> Language Class Initialized
ERROR - 2025-01-02 20:51:44 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:44 --> Config Class Initialized
INFO - 2025-01-02 20:51:44 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:44 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:44 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:44 --> URI Class Initialized
INFO - 2025-01-02 20:51:44 --> Router Class Initialized
INFO - 2025-01-02 20:51:44 --> Output Class Initialized
INFO - 2025-01-02 20:51:44 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:44 --> Input Class Initialized
INFO - 2025-01-02 20:51:44 --> Language Class Initialized
ERROR - 2025-01-02 20:51:44 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:51:45 --> Config Class Initialized
INFO - 2025-01-02 20:51:45 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:45 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:45 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:45 --> URI Class Initialized
INFO - 2025-01-02 20:51:45 --> Router Class Initialized
INFO - 2025-01-02 20:51:45 --> Output Class Initialized
INFO - 2025-01-02 20:51:45 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:45 --> Input Class Initialized
INFO - 2025-01-02 20:51:45 --> Language Class Initialized
ERROR - 2025-01-02 20:51:45 --> 404 Page Not Found: Berlinphp/index
INFO - 2025-01-02 20:51:45 --> Config Class Initialized
INFO - 2025-01-02 20:51:45 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:45 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:45 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:45 --> URI Class Initialized
INFO - 2025-01-02 20:51:45 --> Router Class Initialized
INFO - 2025-01-02 20:51:45 --> Output Class Initialized
INFO - 2025-01-02 20:51:45 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:45 --> Input Class Initialized
INFO - 2025-01-02 20:51:45 --> Language Class Initialized
ERROR - 2025-01-02 20:51:45 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2025-01-02 20:51:46 --> Config Class Initialized
INFO - 2025-01-02 20:51:46 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:46 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:46 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:46 --> URI Class Initialized
INFO - 2025-01-02 20:51:46 --> Router Class Initialized
INFO - 2025-01-02 20:51:46 --> Output Class Initialized
INFO - 2025-01-02 20:51:46 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:46 --> Input Class Initialized
INFO - 2025-01-02 20:51:46 --> Language Class Initialized
ERROR - 2025-01-02 20:51:46 --> 404 Page Not Found: Wp-includes/style-engine
INFO - 2025-01-02 20:51:46 --> Config Class Initialized
INFO - 2025-01-02 20:51:46 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:46 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:46 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:46 --> URI Class Initialized
INFO - 2025-01-02 20:51:46 --> Router Class Initialized
INFO - 2025-01-02 20:51:46 --> Output Class Initialized
INFO - 2025-01-02 20:51:46 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:46 --> Input Class Initialized
INFO - 2025-01-02 20:51:46 --> Language Class Initialized
ERROR - 2025-01-02 20:51:46 --> 404 Page Not Found: Wp-includes/rest-api
INFO - 2025-01-02 20:51:47 --> Config Class Initialized
INFO - 2025-01-02 20:51:47 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:47 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:47 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:47 --> URI Class Initialized
INFO - 2025-01-02 20:51:47 --> Router Class Initialized
INFO - 2025-01-02 20:51:47 --> Output Class Initialized
INFO - 2025-01-02 20:51:47 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:47 --> Input Class Initialized
INFO - 2025-01-02 20:51:47 --> Language Class Initialized
ERROR - 2025-01-02 20:51:47 --> 404 Page Not Found: Wp-includes/SimplePie
INFO - 2025-01-02 20:51:47 --> Config Class Initialized
INFO - 2025-01-02 20:51:47 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:47 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:47 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:47 --> URI Class Initialized
INFO - 2025-01-02 20:51:47 --> Router Class Initialized
INFO - 2025-01-02 20:51:47 --> Output Class Initialized
INFO - 2025-01-02 20:51:47 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:47 --> Input Class Initialized
INFO - 2025-01-02 20:51:47 --> Language Class Initialized
ERROR - 2025-01-02 20:51:47 --> 404 Page Not Found: Wp-content/banners
INFO - 2025-01-02 20:51:48 --> Config Class Initialized
INFO - 2025-01-02 20:51:48 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:48 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:48 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:48 --> URI Class Initialized
INFO - 2025-01-02 20:51:48 --> Router Class Initialized
INFO - 2025-01-02 20:51:48 --> Output Class Initialized
INFO - 2025-01-02 20:51:48 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:48 --> Input Class Initialized
INFO - 2025-01-02 20:51:48 --> Language Class Initialized
ERROR - 2025-01-02 20:51:48 --> 404 Page Not Found: Wp-content/about.php
INFO - 2025-01-02 20:51:48 --> Config Class Initialized
INFO - 2025-01-02 20:51:48 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:48 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:48 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:48 --> URI Class Initialized
INFO - 2025-01-02 20:51:48 --> Router Class Initialized
INFO - 2025-01-02 20:51:48 --> Output Class Initialized
INFO - 2025-01-02 20:51:48 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:48 --> Input Class Initialized
INFO - 2025-01-02 20:51:48 --> Language Class Initialized
ERROR - 2025-01-02 20:51:48 --> 404 Page Not Found: Well-known/about.php
INFO - 2025-01-02 20:51:48 --> Config Class Initialized
INFO - 2025-01-02 20:51:48 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:48 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:48 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:48 --> URI Class Initialized
INFO - 2025-01-02 20:51:48 --> Router Class Initialized
INFO - 2025-01-02 20:51:48 --> Output Class Initialized
INFO - 2025-01-02 20:51:48 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:48 --> Input Class Initialized
INFO - 2025-01-02 20:51:48 --> Language Class Initialized
ERROR - 2025-01-02 20:51:48 --> 404 Page Not Found: Wp-includes/Text
INFO - 2025-01-02 20:51:49 --> Config Class Initialized
INFO - 2025-01-02 20:51:49 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:49 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:49 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:49 --> URI Class Initialized
INFO - 2025-01-02 20:51:49 --> Router Class Initialized
INFO - 2025-01-02 20:51:49 --> Output Class Initialized
INFO - 2025-01-02 20:51:49 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:49 --> Input Class Initialized
INFO - 2025-01-02 20:51:49 --> Language Class Initialized
ERROR - 2025-01-02 20:51:49 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2025-01-02 20:51:49 --> Config Class Initialized
INFO - 2025-01-02 20:51:49 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:49 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:49 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:49 --> URI Class Initialized
INFO - 2025-01-02 20:51:49 --> Router Class Initialized
INFO - 2025-01-02 20:51:49 --> Output Class Initialized
INFO - 2025-01-02 20:51:49 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:49 --> Input Class Initialized
INFO - 2025-01-02 20:51:49 --> Language Class Initialized
ERROR - 2025-01-02 20:51:49 --> 404 Page Not Found: Img/about.php
INFO - 2025-01-02 20:51:50 --> Config Class Initialized
INFO - 2025-01-02 20:51:50 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:50 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:50 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:50 --> URI Class Initialized
INFO - 2025-01-02 20:51:50 --> Router Class Initialized
INFO - 2025-01-02 20:51:50 --> Output Class Initialized
INFO - 2025-01-02 20:51:50 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:50 --> Input Class Initialized
INFO - 2025-01-02 20:51:50 --> Language Class Initialized
ERROR - 2025-01-02 20:51:50 --> 404 Page Not Found: Wp-content/languages
INFO - 2025-01-02 20:51:50 --> Config Class Initialized
INFO - 2025-01-02 20:51:50 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:50 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:50 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:50 --> URI Class Initialized
INFO - 2025-01-02 20:51:50 --> Router Class Initialized
INFO - 2025-01-02 20:51:50 --> Output Class Initialized
INFO - 2025-01-02 20:51:50 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:50 --> Input Class Initialized
INFO - 2025-01-02 20:51:50 --> Language Class Initialized
ERROR - 2025-01-02 20:51:50 --> 404 Page Not Found: Wp-includes/customize
INFO - 2025-01-02 20:51:51 --> Config Class Initialized
INFO - 2025-01-02 20:51:51 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:51 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:51 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:51 --> URI Class Initialized
INFO - 2025-01-02 20:51:51 --> Router Class Initialized
INFO - 2025-01-02 20:51:51 --> Output Class Initialized
INFO - 2025-01-02 20:51:51 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:51 --> Input Class Initialized
INFO - 2025-01-02 20:51:51 --> Language Class Initialized
ERROR - 2025-01-02 20:51:51 --> 404 Page Not Found: Wp-includesbak/html-api
INFO - 2025-01-02 20:51:51 --> Config Class Initialized
INFO - 2025-01-02 20:51:51 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:51 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:51 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:51 --> URI Class Initialized
INFO - 2025-01-02 20:51:51 --> Router Class Initialized
INFO - 2025-01-02 20:51:51 --> Output Class Initialized
INFO - 2025-01-02 20:51:51 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:51 --> Input Class Initialized
INFO - 2025-01-02 20:51:51 --> Language Class Initialized
ERROR - 2025-01-02 20:51:51 --> 404 Page Not Found: Wp-includes/widgets
INFO - 2025-01-02 20:51:52 --> Config Class Initialized
INFO - 2025-01-02 20:51:52 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:52 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:52 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:52 --> URI Class Initialized
INFO - 2025-01-02 20:51:52 --> Router Class Initialized
INFO - 2025-01-02 20:51:52 --> Output Class Initialized
INFO - 2025-01-02 20:51:52 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:52 --> Input Class Initialized
INFO - 2025-01-02 20:51:52 --> Language Class Initialized
ERROR - 2025-01-02 20:51:52 --> 404 Page Not Found: Wp-includes/IXR
INFO - 2025-01-02 20:51:52 --> Config Class Initialized
INFO - 2025-01-02 20:51:52 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:52 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:52 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:52 --> URI Class Initialized
INFO - 2025-01-02 20:51:52 --> Router Class Initialized
INFO - 2025-01-02 20:51:52 --> Output Class Initialized
INFO - 2025-01-02 20:51:52 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:52 --> Input Class Initialized
INFO - 2025-01-02 20:51:52 --> Language Class Initialized
ERROR - 2025-01-02 20:51:52 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:51:53 --> Config Class Initialized
INFO - 2025-01-02 20:51:53 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:53 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:53 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:53 --> URI Class Initialized
INFO - 2025-01-02 20:51:53 --> Router Class Initialized
INFO - 2025-01-02 20:51:53 --> Output Class Initialized
INFO - 2025-01-02 20:51:53 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:53 --> Input Class Initialized
INFO - 2025-01-02 20:51:53 --> Language Class Initialized
ERROR - 2025-01-02 20:51:53 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2025-01-02 20:51:53 --> Config Class Initialized
INFO - 2025-01-02 20:51:53 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:53 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:53 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:53 --> URI Class Initialized
INFO - 2025-01-02 20:51:53 --> Router Class Initialized
INFO - 2025-01-02 20:51:53 --> Output Class Initialized
INFO - 2025-01-02 20:51:53 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:53 --> Input Class Initialized
INFO - 2025-01-02 20:51:53 --> Language Class Initialized
ERROR - 2025-01-02 20:51:53 --> 404 Page Not Found: Wp-includes/pomo
INFO - 2025-01-02 20:51:54 --> Config Class Initialized
INFO - 2025-01-02 20:51:54 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:54 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:54 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:54 --> URI Class Initialized
INFO - 2025-01-02 20:51:54 --> Router Class Initialized
INFO - 2025-01-02 20:51:54 --> Output Class Initialized
INFO - 2025-01-02 20:51:54 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:54 --> Input Class Initialized
INFO - 2025-01-02 20:51:54 --> Language Class Initialized
ERROR - 2025-01-02 20:51:54 --> 404 Page Not Found: Wp-includes/block-patterns
INFO - 2025-01-02 20:51:54 --> Config Class Initialized
INFO - 2025-01-02 20:51:54 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:54 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:54 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:54 --> URI Class Initialized
INFO - 2025-01-02 20:51:54 --> Router Class Initialized
INFO - 2025-01-02 20:51:54 --> Output Class Initialized
INFO - 2025-01-02 20:51:54 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:54 --> Input Class Initialized
INFO - 2025-01-02 20:51:54 --> Language Class Initialized
ERROR - 2025-01-02 20:51:54 --> 404 Page Not Found: Wp-content/updraft
INFO - 2025-01-02 20:51:55 --> Config Class Initialized
INFO - 2025-01-02 20:51:55 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:55 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:55 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:55 --> URI Class Initialized
INFO - 2025-01-02 20:51:55 --> Router Class Initialized
INFO - 2025-01-02 20:51:55 --> Output Class Initialized
INFO - 2025-01-02 20:51:55 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:55 --> Input Class Initialized
INFO - 2025-01-02 20:51:55 --> Language Class Initialized
ERROR - 2025-01-02 20:51:55 --> 404 Page Not Found: Wp-content/upgrade-temp-backup
INFO - 2025-01-02 20:51:55 --> Config Class Initialized
INFO - 2025-01-02 20:51:55 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:55 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:55 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:55 --> URI Class Initialized
INFO - 2025-01-02 20:51:55 --> Router Class Initialized
INFO - 2025-01-02 20:51:55 --> Output Class Initialized
INFO - 2025-01-02 20:51:55 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:55 --> Input Class Initialized
INFO - 2025-01-02 20:51:55 --> Language Class Initialized
ERROR - 2025-01-02 20:51:55 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:51:55 --> Config Class Initialized
INFO - 2025-01-02 20:51:55 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:55 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:55 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:55 --> URI Class Initialized
INFO - 2025-01-02 20:51:55 --> Router Class Initialized
INFO - 2025-01-02 20:51:55 --> Output Class Initialized
INFO - 2025-01-02 20:51:55 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:55 --> Input Class Initialized
INFO - 2025-01-02 20:51:55 --> Language Class Initialized
ERROR - 2025-01-02 20:51:55 --> 404 Page Not Found: Wp-admin/includes
INFO - 2025-01-02 20:51:56 --> Config Class Initialized
INFO - 2025-01-02 20:51:56 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:56 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:56 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:56 --> URI Class Initialized
INFO - 2025-01-02 20:51:56 --> Router Class Initialized
INFO - 2025-01-02 20:51:56 --> Output Class Initialized
INFO - 2025-01-02 20:51:56 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:56 --> Input Class Initialized
INFO - 2025-01-02 20:51:56 --> Language Class Initialized
ERROR - 2025-01-02 20:51:56 --> 404 Page Not Found: Images/about.php
INFO - 2025-01-02 20:51:56 --> Config Class Initialized
INFO - 2025-01-02 20:51:56 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:56 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:56 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:56 --> URI Class Initialized
INFO - 2025-01-02 20:51:56 --> Router Class Initialized
INFO - 2025-01-02 20:51:56 --> Output Class Initialized
INFO - 2025-01-02 20:51:56 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:56 --> Input Class Initialized
INFO - 2025-01-02 20:51:56 --> Language Class Initialized
ERROR - 2025-01-02 20:51:56 --> 404 Page Not Found: Wp-content/blogs.dir
INFO - 2025-01-02 20:51:57 --> Config Class Initialized
INFO - 2025-01-02 20:51:57 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:57 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:57 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:57 --> URI Class Initialized
INFO - 2025-01-02 20:51:57 --> Router Class Initialized
INFO - 2025-01-02 20:51:57 --> Output Class Initialized
INFO - 2025-01-02 20:51:57 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:57 --> Input Class Initialized
INFO - 2025-01-02 20:51:57 --> Language Class Initialized
ERROR - 2025-01-02 20:51:57 --> 404 Page Not Found: Wp-includes/images
INFO - 2025-01-02 20:51:57 --> Config Class Initialized
INFO - 2025-01-02 20:51:57 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:57 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:57 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:57 --> URI Class Initialized
INFO - 2025-01-02 20:51:57 --> Router Class Initialized
INFO - 2025-01-02 20:51:57 --> Output Class Initialized
INFO - 2025-01-02 20:51:57 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:57 --> Input Class Initialized
INFO - 2025-01-02 20:51:57 --> Language Class Initialized
ERROR - 2025-01-02 20:51:57 --> 404 Page Not Found: Wp-includes/about.php
INFO - 2025-01-02 20:51:58 --> Config Class Initialized
INFO - 2025-01-02 20:51:58 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:58 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:58 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:58 --> URI Class Initialized
INFO - 2025-01-02 20:51:58 --> Router Class Initialized
INFO - 2025-01-02 20:51:58 --> Output Class Initialized
INFO - 2025-01-02 20:51:58 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:58 --> Input Class Initialized
INFO - 2025-01-02 20:51:58 --> Language Class Initialized
ERROR - 2025-01-02 20:51:58 --> 404 Page Not Found: Cgi-bin/about.php
INFO - 2025-01-02 20:51:58 --> Config Class Initialized
INFO - 2025-01-02 20:51:58 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:58 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:58 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:58 --> URI Class Initialized
INFO - 2025-01-02 20:51:58 --> Router Class Initialized
INFO - 2025-01-02 20:51:58 --> Output Class Initialized
INFO - 2025-01-02 20:51:58 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:58 --> Input Class Initialized
INFO - 2025-01-02 20:51:58 --> Language Class Initialized
ERROR - 2025-01-02 20:51:58 --> 404 Page Not Found: Wp-content/gallery
INFO - 2025-01-02 20:51:59 --> Config Class Initialized
INFO - 2025-01-02 20:51:59 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:59 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:59 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:59 --> URI Class Initialized
INFO - 2025-01-02 20:51:59 --> Router Class Initialized
INFO - 2025-01-02 20:51:59 --> Output Class Initialized
INFO - 2025-01-02 20:51:59 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:59 --> Input Class Initialized
INFO - 2025-01-02 20:51:59 --> Language Class Initialized
ERROR - 2025-01-02 20:51:59 --> 404 Page Not Found: Wp-includes/blocks
INFO - 2025-01-02 20:51:59 --> Config Class Initialized
INFO - 2025-01-02 20:51:59 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:51:59 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:51:59 --> Utf8 Class Initialized
INFO - 2025-01-02 20:51:59 --> URI Class Initialized
INFO - 2025-01-02 20:51:59 --> Router Class Initialized
INFO - 2025-01-02 20:51:59 --> Output Class Initialized
INFO - 2025-01-02 20:51:59 --> Security Class Initialized
DEBUG - 2025-01-02 20:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:51:59 --> Input Class Initialized
INFO - 2025-01-02 20:51:59 --> Language Class Initialized
ERROR - 2025-01-02 20:51:59 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:00 --> Config Class Initialized
INFO - 2025-01-02 20:52:00 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:00 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:00 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:00 --> URI Class Initialized
INFO - 2025-01-02 20:52:00 --> Router Class Initialized
INFO - 2025-01-02 20:52:00 --> Output Class Initialized
INFO - 2025-01-02 20:52:00 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:00 --> Input Class Initialized
INFO - 2025-01-02 20:52:00 --> Language Class Initialized
ERROR - 2025-01-02 20:52:00 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:52:00 --> Config Class Initialized
INFO - 2025-01-02 20:52:00 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:00 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:00 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:00 --> URI Class Initialized
INFO - 2025-01-02 20:52:00 --> Router Class Initialized
INFO - 2025-01-02 20:52:00 --> Output Class Initialized
INFO - 2025-01-02 20:52:00 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:00 --> Input Class Initialized
INFO - 2025-01-02 20:52:00 --> Language Class Initialized
ERROR - 2025-01-02 20:52:00 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2025-01-02 20:52:01 --> Config Class Initialized
INFO - 2025-01-02 20:52:01 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:01 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:01 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:01 --> URI Class Initialized
INFO - 2025-01-02 20:52:01 --> Router Class Initialized
INFO - 2025-01-02 20:52:01 --> Output Class Initialized
INFO - 2025-01-02 20:52:01 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:01 --> Input Class Initialized
INFO - 2025-01-02 20:52:01 --> Language Class Initialized
ERROR - 2025-01-02 20:52:01 --> 404 Page Not Found: Wp-admin/network
INFO - 2025-01-02 20:52:01 --> Config Class Initialized
INFO - 2025-01-02 20:52:01 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:01 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:01 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:01 --> URI Class Initialized
INFO - 2025-01-02 20:52:01 --> Router Class Initialized
INFO - 2025-01-02 20:52:01 --> Output Class Initialized
INFO - 2025-01-02 20:52:01 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:01 --> Input Class Initialized
INFO - 2025-01-02 20:52:01 --> Language Class Initialized
ERROR - 2025-01-02 20:52:01 --> 404 Page Not Found: Cloudphp/index
INFO - 2025-01-02 20:52:02 --> Config Class Initialized
INFO - 2025-01-02 20:52:02 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:02 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:02 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:02 --> URI Class Initialized
INFO - 2025-01-02 20:52:02 --> Router Class Initialized
INFO - 2025-01-02 20:52:02 --> Output Class Initialized
INFO - 2025-01-02 20:52:02 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:02 --> Input Class Initialized
INFO - 2025-01-02 20:52:02 --> Language Class Initialized
ERROR - 2025-01-02 20:52:02 --> 404 Page Not Found: Cgi-bin/cloud.php
INFO - 2025-01-02 20:52:02 --> Config Class Initialized
INFO - 2025-01-02 20:52:02 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:02 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:02 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:02 --> URI Class Initialized
INFO - 2025-01-02 20:52:02 --> Router Class Initialized
INFO - 2025-01-02 20:52:02 --> Output Class Initialized
INFO - 2025-01-02 20:52:02 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:02 --> Input Class Initialized
INFO - 2025-01-02 20:52:02 --> Language Class Initialized
ERROR - 2025-01-02 20:52:02 --> 404 Page Not Found: Wp-content/updates.php
INFO - 2025-01-02 20:52:03 --> Config Class Initialized
INFO - 2025-01-02 20:52:03 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:03 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:03 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:03 --> URI Class Initialized
INFO - 2025-01-02 20:52:03 --> Router Class Initialized
INFO - 2025-01-02 20:52:03 --> Output Class Initialized
INFO - 2025-01-02 20:52:03 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:03 --> Input Class Initialized
INFO - 2025-01-02 20:52:03 --> Language Class Initialized
ERROR - 2025-01-02 20:52:03 --> 404 Page Not Found: Css/cloud.php
INFO - 2025-01-02 20:52:03 --> Config Class Initialized
INFO - 2025-01-02 20:52:03 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:03 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:03 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:03 --> URI Class Initialized
INFO - 2025-01-02 20:52:03 --> Router Class Initialized
INFO - 2025-01-02 20:52:03 --> Output Class Initialized
INFO - 2025-01-02 20:52:03 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:03 --> Input Class Initialized
INFO - 2025-01-02 20:52:03 --> Language Class Initialized
ERROR - 2025-01-02 20:52:03 --> 404 Page Not Found: Wp-admin/user
INFO - 2025-01-02 20:52:04 --> Config Class Initialized
INFO - 2025-01-02 20:52:04 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:04 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:04 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:04 --> URI Class Initialized
INFO - 2025-01-02 20:52:04 --> Router Class Initialized
INFO - 2025-01-02 20:52:04 --> Output Class Initialized
INFO - 2025-01-02 20:52:04 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:04 --> Input Class Initialized
INFO - 2025-01-02 20:52:04 --> Language Class Initialized
ERROR - 2025-01-02 20:52:04 --> 404 Page Not Found: Img/cloud.php
INFO - 2025-01-02 20:52:04 --> Config Class Initialized
INFO - 2025-01-02 20:52:04 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:04 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:04 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:04 --> URI Class Initialized
INFO - 2025-01-02 20:52:04 --> Router Class Initialized
INFO - 2025-01-02 20:52:04 --> Output Class Initialized
INFO - 2025-01-02 20:52:04 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:04 --> Input Class Initialized
INFO - 2025-01-02 20:52:04 --> Language Class Initialized
ERROR - 2025-01-02 20:52:04 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:05 --> Config Class Initialized
INFO - 2025-01-02 20:52:05 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:05 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:05 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:05 --> URI Class Initialized
INFO - 2025-01-02 20:52:05 --> Router Class Initialized
INFO - 2025-01-02 20:52:05 --> Output Class Initialized
INFO - 2025-01-02 20:52:05 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:05 --> Input Class Initialized
INFO - 2025-01-02 20:52:05 --> Language Class Initialized
ERROR - 2025-01-02 20:52:05 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:52:05 --> Config Class Initialized
INFO - 2025-01-02 20:52:05 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:05 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:05 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:05 --> URI Class Initialized
INFO - 2025-01-02 20:52:05 --> Router Class Initialized
INFO - 2025-01-02 20:52:05 --> Output Class Initialized
INFO - 2025-01-02 20:52:05 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:05 --> Input Class Initialized
INFO - 2025-01-02 20:52:05 --> Language Class Initialized
ERROR - 2025-01-02 20:52:05 --> 404 Page Not Found: Avaaphp/index
INFO - 2025-01-02 20:52:06 --> Config Class Initialized
INFO - 2025-01-02 20:52:06 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:06 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:06 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:06 --> URI Class Initialized
INFO - 2025-01-02 20:52:06 --> Router Class Initialized
INFO - 2025-01-02 20:52:06 --> Output Class Initialized
INFO - 2025-01-02 20:52:06 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:06 --> Input Class Initialized
INFO - 2025-01-02 20:52:06 --> Language Class Initialized
ERROR - 2025-01-02 20:52:06 --> 404 Page Not Found: Images/cloud.php
INFO - 2025-01-02 20:52:06 --> Config Class Initialized
INFO - 2025-01-02 20:52:06 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:06 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:06 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:06 --> URI Class Initialized
INFO - 2025-01-02 20:52:06 --> Router Class Initialized
INFO - 2025-01-02 20:52:06 --> Output Class Initialized
INFO - 2025-01-02 20:52:06 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:06 --> Input Class Initialized
INFO - 2025-01-02 20:52:06 --> Language Class Initialized
ERROR - 2025-01-02 20:52:06 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:52:07 --> Config Class Initialized
INFO - 2025-01-02 20:52:07 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:07 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:07 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:07 --> URI Class Initialized
INFO - 2025-01-02 20:52:07 --> Router Class Initialized
INFO - 2025-01-02 20:52:07 --> Output Class Initialized
INFO - 2025-01-02 20:52:07 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:07 --> Input Class Initialized
INFO - 2025-01-02 20:52:07 --> Language Class Initialized
ERROR - 2025-01-02 20:52:07 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2025-01-02 20:52:07 --> Config Class Initialized
INFO - 2025-01-02 20:52:07 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:07 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:07 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:07 --> URI Class Initialized
INFO - 2025-01-02 20:52:07 --> Router Class Initialized
INFO - 2025-01-02 20:52:07 --> Output Class Initialized
INFO - 2025-01-02 20:52:07 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:07 --> Input Class Initialized
INFO - 2025-01-02 20:52:07 --> Language Class Initialized
ERROR - 2025-01-02 20:52:07 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:07 --> Config Class Initialized
INFO - 2025-01-02 20:52:07 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:08 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:08 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:08 --> URI Class Initialized
INFO - 2025-01-02 20:52:08 --> Router Class Initialized
INFO - 2025-01-02 20:52:08 --> Output Class Initialized
INFO - 2025-01-02 20:52:08 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:08 --> Input Class Initialized
INFO - 2025-01-02 20:52:08 --> Language Class Initialized
ERROR - 2025-01-02 20:52:08 --> 404 Page Not Found: Wp-admin/includes
INFO - 2025-01-02 20:52:08 --> Config Class Initialized
INFO - 2025-01-02 20:52:08 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:08 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:08 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:08 --> URI Class Initialized
INFO - 2025-01-02 20:52:08 --> Router Class Initialized
INFO - 2025-01-02 20:52:08 --> Output Class Initialized
INFO - 2025-01-02 20:52:08 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:08 --> Input Class Initialized
INFO - 2025-01-02 20:52:08 --> Language Class Initialized
ERROR - 2025-01-02 20:52:08 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:08 --> Config Class Initialized
INFO - 2025-01-02 20:52:08 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:08 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:08 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:08 --> URI Class Initialized
INFO - 2025-01-02 20:52:08 --> Router Class Initialized
INFO - 2025-01-02 20:52:08 --> Output Class Initialized
INFO - 2025-01-02 20:52:08 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:08 --> Input Class Initialized
INFO - 2025-01-02 20:52:08 --> Language Class Initialized
ERROR - 2025-01-02 20:52:08 --> 404 Page Not Found: Wp-admin/cloud.php
INFO - 2025-01-02 20:52:09 --> Config Class Initialized
INFO - 2025-01-02 20:52:09 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:09 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:09 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:09 --> URI Class Initialized
INFO - 2025-01-02 20:52:09 --> Router Class Initialized
INFO - 2025-01-02 20:52:09 --> Output Class Initialized
INFO - 2025-01-02 20:52:09 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:09 --> Input Class Initialized
INFO - 2025-01-02 20:52:09 --> Language Class Initialized
ERROR - 2025-01-02 20:52:09 --> 404 Page Not Found: Updatesphp/index
INFO - 2025-01-02 20:52:09 --> Config Class Initialized
INFO - 2025-01-02 20:52:09 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:09 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:09 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:09 --> URI Class Initialized
INFO - 2025-01-02 20:52:09 --> Router Class Initialized
INFO - 2025-01-02 20:52:09 --> Output Class Initialized
INFO - 2025-01-02 20:52:09 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:09 --> Input Class Initialized
INFO - 2025-01-02 20:52:09 --> Language Class Initialized
ERROR - 2025-01-02 20:52:09 --> 404 Page Not Found: Libraries/legacy
INFO - 2025-01-02 20:52:10 --> Config Class Initialized
INFO - 2025-01-02 20:52:10 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:10 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:10 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:10 --> URI Class Initialized
INFO - 2025-01-02 20:52:10 --> Router Class Initialized
INFO - 2025-01-02 20:52:10 --> Output Class Initialized
INFO - 2025-01-02 20:52:10 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:10 --> Input Class Initialized
INFO - 2025-01-02 20:52:10 --> Language Class Initialized
ERROR - 2025-01-02 20:52:10 --> 404 Page Not Found: Libraries/phpmailer
INFO - 2025-01-02 20:52:10 --> Config Class Initialized
INFO - 2025-01-02 20:52:10 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:10 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:10 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:10 --> URI Class Initialized
INFO - 2025-01-02 20:52:10 --> Router Class Initialized
INFO - 2025-01-02 20:52:10 --> Output Class Initialized
INFO - 2025-01-02 20:52:10 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:10 --> Input Class Initialized
INFO - 2025-01-02 20:52:10 --> Language Class Initialized
ERROR - 2025-01-02 20:52:10 --> 404 Page Not Found: Libraries/vendor
INFO - 2025-01-02 20:52:11 --> Config Class Initialized
INFO - 2025-01-02 20:52:11 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:11 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:11 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:11 --> URI Class Initialized
INFO - 2025-01-02 20:52:11 --> Router Class Initialized
INFO - 2025-01-02 20:52:11 --> Output Class Initialized
INFO - 2025-01-02 20:52:11 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:11 --> Input Class Initialized
INFO - 2025-01-02 20:52:11 --> Language Class Initialized
ERROR - 2025-01-02 20:52:11 --> 404 Page Not Found: Alfa-rexphp7/index
INFO - 2025-01-02 20:52:11 --> Config Class Initialized
INFO - 2025-01-02 20:52:11 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:11 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:11 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:11 --> URI Class Initialized
INFO - 2025-01-02 20:52:11 --> Router Class Initialized
INFO - 2025-01-02 20:52:11 --> Output Class Initialized
INFO - 2025-01-02 20:52:11 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:11 --> Input Class Initialized
INFO - 2025-01-02 20:52:11 --> Language Class Initialized
ERROR - 2025-01-02 20:52:11 --> 404 Page Not Found: Alfanewphp/index
INFO - 2025-01-02 20:52:12 --> Config Class Initialized
INFO - 2025-01-02 20:52:12 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:12 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:12 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:12 --> URI Class Initialized
INFO - 2025-01-02 20:52:12 --> Router Class Initialized
INFO - 2025-01-02 20:52:12 --> Output Class Initialized
INFO - 2025-01-02 20:52:12 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:12 --> Input Class Initialized
INFO - 2025-01-02 20:52:12 --> Language Class Initialized
ERROR - 2025-01-02 20:52:12 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:52:12 --> Config Class Initialized
INFO - 2025-01-02 20:52:12 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:12 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:12 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:12 --> URI Class Initialized
INFO - 2025-01-02 20:52:12 --> Router Class Initialized
INFO - 2025-01-02 20:52:12 --> Output Class Initialized
INFO - 2025-01-02 20:52:12 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:12 --> Input Class Initialized
INFO - 2025-01-02 20:52:12 --> Language Class Initialized
ERROR - 2025-01-02 20:52:12 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:52:13 --> Config Class Initialized
INFO - 2025-01-02 20:52:13 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:13 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:13 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:13 --> URI Class Initialized
INFO - 2025-01-02 20:52:13 --> Router Class Initialized
INFO - 2025-01-02 20:52:13 --> Output Class Initialized
INFO - 2025-01-02 20:52:13 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:13 --> Input Class Initialized
INFO - 2025-01-02 20:52:13 --> Language Class Initialized
ERROR - 2025-01-02 20:52:13 --> 404 Page Not Found: Wp-pphp7/index
INFO - 2025-01-02 20:52:13 --> Config Class Initialized
INFO - 2025-01-02 20:52:13 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:13 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:13 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:13 --> URI Class Initialized
INFO - 2025-01-02 20:52:13 --> Router Class Initialized
INFO - 2025-01-02 20:52:13 --> Output Class Initialized
INFO - 2025-01-02 20:52:13 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:13 --> Input Class Initialized
INFO - 2025-01-02 20:52:13 --> Language Class Initialized
ERROR - 2025-01-02 20:52:13 --> 404 Page Not Found: Wp-admin/repeater.php
INFO - 2025-01-02 20:52:14 --> Config Class Initialized
INFO - 2025-01-02 20:52:14 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:14 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:14 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:14 --> URI Class Initialized
INFO - 2025-01-02 20:52:14 --> Router Class Initialized
INFO - 2025-01-02 20:52:14 --> Output Class Initialized
INFO - 2025-01-02 20:52:14 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:14 --> Input Class Initialized
INFO - 2025-01-02 20:52:14 --> Language Class Initialized
ERROR - 2025-01-02 20:52:14 --> 404 Page Not Found: Wp-includes/repeater.php
INFO - 2025-01-02 20:52:14 --> Config Class Initialized
INFO - 2025-01-02 20:52:14 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:14 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:14 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:14 --> URI Class Initialized
INFO - 2025-01-02 20:52:14 --> Router Class Initialized
INFO - 2025-01-02 20:52:14 --> Output Class Initialized
INFO - 2025-01-02 20:52:14 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:14 --> Input Class Initialized
INFO - 2025-01-02 20:52:14 --> Language Class Initialized
ERROR - 2025-01-02 20:52:14 --> 404 Page Not Found: Wp-content/repeater.php
INFO - 2025-01-02 20:52:15 --> Config Class Initialized
INFO - 2025-01-02 20:52:15 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:15 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:15 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:15 --> URI Class Initialized
INFO - 2025-01-02 20:52:15 --> Router Class Initialized
INFO - 2025-01-02 20:52:15 --> Output Class Initialized
INFO - 2025-01-02 20:52:15 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:15 --> Input Class Initialized
INFO - 2025-01-02 20:52:15 --> Language Class Initialized
ERROR - 2025-01-02 20:52:15 --> 404 Page Not Found: Wsoyanzphp/index
INFO - 2025-01-02 20:52:15 --> Config Class Initialized
INFO - 2025-01-02 20:52:15 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:15 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:15 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:15 --> URI Class Initialized
INFO - 2025-01-02 20:52:15 --> Router Class Initialized
INFO - 2025-01-02 20:52:15 --> Output Class Initialized
INFO - 2025-01-02 20:52:15 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:15 --> Input Class Initialized
INFO - 2025-01-02 20:52:15 --> Language Class Initialized
ERROR - 2025-01-02 20:52:15 --> 404 Page Not Found: Yanzphp/index
INFO - 2025-01-02 20:52:16 --> Config Class Initialized
INFO - 2025-01-02 20:52:16 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:16 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:16 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:16 --> URI Class Initialized
INFO - 2025-01-02 20:52:16 --> Router Class Initialized
INFO - 2025-01-02 20:52:16 --> Output Class Initialized
INFO - 2025-01-02 20:52:16 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:16 --> Input Class Initialized
INFO - 2025-01-02 20:52:16 --> Language Class Initialized
ERROR - 2025-01-02 20:52:16 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:52:16 --> Config Class Initialized
INFO - 2025-01-02 20:52:16 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:16 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:16 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:16 --> URI Class Initialized
INFO - 2025-01-02 20:52:16 --> Router Class Initialized
INFO - 2025-01-02 20:52:16 --> Output Class Initialized
INFO - 2025-01-02 20:52:16 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:16 --> Input Class Initialized
INFO - 2025-01-02 20:52:16 --> Language Class Initialized
ERROR - 2025-01-02 20:52:16 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:52:17 --> Config Class Initialized
INFO - 2025-01-02 20:52:17 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:17 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:17 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:17 --> URI Class Initialized
INFO - 2025-01-02 20:52:17 --> Router Class Initialized
INFO - 2025-01-02 20:52:17 --> Output Class Initialized
INFO - 2025-01-02 20:52:17 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:17 --> Input Class Initialized
INFO - 2025-01-02 20:52:17 --> Language Class Initialized
ERROR - 2025-01-02 20:52:17 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:52:17 --> Config Class Initialized
INFO - 2025-01-02 20:52:17 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:17 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:17 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:17 --> URI Class Initialized
INFO - 2025-01-02 20:52:17 --> Router Class Initialized
INFO - 2025-01-02 20:52:17 --> Output Class Initialized
INFO - 2025-01-02 20:52:17 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:17 --> Input Class Initialized
INFO - 2025-01-02 20:52:17 --> Language Class Initialized
ERROR - 2025-01-02 20:52:17 --> 404 Page Not Found: Cache-compatphp/index
INFO - 2025-01-02 20:52:17 --> Config Class Initialized
INFO - 2025-01-02 20:52:17 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:17 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:17 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:17 --> URI Class Initialized
INFO - 2025-01-02 20:52:17 --> Router Class Initialized
INFO - 2025-01-02 20:52:17 --> Output Class Initialized
INFO - 2025-01-02 20:52:17 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:17 --> Input Class Initialized
INFO - 2025-01-02 20:52:17 --> Language Class Initialized
ERROR - 2025-01-02 20:52:17 --> 404 Page Not Found: Ajax-actionsphp/index
INFO - 2025-01-02 20:52:18 --> Config Class Initialized
INFO - 2025-01-02 20:52:18 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:18 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:18 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:18 --> URI Class Initialized
INFO - 2025-01-02 20:52:18 --> Router Class Initialized
INFO - 2025-01-02 20:52:18 --> Output Class Initialized
INFO - 2025-01-02 20:52:18 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:18 --> Input Class Initialized
INFO - 2025-01-02 20:52:18 --> Language Class Initialized
ERROR - 2025-01-02 20:52:18 --> 404 Page Not Found: Wp-admin/ajax-actions.php
INFO - 2025-01-02 20:52:19 --> Config Class Initialized
INFO - 2025-01-02 20:52:19 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:19 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:19 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:19 --> URI Class Initialized
INFO - 2025-01-02 20:52:19 --> Router Class Initialized
INFO - 2025-01-02 20:52:19 --> Output Class Initialized
INFO - 2025-01-02 20:52:19 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:19 --> Input Class Initialized
INFO - 2025-01-02 20:52:19 --> Language Class Initialized
ERROR - 2025-01-02 20:52:19 --> 404 Page Not Found: Wp-consarphp/index
INFO - 2025-01-02 20:52:19 --> Config Class Initialized
INFO - 2025-01-02 20:52:19 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:19 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:19 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:19 --> URI Class Initialized
INFO - 2025-01-02 20:52:19 --> Router Class Initialized
INFO - 2025-01-02 20:52:19 --> Output Class Initialized
INFO - 2025-01-02 20:52:19 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:19 --> Input Class Initialized
INFO - 2025-01-02 20:52:19 --> Language Class Initialized
ERROR - 2025-01-02 20:52:19 --> 404 Page Not Found: Repeaterphp/index
INFO - 2025-01-02 20:52:19 --> Config Class Initialized
INFO - 2025-01-02 20:52:19 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:20 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:20 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:20 --> URI Class Initialized
INFO - 2025-01-02 20:52:20 --> Router Class Initialized
INFO - 2025-01-02 20:52:20 --> Output Class Initialized
INFO - 2025-01-02 20:52:20 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:20 --> Input Class Initialized
INFO - 2025-01-02 20:52:20 --> Language Class Initialized
ERROR - 2025-01-02 20:52:20 --> 404 Page Not Found: Admin-postphp/index
INFO - 2025-01-02 20:52:20 --> Config Class Initialized
INFO - 2025-01-02 20:52:20 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:20 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:20 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:20 --> URI Class Initialized
INFO - 2025-01-02 20:52:20 --> Router Class Initialized
INFO - 2025-01-02 20:52:20 --> Output Class Initialized
INFO - 2025-01-02 20:52:20 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:20 --> Input Class Initialized
INFO - 2025-01-02 20:52:20 --> Language Class Initialized
ERROR - 2025-01-02 20:52:20 --> 404 Page Not Found: Wp-admin/maint
INFO - 2025-01-02 20:52:20 --> Config Class Initialized
INFO - 2025-01-02 20:52:20 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:20 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:20 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:20 --> URI Class Initialized
INFO - 2025-01-02 20:52:20 --> Router Class Initialized
INFO - 2025-01-02 20:52:20 --> Output Class Initialized
INFO - 2025-01-02 20:52:20 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:20 --> Input Class Initialized
INFO - 2025-01-02 20:52:20 --> Language Class Initialized
ERROR - 2025-01-02 20:52:20 --> 404 Page Not Found: Wp-admin/dropdown.php
INFO - 2025-01-02 20:52:21 --> Config Class Initialized
INFO - 2025-01-02 20:52:21 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:21 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:21 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:21 --> URI Class Initialized
INFO - 2025-01-02 20:52:21 --> Router Class Initialized
INFO - 2025-01-02 20:52:21 --> Output Class Initialized
INFO - 2025-01-02 20:52:21 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:21 --> Input Class Initialized
INFO - 2025-01-02 20:52:21 --> Language Class Initialized
ERROR - 2025-01-02 20:52:21 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:21 --> Config Class Initialized
INFO - 2025-01-02 20:52:21 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:21 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:21 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:21 --> URI Class Initialized
INFO - 2025-01-02 20:52:21 --> Router Class Initialized
INFO - 2025-01-02 20:52:21 --> Output Class Initialized
INFO - 2025-01-02 20:52:21 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:21 --> Input Class Initialized
INFO - 2025-01-02 20:52:21 --> Language Class Initialized
ERROR - 2025-01-02 20:52:21 --> 404 Page Not Found: Dropdownphp/index
INFO - 2025-01-02 20:52:22 --> Config Class Initialized
INFO - 2025-01-02 20:52:22 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:22 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:22 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:22 --> URI Class Initialized
INFO - 2025-01-02 20:52:22 --> Router Class Initialized
INFO - 2025-01-02 20:52:22 --> Output Class Initialized
INFO - 2025-01-02 20:52:22 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:22 --> Input Class Initialized
INFO - 2025-01-02 20:52:22 --> Language Class Initialized
ERROR - 2025-01-02 20:52:22 --> 404 Page Not Found: Aboutphp/index
INFO - 2025-01-02 20:52:22 --> Config Class Initialized
INFO - 2025-01-02 20:52:22 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:22 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:22 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:22 --> URI Class Initialized
INFO - 2025-01-02 20:52:22 --> Router Class Initialized
INFO - 2025-01-02 20:52:22 --> Output Class Initialized
INFO - 2025-01-02 20:52:22 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:22 --> Input Class Initialized
INFO - 2025-01-02 20:52:22 --> Language Class Initialized
ERROR - 2025-01-02 20:52:22 --> 404 Page Not Found: Adminphp/index
INFO - 2025-01-02 20:52:23 --> Config Class Initialized
INFO - 2025-01-02 20:52:23 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:23 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:23 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:23 --> URI Class Initialized
INFO - 2025-01-02 20:52:23 --> Router Class Initialized
INFO - 2025-01-02 20:52:23 --> Output Class Initialized
INFO - 2025-01-02 20:52:23 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:23 --> Input Class Initialized
INFO - 2025-01-02 20:52:23 --> Language Class Initialized
ERROR - 2025-01-02 20:52:23 --> 404 Page Not Found: Aboutphp7/index
INFO - 2025-01-02 20:52:23 --> Config Class Initialized
INFO - 2025-01-02 20:52:23 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:23 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:23 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:23 --> URI Class Initialized
INFO - 2025-01-02 20:52:23 --> Router Class Initialized
INFO - 2025-01-02 20:52:23 --> Output Class Initialized
INFO - 2025-01-02 20:52:23 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:23 --> Input Class Initialized
INFO - 2025-01-02 20:52:23 --> Language Class Initialized
ERROR - 2025-01-02 20:52:23 --> 404 Page Not Found: Alfanewphp7/index
INFO - 2025-01-02 20:52:24 --> Config Class Initialized
INFO - 2025-01-02 20:52:24 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:24 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:24 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:24 --> URI Class Initialized
INFO - 2025-01-02 20:52:24 --> Router Class Initialized
INFO - 2025-01-02 20:52:24 --> Output Class Initialized
INFO - 2025-01-02 20:52:24 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:24 --> Input Class Initialized
INFO - 2025-01-02 20:52:24 --> Language Class Initialized
ERROR - 2025-01-02 20:52:24 --> 404 Page Not Found: Adminfunsphp7/index
INFO - 2025-01-02 20:52:24 --> Config Class Initialized
INFO - 2025-01-02 20:52:24 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:24 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:24 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:24 --> URI Class Initialized
INFO - 2025-01-02 20:52:24 --> Router Class Initialized
INFO - 2025-01-02 20:52:24 --> Output Class Initialized
INFO - 2025-01-02 20:52:24 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:24 --> Input Class Initialized
INFO - 2025-01-02 20:52:24 --> Language Class Initialized
ERROR - 2025-01-02 20:52:24 --> 404 Page Not Found: Ebsphp7/index
INFO - 2025-01-02 20:52:25 --> Config Class Initialized
INFO - 2025-01-02 20:52:25 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:25 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:25 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:25 --> URI Class Initialized
INFO - 2025-01-02 20:52:25 --> Router Class Initialized
INFO - 2025-01-02 20:52:25 --> Output Class Initialized
INFO - 2025-01-02 20:52:25 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:25 --> Input Class Initialized
INFO - 2025-01-02 20:52:25 --> Language Class Initialized
ERROR - 2025-01-02 20:52:25 --> 404 Page Not Found: Wsphp7/index
INFO - 2025-01-02 20:52:25 --> Config Class Initialized
INFO - 2025-01-02 20:52:25 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:25 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:25 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:25 --> URI Class Initialized
INFO - 2025-01-02 20:52:25 --> Router Class Initialized
INFO - 2025-01-02 20:52:25 --> Output Class Initialized
INFO - 2025-01-02 20:52:25 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:25 --> Input Class Initialized
INFO - 2025-01-02 20:52:25 --> Language Class Initialized
ERROR - 2025-01-02 20:52:25 --> 404 Page Not Found: Alfanew2php7/index
INFO - 2025-01-02 20:52:26 --> Config Class Initialized
INFO - 2025-01-02 20:52:26 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:26 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:26 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:26 --> URI Class Initialized
INFO - 2025-01-02 20:52:26 --> Router Class Initialized
INFO - 2025-01-02 20:52:26 --> Output Class Initialized
INFO - 2025-01-02 20:52:26 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:26 --> Input Class Initialized
INFO - 2025-01-02 20:52:26 --> Language Class Initialized
ERROR - 2025-01-02 20:52:26 --> 404 Page Not Found: Alfa-rex2php7/index
INFO - 2025-01-02 20:52:26 --> Config Class Initialized
INFO - 2025-01-02 20:52:26 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:26 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:26 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:26 --> URI Class Initialized
INFO - 2025-01-02 20:52:26 --> Router Class Initialized
INFO - 2025-01-02 20:52:26 --> Output Class Initialized
INFO - 2025-01-02 20:52:26 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:26 --> Input Class Initialized
INFO - 2025-01-02 20:52:26 --> Language Class Initialized
ERROR - 2025-01-02 20:52:26 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:52:27 --> Config Class Initialized
INFO - 2025-01-02 20:52:27 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:27 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:27 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:27 --> URI Class Initialized
INFO - 2025-01-02 20:52:27 --> Router Class Initialized
INFO - 2025-01-02 20:52:27 --> Output Class Initialized
INFO - 2025-01-02 20:52:27 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:27 --> Input Class Initialized
INFO - 2025-01-02 20:52:27 --> Language Class Initialized
ERROR - 2025-01-02 20:52:27 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:27 --> Config Class Initialized
INFO - 2025-01-02 20:52:27 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:27 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:27 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:27 --> URI Class Initialized
INFO - 2025-01-02 20:52:27 --> Router Class Initialized
INFO - 2025-01-02 20:52:27 --> Output Class Initialized
INFO - 2025-01-02 20:52:27 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:27 --> Input Class Initialized
INFO - 2025-01-02 20:52:27 --> Language Class Initialized
ERROR - 2025-01-02 20:52:27 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:52:28 --> Config Class Initialized
INFO - 2025-01-02 20:52:28 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:28 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:28 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:28 --> URI Class Initialized
INFO - 2025-01-02 20:52:28 --> Router Class Initialized
INFO - 2025-01-02 20:52:28 --> Output Class Initialized
INFO - 2025-01-02 20:52:28 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:28 --> Input Class Initialized
INFO - 2025-01-02 20:52:28 --> Language Class Initialized
ERROR - 2025-01-02 20:52:28 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:52:29 --> Config Class Initialized
INFO - 2025-01-02 20:52:29 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:29 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:29 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:29 --> URI Class Initialized
INFO - 2025-01-02 20:52:29 --> Router Class Initialized
INFO - 2025-01-02 20:52:29 --> Output Class Initialized
INFO - 2025-01-02 20:52:29 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:29 --> Input Class Initialized
INFO - 2025-01-02 20:52:29 --> Language Class Initialized
ERROR - 2025-01-02 20:52:29 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:52:29 --> Config Class Initialized
INFO - 2025-01-02 20:52:29 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:29 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:29 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:29 --> URI Class Initialized
INFO - 2025-01-02 20:52:29 --> Router Class Initialized
INFO - 2025-01-02 20:52:29 --> Output Class Initialized
INFO - 2025-01-02 20:52:29 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:29 --> Input Class Initialized
INFO - 2025-01-02 20:52:29 --> Language Class Initialized
ERROR - 2025-01-02 20:52:29 --> 404 Page Not Found: Wp-content/themes
INFO - 2025-01-02 20:52:30 --> Config Class Initialized
INFO - 2025-01-02 20:52:30 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:30 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:30 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:30 --> URI Class Initialized
INFO - 2025-01-02 20:52:30 --> Router Class Initialized
INFO - 2025-01-02 20:52:30 --> Output Class Initialized
INFO - 2025-01-02 20:52:30 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:30 --> Input Class Initialized
INFO - 2025-01-02 20:52:30 --> Language Class Initialized
ERROR - 2025-01-02 20:52:30 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:52:30 --> Config Class Initialized
INFO - 2025-01-02 20:52:30 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:30 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:30 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:30 --> URI Class Initialized
INFO - 2025-01-02 20:52:30 --> Router Class Initialized
INFO - 2025-01-02 20:52:30 --> Output Class Initialized
INFO - 2025-01-02 20:52:30 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:30 --> Input Class Initialized
INFO - 2025-01-02 20:52:30 --> Language Class Initialized
ERROR - 2025-01-02 20:52:30 --> 404 Page Not Found: Wp-content/plugins
INFO - 2025-01-02 20:52:30 --> Config Class Initialized
INFO - 2025-01-02 20:52:30 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:30 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:30 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:30 --> URI Class Initialized
INFO - 2025-01-02 20:52:30 --> Router Class Initialized
INFO - 2025-01-02 20:52:30 --> Output Class Initialized
INFO - 2025-01-02 20:52:31 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:31 --> Input Class Initialized
INFO - 2025-01-02 20:52:31 --> Language Class Initialized
ERROR - 2025-01-02 20:52:31 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2025-01-02 20:52:31 --> Config Class Initialized
INFO - 2025-01-02 20:52:31 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:31 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:31 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:31 --> URI Class Initialized
INFO - 2025-01-02 20:52:31 --> Router Class Initialized
INFO - 2025-01-02 20:52:31 --> Output Class Initialized
INFO - 2025-01-02 20:52:31 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:31 --> Input Class Initialized
INFO - 2025-01-02 20:52:31 --> Language Class Initialized
ERROR - 2025-01-02 20:52:31 --> 404 Page Not Found: Wp-admin/network
INFO - 2025-01-02 20:52:32 --> Config Class Initialized
INFO - 2025-01-02 20:52:32 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:32 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:32 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:32 --> URI Class Initialized
INFO - 2025-01-02 20:52:32 --> Router Class Initialized
INFO - 2025-01-02 20:52:32 --> Output Class Initialized
INFO - 2025-01-02 20:52:32 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:32 --> Input Class Initialized
INFO - 2025-01-02 20:52:32 --> Language Class Initialized
ERROR - 2025-01-02 20:52:32 --> 404 Page Not Found: Xmrlpcphp/index
INFO - 2025-01-02 20:52:32 --> Config Class Initialized
INFO - 2025-01-02 20:52:32 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:32 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:32 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:32 --> URI Class Initialized
INFO - 2025-01-02 20:52:32 --> Router Class Initialized
INFO - 2025-01-02 20:52:32 --> Output Class Initialized
INFO - 2025-01-02 20:52:32 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:32 --> Input Class Initialized
INFO - 2025-01-02 20:52:32 --> Language Class Initialized
ERROR - 2025-01-02 20:52:32 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
INFO - 2025-01-02 20:52:33 --> Config Class Initialized
INFO - 2025-01-02 20:52:33 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:33 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:33 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:33 --> URI Class Initialized
INFO - 2025-01-02 20:52:33 --> Router Class Initialized
INFO - 2025-01-02 20:52:33 --> Output Class Initialized
INFO - 2025-01-02 20:52:33 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:33 --> Input Class Initialized
INFO - 2025-01-02 20:52:33 --> Language Class Initialized
ERROR - 2025-01-02 20:52:33 --> 404 Page Not Found: Css/xmrlpc.php
INFO - 2025-01-02 20:52:33 --> Config Class Initialized
INFO - 2025-01-02 20:52:33 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:33 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:33 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:33 --> URI Class Initialized
INFO - 2025-01-02 20:52:33 --> Router Class Initialized
INFO - 2025-01-02 20:52:33 --> Output Class Initialized
INFO - 2025-01-02 20:52:33 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:33 --> Input Class Initialized
INFO - 2025-01-02 20:52:33 --> Language Class Initialized
ERROR - 2025-01-02 20:52:33 --> 404 Page Not Found: Wp-admin/user
INFO - 2025-01-02 20:52:34 --> Config Class Initialized
INFO - 2025-01-02 20:52:34 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:34 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:34 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:34 --> URI Class Initialized
INFO - 2025-01-02 20:52:34 --> Router Class Initialized
INFO - 2025-01-02 20:52:34 --> Output Class Initialized
INFO - 2025-01-02 20:52:34 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:34 --> Input Class Initialized
INFO - 2025-01-02 20:52:34 --> Language Class Initialized
ERROR - 2025-01-02 20:52:34 --> 404 Page Not Found: Img/xmrlpc.php
INFO - 2025-01-02 20:52:34 --> Config Class Initialized
INFO - 2025-01-02 20:52:34 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:34 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:34 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:34 --> URI Class Initialized
INFO - 2025-01-02 20:52:34 --> Router Class Initialized
INFO - 2025-01-02 20:52:34 --> Output Class Initialized
INFO - 2025-01-02 20:52:34 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:34 --> Input Class Initialized
INFO - 2025-01-02 20:52:34 --> Language Class Initialized
ERROR - 2025-01-02 20:52:34 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:34 --> Config Class Initialized
INFO - 2025-01-02 20:52:34 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:34 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:34 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:34 --> URI Class Initialized
INFO - 2025-01-02 20:52:35 --> Router Class Initialized
INFO - 2025-01-02 20:52:35 --> Output Class Initialized
INFO - 2025-01-02 20:52:35 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:35 --> Input Class Initialized
INFO - 2025-01-02 20:52:35 --> Language Class Initialized
ERROR - 2025-01-02 20:52:35 --> 404 Page Not Found: Wp-admin/images
INFO - 2025-01-02 20:52:35 --> Config Class Initialized
INFO - 2025-01-02 20:52:35 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:35 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:35 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:35 --> URI Class Initialized
INFO - 2025-01-02 20:52:35 --> Router Class Initialized
INFO - 2025-01-02 20:52:35 --> Output Class Initialized
INFO - 2025-01-02 20:52:35 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:35 --> Input Class Initialized
INFO - 2025-01-02 20:52:35 --> Language Class Initialized
ERROR - 2025-01-02 20:52:35 --> 404 Page Not Found: Images/xmrlpc.php
INFO - 2025-01-02 20:52:35 --> Config Class Initialized
INFO - 2025-01-02 20:52:35 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:35 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:35 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:35 --> URI Class Initialized
INFO - 2025-01-02 20:52:35 --> Router Class Initialized
INFO - 2025-01-02 20:52:35 --> Output Class Initialized
INFO - 2025-01-02 20:52:35 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:35 --> Input Class Initialized
INFO - 2025-01-02 20:52:35 --> Language Class Initialized
ERROR - 2025-01-02 20:52:35 --> 404 Page Not Found: Wp-admin/js
INFO - 2025-01-02 20:52:36 --> Config Class Initialized
INFO - 2025-01-02 20:52:36 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:36 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:36 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:36 --> URI Class Initialized
INFO - 2025-01-02 20:52:36 --> Router Class Initialized
INFO - 2025-01-02 20:52:36 --> Output Class Initialized
INFO - 2025-01-02 20:52:36 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:36 --> Input Class Initialized
INFO - 2025-01-02 20:52:36 --> Language Class Initialized
ERROR - 2025-01-02 20:52:36 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:36 --> Config Class Initialized
INFO - 2025-01-02 20:52:36 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:36 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:36 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:36 --> URI Class Initialized
INFO - 2025-01-02 20:52:36 --> Router Class Initialized
INFO - 2025-01-02 20:52:36 --> Output Class Initialized
INFO - 2025-01-02 20:52:36 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:36 --> Input Class Initialized
INFO - 2025-01-02 20:52:36 --> Language Class Initialized
ERROR - 2025-01-02 20:52:36 --> 404 Page Not Found: Wp-admin/includes
INFO - 2025-01-02 20:52:37 --> Config Class Initialized
INFO - 2025-01-02 20:52:37 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:37 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:37 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:37 --> URI Class Initialized
INFO - 2025-01-02 20:52:37 --> Router Class Initialized
INFO - 2025-01-02 20:52:37 --> Output Class Initialized
INFO - 2025-01-02 20:52:37 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:37 --> Input Class Initialized
INFO - 2025-01-02 20:52:37 --> Language Class Initialized
ERROR - 2025-01-02 20:52:37 --> 404 Page Not Found: Wp-admin/css
INFO - 2025-01-02 20:52:37 --> Config Class Initialized
INFO - 2025-01-02 20:52:37 --> Hooks Class Initialized
DEBUG - 2025-01-02 20:52:37 --> UTF-8 Support Enabled
INFO - 2025-01-02 20:52:37 --> Utf8 Class Initialized
INFO - 2025-01-02 20:52:37 --> URI Class Initialized
INFO - 2025-01-02 20:52:37 --> Router Class Initialized
INFO - 2025-01-02 20:52:37 --> Output Class Initialized
INFO - 2025-01-02 20:52:37 --> Security Class Initialized
DEBUG - 2025-01-02 20:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-02 20:52:37 --> Input Class Initialized
INFO - 2025-01-02 20:52:37 --> Language Class Initialized
ERROR - 2025-01-02 20:52:37 --> 404 Page Not Found: Wp-admin/xmrlpc.php
