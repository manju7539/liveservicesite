<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-20 00:07:56 --> Model "MainModel" initialized
INFO - 2024-10-20 00:07:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 00:07:56 --> Final output sent to browser
DEBUG - 2024-10-20 00:07:56 --> Total execution time: 2.2727
INFO - 2024-10-20 03:00:42 --> Model "MainModel" initialized
INFO - 2024-10-20 03:00:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 03:00:42 --> Final output sent to browser
DEBUG - 2024-10-20 03:00:42 --> Total execution time: 8.5820
INFO - 2024-10-20 03:44:59 --> Model "MainModel" initialized
INFO - 2024-10-20 03:44:59 --> Model "MainModel" initialized
INFO - 2024-10-20 03:44:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 03:44:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 03:44:59 --> Final output sent to browser
DEBUG - 2024-10-20 03:44:59 --> Total execution time: 4.1914
INFO - 2024-10-20 03:44:59 --> Final output sent to browser
DEBUG - 2024-10-20 03:44:59 --> Total execution time: 4.2000
INFO - 2024-10-20 00:54:09 --> Config Class Initialized
INFO - 2024-10-20 00:54:09 --> Hooks Class Initialized
DEBUG - 2024-10-20 00:54:10 --> UTF-8 Support Enabled
INFO - 2024-10-20 00:54:10 --> Utf8 Class Initialized
INFO - 2024-10-20 00:54:10 --> URI Class Initialized
DEBUG - 2024-10-20 00:54:10 --> No URI present. Default controller set.
INFO - 2024-10-20 00:54:10 --> Router Class Initialized
INFO - 2024-10-20 00:54:10 --> Output Class Initialized
INFO - 2024-10-20 00:54:10 --> Security Class Initialized
DEBUG - 2024-10-20 00:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 00:54:10 --> Input Class Initialized
INFO - 2024-10-20 00:54:10 --> Language Class Initialized
INFO - 2024-10-20 00:54:10 --> Loader Class Initialized
INFO - 2024-10-20 00:54:11 --> Helper loaded: url_helper
INFO - 2024-10-20 00:54:11 --> Helper loaded: html_helper
INFO - 2024-10-20 00:54:11 --> Helper loaded: file_helper
INFO - 2024-10-20 00:54:11 --> Helper loaded: string_helper
INFO - 2024-10-20 00:54:11 --> Helper loaded: form_helper
INFO - 2024-10-20 00:54:11 --> Helper loaded: my_helper
INFO - 2024-10-20 00:54:12 --> Database Driver Class Initialized
INFO - 2024-10-20 00:54:14 --> Upload Class Initialized
INFO - 2024-10-20 00:54:14 --> Email Class Initialized
INFO - 2024-10-20 00:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 00:54:15 --> Form Validation Class Initialized
INFO - 2024-10-20 00:54:15 --> Controller Class Initialized
INFO - 2024-10-20 06:24:15 --> Model "MainModel" initialized
INFO - 2024-10-20 06:24:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 06:24:16 --> Final output sent to browser
DEBUG - 2024-10-20 06:24:16 --> Total execution time: 6.7805
INFO - 2024-10-20 02:20:00 --> Config Class Initialized
INFO - 2024-10-20 02:20:00 --> Hooks Class Initialized
DEBUG - 2024-10-20 02:20:00 --> UTF-8 Support Enabled
INFO - 2024-10-20 02:20:00 --> Utf8 Class Initialized
INFO - 2024-10-20 02:20:00 --> URI Class Initialized
DEBUG - 2024-10-20 02:20:00 --> No URI present. Default controller set.
INFO - 2024-10-20 02:20:00 --> Router Class Initialized
INFO - 2024-10-20 02:20:00 --> Output Class Initialized
INFO - 2024-10-20 02:20:00 --> Security Class Initialized
DEBUG - 2024-10-20 02:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 02:20:00 --> Input Class Initialized
INFO - 2024-10-20 02:20:00 --> Language Class Initialized
INFO - 2024-10-20 02:20:00 --> Loader Class Initialized
INFO - 2024-10-20 02:20:00 --> Helper loaded: url_helper
INFO - 2024-10-20 02:20:00 --> Helper loaded: html_helper
INFO - 2024-10-20 02:20:01 --> Helper loaded: file_helper
INFO - 2024-10-20 02:20:01 --> Helper loaded: string_helper
INFO - 2024-10-20 02:20:01 --> Helper loaded: form_helper
INFO - 2024-10-20 02:20:01 --> Helper loaded: my_helper
INFO - 2024-10-20 02:20:01 --> Database Driver Class Initialized
INFO - 2024-10-20 02:20:03 --> Upload Class Initialized
INFO - 2024-10-20 02:20:03 --> Email Class Initialized
INFO - 2024-10-20 02:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 02:20:04 --> Form Validation Class Initialized
INFO - 2024-10-20 02:20:04 --> Controller Class Initialized
INFO - 2024-10-20 07:50:04 --> Model "MainModel" initialized
INFO - 2024-10-20 07:50:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 07:50:04 --> Final output sent to browser
DEBUG - 2024-10-20 07:50:04 --> Total execution time: 4.3936
INFO - 2024-10-20 03:04:27 --> Config Class Initialized
INFO - 2024-10-20 03:04:27 --> Hooks Class Initialized
DEBUG - 2024-10-20 03:04:27 --> UTF-8 Support Enabled
INFO - 2024-10-20 03:04:27 --> Utf8 Class Initialized
INFO - 2024-10-20 03:04:28 --> URI Class Initialized
DEBUG - 2024-10-20 03:04:28 --> No URI present. Default controller set.
INFO - 2024-10-20 03:04:28 --> Router Class Initialized
INFO - 2024-10-20 03:04:28 --> Output Class Initialized
INFO - 2024-10-20 03:04:29 --> Security Class Initialized
DEBUG - 2024-10-20 03:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 03:04:29 --> Input Class Initialized
INFO - 2024-10-20 03:04:29 --> Language Class Initialized
INFO - 2024-10-20 03:04:29 --> Loader Class Initialized
INFO - 2024-10-20 03:04:30 --> Helper loaded: url_helper
INFO - 2024-10-20 03:04:30 --> Helper loaded: html_helper
INFO - 2024-10-20 03:04:30 --> Helper loaded: file_helper
INFO - 2024-10-20 03:04:30 --> Helper loaded: string_helper
INFO - 2024-10-20 03:04:31 --> Helper loaded: form_helper
INFO - 2024-10-20 03:04:31 --> Helper loaded: my_helper
INFO - 2024-10-20 03:04:31 --> Database Driver Class Initialized
INFO - 2024-10-20 03:04:33 --> Upload Class Initialized
INFO - 2024-10-20 03:04:33 --> Email Class Initialized
INFO - 2024-10-20 03:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 03:04:37 --> Form Validation Class Initialized
INFO - 2024-10-20 03:04:37 --> Controller Class Initialized
INFO - 2024-10-20 03:04:37 --> Config Class Initialized
INFO - 2024-10-20 03:04:37 --> Hooks Class Initialized
DEBUG - 2024-10-20 03:04:37 --> UTF-8 Support Enabled
INFO - 2024-10-20 03:04:37 --> Utf8 Class Initialized
INFO - 2024-10-20 03:04:37 --> URI Class Initialized
DEBUG - 2024-10-20 03:04:37 --> No URI present. Default controller set.
INFO - 2024-10-20 03:04:37 --> Router Class Initialized
INFO - 2024-10-20 03:04:37 --> Output Class Initialized
INFO - 2024-10-20 03:04:37 --> Security Class Initialized
DEBUG - 2024-10-20 03:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 03:04:37 --> Input Class Initialized
INFO - 2024-10-20 03:04:37 --> Language Class Initialized
INFO - 2024-10-20 03:04:37 --> Loader Class Initialized
INFO - 2024-10-20 03:04:37 --> Helper loaded: url_helper
INFO - 2024-10-20 03:04:37 --> Helper loaded: html_helper
INFO - 2024-10-20 03:04:37 --> Helper loaded: file_helper
INFO - 2024-10-20 03:04:37 --> Helper loaded: string_helper
INFO - 2024-10-20 03:04:37 --> Helper loaded: form_helper
INFO - 2024-10-20 03:04:37 --> Helper loaded: my_helper
INFO - 2024-10-20 03:04:37 --> Database Driver Class Initialized
INFO - 2024-10-20 08:34:38 --> Model "MainModel" initialized
INFO - 2024-10-20 03:04:39 --> Upload Class Initialized
INFO - 2024-10-20 03:04:39 --> Email Class Initialized
INFO - 2024-10-20 03:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 03:04:39 --> Form Validation Class Initialized
INFO - 2024-10-20 03:04:39 --> Controller Class Initialized
INFO - 2024-10-20 08:34:39 --> Model "MainModel" initialized
INFO - 2024-10-20 08:34:40 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 08:34:40 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 08:34:40 --> Final output sent to browser
INFO - 2024-10-20 08:34:40 --> Final output sent to browser
DEBUG - 2024-10-20 08:34:40 --> Total execution time: 12.7246
DEBUG - 2024-10-20 08:34:40 --> Total execution time: 2.4008
INFO - 2024-10-20 03:04:57 --> Config Class Initialized
INFO - 2024-10-20 03:04:57 --> Hooks Class Initialized
DEBUG - 2024-10-20 03:04:57 --> UTF-8 Support Enabled
INFO - 2024-10-20 03:04:57 --> Utf8 Class Initialized
INFO - 2024-10-20 03:04:57 --> URI Class Initialized
DEBUG - 2024-10-20 03:04:57 --> No URI present. Default controller set.
INFO - 2024-10-20 03:04:57 --> Router Class Initialized
INFO - 2024-10-20 03:04:57 --> Output Class Initialized
INFO - 2024-10-20 03:04:57 --> Security Class Initialized
DEBUG - 2024-10-20 03:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 03:04:57 --> Input Class Initialized
INFO - 2024-10-20 03:04:57 --> Language Class Initialized
INFO - 2024-10-20 03:04:57 --> Loader Class Initialized
INFO - 2024-10-20 03:04:57 --> Helper loaded: url_helper
INFO - 2024-10-20 03:04:57 --> Helper loaded: html_helper
INFO - 2024-10-20 03:04:57 --> Helper loaded: file_helper
INFO - 2024-10-20 03:04:57 --> Helper loaded: string_helper
INFO - 2024-10-20 03:04:57 --> Helper loaded: form_helper
INFO - 2024-10-20 03:04:57 --> Helper loaded: my_helper
INFO - 2024-10-20 03:04:57 --> Database Driver Class Initialized
INFO - 2024-10-20 03:04:59 --> Upload Class Initialized
INFO - 2024-10-20 03:04:59 --> Email Class Initialized
INFO - 2024-10-20 03:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 03:04:59 --> Form Validation Class Initialized
INFO - 2024-10-20 03:04:59 --> Controller Class Initialized
INFO - 2024-10-20 08:34:59 --> Model "MainModel" initialized
INFO - 2024-10-20 08:34:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 08:34:59 --> Final output sent to browser
DEBUG - 2024-10-20 08:34:59 --> Total execution time: 2.3334
INFO - 2024-10-20 08:43:46 --> Config Class Initialized
INFO - 2024-10-20 08:43:47 --> Hooks Class Initialized
DEBUG - 2024-10-20 08:43:47 --> UTF-8 Support Enabled
INFO - 2024-10-20 08:43:47 --> Utf8 Class Initialized
INFO - 2024-10-20 08:43:47 --> URI Class Initialized
DEBUG - 2024-10-20 08:43:47 --> No URI present. Default controller set.
INFO - 2024-10-20 08:43:47 --> Router Class Initialized
INFO - 2024-10-20 08:43:47 --> Output Class Initialized
INFO - 2024-10-20 08:43:47 --> Security Class Initialized
DEBUG - 2024-10-20 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 08:43:47 --> Input Class Initialized
INFO - 2024-10-20 08:43:47 --> Language Class Initialized
INFO - 2024-10-20 08:43:47 --> Loader Class Initialized
INFO - 2024-10-20 08:43:47 --> Helper loaded: url_helper
INFO - 2024-10-20 08:43:47 --> Helper loaded: html_helper
INFO - 2024-10-20 08:43:47 --> Helper loaded: file_helper
INFO - 2024-10-20 08:43:47 --> Helper loaded: string_helper
INFO - 2024-10-20 08:43:47 --> Helper loaded: form_helper
INFO - 2024-10-20 08:43:47 --> Helper loaded: my_helper
INFO - 2024-10-20 08:43:47 --> Database Driver Class Initialized
INFO - 2024-10-20 08:43:48 --> Config Class Initialized
INFO - 2024-10-20 08:43:48 --> Hooks Class Initialized
DEBUG - 2024-10-20 08:43:48 --> UTF-8 Support Enabled
INFO - 2024-10-20 08:43:48 --> Utf8 Class Initialized
INFO - 2024-10-20 08:43:48 --> URI Class Initialized
DEBUG - 2024-10-20 08:43:48 --> No URI present. Default controller set.
INFO - 2024-10-20 08:43:48 --> Router Class Initialized
INFO - 2024-10-20 08:43:48 --> Output Class Initialized
INFO - 2024-10-20 08:43:48 --> Security Class Initialized
DEBUG - 2024-10-20 08:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 08:43:48 --> Input Class Initialized
INFO - 2024-10-20 08:43:48 --> Language Class Initialized
INFO - 2024-10-20 08:43:48 --> Loader Class Initialized
INFO - 2024-10-20 08:43:48 --> Helper loaded: url_helper
INFO - 2024-10-20 08:43:48 --> Helper loaded: html_helper
INFO - 2024-10-20 08:43:48 --> Helper loaded: file_helper
INFO - 2024-10-20 08:43:48 --> Helper loaded: string_helper
INFO - 2024-10-20 08:43:48 --> Helper loaded: form_helper
INFO - 2024-10-20 08:43:48 --> Helper loaded: my_helper
INFO - 2024-10-20 08:43:48 --> Database Driver Class Initialized
INFO - 2024-10-20 08:43:49 --> Upload Class Initialized
INFO - 2024-10-20 08:43:49 --> Email Class Initialized
INFO - 2024-10-20 08:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 08:43:49 --> Form Validation Class Initialized
INFO - 2024-10-20 08:43:49 --> Controller Class Initialized
INFO - 2024-10-20 14:13:49 --> Model "MainModel" initialized
INFO - 2024-10-20 14:13:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 14:13:49 --> Final output sent to browser
DEBUG - 2024-10-20 14:13:49 --> Total execution time: 2.8063
INFO - 2024-10-20 08:43:50 --> Upload Class Initialized
INFO - 2024-10-20 08:43:50 --> Email Class Initialized
INFO - 2024-10-20 08:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 08:43:50 --> Form Validation Class Initialized
INFO - 2024-10-20 08:43:50 --> Controller Class Initialized
INFO - 2024-10-20 14:13:50 --> Model "MainModel" initialized
INFO - 2024-10-20 14:13:50 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 14:13:50 --> Final output sent to browser
DEBUG - 2024-10-20 14:13:50 --> Total execution time: 2.1180
INFO - 2024-10-20 10:40:15 --> Config Class Initialized
INFO - 2024-10-20 10:40:15 --> Hooks Class Initialized
DEBUG - 2024-10-20 10:40:15 --> UTF-8 Support Enabled
INFO - 2024-10-20 10:40:15 --> Utf8 Class Initialized
INFO - 2024-10-20 10:40:15 --> URI Class Initialized
DEBUG - 2024-10-20 10:40:15 --> No URI present. Default controller set.
INFO - 2024-10-20 10:40:15 --> Router Class Initialized
INFO - 2024-10-20 10:40:15 --> Output Class Initialized
INFO - 2024-10-20 10:40:15 --> Security Class Initialized
DEBUG - 2024-10-20 10:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 10:40:15 --> Input Class Initialized
INFO - 2024-10-20 10:40:15 --> Language Class Initialized
INFO - 2024-10-20 10:40:15 --> Loader Class Initialized
INFO - 2024-10-20 10:40:15 --> Helper loaded: url_helper
INFO - 2024-10-20 10:40:15 --> Helper loaded: html_helper
INFO - 2024-10-20 10:40:15 --> Helper loaded: file_helper
INFO - 2024-10-20 10:40:15 --> Helper loaded: string_helper
INFO - 2024-10-20 10:40:15 --> Helper loaded: form_helper
INFO - 2024-10-20 10:40:15 --> Helper loaded: my_helper
INFO - 2024-10-20 10:40:15 --> Database Driver Class Initialized
INFO - 2024-10-20 10:40:17 --> Upload Class Initialized
INFO - 2024-10-20 10:40:17 --> Email Class Initialized
INFO - 2024-10-20 10:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 10:40:18 --> Form Validation Class Initialized
INFO - 2024-10-20 10:40:18 --> Controller Class Initialized
INFO - 2024-10-20 16:10:18 --> Model "MainModel" initialized
INFO - 2024-10-20 16:10:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 16:10:18 --> Final output sent to browser
DEBUG - 2024-10-20 16:10:18 --> Total execution time: 2.2560
INFO - 2024-10-20 12:41:22 --> Config Class Initialized
INFO - 2024-10-20 12:41:22 --> Hooks Class Initialized
DEBUG - 2024-10-20 12:41:22 --> UTF-8 Support Enabled
INFO - 2024-10-20 12:41:22 --> Utf8 Class Initialized
INFO - 2024-10-20 12:41:22 --> URI Class Initialized
DEBUG - 2024-10-20 12:41:22 --> No URI present. Default controller set.
INFO - 2024-10-20 12:41:22 --> Router Class Initialized
INFO - 2024-10-20 12:41:22 --> Output Class Initialized
INFO - 2024-10-20 12:41:22 --> Security Class Initialized
DEBUG - 2024-10-20 12:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 12:41:22 --> Input Class Initialized
INFO - 2024-10-20 12:41:22 --> Language Class Initialized
INFO - 2024-10-20 12:41:22 --> Loader Class Initialized
INFO - 2024-10-20 12:41:22 --> Helper loaded: url_helper
INFO - 2024-10-20 12:41:22 --> Helper loaded: html_helper
INFO - 2024-10-20 12:41:22 --> Helper loaded: file_helper
INFO - 2024-10-20 12:41:22 --> Helper loaded: string_helper
INFO - 2024-10-20 12:41:22 --> Helper loaded: form_helper
INFO - 2024-10-20 12:41:22 --> Helper loaded: my_helper
INFO - 2024-10-20 12:41:22 --> Database Driver Class Initialized
INFO - 2024-10-20 12:41:24 --> Upload Class Initialized
INFO - 2024-10-20 12:41:24 --> Email Class Initialized
INFO - 2024-10-20 12:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 12:41:24 --> Form Validation Class Initialized
INFO - 2024-10-20 12:41:24 --> Controller Class Initialized
INFO - 2024-10-20 18:11:24 --> Model "MainModel" initialized
INFO - 2024-10-20 18:11:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 18:11:24 --> Final output sent to browser
DEBUG - 2024-10-20 18:11:24 --> Total execution time: 2.2392
INFO - 2024-10-20 12:42:23 --> Config Class Initialized
INFO - 2024-10-20 12:42:23 --> Hooks Class Initialized
DEBUG - 2024-10-20 12:42:23 --> UTF-8 Support Enabled
INFO - 2024-10-20 12:42:23 --> Utf8 Class Initialized
INFO - 2024-10-20 12:42:24 --> URI Class Initialized
DEBUG - 2024-10-20 12:42:24 --> No URI present. Default controller set.
INFO - 2024-10-20 12:42:24 --> Router Class Initialized
INFO - 2024-10-20 12:42:24 --> Output Class Initialized
INFO - 2024-10-20 12:42:24 --> Security Class Initialized
DEBUG - 2024-10-20 12:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 12:42:24 --> Input Class Initialized
INFO - 2024-10-20 12:42:24 --> Language Class Initialized
INFO - 2024-10-20 12:42:24 --> Loader Class Initialized
INFO - 2024-10-20 12:42:24 --> Helper loaded: url_helper
INFO - 2024-10-20 12:42:24 --> Helper loaded: html_helper
INFO - 2024-10-20 12:42:24 --> Helper loaded: file_helper
INFO - 2024-10-20 12:42:24 --> Helper loaded: string_helper
INFO - 2024-10-20 12:42:24 --> Helper loaded: form_helper
INFO - 2024-10-20 12:42:24 --> Helper loaded: my_helper
INFO - 2024-10-20 12:42:24 --> Database Driver Class Initialized
INFO - 2024-10-20 12:42:26 --> Upload Class Initialized
INFO - 2024-10-20 12:42:26 --> Email Class Initialized
INFO - 2024-10-20 12:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 12:42:26 --> Form Validation Class Initialized
INFO - 2024-10-20 12:42:26 --> Controller Class Initialized
INFO - 2024-10-20 18:12:26 --> Model "MainModel" initialized
INFO - 2024-10-20 18:12:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 18:12:26 --> Final output sent to browser
DEBUG - 2024-10-20 18:12:26 --> Total execution time: 2.1297
INFO - 2024-10-20 12:42:27 --> Config Class Initialized
INFO - 2024-10-20 12:42:27 --> Hooks Class Initialized
DEBUG - 2024-10-20 12:42:27 --> UTF-8 Support Enabled
INFO - 2024-10-20 12:42:27 --> Utf8 Class Initialized
INFO - 2024-10-20 12:42:27 --> URI Class Initialized
DEBUG - 2024-10-20 12:42:27 --> No URI present. Default controller set.
INFO - 2024-10-20 12:42:27 --> Router Class Initialized
INFO - 2024-10-20 12:42:27 --> Output Class Initialized
INFO - 2024-10-20 12:42:27 --> Security Class Initialized
DEBUG - 2024-10-20 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 12:42:27 --> Input Class Initialized
INFO - 2024-10-20 12:42:27 --> Language Class Initialized
INFO - 2024-10-20 12:42:27 --> Loader Class Initialized
INFO - 2024-10-20 12:42:27 --> Helper loaded: url_helper
INFO - 2024-10-20 12:42:27 --> Helper loaded: html_helper
INFO - 2024-10-20 12:42:27 --> Helper loaded: file_helper
INFO - 2024-10-20 12:42:27 --> Helper loaded: string_helper
INFO - 2024-10-20 12:42:27 --> Helper loaded: form_helper
INFO - 2024-10-20 12:42:27 --> Helper loaded: my_helper
INFO - 2024-10-20 12:42:27 --> Database Driver Class Initialized
INFO - 2024-10-20 12:42:29 --> Upload Class Initialized
INFO - 2024-10-20 12:42:29 --> Email Class Initialized
INFO - 2024-10-20 12:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 12:42:29 --> Form Validation Class Initialized
INFO - 2024-10-20 12:42:29 --> Controller Class Initialized
INFO - 2024-10-20 18:12:29 --> Model "MainModel" initialized
INFO - 2024-10-20 18:12:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 18:12:29 --> Final output sent to browser
DEBUG - 2024-10-20 18:12:29 --> Total execution time: 2.1093
INFO - 2024-10-20 13:30:09 --> Config Class Initialized
INFO - 2024-10-20 13:30:09 --> Hooks Class Initialized
DEBUG - 2024-10-20 13:30:09 --> UTF-8 Support Enabled
INFO - 2024-10-20 13:30:09 --> Utf8 Class Initialized
INFO - 2024-10-20 13:30:09 --> URI Class Initialized
DEBUG - 2024-10-20 13:30:09 --> No URI present. Default controller set.
INFO - 2024-10-20 13:30:09 --> Router Class Initialized
INFO - 2024-10-20 13:30:09 --> Output Class Initialized
INFO - 2024-10-20 13:30:09 --> Security Class Initialized
DEBUG - 2024-10-20 13:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 13:30:09 --> Input Class Initialized
INFO - 2024-10-20 13:30:09 --> Language Class Initialized
INFO - 2024-10-20 13:30:09 --> Loader Class Initialized
INFO - 2024-10-20 13:30:09 --> Helper loaded: url_helper
INFO - 2024-10-20 13:30:09 --> Helper loaded: html_helper
INFO - 2024-10-20 13:30:09 --> Helper loaded: file_helper
INFO - 2024-10-20 13:30:09 --> Helper loaded: string_helper
INFO - 2024-10-20 13:30:09 --> Helper loaded: form_helper
INFO - 2024-10-20 13:30:09 --> Helper loaded: my_helper
INFO - 2024-10-20 13:30:09 --> Database Driver Class Initialized
INFO - 2024-10-20 13:30:11 --> Upload Class Initialized
INFO - 2024-10-20 13:30:11 --> Email Class Initialized
INFO - 2024-10-20 13:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 13:30:11 --> Form Validation Class Initialized
INFO - 2024-10-20 13:30:11 --> Controller Class Initialized
INFO - 2024-10-20 19:00:11 --> Model "MainModel" initialized
INFO - 2024-10-20 19:00:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-20 19:00:11 --> Final output sent to browser
DEBUG - 2024-10-20 19:00:11 --> Total execution time: 2.1969
INFO - 2024-10-20 19:12:37 --> Config Class Initialized
INFO - 2024-10-20 19:12:37 --> Hooks Class Initialized
DEBUG - 2024-10-20 19:12:37 --> UTF-8 Support Enabled
INFO - 2024-10-20 19:12:37 --> Utf8 Class Initialized
INFO - 2024-10-20 19:12:37 --> URI Class Initialized
DEBUG - 2024-10-20 19:12:37 --> No URI present. Default controller set.
INFO - 2024-10-20 19:12:37 --> Router Class Initialized
INFO - 2024-10-20 19:12:37 --> Output Class Initialized
INFO - 2024-10-20 19:12:37 --> Security Class Initialized
DEBUG - 2024-10-20 19:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 19:12:37 --> Input Class Initialized
INFO - 2024-10-20 19:12:37 --> Language Class Initialized
INFO - 2024-10-20 19:12:37 --> Loader Class Initialized
INFO - 2024-10-20 19:12:37 --> Helper loaded: url_helper
INFO - 2024-10-20 19:12:37 --> Helper loaded: html_helper
INFO - 2024-10-20 19:12:37 --> Helper loaded: file_helper
INFO - 2024-10-20 19:12:37 --> Helper loaded: string_helper
INFO - 2024-10-20 19:12:37 --> Helper loaded: form_helper
INFO - 2024-10-20 19:12:37 --> Helper loaded: my_helper
INFO - 2024-10-20 19:12:37 --> Database Driver Class Initialized
INFO - 2024-10-20 19:12:39 --> Upload Class Initialized
INFO - 2024-10-20 19:12:39 --> Email Class Initialized
INFO - 2024-10-20 19:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 19:12:39 --> Form Validation Class Initialized
INFO - 2024-10-20 19:12:39 --> Controller Class Initialized
