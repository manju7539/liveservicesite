<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-15 00:27:26 --> Config Class Initialized
INFO - 2024-11-15 00:27:26 --> Hooks Class Initialized
DEBUG - 2024-11-15 00:27:26 --> UTF-8 Support Enabled
INFO - 2024-11-15 00:27:26 --> Utf8 Class Initialized
INFO - 2024-11-15 00:27:26 --> URI Class Initialized
INFO - 2024-11-15 00:27:26 --> Router Class Initialized
INFO - 2024-11-15 00:27:26 --> Output Class Initialized
INFO - 2024-11-15 00:27:26 --> Security Class Initialized
DEBUG - 2024-11-15 00:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 00:27:26 --> Input Class Initialized
INFO - 2024-11-15 00:27:26 --> Language Class Initialized
ERROR - 2024-11-15 00:27:26 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-15 07:54:23 --> Config Class Initialized
INFO - 2024-11-15 07:54:23 --> Hooks Class Initialized
DEBUG - 2024-11-15 07:54:23 --> UTF-8 Support Enabled
INFO - 2024-11-15 07:54:23 --> Utf8 Class Initialized
INFO - 2024-11-15 07:54:23 --> URI Class Initialized
DEBUG - 2024-11-15 07:54:23 --> No URI present. Default controller set.
INFO - 2024-11-15 07:54:23 --> Router Class Initialized
INFO - 2024-11-15 07:54:23 --> Output Class Initialized
INFO - 2024-11-15 07:54:23 --> Security Class Initialized
DEBUG - 2024-11-15 07:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 07:54:23 --> Input Class Initialized
INFO - 2024-11-15 07:54:23 --> Language Class Initialized
INFO - 2024-11-15 07:54:23 --> Loader Class Initialized
INFO - 2024-11-15 07:54:23 --> Helper loaded: url_helper
INFO - 2024-11-15 07:54:23 --> Helper loaded: html_helper
INFO - 2024-11-15 07:54:23 --> Helper loaded: file_helper
INFO - 2024-11-15 07:54:23 --> Helper loaded: string_helper
INFO - 2024-11-15 07:54:24 --> Helper loaded: form_helper
INFO - 2024-11-15 07:54:24 --> Helper loaded: my_helper
INFO - 2024-11-15 07:54:24 --> Database Driver Class Initialized
INFO - 2024-11-15 07:54:26 --> Upload Class Initialized
INFO - 2024-11-15 07:54:26 --> Email Class Initialized
INFO - 2024-11-15 07:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-15 07:54:26 --> Form Validation Class Initialized
INFO - 2024-11-15 07:54:26 --> Controller Class Initialized
INFO - 2024-11-15 13:24:26 --> Model "MainModel" initialized
INFO - 2024-11-15 13:24:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-15 13:24:26 --> Final output sent to browser
DEBUG - 2024-11-15 13:24:26 --> Total execution time: 2.6589
INFO - 2024-11-15 10:01:31 --> Config Class Initialized
INFO - 2024-11-15 10:01:31 --> Hooks Class Initialized
DEBUG - 2024-11-15 10:01:31 --> UTF-8 Support Enabled
INFO - 2024-11-15 10:01:31 --> Utf8 Class Initialized
INFO - 2024-11-15 10:01:31 --> URI Class Initialized
DEBUG - 2024-11-15 10:01:31 --> No URI present. Default controller set.
INFO - 2024-11-15 10:01:31 --> Router Class Initialized
INFO - 2024-11-15 10:01:31 --> Output Class Initialized
INFO - 2024-11-15 10:01:31 --> Security Class Initialized
DEBUG - 2024-11-15 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 10:01:31 --> Input Class Initialized
INFO - 2024-11-15 10:01:31 --> Language Class Initialized
INFO - 2024-11-15 10:01:31 --> Loader Class Initialized
INFO - 2024-11-15 10:01:31 --> Helper loaded: url_helper
INFO - 2024-11-15 10:01:31 --> Helper loaded: html_helper
INFO - 2024-11-15 10:01:31 --> Helper loaded: file_helper
INFO - 2024-11-15 10:01:31 --> Helper loaded: string_helper
INFO - 2024-11-15 10:01:31 --> Helper loaded: form_helper
INFO - 2024-11-15 10:01:31 --> Helper loaded: my_helper
INFO - 2024-11-15 10:01:31 --> Database Driver Class Initialized
INFO - 2024-11-15 10:01:33 --> Upload Class Initialized
INFO - 2024-11-15 10:01:33 --> Email Class Initialized
INFO - 2024-11-15 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-15 10:01:33 --> Form Validation Class Initialized
INFO - 2024-11-15 10:01:33 --> Controller Class Initialized
INFO - 2024-11-15 15:31:33 --> Model "MainModel" initialized
INFO - 2024-11-15 15:31:33 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-15 15:31:33 --> Final output sent to browser
DEBUG - 2024-11-15 15:31:33 --> Total execution time: 2.2779
INFO - 2024-11-15 12:22:22 --> Config Class Initialized
INFO - 2024-11-15 12:22:22 --> Hooks Class Initialized
DEBUG - 2024-11-15 12:22:22 --> UTF-8 Support Enabled
INFO - 2024-11-15 12:22:22 --> Utf8 Class Initialized
INFO - 2024-11-15 12:22:22 --> URI Class Initialized
DEBUG - 2024-11-15 12:22:22 --> No URI present. Default controller set.
INFO - 2024-11-15 12:22:22 --> Router Class Initialized
INFO - 2024-11-15 12:22:22 --> Output Class Initialized
INFO - 2024-11-15 12:22:22 --> Security Class Initialized
DEBUG - 2024-11-15 12:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-15 12:22:22 --> Input Class Initialized
INFO - 2024-11-15 12:22:22 --> Language Class Initialized
INFO - 2024-11-15 12:22:22 --> Loader Class Initialized
INFO - 2024-11-15 12:22:22 --> Helper loaded: url_helper
INFO - 2024-11-15 12:22:22 --> Helper loaded: html_helper
INFO - 2024-11-15 12:22:22 --> Helper loaded: file_helper
INFO - 2024-11-15 12:22:22 --> Helper loaded: string_helper
INFO - 2024-11-15 12:22:22 --> Helper loaded: form_helper
INFO - 2024-11-15 12:22:22 --> Helper loaded: my_helper
INFO - 2024-11-15 12:22:22 --> Database Driver Class Initialized
INFO - 2024-11-15 12:22:24 --> Upload Class Initialized
INFO - 2024-11-15 12:22:24 --> Email Class Initialized
INFO - 2024-11-15 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-15 12:22:24 --> Form Validation Class Initialized
INFO - 2024-11-15 12:22:24 --> Controller Class Initialized
INFO - 2024-11-15 17:52:24 --> Model "MainModel" initialized
INFO - 2024-11-15 17:52:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-15 17:52:24 --> Final output sent to browser
DEBUG - 2024-11-15 17:52:24 --> Total execution time: 2.2735
