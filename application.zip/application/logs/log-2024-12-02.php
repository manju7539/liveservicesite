<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-02 03:37:07 --> Config Class Initialized
INFO - 2024-12-02 03:37:07 --> Hooks Class Initialized
DEBUG - 2024-12-02 03:37:07 --> UTF-8 Support Enabled
INFO - 2024-12-02 03:37:07 --> Utf8 Class Initialized
INFO - 2024-12-02 03:37:07 --> URI Class Initialized
INFO - 2024-12-02 03:37:07 --> Router Class Initialized
INFO - 2024-12-02 03:37:07 --> Output Class Initialized
INFO - 2024-12-02 03:37:07 --> Security Class Initialized
DEBUG - 2024-12-02 03:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-02 03:37:07 --> Input Class Initialized
INFO - 2024-12-02 03:37:07 --> Language Class Initialized
ERROR - 2024-12-02 03:37:07 --> 404 Page Not Found: Wp-loginphp/index
