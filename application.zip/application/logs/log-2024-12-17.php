<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-17 02:52:17 --> Model "MainModel" initialized
INFO - 2024-12-17 02:52:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-17 02:52:17 --> Final output sent to browser
DEBUG - 2024-12-17 02:52:17 --> Total execution time: 2.3670
INFO - 2024-12-17 02:52:21 --> Model "MainModel" initialized
INFO - 2024-12-17 02:52:21 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-17 02:52:21 --> Final output sent to browser
DEBUG - 2024-12-17 02:52:21 --> Total execution time: 2.2222
INFO - 2024-12-17 03:50:45 --> Config Class Initialized
INFO - 2024-12-17 03:50:45 --> Hooks Class Initialized
DEBUG - 2024-12-17 03:50:45 --> UTF-8 Support Enabled
INFO - 2024-12-17 03:50:45 --> Utf8 Class Initialized
INFO - 2024-12-17 03:50:45 --> URI Class Initialized
DEBUG - 2024-12-17 03:50:45 --> No URI present. Default controller set.
INFO - 2024-12-17 03:50:45 --> Router Class Initialized
INFO - 2024-12-17 03:50:45 --> Output Class Initialized
INFO - 2024-12-17 03:50:45 --> Security Class Initialized
DEBUG - 2024-12-17 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-17 03:50:45 --> Input Class Initialized
INFO - 2024-12-17 03:50:45 --> Language Class Initialized
INFO - 2024-12-17 03:50:45 --> Loader Class Initialized
INFO - 2024-12-17 03:50:45 --> Helper loaded: url_helper
INFO - 2024-12-17 03:50:45 --> Helper loaded: html_helper
INFO - 2024-12-17 03:50:45 --> Helper loaded: file_helper
INFO - 2024-12-17 03:50:45 --> Helper loaded: string_helper
INFO - 2024-12-17 03:50:45 --> Helper loaded: form_helper
INFO - 2024-12-17 03:50:45 --> Helper loaded: my_helper
INFO - 2024-12-17 03:50:45 --> Database Driver Class Initialized
INFO - 2024-12-17 03:50:47 --> Upload Class Initialized
INFO - 2024-12-17 03:50:47 --> Email Class Initialized
INFO - 2024-12-17 03:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-17 03:50:47 --> Form Validation Class Initialized
INFO - 2024-12-17 03:50:47 --> Controller Class Initialized
INFO - 2024-12-17 09:20:47 --> Model "MainModel" initialized
INFO - 2024-12-17 09:20:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-17 09:20:47 --> Final output sent to browser
DEBUG - 2024-12-17 09:20:47 --> Total execution time: 2.2754
