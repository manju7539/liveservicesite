<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-13 02:48:09 --> Config Class Initialized
INFO - 2024-12-13 02:48:09 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:48:09 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:48:09 --> Utf8 Class Initialized
INFO - 2024-12-13 02:48:09 --> URI Class Initialized
DEBUG - 2024-12-13 02:48:09 --> No URI present. Default controller set.
INFO - 2024-12-13 02:48:09 --> Router Class Initialized
INFO - 2024-12-13 02:48:09 --> Output Class Initialized
INFO - 2024-12-13 02:48:09 --> Security Class Initialized
DEBUG - 2024-12-13 02:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:48:09 --> Input Class Initialized
INFO - 2024-12-13 02:48:09 --> Language Class Initialized
INFO - 2024-12-13 02:48:09 --> Loader Class Initialized
INFO - 2024-12-13 02:48:09 --> Helper loaded: url_helper
INFO - 2024-12-13 02:48:09 --> Helper loaded: html_helper
INFO - 2024-12-13 02:48:09 --> Helper loaded: file_helper
INFO - 2024-12-13 02:48:09 --> Helper loaded: string_helper
INFO - 2024-12-13 02:48:09 --> Helper loaded: form_helper
INFO - 2024-12-13 02:48:09 --> Helper loaded: my_helper
INFO - 2024-12-13 02:48:09 --> Database Driver Class Initialized
INFO - 2024-12-13 02:48:11 --> Upload Class Initialized
INFO - 2024-12-13 02:48:11 --> Email Class Initialized
INFO - 2024-12-13 02:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 02:48:11 --> Form Validation Class Initialized
INFO - 2024-12-13 02:48:11 --> Controller Class Initialized
INFO - 2024-12-13 08:18:11 --> Model "MainModel" initialized
INFO - 2024-12-13 08:18:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-13 08:18:12 --> Final output sent to browser
DEBUG - 2024-12-13 08:18:12 --> Total execution time: 2.8195
INFO - 2024-12-13 02:48:14 --> Config Class Initialized
INFO - 2024-12-13 02:48:14 --> Hooks Class Initialized
DEBUG - 2024-12-13 02:48:14 --> UTF-8 Support Enabled
INFO - 2024-12-13 02:48:14 --> Utf8 Class Initialized
INFO - 2024-12-13 02:48:15 --> URI Class Initialized
INFO - 2024-12-13 02:48:15 --> Router Class Initialized
INFO - 2024-12-13 02:48:15 --> Output Class Initialized
INFO - 2024-12-13 02:48:15 --> Security Class Initialized
DEBUG - 2024-12-13 02:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 02:48:15 --> Input Class Initialized
INFO - 2024-12-13 02:48:15 --> Language Class Initialized
ERROR - 2024-12-13 02:48:15 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-13 11:23:38 --> Config Class Initialized
INFO - 2024-12-13 11:23:38 --> Hooks Class Initialized
DEBUG - 2024-12-13 11:23:38 --> UTF-8 Support Enabled
INFO - 2024-12-13 11:23:38 --> Utf8 Class Initialized
INFO - 2024-12-13 11:23:38 --> URI Class Initialized
INFO - 2024-12-13 11:23:38 --> Router Class Initialized
INFO - 2024-12-13 11:23:38 --> Output Class Initialized
INFO - 2024-12-13 11:23:38 --> Security Class Initialized
DEBUG - 2024-12-13 11:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 11:23:38 --> Input Class Initialized
INFO - 2024-12-13 11:23:38 --> Language Class Initialized
ERROR - 2024-12-13 11:23:38 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-13 11:23:40 --> Config Class Initialized
INFO - 2024-12-13 11:23:40 --> Hooks Class Initialized
DEBUG - 2024-12-13 11:23:40 --> UTF-8 Support Enabled
INFO - 2024-12-13 11:23:40 --> Utf8 Class Initialized
INFO - 2024-12-13 11:23:40 --> URI Class Initialized
DEBUG - 2024-12-13 11:23:40 --> No URI present. Default controller set.
INFO - 2024-12-13 11:23:40 --> Router Class Initialized
INFO - 2024-12-13 11:23:40 --> Output Class Initialized
INFO - 2024-12-13 11:23:40 --> Security Class Initialized
DEBUG - 2024-12-13 11:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 11:23:40 --> Input Class Initialized
INFO - 2024-12-13 11:23:40 --> Language Class Initialized
INFO - 2024-12-13 11:23:40 --> Loader Class Initialized
INFO - 2024-12-13 11:23:40 --> Helper loaded: url_helper
INFO - 2024-12-13 11:23:40 --> Helper loaded: html_helper
INFO - 2024-12-13 11:23:40 --> Helper loaded: file_helper
INFO - 2024-12-13 11:23:40 --> Helper loaded: string_helper
INFO - 2024-12-13 11:23:40 --> Helper loaded: form_helper
INFO - 2024-12-13 11:23:40 --> Helper loaded: my_helper
INFO - 2024-12-13 11:23:40 --> Database Driver Class Initialized
INFO - 2024-12-13 11:23:43 --> Upload Class Initialized
INFO - 2024-12-13 11:23:43 --> Email Class Initialized
INFO - 2024-12-13 11:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 11:23:43 --> Form Validation Class Initialized
INFO - 2024-12-13 11:23:43 --> Controller Class Initialized
INFO - 2024-12-13 16:53:43 --> Model "MainModel" initialized
INFO - 2024-12-13 16:53:43 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-13 16:53:43 --> Final output sent to browser
DEBUG - 2024-12-13 16:53:43 --> Total execution time: 3.0307
INFO - 2024-12-13 17:19:49 --> Config Class Initialized
INFO - 2024-12-13 17:19:49 --> Hooks Class Initialized
DEBUG - 2024-12-13 17:19:49 --> UTF-8 Support Enabled
INFO - 2024-12-13 17:19:49 --> Utf8 Class Initialized
INFO - 2024-12-13 17:19:49 --> URI Class Initialized
DEBUG - 2024-12-13 17:19:49 --> No URI present. Default controller set.
INFO - 2024-12-13 17:19:49 --> Router Class Initialized
INFO - 2024-12-13 17:19:49 --> Output Class Initialized
INFO - 2024-12-13 17:19:49 --> Security Class Initialized
DEBUG - 2024-12-13 17:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 17:19:49 --> Input Class Initialized
INFO - 2024-12-13 17:19:49 --> Language Class Initialized
INFO - 2024-12-13 17:19:49 --> Loader Class Initialized
INFO - 2024-12-13 17:19:49 --> Helper loaded: url_helper
INFO - 2024-12-13 17:19:49 --> Helper loaded: html_helper
INFO - 2024-12-13 17:19:49 --> Helper loaded: file_helper
INFO - 2024-12-13 17:19:49 --> Helper loaded: string_helper
INFO - 2024-12-13 17:19:49 --> Helper loaded: form_helper
INFO - 2024-12-13 17:19:49 --> Helper loaded: my_helper
INFO - 2024-12-13 17:19:49 --> Database Driver Class Initialized
INFO - 2024-12-13 17:19:51 --> Upload Class Initialized
INFO - 2024-12-13 17:19:51 --> Email Class Initialized
INFO - 2024-12-13 17:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 17:19:51 --> Form Validation Class Initialized
INFO - 2024-12-13 17:19:51 --> Controller Class Initialized
INFO - 2024-12-13 22:49:51 --> Model "MainModel" initialized
INFO - 2024-12-13 22:49:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-13 22:49:51 --> Final output sent to browser
DEBUG - 2024-12-13 22:49:51 --> Total execution time: 2.2769
INFO - 2024-12-13 19:57:46 --> Config Class Initialized
INFO - 2024-12-13 19:57:46 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:46 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:46 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:46 --> URI Class Initialized
DEBUG - 2024-12-13 19:57:46 --> No URI present. Default controller set.
INFO - 2024-12-13 19:57:46 --> Router Class Initialized
INFO - 2024-12-13 19:57:46 --> Output Class Initialized
INFO - 2024-12-13 19:57:46 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:46 --> Input Class Initialized
INFO - 2024-12-13 19:57:46 --> Language Class Initialized
INFO - 2024-12-13 19:57:46 --> Loader Class Initialized
INFO - 2024-12-13 19:57:46 --> Helper loaded: url_helper
INFO - 2024-12-13 19:57:46 --> Helper loaded: html_helper
INFO - 2024-12-13 19:57:46 --> Helper loaded: file_helper
INFO - 2024-12-13 19:57:46 --> Helper loaded: string_helper
INFO - 2024-12-13 19:57:46 --> Helper loaded: form_helper
INFO - 2024-12-13 19:57:46 --> Helper loaded: my_helper
INFO - 2024-12-13 19:57:46 --> Database Driver Class Initialized
INFO - 2024-12-13 19:57:48 --> Upload Class Initialized
INFO - 2024-12-13 19:57:48 --> Email Class Initialized
INFO - 2024-12-13 19:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 19:57:48 --> Form Validation Class Initialized
INFO - 2024-12-13 19:57:48 --> Controller Class Initialized
INFO - 2024-12-13 19:57:49 --> Config Class Initialized
INFO - 2024-12-13 19:57:49 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:49 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:49 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:49 --> URI Class Initialized
INFO - 2024-12-13 19:57:49 --> Router Class Initialized
INFO - 2024-12-13 19:57:49 --> Output Class Initialized
INFO - 2024-12-13 19:57:49 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:49 --> Input Class Initialized
INFO - 2024-12-13 19:57:49 --> Language Class Initialized
ERROR - 2024-12-13 19:57:49 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-13 19:57:49 --> Config Class Initialized
INFO - 2024-12-13 19:57:49 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:49 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:49 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:49 --> URI Class Initialized
INFO - 2024-12-13 19:57:49 --> Router Class Initialized
INFO - 2024-12-13 19:57:49 --> Output Class Initialized
INFO - 2024-12-13 19:57:49 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:49 --> Input Class Initialized
INFO - 2024-12-13 19:57:49 --> Language Class Initialized
ERROR - 2024-12-13 19:57:49 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-13 19:57:49 --> Config Class Initialized
INFO - 2024-12-13 19:57:49 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:49 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:49 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:49 --> URI Class Initialized
DEBUG - 2024-12-13 19:57:49 --> No URI present. Default controller set.
INFO - 2024-12-13 19:57:49 --> Router Class Initialized
INFO - 2024-12-13 19:57:49 --> Output Class Initialized
INFO - 2024-12-13 19:57:49 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:49 --> Input Class Initialized
INFO - 2024-12-13 19:57:49 --> Language Class Initialized
INFO - 2024-12-13 19:57:49 --> Loader Class Initialized
INFO - 2024-12-13 19:57:49 --> Helper loaded: url_helper
INFO - 2024-12-13 19:57:49 --> Helper loaded: html_helper
INFO - 2024-12-13 19:57:49 --> Helper loaded: file_helper
INFO - 2024-12-13 19:57:49 --> Helper loaded: string_helper
INFO - 2024-12-13 19:57:49 --> Helper loaded: form_helper
INFO - 2024-12-13 19:57:49 --> Helper loaded: my_helper
INFO - 2024-12-13 19:57:49 --> Database Driver Class Initialized
INFO - 2024-12-13 19:57:51 --> Upload Class Initialized
INFO - 2024-12-13 19:57:51 --> Email Class Initialized
INFO - 2024-12-13 19:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-13 19:57:51 --> Form Validation Class Initialized
INFO - 2024-12-13 19:57:51 --> Controller Class Initialized
INFO - 2024-12-13 19:57:51 --> Config Class Initialized
INFO - 2024-12-13 19:57:51 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:51 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:51 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:51 --> URI Class Initialized
INFO - 2024-12-13 19:57:51 --> Router Class Initialized
INFO - 2024-12-13 19:57:51 --> Output Class Initialized
INFO - 2024-12-13 19:57:51 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:51 --> Input Class Initialized
INFO - 2024-12-13 19:57:51 --> Language Class Initialized
ERROR - 2024-12-13 19:57:51 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-13 19:57:52 --> Config Class Initialized
INFO - 2024-12-13 19:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:52 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:52 --> URI Class Initialized
INFO - 2024-12-13 19:57:52 --> Router Class Initialized
INFO - 2024-12-13 19:57:52 --> Output Class Initialized
INFO - 2024-12-13 19:57:52 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:52 --> Input Class Initialized
INFO - 2024-12-13 19:57:52 --> Language Class Initialized
ERROR - 2024-12-13 19:57:52 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-13 19:57:52 --> Config Class Initialized
INFO - 2024-12-13 19:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:52 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:52 --> URI Class Initialized
INFO - 2024-12-13 19:57:52 --> Router Class Initialized
INFO - 2024-12-13 19:57:52 --> Output Class Initialized
INFO - 2024-12-13 19:57:52 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:52 --> Input Class Initialized
INFO - 2024-12-13 19:57:52 --> Language Class Initialized
ERROR - 2024-12-13 19:57:52 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-13 19:57:52 --> Config Class Initialized
INFO - 2024-12-13 19:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:52 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:52 --> URI Class Initialized
INFO - 2024-12-13 19:57:52 --> Router Class Initialized
INFO - 2024-12-13 19:57:52 --> Output Class Initialized
INFO - 2024-12-13 19:57:52 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:52 --> Input Class Initialized
INFO - 2024-12-13 19:57:52 --> Language Class Initialized
ERROR - 2024-12-13 19:57:52 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-13 19:57:52 --> Config Class Initialized
INFO - 2024-12-13 19:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:52 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:52 --> URI Class Initialized
INFO - 2024-12-13 19:57:52 --> Router Class Initialized
INFO - 2024-12-13 19:57:52 --> Output Class Initialized
INFO - 2024-12-13 19:57:52 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:52 --> Input Class Initialized
INFO - 2024-12-13 19:57:52 --> Language Class Initialized
ERROR - 2024-12-13 19:57:52 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-13 19:57:53 --> Config Class Initialized
INFO - 2024-12-13 19:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:53 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:53 --> URI Class Initialized
INFO - 2024-12-13 19:57:53 --> Router Class Initialized
INFO - 2024-12-13 19:57:53 --> Output Class Initialized
INFO - 2024-12-13 19:57:53 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:53 --> Input Class Initialized
INFO - 2024-12-13 19:57:53 --> Language Class Initialized
ERROR - 2024-12-13 19:57:53 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-13 19:57:53 --> Config Class Initialized
INFO - 2024-12-13 19:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:53 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:53 --> URI Class Initialized
INFO - 2024-12-13 19:57:53 --> Router Class Initialized
INFO - 2024-12-13 19:57:53 --> Output Class Initialized
INFO - 2024-12-13 19:57:53 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:53 --> Input Class Initialized
INFO - 2024-12-13 19:57:53 --> Language Class Initialized
ERROR - 2024-12-13 19:57:53 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-12-13 19:57:53 --> Config Class Initialized
INFO - 2024-12-13 19:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:53 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:53 --> URI Class Initialized
INFO - 2024-12-13 19:57:53 --> Router Class Initialized
INFO - 2024-12-13 19:57:53 --> Output Class Initialized
INFO - 2024-12-13 19:57:53 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:53 --> Input Class Initialized
INFO - 2024-12-13 19:57:53 --> Language Class Initialized
ERROR - 2024-12-13 19:57:53 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-13 19:57:53 --> Config Class Initialized
INFO - 2024-12-13 19:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:53 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:53 --> URI Class Initialized
INFO - 2024-12-13 19:57:53 --> Router Class Initialized
INFO - 2024-12-13 19:57:53 --> Output Class Initialized
INFO - 2024-12-13 19:57:53 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:53 --> Input Class Initialized
INFO - 2024-12-13 19:57:53 --> Language Class Initialized
ERROR - 2024-12-13 19:57:53 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-13 19:57:53 --> Config Class Initialized
INFO - 2024-12-13 19:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:53 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:53 --> URI Class Initialized
INFO - 2024-12-13 19:57:53 --> Router Class Initialized
INFO - 2024-12-13 19:57:53 --> Output Class Initialized
INFO - 2024-12-13 19:57:53 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:53 --> Input Class Initialized
INFO - 2024-12-13 19:57:53 --> Language Class Initialized
ERROR - 2024-12-13 19:57:53 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-13 19:57:54 --> Config Class Initialized
INFO - 2024-12-13 19:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:54 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:54 --> URI Class Initialized
INFO - 2024-12-13 19:57:54 --> Router Class Initialized
INFO - 2024-12-13 19:57:54 --> Output Class Initialized
INFO - 2024-12-13 19:57:54 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:54 --> Input Class Initialized
INFO - 2024-12-13 19:57:54 --> Language Class Initialized
ERROR - 2024-12-13 19:57:54 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-13 19:57:54 --> Config Class Initialized
INFO - 2024-12-13 19:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:54 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:54 --> URI Class Initialized
INFO - 2024-12-13 19:57:54 --> Router Class Initialized
INFO - 2024-12-13 19:57:54 --> Output Class Initialized
INFO - 2024-12-13 19:57:54 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:54 --> Input Class Initialized
INFO - 2024-12-13 19:57:54 --> Language Class Initialized
ERROR - 2024-12-13 19:57:54 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-12-13 19:57:54 --> Config Class Initialized
INFO - 2024-12-13 19:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:54 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:54 --> URI Class Initialized
INFO - 2024-12-13 19:57:54 --> Router Class Initialized
INFO - 2024-12-13 19:57:54 --> Output Class Initialized
INFO - 2024-12-13 19:57:54 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:54 --> Input Class Initialized
INFO - 2024-12-13 19:57:54 --> Language Class Initialized
ERROR - 2024-12-13 19:57:54 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-13 19:57:54 --> Config Class Initialized
INFO - 2024-12-13 19:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:54 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:54 --> URI Class Initialized
INFO - 2024-12-13 19:57:54 --> Router Class Initialized
INFO - 2024-12-13 19:57:54 --> Output Class Initialized
INFO - 2024-12-13 19:57:54 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:54 --> Input Class Initialized
INFO - 2024-12-13 19:57:54 --> Language Class Initialized
ERROR - 2024-12-13 19:57:54 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-13 19:57:55 --> Config Class Initialized
INFO - 2024-12-13 19:57:55 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:55 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:55 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:55 --> URI Class Initialized
INFO - 2024-12-13 19:57:55 --> Router Class Initialized
INFO - 2024-12-13 19:57:55 --> Output Class Initialized
INFO - 2024-12-13 19:57:55 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:55 --> Input Class Initialized
INFO - 2024-12-13 19:57:55 --> Language Class Initialized
ERROR - 2024-12-13 19:57:55 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-13 19:57:55 --> Config Class Initialized
INFO - 2024-12-13 19:57:55 --> Hooks Class Initialized
DEBUG - 2024-12-13 19:57:55 --> UTF-8 Support Enabled
INFO - 2024-12-13 19:57:55 --> Utf8 Class Initialized
INFO - 2024-12-13 19:57:55 --> URI Class Initialized
INFO - 2024-12-13 19:57:55 --> Router Class Initialized
INFO - 2024-12-13 19:57:55 --> Output Class Initialized
INFO - 2024-12-13 19:57:55 --> Security Class Initialized
DEBUG - 2024-12-13 19:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-13 19:57:55 --> Input Class Initialized
INFO - 2024-12-13 19:57:55 --> Language Class Initialized
ERROR - 2024-12-13 19:57:55 --> 404 Page Not Found: Sito/wp-includes
