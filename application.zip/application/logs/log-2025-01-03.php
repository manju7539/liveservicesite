<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-03 01:40:06 --> Model "MainModel" initialized
INFO - 2025-01-03 01:40:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2025-01-03 01:40:06 --> Final output sent to browser
DEBUG - 2025-01-03 01:40:06 --> Total execution time: 2.6125
INFO - 2025-01-03 05:45:17 --> Config Class Initialized
INFO - 2025-01-03 05:45:17 --> Hooks Class Initialized
DEBUG - 2025-01-03 05:45:17 --> UTF-8 Support Enabled
INFO - 2025-01-03 05:45:17 --> Utf8 Class Initialized
INFO - 2025-01-03 05:45:17 --> URI Class Initialized
DEBUG - 2025-01-03 05:45:18 --> No URI present. Default controller set.
INFO - 2025-01-03 05:45:18 --> Router Class Initialized
INFO - 2025-01-03 05:45:18 --> Output Class Initialized
INFO - 2025-01-03 05:45:18 --> Security Class Initialized
DEBUG - 2025-01-03 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-03 05:45:18 --> Input Class Initialized
INFO - 2025-01-03 05:45:18 --> Language Class Initialized
INFO - 2025-01-03 05:45:18 --> Loader Class Initialized
INFO - 2025-01-03 05:45:18 --> Helper loaded: url_helper
INFO - 2025-01-03 05:45:18 --> Helper loaded: html_helper
INFO - 2025-01-03 05:45:18 --> Helper loaded: file_helper
INFO - 2025-01-03 05:45:18 --> Helper loaded: string_helper
INFO - 2025-01-03 05:45:18 --> Helper loaded: form_helper
INFO - 2025-01-03 05:45:18 --> Helper loaded: my_helper
INFO - 2025-01-03 05:45:18 --> Database Driver Class Initialized
INFO - 2025-01-03 05:45:20 --> Upload Class Initialized
INFO - 2025-01-03 05:45:20 --> Email Class Initialized
INFO - 2025-01-03 05:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-03 05:45:20 --> Form Validation Class Initialized
INFO - 2025-01-03 05:45:20 --> Controller Class Initialized
INFO - 2025-01-03 11:15:21 --> Model "MainModel" initialized
INFO - 2025-01-03 11:15:21 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2025-01-03 11:15:21 --> Final output sent to browser
DEBUG - 2025-01-03 11:15:21 --> Total execution time: 3.3857
INFO - 2025-01-03 05:45:49 --> Config Class Initialized
INFO - 2025-01-03 05:45:49 --> Hooks Class Initialized
DEBUG - 2025-01-03 05:45:49 --> UTF-8 Support Enabled
INFO - 2025-01-03 05:45:49 --> Utf8 Class Initialized
INFO - 2025-01-03 05:45:49 --> URI Class Initialized
DEBUG - 2025-01-03 05:45:49 --> No URI present. Default controller set.
INFO - 2025-01-03 05:45:49 --> Router Class Initialized
INFO - 2025-01-03 05:45:49 --> Output Class Initialized
INFO - 2025-01-03 05:45:49 --> Security Class Initialized
DEBUG - 2025-01-03 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-03 05:45:49 --> Input Class Initialized
INFO - 2025-01-03 05:45:49 --> Language Class Initialized
INFO - 2025-01-03 05:45:49 --> Loader Class Initialized
INFO - 2025-01-03 05:45:49 --> Helper loaded: url_helper
INFO - 2025-01-03 05:45:49 --> Helper loaded: html_helper
INFO - 2025-01-03 05:45:49 --> Helper loaded: file_helper
INFO - 2025-01-03 05:45:49 --> Helper loaded: string_helper
INFO - 2025-01-03 05:45:49 --> Helper loaded: form_helper
INFO - 2025-01-03 05:45:49 --> Helper loaded: my_helper
INFO - 2025-01-03 05:45:49 --> Database Driver Class Initialized
INFO - 2025-01-03 05:45:51 --> Upload Class Initialized
INFO - 2025-01-03 05:45:51 --> Email Class Initialized
INFO - 2025-01-03 05:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-03 05:45:51 --> Form Validation Class Initialized
INFO - 2025-01-03 05:45:51 --> Controller Class Initialized
INFO - 2025-01-03 11:15:51 --> Model "MainModel" initialized
INFO - 2025-01-03 11:15:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2025-01-03 11:15:51 --> Final output sent to browser
DEBUG - 2025-01-03 11:15:51 --> Total execution time: 2.1640
