<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-27 02:58:32 --> Config Class Initialized
INFO - 2024-12-27 02:58:32 --> Hooks Class Initialized
DEBUG - 2024-12-27 02:58:32 --> UTF-8 Support Enabled
INFO - 2024-12-27 02:58:32 --> Utf8 Class Initialized
INFO - 2024-12-27 02:58:32 --> URI Class Initialized
INFO - 2024-12-27 02:58:32 --> Router Class Initialized
INFO - 2024-12-27 02:58:32 --> Output Class Initialized
INFO - 2024-12-27 02:58:32 --> Security Class Initialized
DEBUG - 2024-12-27 02:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 02:58:32 --> Input Class Initialized
INFO - 2024-12-27 02:58:32 --> Language Class Initialized
ERROR - 2024-12-27 02:58:32 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-27 16:39:25 --> Config Class Initialized
INFO - 2024-12-27 16:39:25 --> Hooks Class Initialized
DEBUG - 2024-12-27 16:39:25 --> UTF-8 Support Enabled
INFO - 2024-12-27 16:39:25 --> Utf8 Class Initialized
INFO - 2024-12-27 16:39:25 --> URI Class Initialized
DEBUG - 2024-12-27 16:39:25 --> No URI present. Default controller set.
INFO - 2024-12-27 16:39:25 --> Router Class Initialized
INFO - 2024-12-27 16:39:25 --> Output Class Initialized
INFO - 2024-12-27 16:39:25 --> Security Class Initialized
DEBUG - 2024-12-27 16:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 16:39:25 --> Input Class Initialized
INFO - 2024-12-27 16:39:25 --> Language Class Initialized
INFO - 2024-12-27 16:39:25 --> Loader Class Initialized
INFO - 2024-12-27 16:39:25 --> Helper loaded: url_helper
INFO - 2024-12-27 16:39:25 --> Helper loaded: html_helper
INFO - 2024-12-27 16:39:25 --> Helper loaded: file_helper
INFO - 2024-12-27 16:39:25 --> Helper loaded: string_helper
INFO - 2024-12-27 16:39:25 --> Helper loaded: form_helper
INFO - 2024-12-27 16:39:25 --> Helper loaded: my_helper
INFO - 2024-12-27 16:39:25 --> Database Driver Class Initialized
INFO - 2024-12-27 16:39:27 --> Upload Class Initialized
INFO - 2024-12-27 16:39:27 --> Email Class Initialized
INFO - 2024-12-27 16:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 16:39:27 --> Form Validation Class Initialized
INFO - 2024-12-27 16:39:27 --> Controller Class Initialized
INFO - 2024-12-27 22:09:27 --> Model "MainModel" initialized
INFO - 2024-12-27 22:09:27 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-27 22:09:27 --> Final output sent to browser
DEBUG - 2024-12-27 22:09:27 --> Total execution time: 2.7336
INFO - 2024-12-27 19:39:15 --> Config Class Initialized
INFO - 2024-12-27 19:39:15 --> Hooks Class Initialized
DEBUG - 2024-12-27 19:39:15 --> UTF-8 Support Enabled
INFO - 2024-12-27 19:39:15 --> Utf8 Class Initialized
INFO - 2024-12-27 19:39:15 --> URI Class Initialized
INFO - 2024-12-27 19:39:15 --> Router Class Initialized
INFO - 2024-12-27 19:39:15 --> Output Class Initialized
INFO - 2024-12-27 19:39:15 --> Security Class Initialized
DEBUG - 2024-12-27 19:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 19:39:15 --> Input Class Initialized
INFO - 2024-12-27 19:39:15 --> Language Class Initialized
ERROR - 2024-12-27 19:39:15 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-27 19:39:16 --> Config Class Initialized
INFO - 2024-12-27 19:39:16 --> Hooks Class Initialized
DEBUG - 2024-12-27 19:39:16 --> UTF-8 Support Enabled
INFO - 2024-12-27 19:39:16 --> Utf8 Class Initialized
INFO - 2024-12-27 19:39:16 --> URI Class Initialized
DEBUG - 2024-12-27 19:39:16 --> No URI present. Default controller set.
INFO - 2024-12-27 19:39:16 --> Router Class Initialized
INFO - 2024-12-27 19:39:16 --> Output Class Initialized
INFO - 2024-12-27 19:39:16 --> Security Class Initialized
DEBUG - 2024-12-27 19:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 19:39:16 --> Input Class Initialized
INFO - 2024-12-27 19:39:16 --> Language Class Initialized
INFO - 2024-12-27 19:39:16 --> Loader Class Initialized
INFO - 2024-12-27 19:39:16 --> Helper loaded: url_helper
INFO - 2024-12-27 19:39:16 --> Helper loaded: html_helper
INFO - 2024-12-27 19:39:16 --> Helper loaded: file_helper
INFO - 2024-12-27 19:39:16 --> Helper loaded: string_helper
INFO - 2024-12-27 19:39:16 --> Helper loaded: form_helper
INFO - 2024-12-27 19:39:16 --> Helper loaded: my_helper
INFO - 2024-12-27 19:39:16 --> Database Driver Class Initialized
INFO - 2024-12-27 19:39:18 --> Upload Class Initialized
INFO - 2024-12-27 19:39:18 --> Email Class Initialized
INFO - 2024-12-27 19:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-27 19:39:18 --> Form Validation Class Initialized
INFO - 2024-12-27 19:39:18 --> Controller Class Initialized
INFO - 2024-12-27 22:43:27 --> Config Class Initialized
INFO - 2024-12-27 22:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-27 22:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-27 22:43:27 --> Utf8 Class Initialized
INFO - 2024-12-27 22:43:27 --> URI Class Initialized
INFO - 2024-12-27 22:43:27 --> Router Class Initialized
INFO - 2024-12-27 22:43:27 --> Output Class Initialized
INFO - 2024-12-27 22:43:27 --> Security Class Initialized
DEBUG - 2024-12-27 22:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-27 22:43:27 --> Input Class Initialized
INFO - 2024-12-27 22:43:27 --> Language Class Initialized
ERROR - 2024-12-27 22:43:27 --> 404 Page Not Found: Wp-loginphp/index
