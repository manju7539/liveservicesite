<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-19 00:17:56 --> Model "MainModel" initialized
INFO - 2024-12-19 00:17:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-19 00:17:56 --> Final output sent to browser
DEBUG - 2024-12-19 00:17:56 --> Total execution time: 2.4489
