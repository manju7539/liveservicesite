<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-17 16:39:44 --> Config Class Initialized
INFO - 2024-11-17 16:39:44 --> Hooks Class Initialized
DEBUG - 2024-11-17 16:39:44 --> UTF-8 Support Enabled
INFO - 2024-11-17 16:39:44 --> Utf8 Class Initialized
INFO - 2024-11-17 16:39:44 --> URI Class Initialized
INFO - 2024-11-17 16:39:44 --> Router Class Initialized
INFO - 2024-11-17 16:39:44 --> Output Class Initialized
INFO - 2024-11-17 16:39:44 --> Security Class Initialized
DEBUG - 2024-11-17 16:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 16:39:44 --> Input Class Initialized
INFO - 2024-11-17 16:39:44 --> Language Class Initialized
ERROR - 2024-11-17 16:39:44 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-17 16:39:46 --> Config Class Initialized
INFO - 2024-11-17 16:39:46 --> Hooks Class Initialized
DEBUG - 2024-11-17 16:39:46 --> UTF-8 Support Enabled
INFO - 2024-11-17 16:39:46 --> Utf8 Class Initialized
INFO - 2024-11-17 16:39:46 --> URI Class Initialized
DEBUG - 2024-11-17 16:39:46 --> No URI present. Default controller set.
INFO - 2024-11-17 16:39:46 --> Router Class Initialized
INFO - 2024-11-17 16:39:46 --> Output Class Initialized
INFO - 2024-11-17 16:39:46 --> Security Class Initialized
DEBUG - 2024-11-17 16:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 16:39:46 --> Input Class Initialized
INFO - 2024-11-17 16:39:46 --> Language Class Initialized
INFO - 2024-11-17 16:39:46 --> Loader Class Initialized
INFO - 2024-11-17 16:39:46 --> Helper loaded: url_helper
INFO - 2024-11-17 16:39:46 --> Helper loaded: html_helper
INFO - 2024-11-17 16:39:46 --> Helper loaded: file_helper
INFO - 2024-11-17 16:39:46 --> Helper loaded: string_helper
INFO - 2024-11-17 16:39:46 --> Helper loaded: form_helper
INFO - 2024-11-17 16:39:46 --> Helper loaded: my_helper
INFO - 2024-11-17 16:39:47 --> Database Driver Class Initialized
INFO - 2024-11-17 16:39:49 --> Upload Class Initialized
INFO - 2024-11-17 16:39:49 --> Email Class Initialized
INFO - 2024-11-17 16:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 16:39:49 --> Form Validation Class Initialized
INFO - 2024-11-17 16:39:49 --> Controller Class Initialized
INFO - 2024-11-17 22:09:49 --> Model "MainModel" initialized
INFO - 2024-11-17 22:09:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-17 22:09:49 --> Final output sent to browser
DEBUG - 2024-11-17 22:09:49 --> Total execution time: 3.1872
INFO - 2024-11-17 21:02:15 --> Config Class Initialized
INFO - 2024-11-17 21:02:15 --> Hooks Class Initialized
DEBUG - 2024-11-17 21:02:15 --> UTF-8 Support Enabled
INFO - 2024-11-17 21:02:15 --> Utf8 Class Initialized
INFO - 2024-11-17 21:02:15 --> URI Class Initialized
DEBUG - 2024-11-17 21:02:15 --> No URI present. Default controller set.
INFO - 2024-11-17 21:02:15 --> Router Class Initialized
INFO - 2024-11-17 21:02:15 --> Output Class Initialized
INFO - 2024-11-17 21:02:15 --> Security Class Initialized
DEBUG - 2024-11-17 21:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-17 21:02:15 --> Input Class Initialized
INFO - 2024-11-17 21:02:15 --> Language Class Initialized
INFO - 2024-11-17 21:02:15 --> Loader Class Initialized
INFO - 2024-11-17 21:02:15 --> Helper loaded: url_helper
INFO - 2024-11-17 21:02:15 --> Helper loaded: html_helper
INFO - 2024-11-17 21:02:15 --> Helper loaded: file_helper
INFO - 2024-11-17 21:02:15 --> Helper loaded: string_helper
INFO - 2024-11-17 21:02:15 --> Helper loaded: form_helper
INFO - 2024-11-17 21:02:15 --> Helper loaded: my_helper
INFO - 2024-11-17 21:02:15 --> Database Driver Class Initialized
INFO - 2024-11-17 21:02:17 --> Upload Class Initialized
INFO - 2024-11-17 21:02:17 --> Email Class Initialized
INFO - 2024-11-17 21:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-17 21:02:17 --> Form Validation Class Initialized
INFO - 2024-11-17 21:02:17 --> Controller Class Initialized
