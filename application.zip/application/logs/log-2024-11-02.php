<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-02 03:19:13 --> Config Class Initialized
INFO - 2024-11-02 03:19:13 --> Hooks Class Initialized
DEBUG - 2024-11-02 03:19:13 --> UTF-8 Support Enabled
INFO - 2024-11-02 03:19:13 --> Utf8 Class Initialized
INFO - 2024-11-02 03:19:13 --> URI Class Initialized
DEBUG - 2024-11-02 03:19:13 --> No URI present. Default controller set.
INFO - 2024-11-02 03:19:13 --> Router Class Initialized
INFO - 2024-11-02 03:19:13 --> Output Class Initialized
INFO - 2024-11-02 03:19:13 --> Security Class Initialized
DEBUG - 2024-11-02 03:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 03:19:13 --> Input Class Initialized
INFO - 2024-11-02 03:19:13 --> Language Class Initialized
INFO - 2024-11-02 03:19:13 --> Loader Class Initialized
INFO - 2024-11-02 03:19:13 --> Helper loaded: url_helper
INFO - 2024-11-02 03:19:13 --> Helper loaded: html_helper
INFO - 2024-11-02 03:19:13 --> Helper loaded: file_helper
INFO - 2024-11-02 03:19:13 --> Helper loaded: string_helper
INFO - 2024-11-02 03:19:13 --> Helper loaded: form_helper
INFO - 2024-11-02 03:19:13 --> Helper loaded: my_helper
INFO - 2024-11-02 03:19:13 --> Database Driver Class Initialized
INFO - 2024-11-02 03:19:15 --> Upload Class Initialized
INFO - 2024-11-02 03:19:15 --> Email Class Initialized
INFO - 2024-11-02 03:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-02 03:19:15 --> Form Validation Class Initialized
INFO - 2024-11-02 03:19:15 --> Controller Class Initialized
INFO - 2024-11-02 08:49:15 --> Model "MainModel" initialized
INFO - 2024-11-02 08:49:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-02 08:49:15 --> Final output sent to browser
DEBUG - 2024-11-02 08:49:15 --> Total execution time: 2.3611
INFO - 2024-11-02 12:40:48 --> Config Class Initialized
INFO - 2024-11-02 12:40:48 --> Hooks Class Initialized
DEBUG - 2024-11-02 12:40:48 --> UTF-8 Support Enabled
INFO - 2024-11-02 12:40:48 --> Utf8 Class Initialized
INFO - 2024-11-02 12:40:48 --> URI Class Initialized
DEBUG - 2024-11-02 12:40:48 --> No URI present. Default controller set.
INFO - 2024-11-02 12:40:48 --> Router Class Initialized
INFO - 2024-11-02 12:40:48 --> Output Class Initialized
INFO - 2024-11-02 12:40:48 --> Security Class Initialized
DEBUG - 2024-11-02 12:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 12:40:48 --> Input Class Initialized
INFO - 2024-11-02 12:40:48 --> Language Class Initialized
INFO - 2024-11-02 12:40:48 --> Loader Class Initialized
INFO - 2024-11-02 12:40:48 --> Helper loaded: url_helper
INFO - 2024-11-02 12:40:48 --> Helper loaded: html_helper
INFO - 2024-11-02 12:40:48 --> Helper loaded: file_helper
INFO - 2024-11-02 12:40:48 --> Helper loaded: string_helper
INFO - 2024-11-02 12:40:48 --> Helper loaded: form_helper
INFO - 2024-11-02 12:40:48 --> Helper loaded: my_helper
INFO - 2024-11-02 12:40:48 --> Database Driver Class Initialized
INFO - 2024-11-02 12:40:50 --> Upload Class Initialized
INFO - 2024-11-02 12:40:50 --> Email Class Initialized
INFO - 2024-11-02 12:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-02 12:40:50 --> Form Validation Class Initialized
INFO - 2024-11-02 12:40:50 --> Controller Class Initialized
INFO - 2024-11-02 18:10:50 --> Model "MainModel" initialized
INFO - 2024-11-02 18:10:50 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-02 18:10:50 --> Final output sent to browser
DEBUG - 2024-11-02 18:10:50 --> Total execution time: 2.4673
INFO - 2024-11-02 12:41:46 --> Config Class Initialized
INFO - 2024-11-02 12:41:46 --> Hooks Class Initialized
DEBUG - 2024-11-02 12:41:46 --> UTF-8 Support Enabled
INFO - 2024-11-02 12:41:46 --> Utf8 Class Initialized
INFO - 2024-11-02 12:41:46 --> URI Class Initialized
DEBUG - 2024-11-02 12:41:46 --> No URI present. Default controller set.
INFO - 2024-11-02 12:41:46 --> Router Class Initialized
INFO - 2024-11-02 12:41:46 --> Output Class Initialized
INFO - 2024-11-02 12:41:46 --> Security Class Initialized
DEBUG - 2024-11-02 12:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 12:41:46 --> Input Class Initialized
INFO - 2024-11-02 12:41:46 --> Language Class Initialized
INFO - 2024-11-02 12:41:46 --> Loader Class Initialized
INFO - 2024-11-02 12:41:46 --> Helper loaded: url_helper
INFO - 2024-11-02 12:41:46 --> Helper loaded: html_helper
INFO - 2024-11-02 12:41:47 --> Helper loaded: file_helper
INFO - 2024-11-02 12:41:47 --> Helper loaded: string_helper
INFO - 2024-11-02 12:41:47 --> Helper loaded: form_helper
INFO - 2024-11-02 12:41:47 --> Helper loaded: my_helper
INFO - 2024-11-02 12:41:47 --> Database Driver Class Initialized
INFO - 2024-11-02 12:41:49 --> Upload Class Initialized
INFO - 2024-11-02 12:41:49 --> Email Class Initialized
INFO - 2024-11-02 12:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-02 12:41:49 --> Form Validation Class Initialized
INFO - 2024-11-02 12:41:49 --> Controller Class Initialized
INFO - 2024-11-02 18:11:49 --> Model "MainModel" initialized
INFO - 2024-11-02 18:11:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-02 18:11:49 --> Final output sent to browser
DEBUG - 2024-11-02 18:11:49 --> Total execution time: 2.1789
INFO - 2024-11-02 12:41:50 --> Config Class Initialized
INFO - 2024-11-02 12:41:50 --> Hooks Class Initialized
DEBUG - 2024-11-02 12:41:50 --> UTF-8 Support Enabled
INFO - 2024-11-02 12:41:50 --> Utf8 Class Initialized
INFO - 2024-11-02 12:41:50 --> URI Class Initialized
DEBUG - 2024-11-02 12:41:50 --> No URI present. Default controller set.
INFO - 2024-11-02 12:41:50 --> Router Class Initialized
INFO - 2024-11-02 12:41:50 --> Output Class Initialized
INFO - 2024-11-02 12:41:50 --> Security Class Initialized
DEBUG - 2024-11-02 12:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-02 12:41:50 --> Input Class Initialized
INFO - 2024-11-02 12:41:50 --> Language Class Initialized
INFO - 2024-11-02 12:41:50 --> Loader Class Initialized
INFO - 2024-11-02 12:41:50 --> Helper loaded: url_helper
INFO - 2024-11-02 12:41:50 --> Helper loaded: html_helper
INFO - 2024-11-02 12:41:50 --> Helper loaded: file_helper
INFO - 2024-11-02 12:41:50 --> Helper loaded: string_helper
INFO - 2024-11-02 12:41:50 --> Helper loaded: form_helper
INFO - 2024-11-02 12:41:50 --> Helper loaded: my_helper
INFO - 2024-11-02 12:41:50 --> Database Driver Class Initialized
INFO - 2024-11-02 12:41:52 --> Upload Class Initialized
INFO - 2024-11-02 12:41:52 --> Email Class Initialized
INFO - 2024-11-02 12:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-02 12:41:52 --> Form Validation Class Initialized
INFO - 2024-11-02 12:41:52 --> Controller Class Initialized
INFO - 2024-11-02 18:11:52 --> Model "MainModel" initialized
INFO - 2024-11-02 18:11:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-02 18:11:52 --> Final output sent to browser
DEBUG - 2024-11-02 18:11:52 --> Total execution time: 2.1739
