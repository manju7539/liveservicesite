<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-29 04:55:09 --> Config Class Initialized
INFO - 2024-11-29 04:55:09 --> Hooks Class Initialized
DEBUG - 2024-11-29 04:55:09 --> UTF-8 Support Enabled
INFO - 2024-11-29 04:55:09 --> Utf8 Class Initialized
INFO - 2024-11-29 04:55:09 --> URI Class Initialized
DEBUG - 2024-11-29 04:55:09 --> No URI present. Default controller set.
INFO - 2024-11-29 04:55:09 --> Router Class Initialized
INFO - 2024-11-29 04:55:09 --> Output Class Initialized
INFO - 2024-11-29 04:55:09 --> Security Class Initialized
DEBUG - 2024-11-29 04:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 04:55:09 --> Input Class Initialized
INFO - 2024-11-29 04:55:09 --> Language Class Initialized
INFO - 2024-11-29 04:55:09 --> Loader Class Initialized
INFO - 2024-11-29 04:55:09 --> Helper loaded: url_helper
INFO - 2024-11-29 04:55:09 --> Helper loaded: html_helper
INFO - 2024-11-29 04:55:09 --> Helper loaded: file_helper
INFO - 2024-11-29 04:55:09 --> Helper loaded: string_helper
INFO - 2024-11-29 04:55:09 --> Helper loaded: form_helper
INFO - 2024-11-29 04:55:09 --> Helper loaded: my_helper
INFO - 2024-11-29 04:55:09 --> Database Driver Class Initialized
INFO - 2024-11-29 04:55:11 --> Upload Class Initialized
INFO - 2024-11-29 04:55:11 --> Email Class Initialized
INFO - 2024-11-29 04:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 04:55:12 --> Form Validation Class Initialized
INFO - 2024-11-29 04:55:12 --> Controller Class Initialized
INFO - 2024-11-29 10:25:12 --> Model "MainModel" initialized
INFO - 2024-11-29 10:25:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-29 10:25:12 --> Final output sent to browser
DEBUG - 2024-11-29 10:25:12 --> Total execution time: 2.8222
INFO - 2024-11-29 04:55:13 --> Config Class Initialized
INFO - 2024-11-29 04:55:13 --> Hooks Class Initialized
DEBUG - 2024-11-29 04:55:13 --> UTF-8 Support Enabled
INFO - 2024-11-29 04:55:13 --> Utf8 Class Initialized
INFO - 2024-11-29 04:55:13 --> URI Class Initialized
INFO - 2024-11-29 04:55:13 --> Router Class Initialized
INFO - 2024-11-29 04:55:13 --> Output Class Initialized
INFO - 2024-11-29 04:55:13 --> Security Class Initialized
DEBUG - 2024-11-29 04:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 04:55:13 --> Input Class Initialized
INFO - 2024-11-29 04:55:13 --> Language Class Initialized
ERROR - 2024-11-29 04:55:13 --> 404 Page Not Found: Faviconico/index
INFO - 2024-11-29 07:41:57 --> Config Class Initialized
INFO - 2024-11-29 07:41:57 --> Hooks Class Initialized
DEBUG - 2024-11-29 07:41:57 --> UTF-8 Support Enabled
INFO - 2024-11-29 07:41:57 --> Utf8 Class Initialized
INFO - 2024-11-29 07:41:57 --> URI Class Initialized
DEBUG - 2024-11-29 07:41:57 --> No URI present. Default controller set.
INFO - 2024-11-29 07:41:57 --> Router Class Initialized
INFO - 2024-11-29 07:41:57 --> Output Class Initialized
INFO - 2024-11-29 07:41:57 --> Security Class Initialized
DEBUG - 2024-11-29 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 07:41:57 --> Input Class Initialized
INFO - 2024-11-29 07:41:57 --> Language Class Initialized
INFO - 2024-11-29 07:41:57 --> Loader Class Initialized
INFO - 2024-11-29 07:41:57 --> Helper loaded: url_helper
INFO - 2024-11-29 07:41:57 --> Helper loaded: html_helper
INFO - 2024-11-29 07:41:57 --> Helper loaded: file_helper
INFO - 2024-11-29 07:41:57 --> Helper loaded: string_helper
INFO - 2024-11-29 07:41:57 --> Helper loaded: form_helper
INFO - 2024-11-29 07:41:57 --> Helper loaded: my_helper
INFO - 2024-11-29 07:41:57 --> Database Driver Class Initialized
INFO - 2024-11-29 07:41:59 --> Upload Class Initialized
INFO - 2024-11-29 07:41:59 --> Email Class Initialized
INFO - 2024-11-29 07:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-29 07:41:59 --> Form Validation Class Initialized
INFO - 2024-11-29 07:41:59 --> Controller Class Initialized
INFO - 2024-11-29 13:11:59 --> Model "MainModel" initialized
INFO - 2024-11-29 13:11:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-29 13:11:59 --> Final output sent to browser
DEBUG - 2024-11-29 13:11:59 --> Total execution time: 2.3067
INFO - 2024-11-29 07:42:00 --> Config Class Initialized
INFO - 2024-11-29 07:42:00 --> Hooks Class Initialized
DEBUG - 2024-11-29 07:42:00 --> UTF-8 Support Enabled
INFO - 2024-11-29 07:42:00 --> Utf8 Class Initialized
INFO - 2024-11-29 07:42:00 --> URI Class Initialized
INFO - 2024-11-29 07:42:00 --> Router Class Initialized
INFO - 2024-11-29 07:42:01 --> Output Class Initialized
INFO - 2024-11-29 07:42:01 --> Security Class Initialized
DEBUG - 2024-11-29 07:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-29 07:42:01 --> Input Class Initialized
INFO - 2024-11-29 07:42:01 --> Language Class Initialized
ERROR - 2024-11-29 07:42:01 --> 404 Page Not Found: Faviconico/index
