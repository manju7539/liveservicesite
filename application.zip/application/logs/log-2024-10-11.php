<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-11 16:01:42 --> Config Class Initialized
INFO - 2024-10-11 16:01:42 --> Hooks Class Initialized
DEBUG - 2024-10-11 16:01:42 --> UTF-8 Support Enabled
INFO - 2024-10-11 16:01:42 --> Utf8 Class Initialized
INFO - 2024-10-11 16:01:42 --> URI Class Initialized
DEBUG - 2024-10-11 16:01:42 --> No URI present. Default controller set.
INFO - 2024-10-11 16:01:42 --> Router Class Initialized
INFO - 2024-10-11 16:01:42 --> Output Class Initialized
INFO - 2024-10-11 16:01:42 --> Security Class Initialized
DEBUG - 2024-10-11 16:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 16:01:42 --> Input Class Initialized
INFO - 2024-10-11 16:01:42 --> Language Class Initialized
INFO - 2024-10-11 16:01:42 --> Loader Class Initialized
INFO - 2024-10-11 16:01:42 --> Helper loaded: url_helper
INFO - 2024-10-11 16:01:42 --> Helper loaded: html_helper
INFO - 2024-10-11 16:01:42 --> Helper loaded: file_helper
INFO - 2024-10-11 16:01:42 --> Helper loaded: string_helper
INFO - 2024-10-11 16:01:42 --> Helper loaded: form_helper
INFO - 2024-10-11 16:01:42 --> Helper loaded: my_helper
INFO - 2024-10-11 16:01:42 --> Database Driver Class Initialized
INFO - 2024-10-11 16:01:44 --> Upload Class Initialized
INFO - 2024-10-11 16:01:44 --> Email Class Initialized
DEBUG - 2024-10-11 16:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-10-11 16:01:44 --> Session: Configured save path 'C:\Windows\Temp' is not writable by the PHP process.
ERROR - 2024-10-11 16:01:44 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\Windows\Temp) C:\inetpub\vhosts\livservice.in\httpdocs\system\libraries\Session\Session.php 137
INFO - 2024-10-11 16:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-11 16:01:44 --> Form Validation Class Initialized
INFO - 2024-10-11 16:01:44 --> Controller Class Initialized
INFO - 2024-10-11 21:31:44 --> Model "MainModel" initialized
INFO - 2024-10-11 21:31:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-11 21:31:44 --> Final output sent to browser
DEBUG - 2024-10-11 21:31:44 --> Total execution time: 2.3913
INFO - 2024-10-11 16:01:45 --> Config Class Initialized
INFO - 2024-10-11 16:01:45 --> Hooks Class Initialized
DEBUG - 2024-10-11 16:01:45 --> UTF-8 Support Enabled
INFO - 2024-10-11 16:01:45 --> Utf8 Class Initialized
INFO - 2024-10-11 16:01:45 --> URI Class Initialized
DEBUG - 2024-10-11 16:01:45 --> No URI present. Default controller set.
INFO - 2024-10-11 16:01:45 --> Router Class Initialized
INFO - 2024-10-11 16:01:45 --> Output Class Initialized
INFO - 2024-10-11 16:01:45 --> Security Class Initialized
DEBUG - 2024-10-11 16:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 16:01:45 --> Input Class Initialized
INFO - 2024-10-11 16:01:45 --> Language Class Initialized
INFO - 2024-10-11 16:01:45 --> Loader Class Initialized
INFO - 2024-10-11 16:01:45 --> Helper loaded: url_helper
INFO - 2024-10-11 16:01:45 --> Helper loaded: html_helper
INFO - 2024-10-11 16:01:46 --> Helper loaded: file_helper
INFO - 2024-10-11 16:01:46 --> Helper loaded: string_helper
INFO - 2024-10-11 16:01:46 --> Helper loaded: form_helper
INFO - 2024-10-11 16:01:46 --> Helper loaded: my_helper
INFO - 2024-10-11 16:01:46 --> Database Driver Class Initialized
INFO - 2024-10-11 16:01:48 --> Upload Class Initialized
INFO - 2024-10-11 16:01:48 --> Email Class Initialized
DEBUG - 2024-10-11 16:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-10-11 16:01:48 --> Session: Configured save path 'C:\Windows\Temp' is not writable by the PHP process.
ERROR - 2024-10-11 16:01:48 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\Windows\Temp) C:\inetpub\vhosts\livservice.in\httpdocs\system\libraries\Session\Session.php 137
INFO - 2024-10-11 16:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-11 16:01:48 --> Form Validation Class Initialized
INFO - 2024-10-11 16:01:48 --> Controller Class Initialized
INFO - 2024-10-11 21:31:48 --> Model "MainModel" initialized
INFO - 2024-10-11 21:31:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-11 21:31:48 --> Final output sent to browser
DEBUG - 2024-10-11 21:31:48 --> Total execution time: 2.1562
INFO - 2024-10-11 16:06:37 --> Config Class Initialized
INFO - 2024-10-11 16:06:37 --> Hooks Class Initialized
DEBUG - 2024-10-11 16:06:37 --> UTF-8 Support Enabled
INFO - 2024-10-11 16:06:37 --> Utf8 Class Initialized
INFO - 2024-10-11 16:06:37 --> URI Class Initialized
DEBUG - 2024-10-11 16:06:37 --> No URI present. Default controller set.
INFO - 2024-10-11 16:06:37 --> Router Class Initialized
INFO - 2024-10-11 16:06:37 --> Output Class Initialized
INFO - 2024-10-11 16:06:37 --> Security Class Initialized
DEBUG - 2024-10-11 16:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 16:06:37 --> Input Class Initialized
INFO - 2024-10-11 16:06:37 --> Language Class Initialized
INFO - 2024-10-11 16:06:37 --> Loader Class Initialized
INFO - 2024-10-11 16:06:37 --> Helper loaded: url_helper
INFO - 2024-10-11 16:06:37 --> Helper loaded: html_helper
INFO - 2024-10-11 16:06:37 --> Helper loaded: file_helper
INFO - 2024-10-11 16:06:37 --> Helper loaded: string_helper
INFO - 2024-10-11 16:06:37 --> Helper loaded: form_helper
INFO - 2024-10-11 16:06:37 --> Helper loaded: my_helper
INFO - 2024-10-11 16:06:37 --> Database Driver Class Initialized
INFO - 2024-10-11 16:06:39 --> Upload Class Initialized
INFO - 2024-10-11 16:06:39 --> Email Class Initialized
DEBUG - 2024-10-11 16:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-10-11 16:06:39 --> Session: Configured save path 'C:\Windows\Temp' is not writable by the PHP process.
ERROR - 2024-10-11 16:06:39 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\Windows\Temp) C:\inetpub\vhosts\livservice.in\httpdocs\system\libraries\Session\Session.php 137
INFO - 2024-10-11 16:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-11 16:06:39 --> Form Validation Class Initialized
INFO - 2024-10-11 16:06:39 --> Controller Class Initialized
INFO - 2024-10-11 21:36:39 --> Model "MainModel" initialized
INFO - 2024-10-11 21:36:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-11 21:36:39 --> Final output sent to browser
DEBUG - 2024-10-11 21:36:39 --> Total execution time: 2.1416
INFO - 2024-10-11 16:13:28 --> Config Class Initialized
INFO - 2024-10-11 16:13:28 --> Hooks Class Initialized
DEBUG - 2024-10-11 16:13:28 --> UTF-8 Support Enabled
INFO - 2024-10-11 16:13:28 --> Utf8 Class Initialized
INFO - 2024-10-11 16:13:28 --> URI Class Initialized
DEBUG - 2024-10-11 16:13:28 --> No URI present. Default controller set.
INFO - 2024-10-11 16:13:28 --> Router Class Initialized
INFO - 2024-10-11 16:13:28 --> Output Class Initialized
INFO - 2024-10-11 16:13:28 --> Security Class Initialized
DEBUG - 2024-10-11 16:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-11 16:13:28 --> Input Class Initialized
INFO - 2024-10-11 16:13:28 --> Language Class Initialized
INFO - 2024-10-11 16:13:28 --> Loader Class Initialized
INFO - 2024-10-11 16:13:28 --> Helper loaded: url_helper
INFO - 2024-10-11 16:13:28 --> Helper loaded: html_helper
INFO - 2024-10-11 16:13:28 --> Helper loaded: file_helper
INFO - 2024-10-11 16:13:28 --> Helper loaded: string_helper
INFO - 2024-10-11 16:13:28 --> Helper loaded: form_helper
INFO - 2024-10-11 16:13:28 --> Helper loaded: my_helper
INFO - 2024-10-11 16:13:28 --> Database Driver Class Initialized
INFO - 2024-10-11 16:13:30 --> Upload Class Initialized
INFO - 2024-10-11 16:13:30 --> Email Class Initialized
DEBUG - 2024-10-11 16:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2024-10-11 16:13:30 --> Session: Configured save path 'C:\Windows\Temp' is not writable by the PHP process.
ERROR - 2024-10-11 16:13:30 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\Windows\Temp) C:\inetpub\vhosts\livservice.in\httpdocs\system\libraries\Session\Session.php 137
INFO - 2024-10-11 16:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-11 16:13:30 --> Form Validation Class Initialized
INFO - 2024-10-11 16:13:30 --> Controller Class Initialized
INFO - 2024-10-11 21:43:30 --> Model "MainModel" initialized
INFO - 2024-10-11 21:43:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-11 21:43:30 --> Final output sent to browser
DEBUG - 2024-10-11 21:43:30 --> Total execution time: 2.3472
