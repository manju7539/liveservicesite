<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-27 01:16:40 --> Model "MainModel" initialized
INFO - 2024-10-27 01:16:40 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 01:16:40 --> Final output sent to browser
DEBUG - 2024-10-27 01:16:40 --> Total execution time: 2.6070
INFO - 2024-10-27 01:16:44 --> Model "MainModel" initialized
INFO - 2024-10-27 01:16:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 01:16:44 --> Final output sent to browser
DEBUG - 2024-10-27 01:16:44 --> Total execution time: 2.2159
INFO - 2024-10-27 03:26:29 --> Model "MainModel" initialized
INFO - 2024-10-27 03:26:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 03:26:30 --> Final output sent to browser
DEBUG - 2024-10-27 03:26:30 --> Total execution time: 18.9977
INFO - 2024-10-27 03:26:34 --> Model "MainModel" initialized
INFO - 2024-10-27 03:26:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 03:26:34 --> Final output sent to browser
DEBUG - 2024-10-27 03:26:34 --> Total execution time: 2.5566
INFO - 2024-10-27 03:48:36 --> Model "MainModel" initialized
INFO - 2024-10-27 03:48:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 03:48:37 --> Final output sent to browser
DEBUG - 2024-10-27 03:48:37 --> Total execution time: 5.2827
INFO - 2024-10-27 03:48:40 --> Model "MainModel" initialized
INFO - 2024-10-27 03:48:40 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 03:48:40 --> Final output sent to browser
DEBUG - 2024-10-27 03:48:40 --> Total execution time: 2.1182
INFO - 2024-10-27 02:22:43 --> Config Class Initialized
INFO - 2024-10-27 02:22:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 02:22:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 02:22:43 --> Utf8 Class Initialized
INFO - 2024-10-27 02:22:43 --> URI Class Initialized
DEBUG - 2024-10-27 02:22:43 --> No URI present. Default controller set.
INFO - 2024-10-27 02:22:43 --> Router Class Initialized
INFO - 2024-10-27 02:22:43 --> Output Class Initialized
INFO - 2024-10-27 02:22:43 --> Security Class Initialized
DEBUG - 2024-10-27 02:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 02:22:43 --> Input Class Initialized
INFO - 2024-10-27 02:22:43 --> Language Class Initialized
INFO - 2024-10-27 02:22:43 --> Loader Class Initialized
INFO - 2024-10-27 02:22:43 --> Helper loaded: url_helper
INFO - 2024-10-27 02:22:44 --> Helper loaded: html_helper
INFO - 2024-10-27 02:22:44 --> Helper loaded: file_helper
INFO - 2024-10-27 02:22:44 --> Helper loaded: string_helper
INFO - 2024-10-27 02:22:44 --> Helper loaded: form_helper
INFO - 2024-10-27 02:22:44 --> Helper loaded: my_helper
INFO - 2024-10-27 02:22:44 --> Database Driver Class Initialized
INFO - 2024-10-27 02:22:46 --> Upload Class Initialized
INFO - 2024-10-27 02:22:46 --> Email Class Initialized
INFO - 2024-10-27 02:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 02:22:47 --> Form Validation Class Initialized
INFO - 2024-10-27 02:22:47 --> Controller Class Initialized
INFO - 2024-10-27 07:52:47 --> Model "MainModel" initialized
INFO - 2024-10-27 07:52:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 07:52:47 --> Final output sent to browser
DEBUG - 2024-10-27 07:52:47 --> Total execution time: 4.3431
INFO - 2024-10-27 02:22:54 --> Config Class Initialized
INFO - 2024-10-27 02:22:54 --> Hooks Class Initialized
DEBUG - 2024-10-27 02:22:54 --> UTF-8 Support Enabled
INFO - 2024-10-27 02:22:54 --> Utf8 Class Initialized
INFO - 2024-10-27 02:22:55 --> URI Class Initialized
DEBUG - 2024-10-27 02:22:55 --> No URI present. Default controller set.
INFO - 2024-10-27 02:22:55 --> Router Class Initialized
INFO - 2024-10-27 02:22:55 --> Output Class Initialized
INFO - 2024-10-27 02:22:55 --> Security Class Initialized
DEBUG - 2024-10-27 02:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 02:22:55 --> Input Class Initialized
INFO - 2024-10-27 02:22:55 --> Language Class Initialized
INFO - 2024-10-27 02:22:55 --> Loader Class Initialized
INFO - 2024-10-27 02:22:55 --> Helper loaded: url_helper
INFO - 2024-10-27 02:22:55 --> Helper loaded: html_helper
INFO - 2024-10-27 02:22:55 --> Helper loaded: file_helper
INFO - 2024-10-27 02:22:55 --> Helper loaded: string_helper
INFO - 2024-10-27 02:22:55 --> Helper loaded: form_helper
INFO - 2024-10-27 02:22:55 --> Helper loaded: my_helper
INFO - 2024-10-27 02:22:55 --> Database Driver Class Initialized
INFO - 2024-10-27 02:22:57 --> Upload Class Initialized
INFO - 2024-10-27 02:22:57 --> Email Class Initialized
INFO - 2024-10-27 02:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 02:22:57 --> Form Validation Class Initialized
INFO - 2024-10-27 02:22:57 --> Controller Class Initialized
INFO - 2024-10-27 07:52:57 --> Model "MainModel" initialized
INFO - 2024-10-27 07:52:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 07:52:57 --> Final output sent to browser
DEBUG - 2024-10-27 07:52:57 --> Total execution time: 2.3568
INFO - 2024-10-27 02:47:10 --> Config Class Initialized
INFO - 2024-10-27 02:47:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 02:47:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 02:47:10 --> Utf8 Class Initialized
INFO - 2024-10-27 02:47:10 --> URI Class Initialized
DEBUG - 2024-10-27 02:47:11 --> No URI present. Default controller set.
INFO - 2024-10-27 02:47:11 --> Router Class Initialized
INFO - 2024-10-27 02:47:11 --> Output Class Initialized
INFO - 2024-10-27 02:47:11 --> Security Class Initialized
DEBUG - 2024-10-27 02:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 02:47:11 --> Input Class Initialized
INFO - 2024-10-27 02:47:11 --> Language Class Initialized
INFO - 2024-10-27 02:47:11 --> Loader Class Initialized
INFO - 2024-10-27 02:47:11 --> Helper loaded: url_helper
INFO - 2024-10-27 02:47:11 --> Helper loaded: html_helper
INFO - 2024-10-27 02:47:11 --> Helper loaded: file_helper
INFO - 2024-10-27 02:47:11 --> Helper loaded: string_helper
INFO - 2024-10-27 02:47:11 --> Helper loaded: form_helper
INFO - 2024-10-27 02:47:11 --> Helper loaded: my_helper
INFO - 2024-10-27 02:47:11 --> Database Driver Class Initialized
INFO - 2024-10-27 02:47:13 --> Upload Class Initialized
INFO - 2024-10-27 02:47:13 --> Email Class Initialized
INFO - 2024-10-27 02:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 02:47:13 --> Form Validation Class Initialized
INFO - 2024-10-27 02:47:13 --> Controller Class Initialized
INFO - 2024-10-27 08:17:14 --> Model "MainModel" initialized
INFO - 2024-10-27 08:17:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 08:17:14 --> Final output sent to browser
DEBUG - 2024-10-27 08:17:14 --> Total execution time: 3.1414
INFO - 2024-10-27 05:16:17 --> Config Class Initialized
INFO - 2024-10-27 05:16:17 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:16:18 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:16:18 --> Utf8 Class Initialized
INFO - 2024-10-27 05:16:19 --> URI Class Initialized
INFO - 2024-10-27 05:16:20 --> Router Class Initialized
INFO - 2024-10-27 05:16:20 --> Output Class Initialized
INFO - 2024-10-27 05:16:20 --> Security Class Initialized
DEBUG - 2024-10-27 05:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:16:20 --> Input Class Initialized
INFO - 2024-10-27 05:16:20 --> Language Class Initialized
ERROR - 2024-10-27 05:16:20 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-27 05:16:21 --> Config Class Initialized
INFO - 2024-10-27 05:16:21 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:16:21 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:16:21 --> Utf8 Class Initialized
INFO - 2024-10-27 05:16:21 --> URI Class Initialized
DEBUG - 2024-10-27 05:16:21 --> No URI present. Default controller set.
INFO - 2024-10-27 05:16:21 --> Router Class Initialized
INFO - 2024-10-27 05:16:21 --> Output Class Initialized
INFO - 2024-10-27 05:16:21 --> Security Class Initialized
DEBUG - 2024-10-27 05:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:16:21 --> Input Class Initialized
INFO - 2024-10-27 05:16:21 --> Language Class Initialized
INFO - 2024-10-27 05:16:21 --> Loader Class Initialized
INFO - 2024-10-27 05:16:21 --> Helper loaded: url_helper
INFO - 2024-10-27 05:16:21 --> Helper loaded: html_helper
INFO - 2024-10-27 05:16:21 --> Helper loaded: file_helper
INFO - 2024-10-27 05:16:21 --> Helper loaded: string_helper
INFO - 2024-10-27 05:16:21 --> Helper loaded: form_helper
INFO - 2024-10-27 05:16:21 --> Helper loaded: my_helper
INFO - 2024-10-27 05:16:22 --> Database Driver Class Initialized
INFO - 2024-10-27 05:16:24 --> Upload Class Initialized
INFO - 2024-10-27 05:16:24 --> Email Class Initialized
INFO - 2024-10-27 05:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 05:16:24 --> Form Validation Class Initialized
INFO - 2024-10-27 05:16:24 --> Controller Class Initialized
INFO - 2024-10-27 10:46:24 --> Model "MainModel" initialized
INFO - 2024-10-27 10:46:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 10:46:24 --> Final output sent to browser
DEBUG - 2024-10-27 10:46:24 --> Total execution time: 3.5556
INFO - 2024-10-27 05:16:25 --> Config Class Initialized
INFO - 2024-10-27 05:16:25 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:16:25 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:16:25 --> Utf8 Class Initialized
INFO - 2024-10-27 05:16:25 --> URI Class Initialized
INFO - 2024-10-27 05:16:25 --> Router Class Initialized
INFO - 2024-10-27 05:16:25 --> Output Class Initialized
INFO - 2024-10-27 05:16:25 --> Security Class Initialized
DEBUG - 2024-10-27 05:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:16:25 --> Input Class Initialized
INFO - 2024-10-27 05:16:25 --> Language Class Initialized
ERROR - 2024-10-27 05:16:25 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-27 05:16:26 --> Config Class Initialized
INFO - 2024-10-27 05:16:26 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:16:26 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:16:26 --> Utf8 Class Initialized
INFO - 2024-10-27 05:16:26 --> URI Class Initialized
DEBUG - 2024-10-27 05:16:26 --> No URI present. Default controller set.
INFO - 2024-10-27 05:16:26 --> Router Class Initialized
INFO - 2024-10-27 05:16:26 --> Output Class Initialized
INFO - 2024-10-27 05:16:26 --> Security Class Initialized
DEBUG - 2024-10-27 05:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:16:26 --> Input Class Initialized
INFO - 2024-10-27 05:16:26 --> Language Class Initialized
INFO - 2024-10-27 05:16:26 --> Loader Class Initialized
INFO - 2024-10-27 05:16:26 --> Helper loaded: url_helper
INFO - 2024-10-27 05:16:26 --> Helper loaded: html_helper
INFO - 2024-10-27 05:16:26 --> Helper loaded: file_helper
INFO - 2024-10-27 05:16:26 --> Helper loaded: string_helper
INFO - 2024-10-27 05:16:26 --> Helper loaded: form_helper
INFO - 2024-10-27 05:16:26 --> Helper loaded: my_helper
INFO - 2024-10-27 05:16:26 --> Database Driver Class Initialized
INFO - 2024-10-27 05:16:28 --> Upload Class Initialized
INFO - 2024-10-27 05:16:28 --> Email Class Initialized
INFO - 2024-10-27 05:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 05:16:28 --> Form Validation Class Initialized
INFO - 2024-10-27 05:16:28 --> Controller Class Initialized
INFO - 2024-10-27 10:46:28 --> Model "MainModel" initialized
INFO - 2024-10-27 10:46:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 10:46:28 --> Final output sent to browser
DEBUG - 2024-10-27 10:46:28 --> Total execution time: 2.2292
INFO - 2024-10-27 05:52:42 --> Config Class Initialized
INFO - 2024-10-27 05:52:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:42 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:42 --> URI Class Initialized
DEBUG - 2024-10-27 05:52:42 --> No URI present. Default controller set.
INFO - 2024-10-27 05:52:42 --> Router Class Initialized
INFO - 2024-10-27 05:52:42 --> Output Class Initialized
INFO - 2024-10-27 05:52:42 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:42 --> Input Class Initialized
INFO - 2024-10-27 05:52:42 --> Language Class Initialized
INFO - 2024-10-27 05:52:42 --> Loader Class Initialized
INFO - 2024-10-27 05:52:42 --> Helper loaded: url_helper
INFO - 2024-10-27 05:52:42 --> Helper loaded: html_helper
INFO - 2024-10-27 05:52:42 --> Helper loaded: file_helper
INFO - 2024-10-27 05:52:42 --> Helper loaded: string_helper
INFO - 2024-10-27 05:52:42 --> Helper loaded: form_helper
INFO - 2024-10-27 05:52:42 --> Helper loaded: my_helper
INFO - 2024-10-27 05:52:43 --> Database Driver Class Initialized
INFO - 2024-10-27 05:52:45 --> Upload Class Initialized
INFO - 2024-10-27 05:52:45 --> Email Class Initialized
INFO - 2024-10-27 05:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 05:52:45 --> Form Validation Class Initialized
INFO - 2024-10-27 05:52:45 --> Controller Class Initialized
INFO - 2024-10-27 11:22:45 --> Model "MainModel" initialized
INFO - 2024-10-27 11:22:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 11:22:45 --> Final output sent to browser
DEBUG - 2024-10-27 11:22:45 --> Total execution time: 3.6703
INFO - 2024-10-27 05:52:45 --> Config Class Initialized
INFO - 2024-10-27 05:52:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:46 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:46 --> URI Class Initialized
INFO - 2024-10-27 05:52:46 --> Router Class Initialized
INFO - 2024-10-27 05:52:46 --> Output Class Initialized
INFO - 2024-10-27 05:52:46 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:46 --> Input Class Initialized
INFO - 2024-10-27 05:52:46 --> Language Class Initialized
ERROR - 2024-10-27 05:52:46 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 05:52:46 --> Config Class Initialized
INFO - 2024-10-27 05:52:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:46 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:46 --> URI Class Initialized
INFO - 2024-10-27 05:52:46 --> Router Class Initialized
INFO - 2024-10-27 05:52:46 --> Output Class Initialized
INFO - 2024-10-27 05:52:46 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:46 --> Input Class Initialized
INFO - 2024-10-27 05:52:46 --> Language Class Initialized
ERROR - 2024-10-27 05:52:46 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 05:52:46 --> Config Class Initialized
INFO - 2024-10-27 05:52:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:46 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:46 --> URI Class Initialized
DEBUG - 2024-10-27 05:52:46 --> No URI present. Default controller set.
INFO - 2024-10-27 05:52:46 --> Router Class Initialized
INFO - 2024-10-27 05:52:46 --> Output Class Initialized
INFO - 2024-10-27 05:52:46 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:46 --> Input Class Initialized
INFO - 2024-10-27 05:52:46 --> Language Class Initialized
INFO - 2024-10-27 05:52:46 --> Loader Class Initialized
INFO - 2024-10-27 05:52:46 --> Helper loaded: url_helper
INFO - 2024-10-27 05:52:46 --> Helper loaded: html_helper
INFO - 2024-10-27 05:52:46 --> Helper loaded: file_helper
INFO - 2024-10-27 05:52:46 --> Helper loaded: string_helper
INFO - 2024-10-27 05:52:46 --> Helper loaded: form_helper
INFO - 2024-10-27 05:52:46 --> Helper loaded: my_helper
INFO - 2024-10-27 05:52:46 --> Database Driver Class Initialized
INFO - 2024-10-27 05:52:48 --> Upload Class Initialized
INFO - 2024-10-27 05:52:48 --> Email Class Initialized
INFO - 2024-10-27 05:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 05:52:48 --> Form Validation Class Initialized
INFO - 2024-10-27 05:52:48 --> Controller Class Initialized
INFO - 2024-10-27 11:22:48 --> Model "MainModel" initialized
INFO - 2024-10-27 11:22:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 11:22:48 --> Final output sent to browser
DEBUG - 2024-10-27 11:22:48 --> Total execution time: 2.1676
INFO - 2024-10-27 05:52:49 --> Config Class Initialized
INFO - 2024-10-27 05:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:49 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:49 --> URI Class Initialized
INFO - 2024-10-27 05:52:49 --> Router Class Initialized
INFO - 2024-10-27 05:52:49 --> Output Class Initialized
INFO - 2024-10-27 05:52:49 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:49 --> Input Class Initialized
INFO - 2024-10-27 05:52:49 --> Language Class Initialized
ERROR - 2024-10-27 05:52:49 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 05:52:49 --> Config Class Initialized
INFO - 2024-10-27 05:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:49 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:49 --> URI Class Initialized
INFO - 2024-10-27 05:52:49 --> Router Class Initialized
INFO - 2024-10-27 05:52:49 --> Output Class Initialized
INFO - 2024-10-27 05:52:49 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:49 --> Input Class Initialized
INFO - 2024-10-27 05:52:49 --> Language Class Initialized
ERROR - 2024-10-27 05:52:49 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 05:52:49 --> Config Class Initialized
INFO - 2024-10-27 05:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:49 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:49 --> URI Class Initialized
INFO - 2024-10-27 05:52:49 --> Router Class Initialized
INFO - 2024-10-27 05:52:49 --> Output Class Initialized
INFO - 2024-10-27 05:52:49 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:49 --> Input Class Initialized
INFO - 2024-10-27 05:52:49 --> Language Class Initialized
ERROR - 2024-10-27 05:52:49 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 05:52:49 --> Config Class Initialized
INFO - 2024-10-27 05:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:49 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:49 --> URI Class Initialized
INFO - 2024-10-27 05:52:49 --> Router Class Initialized
INFO - 2024-10-27 05:52:49 --> Output Class Initialized
INFO - 2024-10-27 05:52:49 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:49 --> Input Class Initialized
INFO - 2024-10-27 05:52:49 --> Language Class Initialized
ERROR - 2024-10-27 05:52:49 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 05:52:50 --> Config Class Initialized
INFO - 2024-10-27 05:52:50 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:50 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:50 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:50 --> URI Class Initialized
INFO - 2024-10-27 05:52:50 --> Router Class Initialized
INFO - 2024-10-27 05:52:50 --> Output Class Initialized
INFO - 2024-10-27 05:52:50 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:50 --> Input Class Initialized
INFO - 2024-10-27 05:52:50 --> Language Class Initialized
ERROR - 2024-10-27 05:52:50 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 05:52:50 --> Config Class Initialized
INFO - 2024-10-27 05:52:50 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:50 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:50 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:50 --> URI Class Initialized
INFO - 2024-10-27 05:52:50 --> Router Class Initialized
INFO - 2024-10-27 05:52:50 --> Output Class Initialized
INFO - 2024-10-27 05:52:50 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:50 --> Input Class Initialized
INFO - 2024-10-27 05:52:50 --> Language Class Initialized
ERROR - 2024-10-27 05:52:50 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 05:52:50 --> Config Class Initialized
INFO - 2024-10-27 05:52:50 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:50 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:50 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:50 --> URI Class Initialized
INFO - 2024-10-27 05:52:50 --> Router Class Initialized
INFO - 2024-10-27 05:52:50 --> Output Class Initialized
INFO - 2024-10-27 05:52:50 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:50 --> Input Class Initialized
INFO - 2024-10-27 05:52:50 --> Language Class Initialized
ERROR - 2024-10-27 05:52:50 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-27 05:52:51 --> Config Class Initialized
INFO - 2024-10-27 05:52:51 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:51 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:51 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:51 --> URI Class Initialized
INFO - 2024-10-27 05:52:51 --> Router Class Initialized
INFO - 2024-10-27 05:52:51 --> Output Class Initialized
INFO - 2024-10-27 05:52:51 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:51 --> Input Class Initialized
INFO - 2024-10-27 05:52:51 --> Language Class Initialized
ERROR - 2024-10-27 05:52:51 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 05:52:51 --> Config Class Initialized
INFO - 2024-10-27 05:52:51 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:51 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:51 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:51 --> URI Class Initialized
INFO - 2024-10-27 05:52:51 --> Router Class Initialized
INFO - 2024-10-27 05:52:51 --> Output Class Initialized
INFO - 2024-10-27 05:52:51 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:51 --> Input Class Initialized
INFO - 2024-10-27 05:52:51 --> Language Class Initialized
ERROR - 2024-10-27 05:52:51 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 05:52:51 --> Config Class Initialized
INFO - 2024-10-27 05:52:51 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:51 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:51 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:51 --> URI Class Initialized
INFO - 2024-10-27 05:52:51 --> Router Class Initialized
INFO - 2024-10-27 05:52:51 --> Output Class Initialized
INFO - 2024-10-27 05:52:51 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:51 --> Input Class Initialized
INFO - 2024-10-27 05:52:51 --> Language Class Initialized
ERROR - 2024-10-27 05:52:51 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 05:52:51 --> Config Class Initialized
INFO - 2024-10-27 05:52:51 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:51 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:51 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:51 --> URI Class Initialized
INFO - 2024-10-27 05:52:51 --> Router Class Initialized
INFO - 2024-10-27 05:52:51 --> Output Class Initialized
INFO - 2024-10-27 05:52:51 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:51 --> Input Class Initialized
INFO - 2024-10-27 05:52:51 --> Language Class Initialized
ERROR - 2024-10-27 05:52:51 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 05:52:52 --> Config Class Initialized
INFO - 2024-10-27 05:52:52 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:52 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:52 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:52 --> URI Class Initialized
INFO - 2024-10-27 05:52:52 --> Router Class Initialized
INFO - 2024-10-27 05:52:52 --> Output Class Initialized
INFO - 2024-10-27 05:52:52 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:52 --> Input Class Initialized
INFO - 2024-10-27 05:52:52 --> Language Class Initialized
ERROR - 2024-10-27 05:52:52 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-27 05:52:52 --> Config Class Initialized
INFO - 2024-10-27 05:52:52 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:52 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:52 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:52 --> URI Class Initialized
INFO - 2024-10-27 05:52:52 --> Router Class Initialized
INFO - 2024-10-27 05:52:52 --> Output Class Initialized
INFO - 2024-10-27 05:52:52 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:52 --> Input Class Initialized
INFO - 2024-10-27 05:52:52 --> Language Class Initialized
ERROR - 2024-10-27 05:52:52 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 05:52:52 --> Config Class Initialized
INFO - 2024-10-27 05:52:52 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:52 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:52 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:52 --> URI Class Initialized
INFO - 2024-10-27 05:52:52 --> Router Class Initialized
INFO - 2024-10-27 05:52:52 --> Output Class Initialized
INFO - 2024-10-27 05:52:52 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:52 --> Input Class Initialized
INFO - 2024-10-27 05:52:52 --> Language Class Initialized
ERROR - 2024-10-27 05:52:52 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 05:52:52 --> Config Class Initialized
INFO - 2024-10-27 05:52:52 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:53 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:53 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:53 --> URI Class Initialized
INFO - 2024-10-27 05:52:53 --> Router Class Initialized
INFO - 2024-10-27 05:52:53 --> Output Class Initialized
INFO - 2024-10-27 05:52:53 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:53 --> Input Class Initialized
INFO - 2024-10-27 05:52:53 --> Language Class Initialized
ERROR - 2024-10-27 05:52:53 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 05:52:53 --> Config Class Initialized
INFO - 2024-10-27 05:52:53 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:52:53 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:52:53 --> Utf8 Class Initialized
INFO - 2024-10-27 05:52:53 --> URI Class Initialized
INFO - 2024-10-27 05:52:53 --> Router Class Initialized
INFO - 2024-10-27 05:52:53 --> Output Class Initialized
INFO - 2024-10-27 05:52:53 --> Security Class Initialized
DEBUG - 2024-10-27 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:52:53 --> Input Class Initialized
INFO - 2024-10-27 05:52:53 --> Language Class Initialized
ERROR - 2024-10-27 05:52:53 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 07:40:18 --> Config Class Initialized
INFO - 2024-10-27 07:40:18 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:40:18 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:40:18 --> Utf8 Class Initialized
INFO - 2024-10-27 07:40:19 --> URI Class Initialized
DEBUG - 2024-10-27 07:40:19 --> No URI present. Default controller set.
INFO - 2024-10-27 07:40:19 --> Router Class Initialized
INFO - 2024-10-27 07:40:19 --> Output Class Initialized
INFO - 2024-10-27 07:40:19 --> Security Class Initialized
DEBUG - 2024-10-27 07:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:40:19 --> Input Class Initialized
INFO - 2024-10-27 07:40:19 --> Language Class Initialized
INFO - 2024-10-27 07:40:19 --> Loader Class Initialized
INFO - 2024-10-27 07:40:19 --> Helper loaded: url_helper
INFO - 2024-10-27 07:40:19 --> Helper loaded: html_helper
INFO - 2024-10-27 07:40:19 --> Helper loaded: file_helper
INFO - 2024-10-27 07:40:19 --> Helper loaded: string_helper
INFO - 2024-10-27 07:40:19 --> Helper loaded: form_helper
INFO - 2024-10-27 07:40:19 --> Helper loaded: my_helper
INFO - 2024-10-27 07:40:19 --> Database Driver Class Initialized
INFO - 2024-10-27 07:40:22 --> Upload Class Initialized
INFO - 2024-10-27 07:40:22 --> Email Class Initialized
INFO - 2024-10-27 07:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 07:40:23 --> Form Validation Class Initialized
INFO - 2024-10-27 07:40:23 --> Controller Class Initialized
INFO - 2024-10-27 13:10:24 --> Model "MainModel" initialized
INFO - 2024-10-27 13:10:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 13:10:24 --> Final output sent to browser
DEBUG - 2024-10-27 13:10:24 --> Total execution time: 5.9655
INFO - 2024-10-27 07:48:36 --> Config Class Initialized
INFO - 2024-10-27 07:48:36 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:36 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:36 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:37 --> URI Class Initialized
DEBUG - 2024-10-27 07:48:37 --> No URI present. Default controller set.
INFO - 2024-10-27 07:48:37 --> Router Class Initialized
INFO - 2024-10-27 07:48:37 --> Output Class Initialized
INFO - 2024-10-27 07:48:37 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:37 --> Input Class Initialized
INFO - 2024-10-27 07:48:37 --> Language Class Initialized
INFO - 2024-10-27 07:48:37 --> Loader Class Initialized
INFO - 2024-10-27 07:48:37 --> Helper loaded: url_helper
INFO - 2024-10-27 07:48:37 --> Helper loaded: html_helper
INFO - 2024-10-27 07:48:37 --> Helper loaded: file_helper
INFO - 2024-10-27 07:48:37 --> Helper loaded: string_helper
INFO - 2024-10-27 07:48:37 --> Helper loaded: form_helper
INFO - 2024-10-27 07:48:37 --> Helper loaded: my_helper
INFO - 2024-10-27 07:48:37 --> Database Driver Class Initialized
INFO - 2024-10-27 07:48:39 --> Upload Class Initialized
INFO - 2024-10-27 07:48:39 --> Email Class Initialized
INFO - 2024-10-27 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 07:48:39 --> Form Validation Class Initialized
INFO - 2024-10-27 07:48:39 --> Controller Class Initialized
INFO - 2024-10-27 13:18:39 --> Model "MainModel" initialized
INFO - 2024-10-27 13:18:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 13:18:39 --> Final output sent to browser
DEBUG - 2024-10-27 13:18:39 --> Total execution time: 2.2479
INFO - 2024-10-27 07:48:39 --> Config Class Initialized
INFO - 2024-10-27 07:48:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:39 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:39 --> URI Class Initialized
INFO - 2024-10-27 07:48:39 --> Router Class Initialized
INFO - 2024-10-27 07:48:39 --> Output Class Initialized
INFO - 2024-10-27 07:48:39 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:39 --> Input Class Initialized
INFO - 2024-10-27 07:48:39 --> Language Class Initialized
ERROR - 2024-10-27 07:48:39 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 07:48:39 --> Config Class Initialized
INFO - 2024-10-27 07:48:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:39 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:39 --> URI Class Initialized
INFO - 2024-10-27 07:48:39 --> Router Class Initialized
INFO - 2024-10-27 07:48:39 --> Output Class Initialized
INFO - 2024-10-27 07:48:39 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:39 --> Input Class Initialized
INFO - 2024-10-27 07:48:39 --> Language Class Initialized
ERROR - 2024-10-27 07:48:39 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 07:48:40 --> Config Class Initialized
INFO - 2024-10-27 07:48:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:40 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:40 --> URI Class Initialized
DEBUG - 2024-10-27 07:48:40 --> No URI present. Default controller set.
INFO - 2024-10-27 07:48:40 --> Router Class Initialized
INFO - 2024-10-27 07:48:40 --> Output Class Initialized
INFO - 2024-10-27 07:48:40 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:40 --> Input Class Initialized
INFO - 2024-10-27 07:48:40 --> Language Class Initialized
INFO - 2024-10-27 07:48:40 --> Loader Class Initialized
INFO - 2024-10-27 07:48:40 --> Helper loaded: url_helper
INFO - 2024-10-27 07:48:40 --> Helper loaded: html_helper
INFO - 2024-10-27 07:48:40 --> Helper loaded: file_helper
INFO - 2024-10-27 07:48:40 --> Helper loaded: string_helper
INFO - 2024-10-27 07:48:40 --> Helper loaded: form_helper
INFO - 2024-10-27 07:48:40 --> Helper loaded: my_helper
INFO - 2024-10-27 07:48:40 --> Database Driver Class Initialized
INFO - 2024-10-27 07:48:42 --> Upload Class Initialized
INFO - 2024-10-27 07:48:42 --> Email Class Initialized
INFO - 2024-10-27 07:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 07:48:42 --> Form Validation Class Initialized
INFO - 2024-10-27 07:48:42 --> Controller Class Initialized
INFO - 2024-10-27 13:18:42 --> Model "MainModel" initialized
INFO - 2024-10-27 13:18:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 13:18:42 --> Final output sent to browser
DEBUG - 2024-10-27 13:18:42 --> Total execution time: 2.1374
INFO - 2024-10-27 07:48:42 --> Config Class Initialized
INFO - 2024-10-27 07:48:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:42 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:42 --> URI Class Initialized
INFO - 2024-10-27 07:48:42 --> Router Class Initialized
INFO - 2024-10-27 07:48:42 --> Output Class Initialized
INFO - 2024-10-27 07:48:42 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:42 --> Input Class Initialized
INFO - 2024-10-27 07:48:42 --> Language Class Initialized
ERROR - 2024-10-27 07:48:42 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 07:48:42 --> Config Class Initialized
INFO - 2024-10-27 07:48:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:42 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:42 --> URI Class Initialized
INFO - 2024-10-27 07:48:42 --> Router Class Initialized
INFO - 2024-10-27 07:48:42 --> Output Class Initialized
INFO - 2024-10-27 07:48:42 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:42 --> Input Class Initialized
INFO - 2024-10-27 07:48:42 --> Language Class Initialized
ERROR - 2024-10-27 07:48:42 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 07:48:43 --> Config Class Initialized
INFO - 2024-10-27 07:48:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:43 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:43 --> URI Class Initialized
INFO - 2024-10-27 07:48:43 --> Router Class Initialized
INFO - 2024-10-27 07:48:43 --> Output Class Initialized
INFO - 2024-10-27 07:48:43 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:43 --> Input Class Initialized
INFO - 2024-10-27 07:48:43 --> Language Class Initialized
ERROR - 2024-10-27 07:48:43 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 07:48:43 --> Config Class Initialized
INFO - 2024-10-27 07:48:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:43 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:43 --> URI Class Initialized
INFO - 2024-10-27 07:48:43 --> Router Class Initialized
INFO - 2024-10-27 07:48:43 --> Output Class Initialized
INFO - 2024-10-27 07:48:43 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:43 --> Input Class Initialized
INFO - 2024-10-27 07:48:43 --> Language Class Initialized
ERROR - 2024-10-27 07:48:43 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 07:48:43 --> Config Class Initialized
INFO - 2024-10-27 07:48:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:43 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:43 --> URI Class Initialized
INFO - 2024-10-27 07:48:43 --> Router Class Initialized
INFO - 2024-10-27 07:48:43 --> Output Class Initialized
INFO - 2024-10-27 07:48:43 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:43 --> Input Class Initialized
INFO - 2024-10-27 07:48:43 --> Language Class Initialized
ERROR - 2024-10-27 07:48:43 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 07:48:44 --> Config Class Initialized
INFO - 2024-10-27 07:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:44 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:44 --> URI Class Initialized
INFO - 2024-10-27 07:48:44 --> Router Class Initialized
INFO - 2024-10-27 07:48:44 --> Output Class Initialized
INFO - 2024-10-27 07:48:44 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:44 --> Input Class Initialized
INFO - 2024-10-27 07:48:44 --> Language Class Initialized
ERROR - 2024-10-27 07:48:44 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 07:48:44 --> Config Class Initialized
INFO - 2024-10-27 07:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:44 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:44 --> URI Class Initialized
INFO - 2024-10-27 07:48:44 --> Router Class Initialized
INFO - 2024-10-27 07:48:44 --> Output Class Initialized
INFO - 2024-10-27 07:48:44 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:44 --> Input Class Initialized
INFO - 2024-10-27 07:48:44 --> Language Class Initialized
ERROR - 2024-10-27 07:48:44 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-27 07:48:44 --> Config Class Initialized
INFO - 2024-10-27 07:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:44 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:44 --> URI Class Initialized
INFO - 2024-10-27 07:48:44 --> Router Class Initialized
INFO - 2024-10-27 07:48:44 --> Output Class Initialized
INFO - 2024-10-27 07:48:44 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:44 --> Input Class Initialized
INFO - 2024-10-27 07:48:44 --> Language Class Initialized
ERROR - 2024-10-27 07:48:44 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 07:48:44 --> Config Class Initialized
INFO - 2024-10-27 07:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:44 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:44 --> URI Class Initialized
INFO - 2024-10-27 07:48:44 --> Router Class Initialized
INFO - 2024-10-27 07:48:44 --> Output Class Initialized
INFO - 2024-10-27 07:48:44 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:44 --> Input Class Initialized
INFO - 2024-10-27 07:48:44 --> Language Class Initialized
ERROR - 2024-10-27 07:48:44 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 07:48:45 --> Config Class Initialized
INFO - 2024-10-27 07:48:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:45 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:45 --> URI Class Initialized
INFO - 2024-10-27 07:48:45 --> Router Class Initialized
INFO - 2024-10-27 07:48:45 --> Output Class Initialized
INFO - 2024-10-27 07:48:45 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:45 --> Input Class Initialized
INFO - 2024-10-27 07:48:45 --> Language Class Initialized
ERROR - 2024-10-27 07:48:45 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 07:48:45 --> Config Class Initialized
INFO - 2024-10-27 07:48:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:45 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:45 --> URI Class Initialized
INFO - 2024-10-27 07:48:45 --> Router Class Initialized
INFO - 2024-10-27 07:48:45 --> Output Class Initialized
INFO - 2024-10-27 07:48:45 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:45 --> Input Class Initialized
INFO - 2024-10-27 07:48:45 --> Language Class Initialized
ERROR - 2024-10-27 07:48:45 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 07:48:45 --> Config Class Initialized
INFO - 2024-10-27 07:48:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:45 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:45 --> URI Class Initialized
INFO - 2024-10-27 07:48:45 --> Router Class Initialized
INFO - 2024-10-27 07:48:45 --> Output Class Initialized
INFO - 2024-10-27 07:48:45 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:45 --> Input Class Initialized
INFO - 2024-10-27 07:48:45 --> Language Class Initialized
ERROR - 2024-10-27 07:48:45 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-27 07:48:46 --> Config Class Initialized
INFO - 2024-10-27 07:48:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:46 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:46 --> URI Class Initialized
INFO - 2024-10-27 07:48:46 --> Router Class Initialized
INFO - 2024-10-27 07:48:46 --> Output Class Initialized
INFO - 2024-10-27 07:48:46 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:46 --> Input Class Initialized
INFO - 2024-10-27 07:48:46 --> Language Class Initialized
ERROR - 2024-10-27 07:48:46 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 07:48:46 --> Config Class Initialized
INFO - 2024-10-27 07:48:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:46 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:46 --> URI Class Initialized
INFO - 2024-10-27 07:48:46 --> Router Class Initialized
INFO - 2024-10-27 07:48:46 --> Output Class Initialized
INFO - 2024-10-27 07:48:46 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:46 --> Input Class Initialized
INFO - 2024-10-27 07:48:46 --> Language Class Initialized
ERROR - 2024-10-27 07:48:46 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 07:48:46 --> Config Class Initialized
INFO - 2024-10-27 07:48:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:46 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:46 --> URI Class Initialized
INFO - 2024-10-27 07:48:46 --> Router Class Initialized
INFO - 2024-10-27 07:48:46 --> Output Class Initialized
INFO - 2024-10-27 07:48:46 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:46 --> Input Class Initialized
INFO - 2024-10-27 07:48:46 --> Language Class Initialized
ERROR - 2024-10-27 07:48:46 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 07:48:46 --> Config Class Initialized
INFO - 2024-10-27 07:48:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:48:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:48:46 --> Utf8 Class Initialized
INFO - 2024-10-27 07:48:46 --> URI Class Initialized
INFO - 2024-10-27 07:48:46 --> Router Class Initialized
INFO - 2024-10-27 07:48:46 --> Output Class Initialized
INFO - 2024-10-27 07:48:46 --> Security Class Initialized
DEBUG - 2024-10-27 07:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:48:46 --> Input Class Initialized
INFO - 2024-10-27 07:48:46 --> Language Class Initialized
ERROR - 2024-10-27 07:48:46 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 08:06:31 --> Config Class Initialized
INFO - 2024-10-27 08:06:31 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:31 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:31 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:31 --> URI Class Initialized
DEBUG - 2024-10-27 08:06:32 --> No URI present. Default controller set.
INFO - 2024-10-27 08:06:32 --> Router Class Initialized
INFO - 2024-10-27 08:06:32 --> Output Class Initialized
INFO - 2024-10-27 08:06:32 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:32 --> Input Class Initialized
INFO - 2024-10-27 08:06:32 --> Language Class Initialized
INFO - 2024-10-27 08:06:32 --> Loader Class Initialized
INFO - 2024-10-27 08:06:32 --> Helper loaded: url_helper
INFO - 2024-10-27 08:06:32 --> Helper loaded: html_helper
INFO - 2024-10-27 08:06:32 --> Helper loaded: file_helper
INFO - 2024-10-27 08:06:32 --> Helper loaded: string_helper
INFO - 2024-10-27 08:06:32 --> Helper loaded: form_helper
INFO - 2024-10-27 08:06:32 --> Helper loaded: my_helper
INFO - 2024-10-27 08:06:32 --> Database Driver Class Initialized
INFO - 2024-10-27 08:06:34 --> Upload Class Initialized
INFO - 2024-10-27 08:06:34 --> Email Class Initialized
INFO - 2024-10-27 08:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:06:34 --> Form Validation Class Initialized
INFO - 2024-10-27 08:06:34 --> Controller Class Initialized
INFO - 2024-10-27 13:36:34 --> Model "MainModel" initialized
INFO - 2024-10-27 13:36:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 13:36:34 --> Final output sent to browser
DEBUG - 2024-10-27 13:36:34 --> Total execution time: 2.9314
INFO - 2024-10-27 08:06:34 --> Config Class Initialized
INFO - 2024-10-27 08:06:34 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:34 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:34 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:34 --> URI Class Initialized
INFO - 2024-10-27 08:06:34 --> Router Class Initialized
INFO - 2024-10-27 08:06:34 --> Output Class Initialized
INFO - 2024-10-27 08:06:34 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:34 --> Input Class Initialized
INFO - 2024-10-27 08:06:34 --> Language Class Initialized
ERROR - 2024-10-27 08:06:34 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 08:06:35 --> Config Class Initialized
INFO - 2024-10-27 08:06:35 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:35 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:35 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:35 --> URI Class Initialized
INFO - 2024-10-27 08:06:35 --> Router Class Initialized
INFO - 2024-10-27 08:06:35 --> Output Class Initialized
INFO - 2024-10-27 08:06:35 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:35 --> Input Class Initialized
INFO - 2024-10-27 08:06:35 --> Language Class Initialized
ERROR - 2024-10-27 08:06:35 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 08:06:35 --> Config Class Initialized
INFO - 2024-10-27 08:06:35 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:35 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:35 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:35 --> URI Class Initialized
DEBUG - 2024-10-27 08:06:35 --> No URI present. Default controller set.
INFO - 2024-10-27 08:06:35 --> Router Class Initialized
INFO - 2024-10-27 08:06:35 --> Output Class Initialized
INFO - 2024-10-27 08:06:35 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:35 --> Input Class Initialized
INFO - 2024-10-27 08:06:35 --> Language Class Initialized
INFO - 2024-10-27 08:06:35 --> Loader Class Initialized
INFO - 2024-10-27 08:06:35 --> Helper loaded: url_helper
INFO - 2024-10-27 08:06:35 --> Helper loaded: html_helper
INFO - 2024-10-27 08:06:35 --> Helper loaded: file_helper
INFO - 2024-10-27 08:06:35 --> Helper loaded: string_helper
INFO - 2024-10-27 08:06:35 --> Helper loaded: form_helper
INFO - 2024-10-27 08:06:35 --> Helper loaded: my_helper
INFO - 2024-10-27 08:06:35 --> Database Driver Class Initialized
INFO - 2024-10-27 08:06:37 --> Upload Class Initialized
INFO - 2024-10-27 08:06:37 --> Email Class Initialized
INFO - 2024-10-27 08:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:06:37 --> Form Validation Class Initialized
INFO - 2024-10-27 08:06:37 --> Controller Class Initialized
INFO - 2024-10-27 13:36:37 --> Model "MainModel" initialized
INFO - 2024-10-27 13:36:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 13:36:37 --> Final output sent to browser
DEBUG - 2024-10-27 13:36:37 --> Total execution time: 2.1921
INFO - 2024-10-27 08:06:37 --> Config Class Initialized
INFO - 2024-10-27 08:06:37 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:37 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:37 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:37 --> URI Class Initialized
INFO - 2024-10-27 08:06:37 --> Router Class Initialized
INFO - 2024-10-27 08:06:37 --> Output Class Initialized
INFO - 2024-10-27 08:06:37 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:37 --> Input Class Initialized
INFO - 2024-10-27 08:06:37 --> Language Class Initialized
ERROR - 2024-10-27 08:06:37 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 08:06:38 --> Config Class Initialized
INFO - 2024-10-27 08:06:38 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:38 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:38 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:38 --> URI Class Initialized
INFO - 2024-10-27 08:06:38 --> Router Class Initialized
INFO - 2024-10-27 08:06:38 --> Output Class Initialized
INFO - 2024-10-27 08:06:38 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:38 --> Input Class Initialized
INFO - 2024-10-27 08:06:38 --> Language Class Initialized
ERROR - 2024-10-27 08:06:38 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 08:06:38 --> Config Class Initialized
INFO - 2024-10-27 08:06:38 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:38 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:38 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:38 --> URI Class Initialized
INFO - 2024-10-27 08:06:38 --> Router Class Initialized
INFO - 2024-10-27 08:06:38 --> Output Class Initialized
INFO - 2024-10-27 08:06:38 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:38 --> Input Class Initialized
INFO - 2024-10-27 08:06:38 --> Language Class Initialized
ERROR - 2024-10-27 08:06:38 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 08:06:38 --> Config Class Initialized
INFO - 2024-10-27 08:06:38 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:38 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:38 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:38 --> URI Class Initialized
INFO - 2024-10-27 08:06:38 --> Router Class Initialized
INFO - 2024-10-27 08:06:38 --> Output Class Initialized
INFO - 2024-10-27 08:06:38 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:38 --> Input Class Initialized
INFO - 2024-10-27 08:06:38 --> Language Class Initialized
ERROR - 2024-10-27 08:06:38 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 08:06:39 --> Config Class Initialized
INFO - 2024-10-27 08:06:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:39 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:39 --> URI Class Initialized
INFO - 2024-10-27 08:06:39 --> Router Class Initialized
INFO - 2024-10-27 08:06:39 --> Output Class Initialized
INFO - 2024-10-27 08:06:39 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:39 --> Input Class Initialized
INFO - 2024-10-27 08:06:39 --> Language Class Initialized
ERROR - 2024-10-27 08:06:39 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 08:06:39 --> Config Class Initialized
INFO - 2024-10-27 08:06:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:39 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:39 --> URI Class Initialized
INFO - 2024-10-27 08:06:39 --> Router Class Initialized
INFO - 2024-10-27 08:06:39 --> Output Class Initialized
INFO - 2024-10-27 08:06:39 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:39 --> Input Class Initialized
INFO - 2024-10-27 08:06:39 --> Language Class Initialized
ERROR - 2024-10-27 08:06:39 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 08:06:39 --> Config Class Initialized
INFO - 2024-10-27 08:06:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:39 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:39 --> URI Class Initialized
INFO - 2024-10-27 08:06:39 --> Router Class Initialized
INFO - 2024-10-27 08:06:39 --> Output Class Initialized
INFO - 2024-10-27 08:06:39 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:39 --> Input Class Initialized
INFO - 2024-10-27 08:06:39 --> Language Class Initialized
ERROR - 2024-10-27 08:06:39 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-27 08:06:39 --> Config Class Initialized
INFO - 2024-10-27 08:06:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:39 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:39 --> URI Class Initialized
INFO - 2024-10-27 08:06:39 --> Router Class Initialized
INFO - 2024-10-27 08:06:39 --> Output Class Initialized
INFO - 2024-10-27 08:06:39 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:39 --> Input Class Initialized
INFO - 2024-10-27 08:06:39 --> Language Class Initialized
ERROR - 2024-10-27 08:06:39 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 08:06:40 --> Config Class Initialized
INFO - 2024-10-27 08:06:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:40 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:40 --> URI Class Initialized
INFO - 2024-10-27 08:06:40 --> Router Class Initialized
INFO - 2024-10-27 08:06:40 --> Output Class Initialized
INFO - 2024-10-27 08:06:40 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:40 --> Input Class Initialized
INFO - 2024-10-27 08:06:40 --> Language Class Initialized
ERROR - 2024-10-27 08:06:40 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 08:06:40 --> Config Class Initialized
INFO - 2024-10-27 08:06:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:40 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:40 --> URI Class Initialized
INFO - 2024-10-27 08:06:40 --> Router Class Initialized
INFO - 2024-10-27 08:06:40 --> Output Class Initialized
INFO - 2024-10-27 08:06:40 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:40 --> Input Class Initialized
INFO - 2024-10-27 08:06:40 --> Language Class Initialized
ERROR - 2024-10-27 08:06:40 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 08:06:40 --> Config Class Initialized
INFO - 2024-10-27 08:06:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:40 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:40 --> URI Class Initialized
INFO - 2024-10-27 08:06:40 --> Router Class Initialized
INFO - 2024-10-27 08:06:40 --> Output Class Initialized
INFO - 2024-10-27 08:06:40 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:40 --> Input Class Initialized
INFO - 2024-10-27 08:06:40 --> Language Class Initialized
ERROR - 2024-10-27 08:06:40 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 08:06:41 --> Config Class Initialized
INFO - 2024-10-27 08:06:41 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:41 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:41 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:41 --> URI Class Initialized
INFO - 2024-10-27 08:06:41 --> Router Class Initialized
INFO - 2024-10-27 08:06:41 --> Output Class Initialized
INFO - 2024-10-27 08:06:41 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:41 --> Input Class Initialized
INFO - 2024-10-27 08:06:41 --> Language Class Initialized
ERROR - 2024-10-27 08:06:41 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-27 08:06:41 --> Config Class Initialized
INFO - 2024-10-27 08:06:41 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:41 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:41 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:41 --> URI Class Initialized
INFO - 2024-10-27 08:06:41 --> Router Class Initialized
INFO - 2024-10-27 08:06:41 --> Output Class Initialized
INFO - 2024-10-27 08:06:41 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:41 --> Input Class Initialized
INFO - 2024-10-27 08:06:41 --> Language Class Initialized
ERROR - 2024-10-27 08:06:41 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 08:06:41 --> Config Class Initialized
INFO - 2024-10-27 08:06:41 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:41 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:41 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:41 --> URI Class Initialized
INFO - 2024-10-27 08:06:41 --> Router Class Initialized
INFO - 2024-10-27 08:06:41 --> Output Class Initialized
INFO - 2024-10-27 08:06:41 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:41 --> Input Class Initialized
INFO - 2024-10-27 08:06:41 --> Language Class Initialized
ERROR - 2024-10-27 08:06:41 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 08:06:42 --> Config Class Initialized
INFO - 2024-10-27 08:06:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:42 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:42 --> URI Class Initialized
INFO - 2024-10-27 08:06:42 --> Router Class Initialized
INFO - 2024-10-27 08:06:42 --> Output Class Initialized
INFO - 2024-10-27 08:06:42 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:42 --> Input Class Initialized
INFO - 2024-10-27 08:06:42 --> Language Class Initialized
ERROR - 2024-10-27 08:06:42 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 08:06:42 --> Config Class Initialized
INFO - 2024-10-27 08:06:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:06:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:06:42 --> Utf8 Class Initialized
INFO - 2024-10-27 08:06:42 --> URI Class Initialized
INFO - 2024-10-27 08:06:42 --> Router Class Initialized
INFO - 2024-10-27 08:06:42 --> Output Class Initialized
INFO - 2024-10-27 08:06:42 --> Security Class Initialized
DEBUG - 2024-10-27 08:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:06:42 --> Input Class Initialized
INFO - 2024-10-27 08:06:42 --> Language Class Initialized
ERROR - 2024-10-27 08:06:42 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 09:06:51 --> Config Class Initialized
INFO - 2024-10-27 09:06:51 --> Hooks Class Initialized
DEBUG - 2024-10-27 09:06:51 --> UTF-8 Support Enabled
INFO - 2024-10-27 09:06:51 --> Utf8 Class Initialized
INFO - 2024-10-27 09:06:51 --> URI Class Initialized
DEBUG - 2024-10-27 09:06:51 --> No URI present. Default controller set.
INFO - 2024-10-27 09:06:51 --> Router Class Initialized
INFO - 2024-10-27 09:06:51 --> Output Class Initialized
INFO - 2024-10-27 09:06:51 --> Security Class Initialized
DEBUG - 2024-10-27 09:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 09:06:51 --> Input Class Initialized
INFO - 2024-10-27 09:06:51 --> Language Class Initialized
INFO - 2024-10-27 09:06:51 --> Loader Class Initialized
INFO - 2024-10-27 09:06:51 --> Helper loaded: url_helper
INFO - 2024-10-27 09:06:51 --> Helper loaded: html_helper
INFO - 2024-10-27 09:06:51 --> Helper loaded: file_helper
INFO - 2024-10-27 09:06:51 --> Helper loaded: string_helper
INFO - 2024-10-27 09:06:51 --> Helper loaded: form_helper
INFO - 2024-10-27 09:06:51 --> Helper loaded: my_helper
INFO - 2024-10-27 09:06:51 --> Database Driver Class Initialized
INFO - 2024-10-27 09:06:53 --> Upload Class Initialized
INFO - 2024-10-27 09:06:53 --> Email Class Initialized
INFO - 2024-10-27 09:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 09:06:53 --> Form Validation Class Initialized
INFO - 2024-10-27 09:06:53 --> Controller Class Initialized
INFO - 2024-10-27 14:36:54 --> Model "MainModel" initialized
INFO - 2024-10-27 14:36:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 14:36:54 --> Final output sent to browser
DEBUG - 2024-10-27 14:36:54 --> Total execution time: 3.0942
INFO - 2024-10-27 10:06:53 --> Config Class Initialized
INFO - 2024-10-27 10:06:53 --> Hooks Class Initialized
DEBUG - 2024-10-27 10:06:53 --> UTF-8 Support Enabled
INFO - 2024-10-27 10:06:53 --> Utf8 Class Initialized
INFO - 2024-10-27 10:06:53 --> URI Class Initialized
DEBUG - 2024-10-27 10:06:53 --> No URI present. Default controller set.
INFO - 2024-10-27 10:06:53 --> Router Class Initialized
INFO - 2024-10-27 10:06:53 --> Output Class Initialized
INFO - 2024-10-27 10:06:53 --> Security Class Initialized
DEBUG - 2024-10-27 10:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 10:06:53 --> Input Class Initialized
INFO - 2024-10-27 10:06:53 --> Language Class Initialized
INFO - 2024-10-27 10:06:53 --> Loader Class Initialized
INFO - 2024-10-27 10:06:53 --> Helper loaded: url_helper
INFO - 2024-10-27 10:06:53 --> Helper loaded: html_helper
INFO - 2024-10-27 10:06:53 --> Helper loaded: file_helper
INFO - 2024-10-27 10:06:53 --> Helper loaded: string_helper
INFO - 2024-10-27 10:06:53 --> Helper loaded: form_helper
INFO - 2024-10-27 10:06:53 --> Helper loaded: my_helper
INFO - 2024-10-27 10:06:53 --> Database Driver Class Initialized
INFO - 2024-10-27 10:06:55 --> Upload Class Initialized
INFO - 2024-10-27 10:06:55 --> Email Class Initialized
INFO - 2024-10-27 10:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 10:06:56 --> Form Validation Class Initialized
INFO - 2024-10-27 10:06:56 --> Controller Class Initialized
INFO - 2024-10-27 15:36:56 --> Model "MainModel" initialized
INFO - 2024-10-27 15:36:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 15:36:56 --> Final output sent to browser
DEBUG - 2024-10-27 15:36:56 --> Total execution time: 2.8157
INFO - 2024-10-27 12:38:39 --> Config Class Initialized
INFO - 2024-10-27 12:38:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:39 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:39 --> URI Class Initialized
DEBUG - 2024-10-27 12:38:39 --> No URI present. Default controller set.
INFO - 2024-10-27 12:38:39 --> Router Class Initialized
INFO - 2024-10-27 12:38:39 --> Output Class Initialized
INFO - 2024-10-27 12:38:39 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:39 --> Input Class Initialized
INFO - 2024-10-27 12:38:39 --> Language Class Initialized
INFO - 2024-10-27 12:38:39 --> Loader Class Initialized
INFO - 2024-10-27 12:38:39 --> Helper loaded: url_helper
INFO - 2024-10-27 12:38:39 --> Helper loaded: html_helper
INFO - 2024-10-27 12:38:39 --> Helper loaded: file_helper
INFO - 2024-10-27 12:38:39 --> Helper loaded: string_helper
INFO - 2024-10-27 12:38:39 --> Helper loaded: form_helper
INFO - 2024-10-27 12:38:39 --> Helper loaded: my_helper
INFO - 2024-10-27 12:38:39 --> Database Driver Class Initialized
INFO - 2024-10-27 12:38:41 --> Upload Class Initialized
INFO - 2024-10-27 12:38:41 --> Email Class Initialized
INFO - 2024-10-27 12:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:38:41 --> Form Validation Class Initialized
INFO - 2024-10-27 12:38:41 --> Controller Class Initialized
INFO - 2024-10-27 18:08:41 --> Model "MainModel" initialized
INFO - 2024-10-27 18:08:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 18:08:41 --> Final output sent to browser
DEBUG - 2024-10-27 18:08:41 --> Total execution time: 2.3963
INFO - 2024-10-27 12:38:41 --> Config Class Initialized
INFO - 2024-10-27 12:38:41 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:41 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:42 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:42 --> URI Class Initialized
INFO - 2024-10-27 12:38:42 --> Router Class Initialized
INFO - 2024-10-27 12:38:42 --> Output Class Initialized
INFO - 2024-10-27 12:38:42 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:42 --> Input Class Initialized
INFO - 2024-10-27 12:38:42 --> Language Class Initialized
ERROR - 2024-10-27 12:38:42 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 12:38:42 --> Config Class Initialized
INFO - 2024-10-27 12:38:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:42 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:42 --> URI Class Initialized
INFO - 2024-10-27 12:38:42 --> Router Class Initialized
INFO - 2024-10-27 12:38:42 --> Output Class Initialized
INFO - 2024-10-27 12:38:42 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:42 --> Input Class Initialized
INFO - 2024-10-27 12:38:42 --> Language Class Initialized
ERROR - 2024-10-27 12:38:42 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 12:38:42 --> Config Class Initialized
INFO - 2024-10-27 12:38:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:42 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:42 --> URI Class Initialized
DEBUG - 2024-10-27 12:38:42 --> No URI present. Default controller set.
INFO - 2024-10-27 12:38:42 --> Router Class Initialized
INFO - 2024-10-27 12:38:43 --> Output Class Initialized
INFO - 2024-10-27 12:38:43 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:43 --> Input Class Initialized
INFO - 2024-10-27 12:38:43 --> Language Class Initialized
INFO - 2024-10-27 12:38:43 --> Loader Class Initialized
INFO - 2024-10-27 12:38:43 --> Helper loaded: url_helper
INFO - 2024-10-27 12:38:43 --> Helper loaded: html_helper
INFO - 2024-10-27 12:38:43 --> Helper loaded: file_helper
INFO - 2024-10-27 12:38:43 --> Helper loaded: string_helper
INFO - 2024-10-27 12:38:43 --> Helper loaded: form_helper
INFO - 2024-10-27 12:38:43 --> Helper loaded: my_helper
INFO - 2024-10-27 12:38:43 --> Database Driver Class Initialized
INFO - 2024-10-27 12:38:45 --> Upload Class Initialized
INFO - 2024-10-27 12:38:45 --> Email Class Initialized
INFO - 2024-10-27 12:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:38:45 --> Form Validation Class Initialized
INFO - 2024-10-27 12:38:45 --> Controller Class Initialized
INFO - 2024-10-27 18:08:45 --> Model "MainModel" initialized
INFO - 2024-10-27 18:08:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 18:08:45 --> Final output sent to browser
DEBUG - 2024-10-27 18:08:45 --> Total execution time: 2.2396
INFO - 2024-10-27 12:38:45 --> Config Class Initialized
INFO - 2024-10-27 12:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:45 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:45 --> URI Class Initialized
INFO - 2024-10-27 12:38:45 --> Router Class Initialized
INFO - 2024-10-27 12:38:45 --> Output Class Initialized
INFO - 2024-10-27 12:38:45 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:45 --> Input Class Initialized
INFO - 2024-10-27 12:38:45 --> Language Class Initialized
ERROR - 2024-10-27 12:38:45 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 12:38:45 --> Config Class Initialized
INFO - 2024-10-27 12:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:45 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:45 --> URI Class Initialized
INFO - 2024-10-27 12:38:45 --> Router Class Initialized
INFO - 2024-10-27 12:38:45 --> Output Class Initialized
INFO - 2024-10-27 12:38:45 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:45 --> Input Class Initialized
INFO - 2024-10-27 12:38:45 --> Language Class Initialized
ERROR - 2024-10-27 12:38:45 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 12:38:46 --> Config Class Initialized
INFO - 2024-10-27 12:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:46 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:46 --> URI Class Initialized
INFO - 2024-10-27 12:38:46 --> Router Class Initialized
INFO - 2024-10-27 12:38:46 --> Output Class Initialized
INFO - 2024-10-27 12:38:46 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:46 --> Input Class Initialized
INFO - 2024-10-27 12:38:46 --> Language Class Initialized
ERROR - 2024-10-27 12:38:46 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 12:38:46 --> Config Class Initialized
INFO - 2024-10-27 12:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:46 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:46 --> URI Class Initialized
INFO - 2024-10-27 12:38:46 --> Router Class Initialized
INFO - 2024-10-27 12:38:46 --> Output Class Initialized
INFO - 2024-10-27 12:38:46 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:46 --> Input Class Initialized
INFO - 2024-10-27 12:38:46 --> Language Class Initialized
ERROR - 2024-10-27 12:38:46 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 12:38:46 --> Config Class Initialized
INFO - 2024-10-27 12:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:46 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:46 --> URI Class Initialized
INFO - 2024-10-27 12:38:46 --> Router Class Initialized
INFO - 2024-10-27 12:38:46 --> Output Class Initialized
INFO - 2024-10-27 12:38:46 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:46 --> Input Class Initialized
INFO - 2024-10-27 12:38:46 --> Language Class Initialized
ERROR - 2024-10-27 12:38:46 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 12:38:46 --> Config Class Initialized
INFO - 2024-10-27 12:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:46 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:46 --> URI Class Initialized
INFO - 2024-10-27 12:38:46 --> Router Class Initialized
INFO - 2024-10-27 12:38:46 --> Output Class Initialized
INFO - 2024-10-27 12:38:47 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:47 --> Input Class Initialized
INFO - 2024-10-27 12:38:47 --> Language Class Initialized
ERROR - 2024-10-27 12:38:47 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 12:38:47 --> Config Class Initialized
INFO - 2024-10-27 12:38:47 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:47 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:47 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:47 --> URI Class Initialized
INFO - 2024-10-27 12:38:47 --> Router Class Initialized
INFO - 2024-10-27 12:38:47 --> Output Class Initialized
INFO - 2024-10-27 12:38:47 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:47 --> Input Class Initialized
INFO - 2024-10-27 12:38:47 --> Language Class Initialized
ERROR - 2024-10-27 12:38:47 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-10-27 12:38:47 --> Config Class Initialized
INFO - 2024-10-27 12:38:47 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:47 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:47 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:47 --> URI Class Initialized
INFO - 2024-10-27 12:38:47 --> Router Class Initialized
INFO - 2024-10-27 12:38:47 --> Output Class Initialized
INFO - 2024-10-27 12:38:47 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:47 --> Input Class Initialized
INFO - 2024-10-27 12:38:47 --> Language Class Initialized
ERROR - 2024-10-27 12:38:47 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 12:38:47 --> Config Class Initialized
INFO - 2024-10-27 12:38:47 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:47 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:47 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:47 --> URI Class Initialized
INFO - 2024-10-27 12:38:47 --> Router Class Initialized
INFO - 2024-10-27 12:38:47 --> Output Class Initialized
INFO - 2024-10-27 12:38:47 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:47 --> Input Class Initialized
INFO - 2024-10-27 12:38:48 --> Language Class Initialized
ERROR - 2024-10-27 12:38:48 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 12:38:48 --> Config Class Initialized
INFO - 2024-10-27 12:38:48 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:48 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:48 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:48 --> URI Class Initialized
INFO - 2024-10-27 12:38:48 --> Router Class Initialized
INFO - 2024-10-27 12:38:48 --> Output Class Initialized
INFO - 2024-10-27 12:38:48 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:48 --> Input Class Initialized
INFO - 2024-10-27 12:38:48 --> Language Class Initialized
ERROR - 2024-10-27 12:38:48 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 12:38:48 --> Config Class Initialized
INFO - 2024-10-27 12:38:48 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:48 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:48 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:48 --> URI Class Initialized
INFO - 2024-10-27 12:38:48 --> Router Class Initialized
INFO - 2024-10-27 12:38:48 --> Output Class Initialized
INFO - 2024-10-27 12:38:48 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:48 --> Input Class Initialized
INFO - 2024-10-27 12:38:48 --> Language Class Initialized
ERROR - 2024-10-27 12:38:48 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 12:38:48 --> Config Class Initialized
INFO - 2024-10-27 12:38:48 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:48 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:48 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:48 --> URI Class Initialized
INFO - 2024-10-27 12:38:48 --> Router Class Initialized
INFO - 2024-10-27 12:38:48 --> Output Class Initialized
INFO - 2024-10-27 12:38:48 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:48 --> Input Class Initialized
INFO - 2024-10-27 12:38:48 --> Language Class Initialized
ERROR - 2024-10-27 12:38:48 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 12:38:49 --> Config Class Initialized
INFO - 2024-10-27 12:38:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:49 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:49 --> URI Class Initialized
INFO - 2024-10-27 12:38:49 --> Router Class Initialized
INFO - 2024-10-27 12:38:49 --> Output Class Initialized
INFO - 2024-10-27 12:38:49 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:49 --> Input Class Initialized
INFO - 2024-10-27 12:38:49 --> Language Class Initialized
ERROR - 2024-10-27 12:38:49 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 12:38:49 --> Config Class Initialized
INFO - 2024-10-27 12:38:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:49 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:49 --> URI Class Initialized
INFO - 2024-10-27 12:38:49 --> Router Class Initialized
INFO - 2024-10-27 12:38:49 --> Output Class Initialized
INFO - 2024-10-27 12:38:49 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:49 --> Input Class Initialized
INFO - 2024-10-27 12:38:49 --> Language Class Initialized
ERROR - 2024-10-27 12:38:49 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 12:38:49 --> Config Class Initialized
INFO - 2024-10-27 12:38:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:38:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:38:49 --> Utf8 Class Initialized
INFO - 2024-10-27 12:38:49 --> URI Class Initialized
INFO - 2024-10-27 12:38:49 --> Router Class Initialized
INFO - 2024-10-27 12:38:49 --> Output Class Initialized
INFO - 2024-10-27 12:38:49 --> Security Class Initialized
DEBUG - 2024-10-27 12:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:38:49 --> Input Class Initialized
INFO - 2024-10-27 12:38:49 --> Language Class Initialized
ERROR - 2024-10-27 12:38:49 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 15:23:24 --> Config Class Initialized
INFO - 2024-10-27 15:23:24 --> Hooks Class Initialized
DEBUG - 2024-10-27 15:23:24 --> UTF-8 Support Enabled
INFO - 2024-10-27 15:23:24 --> Utf8 Class Initialized
INFO - 2024-10-27 15:23:24 --> URI Class Initialized
DEBUG - 2024-10-27 15:23:24 --> No URI present. Default controller set.
INFO - 2024-10-27 15:23:24 --> Router Class Initialized
INFO - 2024-10-27 15:23:24 --> Output Class Initialized
INFO - 2024-10-27 15:23:24 --> Security Class Initialized
DEBUG - 2024-10-27 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 15:23:24 --> Input Class Initialized
INFO - 2024-10-27 15:23:24 --> Language Class Initialized
INFO - 2024-10-27 15:23:24 --> Loader Class Initialized
INFO - 2024-10-27 15:23:24 --> Helper loaded: url_helper
INFO - 2024-10-27 15:23:24 --> Helper loaded: html_helper
INFO - 2024-10-27 15:23:24 --> Helper loaded: file_helper
INFO - 2024-10-27 15:23:24 --> Helper loaded: string_helper
INFO - 2024-10-27 15:23:24 --> Helper loaded: form_helper
INFO - 2024-10-27 15:23:24 --> Helper loaded: my_helper
INFO - 2024-10-27 15:23:24 --> Database Driver Class Initialized
INFO - 2024-10-27 15:23:26 --> Upload Class Initialized
INFO - 2024-10-27 15:23:26 --> Email Class Initialized
INFO - 2024-10-27 15:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 15:23:26 --> Form Validation Class Initialized
INFO - 2024-10-27 15:23:26 --> Controller Class Initialized
INFO - 2024-10-27 20:53:26 --> Model "MainModel" initialized
INFO - 2024-10-27 20:53:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 20:53:26 --> Final output sent to browser
DEBUG - 2024-10-27 20:53:26 --> Total execution time: 2.3176
INFO - 2024-10-27 16:37:04 --> Config Class Initialized
INFO - 2024-10-27 16:37:04 --> Hooks Class Initialized
DEBUG - 2024-10-27 16:37:04 --> UTF-8 Support Enabled
INFO - 2024-10-27 16:37:04 --> Utf8 Class Initialized
INFO - 2024-10-27 16:37:04 --> URI Class Initialized
DEBUG - 2024-10-27 16:37:04 --> No URI present. Default controller set.
INFO - 2024-10-27 16:37:04 --> Router Class Initialized
INFO - 2024-10-27 16:37:04 --> Output Class Initialized
INFO - 2024-10-27 16:37:04 --> Security Class Initialized
DEBUG - 2024-10-27 16:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 16:37:04 --> Input Class Initialized
INFO - 2024-10-27 16:37:04 --> Language Class Initialized
INFO - 2024-10-27 16:37:04 --> Loader Class Initialized
INFO - 2024-10-27 16:37:04 --> Helper loaded: url_helper
INFO - 2024-10-27 16:37:04 --> Helper loaded: html_helper
INFO - 2024-10-27 16:37:04 --> Helper loaded: file_helper
INFO - 2024-10-27 16:37:04 --> Helper loaded: string_helper
INFO - 2024-10-27 16:37:04 --> Helper loaded: form_helper
INFO - 2024-10-27 16:37:04 --> Helper loaded: my_helper
INFO - 2024-10-27 16:37:04 --> Database Driver Class Initialized
ERROR - 2024-10-27 16:37:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions C:\inetpub\vhosts\livservice.in\httpdocs\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-27 16:37:06 --> Unable to connect to the database
INFO - 2024-10-27 16:37:06 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-27 16:37:52 --> Config Class Initialized
INFO - 2024-10-27 16:37:52 --> Hooks Class Initialized
DEBUG - 2024-10-27 16:37:52 --> UTF-8 Support Enabled
INFO - 2024-10-27 16:37:52 --> Utf8 Class Initialized
INFO - 2024-10-27 16:37:52 --> URI Class Initialized
DEBUG - 2024-10-27 16:37:52 --> No URI present. Default controller set.
INFO - 2024-10-27 16:37:52 --> Router Class Initialized
INFO - 2024-10-27 16:37:52 --> Output Class Initialized
INFO - 2024-10-27 16:37:52 --> Security Class Initialized
DEBUG - 2024-10-27 16:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 16:37:52 --> Input Class Initialized
INFO - 2024-10-27 16:37:52 --> Language Class Initialized
INFO - 2024-10-27 16:37:52 --> Loader Class Initialized
INFO - 2024-10-27 16:37:52 --> Helper loaded: url_helper
INFO - 2024-10-27 16:37:52 --> Helper loaded: html_helper
INFO - 2024-10-27 16:37:52 --> Helper loaded: file_helper
INFO - 2024-10-27 16:37:52 --> Helper loaded: string_helper
INFO - 2024-10-27 16:37:52 --> Helper loaded: form_helper
INFO - 2024-10-27 16:37:52 --> Helper loaded: my_helper
INFO - 2024-10-27 16:37:52 --> Database Driver Class Initialized
ERROR - 2024-10-27 16:37:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions C:\inetpub\vhosts\livservice.in\httpdocs\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-27 16:37:54 --> Unable to connect to the database
INFO - 2024-10-27 16:37:54 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-27 18:01:37 --> Config Class Initialized
INFO - 2024-10-27 18:01:37 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:37 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:37 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:37 --> URI Class Initialized
DEBUG - 2024-10-27 18:01:37 --> No URI present. Default controller set.
INFO - 2024-10-27 18:01:37 --> Router Class Initialized
INFO - 2024-10-27 18:01:37 --> Output Class Initialized
INFO - 2024-10-27 18:01:37 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:37 --> Input Class Initialized
INFO - 2024-10-27 18:01:37 --> Language Class Initialized
INFO - 2024-10-27 18:01:37 --> Loader Class Initialized
INFO - 2024-10-27 18:01:37 --> Helper loaded: url_helper
INFO - 2024-10-27 18:01:37 --> Helper loaded: html_helper
INFO - 2024-10-27 18:01:37 --> Helper loaded: file_helper
INFO - 2024-10-27 18:01:37 --> Helper loaded: string_helper
INFO - 2024-10-27 18:01:37 --> Helper loaded: form_helper
INFO - 2024-10-27 18:01:37 --> Helper loaded: my_helper
INFO - 2024-10-27 18:01:37 --> Database Driver Class Initialized
INFO - 2024-10-27 18:01:39 --> Upload Class Initialized
INFO - 2024-10-27 18:01:39 --> Email Class Initialized
INFO - 2024-10-27 18:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 18:01:39 --> Form Validation Class Initialized
INFO - 2024-10-27 18:01:39 --> Controller Class Initialized
INFO - 2024-10-27 23:31:39 --> Model "MainModel" initialized
INFO - 2024-10-27 23:31:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 23:31:39 --> Final output sent to browser
DEBUG - 2024-10-27 23:31:39 --> Total execution time: 2.2128
INFO - 2024-10-27 18:01:40 --> Config Class Initialized
INFO - 2024-10-27 18:01:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:40 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:40 --> URI Class Initialized
INFO - 2024-10-27 18:01:40 --> Router Class Initialized
INFO - 2024-10-27 18:01:40 --> Output Class Initialized
INFO - 2024-10-27 18:01:40 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:40 --> Input Class Initialized
INFO - 2024-10-27 18:01:40 --> Language Class Initialized
ERROR - 2024-10-27 18:01:40 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 18:01:40 --> Config Class Initialized
INFO - 2024-10-27 18:01:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:40 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:40 --> URI Class Initialized
INFO - 2024-10-27 18:01:40 --> Router Class Initialized
INFO - 2024-10-27 18:01:40 --> Output Class Initialized
INFO - 2024-10-27 18:01:40 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:40 --> Input Class Initialized
INFO - 2024-10-27 18:01:40 --> Language Class Initialized
ERROR - 2024-10-27 18:01:40 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 18:01:40 --> Config Class Initialized
INFO - 2024-10-27 18:01:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:40 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:40 --> URI Class Initialized
DEBUG - 2024-10-27 18:01:40 --> No URI present. Default controller set.
INFO - 2024-10-27 18:01:40 --> Router Class Initialized
INFO - 2024-10-27 18:01:40 --> Output Class Initialized
INFO - 2024-10-27 18:01:40 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:40 --> Input Class Initialized
INFO - 2024-10-27 18:01:40 --> Language Class Initialized
INFO - 2024-10-27 18:01:40 --> Loader Class Initialized
INFO - 2024-10-27 18:01:40 --> Helper loaded: url_helper
INFO - 2024-10-27 18:01:40 --> Helper loaded: html_helper
INFO - 2024-10-27 18:01:40 --> Helper loaded: file_helper
INFO - 2024-10-27 18:01:40 --> Helper loaded: string_helper
INFO - 2024-10-27 18:01:40 --> Helper loaded: form_helper
INFO - 2024-10-27 18:01:40 --> Helper loaded: my_helper
INFO - 2024-10-27 18:01:40 --> Database Driver Class Initialized
INFO - 2024-10-27 18:01:42 --> Upload Class Initialized
INFO - 2024-10-27 18:01:42 --> Email Class Initialized
INFO - 2024-10-27 18:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 18:01:42 --> Form Validation Class Initialized
INFO - 2024-10-27 18:01:42 --> Controller Class Initialized
INFO - 2024-10-27 23:31:42 --> Model "MainModel" initialized
INFO - 2024-10-27 23:31:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-27 23:31:42 --> Final output sent to browser
DEBUG - 2024-10-27 23:31:42 --> Total execution time: 2.1189
INFO - 2024-10-27 18:01:43 --> Config Class Initialized
INFO - 2024-10-27 18:01:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:43 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:43 --> URI Class Initialized
INFO - 2024-10-27 18:01:43 --> Router Class Initialized
INFO - 2024-10-27 18:01:43 --> Output Class Initialized
INFO - 2024-10-27 18:01:43 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:43 --> Input Class Initialized
INFO - 2024-10-27 18:01:43 --> Language Class Initialized
ERROR - 2024-10-27 18:01:43 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 18:01:43 --> Config Class Initialized
INFO - 2024-10-27 18:01:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:43 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:43 --> URI Class Initialized
INFO - 2024-10-27 18:01:43 --> Router Class Initialized
INFO - 2024-10-27 18:01:43 --> Output Class Initialized
INFO - 2024-10-27 18:01:43 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:43 --> Input Class Initialized
INFO - 2024-10-27 18:01:43 --> Language Class Initialized
ERROR - 2024-10-27 18:01:43 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 18:01:43 --> Config Class Initialized
INFO - 2024-10-27 18:01:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:43 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:43 --> URI Class Initialized
INFO - 2024-10-27 18:01:43 --> Router Class Initialized
INFO - 2024-10-27 18:01:43 --> Output Class Initialized
INFO - 2024-10-27 18:01:43 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:43 --> Input Class Initialized
INFO - 2024-10-27 18:01:43 --> Language Class Initialized
ERROR - 2024-10-27 18:01:43 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 18:01:43 --> Config Class Initialized
INFO - 2024-10-27 18:01:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:43 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:43 --> URI Class Initialized
INFO - 2024-10-27 18:01:43 --> Router Class Initialized
INFO - 2024-10-27 18:01:43 --> Output Class Initialized
INFO - 2024-10-27 18:01:43 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:43 --> Input Class Initialized
INFO - 2024-10-27 18:01:43 --> Language Class Initialized
ERROR - 2024-10-27 18:01:43 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 18:01:44 --> Config Class Initialized
INFO - 2024-10-27 18:01:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:44 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:44 --> URI Class Initialized
INFO - 2024-10-27 18:01:44 --> Router Class Initialized
INFO - 2024-10-27 18:01:44 --> Output Class Initialized
INFO - 2024-10-27 18:01:44 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:44 --> Input Class Initialized
INFO - 2024-10-27 18:01:44 --> Language Class Initialized
ERROR - 2024-10-27 18:01:44 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 18:01:44 --> Config Class Initialized
INFO - 2024-10-27 18:01:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:44 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:44 --> URI Class Initialized
INFO - 2024-10-27 18:01:44 --> Router Class Initialized
INFO - 2024-10-27 18:01:44 --> Output Class Initialized
INFO - 2024-10-27 18:01:44 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:44 --> Input Class Initialized
INFO - 2024-10-27 18:01:44 --> Language Class Initialized
ERROR - 2024-10-27 18:01:44 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 18:01:44 --> Config Class Initialized
INFO - 2024-10-27 18:01:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:44 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:44 --> URI Class Initialized
INFO - 2024-10-27 18:01:44 --> Router Class Initialized
INFO - 2024-10-27 18:01:44 --> Output Class Initialized
INFO - 2024-10-27 18:01:44 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:44 --> Input Class Initialized
INFO - 2024-10-27 18:01:44 --> Language Class Initialized
ERROR - 2024-10-27 18:01:44 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-27 18:01:45 --> Config Class Initialized
INFO - 2024-10-27 18:01:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:45 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:45 --> URI Class Initialized
INFO - 2024-10-27 18:01:45 --> Router Class Initialized
INFO - 2024-10-27 18:01:45 --> Output Class Initialized
INFO - 2024-10-27 18:01:45 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:45 --> Input Class Initialized
INFO - 2024-10-27 18:01:45 --> Language Class Initialized
ERROR - 2024-10-27 18:01:45 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 18:01:45 --> Config Class Initialized
INFO - 2024-10-27 18:01:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:45 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:45 --> URI Class Initialized
INFO - 2024-10-27 18:01:45 --> Router Class Initialized
INFO - 2024-10-27 18:01:45 --> Output Class Initialized
INFO - 2024-10-27 18:01:45 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:45 --> Input Class Initialized
INFO - 2024-10-27 18:01:45 --> Language Class Initialized
ERROR - 2024-10-27 18:01:45 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 18:01:45 --> Config Class Initialized
INFO - 2024-10-27 18:01:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:45 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:45 --> URI Class Initialized
INFO - 2024-10-27 18:01:45 --> Router Class Initialized
INFO - 2024-10-27 18:01:45 --> Output Class Initialized
INFO - 2024-10-27 18:01:45 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:45 --> Input Class Initialized
INFO - 2024-10-27 18:01:45 --> Language Class Initialized
ERROR - 2024-10-27 18:01:45 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 18:01:46 --> Config Class Initialized
INFO - 2024-10-27 18:01:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:46 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:46 --> URI Class Initialized
INFO - 2024-10-27 18:01:46 --> Router Class Initialized
INFO - 2024-10-27 18:01:46 --> Output Class Initialized
INFO - 2024-10-27 18:01:46 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:46 --> Input Class Initialized
INFO - 2024-10-27 18:01:46 --> Language Class Initialized
ERROR - 2024-10-27 18:01:46 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 18:01:46 --> Config Class Initialized
INFO - 2024-10-27 18:01:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:46 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:46 --> URI Class Initialized
INFO - 2024-10-27 18:01:46 --> Router Class Initialized
INFO - 2024-10-27 18:01:46 --> Output Class Initialized
INFO - 2024-10-27 18:01:46 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:46 --> Input Class Initialized
INFO - 2024-10-27 18:01:46 --> Language Class Initialized
ERROR - 2024-10-27 18:01:46 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-27 18:01:46 --> Config Class Initialized
INFO - 2024-10-27 18:01:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:46 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:46 --> URI Class Initialized
INFO - 2024-10-27 18:01:46 --> Router Class Initialized
INFO - 2024-10-27 18:01:46 --> Output Class Initialized
INFO - 2024-10-27 18:01:46 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:46 --> Input Class Initialized
INFO - 2024-10-27 18:01:46 --> Language Class Initialized
ERROR - 2024-10-27 18:01:46 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 18:01:47 --> Config Class Initialized
INFO - 2024-10-27 18:01:47 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:47 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:47 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:47 --> URI Class Initialized
INFO - 2024-10-27 18:01:47 --> Router Class Initialized
INFO - 2024-10-27 18:01:47 --> Output Class Initialized
INFO - 2024-10-27 18:01:47 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:47 --> Input Class Initialized
INFO - 2024-10-27 18:01:47 --> Language Class Initialized
ERROR - 2024-10-27 18:01:47 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 18:01:47 --> Config Class Initialized
INFO - 2024-10-27 18:01:47 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:47 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:47 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:47 --> URI Class Initialized
INFO - 2024-10-27 18:01:47 --> Router Class Initialized
INFO - 2024-10-27 18:01:47 --> Output Class Initialized
INFO - 2024-10-27 18:01:47 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:47 --> Input Class Initialized
INFO - 2024-10-27 18:01:47 --> Language Class Initialized
ERROR - 2024-10-27 18:01:47 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 18:01:47 --> Config Class Initialized
INFO - 2024-10-27 18:01:47 --> Hooks Class Initialized
DEBUG - 2024-10-27 18:01:47 --> UTF-8 Support Enabled
INFO - 2024-10-27 18:01:47 --> Utf8 Class Initialized
INFO - 2024-10-27 18:01:47 --> URI Class Initialized
INFO - 2024-10-27 18:01:47 --> Router Class Initialized
INFO - 2024-10-27 18:01:47 --> Output Class Initialized
INFO - 2024-10-27 18:01:47 --> Security Class Initialized
DEBUG - 2024-10-27 18:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 18:01:47 --> Input Class Initialized
INFO - 2024-10-27 18:01:47 --> Language Class Initialized
ERROR - 2024-10-27 18:01:47 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 20:37:04 --> Config Class Initialized
INFO - 2024-10-27 20:37:04 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:04 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:04 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:04 --> URI Class Initialized
DEBUG - 2024-10-27 20:37:04 --> No URI present. Default controller set.
INFO - 2024-10-27 20:37:04 --> Router Class Initialized
INFO - 2024-10-27 20:37:04 --> Output Class Initialized
INFO - 2024-10-27 20:37:04 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:04 --> Input Class Initialized
INFO - 2024-10-27 20:37:04 --> Language Class Initialized
INFO - 2024-10-27 20:37:04 --> Loader Class Initialized
INFO - 2024-10-27 20:37:04 --> Helper loaded: url_helper
INFO - 2024-10-27 20:37:04 --> Helper loaded: html_helper
INFO - 2024-10-27 20:37:05 --> Helper loaded: file_helper
INFO - 2024-10-27 20:37:05 --> Helper loaded: string_helper
INFO - 2024-10-27 20:37:05 --> Helper loaded: form_helper
INFO - 2024-10-27 20:37:05 --> Helper loaded: my_helper
INFO - 2024-10-27 20:37:05 --> Database Driver Class Initialized
INFO - 2024-10-27 20:37:07 --> Upload Class Initialized
INFO - 2024-10-27 20:37:07 --> Email Class Initialized
INFO - 2024-10-27 20:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 20:37:07 --> Form Validation Class Initialized
INFO - 2024-10-27 20:37:07 --> Controller Class Initialized
INFO - 2024-10-27 20:37:07 --> Config Class Initialized
INFO - 2024-10-27 20:37:07 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:07 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:07 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:07 --> URI Class Initialized
INFO - 2024-10-27 20:37:07 --> Router Class Initialized
INFO - 2024-10-27 20:37:07 --> Output Class Initialized
INFO - 2024-10-27 20:37:07 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:07 --> Input Class Initialized
INFO - 2024-10-27 20:37:07 --> Language Class Initialized
ERROR - 2024-10-27 20:37:07 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 20:37:07 --> Config Class Initialized
INFO - 2024-10-27 20:37:07 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:07 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:07 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:07 --> URI Class Initialized
INFO - 2024-10-27 20:37:07 --> Router Class Initialized
INFO - 2024-10-27 20:37:07 --> Output Class Initialized
INFO - 2024-10-27 20:37:07 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:07 --> Input Class Initialized
INFO - 2024-10-27 20:37:07 --> Language Class Initialized
ERROR - 2024-10-27 20:37:07 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 20:37:08 --> Config Class Initialized
INFO - 2024-10-27 20:37:08 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:08 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:08 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:08 --> URI Class Initialized
DEBUG - 2024-10-27 20:37:08 --> No URI present. Default controller set.
INFO - 2024-10-27 20:37:08 --> Router Class Initialized
INFO - 2024-10-27 20:37:08 --> Output Class Initialized
INFO - 2024-10-27 20:37:08 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:08 --> Input Class Initialized
INFO - 2024-10-27 20:37:08 --> Language Class Initialized
INFO - 2024-10-27 20:37:08 --> Loader Class Initialized
INFO - 2024-10-27 20:37:08 --> Helper loaded: url_helper
INFO - 2024-10-27 20:37:08 --> Helper loaded: html_helper
INFO - 2024-10-27 20:37:08 --> Helper loaded: file_helper
INFO - 2024-10-27 20:37:08 --> Helper loaded: string_helper
INFO - 2024-10-27 20:37:08 --> Helper loaded: form_helper
INFO - 2024-10-27 20:37:08 --> Helper loaded: my_helper
INFO - 2024-10-27 20:37:08 --> Database Driver Class Initialized
INFO - 2024-10-27 20:37:10 --> Upload Class Initialized
INFO - 2024-10-27 20:37:10 --> Email Class Initialized
INFO - 2024-10-27 20:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 20:37:10 --> Form Validation Class Initialized
INFO - 2024-10-27 20:37:10 --> Controller Class Initialized
INFO - 2024-10-27 20:37:10 --> Config Class Initialized
INFO - 2024-10-27 20:37:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:10 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:10 --> URI Class Initialized
INFO - 2024-10-27 20:37:10 --> Router Class Initialized
INFO - 2024-10-27 20:37:10 --> Output Class Initialized
INFO - 2024-10-27 20:37:10 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:10 --> Input Class Initialized
INFO - 2024-10-27 20:37:10 --> Language Class Initialized
ERROR - 2024-10-27 20:37:10 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 20:37:10 --> Config Class Initialized
INFO - 2024-10-27 20:37:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:11 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:11 --> URI Class Initialized
INFO - 2024-10-27 20:37:11 --> Router Class Initialized
INFO - 2024-10-27 20:37:11 --> Output Class Initialized
INFO - 2024-10-27 20:37:11 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:11 --> Input Class Initialized
INFO - 2024-10-27 20:37:11 --> Language Class Initialized
ERROR - 2024-10-27 20:37:11 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 20:37:11 --> Config Class Initialized
INFO - 2024-10-27 20:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:11 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:11 --> URI Class Initialized
INFO - 2024-10-27 20:37:11 --> Router Class Initialized
INFO - 2024-10-27 20:37:11 --> Output Class Initialized
INFO - 2024-10-27 20:37:11 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:11 --> Input Class Initialized
INFO - 2024-10-27 20:37:11 --> Language Class Initialized
ERROR - 2024-10-27 20:37:11 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 20:37:11 --> Config Class Initialized
INFO - 2024-10-27 20:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:11 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:11 --> URI Class Initialized
INFO - 2024-10-27 20:37:11 --> Router Class Initialized
INFO - 2024-10-27 20:37:11 --> Output Class Initialized
INFO - 2024-10-27 20:37:11 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:11 --> Input Class Initialized
INFO - 2024-10-27 20:37:11 --> Language Class Initialized
ERROR - 2024-10-27 20:37:11 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 20:37:11 --> Config Class Initialized
INFO - 2024-10-27 20:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:11 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:11 --> URI Class Initialized
INFO - 2024-10-27 20:37:11 --> Router Class Initialized
INFO - 2024-10-27 20:37:11 --> Output Class Initialized
INFO - 2024-10-27 20:37:11 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:11 --> Input Class Initialized
INFO - 2024-10-27 20:37:11 --> Language Class Initialized
ERROR - 2024-10-27 20:37:11 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 20:37:12 --> Config Class Initialized
INFO - 2024-10-27 20:37:12 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:12 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:12 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:12 --> URI Class Initialized
INFO - 2024-10-27 20:37:12 --> Router Class Initialized
INFO - 2024-10-27 20:37:12 --> Output Class Initialized
INFO - 2024-10-27 20:37:12 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:12 --> Input Class Initialized
INFO - 2024-10-27 20:37:12 --> Language Class Initialized
ERROR - 2024-10-27 20:37:12 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 20:37:12 --> Config Class Initialized
INFO - 2024-10-27 20:37:12 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:12 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:12 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:12 --> URI Class Initialized
INFO - 2024-10-27 20:37:12 --> Router Class Initialized
INFO - 2024-10-27 20:37:12 --> Output Class Initialized
INFO - 2024-10-27 20:37:12 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:12 --> Input Class Initialized
INFO - 2024-10-27 20:37:12 --> Language Class Initialized
ERROR - 2024-10-27 20:37:12 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-27 20:37:12 --> Config Class Initialized
INFO - 2024-10-27 20:37:12 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:12 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:12 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:12 --> URI Class Initialized
INFO - 2024-10-27 20:37:12 --> Router Class Initialized
INFO - 2024-10-27 20:37:12 --> Output Class Initialized
INFO - 2024-10-27 20:37:12 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:12 --> Input Class Initialized
INFO - 2024-10-27 20:37:12 --> Language Class Initialized
ERROR - 2024-10-27 20:37:12 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 20:37:13 --> Config Class Initialized
INFO - 2024-10-27 20:37:13 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:13 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:13 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:13 --> URI Class Initialized
INFO - 2024-10-27 20:37:13 --> Router Class Initialized
INFO - 2024-10-27 20:37:13 --> Output Class Initialized
INFO - 2024-10-27 20:37:13 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:13 --> Input Class Initialized
INFO - 2024-10-27 20:37:13 --> Language Class Initialized
ERROR - 2024-10-27 20:37:13 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 20:37:13 --> Config Class Initialized
INFO - 2024-10-27 20:37:13 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:13 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:13 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:13 --> URI Class Initialized
INFO - 2024-10-27 20:37:13 --> Router Class Initialized
INFO - 2024-10-27 20:37:13 --> Output Class Initialized
INFO - 2024-10-27 20:37:13 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:13 --> Input Class Initialized
INFO - 2024-10-27 20:37:13 --> Language Class Initialized
ERROR - 2024-10-27 20:37:13 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 20:37:13 --> Config Class Initialized
INFO - 2024-10-27 20:37:13 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:13 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:13 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:13 --> URI Class Initialized
INFO - 2024-10-27 20:37:13 --> Router Class Initialized
INFO - 2024-10-27 20:37:13 --> Output Class Initialized
INFO - 2024-10-27 20:37:13 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:13 --> Input Class Initialized
INFO - 2024-10-27 20:37:13 --> Language Class Initialized
ERROR - 2024-10-27 20:37:13 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 20:37:13 --> Config Class Initialized
INFO - 2024-10-27 20:37:13 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:13 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:13 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:13 --> URI Class Initialized
INFO - 2024-10-27 20:37:13 --> Router Class Initialized
INFO - 2024-10-27 20:37:13 --> Output Class Initialized
INFO - 2024-10-27 20:37:13 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:13 --> Input Class Initialized
INFO - 2024-10-27 20:37:13 --> Language Class Initialized
ERROR - 2024-10-27 20:37:13 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-27 20:37:14 --> Config Class Initialized
INFO - 2024-10-27 20:37:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:14 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:14 --> URI Class Initialized
INFO - 2024-10-27 20:37:14 --> Router Class Initialized
INFO - 2024-10-27 20:37:14 --> Output Class Initialized
INFO - 2024-10-27 20:37:14 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:14 --> Input Class Initialized
INFO - 2024-10-27 20:37:14 --> Language Class Initialized
ERROR - 2024-10-27 20:37:14 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 20:37:14 --> Config Class Initialized
INFO - 2024-10-27 20:37:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:14 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:14 --> URI Class Initialized
INFO - 2024-10-27 20:37:14 --> Router Class Initialized
INFO - 2024-10-27 20:37:14 --> Output Class Initialized
INFO - 2024-10-27 20:37:14 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:14 --> Input Class Initialized
INFO - 2024-10-27 20:37:14 --> Language Class Initialized
ERROR - 2024-10-27 20:37:14 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 20:37:14 --> Config Class Initialized
INFO - 2024-10-27 20:37:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:14 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:14 --> URI Class Initialized
INFO - 2024-10-27 20:37:14 --> Router Class Initialized
INFO - 2024-10-27 20:37:14 --> Output Class Initialized
INFO - 2024-10-27 20:37:14 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:14 --> Input Class Initialized
INFO - 2024-10-27 20:37:14 --> Language Class Initialized
ERROR - 2024-10-27 20:37:14 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 20:37:15 --> Config Class Initialized
INFO - 2024-10-27 20:37:15 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:37:15 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:37:15 --> Utf8 Class Initialized
INFO - 2024-10-27 20:37:15 --> URI Class Initialized
INFO - 2024-10-27 20:37:15 --> Router Class Initialized
INFO - 2024-10-27 20:37:15 --> Output Class Initialized
INFO - 2024-10-27 20:37:15 --> Security Class Initialized
DEBUG - 2024-10-27 20:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:37:15 --> Input Class Initialized
INFO - 2024-10-27 20:37:15 --> Language Class Initialized
ERROR - 2024-10-27 20:37:15 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 20:45:18 --> Config Class Initialized
INFO - 2024-10-27 20:45:18 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:18 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:18 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:18 --> URI Class Initialized
DEBUG - 2024-10-27 20:45:18 --> No URI present. Default controller set.
INFO - 2024-10-27 20:45:18 --> Router Class Initialized
INFO - 2024-10-27 20:45:18 --> Output Class Initialized
INFO - 2024-10-27 20:45:18 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:18 --> Input Class Initialized
INFO - 2024-10-27 20:45:18 --> Language Class Initialized
INFO - 2024-10-27 20:45:18 --> Loader Class Initialized
INFO - 2024-10-27 20:45:18 --> Helper loaded: url_helper
INFO - 2024-10-27 20:45:18 --> Helper loaded: html_helper
INFO - 2024-10-27 20:45:18 --> Helper loaded: file_helper
INFO - 2024-10-27 20:45:18 --> Helper loaded: string_helper
INFO - 2024-10-27 20:45:18 --> Helper loaded: form_helper
INFO - 2024-10-27 20:45:18 --> Helper loaded: my_helper
INFO - 2024-10-27 20:45:18 --> Database Driver Class Initialized
INFO - 2024-10-27 20:45:20 --> Upload Class Initialized
INFO - 2024-10-27 20:45:20 --> Email Class Initialized
INFO - 2024-10-27 20:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 20:45:20 --> Form Validation Class Initialized
INFO - 2024-10-27 20:45:20 --> Controller Class Initialized
INFO - 2024-10-27 20:45:20 --> Config Class Initialized
INFO - 2024-10-27 20:45:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:20 --> URI Class Initialized
INFO - 2024-10-27 20:45:20 --> Router Class Initialized
INFO - 2024-10-27 20:45:20 --> Output Class Initialized
INFO - 2024-10-27 20:45:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:20 --> Input Class Initialized
INFO - 2024-10-27 20:45:20 --> Language Class Initialized
ERROR - 2024-10-27 20:45:20 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 20:45:20 --> Config Class Initialized
INFO - 2024-10-27 20:45:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:20 --> URI Class Initialized
INFO - 2024-10-27 20:45:20 --> Router Class Initialized
INFO - 2024-10-27 20:45:20 --> Output Class Initialized
INFO - 2024-10-27 20:45:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:21 --> Input Class Initialized
INFO - 2024-10-27 20:45:21 --> Language Class Initialized
ERROR - 2024-10-27 20:45:21 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 20:45:21 --> Config Class Initialized
INFO - 2024-10-27 20:45:21 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:21 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:21 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:21 --> URI Class Initialized
DEBUG - 2024-10-27 20:45:21 --> No URI present. Default controller set.
INFO - 2024-10-27 20:45:21 --> Router Class Initialized
INFO - 2024-10-27 20:45:21 --> Output Class Initialized
INFO - 2024-10-27 20:45:21 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:21 --> Input Class Initialized
INFO - 2024-10-27 20:45:21 --> Language Class Initialized
INFO - 2024-10-27 20:45:21 --> Loader Class Initialized
INFO - 2024-10-27 20:45:21 --> Helper loaded: url_helper
INFO - 2024-10-27 20:45:21 --> Helper loaded: html_helper
INFO - 2024-10-27 20:45:21 --> Helper loaded: file_helper
INFO - 2024-10-27 20:45:21 --> Helper loaded: string_helper
INFO - 2024-10-27 20:45:21 --> Helper loaded: form_helper
INFO - 2024-10-27 20:45:21 --> Helper loaded: my_helper
INFO - 2024-10-27 20:45:21 --> Database Driver Class Initialized
INFO - 2024-10-27 20:45:23 --> Upload Class Initialized
INFO - 2024-10-27 20:45:23 --> Email Class Initialized
INFO - 2024-10-27 20:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 20:45:23 --> Form Validation Class Initialized
INFO - 2024-10-27 20:45:23 --> Controller Class Initialized
INFO - 2024-10-27 20:45:23 --> Config Class Initialized
INFO - 2024-10-27 20:45:23 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:23 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:23 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:23 --> URI Class Initialized
INFO - 2024-10-27 20:45:23 --> Router Class Initialized
INFO - 2024-10-27 20:45:23 --> Output Class Initialized
INFO - 2024-10-27 20:45:23 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:23 --> Input Class Initialized
INFO - 2024-10-27 20:45:23 --> Language Class Initialized
ERROR - 2024-10-27 20:45:23 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 20:45:23 --> Config Class Initialized
INFO - 2024-10-27 20:45:23 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:23 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:24 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:24 --> URI Class Initialized
INFO - 2024-10-27 20:45:24 --> Router Class Initialized
INFO - 2024-10-27 20:45:24 --> Output Class Initialized
INFO - 2024-10-27 20:45:24 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:24 --> Input Class Initialized
INFO - 2024-10-27 20:45:24 --> Language Class Initialized
ERROR - 2024-10-27 20:45:24 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 20:45:24 --> Config Class Initialized
INFO - 2024-10-27 20:45:24 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:24 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:24 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:24 --> URI Class Initialized
INFO - 2024-10-27 20:45:24 --> Router Class Initialized
INFO - 2024-10-27 20:45:24 --> Output Class Initialized
INFO - 2024-10-27 20:45:24 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:24 --> Input Class Initialized
INFO - 2024-10-27 20:45:24 --> Language Class Initialized
ERROR - 2024-10-27 20:45:24 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 20:45:24 --> Config Class Initialized
INFO - 2024-10-27 20:45:24 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:24 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:24 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:24 --> URI Class Initialized
INFO - 2024-10-27 20:45:24 --> Router Class Initialized
INFO - 2024-10-27 20:45:24 --> Output Class Initialized
INFO - 2024-10-27 20:45:24 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:24 --> Input Class Initialized
INFO - 2024-10-27 20:45:24 --> Language Class Initialized
ERROR - 2024-10-27 20:45:24 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 20:45:24 --> Config Class Initialized
INFO - 2024-10-27 20:45:24 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:24 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:24 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:24 --> URI Class Initialized
INFO - 2024-10-27 20:45:24 --> Router Class Initialized
INFO - 2024-10-27 20:45:24 --> Output Class Initialized
INFO - 2024-10-27 20:45:24 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:24 --> Input Class Initialized
INFO - 2024-10-27 20:45:24 --> Language Class Initialized
ERROR - 2024-10-27 20:45:24 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 20:45:25 --> Config Class Initialized
INFO - 2024-10-27 20:45:25 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:25 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:25 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:25 --> URI Class Initialized
INFO - 2024-10-27 20:45:25 --> Router Class Initialized
INFO - 2024-10-27 20:45:25 --> Output Class Initialized
INFO - 2024-10-27 20:45:25 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:25 --> Input Class Initialized
INFO - 2024-10-27 20:45:25 --> Language Class Initialized
ERROR - 2024-10-27 20:45:25 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 20:45:25 --> Config Class Initialized
INFO - 2024-10-27 20:45:25 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:25 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:25 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:25 --> URI Class Initialized
INFO - 2024-10-27 20:45:25 --> Router Class Initialized
INFO - 2024-10-27 20:45:25 --> Output Class Initialized
INFO - 2024-10-27 20:45:25 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:25 --> Input Class Initialized
INFO - 2024-10-27 20:45:25 --> Language Class Initialized
ERROR - 2024-10-27 20:45:25 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-27 20:45:25 --> Config Class Initialized
INFO - 2024-10-27 20:45:25 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:25 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:25 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:25 --> URI Class Initialized
INFO - 2024-10-27 20:45:25 --> Router Class Initialized
INFO - 2024-10-27 20:45:25 --> Output Class Initialized
INFO - 2024-10-27 20:45:25 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:25 --> Input Class Initialized
INFO - 2024-10-27 20:45:25 --> Language Class Initialized
ERROR - 2024-10-27 20:45:25 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 20:45:26 --> Config Class Initialized
INFO - 2024-10-27 20:45:26 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:26 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:26 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:26 --> URI Class Initialized
INFO - 2024-10-27 20:45:26 --> Router Class Initialized
INFO - 2024-10-27 20:45:26 --> Output Class Initialized
INFO - 2024-10-27 20:45:26 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:26 --> Input Class Initialized
INFO - 2024-10-27 20:45:26 --> Language Class Initialized
ERROR - 2024-10-27 20:45:26 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 20:45:26 --> Config Class Initialized
INFO - 2024-10-27 20:45:26 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:26 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:26 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:26 --> URI Class Initialized
INFO - 2024-10-27 20:45:26 --> Router Class Initialized
INFO - 2024-10-27 20:45:26 --> Output Class Initialized
INFO - 2024-10-27 20:45:26 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:26 --> Input Class Initialized
INFO - 2024-10-27 20:45:26 --> Language Class Initialized
ERROR - 2024-10-27 20:45:26 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 20:45:26 --> Config Class Initialized
INFO - 2024-10-27 20:45:26 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:26 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:26 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:26 --> URI Class Initialized
INFO - 2024-10-27 20:45:26 --> Router Class Initialized
INFO - 2024-10-27 20:45:26 --> Output Class Initialized
INFO - 2024-10-27 20:45:26 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:26 --> Input Class Initialized
INFO - 2024-10-27 20:45:26 --> Language Class Initialized
ERROR - 2024-10-27 20:45:26 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 20:45:26 --> Config Class Initialized
INFO - 2024-10-27 20:45:26 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:26 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:26 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:26 --> URI Class Initialized
INFO - 2024-10-27 20:45:26 --> Router Class Initialized
INFO - 2024-10-27 20:45:26 --> Output Class Initialized
INFO - 2024-10-27 20:45:26 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:26 --> Input Class Initialized
INFO - 2024-10-27 20:45:26 --> Language Class Initialized
ERROR - 2024-10-27 20:45:26 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-27 20:45:27 --> Config Class Initialized
INFO - 2024-10-27 20:45:27 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:27 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:27 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:27 --> URI Class Initialized
INFO - 2024-10-27 20:45:27 --> Router Class Initialized
INFO - 2024-10-27 20:45:27 --> Output Class Initialized
INFO - 2024-10-27 20:45:27 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:27 --> Input Class Initialized
INFO - 2024-10-27 20:45:27 --> Language Class Initialized
ERROR - 2024-10-27 20:45:27 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 20:45:27 --> Config Class Initialized
INFO - 2024-10-27 20:45:27 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:27 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:27 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:27 --> URI Class Initialized
INFO - 2024-10-27 20:45:27 --> Router Class Initialized
INFO - 2024-10-27 20:45:27 --> Output Class Initialized
INFO - 2024-10-27 20:45:27 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:27 --> Input Class Initialized
INFO - 2024-10-27 20:45:27 --> Language Class Initialized
ERROR - 2024-10-27 20:45:27 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 20:45:27 --> Config Class Initialized
INFO - 2024-10-27 20:45:27 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:27 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:27 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:27 --> URI Class Initialized
INFO - 2024-10-27 20:45:27 --> Router Class Initialized
INFO - 2024-10-27 20:45:27 --> Output Class Initialized
INFO - 2024-10-27 20:45:27 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:27 --> Input Class Initialized
INFO - 2024-10-27 20:45:27 --> Language Class Initialized
ERROR - 2024-10-27 20:45:27 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 20:45:28 --> Config Class Initialized
INFO - 2024-10-27 20:45:28 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:45:28 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:45:28 --> Utf8 Class Initialized
INFO - 2024-10-27 20:45:28 --> URI Class Initialized
INFO - 2024-10-27 20:45:28 --> Router Class Initialized
INFO - 2024-10-27 20:45:28 --> Output Class Initialized
INFO - 2024-10-27 20:45:28 --> Security Class Initialized
DEBUG - 2024-10-27 20:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:45:28 --> Input Class Initialized
INFO - 2024-10-27 20:45:28 --> Language Class Initialized
ERROR - 2024-10-27 20:45:28 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 20:46:14 --> Config Class Initialized
INFO - 2024-10-27 20:46:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:14 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:14 --> URI Class Initialized
DEBUG - 2024-10-27 20:46:14 --> No URI present. Default controller set.
INFO - 2024-10-27 20:46:14 --> Router Class Initialized
INFO - 2024-10-27 20:46:14 --> Output Class Initialized
INFO - 2024-10-27 20:46:14 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:14 --> Input Class Initialized
INFO - 2024-10-27 20:46:14 --> Language Class Initialized
INFO - 2024-10-27 20:46:14 --> Loader Class Initialized
INFO - 2024-10-27 20:46:14 --> Helper loaded: url_helper
INFO - 2024-10-27 20:46:14 --> Helper loaded: html_helper
INFO - 2024-10-27 20:46:14 --> Helper loaded: file_helper
INFO - 2024-10-27 20:46:14 --> Helper loaded: string_helper
INFO - 2024-10-27 20:46:14 --> Helper loaded: form_helper
INFO - 2024-10-27 20:46:14 --> Helper loaded: my_helper
INFO - 2024-10-27 20:46:14 --> Database Driver Class Initialized
INFO - 2024-10-27 20:46:16 --> Upload Class Initialized
INFO - 2024-10-27 20:46:16 --> Email Class Initialized
INFO - 2024-10-27 20:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 20:46:16 --> Form Validation Class Initialized
INFO - 2024-10-27 20:46:16 --> Controller Class Initialized
INFO - 2024-10-27 20:46:16 --> Config Class Initialized
INFO - 2024-10-27 20:46:16 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:16 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:16 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:16 --> URI Class Initialized
INFO - 2024-10-27 20:46:16 --> Router Class Initialized
INFO - 2024-10-27 20:46:16 --> Output Class Initialized
INFO - 2024-10-27 20:46:16 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:16 --> Input Class Initialized
INFO - 2024-10-27 20:46:16 --> Language Class Initialized
ERROR - 2024-10-27 20:46:16 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-27 20:46:16 --> Config Class Initialized
INFO - 2024-10-27 20:46:16 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:16 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:16 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:16 --> URI Class Initialized
INFO - 2024-10-27 20:46:16 --> Router Class Initialized
INFO - 2024-10-27 20:46:16 --> Output Class Initialized
INFO - 2024-10-27 20:46:16 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:16 --> Input Class Initialized
INFO - 2024-10-27 20:46:16 --> Language Class Initialized
ERROR - 2024-10-27 20:46:16 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-27 20:46:16 --> Config Class Initialized
INFO - 2024-10-27 20:46:16 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:16 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:16 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:16 --> URI Class Initialized
DEBUG - 2024-10-27 20:46:16 --> No URI present. Default controller set.
INFO - 2024-10-27 20:46:16 --> Router Class Initialized
INFO - 2024-10-27 20:46:16 --> Output Class Initialized
INFO - 2024-10-27 20:46:16 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:16 --> Input Class Initialized
INFO - 2024-10-27 20:46:16 --> Language Class Initialized
INFO - 2024-10-27 20:46:16 --> Loader Class Initialized
INFO - 2024-10-27 20:46:16 --> Helper loaded: url_helper
INFO - 2024-10-27 20:46:16 --> Helper loaded: html_helper
INFO - 2024-10-27 20:46:16 --> Helper loaded: file_helper
INFO - 2024-10-27 20:46:16 --> Helper loaded: string_helper
INFO - 2024-10-27 20:46:16 --> Helper loaded: form_helper
INFO - 2024-10-27 20:46:16 --> Helper loaded: my_helper
INFO - 2024-10-27 20:46:16 --> Database Driver Class Initialized
INFO - 2024-10-27 20:46:18 --> Upload Class Initialized
INFO - 2024-10-27 20:46:18 --> Email Class Initialized
INFO - 2024-10-27 20:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 20:46:18 --> Form Validation Class Initialized
INFO - 2024-10-27 20:46:18 --> Controller Class Initialized
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-27 20:46:19 --> Config Class Initialized
INFO - 2024-10-27 20:46:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:19 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:19 --> URI Class Initialized
INFO - 2024-10-27 20:46:19 --> Router Class Initialized
INFO - 2024-10-27 20:46:19 --> Output Class Initialized
INFO - 2024-10-27 20:46:19 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:19 --> Input Class Initialized
INFO - 2024-10-27 20:46:19 --> Language Class Initialized
ERROR - 2024-10-27 20:46:19 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-27 20:46:20 --> Config Class Initialized
INFO - 2024-10-27 20:46:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:20 --> URI Class Initialized
INFO - 2024-10-27 20:46:20 --> Router Class Initialized
INFO - 2024-10-27 20:46:20 --> Output Class Initialized
INFO - 2024-10-27 20:46:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:20 --> Input Class Initialized
INFO - 2024-10-27 20:46:20 --> Language Class Initialized
ERROR - 2024-10-27 20:46:20 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-27 20:46:20 --> Config Class Initialized
INFO - 2024-10-27 20:46:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:20 --> URI Class Initialized
INFO - 2024-10-27 20:46:20 --> Router Class Initialized
INFO - 2024-10-27 20:46:20 --> Output Class Initialized
INFO - 2024-10-27 20:46:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:20 --> Input Class Initialized
INFO - 2024-10-27 20:46:20 --> Language Class Initialized
ERROR - 2024-10-27 20:46:20 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-27 20:46:20 --> Config Class Initialized
INFO - 2024-10-27 20:46:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:20 --> URI Class Initialized
INFO - 2024-10-27 20:46:20 --> Router Class Initialized
INFO - 2024-10-27 20:46:20 --> Output Class Initialized
INFO - 2024-10-27 20:46:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:20 --> Input Class Initialized
INFO - 2024-10-27 20:46:20 --> Language Class Initialized
ERROR - 2024-10-27 20:46:20 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-27 20:46:20 --> Config Class Initialized
INFO - 2024-10-27 20:46:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:20 --> URI Class Initialized
INFO - 2024-10-27 20:46:20 --> Router Class Initialized
INFO - 2024-10-27 20:46:20 --> Output Class Initialized
INFO - 2024-10-27 20:46:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:20 --> Input Class Initialized
INFO - 2024-10-27 20:46:20 --> Language Class Initialized
ERROR - 2024-10-27 20:46:20 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-27 20:46:20 --> Config Class Initialized
INFO - 2024-10-27 20:46:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:20 --> URI Class Initialized
INFO - 2024-10-27 20:46:20 --> Router Class Initialized
INFO - 2024-10-27 20:46:20 --> Output Class Initialized
INFO - 2024-10-27 20:46:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:20 --> Input Class Initialized
INFO - 2024-10-27 20:46:20 --> Language Class Initialized
ERROR - 2024-10-27 20:46:20 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-27 20:46:20 --> Config Class Initialized
INFO - 2024-10-27 20:46:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 20:46:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 20:46:20 --> Utf8 Class Initialized
INFO - 2024-10-27 20:46:20 --> URI Class Initialized
INFO - 2024-10-27 20:46:20 --> Router Class Initialized
INFO - 2024-10-27 20:46:20 --> Output Class Initialized
INFO - 2024-10-27 20:46:20 --> Security Class Initialized
DEBUG - 2024-10-27 20:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 20:46:20 --> Input Class Initialized
INFO - 2024-10-27 20:46:20 --> Language Class Initialized
ERROR - 2024-10-27 20:46:20 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-27 21:06:36 --> Config Class Initialized
INFO - 2024-10-27 21:06:36 --> Hooks Class Initialized
DEBUG - 2024-10-27 21:06:36 --> UTF-8 Support Enabled
INFO - 2024-10-27 21:06:36 --> Utf8 Class Initialized
INFO - 2024-10-27 21:06:36 --> URI Class Initialized
DEBUG - 2024-10-27 21:06:36 --> No URI present. Default controller set.
INFO - 2024-10-27 21:06:36 --> Router Class Initialized
INFO - 2024-10-27 21:06:36 --> Output Class Initialized
INFO - 2024-10-27 21:06:36 --> Security Class Initialized
DEBUG - 2024-10-27 21:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 21:06:36 --> Input Class Initialized
INFO - 2024-10-27 21:06:36 --> Language Class Initialized
INFO - 2024-10-27 21:06:36 --> Loader Class Initialized
INFO - 2024-10-27 21:06:36 --> Helper loaded: url_helper
INFO - 2024-10-27 21:06:36 --> Helper loaded: html_helper
INFO - 2024-10-27 21:06:36 --> Helper loaded: file_helper
INFO - 2024-10-27 21:06:36 --> Helper loaded: string_helper
INFO - 2024-10-27 21:06:36 --> Helper loaded: form_helper
INFO - 2024-10-27 21:06:36 --> Helper loaded: my_helper
INFO - 2024-10-27 21:06:36 --> Database Driver Class Initialized
INFO - 2024-10-27 21:06:38 --> Upload Class Initialized
INFO - 2024-10-27 21:06:38 --> Email Class Initialized
INFO - 2024-10-27 21:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 21:06:38 --> Form Validation Class Initialized
INFO - 2024-10-27 21:06:38 --> Controller Class Initialized
INFO - 2024-10-27 22:40:04 --> Config Class Initialized
INFO - 2024-10-27 22:40:04 --> Hooks Class Initialized
DEBUG - 2024-10-27 22:40:04 --> UTF-8 Support Enabled
INFO - 2024-10-27 22:40:04 --> Utf8 Class Initialized
INFO - 2024-10-27 22:40:04 --> URI Class Initialized
DEBUG - 2024-10-27 22:40:04 --> No URI present. Default controller set.
INFO - 2024-10-27 22:40:04 --> Router Class Initialized
INFO - 2024-10-27 22:40:04 --> Output Class Initialized
INFO - 2024-10-27 22:40:05 --> Security Class Initialized
DEBUG - 2024-10-27 22:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 22:40:05 --> Input Class Initialized
INFO - 2024-10-27 22:40:05 --> Language Class Initialized
INFO - 2024-10-27 22:40:05 --> Loader Class Initialized
INFO - 2024-10-27 22:40:05 --> Helper loaded: url_helper
INFO - 2024-10-27 22:40:05 --> Helper loaded: html_helper
INFO - 2024-10-27 22:40:05 --> Helper loaded: file_helper
INFO - 2024-10-27 22:40:05 --> Helper loaded: string_helper
INFO - 2024-10-27 22:40:05 --> Helper loaded: form_helper
INFO - 2024-10-27 22:40:05 --> Helper loaded: my_helper
INFO - 2024-10-27 22:40:05 --> Database Driver Class Initialized
INFO - 2024-10-27 22:40:07 --> Upload Class Initialized
INFO - 2024-10-27 22:40:07 --> Email Class Initialized
INFO - 2024-10-27 22:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 22:40:07 --> Form Validation Class Initialized
INFO - 2024-10-27 22:40:07 --> Controller Class Initialized
INFO - 2024-10-27 22:40:11 --> Config Class Initialized
INFO - 2024-10-27 22:40:11 --> Hooks Class Initialized
DEBUG - 2024-10-27 22:40:11 --> UTF-8 Support Enabled
INFO - 2024-10-27 22:40:11 --> Utf8 Class Initialized
INFO - 2024-10-27 22:40:11 --> URI Class Initialized
DEBUG - 2024-10-27 22:40:11 --> No URI present. Default controller set.
INFO - 2024-10-27 22:40:11 --> Router Class Initialized
INFO - 2024-10-27 22:40:11 --> Output Class Initialized
INFO - 2024-10-27 22:40:11 --> Security Class Initialized
DEBUG - 2024-10-27 22:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 22:40:11 --> Input Class Initialized
INFO - 2024-10-27 22:40:11 --> Language Class Initialized
INFO - 2024-10-27 22:40:11 --> Loader Class Initialized
INFO - 2024-10-27 22:40:11 --> Helper loaded: url_helper
INFO - 2024-10-27 22:40:11 --> Helper loaded: html_helper
INFO - 2024-10-27 22:40:11 --> Helper loaded: file_helper
INFO - 2024-10-27 22:40:11 --> Helper loaded: string_helper
INFO - 2024-10-27 22:40:11 --> Helper loaded: form_helper
INFO - 2024-10-27 22:40:11 --> Helper loaded: my_helper
INFO - 2024-10-27 22:40:11 --> Database Driver Class Initialized
INFO - 2024-10-27 22:40:13 --> Upload Class Initialized
INFO - 2024-10-27 22:40:13 --> Email Class Initialized
INFO - 2024-10-27 22:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 22:40:13 --> Form Validation Class Initialized
INFO - 2024-10-27 22:40:13 --> Controller Class Initialized
INFO - 2024-10-27 22:55:14 --> Config Class Initialized
INFO - 2024-10-27 22:55:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 22:55:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 22:55:14 --> Utf8 Class Initialized
INFO - 2024-10-27 22:55:14 --> URI Class Initialized
DEBUG - 2024-10-27 22:55:14 --> No URI present. Default controller set.
INFO - 2024-10-27 22:55:14 --> Router Class Initialized
INFO - 2024-10-27 22:55:14 --> Output Class Initialized
INFO - 2024-10-27 22:55:14 --> Security Class Initialized
DEBUG - 2024-10-27 22:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 22:55:14 --> Input Class Initialized
INFO - 2024-10-27 22:55:14 --> Language Class Initialized
INFO - 2024-10-27 22:55:14 --> Loader Class Initialized
INFO - 2024-10-27 22:55:14 --> Helper loaded: url_helper
INFO - 2024-10-27 22:55:14 --> Helper loaded: html_helper
INFO - 2024-10-27 22:55:14 --> Helper loaded: file_helper
INFO - 2024-10-27 22:55:14 --> Helper loaded: string_helper
INFO - 2024-10-27 22:55:14 --> Helper loaded: form_helper
INFO - 2024-10-27 22:55:14 --> Helper loaded: my_helper
INFO - 2024-10-27 22:55:14 --> Database Driver Class Initialized
INFO - 2024-10-27 22:55:16 --> Upload Class Initialized
INFO - 2024-10-27 22:55:16 --> Email Class Initialized
INFO - 2024-10-27 22:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 22:55:16 --> Form Validation Class Initialized
INFO - 2024-10-27 22:55:16 --> Controller Class Initialized
INFO - 2024-10-27 23:31:35 --> Config Class Initialized
INFO - 2024-10-27 23:31:35 --> Hooks Class Initialized
DEBUG - 2024-10-27 23:31:35 --> UTF-8 Support Enabled
INFO - 2024-10-27 23:31:35 --> Utf8 Class Initialized
INFO - 2024-10-27 23:31:35 --> URI Class Initialized
INFO - 2024-10-27 23:31:35 --> Router Class Initialized
INFO - 2024-10-27 23:31:35 --> Output Class Initialized
INFO - 2024-10-27 23:31:35 --> Security Class Initialized
DEBUG - 2024-10-27 23:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 23:31:35 --> Input Class Initialized
INFO - 2024-10-27 23:31:35 --> Language Class Initialized
ERROR - 2024-10-27 23:31:35 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-27 23:31:37 --> Config Class Initialized
INFO - 2024-10-27 23:31:37 --> Hooks Class Initialized
DEBUG - 2024-10-27 23:31:37 --> UTF-8 Support Enabled
INFO - 2024-10-27 23:31:37 --> Utf8 Class Initialized
INFO - 2024-10-27 23:31:37 --> URI Class Initialized
DEBUG - 2024-10-27 23:31:37 --> No URI present. Default controller set.
INFO - 2024-10-27 23:31:37 --> Router Class Initialized
INFO - 2024-10-27 23:31:37 --> Output Class Initialized
INFO - 2024-10-27 23:31:37 --> Security Class Initialized
DEBUG - 2024-10-27 23:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 23:31:37 --> Input Class Initialized
INFO - 2024-10-27 23:31:37 --> Language Class Initialized
INFO - 2024-10-27 23:31:37 --> Loader Class Initialized
INFO - 2024-10-27 23:31:37 --> Helper loaded: url_helper
INFO - 2024-10-27 23:31:37 --> Helper loaded: html_helper
INFO - 2024-10-27 23:31:37 --> Helper loaded: file_helper
INFO - 2024-10-27 23:31:37 --> Helper loaded: string_helper
INFO - 2024-10-27 23:31:37 --> Helper loaded: form_helper
INFO - 2024-10-27 23:31:37 --> Helper loaded: my_helper
INFO - 2024-10-27 23:31:37 --> Database Driver Class Initialized
INFO - 2024-10-27 23:31:39 --> Upload Class Initialized
INFO - 2024-10-27 23:31:39 --> Email Class Initialized
INFO - 2024-10-27 23:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 23:31:39 --> Form Validation Class Initialized
INFO - 2024-10-27 23:31:39 --> Controller Class Initialized
