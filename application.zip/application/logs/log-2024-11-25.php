<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-25 03:10:58 --> Config Class Initialized
INFO - 2024-11-25 03:10:58 --> Hooks Class Initialized
DEBUG - 2024-11-25 03:10:58 --> UTF-8 Support Enabled
INFO - 2024-11-25 03:10:58 --> Utf8 Class Initialized
INFO - 2024-11-25 03:10:58 --> URI Class Initialized
DEBUG - 2024-11-25 03:10:58 --> No URI present. Default controller set.
INFO - 2024-11-25 03:10:58 --> Router Class Initialized
INFO - 2024-11-25 03:10:58 --> Output Class Initialized
INFO - 2024-11-25 03:10:58 --> Security Class Initialized
DEBUG - 2024-11-25 03:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-25 03:10:58 --> Input Class Initialized
INFO - 2024-11-25 03:10:58 --> Language Class Initialized
INFO - 2024-11-25 03:10:58 --> Loader Class Initialized
INFO - 2024-11-25 03:10:58 --> Helper loaded: url_helper
INFO - 2024-11-25 03:10:58 --> Helper loaded: html_helper
INFO - 2024-11-25 03:10:58 --> Helper loaded: file_helper
INFO - 2024-11-25 03:10:58 --> Helper loaded: string_helper
INFO - 2024-11-25 03:10:58 --> Helper loaded: form_helper
INFO - 2024-11-25 03:10:58 --> Helper loaded: my_helper
INFO - 2024-11-25 03:10:58 --> Database Driver Class Initialized
INFO - 2024-11-25 03:11:00 --> Upload Class Initialized
INFO - 2024-11-25 03:11:00 --> Email Class Initialized
INFO - 2024-11-25 03:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-25 03:11:01 --> Form Validation Class Initialized
INFO - 2024-11-25 03:11:01 --> Controller Class Initialized
INFO - 2024-11-25 08:41:01 --> Model "MainModel" initialized
INFO - 2024-11-25 08:41:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-25 08:41:01 --> Final output sent to browser
DEBUG - 2024-11-25 08:41:01 --> Total execution time: 2.6821
INFO - 2024-11-25 10:59:55 --> Config Class Initialized
INFO - 2024-11-25 10:59:55 --> Hooks Class Initialized
DEBUG - 2024-11-25 10:59:55 --> UTF-8 Support Enabled
INFO - 2024-11-25 10:59:55 --> Utf8 Class Initialized
INFO - 2024-11-25 10:59:55 --> URI Class Initialized
DEBUG - 2024-11-25 10:59:55 --> No URI present. Default controller set.
INFO - 2024-11-25 10:59:55 --> Router Class Initialized
INFO - 2024-11-25 10:59:55 --> Output Class Initialized
INFO - 2024-11-25 10:59:55 --> Security Class Initialized
DEBUG - 2024-11-25 10:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-25 10:59:55 --> Input Class Initialized
INFO - 2024-11-25 10:59:55 --> Language Class Initialized
INFO - 2024-11-25 10:59:55 --> Loader Class Initialized
INFO - 2024-11-25 10:59:55 --> Helper loaded: url_helper
INFO - 2024-11-25 10:59:55 --> Helper loaded: html_helper
INFO - 2024-11-25 10:59:55 --> Helper loaded: file_helper
INFO - 2024-11-25 10:59:55 --> Helper loaded: string_helper
INFO - 2024-11-25 10:59:55 --> Helper loaded: form_helper
INFO - 2024-11-25 10:59:55 --> Helper loaded: my_helper
INFO - 2024-11-25 10:59:55 --> Database Driver Class Initialized
INFO - 2024-11-25 10:59:57 --> Upload Class Initialized
INFO - 2024-11-25 10:59:57 --> Email Class Initialized
INFO - 2024-11-25 10:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-25 10:59:57 --> Form Validation Class Initialized
INFO - 2024-11-25 10:59:57 --> Controller Class Initialized
INFO - 2024-11-25 16:29:57 --> Model "MainModel" initialized
INFO - 2024-11-25 16:29:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-25 16:29:57 --> Final output sent to browser
DEBUG - 2024-11-25 16:29:57 --> Total execution time: 2.2989
INFO - 2024-11-25 11:00:09 --> Config Class Initialized
INFO - 2024-11-25 11:00:09 --> Hooks Class Initialized
DEBUG - 2024-11-25 11:00:09 --> UTF-8 Support Enabled
INFO - 2024-11-25 11:00:09 --> Utf8 Class Initialized
INFO - 2024-11-25 11:00:09 --> URI Class Initialized
DEBUG - 2024-11-25 11:00:09 --> No URI present. Default controller set.
INFO - 2024-11-25 11:00:09 --> Router Class Initialized
INFO - 2024-11-25 11:00:09 --> Output Class Initialized
INFO - 2024-11-25 11:00:09 --> Security Class Initialized
DEBUG - 2024-11-25 11:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-25 11:00:09 --> Input Class Initialized
INFO - 2024-11-25 11:00:09 --> Language Class Initialized
INFO - 2024-11-25 11:00:09 --> Loader Class Initialized
INFO - 2024-11-25 11:00:09 --> Helper loaded: url_helper
INFO - 2024-11-25 11:00:09 --> Helper loaded: html_helper
INFO - 2024-11-25 11:00:09 --> Helper loaded: file_helper
INFO - 2024-11-25 11:00:09 --> Helper loaded: string_helper
INFO - 2024-11-25 11:00:09 --> Helper loaded: form_helper
INFO - 2024-11-25 11:00:09 --> Helper loaded: my_helper
INFO - 2024-11-25 11:00:09 --> Database Driver Class Initialized
INFO - 2024-11-25 11:00:11 --> Upload Class Initialized
INFO - 2024-11-25 11:00:11 --> Email Class Initialized
INFO - 2024-11-25 11:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-25 11:00:11 --> Form Validation Class Initialized
INFO - 2024-11-25 11:00:11 --> Controller Class Initialized
INFO - 2024-11-25 16:30:11 --> Model "MainModel" initialized
INFO - 2024-11-25 16:30:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-25 16:30:11 --> Final output sent to browser
DEBUG - 2024-11-25 16:30:11 --> Total execution time: 2.3361
INFO - 2024-11-25 13:02:39 --> Config Class Initialized
INFO - 2024-11-25 13:02:39 --> Hooks Class Initialized
DEBUG - 2024-11-25 13:02:39 --> UTF-8 Support Enabled
INFO - 2024-11-25 13:02:39 --> Utf8 Class Initialized
INFO - 2024-11-25 13:02:39 --> URI Class Initialized
DEBUG - 2024-11-25 13:02:39 --> No URI present. Default controller set.
INFO - 2024-11-25 13:02:39 --> Router Class Initialized
INFO - 2024-11-25 13:02:39 --> Output Class Initialized
INFO - 2024-11-25 13:02:39 --> Security Class Initialized
DEBUG - 2024-11-25 13:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-25 13:02:39 --> Input Class Initialized
INFO - 2024-11-25 13:02:39 --> Language Class Initialized
INFO - 2024-11-25 13:02:39 --> Loader Class Initialized
INFO - 2024-11-25 13:02:39 --> Helper loaded: url_helper
INFO - 2024-11-25 13:02:39 --> Helper loaded: html_helper
INFO - 2024-11-25 13:02:39 --> Helper loaded: file_helper
INFO - 2024-11-25 13:02:39 --> Helper loaded: string_helper
INFO - 2024-11-25 13:02:39 --> Helper loaded: form_helper
INFO - 2024-11-25 13:02:39 --> Helper loaded: my_helper
INFO - 2024-11-25 13:02:39 --> Database Driver Class Initialized
INFO - 2024-11-25 13:02:41 --> Upload Class Initialized
INFO - 2024-11-25 13:02:41 --> Email Class Initialized
INFO - 2024-11-25 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-25 13:02:41 --> Form Validation Class Initialized
INFO - 2024-11-25 13:02:41 --> Controller Class Initialized
INFO - 2024-11-25 18:32:41 --> Model "MainModel" initialized
INFO - 2024-11-25 18:32:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-25 18:32:41 --> Final output sent to browser
DEBUG - 2024-11-25 18:32:41 --> Total execution time: 2.2994
