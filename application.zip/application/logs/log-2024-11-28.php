<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-28 05:43:19 --> Config Class Initialized
INFO - 2024-11-28 05:43:19 --> Hooks Class Initialized
DEBUG - 2024-11-28 05:43:19 --> UTF-8 Support Enabled
INFO - 2024-11-28 05:43:19 --> Utf8 Class Initialized
INFO - 2024-11-28 05:43:19 --> URI Class Initialized
DEBUG - 2024-11-28 05:43:19 --> No URI present. Default controller set.
INFO - 2024-11-28 05:43:19 --> Router Class Initialized
INFO - 2024-11-28 05:43:19 --> Output Class Initialized
INFO - 2024-11-28 05:43:19 --> Security Class Initialized
DEBUG - 2024-11-28 05:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-28 05:43:19 --> Input Class Initialized
INFO - 2024-11-28 05:43:19 --> Language Class Initialized
INFO - 2024-11-28 05:43:19 --> Loader Class Initialized
INFO - 2024-11-28 05:43:19 --> Helper loaded: url_helper
INFO - 2024-11-28 05:43:19 --> Helper loaded: html_helper
INFO - 2024-11-28 05:43:19 --> Helper loaded: file_helper
INFO - 2024-11-28 05:43:19 --> Helper loaded: string_helper
INFO - 2024-11-28 05:43:19 --> Helper loaded: form_helper
INFO - 2024-11-28 05:43:19 --> Helper loaded: my_helper
INFO - 2024-11-28 05:43:20 --> Database Driver Class Initialized
INFO - 2024-11-28 05:43:22 --> Upload Class Initialized
INFO - 2024-11-28 05:43:22 --> Email Class Initialized
INFO - 2024-11-28 05:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-28 05:43:22 --> Form Validation Class Initialized
INFO - 2024-11-28 05:43:22 --> Controller Class Initialized
INFO - 2024-11-28 11:13:22 --> Model "MainModel" initialized
INFO - 2024-11-28 11:13:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-28 11:13:22 --> Final output sent to browser
DEBUG - 2024-11-28 11:13:22 --> Total execution time: 4.1970
INFO - 2024-11-28 05:57:57 --> Config Class Initialized
INFO - 2024-11-28 05:57:57 --> Hooks Class Initialized
DEBUG - 2024-11-28 05:57:57 --> UTF-8 Support Enabled
INFO - 2024-11-28 05:57:57 --> Utf8 Class Initialized
INFO - 2024-11-28 05:57:57 --> URI Class Initialized
DEBUG - 2024-11-28 05:57:57 --> No URI present. Default controller set.
INFO - 2024-11-28 05:57:57 --> Router Class Initialized
INFO - 2024-11-28 05:57:57 --> Output Class Initialized
INFO - 2024-11-28 05:57:57 --> Security Class Initialized
DEBUG - 2024-11-28 05:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-28 05:57:57 --> Input Class Initialized
INFO - 2024-11-28 05:57:57 --> Language Class Initialized
INFO - 2024-11-28 05:57:57 --> Loader Class Initialized
INFO - 2024-11-28 05:57:57 --> Helper loaded: url_helper
INFO - 2024-11-28 05:57:57 --> Helper loaded: html_helper
INFO - 2024-11-28 05:57:57 --> Helper loaded: file_helper
INFO - 2024-11-28 05:57:57 --> Helper loaded: string_helper
INFO - 2024-11-28 05:57:57 --> Helper loaded: form_helper
INFO - 2024-11-28 05:57:57 --> Helper loaded: my_helper
INFO - 2024-11-28 05:57:57 --> Database Driver Class Initialized
INFO - 2024-11-28 05:57:59 --> Upload Class Initialized
INFO - 2024-11-28 05:57:59 --> Email Class Initialized
INFO - 2024-11-28 05:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-28 05:58:00 --> Form Validation Class Initialized
INFO - 2024-11-28 05:58:00 --> Controller Class Initialized
INFO - 2024-11-28 11:28:00 --> Model "MainModel" initialized
INFO - 2024-11-28 11:28:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-28 11:28:00 --> Final output sent to browser
DEBUG - 2024-11-28 11:28:00 --> Total execution time: 3.4739
INFO - 2024-11-28 13:10:32 --> Config Class Initialized
INFO - 2024-11-28 13:10:32 --> Hooks Class Initialized
DEBUG - 2024-11-28 13:10:32 --> UTF-8 Support Enabled
INFO - 2024-11-28 13:10:32 --> Utf8 Class Initialized
INFO - 2024-11-28 13:10:33 --> URI Class Initialized
DEBUG - 2024-11-28 13:10:33 --> No URI present. Default controller set.
INFO - 2024-11-28 13:10:33 --> Router Class Initialized
INFO - 2024-11-28 13:10:33 --> Output Class Initialized
INFO - 2024-11-28 13:10:33 --> Security Class Initialized
DEBUG - 2024-11-28 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-28 13:10:33 --> Input Class Initialized
INFO - 2024-11-28 13:10:33 --> Language Class Initialized
INFO - 2024-11-28 13:10:33 --> Loader Class Initialized
INFO - 2024-11-28 13:10:33 --> Helper loaded: url_helper
INFO - 2024-11-28 13:10:33 --> Helper loaded: html_helper
INFO - 2024-11-28 13:10:33 --> Helper loaded: file_helper
INFO - 2024-11-28 13:10:33 --> Helper loaded: string_helper
INFO - 2024-11-28 13:10:34 --> Helper loaded: form_helper
INFO - 2024-11-28 13:10:34 --> Helper loaded: my_helper
INFO - 2024-11-28 13:10:34 --> Database Driver Class Initialized
INFO - 2024-11-28 13:10:36 --> Upload Class Initialized
INFO - 2024-11-28 13:10:37 --> Email Class Initialized
INFO - 2024-11-28 13:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-28 13:10:38 --> Form Validation Class Initialized
INFO - 2024-11-28 13:10:38 --> Controller Class Initialized
INFO - 2024-11-28 18:40:38 --> Model "MainModel" initialized
INFO - 2024-11-28 18:40:38 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-28 18:40:39 --> Final output sent to browser
DEBUG - 2024-11-28 18:40:39 --> Total execution time: 6.4759
