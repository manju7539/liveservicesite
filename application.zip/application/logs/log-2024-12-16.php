<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-16 16:13:42 --> Config Class Initialized
INFO - 2024-12-16 16:13:42 --> Hooks Class Initialized
DEBUG - 2024-12-16 16:13:42 --> UTF-8 Support Enabled
INFO - 2024-12-16 16:13:42 --> Utf8 Class Initialized
INFO - 2024-12-16 16:13:42 --> URI Class Initialized
DEBUG - 2024-12-16 16:13:43 --> No URI present. Default controller set.
INFO - 2024-12-16 16:13:43 --> Router Class Initialized
INFO - 2024-12-16 16:13:43 --> Output Class Initialized
INFO - 2024-12-16 16:13:43 --> Security Class Initialized
DEBUG - 2024-12-16 16:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 16:13:43 --> Input Class Initialized
INFO - 2024-12-16 16:13:43 --> Language Class Initialized
INFO - 2024-12-16 16:13:43 --> Loader Class Initialized
INFO - 2024-12-16 16:13:43 --> Helper loaded: url_helper
INFO - 2024-12-16 16:13:43 --> Helper loaded: html_helper
INFO - 2024-12-16 16:13:43 --> Helper loaded: file_helper
INFO - 2024-12-16 16:13:43 --> Helper loaded: string_helper
INFO - 2024-12-16 16:13:43 --> Helper loaded: form_helper
INFO - 2024-12-16 16:13:43 --> Helper loaded: my_helper
INFO - 2024-12-16 16:13:43 --> Database Driver Class Initialized
INFO - 2024-12-16 16:13:45 --> Upload Class Initialized
INFO - 2024-12-16 16:13:45 --> Email Class Initialized
INFO - 2024-12-16 16:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 16:13:45 --> Form Validation Class Initialized
INFO - 2024-12-16 16:13:45 --> Controller Class Initialized
INFO - 2024-12-16 21:43:45 --> Model "MainModel" initialized
INFO - 2024-12-16 21:43:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-16 21:43:45 --> Final output sent to browser
DEBUG - 2024-12-16 21:43:45 --> Total execution time: 2.9142
INFO - 2024-12-16 21:22:14 --> Config Class Initialized
INFO - 2024-12-16 21:22:14 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:14 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:14 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:14 --> URI Class Initialized
DEBUG - 2024-12-16 21:22:14 --> No URI present. Default controller set.
INFO - 2024-12-16 21:22:14 --> Router Class Initialized
INFO - 2024-12-16 21:22:14 --> Output Class Initialized
INFO - 2024-12-16 21:22:14 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:14 --> Input Class Initialized
INFO - 2024-12-16 21:22:14 --> Language Class Initialized
INFO - 2024-12-16 21:22:14 --> Loader Class Initialized
INFO - 2024-12-16 21:22:14 --> Helper loaded: url_helper
INFO - 2024-12-16 21:22:14 --> Helper loaded: html_helper
INFO - 2024-12-16 21:22:14 --> Helper loaded: file_helper
INFO - 2024-12-16 21:22:14 --> Helper loaded: string_helper
INFO - 2024-12-16 21:22:14 --> Helper loaded: form_helper
INFO - 2024-12-16 21:22:14 --> Helper loaded: my_helper
INFO - 2024-12-16 21:22:14 --> Database Driver Class Initialized
INFO - 2024-12-16 21:22:16 --> Upload Class Initialized
INFO - 2024-12-16 21:22:16 --> Email Class Initialized
INFO - 2024-12-16 21:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 21:22:17 --> Form Validation Class Initialized
INFO - 2024-12-16 21:22:17 --> Controller Class Initialized
INFO - 2024-12-16 21:22:17 --> Config Class Initialized
INFO - 2024-12-16 21:22:17 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:17 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:17 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:17 --> URI Class Initialized
INFO - 2024-12-16 21:22:17 --> Router Class Initialized
INFO - 2024-12-16 21:22:17 --> Output Class Initialized
INFO - 2024-12-16 21:22:17 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:17 --> Input Class Initialized
INFO - 2024-12-16 21:22:17 --> Language Class Initialized
ERROR - 2024-12-16 21:22:17 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-16 21:22:18 --> Config Class Initialized
INFO - 2024-12-16 21:22:18 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:18 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:18 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:18 --> URI Class Initialized
INFO - 2024-12-16 21:22:18 --> Router Class Initialized
INFO - 2024-12-16 21:22:18 --> Output Class Initialized
INFO - 2024-12-16 21:22:18 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:18 --> Input Class Initialized
INFO - 2024-12-16 21:22:18 --> Language Class Initialized
ERROR - 2024-12-16 21:22:18 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-16 21:22:18 --> Config Class Initialized
INFO - 2024-12-16 21:22:18 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:18 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:18 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:18 --> URI Class Initialized
DEBUG - 2024-12-16 21:22:18 --> No URI present. Default controller set.
INFO - 2024-12-16 21:22:18 --> Router Class Initialized
INFO - 2024-12-16 21:22:18 --> Output Class Initialized
INFO - 2024-12-16 21:22:18 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:18 --> Input Class Initialized
INFO - 2024-12-16 21:22:18 --> Language Class Initialized
INFO - 2024-12-16 21:22:18 --> Loader Class Initialized
INFO - 2024-12-16 21:22:18 --> Helper loaded: url_helper
INFO - 2024-12-16 21:22:18 --> Helper loaded: html_helper
INFO - 2024-12-16 21:22:18 --> Helper loaded: file_helper
INFO - 2024-12-16 21:22:18 --> Helper loaded: string_helper
INFO - 2024-12-16 21:22:18 --> Helper loaded: form_helper
INFO - 2024-12-16 21:22:18 --> Helper loaded: my_helper
INFO - 2024-12-16 21:22:18 --> Database Driver Class Initialized
INFO - 2024-12-16 21:22:21 --> Upload Class Initialized
INFO - 2024-12-16 21:22:21 --> Email Class Initialized
INFO - 2024-12-16 21:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-16 21:22:21 --> Form Validation Class Initialized
INFO - 2024-12-16 21:22:21 --> Controller Class Initialized
INFO - 2024-12-16 21:22:21 --> Config Class Initialized
INFO - 2024-12-16 21:22:21 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:21 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:21 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:21 --> URI Class Initialized
INFO - 2024-12-16 21:22:21 --> Router Class Initialized
INFO - 2024-12-16 21:22:21 --> Output Class Initialized
INFO - 2024-12-16 21:22:21 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:21 --> Input Class Initialized
INFO - 2024-12-16 21:22:21 --> Language Class Initialized
ERROR - 2024-12-16 21:22:21 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-16 21:22:21 --> Config Class Initialized
INFO - 2024-12-16 21:22:21 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:21 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:21 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:21 --> URI Class Initialized
INFO - 2024-12-16 21:22:21 --> Router Class Initialized
INFO - 2024-12-16 21:22:21 --> Output Class Initialized
INFO - 2024-12-16 21:22:21 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:21 --> Input Class Initialized
INFO - 2024-12-16 21:22:21 --> Language Class Initialized
ERROR - 2024-12-16 21:22:21 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-16 21:22:22 --> Config Class Initialized
INFO - 2024-12-16 21:22:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:22 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:22 --> URI Class Initialized
INFO - 2024-12-16 21:22:22 --> Router Class Initialized
INFO - 2024-12-16 21:22:22 --> Output Class Initialized
INFO - 2024-12-16 21:22:22 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:22 --> Input Class Initialized
INFO - 2024-12-16 21:22:22 --> Language Class Initialized
ERROR - 2024-12-16 21:22:22 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-16 21:22:22 --> Config Class Initialized
INFO - 2024-12-16 21:22:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:22 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:22 --> URI Class Initialized
INFO - 2024-12-16 21:22:22 --> Router Class Initialized
INFO - 2024-12-16 21:22:22 --> Output Class Initialized
INFO - 2024-12-16 21:22:22 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:22 --> Input Class Initialized
INFO - 2024-12-16 21:22:22 --> Language Class Initialized
ERROR - 2024-12-16 21:22:22 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-16 21:22:22 --> Config Class Initialized
INFO - 2024-12-16 21:22:22 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:22 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:22 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:22 --> URI Class Initialized
INFO - 2024-12-16 21:22:22 --> Router Class Initialized
INFO - 2024-12-16 21:22:22 --> Output Class Initialized
INFO - 2024-12-16 21:22:22 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:22 --> Input Class Initialized
INFO - 2024-12-16 21:22:22 --> Language Class Initialized
ERROR - 2024-12-16 21:22:22 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-16 21:22:23 --> Config Class Initialized
INFO - 2024-12-16 21:22:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:23 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:23 --> URI Class Initialized
INFO - 2024-12-16 21:22:23 --> Router Class Initialized
INFO - 2024-12-16 21:22:23 --> Output Class Initialized
INFO - 2024-12-16 21:22:23 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:23 --> Input Class Initialized
INFO - 2024-12-16 21:22:23 --> Language Class Initialized
ERROR - 2024-12-16 21:22:23 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-16 21:22:23 --> Config Class Initialized
INFO - 2024-12-16 21:22:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:23 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:23 --> URI Class Initialized
INFO - 2024-12-16 21:22:23 --> Router Class Initialized
INFO - 2024-12-16 21:22:23 --> Output Class Initialized
INFO - 2024-12-16 21:22:23 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:23 --> Input Class Initialized
INFO - 2024-12-16 21:22:23 --> Language Class Initialized
ERROR - 2024-12-16 21:22:23 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-16 21:22:23 --> Config Class Initialized
INFO - 2024-12-16 21:22:23 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:23 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:23 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:23 --> URI Class Initialized
INFO - 2024-12-16 21:22:23 --> Router Class Initialized
INFO - 2024-12-16 21:22:23 --> Output Class Initialized
INFO - 2024-12-16 21:22:23 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:23 --> Input Class Initialized
INFO - 2024-12-16 21:22:23 --> Language Class Initialized
ERROR - 2024-12-16 21:22:23 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-16 21:22:24 --> Config Class Initialized
INFO - 2024-12-16 21:22:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:24 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:24 --> URI Class Initialized
INFO - 2024-12-16 21:22:24 --> Router Class Initialized
INFO - 2024-12-16 21:22:24 --> Output Class Initialized
INFO - 2024-12-16 21:22:24 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:24 --> Input Class Initialized
INFO - 2024-12-16 21:22:24 --> Language Class Initialized
ERROR - 2024-12-16 21:22:24 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-16 21:22:24 --> Config Class Initialized
INFO - 2024-12-16 21:22:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:24 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:24 --> URI Class Initialized
INFO - 2024-12-16 21:22:24 --> Router Class Initialized
INFO - 2024-12-16 21:22:24 --> Output Class Initialized
INFO - 2024-12-16 21:22:24 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:24 --> Input Class Initialized
INFO - 2024-12-16 21:22:24 --> Language Class Initialized
ERROR - 2024-12-16 21:22:24 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-16 21:22:24 --> Config Class Initialized
INFO - 2024-12-16 21:22:24 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:24 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:24 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:24 --> URI Class Initialized
INFO - 2024-12-16 21:22:24 --> Router Class Initialized
INFO - 2024-12-16 21:22:24 --> Output Class Initialized
INFO - 2024-12-16 21:22:24 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:24 --> Input Class Initialized
INFO - 2024-12-16 21:22:24 --> Language Class Initialized
ERROR - 2024-12-16 21:22:24 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-16 21:22:25 --> Config Class Initialized
INFO - 2024-12-16 21:22:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:25 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:25 --> URI Class Initialized
INFO - 2024-12-16 21:22:25 --> Router Class Initialized
INFO - 2024-12-16 21:22:25 --> Output Class Initialized
INFO - 2024-12-16 21:22:25 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:25 --> Input Class Initialized
INFO - 2024-12-16 21:22:25 --> Language Class Initialized
ERROR - 2024-12-16 21:22:25 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-16 21:22:25 --> Config Class Initialized
INFO - 2024-12-16 21:22:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:25 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:25 --> URI Class Initialized
INFO - 2024-12-16 21:22:25 --> Router Class Initialized
INFO - 2024-12-16 21:22:25 --> Output Class Initialized
INFO - 2024-12-16 21:22:25 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:25 --> Input Class Initialized
INFO - 2024-12-16 21:22:25 --> Language Class Initialized
ERROR - 2024-12-16 21:22:25 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-16 21:22:25 --> Config Class Initialized
INFO - 2024-12-16 21:22:25 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:25 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:25 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:25 --> URI Class Initialized
INFO - 2024-12-16 21:22:25 --> Router Class Initialized
INFO - 2024-12-16 21:22:25 --> Output Class Initialized
INFO - 2024-12-16 21:22:25 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:25 --> Input Class Initialized
INFO - 2024-12-16 21:22:25 --> Language Class Initialized
ERROR - 2024-12-16 21:22:25 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-16 21:22:26 --> Config Class Initialized
INFO - 2024-12-16 21:22:26 --> Hooks Class Initialized
DEBUG - 2024-12-16 21:22:26 --> UTF-8 Support Enabled
INFO - 2024-12-16 21:22:26 --> Utf8 Class Initialized
INFO - 2024-12-16 21:22:26 --> URI Class Initialized
INFO - 2024-12-16 21:22:26 --> Router Class Initialized
INFO - 2024-12-16 21:22:26 --> Output Class Initialized
INFO - 2024-12-16 21:22:26 --> Security Class Initialized
DEBUG - 2024-12-16 21:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-16 21:22:26 --> Input Class Initialized
INFO - 2024-12-16 21:22:26 --> Language Class Initialized
ERROR - 2024-12-16 21:22:26 --> 404 Page Not Found: Sito/wp-includes
