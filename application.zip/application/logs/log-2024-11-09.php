<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-09 06:22:44 --> Config Class Initialized
INFO - 2024-11-09 06:22:44 --> Hooks Class Initialized
DEBUG - 2024-11-09 06:22:44 --> UTF-8 Support Enabled
INFO - 2024-11-09 06:22:44 --> Utf8 Class Initialized
INFO - 2024-11-09 06:22:44 --> URI Class Initialized
DEBUG - 2024-11-09 06:22:44 --> No URI present. Default controller set.
INFO - 2024-11-09 06:22:44 --> Router Class Initialized
INFO - 2024-11-09 06:22:44 --> Output Class Initialized
INFO - 2024-11-09 06:22:44 --> Security Class Initialized
DEBUG - 2024-11-09 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 06:22:44 --> Input Class Initialized
INFO - 2024-11-09 06:22:44 --> Language Class Initialized
INFO - 2024-11-09 06:22:44 --> Loader Class Initialized
INFO - 2024-11-09 06:22:44 --> Helper loaded: url_helper
INFO - 2024-11-09 06:22:44 --> Helper loaded: html_helper
INFO - 2024-11-09 06:22:44 --> Helper loaded: file_helper
INFO - 2024-11-09 06:22:44 --> Helper loaded: string_helper
INFO - 2024-11-09 06:22:44 --> Helper loaded: form_helper
INFO - 2024-11-09 06:22:44 --> Helper loaded: my_helper
INFO - 2024-11-09 06:22:45 --> Database Driver Class Initialized
INFO - 2024-11-09 06:22:47 --> Upload Class Initialized
INFO - 2024-11-09 06:22:47 --> Email Class Initialized
INFO - 2024-11-09 06:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-09 06:22:47 --> Form Validation Class Initialized
INFO - 2024-11-09 06:22:47 --> Controller Class Initialized
INFO - 2024-11-09 11:52:47 --> Model "MainModel" initialized
INFO - 2024-11-09 11:52:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-09 11:52:47 --> Final output sent to browser
DEBUG - 2024-11-09 11:52:47 --> Total execution time: 2.8204
INFO - 2024-11-09 07:59:09 --> Config Class Initialized
INFO - 2024-11-09 07:59:09 --> Hooks Class Initialized
DEBUG - 2024-11-09 07:59:09 --> UTF-8 Support Enabled
INFO - 2024-11-09 07:59:09 --> Utf8 Class Initialized
INFO - 2024-11-09 07:59:09 --> URI Class Initialized
INFO - 2024-11-09 07:59:09 --> Router Class Initialized
INFO - 2024-11-09 07:59:09 --> Output Class Initialized
INFO - 2024-11-09 07:59:09 --> Security Class Initialized
DEBUG - 2024-11-09 07:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 07:59:09 --> Input Class Initialized
INFO - 2024-11-09 07:59:09 --> Language Class Initialized
ERROR - 2024-11-09 07:59:09 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-09 10:33:28 --> Config Class Initialized
INFO - 2024-11-09 10:33:28 --> Hooks Class Initialized
DEBUG - 2024-11-09 10:33:28 --> UTF-8 Support Enabled
INFO - 2024-11-09 10:33:28 --> Utf8 Class Initialized
INFO - 2024-11-09 10:33:28 --> URI Class Initialized
DEBUG - 2024-11-09 10:33:28 --> No URI present. Default controller set.
INFO - 2024-11-09 10:33:28 --> Router Class Initialized
INFO - 2024-11-09 10:33:28 --> Output Class Initialized
INFO - 2024-11-09 10:33:28 --> Security Class Initialized
DEBUG - 2024-11-09 10:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 10:33:28 --> Input Class Initialized
INFO - 2024-11-09 10:33:28 --> Language Class Initialized
INFO - 2024-11-09 10:33:28 --> Loader Class Initialized
INFO - 2024-11-09 10:33:28 --> Helper loaded: url_helper
INFO - 2024-11-09 10:33:29 --> Helper loaded: html_helper
INFO - 2024-11-09 10:33:29 --> Helper loaded: file_helper
INFO - 2024-11-09 10:33:29 --> Helper loaded: string_helper
INFO - 2024-11-09 10:33:29 --> Helper loaded: form_helper
INFO - 2024-11-09 10:33:29 --> Helper loaded: my_helper
INFO - 2024-11-09 10:33:29 --> Database Driver Class Initialized
INFO - 2024-11-09 10:33:31 --> Upload Class Initialized
INFO - 2024-11-09 10:33:31 --> Email Class Initialized
INFO - 2024-11-09 10:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-09 10:33:31 --> Form Validation Class Initialized
INFO - 2024-11-09 10:33:31 --> Controller Class Initialized
INFO - 2024-11-09 16:03:31 --> Model "MainModel" initialized
INFO - 2024-11-09 16:03:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-09 16:03:31 --> Final output sent to browser
DEBUG - 2024-11-09 16:03:31 --> Total execution time: 2.8186
