<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-23 03:10:48 --> Config Class Initialized
INFO - 2024-11-23 03:10:48 --> Hooks Class Initialized
DEBUG - 2024-11-23 03:10:48 --> UTF-8 Support Enabled
INFO - 2024-11-23 03:10:48 --> Utf8 Class Initialized
INFO - 2024-11-23 03:10:48 --> URI Class Initialized
INFO - 2024-11-23 03:10:48 --> Router Class Initialized
INFO - 2024-11-23 03:10:48 --> Output Class Initialized
INFO - 2024-11-23 03:10:48 --> Security Class Initialized
DEBUG - 2024-11-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 03:10:48 --> Input Class Initialized
INFO - 2024-11-23 03:10:48 --> Language Class Initialized
ERROR - 2024-11-23 03:10:48 --> 404 Page Not Found: Wp-loginphp/index
INFO - 2024-11-23 06:49:27 --> Config Class Initialized
INFO - 2024-11-23 06:49:27 --> Hooks Class Initialized
DEBUG - 2024-11-23 06:49:27 --> UTF-8 Support Enabled
INFO - 2024-11-23 06:49:27 --> Utf8 Class Initialized
INFO - 2024-11-23 06:49:27 --> URI Class Initialized
INFO - 2024-11-23 06:49:27 --> Router Class Initialized
INFO - 2024-11-23 06:49:27 --> Output Class Initialized
INFO - 2024-11-23 06:49:27 --> Security Class Initialized
DEBUG - 2024-11-23 06:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 06:49:27 --> Input Class Initialized
INFO - 2024-11-23 06:49:27 --> Language Class Initialized
ERROR - 2024-11-23 06:49:27 --> 404 Page Not Found: Wp-loginphp/index
INFO - 2024-11-23 09:18:38 --> Config Class Initialized
INFO - 2024-11-23 09:18:38 --> Hooks Class Initialized
DEBUG - 2024-11-23 09:18:38 --> UTF-8 Support Enabled
INFO - 2024-11-23 09:18:38 --> Utf8 Class Initialized
INFO - 2024-11-23 09:18:38 --> URI Class Initialized
DEBUG - 2024-11-23 09:18:38 --> No URI present. Default controller set.
INFO - 2024-11-23 09:18:38 --> Router Class Initialized
INFO - 2024-11-23 09:18:38 --> Output Class Initialized
INFO - 2024-11-23 09:18:38 --> Security Class Initialized
DEBUG - 2024-11-23 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 09:18:38 --> Input Class Initialized
INFO - 2024-11-23 09:18:38 --> Language Class Initialized
INFO - 2024-11-23 09:18:38 --> Loader Class Initialized
INFO - 2024-11-23 09:18:38 --> Helper loaded: url_helper
INFO - 2024-11-23 09:18:38 --> Helper loaded: html_helper
INFO - 2024-11-23 09:18:38 --> Helper loaded: file_helper
INFO - 2024-11-23 09:18:38 --> Helper loaded: string_helper
INFO - 2024-11-23 09:18:38 --> Helper loaded: form_helper
INFO - 2024-11-23 09:18:38 --> Helper loaded: my_helper
INFO - 2024-11-23 09:18:38 --> Database Driver Class Initialized
INFO - 2024-11-23 09:18:40 --> Upload Class Initialized
INFO - 2024-11-23 09:18:40 --> Email Class Initialized
INFO - 2024-11-23 09:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 09:18:40 --> Form Validation Class Initialized
INFO - 2024-11-23 09:18:40 --> Controller Class Initialized
INFO - 2024-11-23 14:48:40 --> Model "MainModel" initialized
INFO - 2024-11-23 14:48:40 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-23 14:48:40 --> Final output sent to browser
DEBUG - 2024-11-23 14:48:40 --> Total execution time: 2.7486
INFO - 2024-11-23 09:18:43 --> Config Class Initialized
INFO - 2024-11-23 09:18:43 --> Hooks Class Initialized
DEBUG - 2024-11-23 09:18:43 --> UTF-8 Support Enabled
INFO - 2024-11-23 09:18:43 --> Utf8 Class Initialized
INFO - 2024-11-23 09:18:43 --> URI Class Initialized
INFO - 2024-11-23 09:18:43 --> Router Class Initialized
INFO - 2024-11-23 09:18:43 --> Output Class Initialized
INFO - 2024-11-23 09:18:43 --> Security Class Initialized
DEBUG - 2024-11-23 09:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 09:18:43 --> Input Class Initialized
INFO - 2024-11-23 09:18:43 --> Language Class Initialized
ERROR - 2024-11-23 09:18:43 --> 404 Page Not Found: Faviconico/index
INFO - 2024-11-23 11:35:29 --> Config Class Initialized
INFO - 2024-11-23 11:35:29 --> Hooks Class Initialized
DEBUG - 2024-11-23 11:35:29 --> UTF-8 Support Enabled
INFO - 2024-11-23 11:35:29 --> Utf8 Class Initialized
INFO - 2024-11-23 11:35:29 --> URI Class Initialized
DEBUG - 2024-11-23 11:35:29 --> No URI present. Default controller set.
INFO - 2024-11-23 11:35:29 --> Router Class Initialized
INFO - 2024-11-23 11:35:29 --> Output Class Initialized
INFO - 2024-11-23 11:35:29 --> Security Class Initialized
DEBUG - 2024-11-23 11:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 11:35:29 --> Input Class Initialized
INFO - 2024-11-23 11:35:29 --> Language Class Initialized
INFO - 2024-11-23 11:35:29 --> Loader Class Initialized
INFO - 2024-11-23 11:35:29 --> Helper loaded: url_helper
INFO - 2024-11-23 11:35:29 --> Helper loaded: html_helper
INFO - 2024-11-23 11:35:29 --> Helper loaded: file_helper
INFO - 2024-11-23 11:35:29 --> Helper loaded: string_helper
INFO - 2024-11-23 11:35:29 --> Helper loaded: form_helper
INFO - 2024-11-23 11:35:29 --> Helper loaded: my_helper
INFO - 2024-11-23 11:35:29 --> Database Driver Class Initialized
INFO - 2024-11-23 11:35:31 --> Upload Class Initialized
INFO - 2024-11-23 11:35:31 --> Email Class Initialized
INFO - 2024-11-23 11:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 11:35:31 --> Form Validation Class Initialized
INFO - 2024-11-23 11:35:31 --> Controller Class Initialized
INFO - 2024-11-23 17:05:31 --> Model "MainModel" initialized
INFO - 2024-11-23 17:05:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-23 17:05:31 --> Final output sent to browser
DEBUG - 2024-11-23 17:05:31 --> Total execution time: 2.2467
INFO - 2024-11-23 11:35:34 --> Config Class Initialized
INFO - 2024-11-23 11:35:34 --> Hooks Class Initialized
DEBUG - 2024-11-23 11:35:34 --> UTF-8 Support Enabled
INFO - 2024-11-23 11:35:34 --> Utf8 Class Initialized
INFO - 2024-11-23 11:35:34 --> URI Class Initialized
INFO - 2024-11-23 11:35:34 --> Router Class Initialized
INFO - 2024-11-23 11:35:34 --> Output Class Initialized
INFO - 2024-11-23 11:35:34 --> Security Class Initialized
DEBUG - 2024-11-23 11:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 11:35:34 --> Input Class Initialized
INFO - 2024-11-23 11:35:34 --> Language Class Initialized
ERROR - 2024-11-23 11:35:34 --> 404 Page Not Found: Faviconico/index
INFO - 2024-11-23 12:48:27 --> Config Class Initialized
INFO - 2024-11-23 12:48:27 --> Hooks Class Initialized
DEBUG - 2024-11-23 12:48:27 --> UTF-8 Support Enabled
INFO - 2024-11-23 12:48:27 --> Utf8 Class Initialized
INFO - 2024-11-23 12:48:27 --> URI Class Initialized
DEBUG - 2024-11-23 12:48:27 --> No URI present. Default controller set.
INFO - 2024-11-23 12:48:27 --> Router Class Initialized
INFO - 2024-11-23 12:48:27 --> Output Class Initialized
INFO - 2024-11-23 12:48:27 --> Security Class Initialized
DEBUG - 2024-11-23 12:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-23 12:48:27 --> Input Class Initialized
INFO - 2024-11-23 12:48:27 --> Language Class Initialized
INFO - 2024-11-23 12:48:27 --> Loader Class Initialized
INFO - 2024-11-23 12:48:27 --> Helper loaded: url_helper
INFO - 2024-11-23 12:48:27 --> Helper loaded: html_helper
INFO - 2024-11-23 12:48:27 --> Helper loaded: file_helper
INFO - 2024-11-23 12:48:27 --> Helper loaded: string_helper
INFO - 2024-11-23 12:48:27 --> Helper loaded: form_helper
INFO - 2024-11-23 12:48:27 --> Helper loaded: my_helper
INFO - 2024-11-23 12:48:27 --> Database Driver Class Initialized
INFO - 2024-11-23 12:48:29 --> Upload Class Initialized
INFO - 2024-11-23 12:48:29 --> Email Class Initialized
INFO - 2024-11-23 12:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-23 12:48:29 --> Form Validation Class Initialized
INFO - 2024-11-23 12:48:29 --> Controller Class Initialized
INFO - 2024-11-23 18:18:29 --> Model "MainModel" initialized
INFO - 2024-11-23 18:18:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-23 18:18:29 --> Final output sent to browser
DEBUG - 2024-11-23 18:18:29 --> Total execution time: 2.2621
