<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-27 01:36:54 --> Config Class Initialized
INFO - 2024-11-27 01:36:54 --> Hooks Class Initialized
DEBUG - 2024-11-27 01:36:54 --> UTF-8 Support Enabled
INFO - 2024-11-27 01:36:54 --> Utf8 Class Initialized
INFO - 2024-11-27 01:36:54 --> URI Class Initialized
DEBUG - 2024-11-27 01:36:54 --> No URI present. Default controller set.
INFO - 2024-11-27 01:36:54 --> Router Class Initialized
INFO - 2024-11-27 01:36:54 --> Output Class Initialized
INFO - 2024-11-27 01:36:54 --> Security Class Initialized
DEBUG - 2024-11-27 01:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 01:36:54 --> Input Class Initialized
INFO - 2024-11-27 01:36:54 --> Language Class Initialized
INFO - 2024-11-27 01:36:54 --> Loader Class Initialized
INFO - 2024-11-27 01:36:54 --> Helper loaded: url_helper
INFO - 2024-11-27 01:36:54 --> Helper loaded: html_helper
INFO - 2024-11-27 01:36:54 --> Helper loaded: file_helper
INFO - 2024-11-27 01:36:54 --> Helper loaded: string_helper
INFO - 2024-11-27 01:36:54 --> Helper loaded: form_helper
INFO - 2024-11-27 01:36:54 --> Helper loaded: my_helper
INFO - 2024-11-27 01:36:54 --> Database Driver Class Initialized
INFO - 2024-11-27 01:36:56 --> Upload Class Initialized
INFO - 2024-11-27 01:36:56 --> Email Class Initialized
INFO - 2024-11-27 01:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 01:36:57 --> Form Validation Class Initialized
INFO - 2024-11-27 01:36:57 --> Controller Class Initialized
INFO - 2024-11-27 07:06:57 --> Model "MainModel" initialized
INFO - 2024-11-27 07:06:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 07:06:57 --> Final output sent to browser
DEBUG - 2024-11-27 07:06:57 --> Total execution time: 2.6923
INFO - 2024-11-27 05:24:13 --> Config Class Initialized
INFO - 2024-11-27 05:24:13 --> Hooks Class Initialized
DEBUG - 2024-11-27 05:24:13 --> UTF-8 Support Enabled
INFO - 2024-11-27 05:24:13 --> Utf8 Class Initialized
INFO - 2024-11-27 05:24:13 --> URI Class Initialized
INFO - 2024-11-27 05:24:13 --> Router Class Initialized
INFO - 2024-11-27 05:24:13 --> Output Class Initialized
INFO - 2024-11-27 05:24:13 --> Security Class Initialized
DEBUG - 2024-11-27 05:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 05:24:13 --> Input Class Initialized
INFO - 2024-11-27 05:24:13 --> Language Class Initialized
INFO - 2024-11-27 05:24:13 --> Loader Class Initialized
INFO - 2024-11-27 05:24:13 --> Helper loaded: url_helper
INFO - 2024-11-27 05:24:13 --> Helper loaded: html_helper
INFO - 2024-11-27 05:24:13 --> Helper loaded: file_helper
INFO - 2024-11-27 05:24:13 --> Helper loaded: string_helper
INFO - 2024-11-27 05:24:13 --> Helper loaded: form_helper
INFO - 2024-11-27 05:24:13 --> Helper loaded: my_helper
INFO - 2024-11-27 05:24:13 --> Database Driver Class Initialized
INFO - 2024-11-27 05:24:15 --> Upload Class Initialized
INFO - 2024-11-27 05:24:15 --> Email Class Initialized
INFO - 2024-11-27 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 05:24:15 --> Form Validation Class Initialized
INFO - 2024-11-27 05:24:15 --> Controller Class Initialized
INFO - 2024-11-27 10:54:15 --> Model "MainModel" initialized
INFO - 2024-11-27 10:54:15 --> Model "FrontofficeModel" initialized
INFO - 2024-11-27 10:54:15 --> Model "HotelAdminModel" initialized
INFO - 2024-11-27 10:54:15 --> Model "HouseKeepingModel" initialized
INFO - 2024-11-27 10:54:15 --> Model "FoodAdminModel" initialized
INFO - 2024-11-27 10:54:15 --> Model "SuperAdminModel" initialized
INFO - 2024-11-27 10:54:15 --> Helper loaded: notification_helper
INFO - 2024-11-27 10:54:15 --> Helper loaded: array_helper
INFO - 2024-11-27 05:24:15 --> Config Class Initialized
INFO - 2024-11-27 05:24:15 --> Hooks Class Initialized
DEBUG - 2024-11-27 05:24:15 --> UTF-8 Support Enabled
INFO - 2024-11-27 05:24:15 --> Utf8 Class Initialized
INFO - 2024-11-27 05:24:15 --> URI Class Initialized
DEBUG - 2024-11-27 05:24:15 --> No URI present. Default controller set.
INFO - 2024-11-27 05:24:15 --> Router Class Initialized
INFO - 2024-11-27 05:24:15 --> Output Class Initialized
INFO - 2024-11-27 05:24:15 --> Security Class Initialized
DEBUG - 2024-11-27 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 05:24:16 --> Input Class Initialized
INFO - 2024-11-27 05:24:16 --> Language Class Initialized
INFO - 2024-11-27 05:24:16 --> Loader Class Initialized
INFO - 2024-11-27 05:24:16 --> Helper loaded: url_helper
INFO - 2024-11-27 05:24:16 --> Helper loaded: html_helper
INFO - 2024-11-27 05:24:16 --> Helper loaded: file_helper
INFO - 2024-11-27 05:24:16 --> Helper loaded: string_helper
INFO - 2024-11-27 05:24:16 --> Helper loaded: form_helper
INFO - 2024-11-27 05:24:16 --> Helper loaded: my_helper
INFO - 2024-11-27 05:24:16 --> Database Driver Class Initialized
INFO - 2024-11-27 05:24:16 --> Config Class Initialized
INFO - 2024-11-27 05:24:16 --> Hooks Class Initialized
DEBUG - 2024-11-27 05:24:16 --> UTF-8 Support Enabled
INFO - 2024-11-27 05:24:16 --> Utf8 Class Initialized
INFO - 2024-11-27 05:24:16 --> URI Class Initialized
INFO - 2024-11-27 05:24:16 --> Router Class Initialized
INFO - 2024-11-27 05:24:16 --> Output Class Initialized
INFO - 2024-11-27 05:24:16 --> Security Class Initialized
DEBUG - 2024-11-27 05:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 05:24:16 --> Input Class Initialized
INFO - 2024-11-27 05:24:16 --> Language Class Initialized
ERROR - 2024-11-27 05:24:16 --> 404 Page Not Found: Faviconico/index
INFO - 2024-11-27 05:24:18 --> Upload Class Initialized
INFO - 2024-11-27 05:24:18 --> Email Class Initialized
INFO - 2024-11-27 05:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 05:24:18 --> Form Validation Class Initialized
INFO - 2024-11-27 05:24:18 --> Controller Class Initialized
INFO - 2024-11-27 10:54:18 --> Model "MainModel" initialized
INFO - 2024-11-27 10:54:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 10:54:18 --> Final output sent to browser
DEBUG - 2024-11-27 10:54:18 --> Total execution time: 2.1779
INFO - 2024-11-27 10:43:06 --> Config Class Initialized
INFO - 2024-11-27 10:43:06 --> Config Class Initialized
INFO - 2024-11-27 10:43:07 --> Hooks Class Initialized
INFO - 2024-11-27 10:43:07 --> Hooks Class Initialized
DEBUG - 2024-11-27 10:43:07 --> UTF-8 Support Enabled
DEBUG - 2024-11-27 10:43:07 --> UTF-8 Support Enabled
INFO - 2024-11-27 10:43:07 --> Utf8 Class Initialized
INFO - 2024-11-27 10:43:07 --> Utf8 Class Initialized
INFO - 2024-11-27 10:43:07 --> URI Class Initialized
INFO - 2024-11-27 10:43:07 --> URI Class Initialized
DEBUG - 2024-11-27 10:43:07 --> No URI present. Default controller set.
DEBUG - 2024-11-27 10:43:07 --> No URI present. Default controller set.
INFO - 2024-11-27 10:43:07 --> Router Class Initialized
INFO - 2024-11-27 10:43:07 --> Router Class Initialized
INFO - 2024-11-27 10:43:07 --> Output Class Initialized
INFO - 2024-11-27 10:43:07 --> Output Class Initialized
INFO - 2024-11-27 10:43:07 --> Security Class Initialized
INFO - 2024-11-27 10:43:07 --> Security Class Initialized
DEBUG - 2024-11-27 10:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-27 10:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 10:43:07 --> Input Class Initialized
INFO - 2024-11-27 10:43:07 --> Input Class Initialized
INFO - 2024-11-27 10:43:07 --> Language Class Initialized
INFO - 2024-11-27 10:43:07 --> Language Class Initialized
INFO - 2024-11-27 10:43:07 --> Loader Class Initialized
INFO - 2024-11-27 10:43:08 --> Loader Class Initialized
INFO - 2024-11-27 10:43:08 --> Helper loaded: url_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: url_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: html_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: html_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: file_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: file_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: string_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: string_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: form_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: form_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: my_helper
INFO - 2024-11-27 10:43:08 --> Helper loaded: my_helper
INFO - 2024-11-27 10:43:09 --> Database Driver Class Initialized
INFO - 2024-11-27 10:43:09 --> Database Driver Class Initialized
INFO - 2024-11-27 10:43:11 --> Upload Class Initialized
INFO - 2024-11-27 10:43:11 --> Upload Class Initialized
INFO - 2024-11-27 10:43:11 --> Email Class Initialized
INFO - 2024-11-27 10:43:11 --> Email Class Initialized
INFO - 2024-11-27 10:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 10:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 10:43:11 --> Form Validation Class Initialized
INFO - 2024-11-27 10:43:11 --> Form Validation Class Initialized
INFO - 2024-11-27 10:43:11 --> Controller Class Initialized
INFO - 2024-11-27 10:43:11 --> Controller Class Initialized
INFO - 2024-11-27 16:13:11 --> Model "MainModel" initialized
INFO - 2024-11-27 16:13:11 --> Model "MainModel" initialized
INFO - 2024-11-27 16:13:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 16:13:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 16:13:12 --> Final output sent to browser
INFO - 2024-11-27 16:13:12 --> Final output sent to browser
DEBUG - 2024-11-27 16:13:12 --> Total execution time: 6.0162
DEBUG - 2024-11-27 16:13:12 --> Total execution time: 6.0106
INFO - 2024-11-27 10:43:12 --> Config Class Initialized
INFO - 2024-11-27 10:43:12 --> Hooks Class Initialized
DEBUG - 2024-11-27 10:43:13 --> UTF-8 Support Enabled
INFO - 2024-11-27 10:43:13 --> Utf8 Class Initialized
INFO - 2024-11-27 10:43:13 --> URI Class Initialized
DEBUG - 2024-11-27 10:43:13 --> No URI present. Default controller set.
INFO - 2024-11-27 10:43:13 --> Router Class Initialized
INFO - 2024-11-27 10:43:13 --> Output Class Initialized
INFO - 2024-11-27 10:43:13 --> Security Class Initialized
DEBUG - 2024-11-27 10:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 10:43:13 --> Input Class Initialized
INFO - 2024-11-27 10:43:13 --> Language Class Initialized
INFO - 2024-11-27 10:43:13 --> Loader Class Initialized
INFO - 2024-11-27 10:43:13 --> Helper loaded: url_helper
INFO - 2024-11-27 10:43:13 --> Helper loaded: html_helper
INFO - 2024-11-27 10:43:13 --> Helper loaded: file_helper
INFO - 2024-11-27 10:43:13 --> Helper loaded: string_helper
INFO - 2024-11-27 10:43:13 --> Helper loaded: form_helper
INFO - 2024-11-27 10:43:13 --> Helper loaded: my_helper
INFO - 2024-11-27 10:43:13 --> Database Driver Class Initialized
INFO - 2024-11-27 10:43:15 --> Upload Class Initialized
INFO - 2024-11-27 10:43:15 --> Email Class Initialized
INFO - 2024-11-27 10:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 10:43:15 --> Form Validation Class Initialized
INFO - 2024-11-27 10:43:15 --> Controller Class Initialized
INFO - 2024-11-27 16:13:15 --> Model "MainModel" initialized
INFO - 2024-11-27 16:13:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 16:13:15 --> Final output sent to browser
DEBUG - 2024-11-27 16:13:15 --> Total execution time: 2.2007
INFO - 2024-11-27 10:43:15 --> Config Class Initialized
INFO - 2024-11-27 10:43:15 --> Hooks Class Initialized
DEBUG - 2024-11-27 10:43:15 --> UTF-8 Support Enabled
INFO - 2024-11-27 10:43:15 --> Utf8 Class Initialized
INFO - 2024-11-27 10:43:15 --> URI Class Initialized
DEBUG - 2024-11-27 10:43:15 --> No URI present. Default controller set.
INFO - 2024-11-27 10:43:15 --> Router Class Initialized
INFO - 2024-11-27 10:43:16 --> Output Class Initialized
INFO - 2024-11-27 10:43:16 --> Security Class Initialized
DEBUG - 2024-11-27 10:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 10:43:16 --> Input Class Initialized
INFO - 2024-11-27 10:43:16 --> Language Class Initialized
INFO - 2024-11-27 10:43:16 --> Loader Class Initialized
INFO - 2024-11-27 10:43:16 --> Helper loaded: url_helper
INFO - 2024-11-27 10:43:16 --> Helper loaded: html_helper
INFO - 2024-11-27 10:43:16 --> Helper loaded: file_helper
INFO - 2024-11-27 10:43:16 --> Helper loaded: string_helper
INFO - 2024-11-27 10:43:16 --> Helper loaded: form_helper
INFO - 2024-11-27 10:43:16 --> Helper loaded: my_helper
INFO - 2024-11-27 10:43:16 --> Database Driver Class Initialized
INFO - 2024-11-27 10:43:18 --> Upload Class Initialized
INFO - 2024-11-27 10:43:18 --> Email Class Initialized
INFO - 2024-11-27 10:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 10:43:18 --> Form Validation Class Initialized
INFO - 2024-11-27 10:43:18 --> Controller Class Initialized
INFO - 2024-11-27 16:13:18 --> Model "MainModel" initialized
INFO - 2024-11-27 16:13:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 16:13:18 --> Final output sent to browser
DEBUG - 2024-11-27 16:13:18 --> Total execution time: 2.1611
INFO - 2024-11-27 13:12:15 --> Config Class Initialized
INFO - 2024-11-27 13:12:15 --> Hooks Class Initialized
DEBUG - 2024-11-27 13:12:15 --> UTF-8 Support Enabled
INFO - 2024-11-27 13:12:15 --> Utf8 Class Initialized
INFO - 2024-11-27 13:12:15 --> URI Class Initialized
DEBUG - 2024-11-27 13:12:15 --> No URI present. Default controller set.
INFO - 2024-11-27 13:12:15 --> Router Class Initialized
INFO - 2024-11-27 13:12:15 --> Output Class Initialized
INFO - 2024-11-27 13:12:15 --> Security Class Initialized
DEBUG - 2024-11-27 13:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 13:12:15 --> Input Class Initialized
INFO - 2024-11-27 13:12:15 --> Language Class Initialized
INFO - 2024-11-27 13:12:15 --> Loader Class Initialized
INFO - 2024-11-27 13:12:15 --> Helper loaded: url_helper
INFO - 2024-11-27 13:12:15 --> Helper loaded: html_helper
INFO - 2024-11-27 13:12:15 --> Helper loaded: file_helper
INFO - 2024-11-27 13:12:15 --> Helper loaded: string_helper
INFO - 2024-11-27 13:12:15 --> Helper loaded: form_helper
INFO - 2024-11-27 13:12:15 --> Helper loaded: my_helper
INFO - 2024-11-27 13:12:15 --> Database Driver Class Initialized
INFO - 2024-11-27 13:12:18 --> Upload Class Initialized
INFO - 2024-11-27 13:12:18 --> Email Class Initialized
INFO - 2024-11-27 13:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 13:12:18 --> Form Validation Class Initialized
INFO - 2024-11-27 13:12:18 --> Controller Class Initialized
INFO - 2024-11-27 18:42:18 --> Model "MainModel" initialized
INFO - 2024-11-27 18:42:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 18:42:18 --> Final output sent to browser
DEBUG - 2024-11-27 18:42:18 --> Total execution time: 2.3406
INFO - 2024-11-27 17:54:18 --> Config Class Initialized
INFO - 2024-11-27 17:54:18 --> Hooks Class Initialized
DEBUG - 2024-11-27 17:54:18 --> UTF-8 Support Enabled
INFO - 2024-11-27 17:54:18 --> Utf8 Class Initialized
INFO - 2024-11-27 17:54:18 --> URI Class Initialized
DEBUG - 2024-11-27 17:54:18 --> No URI present. Default controller set.
INFO - 2024-11-27 17:54:18 --> Router Class Initialized
INFO - 2024-11-27 17:54:18 --> Output Class Initialized
INFO - 2024-11-27 17:54:18 --> Security Class Initialized
DEBUG - 2024-11-27 17:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 17:54:18 --> Input Class Initialized
INFO - 2024-11-27 17:54:18 --> Language Class Initialized
INFO - 2024-11-27 17:54:18 --> Loader Class Initialized
INFO - 2024-11-27 17:54:18 --> Helper loaded: url_helper
INFO - 2024-11-27 17:54:18 --> Helper loaded: html_helper
INFO - 2024-11-27 17:54:18 --> Helper loaded: file_helper
INFO - 2024-11-27 17:54:18 --> Helper loaded: string_helper
INFO - 2024-11-27 17:54:18 --> Helper loaded: form_helper
INFO - 2024-11-27 17:54:18 --> Helper loaded: my_helper
INFO - 2024-11-27 17:54:19 --> Database Driver Class Initialized
INFO - 2024-11-27 17:54:21 --> Upload Class Initialized
INFO - 2024-11-27 17:54:21 --> Email Class Initialized
INFO - 2024-11-27 17:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 17:54:21 --> Form Validation Class Initialized
INFO - 2024-11-27 17:54:21 --> Controller Class Initialized
INFO - 2024-11-27 23:24:21 --> Model "MainModel" initialized
INFO - 2024-11-27 23:24:21 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-27 23:24:21 --> Final output sent to browser
DEBUG - 2024-11-27 23:24:21 --> Total execution time: 2.2958
INFO - 2024-11-27 17:54:23 --> Config Class Initialized
INFO - 2024-11-27 17:54:23 --> Hooks Class Initialized
DEBUG - 2024-11-27 17:54:23 --> UTF-8 Support Enabled
INFO - 2024-11-27 17:54:23 --> Utf8 Class Initialized
INFO - 2024-11-27 17:54:23 --> URI Class Initialized
INFO - 2024-11-27 17:54:23 --> Router Class Initialized
INFO - 2024-11-27 17:54:23 --> Output Class Initialized
INFO - 2024-11-27 17:54:23 --> Security Class Initialized
DEBUG - 2024-11-27 17:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 17:54:23 --> Input Class Initialized
INFO - 2024-11-27 17:54:23 --> Language Class Initialized
ERROR - 2024-11-27 17:54:23 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-27 17:54:25 --> Config Class Initialized
INFO - 2024-11-27 17:54:25 --> Hooks Class Initialized
DEBUG - 2024-11-27 17:54:25 --> UTF-8 Support Enabled
INFO - 2024-11-27 17:54:25 --> Utf8 Class Initialized
INFO - 2024-11-27 17:54:25 --> URI Class Initialized
INFO - 2024-11-27 17:54:25 --> Router Class Initialized
INFO - 2024-11-27 17:54:25 --> Output Class Initialized
INFO - 2024-11-27 17:54:25 --> Security Class Initialized
DEBUG - 2024-11-27 17:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 17:54:25 --> Input Class Initialized
INFO - 2024-11-27 17:54:25 --> Language Class Initialized
INFO - 2024-11-27 17:54:25 --> Loader Class Initialized
INFO - 2024-11-27 17:54:25 --> Helper loaded: url_helper
INFO - 2024-11-27 17:54:25 --> Helper loaded: html_helper
INFO - 2024-11-27 17:54:25 --> Helper loaded: file_helper
INFO - 2024-11-27 17:54:25 --> Helper loaded: string_helper
INFO - 2024-11-27 17:54:25 --> Helper loaded: form_helper
INFO - 2024-11-27 17:54:25 --> Helper loaded: my_helper
INFO - 2024-11-27 17:54:25 --> Database Driver Class Initialized
INFO - 2024-11-27 17:54:27 --> Upload Class Initialized
INFO - 2024-11-27 17:54:27 --> Email Class Initialized
INFO - 2024-11-27 17:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-27 17:54:27 --> Form Validation Class Initialized
INFO - 2024-11-27 17:54:27 --> Controller Class Initialized
INFO - 2024-11-27 23:24:27 --> Model "MainModel" initialized
DEBUG - 2024-11-27 23:24:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-11-27 23:24:27 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-11-27 23:24:27 --> Final output sent to browser
DEBUG - 2024-11-27 23:24:27 --> Total execution time: 2.1644
INFO - 2024-11-27 17:54:29 --> Config Class Initialized
INFO - 2024-11-27 17:54:29 --> Hooks Class Initialized
DEBUG - 2024-11-27 17:54:29 --> UTF-8 Support Enabled
INFO - 2024-11-27 17:54:29 --> Utf8 Class Initialized
INFO - 2024-11-27 17:54:29 --> URI Class Initialized
INFO - 2024-11-27 17:54:29 --> Router Class Initialized
INFO - 2024-11-27 17:54:29 --> Output Class Initialized
INFO - 2024-11-27 17:54:29 --> Security Class Initialized
DEBUG - 2024-11-27 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 17:54:29 --> Input Class Initialized
INFO - 2024-11-27 17:54:29 --> Language Class Initialized
ERROR - 2024-11-27 17:54:29 --> 404 Page Not Found: Adstxt/index
INFO - 2024-11-27 19:50:58 --> Config Class Initialized
INFO - 2024-11-27 19:50:58 --> Hooks Class Initialized
DEBUG - 2024-11-27 19:50:58 --> UTF-8 Support Enabled
INFO - 2024-11-27 19:50:58 --> Utf8 Class Initialized
INFO - 2024-11-27 19:50:58 --> URI Class Initialized
INFO - 2024-11-27 19:50:58 --> Router Class Initialized
INFO - 2024-11-27 19:50:58 --> Output Class Initialized
INFO - 2024-11-27 19:50:58 --> Security Class Initialized
DEBUG - 2024-11-27 19:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-27 19:50:58 --> Input Class Initialized
INFO - 2024-11-27 19:50:58 --> Language Class Initialized
ERROR - 2024-11-27 19:50:58 --> 404 Page Not Found: Wp-content/index
