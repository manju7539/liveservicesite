<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-25 00:12:23 --> Model "MainModel" initialized
INFO - 2024-12-25 00:12:23 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-25 00:12:23 --> Final output sent to browser
DEBUG - 2024-12-25 00:12:23 --> Total execution time: 3.4839
INFO - 2024-12-25 04:49:00 --> Config Class Initialized
INFO - 2024-12-25 04:49:00 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:00 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:00 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:00 --> URI Class Initialized
DEBUG - 2024-12-25 04:49:00 --> No URI present. Default controller set.
INFO - 2024-12-25 04:49:00 --> Router Class Initialized
INFO - 2024-12-25 04:49:00 --> Output Class Initialized
INFO - 2024-12-25 04:49:00 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:00 --> Input Class Initialized
INFO - 2024-12-25 04:49:00 --> Language Class Initialized
INFO - 2024-12-25 04:49:00 --> Loader Class Initialized
INFO - 2024-12-25 04:49:00 --> Helper loaded: url_helper
INFO - 2024-12-25 04:49:00 --> Helper loaded: html_helper
INFO - 2024-12-25 04:49:00 --> Helper loaded: file_helper
INFO - 2024-12-25 04:49:00 --> Helper loaded: string_helper
INFO - 2024-12-25 04:49:00 --> Helper loaded: form_helper
INFO - 2024-12-25 04:49:00 --> Helper loaded: my_helper
INFO - 2024-12-25 04:49:00 --> Database Driver Class Initialized
INFO - 2024-12-25 04:49:02 --> Upload Class Initialized
INFO - 2024-12-25 04:49:02 --> Email Class Initialized
INFO - 2024-12-25 04:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-25 04:49:02 --> Form Validation Class Initialized
INFO - 2024-12-25 04:49:02 --> Controller Class Initialized
INFO - 2024-12-25 10:19:02 --> Model "MainModel" initialized
INFO - 2024-12-25 10:19:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-25 10:19:03 --> Final output sent to browser
DEBUG - 2024-12-25 10:19:03 --> Total execution time: 3.1551
INFO - 2024-12-25 04:49:03 --> Config Class Initialized
INFO - 2024-12-25 04:49:03 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:03 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:03 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:03 --> URI Class Initialized
INFO - 2024-12-25 04:49:03 --> Router Class Initialized
INFO - 2024-12-25 04:49:03 --> Output Class Initialized
INFO - 2024-12-25 04:49:03 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:03 --> Input Class Initialized
INFO - 2024-12-25 04:49:03 --> Language Class Initialized
ERROR - 2024-12-25 04:49:03 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-25 04:49:03 --> Config Class Initialized
INFO - 2024-12-25 04:49:03 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:03 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:03 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:03 --> URI Class Initialized
INFO - 2024-12-25 04:49:03 --> Router Class Initialized
INFO - 2024-12-25 04:49:03 --> Output Class Initialized
INFO - 2024-12-25 04:49:03 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:03 --> Input Class Initialized
INFO - 2024-12-25 04:49:03 --> Language Class Initialized
ERROR - 2024-12-25 04:49:03 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-25 04:49:04 --> Config Class Initialized
INFO - 2024-12-25 04:49:04 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:04 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:04 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:04 --> URI Class Initialized
DEBUG - 2024-12-25 04:49:04 --> No URI present. Default controller set.
INFO - 2024-12-25 04:49:04 --> Router Class Initialized
INFO - 2024-12-25 04:49:04 --> Output Class Initialized
INFO - 2024-12-25 04:49:04 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:04 --> Input Class Initialized
INFO - 2024-12-25 04:49:04 --> Language Class Initialized
INFO - 2024-12-25 04:49:04 --> Loader Class Initialized
INFO - 2024-12-25 04:49:04 --> Helper loaded: url_helper
INFO - 2024-12-25 04:49:04 --> Helper loaded: html_helper
INFO - 2024-12-25 04:49:04 --> Helper loaded: file_helper
INFO - 2024-12-25 04:49:04 --> Helper loaded: string_helper
INFO - 2024-12-25 04:49:04 --> Helper loaded: form_helper
INFO - 2024-12-25 04:49:04 --> Helper loaded: my_helper
INFO - 2024-12-25 04:49:04 --> Database Driver Class Initialized
INFO - 2024-12-25 04:49:06 --> Upload Class Initialized
INFO - 2024-12-25 04:49:06 --> Email Class Initialized
INFO - 2024-12-25 04:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-25 04:49:06 --> Form Validation Class Initialized
INFO - 2024-12-25 04:49:06 --> Controller Class Initialized
INFO - 2024-12-25 10:19:06 --> Model "MainModel" initialized
INFO - 2024-12-25 10:19:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-25 10:19:06 --> Final output sent to browser
DEBUG - 2024-12-25 10:19:06 --> Total execution time: 2.2170
INFO - 2024-12-25 04:49:06 --> Config Class Initialized
INFO - 2024-12-25 04:49:06 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:06 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:06 --> URI Class Initialized
INFO - 2024-12-25 04:49:06 --> Router Class Initialized
INFO - 2024-12-25 04:49:06 --> Output Class Initialized
INFO - 2024-12-25 04:49:06 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:06 --> Input Class Initialized
INFO - 2024-12-25 04:49:06 --> Language Class Initialized
ERROR - 2024-12-25 04:49:06 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-25 04:49:06 --> Config Class Initialized
INFO - 2024-12-25 04:49:06 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:06 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:06 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:06 --> URI Class Initialized
INFO - 2024-12-25 04:49:06 --> Router Class Initialized
INFO - 2024-12-25 04:49:06 --> Output Class Initialized
INFO - 2024-12-25 04:49:06 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:06 --> Input Class Initialized
INFO - 2024-12-25 04:49:06 --> Language Class Initialized
ERROR - 2024-12-25 04:49:06 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-25 04:49:07 --> Config Class Initialized
INFO - 2024-12-25 04:49:07 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:07 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:07 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:07 --> URI Class Initialized
INFO - 2024-12-25 04:49:07 --> Router Class Initialized
INFO - 2024-12-25 04:49:07 --> Output Class Initialized
INFO - 2024-12-25 04:49:07 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:07 --> Input Class Initialized
INFO - 2024-12-25 04:49:07 --> Language Class Initialized
ERROR - 2024-12-25 04:49:07 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-25 04:49:07 --> Config Class Initialized
INFO - 2024-12-25 04:49:07 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:07 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:07 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:07 --> URI Class Initialized
INFO - 2024-12-25 04:49:07 --> Router Class Initialized
INFO - 2024-12-25 04:49:07 --> Output Class Initialized
INFO - 2024-12-25 04:49:07 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:07 --> Input Class Initialized
INFO - 2024-12-25 04:49:07 --> Language Class Initialized
ERROR - 2024-12-25 04:49:07 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-25 04:49:07 --> Config Class Initialized
INFO - 2024-12-25 04:49:07 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:07 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:07 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:07 --> URI Class Initialized
INFO - 2024-12-25 04:49:07 --> Router Class Initialized
INFO - 2024-12-25 04:49:07 --> Output Class Initialized
INFO - 2024-12-25 04:49:07 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:07 --> Input Class Initialized
INFO - 2024-12-25 04:49:07 --> Language Class Initialized
ERROR - 2024-12-25 04:49:07 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-25 04:49:07 --> Config Class Initialized
INFO - 2024-12-25 04:49:07 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:07 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:07 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:07 --> URI Class Initialized
INFO - 2024-12-25 04:49:07 --> Router Class Initialized
INFO - 2024-12-25 04:49:07 --> Output Class Initialized
INFO - 2024-12-25 04:49:07 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:07 --> Input Class Initialized
INFO - 2024-12-25 04:49:07 --> Language Class Initialized
ERROR - 2024-12-25 04:49:07 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-25 04:49:08 --> Config Class Initialized
INFO - 2024-12-25 04:49:08 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:08 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:08 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:08 --> URI Class Initialized
INFO - 2024-12-25 04:49:08 --> Router Class Initialized
INFO - 2024-12-25 04:49:08 --> Output Class Initialized
INFO - 2024-12-25 04:49:08 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:08 --> Input Class Initialized
INFO - 2024-12-25 04:49:08 --> Language Class Initialized
ERROR - 2024-12-25 04:49:08 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-25 04:49:08 --> Config Class Initialized
INFO - 2024-12-25 04:49:08 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:08 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:08 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:08 --> URI Class Initialized
INFO - 2024-12-25 04:49:08 --> Router Class Initialized
INFO - 2024-12-25 04:49:08 --> Output Class Initialized
INFO - 2024-12-25 04:49:08 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:08 --> Input Class Initialized
INFO - 2024-12-25 04:49:08 --> Language Class Initialized
ERROR - 2024-12-25 04:49:08 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-25 04:49:08 --> Config Class Initialized
INFO - 2024-12-25 04:49:08 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:08 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:08 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:08 --> URI Class Initialized
INFO - 2024-12-25 04:49:08 --> Router Class Initialized
INFO - 2024-12-25 04:49:08 --> Output Class Initialized
INFO - 2024-12-25 04:49:08 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:08 --> Input Class Initialized
INFO - 2024-12-25 04:49:08 --> Language Class Initialized
ERROR - 2024-12-25 04:49:08 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-25 04:49:09 --> Config Class Initialized
INFO - 2024-12-25 04:49:09 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:09 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:09 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:09 --> URI Class Initialized
INFO - 2024-12-25 04:49:09 --> Router Class Initialized
INFO - 2024-12-25 04:49:09 --> Output Class Initialized
INFO - 2024-12-25 04:49:09 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:09 --> Input Class Initialized
INFO - 2024-12-25 04:49:09 --> Language Class Initialized
ERROR - 2024-12-25 04:49:09 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-25 04:49:09 --> Config Class Initialized
INFO - 2024-12-25 04:49:09 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:09 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:09 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:09 --> URI Class Initialized
INFO - 2024-12-25 04:49:09 --> Router Class Initialized
INFO - 2024-12-25 04:49:09 --> Output Class Initialized
INFO - 2024-12-25 04:49:09 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:09 --> Input Class Initialized
INFO - 2024-12-25 04:49:09 --> Language Class Initialized
ERROR - 2024-12-25 04:49:09 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-25 04:49:09 --> Config Class Initialized
INFO - 2024-12-25 04:49:09 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:09 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:09 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:09 --> URI Class Initialized
INFO - 2024-12-25 04:49:09 --> Router Class Initialized
INFO - 2024-12-25 04:49:09 --> Output Class Initialized
INFO - 2024-12-25 04:49:09 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:09 --> Input Class Initialized
INFO - 2024-12-25 04:49:09 --> Language Class Initialized
ERROR - 2024-12-25 04:49:09 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-25 04:49:10 --> Config Class Initialized
INFO - 2024-12-25 04:49:10 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:10 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:10 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:10 --> URI Class Initialized
INFO - 2024-12-25 04:49:10 --> Router Class Initialized
INFO - 2024-12-25 04:49:10 --> Output Class Initialized
INFO - 2024-12-25 04:49:10 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:10 --> Input Class Initialized
INFO - 2024-12-25 04:49:10 --> Language Class Initialized
ERROR - 2024-12-25 04:49:10 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-25 04:49:10 --> Config Class Initialized
INFO - 2024-12-25 04:49:10 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:10 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:10 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:10 --> URI Class Initialized
INFO - 2024-12-25 04:49:10 --> Router Class Initialized
INFO - 2024-12-25 04:49:10 --> Output Class Initialized
INFO - 2024-12-25 04:49:10 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:10 --> Input Class Initialized
INFO - 2024-12-25 04:49:10 --> Language Class Initialized
ERROR - 2024-12-25 04:49:10 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-25 04:49:10 --> Config Class Initialized
INFO - 2024-12-25 04:49:10 --> Hooks Class Initialized
DEBUG - 2024-12-25 04:49:10 --> UTF-8 Support Enabled
INFO - 2024-12-25 04:49:10 --> Utf8 Class Initialized
INFO - 2024-12-25 04:49:10 --> URI Class Initialized
INFO - 2024-12-25 04:49:10 --> Router Class Initialized
INFO - 2024-12-25 04:49:10 --> Output Class Initialized
INFO - 2024-12-25 04:49:10 --> Security Class Initialized
DEBUG - 2024-12-25 04:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 04:49:10 --> Input Class Initialized
INFO - 2024-12-25 04:49:10 --> Language Class Initialized
ERROR - 2024-12-25 04:49:10 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-12-25 15:15:45 --> Config Class Initialized
INFO - 2024-12-25 15:15:45 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:15:45 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:15:45 --> Utf8 Class Initialized
INFO - 2024-12-25 15:15:46 --> URI Class Initialized
INFO - 2024-12-25 15:15:46 --> Router Class Initialized
INFO - 2024-12-25 15:15:46 --> Output Class Initialized
INFO - 2024-12-25 15:15:46 --> Security Class Initialized
DEBUG - 2024-12-25 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:15:46 --> Input Class Initialized
INFO - 2024-12-25 15:15:46 --> Language Class Initialized
ERROR - 2024-12-25 15:15:46 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-25 15:15:47 --> Config Class Initialized
INFO - 2024-12-25 15:15:47 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:15:47 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:15:47 --> Utf8 Class Initialized
INFO - 2024-12-25 15:15:47 --> URI Class Initialized
DEBUG - 2024-12-25 15:15:47 --> No URI present. Default controller set.
INFO - 2024-12-25 15:15:47 --> Router Class Initialized
INFO - 2024-12-25 15:15:47 --> Output Class Initialized
INFO - 2024-12-25 15:15:47 --> Security Class Initialized
DEBUG - 2024-12-25 15:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:15:47 --> Input Class Initialized
INFO - 2024-12-25 15:15:47 --> Language Class Initialized
INFO - 2024-12-25 15:15:48 --> Loader Class Initialized
INFO - 2024-12-25 15:15:48 --> Helper loaded: url_helper
INFO - 2024-12-25 15:15:48 --> Helper loaded: html_helper
INFO - 2024-12-25 15:15:48 --> Helper loaded: file_helper
INFO - 2024-12-25 15:15:48 --> Helper loaded: string_helper
INFO - 2024-12-25 15:15:48 --> Helper loaded: form_helper
INFO - 2024-12-25 15:15:48 --> Helper loaded: my_helper
INFO - 2024-12-25 15:15:49 --> Database Driver Class Initialized
INFO - 2024-12-25 15:15:54 --> Upload Class Initialized
INFO - 2024-12-25 15:15:55 --> Email Class Initialized
INFO - 2024-12-25 15:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-25 15:15:58 --> Form Validation Class Initialized
INFO - 2024-12-25 15:15:58 --> Controller Class Initialized
INFO - 2024-12-25 20:46:00 --> Model "MainModel" initialized
INFO - 2024-12-25 20:46:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-25 20:46:00 --> Final output sent to browser
DEBUG - 2024-12-25 20:46:00 --> Total execution time: 13.2068
INFO - 2024-12-25 15:16:00 --> Config Class Initialized
INFO - 2024-12-25 15:16:00 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:00 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:00 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:00 --> URI Class Initialized
INFO - 2024-12-25 15:16:01 --> Router Class Initialized
INFO - 2024-12-25 15:16:01 --> Output Class Initialized
INFO - 2024-12-25 15:16:01 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:01 --> Input Class Initialized
INFO - 2024-12-25 15:16:01 --> Language Class Initialized
ERROR - 2024-12-25 15:16:01 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-25 15:16:02 --> Config Class Initialized
INFO - 2024-12-25 15:16:02 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:02 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:02 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:02 --> URI Class Initialized
INFO - 2024-12-25 15:16:02 --> Router Class Initialized
INFO - 2024-12-25 15:16:02 --> Output Class Initialized
INFO - 2024-12-25 15:16:02 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:02 --> Input Class Initialized
INFO - 2024-12-25 15:16:02 --> Language Class Initialized
ERROR - 2024-12-25 15:16:02 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-25 15:16:02 --> Config Class Initialized
INFO - 2024-12-25 15:16:02 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:02 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:02 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:02 --> URI Class Initialized
INFO - 2024-12-25 15:16:02 --> Router Class Initialized
INFO - 2024-12-25 15:16:02 --> Output Class Initialized
INFO - 2024-12-25 15:16:02 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:02 --> Input Class Initialized
INFO - 2024-12-25 15:16:02 --> Language Class Initialized
ERROR - 2024-12-25 15:16:02 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-25 15:16:02 --> Config Class Initialized
INFO - 2024-12-25 15:16:02 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:02 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:02 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:02 --> URI Class Initialized
INFO - 2024-12-25 15:16:02 --> Router Class Initialized
INFO - 2024-12-25 15:16:02 --> Output Class Initialized
INFO - 2024-12-25 15:16:02 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:02 --> Input Class Initialized
INFO - 2024-12-25 15:16:02 --> Language Class Initialized
ERROR - 2024-12-25 15:16:02 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-25 15:16:03 --> Config Class Initialized
INFO - 2024-12-25 15:16:03 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:03 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:03 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:03 --> URI Class Initialized
INFO - 2024-12-25 15:16:03 --> Router Class Initialized
INFO - 2024-12-25 15:16:03 --> Output Class Initialized
INFO - 2024-12-25 15:16:03 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:03 --> Input Class Initialized
INFO - 2024-12-25 15:16:03 --> Language Class Initialized
ERROR - 2024-12-25 15:16:03 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-25 15:16:03 --> Config Class Initialized
INFO - 2024-12-25 15:16:03 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:03 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:03 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:03 --> URI Class Initialized
INFO - 2024-12-25 15:16:03 --> Router Class Initialized
INFO - 2024-12-25 15:16:03 --> Output Class Initialized
INFO - 2024-12-25 15:16:03 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:03 --> Input Class Initialized
INFO - 2024-12-25 15:16:03 --> Language Class Initialized
ERROR - 2024-12-25 15:16:03 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-25 15:16:03 --> Config Class Initialized
INFO - 2024-12-25 15:16:03 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:03 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:03 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:03 --> URI Class Initialized
INFO - 2024-12-25 15:16:03 --> Router Class Initialized
INFO - 2024-12-25 15:16:03 --> Output Class Initialized
INFO - 2024-12-25 15:16:03 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:03 --> Input Class Initialized
INFO - 2024-12-25 15:16:03 --> Language Class Initialized
ERROR - 2024-12-25 15:16:03 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-25 15:16:04 --> Config Class Initialized
INFO - 2024-12-25 15:16:04 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:04 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:04 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:04 --> URI Class Initialized
INFO - 2024-12-25 15:16:04 --> Router Class Initialized
INFO - 2024-12-25 15:16:04 --> Output Class Initialized
INFO - 2024-12-25 15:16:04 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:04 --> Input Class Initialized
INFO - 2024-12-25 15:16:04 --> Language Class Initialized
ERROR - 2024-12-25 15:16:04 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-25 15:16:04 --> Config Class Initialized
INFO - 2024-12-25 15:16:04 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:04 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:04 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:04 --> URI Class Initialized
INFO - 2024-12-25 15:16:04 --> Router Class Initialized
INFO - 2024-12-25 15:16:04 --> Output Class Initialized
INFO - 2024-12-25 15:16:04 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:04 --> Input Class Initialized
INFO - 2024-12-25 15:16:04 --> Language Class Initialized
ERROR - 2024-12-25 15:16:04 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-25 15:16:04 --> Config Class Initialized
INFO - 2024-12-25 15:16:04 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:04 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:04 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:04 --> URI Class Initialized
INFO - 2024-12-25 15:16:04 --> Router Class Initialized
INFO - 2024-12-25 15:16:04 --> Output Class Initialized
INFO - 2024-12-25 15:16:04 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:04 --> Input Class Initialized
INFO - 2024-12-25 15:16:04 --> Language Class Initialized
ERROR - 2024-12-25 15:16:04 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-25 15:16:04 --> Config Class Initialized
INFO - 2024-12-25 15:16:04 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:04 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:04 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:04 --> URI Class Initialized
INFO - 2024-12-25 15:16:04 --> Router Class Initialized
INFO - 2024-12-25 15:16:04 --> Output Class Initialized
INFO - 2024-12-25 15:16:04 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:04 --> Input Class Initialized
INFO - 2024-12-25 15:16:04 --> Language Class Initialized
ERROR - 2024-12-25 15:16:04 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-25 15:16:05 --> Config Class Initialized
INFO - 2024-12-25 15:16:05 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:05 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:05 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:05 --> URI Class Initialized
INFO - 2024-12-25 15:16:05 --> Router Class Initialized
INFO - 2024-12-25 15:16:05 --> Output Class Initialized
INFO - 2024-12-25 15:16:05 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:05 --> Input Class Initialized
INFO - 2024-12-25 15:16:05 --> Language Class Initialized
ERROR - 2024-12-25 15:16:05 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-25 15:16:05 --> Config Class Initialized
INFO - 2024-12-25 15:16:05 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:05 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:05 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:05 --> URI Class Initialized
INFO - 2024-12-25 15:16:05 --> Router Class Initialized
INFO - 2024-12-25 15:16:05 --> Output Class Initialized
INFO - 2024-12-25 15:16:05 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:05 --> Input Class Initialized
INFO - 2024-12-25 15:16:05 --> Language Class Initialized
ERROR - 2024-12-25 15:16:05 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-25 15:16:05 --> Config Class Initialized
INFO - 2024-12-25 15:16:05 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:05 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:05 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:05 --> URI Class Initialized
INFO - 2024-12-25 15:16:05 --> Router Class Initialized
INFO - 2024-12-25 15:16:05 --> Output Class Initialized
INFO - 2024-12-25 15:16:05 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:06 --> Input Class Initialized
INFO - 2024-12-25 15:16:06 --> Language Class Initialized
ERROR - 2024-12-25 15:16:06 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-25 15:16:06 --> Config Class Initialized
INFO - 2024-12-25 15:16:06 --> Hooks Class Initialized
DEBUG - 2024-12-25 15:16:06 --> UTF-8 Support Enabled
INFO - 2024-12-25 15:16:06 --> Utf8 Class Initialized
INFO - 2024-12-25 15:16:06 --> URI Class Initialized
INFO - 2024-12-25 15:16:06 --> Router Class Initialized
INFO - 2024-12-25 15:16:06 --> Output Class Initialized
INFO - 2024-12-25 15:16:06 --> Security Class Initialized
DEBUG - 2024-12-25 15:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-25 15:16:06 --> Input Class Initialized
INFO - 2024-12-25 15:16:06 --> Language Class Initialized
ERROR - 2024-12-25 15:16:06 --> 404 Page Not Found: Sito/wp-includes
