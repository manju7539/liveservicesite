<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-21 03:03:24 --> Config Class Initialized
INFO - 2024-11-21 03:03:24 --> Hooks Class Initialized
DEBUG - 2024-11-21 03:03:24 --> UTF-8 Support Enabled
INFO - 2024-11-21 03:03:24 --> Utf8 Class Initialized
INFO - 2024-11-21 03:03:24 --> URI Class Initialized
DEBUG - 2024-11-21 03:03:24 --> No URI present. Default controller set.
INFO - 2024-11-21 03:03:24 --> Router Class Initialized
INFO - 2024-11-21 03:03:24 --> Output Class Initialized
INFO - 2024-11-21 03:03:24 --> Security Class Initialized
DEBUG - 2024-11-21 03:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 03:03:24 --> Input Class Initialized
INFO - 2024-11-21 03:03:24 --> Language Class Initialized
INFO - 2024-11-21 03:03:24 --> Loader Class Initialized
INFO - 2024-11-21 03:03:24 --> Helper loaded: url_helper
INFO - 2024-11-21 03:03:24 --> Helper loaded: html_helper
INFO - 2024-11-21 03:03:24 --> Helper loaded: file_helper
INFO - 2024-11-21 03:03:24 --> Helper loaded: string_helper
INFO - 2024-11-21 03:03:24 --> Helper loaded: form_helper
INFO - 2024-11-21 03:03:24 --> Helper loaded: my_helper
INFO - 2024-11-21 03:03:24 --> Database Driver Class Initialized
INFO - 2024-11-21 03:03:26 --> Upload Class Initialized
INFO - 2024-11-21 03:03:26 --> Email Class Initialized
INFO - 2024-11-21 03:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 03:03:26 --> Form Validation Class Initialized
INFO - 2024-11-21 03:03:26 --> Controller Class Initialized
INFO - 2024-11-21 08:33:26 --> Model "MainModel" initialized
INFO - 2024-11-21 08:33:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-21 08:33:26 --> Final output sent to browser
DEBUG - 2024-11-21 08:33:26 --> Total execution time: 2.3399
INFO - 2024-11-21 03:06:24 --> Config Class Initialized
INFO - 2024-11-21 03:06:24 --> Hooks Class Initialized
DEBUG - 2024-11-21 03:06:24 --> UTF-8 Support Enabled
INFO - 2024-11-21 03:06:24 --> Utf8 Class Initialized
INFO - 2024-11-21 03:06:24 --> URI Class Initialized
DEBUG - 2024-11-21 03:06:24 --> No URI present. Default controller set.
INFO - 2024-11-21 03:06:24 --> Router Class Initialized
INFO - 2024-11-21 03:06:24 --> Output Class Initialized
INFO - 2024-11-21 03:06:24 --> Security Class Initialized
DEBUG - 2024-11-21 03:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 03:06:24 --> Input Class Initialized
INFO - 2024-11-21 03:06:24 --> Language Class Initialized
INFO - 2024-11-21 03:06:24 --> Loader Class Initialized
INFO - 2024-11-21 03:06:24 --> Helper loaded: url_helper
INFO - 2024-11-21 03:06:24 --> Helper loaded: html_helper
INFO - 2024-11-21 03:06:24 --> Helper loaded: file_helper
INFO - 2024-11-21 03:06:24 --> Helper loaded: string_helper
INFO - 2024-11-21 03:06:24 --> Helper loaded: form_helper
INFO - 2024-11-21 03:06:24 --> Helper loaded: my_helper
INFO - 2024-11-21 03:06:24 --> Database Driver Class Initialized
INFO - 2024-11-21 03:06:26 --> Upload Class Initialized
INFO - 2024-11-21 03:06:26 --> Email Class Initialized
INFO - 2024-11-21 03:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 03:06:26 --> Form Validation Class Initialized
INFO - 2024-11-21 03:06:26 --> Controller Class Initialized
INFO - 2024-11-21 08:36:26 --> Model "MainModel" initialized
INFO - 2024-11-21 08:36:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-21 08:36:26 --> Final output sent to browser
DEBUG - 2024-11-21 08:36:26 --> Total execution time: 2.1704
INFO - 2024-11-21 03:06:27 --> Config Class Initialized
INFO - 2024-11-21 03:06:27 --> Hooks Class Initialized
DEBUG - 2024-11-21 03:06:27 --> UTF-8 Support Enabled
INFO - 2024-11-21 03:06:27 --> Utf8 Class Initialized
INFO - 2024-11-21 03:06:27 --> URI Class Initialized
DEBUG - 2024-11-21 03:06:27 --> No URI present. Default controller set.
INFO - 2024-11-21 03:06:27 --> Router Class Initialized
INFO - 2024-11-21 03:06:27 --> Output Class Initialized
INFO - 2024-11-21 03:06:27 --> Security Class Initialized
DEBUG - 2024-11-21 03:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 03:06:27 --> Input Class Initialized
INFO - 2024-11-21 03:06:27 --> Language Class Initialized
INFO - 2024-11-21 03:06:27 --> Loader Class Initialized
INFO - 2024-11-21 03:06:27 --> Helper loaded: url_helper
INFO - 2024-11-21 03:06:27 --> Helper loaded: html_helper
INFO - 2024-11-21 03:06:27 --> Helper loaded: file_helper
INFO - 2024-11-21 03:06:27 --> Helper loaded: string_helper
INFO - 2024-11-21 03:06:27 --> Helper loaded: form_helper
INFO - 2024-11-21 03:06:27 --> Helper loaded: my_helper
INFO - 2024-11-21 03:06:27 --> Database Driver Class Initialized
INFO - 2024-11-21 03:06:29 --> Upload Class Initialized
INFO - 2024-11-21 03:06:29 --> Email Class Initialized
INFO - 2024-11-21 03:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 03:06:29 --> Form Validation Class Initialized
INFO - 2024-11-21 03:06:29 --> Controller Class Initialized
INFO - 2024-11-21 08:36:29 --> Model "MainModel" initialized
INFO - 2024-11-21 08:36:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-21 08:36:29 --> Final output sent to browser
DEBUG - 2024-11-21 08:36:29 --> Total execution time: 2.1560
INFO - 2024-11-21 04:58:09 --> Config Class Initialized
INFO - 2024-11-21 04:58:09 --> Hooks Class Initialized
DEBUG - 2024-11-21 04:58:09 --> UTF-8 Support Enabled
INFO - 2024-11-21 04:58:09 --> Utf8 Class Initialized
INFO - 2024-11-21 04:58:09 --> URI Class Initialized
INFO - 2024-11-21 04:58:09 --> Router Class Initialized
INFO - 2024-11-21 04:58:09 --> Output Class Initialized
INFO - 2024-11-21 04:58:09 --> Security Class Initialized
DEBUG - 2024-11-21 04:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 04:58:09 --> Input Class Initialized
INFO - 2024-11-21 04:58:09 --> Language Class Initialized
ERROR - 2024-11-21 04:58:09 --> 404 Page Not Found: Wp-loginphp/index
INFO - 2024-11-21 11:13:45 --> Config Class Initialized
INFO - 2024-11-21 11:13:45 --> Config Class Initialized
INFO - 2024-11-21 11:13:45 --> Hooks Class Initialized
INFO - 2024-11-21 11:13:45 --> Hooks Class Initialized
DEBUG - 2024-11-21 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2024-11-21 11:13:45 --> UTF-8 Support Enabled
INFO - 2024-11-21 11:13:45 --> Utf8 Class Initialized
INFO - 2024-11-21 11:13:45 --> Utf8 Class Initialized
INFO - 2024-11-21 11:13:45 --> URI Class Initialized
INFO - 2024-11-21 11:13:45 --> URI Class Initialized
DEBUG - 2024-11-21 11:13:45 --> No URI present. Default controller set.
DEBUG - 2024-11-21 11:13:45 --> No URI present. Default controller set.
INFO - 2024-11-21 11:13:45 --> Router Class Initialized
INFO - 2024-11-21 11:13:45 --> Router Class Initialized
INFO - 2024-11-21 11:13:45 --> Output Class Initialized
INFO - 2024-11-21 11:13:45 --> Output Class Initialized
INFO - 2024-11-21 11:13:45 --> Security Class Initialized
INFO - 2024-11-21 11:13:45 --> Security Class Initialized
DEBUG - 2024-11-21 11:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-21 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 11:13:45 --> Input Class Initialized
INFO - 2024-11-21 11:13:45 --> Input Class Initialized
INFO - 2024-11-21 11:13:45 --> Language Class Initialized
INFO - 2024-11-21 11:13:45 --> Language Class Initialized
INFO - 2024-11-21 11:13:45 --> Loader Class Initialized
INFO - 2024-11-21 11:13:45 --> Loader Class Initialized
INFO - 2024-11-21 11:13:45 --> Helper loaded: url_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: url_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: html_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: html_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: file_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: file_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: string_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: string_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: form_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: form_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: my_helper
INFO - 2024-11-21 11:13:45 --> Helper loaded: my_helper
INFO - 2024-11-21 11:13:45 --> Database Driver Class Initialized
INFO - 2024-11-21 11:13:45 --> Database Driver Class Initialized
INFO - 2024-11-21 11:13:47 --> Upload Class Initialized
INFO - 2024-11-21 11:13:47 --> Upload Class Initialized
INFO - 2024-11-21 11:13:47 --> Email Class Initialized
INFO - 2024-11-21 11:13:47 --> Email Class Initialized
INFO - 2024-11-21 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 11:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 11:13:48 --> Form Validation Class Initialized
INFO - 2024-11-21 11:13:48 --> Form Validation Class Initialized
INFO - 2024-11-21 11:13:48 --> Controller Class Initialized
INFO - 2024-11-21 11:13:48 --> Controller Class Initialized
INFO - 2024-11-21 16:43:48 --> Model "MainModel" initialized
INFO - 2024-11-21 16:43:48 --> Model "MainModel" initialized
INFO - 2024-11-21 16:43:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-21 16:43:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-21 16:43:48 --> Final output sent to browser
INFO - 2024-11-21 16:43:48 --> Final output sent to browser
DEBUG - 2024-11-21 16:43:48 --> Total execution time: 2.9647
DEBUG - 2024-11-21 16:43:48 --> Total execution time: 2.9638
INFO - 2024-11-21 18:04:59 --> Config Class Initialized
INFO - 2024-11-21 18:04:59 --> Hooks Class Initialized
DEBUG - 2024-11-21 18:04:59 --> UTF-8 Support Enabled
INFO - 2024-11-21 18:04:59 --> Utf8 Class Initialized
INFO - 2024-11-21 18:04:59 --> URI Class Initialized
DEBUG - 2024-11-21 18:04:59 --> No URI present. Default controller set.
INFO - 2024-11-21 18:04:59 --> Router Class Initialized
INFO - 2024-11-21 18:04:59 --> Output Class Initialized
INFO - 2024-11-21 18:04:59 --> Security Class Initialized
DEBUG - 2024-11-21 18:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 18:04:59 --> Input Class Initialized
INFO - 2024-11-21 18:04:59 --> Language Class Initialized
INFO - 2024-11-21 18:04:59 --> Loader Class Initialized
INFO - 2024-11-21 18:04:59 --> Helper loaded: url_helper
INFO - 2024-11-21 18:04:59 --> Helper loaded: html_helper
INFO - 2024-11-21 18:04:59 --> Helper loaded: file_helper
INFO - 2024-11-21 18:04:59 --> Helper loaded: string_helper
INFO - 2024-11-21 18:05:00 --> Helper loaded: form_helper
INFO - 2024-11-21 18:05:00 --> Helper loaded: my_helper
INFO - 2024-11-21 18:05:00 --> Database Driver Class Initialized
INFO - 2024-11-21 18:05:02 --> Upload Class Initialized
INFO - 2024-11-21 18:05:02 --> Email Class Initialized
INFO - 2024-11-21 18:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 18:05:02 --> Form Validation Class Initialized
INFO - 2024-11-21 18:05:02 --> Controller Class Initialized
INFO - 2024-11-21 23:35:02 --> Model "MainModel" initialized
INFO - 2024-11-21 23:35:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-21 23:35:02 --> Final output sent to browser
DEBUG - 2024-11-21 23:35:02 --> Total execution time: 2.6107
INFO - 2024-11-21 18:22:01 --> Config Class Initialized
INFO - 2024-11-21 18:22:01 --> Hooks Class Initialized
DEBUG - 2024-11-21 18:22:01 --> UTF-8 Support Enabled
INFO - 2024-11-21 18:22:01 --> Utf8 Class Initialized
INFO - 2024-11-21 18:22:01 --> URI Class Initialized
DEBUG - 2024-11-21 18:22:01 --> No URI present. Default controller set.
INFO - 2024-11-21 18:22:02 --> Router Class Initialized
INFO - 2024-11-21 18:22:02 --> Output Class Initialized
INFO - 2024-11-21 18:22:02 --> Security Class Initialized
DEBUG - 2024-11-21 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 18:22:02 --> Input Class Initialized
INFO - 2024-11-21 18:22:02 --> Language Class Initialized
INFO - 2024-11-21 18:22:02 --> Loader Class Initialized
INFO - 2024-11-21 18:22:02 --> Helper loaded: url_helper
INFO - 2024-11-21 18:22:02 --> Helper loaded: html_helper
INFO - 2024-11-21 18:22:02 --> Helper loaded: file_helper
INFO - 2024-11-21 18:22:02 --> Helper loaded: string_helper
INFO - 2024-11-21 18:22:02 --> Helper loaded: form_helper
INFO - 2024-11-21 18:22:02 --> Helper loaded: my_helper
INFO - 2024-11-21 18:22:02 --> Database Driver Class Initialized
INFO - 2024-11-21 18:22:04 --> Upload Class Initialized
INFO - 2024-11-21 18:22:04 --> Email Class Initialized
INFO - 2024-11-21 18:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 18:22:04 --> Form Validation Class Initialized
INFO - 2024-11-21 18:22:04 --> Controller Class Initialized
INFO - 2024-11-21 23:52:04 --> Model "MainModel" initialized
INFO - 2024-11-21 23:52:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-21 23:52:04 --> Final output sent to browser
DEBUG - 2024-11-21 23:52:04 --> Total execution time: 2.3545
INFO - 2024-11-21 19:01:18 --> Config Class Initialized
INFO - 2024-11-21 19:01:18 --> Hooks Class Initialized
DEBUG - 2024-11-21 19:01:18 --> UTF-8 Support Enabled
INFO - 2024-11-21 19:01:18 --> Utf8 Class Initialized
INFO - 2024-11-21 19:01:18 --> URI Class Initialized
DEBUG - 2024-11-21 19:01:18 --> No URI present. Default controller set.
INFO - 2024-11-21 19:01:18 --> Router Class Initialized
INFO - 2024-11-21 19:01:18 --> Output Class Initialized
INFO - 2024-11-21 19:01:18 --> Security Class Initialized
DEBUG - 2024-11-21 19:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 19:01:18 --> Input Class Initialized
INFO - 2024-11-21 19:01:18 --> Language Class Initialized
INFO - 2024-11-21 19:01:18 --> Loader Class Initialized
INFO - 2024-11-21 19:01:18 --> Helper loaded: url_helper
INFO - 2024-11-21 19:01:18 --> Helper loaded: html_helper
INFO - 2024-11-21 19:01:18 --> Helper loaded: file_helper
INFO - 2024-11-21 19:01:18 --> Helper loaded: string_helper
INFO - 2024-11-21 19:01:18 --> Helper loaded: form_helper
INFO - 2024-11-21 19:01:18 --> Helper loaded: my_helper
INFO - 2024-11-21 19:01:18 --> Database Driver Class Initialized
INFO - 2024-11-21 19:01:20 --> Upload Class Initialized
INFO - 2024-11-21 19:01:20 --> Email Class Initialized
INFO - 2024-11-21 19:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-21 19:01:20 --> Form Validation Class Initialized
INFO - 2024-11-21 19:01:20 --> Controller Class Initialized
INFO - 2024-11-21 22:01:41 --> Config Class Initialized
INFO - 2024-11-21 22:01:41 --> Hooks Class Initialized
DEBUG - 2024-11-21 22:01:41 --> UTF-8 Support Enabled
INFO - 2024-11-21 22:01:41 --> Utf8 Class Initialized
INFO - 2024-11-21 22:01:41 --> URI Class Initialized
INFO - 2024-11-21 22:01:41 --> Router Class Initialized
INFO - 2024-11-21 22:01:41 --> Output Class Initialized
INFO - 2024-11-21 22:01:41 --> Security Class Initialized
DEBUG - 2024-11-21 22:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-21 22:01:41 --> Input Class Initialized
INFO - 2024-11-21 22:01:41 --> Language Class Initialized
ERROR - 2024-11-21 22:01:41 --> 404 Page Not Found: Robotstxt/index
