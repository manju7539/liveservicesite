<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-13 04:31:57 --> Config Class Initialized
INFO - 2025-01-13 04:31:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 04:31:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 04:31:57 --> Utf8 Class Initialized
INFO - 2025-01-13 04:31:57 --> URI Class Initialized
DEBUG - 2025-01-13 04:31:57 --> No URI present. Default controller set.
INFO - 2025-01-13 04:31:57 --> Router Class Initialized
INFO - 2025-01-13 04:31:57 --> Output Class Initialized
INFO - 2025-01-13 04:31:57 --> Security Class Initialized
DEBUG - 2025-01-13 04:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 04:31:57 --> Input Class Initialized
INFO - 2025-01-13 04:31:57 --> Language Class Initialized
INFO - 2025-01-13 04:31:57 --> Loader Class Initialized
INFO - 2025-01-13 04:31:57 --> Helper loaded: url_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: html_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: file_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: string_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: form_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: my_helper
INFO - 2025-01-13 04:31:57 --> Database Driver Class Initialized
INFO - 2025-01-13 04:31:57 --> Upload Class Initialized
INFO - 2025-01-13 04:31:57 --> Email Class Initialized
INFO - 2025-01-13 04:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 04:31:57 --> Form Validation Class Initialized
INFO - 2025-01-13 04:31:57 --> Controller Class Initialized
INFO - 2025-01-13 10:01:57 --> Model "MainModel" initialized
INFO - 2025-01-13 10:01:57 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-13 10:01:57 --> Final output sent to browser
DEBUG - 2025-01-13 10:01:57 --> Total execution time: 0.1161
INFO - 2025-01-13 04:31:57 --> Config Class Initialized
INFO - 2025-01-13 04:31:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 04:31:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 04:31:57 --> Utf8 Class Initialized
INFO - 2025-01-13 04:31:57 --> URI Class Initialized
DEBUG - 2025-01-13 04:31:57 --> No URI present. Default controller set.
INFO - 2025-01-13 04:31:57 --> Router Class Initialized
INFO - 2025-01-13 04:31:57 --> Output Class Initialized
INFO - 2025-01-13 04:31:57 --> Security Class Initialized
DEBUG - 2025-01-13 04:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 04:31:57 --> Input Class Initialized
INFO - 2025-01-13 04:31:57 --> Language Class Initialized
INFO - 2025-01-13 04:31:57 --> Loader Class Initialized
INFO - 2025-01-13 04:31:57 --> Helper loaded: url_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: html_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: file_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: string_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: form_helper
INFO - 2025-01-13 04:31:57 --> Helper loaded: my_helper
INFO - 2025-01-13 04:31:57 --> Database Driver Class Initialized
INFO - 2025-01-13 04:31:57 --> Upload Class Initialized
INFO - 2025-01-13 04:31:57 --> Email Class Initialized
INFO - 2025-01-13 04:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 04:31:57 --> Form Validation Class Initialized
INFO - 2025-01-13 04:31:57 --> Controller Class Initialized
INFO - 2025-01-13 10:01:57 --> Model "MainModel" initialized
INFO - 2025-01-13 10:01:57 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-13 10:01:57 --> Final output sent to browser
DEBUG - 2025-01-13 10:01:57 --> Total execution time: 0.0328
INFO - 2025-01-13 04:39:31 --> Config Class Initialized
INFO - 2025-01-13 04:39:31 --> Hooks Class Initialized
DEBUG - 2025-01-13 04:39:31 --> UTF-8 Support Enabled
INFO - 2025-01-13 04:39:31 --> Utf8 Class Initialized
INFO - 2025-01-13 04:39:31 --> URI Class Initialized
INFO - 2025-01-13 04:39:31 --> Router Class Initialized
INFO - 2025-01-13 04:39:31 --> Output Class Initialized
INFO - 2025-01-13 04:39:31 --> Security Class Initialized
DEBUG - 2025-01-13 04:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 04:39:31 --> Input Class Initialized
INFO - 2025-01-13 04:39:31 --> Language Class Initialized
INFO - 2025-01-13 04:39:31 --> Loader Class Initialized
INFO - 2025-01-13 04:39:31 --> Helper loaded: url_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: html_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: file_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: string_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: form_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: my_helper
INFO - 2025-01-13 04:39:31 --> Database Driver Class Initialized
INFO - 2025-01-13 04:39:31 --> Upload Class Initialized
INFO - 2025-01-13 04:39:31 --> Email Class Initialized
INFO - 2025-01-13 04:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 04:39:31 --> Form Validation Class Initialized
INFO - 2025-01-13 04:39:31 --> Controller Class Initialized
INFO - 2025-01-13 10:09:31 --> Model "MainModel" initialized
INFO - 2025-01-13 04:39:31 --> Config Class Initialized
INFO - 2025-01-13 04:39:31 --> Hooks Class Initialized
DEBUG - 2025-01-13 04:39:31 --> UTF-8 Support Enabled
INFO - 2025-01-13 04:39:31 --> Utf8 Class Initialized
INFO - 2025-01-13 04:39:31 --> URI Class Initialized
DEBUG - 2025-01-13 04:39:31 --> No URI present. Default controller set.
INFO - 2025-01-13 04:39:31 --> Router Class Initialized
INFO - 2025-01-13 04:39:31 --> Output Class Initialized
INFO - 2025-01-13 04:39:31 --> Security Class Initialized
DEBUG - 2025-01-13 04:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 04:39:31 --> Input Class Initialized
INFO - 2025-01-13 04:39:31 --> Language Class Initialized
INFO - 2025-01-13 04:39:31 --> Loader Class Initialized
INFO - 2025-01-13 04:39:31 --> Helper loaded: url_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: html_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: file_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: string_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: form_helper
INFO - 2025-01-13 04:39:31 --> Helper loaded: my_helper
INFO - 2025-01-13 04:39:31 --> Database Driver Class Initialized
INFO - 2025-01-13 04:39:31 --> Upload Class Initialized
INFO - 2025-01-13 04:39:31 --> Email Class Initialized
INFO - 2025-01-13 04:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 04:39:31 --> Form Validation Class Initialized
INFO - 2025-01-13 04:39:31 --> Controller Class Initialized
INFO - 2025-01-13 10:09:31 --> Model "MainModel" initialized
INFO - 2025-01-13 10:09:31 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-13 10:09:31 --> Final output sent to browser
DEBUG - 2025-01-13 10:09:31 --> Total execution time: 0.0377
INFO - 2025-01-13 07:01:26 --> Config Class Initialized
INFO - 2025-01-13 07:01:26 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:01:26 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:01:26 --> Utf8 Class Initialized
INFO - 2025-01-13 07:01:26 --> URI Class Initialized
DEBUG - 2025-01-13 07:01:26 --> No URI present. Default controller set.
INFO - 2025-01-13 07:01:26 --> Router Class Initialized
INFO - 2025-01-13 07:01:26 --> Output Class Initialized
INFO - 2025-01-13 07:01:26 --> Security Class Initialized
DEBUG - 2025-01-13 07:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:01:26 --> Input Class Initialized
INFO - 2025-01-13 07:01:26 --> Language Class Initialized
INFO - 2025-01-13 07:01:26 --> Loader Class Initialized
INFO - 2025-01-13 07:01:26 --> Helper loaded: url_helper
INFO - 2025-01-13 07:01:26 --> Helper loaded: html_helper
INFO - 2025-01-13 07:01:26 --> Helper loaded: file_helper
INFO - 2025-01-13 07:01:26 --> Helper loaded: string_helper
INFO - 2025-01-13 07:01:26 --> Helper loaded: form_helper
INFO - 2025-01-13 07:01:26 --> Helper loaded: my_helper
INFO - 2025-01-13 07:01:26 --> Database Driver Class Initialized
INFO - 2025-01-13 07:01:26 --> Upload Class Initialized
INFO - 2025-01-13 07:01:26 --> Email Class Initialized
INFO - 2025-01-13 07:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:01:26 --> Form Validation Class Initialized
INFO - 2025-01-13 07:01:26 --> Controller Class Initialized
INFO - 2025-01-13 12:31:26 --> Model "MainModel" initialized
INFO - 2025-01-13 12:31:26 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-13 12:31:26 --> Final output sent to browser
DEBUG - 2025-01-13 12:31:26 --> Total execution time: 0.0396
INFO - 2025-01-13 07:01:58 --> Config Class Initialized
INFO - 2025-01-13 07:01:58 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:01:58 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:01:58 --> Utf8 Class Initialized
INFO - 2025-01-13 07:01:58 --> URI Class Initialized
INFO - 2025-01-13 07:01:58 --> Router Class Initialized
INFO - 2025-01-13 07:01:58 --> Output Class Initialized
INFO - 2025-01-13 07:01:58 --> Security Class Initialized
DEBUG - 2025-01-13 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:01:58 --> Input Class Initialized
INFO - 2025-01-13 07:01:58 --> Language Class Initialized
INFO - 2025-01-13 07:01:58 --> Loader Class Initialized
INFO - 2025-01-13 07:01:58 --> Helper loaded: url_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: html_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: file_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: string_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: form_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: my_helper
INFO - 2025-01-13 07:01:58 --> Database Driver Class Initialized
INFO - 2025-01-13 07:01:58 --> Upload Class Initialized
INFO - 2025-01-13 07:01:58 --> Email Class Initialized
INFO - 2025-01-13 07:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:01:58 --> Form Validation Class Initialized
INFO - 2025-01-13 07:01:58 --> Controller Class Initialized
INFO - 2025-01-13 12:31:58 --> Model "MainModel" initialized
INFO - 2025-01-13 07:01:58 --> Config Class Initialized
INFO - 2025-01-13 07:01:58 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:01:58 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:01:58 --> Utf8 Class Initialized
INFO - 2025-01-13 07:01:58 --> URI Class Initialized
INFO - 2025-01-13 07:01:58 --> Router Class Initialized
INFO - 2025-01-13 07:01:58 --> Output Class Initialized
INFO - 2025-01-13 07:01:58 --> Security Class Initialized
DEBUG - 2025-01-13 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:01:58 --> Input Class Initialized
INFO - 2025-01-13 07:01:58 --> Language Class Initialized
INFO - 2025-01-13 07:01:58 --> Loader Class Initialized
INFO - 2025-01-13 07:01:58 --> Helper loaded: url_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: html_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: file_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: string_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: form_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: my_helper
INFO - 2025-01-13 07:01:58 --> Database Driver Class Initialized
INFO - 2025-01-13 07:01:58 --> Upload Class Initialized
INFO - 2025-01-13 07:01:58 --> Email Class Initialized
INFO - 2025-01-13 07:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:01:58 --> Form Validation Class Initialized
INFO - 2025-01-13 07:01:58 --> Controller Class Initialized
INFO - 2025-01-13 12:31:58 --> Model "MainModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "FrontofficeModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "HotelAdminModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "FoodAdminModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "SuperAdminModel" initialized
INFO - 2025-01-13 12:31:58 --> Helper loaded: notification_helper
INFO - 2025-01-13 12:31:58 --> Helper loaded: array_helper
INFO - 2025-01-13 12:31:58 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-13 12:31:58 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-13 12:31:58 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-13 12:31:58 --> Final output sent to browser
DEBUG - 2025-01-13 12:31:58 --> Total execution time: 0.2579
INFO - 2025-01-13 07:01:58 --> Config Class Initialized
INFO - 2025-01-13 07:01:58 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:01:58 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:01:58 --> Utf8 Class Initialized
INFO - 2025-01-13 07:01:58 --> URI Class Initialized
INFO - 2025-01-13 07:01:58 --> Router Class Initialized
INFO - 2025-01-13 07:01:58 --> Output Class Initialized
INFO - 2025-01-13 07:01:58 --> Security Class Initialized
DEBUG - 2025-01-13 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:01:58 --> Input Class Initialized
INFO - 2025-01-13 07:01:58 --> Language Class Initialized
ERROR - 2025-01-13 07:01:58 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-13 07:01:58 --> Config Class Initialized
INFO - 2025-01-13 07:01:58 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:01:58 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:01:58 --> Utf8 Class Initialized
INFO - 2025-01-13 07:01:58 --> URI Class Initialized
INFO - 2025-01-13 07:01:58 --> Router Class Initialized
INFO - 2025-01-13 07:01:58 --> Output Class Initialized
INFO - 2025-01-13 07:01:58 --> Security Class Initialized
DEBUG - 2025-01-13 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:01:58 --> Input Class Initialized
INFO - 2025-01-13 07:01:58 --> Language Class Initialized
ERROR - 2025-01-13 07:01:58 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-13 07:01:58 --> Config Class Initialized
INFO - 2025-01-13 07:01:58 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:01:58 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:01:58 --> Utf8 Class Initialized
INFO - 2025-01-13 07:01:58 --> URI Class Initialized
INFO - 2025-01-13 07:01:58 --> Router Class Initialized
INFO - 2025-01-13 07:01:58 --> Output Class Initialized
INFO - 2025-01-13 07:01:58 --> Security Class Initialized
DEBUG - 2025-01-13 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:01:58 --> Input Class Initialized
INFO - 2025-01-13 07:01:58 --> Language Class Initialized
ERROR - 2025-01-13 07:01:58 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-13 07:01:58 --> Config Class Initialized
INFO - 2025-01-13 07:01:58 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:01:58 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:01:58 --> Utf8 Class Initialized
INFO - 2025-01-13 07:01:58 --> URI Class Initialized
INFO - 2025-01-13 07:01:58 --> Router Class Initialized
INFO - 2025-01-13 07:01:58 --> Output Class Initialized
INFO - 2025-01-13 07:01:58 --> Security Class Initialized
DEBUG - 2025-01-13 07:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:01:58 --> Input Class Initialized
INFO - 2025-01-13 07:01:58 --> Language Class Initialized
INFO - 2025-01-13 07:01:58 --> Loader Class Initialized
INFO - 2025-01-13 07:01:58 --> Helper loaded: url_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: html_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: file_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: string_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: form_helper
INFO - 2025-01-13 07:01:58 --> Helper loaded: my_helper
INFO - 2025-01-13 07:01:58 --> Database Driver Class Initialized
INFO - 2025-01-13 07:01:58 --> Upload Class Initialized
INFO - 2025-01-13 07:01:58 --> Email Class Initialized
INFO - 2025-01-13 07:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:01:58 --> Form Validation Class Initialized
INFO - 2025-01-13 07:01:58 --> Controller Class Initialized
INFO - 2025-01-13 12:31:58 --> Model "MainModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "FrontofficeModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "HotelAdminModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "FoodAdminModel" initialized
INFO - 2025-01-13 12:31:58 --> Model "SuperAdminModel" initialized
INFO - 2025-01-13 12:31:58 --> Helper loaded: notification_helper
INFO - 2025-01-13 12:31:58 --> Helper loaded: array_helper
INFO - 2025-01-13 12:31:58 --> Final output sent to browser
DEBUG - 2025-01-13 12:31:58 --> Total execution time: 0.0319
INFO - 2025-01-13 07:02:04 --> Config Class Initialized
INFO - 2025-01-13 07:02:04 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:04 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:04 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:04 --> URI Class Initialized
INFO - 2025-01-13 07:02:04 --> Router Class Initialized
INFO - 2025-01-13 07:02:04 --> Output Class Initialized
INFO - 2025-01-13 07:02:04 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:04 --> Input Class Initialized
INFO - 2025-01-13 07:02:04 --> Language Class Initialized
INFO - 2025-01-13 07:02:04 --> Loader Class Initialized
INFO - 2025-01-13 07:02:04 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:04 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:04 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:04 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:04 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:04 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:04 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:04 --> Upload Class Initialized
INFO - 2025-01-13 07:02:04 --> Email Class Initialized
INFO - 2025-01-13 07:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:04 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:04 --> Controller Class Initialized
INFO - 2025-01-13 12:32:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:04 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:04 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:09 --> Config Class Initialized
INFO - 2025-01-13 07:02:09 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:09 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:09 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:09 --> URI Class Initialized
INFO - 2025-01-13 07:02:09 --> Router Class Initialized
INFO - 2025-01-13 07:02:09 --> Output Class Initialized
INFO - 2025-01-13 07:02:09 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:09 --> Input Class Initialized
INFO - 2025-01-13 07:02:09 --> Language Class Initialized
INFO - 2025-01-13 07:02:09 --> Loader Class Initialized
INFO - 2025-01-13 07:02:09 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:09 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:09 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:09 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:09 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:09 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:09 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:09 --> Upload Class Initialized
INFO - 2025-01-13 07:02:09 --> Email Class Initialized
INFO - 2025-01-13 07:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:09 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:09 --> Controller Class Initialized
INFO - 2025-01-13 12:32:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:09 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:09 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:14 --> Config Class Initialized
INFO - 2025-01-13 07:02:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:14 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:14 --> URI Class Initialized
INFO - 2025-01-13 07:02:14 --> Router Class Initialized
INFO - 2025-01-13 07:02:14 --> Output Class Initialized
INFO - 2025-01-13 07:02:14 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:14 --> Input Class Initialized
INFO - 2025-01-13 07:02:14 --> Language Class Initialized
INFO - 2025-01-13 07:02:14 --> Loader Class Initialized
INFO - 2025-01-13 07:02:14 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:14 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:14 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:14 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:14 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:14 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:14 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:14 --> Upload Class Initialized
INFO - 2025-01-13 07:02:14 --> Email Class Initialized
INFO - 2025-01-13 07:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:14 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:14 --> Controller Class Initialized
INFO - 2025-01-13 12:32:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:14 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:14 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:19 --> Config Class Initialized
INFO - 2025-01-13 07:02:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:19 --> URI Class Initialized
INFO - 2025-01-13 07:02:19 --> Router Class Initialized
INFO - 2025-01-13 07:02:19 --> Output Class Initialized
INFO - 2025-01-13 07:02:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:19 --> Input Class Initialized
INFO - 2025-01-13 07:02:19 --> Language Class Initialized
INFO - 2025-01-13 07:02:19 --> Loader Class Initialized
INFO - 2025-01-13 07:02:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:19 --> Upload Class Initialized
INFO - 2025-01-13 07:02:19 --> Email Class Initialized
INFO - 2025-01-13 07:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:19 --> Controller Class Initialized
INFO - 2025-01-13 12:32:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:19 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:24 --> Config Class Initialized
INFO - 2025-01-13 07:02:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:24 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:24 --> URI Class Initialized
INFO - 2025-01-13 07:02:24 --> Router Class Initialized
INFO - 2025-01-13 07:02:24 --> Output Class Initialized
INFO - 2025-01-13 07:02:24 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:24 --> Input Class Initialized
INFO - 2025-01-13 07:02:24 --> Language Class Initialized
INFO - 2025-01-13 07:02:24 --> Loader Class Initialized
INFO - 2025-01-13 07:02:24 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:24 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:24 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:24 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:24 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:24 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:24 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:24 --> Upload Class Initialized
INFO - 2025-01-13 07:02:24 --> Email Class Initialized
INFO - 2025-01-13 07:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:24 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:24 --> Controller Class Initialized
INFO - 2025-01-13 12:32:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:24 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:24 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:29 --> Config Class Initialized
INFO - 2025-01-13 07:02:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:29 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:29 --> URI Class Initialized
INFO - 2025-01-13 07:02:29 --> Router Class Initialized
INFO - 2025-01-13 07:02:29 --> Output Class Initialized
INFO - 2025-01-13 07:02:29 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:29 --> Input Class Initialized
INFO - 2025-01-13 07:02:29 --> Language Class Initialized
INFO - 2025-01-13 07:02:29 --> Loader Class Initialized
INFO - 2025-01-13 07:02:29 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:29 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:29 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:29 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:29 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:29 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:29 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:29 --> Upload Class Initialized
INFO - 2025-01-13 07:02:29 --> Email Class Initialized
INFO - 2025-01-13 07:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:29 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:29 --> Controller Class Initialized
INFO - 2025-01-13 12:32:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:29 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:29 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:34 --> Config Class Initialized
INFO - 2025-01-13 07:02:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:34 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:34 --> URI Class Initialized
INFO - 2025-01-13 07:02:34 --> Router Class Initialized
INFO - 2025-01-13 07:02:34 --> Output Class Initialized
INFO - 2025-01-13 07:02:34 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:34 --> Input Class Initialized
INFO - 2025-01-13 07:02:34 --> Language Class Initialized
INFO - 2025-01-13 07:02:34 --> Loader Class Initialized
INFO - 2025-01-13 07:02:34 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:34 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:34 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:34 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:34 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:34 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:34 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:34 --> Upload Class Initialized
INFO - 2025-01-13 07:02:34 --> Email Class Initialized
INFO - 2025-01-13 07:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:34 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:34 --> Controller Class Initialized
INFO - 2025-01-13 12:32:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:34 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:34 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:39 --> Config Class Initialized
INFO - 2025-01-13 07:02:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:39 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:39 --> URI Class Initialized
INFO - 2025-01-13 07:02:39 --> Router Class Initialized
INFO - 2025-01-13 07:02:39 --> Output Class Initialized
INFO - 2025-01-13 07:02:39 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:39 --> Input Class Initialized
INFO - 2025-01-13 07:02:39 --> Language Class Initialized
INFO - 2025-01-13 07:02:39 --> Loader Class Initialized
INFO - 2025-01-13 07:02:39 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:39 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:39 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:39 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:39 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:39 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:39 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:39 --> Upload Class Initialized
INFO - 2025-01-13 07:02:39 --> Email Class Initialized
INFO - 2025-01-13 07:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:39 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:39 --> Controller Class Initialized
INFO - 2025-01-13 12:32:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:39 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:39 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:44 --> Config Class Initialized
INFO - 2025-01-13 07:02:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:44 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:44 --> URI Class Initialized
INFO - 2025-01-13 07:02:44 --> Router Class Initialized
INFO - 2025-01-13 07:02:44 --> Output Class Initialized
INFO - 2025-01-13 07:02:44 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:44 --> Input Class Initialized
INFO - 2025-01-13 07:02:44 --> Language Class Initialized
INFO - 2025-01-13 07:02:44 --> Loader Class Initialized
INFO - 2025-01-13 07:02:44 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:44 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:44 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:44 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:44 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:44 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:44 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:44 --> Upload Class Initialized
INFO - 2025-01-13 07:02:44 --> Email Class Initialized
INFO - 2025-01-13 07:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:44 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:44 --> Controller Class Initialized
INFO - 2025-01-13 12:32:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:44 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:44 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:49 --> Config Class Initialized
INFO - 2025-01-13 07:02:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:49 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:49 --> URI Class Initialized
INFO - 2025-01-13 07:02:49 --> Router Class Initialized
INFO - 2025-01-13 07:02:49 --> Output Class Initialized
INFO - 2025-01-13 07:02:49 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:49 --> Input Class Initialized
INFO - 2025-01-13 07:02:49 --> Language Class Initialized
INFO - 2025-01-13 07:02:49 --> Loader Class Initialized
INFO - 2025-01-13 07:02:49 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:49 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:49 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:49 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:49 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:49 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:49 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:49 --> Upload Class Initialized
INFO - 2025-01-13 07:02:49 --> Email Class Initialized
INFO - 2025-01-13 07:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:49 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:49 --> Controller Class Initialized
INFO - 2025-01-13 12:32:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:49 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:49 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:54 --> Config Class Initialized
INFO - 2025-01-13 07:02:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:54 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:54 --> URI Class Initialized
INFO - 2025-01-13 07:02:54 --> Router Class Initialized
INFO - 2025-01-13 07:02:54 --> Output Class Initialized
INFO - 2025-01-13 07:02:54 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:54 --> Input Class Initialized
INFO - 2025-01-13 07:02:54 --> Language Class Initialized
INFO - 2025-01-13 07:02:54 --> Loader Class Initialized
INFO - 2025-01-13 07:02:54 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:54 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:54 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:54 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:54 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:54 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:54 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:54 --> Upload Class Initialized
INFO - 2025-01-13 07:02:54 --> Email Class Initialized
INFO - 2025-01-13 07:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:54 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:54 --> Controller Class Initialized
INFO - 2025-01-13 12:32:54 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:54 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:54 --> Pagination Class Initialized
INFO - 2025-01-13 07:02:59 --> Config Class Initialized
INFO - 2025-01-13 07:02:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:02:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:02:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:02:59 --> URI Class Initialized
INFO - 2025-01-13 07:02:59 --> Router Class Initialized
INFO - 2025-01-13 07:02:59 --> Output Class Initialized
INFO - 2025-01-13 07:02:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:02:59 --> Input Class Initialized
INFO - 2025-01-13 07:02:59 --> Language Class Initialized
INFO - 2025-01-13 07:02:59 --> Loader Class Initialized
INFO - 2025-01-13 07:02:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:02:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:02:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:02:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:02:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:02:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:02:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:02:59 --> Upload Class Initialized
INFO - 2025-01-13 07:02:59 --> Email Class Initialized
INFO - 2025-01-13 07:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:02:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:02:59 --> Controller Class Initialized
INFO - 2025-01-13 12:32:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:32:59 --> Model "MainModel" initialized
INFO - 2025-01-13 12:32:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:32:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:19 --> Config Class Initialized
INFO - 2025-01-13 07:03:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:19 --> URI Class Initialized
INFO - 2025-01-13 07:03:19 --> Router Class Initialized
INFO - 2025-01-13 07:03:19 --> Output Class Initialized
INFO - 2025-01-13 07:03:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:19 --> Input Class Initialized
INFO - 2025-01-13 07:03:19 --> Language Class Initialized
INFO - 2025-01-13 07:03:19 --> Loader Class Initialized
INFO - 2025-01-13 07:03:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:19 --> Upload Class Initialized
INFO - 2025-01-13 07:03:19 --> Email Class Initialized
INFO - 2025-01-13 07:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:19 --> Controller Class Initialized
INFO - 2025-01-13 12:33:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:19 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:24 --> Config Class Initialized
INFO - 2025-01-13 07:03:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:24 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:24 --> URI Class Initialized
INFO - 2025-01-13 07:03:24 --> Router Class Initialized
INFO - 2025-01-13 07:03:24 --> Output Class Initialized
INFO - 2025-01-13 07:03:24 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:24 --> Input Class Initialized
INFO - 2025-01-13 07:03:24 --> Language Class Initialized
INFO - 2025-01-13 07:03:24 --> Loader Class Initialized
INFO - 2025-01-13 07:03:24 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:24 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:24 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:24 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:24 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:24 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:24 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:24 --> Upload Class Initialized
INFO - 2025-01-13 07:03:24 --> Email Class Initialized
INFO - 2025-01-13 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:24 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:24 --> Controller Class Initialized
INFO - 2025-01-13 12:33:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:24 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:24 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:29 --> Config Class Initialized
INFO - 2025-01-13 07:03:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:29 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:29 --> URI Class Initialized
INFO - 2025-01-13 07:03:29 --> Router Class Initialized
INFO - 2025-01-13 07:03:29 --> Output Class Initialized
INFO - 2025-01-13 07:03:29 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:29 --> Input Class Initialized
INFO - 2025-01-13 07:03:29 --> Language Class Initialized
INFO - 2025-01-13 07:03:29 --> Loader Class Initialized
INFO - 2025-01-13 07:03:29 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:29 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:29 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:29 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:29 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:29 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:29 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:29 --> Upload Class Initialized
INFO - 2025-01-13 07:03:29 --> Email Class Initialized
INFO - 2025-01-13 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:29 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:29 --> Controller Class Initialized
INFO - 2025-01-13 12:33:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:29 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:29 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:34 --> Config Class Initialized
INFO - 2025-01-13 07:03:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:34 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:34 --> URI Class Initialized
INFO - 2025-01-13 07:03:34 --> Router Class Initialized
INFO - 2025-01-13 07:03:34 --> Output Class Initialized
INFO - 2025-01-13 07:03:34 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:34 --> Input Class Initialized
INFO - 2025-01-13 07:03:34 --> Language Class Initialized
INFO - 2025-01-13 07:03:34 --> Loader Class Initialized
INFO - 2025-01-13 07:03:34 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:34 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:34 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:34 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:34 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:34 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:34 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:34 --> Upload Class Initialized
INFO - 2025-01-13 07:03:34 --> Email Class Initialized
INFO - 2025-01-13 07:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:34 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:34 --> Controller Class Initialized
INFO - 2025-01-13 12:33:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:34 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:34 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:39 --> Config Class Initialized
INFO - 2025-01-13 07:03:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:39 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:39 --> URI Class Initialized
INFO - 2025-01-13 07:03:39 --> Router Class Initialized
INFO - 2025-01-13 07:03:39 --> Output Class Initialized
INFO - 2025-01-13 07:03:39 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:39 --> Input Class Initialized
INFO - 2025-01-13 07:03:39 --> Language Class Initialized
INFO - 2025-01-13 07:03:39 --> Loader Class Initialized
INFO - 2025-01-13 07:03:39 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:39 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:39 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:39 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:39 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:39 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:39 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:39 --> Upload Class Initialized
INFO - 2025-01-13 07:03:39 --> Email Class Initialized
INFO - 2025-01-13 07:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:39 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:39 --> Controller Class Initialized
INFO - 2025-01-13 12:33:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:39 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:39 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:44 --> Config Class Initialized
INFO - 2025-01-13 07:03:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:44 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:44 --> URI Class Initialized
INFO - 2025-01-13 07:03:44 --> Router Class Initialized
INFO - 2025-01-13 07:03:44 --> Output Class Initialized
INFO - 2025-01-13 07:03:44 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:44 --> Input Class Initialized
INFO - 2025-01-13 07:03:44 --> Language Class Initialized
INFO - 2025-01-13 07:03:44 --> Loader Class Initialized
INFO - 2025-01-13 07:03:44 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:44 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:44 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:44 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:44 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:44 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:44 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:44 --> Upload Class Initialized
INFO - 2025-01-13 07:03:44 --> Email Class Initialized
INFO - 2025-01-13 07:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:44 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:44 --> Controller Class Initialized
INFO - 2025-01-13 12:33:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:44 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:44 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:49 --> Config Class Initialized
INFO - 2025-01-13 07:03:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:49 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:49 --> URI Class Initialized
INFO - 2025-01-13 07:03:49 --> Router Class Initialized
INFO - 2025-01-13 07:03:49 --> Output Class Initialized
INFO - 2025-01-13 07:03:49 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:49 --> Input Class Initialized
INFO - 2025-01-13 07:03:49 --> Language Class Initialized
INFO - 2025-01-13 07:03:49 --> Loader Class Initialized
INFO - 2025-01-13 07:03:49 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:49 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:49 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:49 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:49 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:49 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:49 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:49 --> Upload Class Initialized
INFO - 2025-01-13 07:03:49 --> Email Class Initialized
INFO - 2025-01-13 07:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:49 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:49 --> Controller Class Initialized
INFO - 2025-01-13 12:33:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:49 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:49 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:54 --> Config Class Initialized
INFO - 2025-01-13 07:03:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:54 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:54 --> URI Class Initialized
INFO - 2025-01-13 07:03:54 --> Router Class Initialized
INFO - 2025-01-13 07:03:54 --> Output Class Initialized
INFO - 2025-01-13 07:03:54 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:54 --> Input Class Initialized
INFO - 2025-01-13 07:03:54 --> Language Class Initialized
INFO - 2025-01-13 07:03:54 --> Loader Class Initialized
INFO - 2025-01-13 07:03:54 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:54 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:54 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:54 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:54 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:54 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:54 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:54 --> Upload Class Initialized
INFO - 2025-01-13 07:03:54 --> Email Class Initialized
INFO - 2025-01-13 07:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:54 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:54 --> Controller Class Initialized
INFO - 2025-01-13 12:33:54 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:54 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:54 --> Pagination Class Initialized
INFO - 2025-01-13 07:03:59 --> Config Class Initialized
INFO - 2025-01-13 07:03:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:03:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:03:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:03:59 --> URI Class Initialized
INFO - 2025-01-13 07:03:59 --> Router Class Initialized
INFO - 2025-01-13 07:03:59 --> Output Class Initialized
INFO - 2025-01-13 07:03:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:03:59 --> Input Class Initialized
INFO - 2025-01-13 07:03:59 --> Language Class Initialized
INFO - 2025-01-13 07:03:59 --> Loader Class Initialized
INFO - 2025-01-13 07:03:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:03:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:03:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:03:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:03:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:03:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:03:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:03:59 --> Upload Class Initialized
INFO - 2025-01-13 07:03:59 --> Email Class Initialized
INFO - 2025-01-13 07:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:03:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:03:59 --> Controller Class Initialized
INFO - 2025-01-13 12:33:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:33:59 --> Model "MainModel" initialized
INFO - 2025-01-13 12:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:33:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:04 --> Config Class Initialized
INFO - 2025-01-13 07:04:04 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:04 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:04 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:04 --> URI Class Initialized
INFO - 2025-01-13 07:04:04 --> Router Class Initialized
INFO - 2025-01-13 07:04:04 --> Output Class Initialized
INFO - 2025-01-13 07:04:04 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:04 --> Input Class Initialized
INFO - 2025-01-13 07:04:04 --> Language Class Initialized
INFO - 2025-01-13 07:04:04 --> Loader Class Initialized
INFO - 2025-01-13 07:04:04 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:04 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:04 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:04 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:04 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:04 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:04 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:04 --> Upload Class Initialized
INFO - 2025-01-13 07:04:04 --> Email Class Initialized
INFO - 2025-01-13 07:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:04 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:04 --> Controller Class Initialized
INFO - 2025-01-13 12:34:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:04 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:04 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:09 --> Config Class Initialized
INFO - 2025-01-13 07:04:09 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:09 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:09 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:09 --> URI Class Initialized
INFO - 2025-01-13 07:04:09 --> Router Class Initialized
INFO - 2025-01-13 07:04:09 --> Output Class Initialized
INFO - 2025-01-13 07:04:09 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:09 --> Input Class Initialized
INFO - 2025-01-13 07:04:09 --> Language Class Initialized
INFO - 2025-01-13 07:04:09 --> Loader Class Initialized
INFO - 2025-01-13 07:04:09 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:09 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:09 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:09 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:09 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:09 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:09 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:09 --> Upload Class Initialized
INFO - 2025-01-13 07:04:09 --> Email Class Initialized
INFO - 2025-01-13 07:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:09 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:09 --> Controller Class Initialized
INFO - 2025-01-13 12:34:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:09 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:09 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:14 --> Config Class Initialized
INFO - 2025-01-13 07:04:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:14 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:14 --> URI Class Initialized
INFO - 2025-01-13 07:04:14 --> Router Class Initialized
INFO - 2025-01-13 07:04:14 --> Output Class Initialized
INFO - 2025-01-13 07:04:14 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:14 --> Input Class Initialized
INFO - 2025-01-13 07:04:14 --> Language Class Initialized
INFO - 2025-01-13 07:04:14 --> Loader Class Initialized
INFO - 2025-01-13 07:04:14 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:14 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:14 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:14 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:14 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:14 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:14 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:14 --> Upload Class Initialized
INFO - 2025-01-13 07:04:14 --> Email Class Initialized
INFO - 2025-01-13 07:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:14 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:14 --> Controller Class Initialized
INFO - 2025-01-13 12:34:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:14 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:14 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:19 --> Config Class Initialized
INFO - 2025-01-13 07:04:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:19 --> URI Class Initialized
INFO - 2025-01-13 07:04:19 --> Router Class Initialized
INFO - 2025-01-13 07:04:19 --> Output Class Initialized
INFO - 2025-01-13 07:04:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:19 --> Input Class Initialized
INFO - 2025-01-13 07:04:19 --> Language Class Initialized
INFO - 2025-01-13 07:04:19 --> Loader Class Initialized
INFO - 2025-01-13 07:04:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:19 --> Upload Class Initialized
INFO - 2025-01-13 07:04:19 --> Email Class Initialized
INFO - 2025-01-13 07:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:19 --> Controller Class Initialized
INFO - 2025-01-13 12:34:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:19 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:24 --> Config Class Initialized
INFO - 2025-01-13 07:04:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:24 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:24 --> URI Class Initialized
INFO - 2025-01-13 07:04:24 --> Router Class Initialized
INFO - 2025-01-13 07:04:24 --> Output Class Initialized
INFO - 2025-01-13 07:04:24 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:24 --> Input Class Initialized
INFO - 2025-01-13 07:04:24 --> Language Class Initialized
INFO - 2025-01-13 07:04:24 --> Loader Class Initialized
INFO - 2025-01-13 07:04:24 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:24 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:24 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:24 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:24 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:24 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:24 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:24 --> Upload Class Initialized
INFO - 2025-01-13 07:04:24 --> Email Class Initialized
INFO - 2025-01-13 07:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:24 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:24 --> Controller Class Initialized
INFO - 2025-01-13 12:34:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:24 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:24 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:29 --> Config Class Initialized
INFO - 2025-01-13 07:04:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:29 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:29 --> URI Class Initialized
INFO - 2025-01-13 07:04:29 --> Router Class Initialized
INFO - 2025-01-13 07:04:29 --> Output Class Initialized
INFO - 2025-01-13 07:04:29 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:29 --> Input Class Initialized
INFO - 2025-01-13 07:04:29 --> Language Class Initialized
INFO - 2025-01-13 07:04:29 --> Loader Class Initialized
INFO - 2025-01-13 07:04:29 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:29 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:29 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:29 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:29 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:29 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:29 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:29 --> Upload Class Initialized
INFO - 2025-01-13 07:04:29 --> Email Class Initialized
INFO - 2025-01-13 07:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:29 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:29 --> Controller Class Initialized
INFO - 2025-01-13 12:34:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:29 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:29 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:31 --> Config Class Initialized
INFO - 2025-01-13 07:04:31 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:31 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:31 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:31 --> URI Class Initialized
INFO - 2025-01-13 07:04:31 --> Router Class Initialized
INFO - 2025-01-13 07:04:31 --> Output Class Initialized
INFO - 2025-01-13 07:04:31 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:31 --> Input Class Initialized
INFO - 2025-01-13 07:04:31 --> Language Class Initialized
INFO - 2025-01-13 07:04:31 --> Loader Class Initialized
INFO - 2025-01-13 07:04:31 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:31 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:31 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:31 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:31 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:31 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:31 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:31 --> Upload Class Initialized
INFO - 2025-01-13 07:04:31 --> Email Class Initialized
INFO - 2025-01-13 07:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:31 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:31 --> Controller Class Initialized
INFO - 2025-01-13 12:34:31 --> Model "ApiModel" initialized
INFO - 2025-01-13 12:34:31 --> Helper loaded: notification_helper
INFO - 2025-01-13 12:34:31 --> Model "MainModel" initialized
INFO - 2025-01-13 07:04:34 --> Config Class Initialized
INFO - 2025-01-13 07:04:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:34 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:34 --> URI Class Initialized
INFO - 2025-01-13 07:04:34 --> Router Class Initialized
INFO - 2025-01-13 07:04:34 --> Output Class Initialized
INFO - 2025-01-13 07:04:34 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:34 --> Input Class Initialized
INFO - 2025-01-13 07:04:34 --> Language Class Initialized
INFO - 2025-01-13 07:04:34 --> Loader Class Initialized
INFO - 2025-01-13 07:04:34 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:34 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:34 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:34 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:34 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:34 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:34 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:34 --> Upload Class Initialized
INFO - 2025-01-13 07:04:34 --> Email Class Initialized
INFO - 2025-01-13 07:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:34 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:34 --> Controller Class Initialized
INFO - 2025-01-13 12:34:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:34 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:34 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:39 --> Config Class Initialized
INFO - 2025-01-13 07:04:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:39 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:39 --> URI Class Initialized
INFO - 2025-01-13 07:04:39 --> Router Class Initialized
INFO - 2025-01-13 07:04:39 --> Output Class Initialized
INFO - 2025-01-13 07:04:39 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:39 --> Input Class Initialized
INFO - 2025-01-13 07:04:39 --> Language Class Initialized
INFO - 2025-01-13 07:04:39 --> Loader Class Initialized
INFO - 2025-01-13 07:04:39 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:39 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:39 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:39 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:39 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:39 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:39 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:39 --> Upload Class Initialized
INFO - 2025-01-13 07:04:39 --> Email Class Initialized
INFO - 2025-01-13 07:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:39 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:39 --> Controller Class Initialized
INFO - 2025-01-13 12:34:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:39 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:39 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:46 --> Config Class Initialized
INFO - 2025-01-13 07:04:46 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:46 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:46 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:46 --> URI Class Initialized
INFO - 2025-01-13 07:04:46 --> Router Class Initialized
INFO - 2025-01-13 07:04:46 --> Output Class Initialized
INFO - 2025-01-13 07:04:46 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:46 --> Input Class Initialized
INFO - 2025-01-13 07:04:46 --> Language Class Initialized
INFO - 2025-01-13 07:04:46 --> Loader Class Initialized
INFO - 2025-01-13 07:04:46 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:46 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:46 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:46 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:46 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:46 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:46 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:46 --> Upload Class Initialized
INFO - 2025-01-13 07:04:46 --> Email Class Initialized
INFO - 2025-01-13 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:46 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:46 --> Controller Class Initialized
INFO - 2025-01-13 12:34:46 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:46 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:46 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:49 --> Config Class Initialized
INFO - 2025-01-13 07:04:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:49 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:49 --> URI Class Initialized
INFO - 2025-01-13 07:04:49 --> Router Class Initialized
INFO - 2025-01-13 07:04:49 --> Output Class Initialized
INFO - 2025-01-13 07:04:49 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:49 --> Input Class Initialized
INFO - 2025-01-13 07:04:49 --> Language Class Initialized
INFO - 2025-01-13 07:04:49 --> Loader Class Initialized
INFO - 2025-01-13 07:04:49 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:49 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:49 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:49 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:49 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:49 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:49 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:49 --> Upload Class Initialized
INFO - 2025-01-13 07:04:49 --> Email Class Initialized
INFO - 2025-01-13 07:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:49 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:49 --> Controller Class Initialized
INFO - 2025-01-13 12:34:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:49 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:49 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:54 --> Config Class Initialized
INFO - 2025-01-13 07:04:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:54 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:54 --> URI Class Initialized
INFO - 2025-01-13 07:04:54 --> Router Class Initialized
INFO - 2025-01-13 07:04:54 --> Output Class Initialized
INFO - 2025-01-13 07:04:54 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:54 --> Input Class Initialized
INFO - 2025-01-13 07:04:54 --> Language Class Initialized
INFO - 2025-01-13 07:04:54 --> Loader Class Initialized
INFO - 2025-01-13 07:04:54 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:54 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:54 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:54 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:54 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:54 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:54 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:54 --> Upload Class Initialized
INFO - 2025-01-13 07:04:54 --> Email Class Initialized
INFO - 2025-01-13 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:54 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:54 --> Controller Class Initialized
INFO - 2025-01-13 12:34:54 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:54 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:54 --> Pagination Class Initialized
INFO - 2025-01-13 07:04:59 --> Config Class Initialized
INFO - 2025-01-13 07:04:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:04:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:04:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:04:59 --> URI Class Initialized
INFO - 2025-01-13 07:04:59 --> Router Class Initialized
INFO - 2025-01-13 07:04:59 --> Output Class Initialized
INFO - 2025-01-13 07:04:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:04:59 --> Input Class Initialized
INFO - 2025-01-13 07:04:59 --> Language Class Initialized
INFO - 2025-01-13 07:04:59 --> Loader Class Initialized
INFO - 2025-01-13 07:04:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:04:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:04:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:04:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:04:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:04:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:04:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:04:59 --> Upload Class Initialized
INFO - 2025-01-13 07:04:59 --> Email Class Initialized
INFO - 2025-01-13 07:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:04:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:04:59 --> Controller Class Initialized
INFO - 2025-01-13 12:34:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:34:59 --> Model "MainModel" initialized
INFO - 2025-01-13 12:34:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:34:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:04 --> Config Class Initialized
INFO - 2025-01-13 07:05:04 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:04 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:04 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:04 --> URI Class Initialized
INFO - 2025-01-13 07:05:04 --> Router Class Initialized
INFO - 2025-01-13 07:05:04 --> Output Class Initialized
INFO - 2025-01-13 07:05:04 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:04 --> Input Class Initialized
INFO - 2025-01-13 07:05:04 --> Language Class Initialized
INFO - 2025-01-13 07:05:04 --> Loader Class Initialized
INFO - 2025-01-13 07:05:04 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:04 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:04 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:04 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:04 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:04 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:04 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:04 --> Upload Class Initialized
INFO - 2025-01-13 07:05:04 --> Email Class Initialized
INFO - 2025-01-13 07:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:04 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:04 --> Controller Class Initialized
INFO - 2025-01-13 12:35:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:04 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:04 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:09 --> Config Class Initialized
INFO - 2025-01-13 07:05:09 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:09 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:09 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:09 --> URI Class Initialized
INFO - 2025-01-13 07:05:09 --> Router Class Initialized
INFO - 2025-01-13 07:05:09 --> Output Class Initialized
INFO - 2025-01-13 07:05:09 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:09 --> Input Class Initialized
INFO - 2025-01-13 07:05:09 --> Language Class Initialized
INFO - 2025-01-13 07:05:09 --> Loader Class Initialized
INFO - 2025-01-13 07:05:09 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:09 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:09 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:09 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:09 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:09 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:09 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:09 --> Upload Class Initialized
INFO - 2025-01-13 07:05:09 --> Email Class Initialized
INFO - 2025-01-13 07:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:09 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:09 --> Controller Class Initialized
INFO - 2025-01-13 12:35:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:09 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:09 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:14 --> Config Class Initialized
INFO - 2025-01-13 07:05:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:14 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:14 --> URI Class Initialized
INFO - 2025-01-13 07:05:14 --> Router Class Initialized
INFO - 2025-01-13 07:05:14 --> Output Class Initialized
INFO - 2025-01-13 07:05:14 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:14 --> Input Class Initialized
INFO - 2025-01-13 07:05:14 --> Language Class Initialized
INFO - 2025-01-13 07:05:14 --> Loader Class Initialized
INFO - 2025-01-13 07:05:14 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:14 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:14 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:14 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:14 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:14 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:14 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:14 --> Upload Class Initialized
INFO - 2025-01-13 07:05:14 --> Email Class Initialized
INFO - 2025-01-13 07:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:14 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:14 --> Controller Class Initialized
INFO - 2025-01-13 12:35:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:14 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:14 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:19 --> Config Class Initialized
INFO - 2025-01-13 07:05:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:19 --> URI Class Initialized
INFO - 2025-01-13 07:05:19 --> Router Class Initialized
INFO - 2025-01-13 07:05:19 --> Output Class Initialized
INFO - 2025-01-13 07:05:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:19 --> Input Class Initialized
INFO - 2025-01-13 07:05:19 --> Language Class Initialized
INFO - 2025-01-13 07:05:19 --> Loader Class Initialized
INFO - 2025-01-13 07:05:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:19 --> Upload Class Initialized
INFO - 2025-01-13 07:05:19 --> Email Class Initialized
INFO - 2025-01-13 07:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:19 --> Controller Class Initialized
INFO - 2025-01-13 12:35:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:19 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:24 --> Config Class Initialized
INFO - 2025-01-13 07:05:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:24 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:24 --> URI Class Initialized
INFO - 2025-01-13 07:05:24 --> Router Class Initialized
INFO - 2025-01-13 07:05:24 --> Output Class Initialized
INFO - 2025-01-13 07:05:24 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:24 --> Input Class Initialized
INFO - 2025-01-13 07:05:24 --> Language Class Initialized
INFO - 2025-01-13 07:05:24 --> Loader Class Initialized
INFO - 2025-01-13 07:05:24 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:24 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:24 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:24 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:24 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:24 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:24 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:24 --> Upload Class Initialized
INFO - 2025-01-13 07:05:24 --> Email Class Initialized
INFO - 2025-01-13 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:24 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:24 --> Controller Class Initialized
INFO - 2025-01-13 12:35:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:24 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:24 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:29 --> Config Class Initialized
INFO - 2025-01-13 07:05:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:29 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:29 --> URI Class Initialized
INFO - 2025-01-13 07:05:29 --> Router Class Initialized
INFO - 2025-01-13 07:05:29 --> Output Class Initialized
INFO - 2025-01-13 07:05:29 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:29 --> Input Class Initialized
INFO - 2025-01-13 07:05:29 --> Language Class Initialized
INFO - 2025-01-13 07:05:29 --> Loader Class Initialized
INFO - 2025-01-13 07:05:29 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:29 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:29 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:29 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:29 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:29 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:29 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:29 --> Upload Class Initialized
INFO - 2025-01-13 07:05:29 --> Email Class Initialized
INFO - 2025-01-13 07:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:29 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:29 --> Controller Class Initialized
INFO - 2025-01-13 12:35:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:29 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:29 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:34 --> Config Class Initialized
INFO - 2025-01-13 07:05:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:34 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:34 --> URI Class Initialized
INFO - 2025-01-13 07:05:34 --> Router Class Initialized
INFO - 2025-01-13 07:05:34 --> Output Class Initialized
INFO - 2025-01-13 07:05:34 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:34 --> Input Class Initialized
INFO - 2025-01-13 07:05:34 --> Language Class Initialized
INFO - 2025-01-13 07:05:34 --> Loader Class Initialized
INFO - 2025-01-13 07:05:34 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:34 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:34 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:34 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:34 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:34 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:34 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:34 --> Upload Class Initialized
INFO - 2025-01-13 07:05:34 --> Email Class Initialized
INFO - 2025-01-13 07:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:34 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:34 --> Controller Class Initialized
INFO - 2025-01-13 12:35:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:34 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:34 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:39 --> Config Class Initialized
INFO - 2025-01-13 07:05:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:39 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:39 --> URI Class Initialized
INFO - 2025-01-13 07:05:39 --> Router Class Initialized
INFO - 2025-01-13 07:05:39 --> Output Class Initialized
INFO - 2025-01-13 07:05:39 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:39 --> Input Class Initialized
INFO - 2025-01-13 07:05:39 --> Language Class Initialized
INFO - 2025-01-13 07:05:39 --> Loader Class Initialized
INFO - 2025-01-13 07:05:39 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:39 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:39 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:39 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:39 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:39 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:39 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:39 --> Upload Class Initialized
INFO - 2025-01-13 07:05:39 --> Email Class Initialized
INFO - 2025-01-13 07:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:39 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:39 --> Controller Class Initialized
INFO - 2025-01-13 12:35:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:39 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:39 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:44 --> Config Class Initialized
INFO - 2025-01-13 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:44 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:44 --> URI Class Initialized
INFO - 2025-01-13 07:05:44 --> Router Class Initialized
INFO - 2025-01-13 07:05:44 --> Output Class Initialized
INFO - 2025-01-13 07:05:44 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:44 --> Input Class Initialized
INFO - 2025-01-13 07:05:44 --> Language Class Initialized
INFO - 2025-01-13 07:05:44 --> Loader Class Initialized
INFO - 2025-01-13 07:05:44 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:44 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:44 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:44 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:44 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:44 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:44 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:44 --> Upload Class Initialized
INFO - 2025-01-13 07:05:44 --> Email Class Initialized
INFO - 2025-01-13 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:44 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:44 --> Controller Class Initialized
INFO - 2025-01-13 12:35:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:44 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:44 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:49 --> Config Class Initialized
INFO - 2025-01-13 07:05:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:49 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:49 --> URI Class Initialized
INFO - 2025-01-13 07:05:49 --> Router Class Initialized
INFO - 2025-01-13 07:05:49 --> Output Class Initialized
INFO - 2025-01-13 07:05:49 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:49 --> Input Class Initialized
INFO - 2025-01-13 07:05:49 --> Language Class Initialized
INFO - 2025-01-13 07:05:49 --> Loader Class Initialized
INFO - 2025-01-13 07:05:49 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:49 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:49 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:49 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:49 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:49 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:49 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:49 --> Upload Class Initialized
INFO - 2025-01-13 07:05:49 --> Email Class Initialized
INFO - 2025-01-13 07:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:49 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:49 --> Controller Class Initialized
INFO - 2025-01-13 12:35:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:49 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:49 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:54 --> Config Class Initialized
INFO - 2025-01-13 07:05:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:54 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:54 --> URI Class Initialized
INFO - 2025-01-13 07:05:54 --> Router Class Initialized
INFO - 2025-01-13 07:05:54 --> Output Class Initialized
INFO - 2025-01-13 07:05:54 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:54 --> Input Class Initialized
INFO - 2025-01-13 07:05:54 --> Language Class Initialized
INFO - 2025-01-13 07:05:54 --> Loader Class Initialized
INFO - 2025-01-13 07:05:54 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:54 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:54 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:54 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:54 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:54 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:54 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:54 --> Upload Class Initialized
INFO - 2025-01-13 07:05:54 --> Email Class Initialized
INFO - 2025-01-13 07:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:54 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:54 --> Controller Class Initialized
INFO - 2025-01-13 12:35:54 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:54 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:54 --> Pagination Class Initialized
INFO - 2025-01-13 07:05:59 --> Config Class Initialized
INFO - 2025-01-13 07:05:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:05:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:05:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:05:59 --> URI Class Initialized
INFO - 2025-01-13 07:05:59 --> Router Class Initialized
INFO - 2025-01-13 07:05:59 --> Output Class Initialized
INFO - 2025-01-13 07:05:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:05:59 --> Input Class Initialized
INFO - 2025-01-13 07:05:59 --> Language Class Initialized
INFO - 2025-01-13 07:05:59 --> Loader Class Initialized
INFO - 2025-01-13 07:05:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:05:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:05:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:05:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:05:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:05:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:05:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:05:59 --> Upload Class Initialized
INFO - 2025-01-13 07:05:59 --> Email Class Initialized
INFO - 2025-01-13 07:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:05:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:05:59 --> Controller Class Initialized
INFO - 2025-01-13 12:35:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:35:59 --> Model "MainModel" initialized
INFO - 2025-01-13 12:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:35:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:04 --> Config Class Initialized
INFO - 2025-01-13 07:06:04 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:04 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:04 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:04 --> URI Class Initialized
INFO - 2025-01-13 07:06:04 --> Router Class Initialized
INFO - 2025-01-13 07:06:04 --> Output Class Initialized
INFO - 2025-01-13 07:06:04 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:04 --> Input Class Initialized
INFO - 2025-01-13 07:06:04 --> Language Class Initialized
INFO - 2025-01-13 07:06:04 --> Loader Class Initialized
INFO - 2025-01-13 07:06:04 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:04 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:04 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:04 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:04 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:04 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:04 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:04 --> Upload Class Initialized
INFO - 2025-01-13 07:06:04 --> Email Class Initialized
INFO - 2025-01-13 07:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:04 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:04 --> Controller Class Initialized
INFO - 2025-01-13 12:36:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:04 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:04 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:09 --> Config Class Initialized
INFO - 2025-01-13 07:06:09 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:09 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:09 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:09 --> URI Class Initialized
INFO - 2025-01-13 07:06:09 --> Router Class Initialized
INFO - 2025-01-13 07:06:09 --> Output Class Initialized
INFO - 2025-01-13 07:06:09 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:09 --> Input Class Initialized
INFO - 2025-01-13 07:06:09 --> Language Class Initialized
INFO - 2025-01-13 07:06:09 --> Loader Class Initialized
INFO - 2025-01-13 07:06:09 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:09 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:09 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:09 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:09 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:09 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:09 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:09 --> Upload Class Initialized
INFO - 2025-01-13 07:06:09 --> Email Class Initialized
INFO - 2025-01-13 07:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:09 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:09 --> Controller Class Initialized
INFO - 2025-01-13 12:36:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:09 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:09 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:14 --> Config Class Initialized
INFO - 2025-01-13 07:06:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:14 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:14 --> URI Class Initialized
INFO - 2025-01-13 07:06:14 --> Router Class Initialized
INFO - 2025-01-13 07:06:14 --> Output Class Initialized
INFO - 2025-01-13 07:06:14 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:14 --> Input Class Initialized
INFO - 2025-01-13 07:06:14 --> Language Class Initialized
INFO - 2025-01-13 07:06:14 --> Loader Class Initialized
INFO - 2025-01-13 07:06:14 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:14 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:14 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:14 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:14 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:14 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:14 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:14 --> Upload Class Initialized
INFO - 2025-01-13 07:06:14 --> Email Class Initialized
INFO - 2025-01-13 07:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:14 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:14 --> Controller Class Initialized
INFO - 2025-01-13 12:36:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:14 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:14 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:19 --> Config Class Initialized
INFO - 2025-01-13 07:06:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:19 --> URI Class Initialized
INFO - 2025-01-13 07:06:19 --> Router Class Initialized
INFO - 2025-01-13 07:06:19 --> Output Class Initialized
INFO - 2025-01-13 07:06:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:19 --> Input Class Initialized
INFO - 2025-01-13 07:06:19 --> Language Class Initialized
INFO - 2025-01-13 07:06:19 --> Loader Class Initialized
INFO - 2025-01-13 07:06:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:19 --> Upload Class Initialized
INFO - 2025-01-13 07:06:19 --> Email Class Initialized
INFO - 2025-01-13 07:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:19 --> Controller Class Initialized
INFO - 2025-01-13 12:36:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:19 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:24 --> Config Class Initialized
INFO - 2025-01-13 07:06:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:24 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:24 --> URI Class Initialized
INFO - 2025-01-13 07:06:24 --> Router Class Initialized
INFO - 2025-01-13 07:06:24 --> Output Class Initialized
INFO - 2025-01-13 07:06:24 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:24 --> Input Class Initialized
INFO - 2025-01-13 07:06:24 --> Language Class Initialized
INFO - 2025-01-13 07:06:24 --> Loader Class Initialized
INFO - 2025-01-13 07:06:24 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:24 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:24 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:24 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:24 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:24 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:24 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:24 --> Upload Class Initialized
INFO - 2025-01-13 07:06:24 --> Email Class Initialized
INFO - 2025-01-13 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:24 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:24 --> Controller Class Initialized
INFO - 2025-01-13 12:36:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:24 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:24 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:29 --> Config Class Initialized
INFO - 2025-01-13 07:06:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:29 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:29 --> URI Class Initialized
INFO - 2025-01-13 07:06:29 --> Router Class Initialized
INFO - 2025-01-13 07:06:29 --> Output Class Initialized
INFO - 2025-01-13 07:06:29 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:29 --> Input Class Initialized
INFO - 2025-01-13 07:06:29 --> Language Class Initialized
INFO - 2025-01-13 07:06:29 --> Loader Class Initialized
INFO - 2025-01-13 07:06:29 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:29 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:29 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:29 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:29 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:29 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:29 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:29 --> Upload Class Initialized
INFO - 2025-01-13 07:06:29 --> Email Class Initialized
INFO - 2025-01-13 07:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:29 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:29 --> Controller Class Initialized
INFO - 2025-01-13 12:36:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:29 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:29 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:34 --> Config Class Initialized
INFO - 2025-01-13 07:06:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:34 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:34 --> URI Class Initialized
INFO - 2025-01-13 07:06:34 --> Router Class Initialized
INFO - 2025-01-13 07:06:34 --> Output Class Initialized
INFO - 2025-01-13 07:06:34 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:34 --> Input Class Initialized
INFO - 2025-01-13 07:06:34 --> Language Class Initialized
INFO - 2025-01-13 07:06:34 --> Loader Class Initialized
INFO - 2025-01-13 07:06:34 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:34 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:34 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:34 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:34 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:34 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:34 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:34 --> Upload Class Initialized
INFO - 2025-01-13 07:06:34 --> Email Class Initialized
INFO - 2025-01-13 07:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:34 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:34 --> Controller Class Initialized
INFO - 2025-01-13 12:36:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:34 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:34 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:39 --> Config Class Initialized
INFO - 2025-01-13 07:06:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:39 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:39 --> URI Class Initialized
INFO - 2025-01-13 07:06:39 --> Router Class Initialized
INFO - 2025-01-13 07:06:39 --> Output Class Initialized
INFO - 2025-01-13 07:06:39 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:39 --> Input Class Initialized
INFO - 2025-01-13 07:06:39 --> Language Class Initialized
INFO - 2025-01-13 07:06:39 --> Loader Class Initialized
INFO - 2025-01-13 07:06:39 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:39 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:39 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:39 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:39 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:39 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:39 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:39 --> Upload Class Initialized
INFO - 2025-01-13 07:06:39 --> Email Class Initialized
INFO - 2025-01-13 07:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:39 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:39 --> Controller Class Initialized
INFO - 2025-01-13 12:36:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:39 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:39 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:44 --> Config Class Initialized
INFO - 2025-01-13 07:06:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:44 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:44 --> URI Class Initialized
INFO - 2025-01-13 07:06:44 --> Router Class Initialized
INFO - 2025-01-13 07:06:44 --> Output Class Initialized
INFO - 2025-01-13 07:06:44 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:44 --> Input Class Initialized
INFO - 2025-01-13 07:06:44 --> Language Class Initialized
INFO - 2025-01-13 07:06:44 --> Loader Class Initialized
INFO - 2025-01-13 07:06:44 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:44 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:44 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:44 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:44 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:44 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:44 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:44 --> Upload Class Initialized
INFO - 2025-01-13 07:06:44 --> Email Class Initialized
INFO - 2025-01-13 07:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:44 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:44 --> Controller Class Initialized
INFO - 2025-01-13 12:36:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:44 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:44 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:49 --> Config Class Initialized
INFO - 2025-01-13 07:06:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:49 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:49 --> URI Class Initialized
INFO - 2025-01-13 07:06:49 --> Router Class Initialized
INFO - 2025-01-13 07:06:49 --> Output Class Initialized
INFO - 2025-01-13 07:06:49 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:49 --> Input Class Initialized
INFO - 2025-01-13 07:06:49 --> Language Class Initialized
INFO - 2025-01-13 07:06:49 --> Loader Class Initialized
INFO - 2025-01-13 07:06:49 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:49 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:49 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:49 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:49 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:49 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:49 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:49 --> Upload Class Initialized
INFO - 2025-01-13 07:06:49 --> Email Class Initialized
INFO - 2025-01-13 07:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:49 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:49 --> Controller Class Initialized
INFO - 2025-01-13 12:36:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:49 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:49 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:54 --> Config Class Initialized
INFO - 2025-01-13 07:06:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:54 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:54 --> URI Class Initialized
INFO - 2025-01-13 07:06:54 --> Router Class Initialized
INFO - 2025-01-13 07:06:54 --> Output Class Initialized
INFO - 2025-01-13 07:06:54 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:54 --> Input Class Initialized
INFO - 2025-01-13 07:06:54 --> Language Class Initialized
INFO - 2025-01-13 07:06:54 --> Loader Class Initialized
INFO - 2025-01-13 07:06:54 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:54 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:54 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:54 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:54 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:54 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:54 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:54 --> Upload Class Initialized
INFO - 2025-01-13 07:06:54 --> Email Class Initialized
INFO - 2025-01-13 07:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:54 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:54 --> Controller Class Initialized
INFO - 2025-01-13 12:36:54 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:54 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:54 --> Pagination Class Initialized
INFO - 2025-01-13 07:06:59 --> Config Class Initialized
INFO - 2025-01-13 07:06:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:06:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:06:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:06:59 --> URI Class Initialized
INFO - 2025-01-13 07:06:59 --> Router Class Initialized
INFO - 2025-01-13 07:06:59 --> Output Class Initialized
INFO - 2025-01-13 07:06:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:06:59 --> Input Class Initialized
INFO - 2025-01-13 07:06:59 --> Language Class Initialized
INFO - 2025-01-13 07:06:59 --> Loader Class Initialized
INFO - 2025-01-13 07:06:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:06:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:06:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:06:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:06:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:06:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:06:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:06:59 --> Upload Class Initialized
INFO - 2025-01-13 07:06:59 --> Email Class Initialized
INFO - 2025-01-13 07:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:06:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:06:59 --> Controller Class Initialized
INFO - 2025-01-13 12:36:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:36:59 --> Model "MainModel" initialized
INFO - 2025-01-13 12:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:36:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:04 --> Config Class Initialized
INFO - 2025-01-13 07:07:04 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:04 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:04 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:04 --> URI Class Initialized
INFO - 2025-01-13 07:07:04 --> Router Class Initialized
INFO - 2025-01-13 07:07:04 --> Output Class Initialized
INFO - 2025-01-13 07:07:04 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:04 --> Input Class Initialized
INFO - 2025-01-13 07:07:04 --> Language Class Initialized
INFO - 2025-01-13 07:07:04 --> Loader Class Initialized
INFO - 2025-01-13 07:07:04 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:04 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:04 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:04 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:04 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:04 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:04 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:04 --> Upload Class Initialized
INFO - 2025-01-13 07:07:04 --> Email Class Initialized
INFO - 2025-01-13 07:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:04 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:04 --> Controller Class Initialized
INFO - 2025-01-13 12:37:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:04 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:04 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:09 --> Config Class Initialized
INFO - 2025-01-13 07:07:09 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:09 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:09 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:09 --> URI Class Initialized
INFO - 2025-01-13 07:07:09 --> Router Class Initialized
INFO - 2025-01-13 07:07:09 --> Output Class Initialized
INFO - 2025-01-13 07:07:09 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:09 --> Input Class Initialized
INFO - 2025-01-13 07:07:09 --> Language Class Initialized
INFO - 2025-01-13 07:07:09 --> Loader Class Initialized
INFO - 2025-01-13 07:07:09 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:09 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:09 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:09 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:09 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:09 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:09 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:09 --> Upload Class Initialized
INFO - 2025-01-13 07:07:09 --> Email Class Initialized
INFO - 2025-01-13 07:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:09 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:09 --> Controller Class Initialized
INFO - 2025-01-13 12:37:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:09 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:09 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:14 --> Config Class Initialized
INFO - 2025-01-13 07:07:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:14 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:14 --> URI Class Initialized
INFO - 2025-01-13 07:07:14 --> Router Class Initialized
INFO - 2025-01-13 07:07:14 --> Output Class Initialized
INFO - 2025-01-13 07:07:14 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:14 --> Input Class Initialized
INFO - 2025-01-13 07:07:14 --> Language Class Initialized
INFO - 2025-01-13 07:07:14 --> Loader Class Initialized
INFO - 2025-01-13 07:07:14 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:14 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:14 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:14 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:14 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:14 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:14 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:14 --> Upload Class Initialized
INFO - 2025-01-13 07:07:14 --> Email Class Initialized
INFO - 2025-01-13 07:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:14 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:14 --> Controller Class Initialized
INFO - 2025-01-13 12:37:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:14 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:14 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:19 --> Config Class Initialized
INFO - 2025-01-13 07:07:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:19 --> URI Class Initialized
INFO - 2025-01-13 07:07:19 --> Router Class Initialized
INFO - 2025-01-13 07:07:19 --> Output Class Initialized
INFO - 2025-01-13 07:07:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:19 --> Input Class Initialized
INFO - 2025-01-13 07:07:19 --> Language Class Initialized
INFO - 2025-01-13 07:07:19 --> Loader Class Initialized
INFO - 2025-01-13 07:07:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:19 --> Upload Class Initialized
INFO - 2025-01-13 07:07:19 --> Email Class Initialized
INFO - 2025-01-13 07:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:19 --> Controller Class Initialized
INFO - 2025-01-13 12:37:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:19 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:24 --> Config Class Initialized
INFO - 2025-01-13 07:07:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:24 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:24 --> URI Class Initialized
INFO - 2025-01-13 07:07:24 --> Router Class Initialized
INFO - 2025-01-13 07:07:24 --> Output Class Initialized
INFO - 2025-01-13 07:07:24 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:24 --> Input Class Initialized
INFO - 2025-01-13 07:07:24 --> Language Class Initialized
INFO - 2025-01-13 07:07:24 --> Loader Class Initialized
INFO - 2025-01-13 07:07:24 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:24 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:24 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:24 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:24 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:24 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:24 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:24 --> Upload Class Initialized
INFO - 2025-01-13 07:07:24 --> Email Class Initialized
INFO - 2025-01-13 07:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:24 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:24 --> Controller Class Initialized
INFO - 2025-01-13 12:37:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:24 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:24 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:29 --> Config Class Initialized
INFO - 2025-01-13 07:07:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:29 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:29 --> URI Class Initialized
INFO - 2025-01-13 07:07:29 --> Router Class Initialized
INFO - 2025-01-13 07:07:29 --> Output Class Initialized
INFO - 2025-01-13 07:07:29 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:29 --> Input Class Initialized
INFO - 2025-01-13 07:07:29 --> Language Class Initialized
INFO - 2025-01-13 07:07:29 --> Loader Class Initialized
INFO - 2025-01-13 07:07:29 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:29 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:29 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:29 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:29 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:29 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:29 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:29 --> Upload Class Initialized
INFO - 2025-01-13 07:07:29 --> Email Class Initialized
INFO - 2025-01-13 07:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:29 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:29 --> Controller Class Initialized
INFO - 2025-01-13 12:37:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:29 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:29 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:34 --> Config Class Initialized
INFO - 2025-01-13 07:07:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:34 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:34 --> URI Class Initialized
INFO - 2025-01-13 07:07:34 --> Router Class Initialized
INFO - 2025-01-13 07:07:34 --> Output Class Initialized
INFO - 2025-01-13 07:07:34 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:34 --> Input Class Initialized
INFO - 2025-01-13 07:07:34 --> Language Class Initialized
INFO - 2025-01-13 07:07:34 --> Loader Class Initialized
INFO - 2025-01-13 07:07:34 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:34 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:34 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:34 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:34 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:34 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:34 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:34 --> Upload Class Initialized
INFO - 2025-01-13 07:07:34 --> Email Class Initialized
INFO - 2025-01-13 07:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:34 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:34 --> Controller Class Initialized
INFO - 2025-01-13 12:37:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:34 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:34 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:39 --> Config Class Initialized
INFO - 2025-01-13 07:07:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:39 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:39 --> URI Class Initialized
INFO - 2025-01-13 07:07:39 --> Router Class Initialized
INFO - 2025-01-13 07:07:39 --> Output Class Initialized
INFO - 2025-01-13 07:07:39 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:39 --> Input Class Initialized
INFO - 2025-01-13 07:07:39 --> Language Class Initialized
INFO - 2025-01-13 07:07:39 --> Loader Class Initialized
INFO - 2025-01-13 07:07:39 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:39 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:39 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:39 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:39 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:39 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:39 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:39 --> Upload Class Initialized
INFO - 2025-01-13 07:07:39 --> Email Class Initialized
INFO - 2025-01-13 07:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:39 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:39 --> Controller Class Initialized
INFO - 2025-01-13 12:37:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:39 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:39 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:44 --> Config Class Initialized
INFO - 2025-01-13 07:07:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:44 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:44 --> URI Class Initialized
INFO - 2025-01-13 07:07:44 --> Router Class Initialized
INFO - 2025-01-13 07:07:44 --> Output Class Initialized
INFO - 2025-01-13 07:07:44 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:44 --> Input Class Initialized
INFO - 2025-01-13 07:07:44 --> Language Class Initialized
INFO - 2025-01-13 07:07:44 --> Loader Class Initialized
INFO - 2025-01-13 07:07:44 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:44 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:44 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:44 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:44 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:44 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:44 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:44 --> Upload Class Initialized
INFO - 2025-01-13 07:07:44 --> Email Class Initialized
INFO - 2025-01-13 07:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:44 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:44 --> Controller Class Initialized
INFO - 2025-01-13 12:37:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:44 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:44 --> Pagination Class Initialized
INFO - 2025-01-13 07:07:57 --> Config Class Initialized
INFO - 2025-01-13 07:07:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:07:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:07:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:07:57 --> URI Class Initialized
INFO - 2025-01-13 07:07:57 --> Router Class Initialized
INFO - 2025-01-13 07:07:57 --> Output Class Initialized
INFO - 2025-01-13 07:07:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:07:57 --> Input Class Initialized
INFO - 2025-01-13 07:07:57 --> Language Class Initialized
INFO - 2025-01-13 07:07:57 --> Loader Class Initialized
INFO - 2025-01-13 07:07:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:07:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:07:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:07:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:07:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:07:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:07:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:07:57 --> Upload Class Initialized
INFO - 2025-01-13 07:07:57 --> Email Class Initialized
INFO - 2025-01-13 07:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:07:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:07:57 --> Controller Class Initialized
INFO - 2025-01-13 12:37:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:37:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:37:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:08:57 --> Config Class Initialized
INFO - 2025-01-13 07:08:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:08:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:08:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:08:57 --> URI Class Initialized
INFO - 2025-01-13 07:08:57 --> Router Class Initialized
INFO - 2025-01-13 07:08:57 --> Output Class Initialized
INFO - 2025-01-13 07:08:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:08:57 --> Input Class Initialized
INFO - 2025-01-13 07:08:57 --> Language Class Initialized
INFO - 2025-01-13 07:08:57 --> Loader Class Initialized
INFO - 2025-01-13 07:08:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:08:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:08:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:08:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:08:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:08:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:08:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:08:57 --> Upload Class Initialized
INFO - 2025-01-13 07:08:57 --> Email Class Initialized
INFO - 2025-01-13 07:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:08:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:08:57 --> Controller Class Initialized
INFO - 2025-01-13 12:38:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:38:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:38:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:09:57 --> Config Class Initialized
INFO - 2025-01-13 07:09:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:09:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:09:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:09:57 --> URI Class Initialized
INFO - 2025-01-13 07:09:57 --> Router Class Initialized
INFO - 2025-01-13 07:09:57 --> Output Class Initialized
INFO - 2025-01-13 07:09:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:09:57 --> Input Class Initialized
INFO - 2025-01-13 07:09:57 --> Language Class Initialized
INFO - 2025-01-13 07:09:57 --> Loader Class Initialized
INFO - 2025-01-13 07:09:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:09:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:09:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:09:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:09:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:09:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:09:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:09:57 --> Upload Class Initialized
INFO - 2025-01-13 07:09:57 --> Email Class Initialized
INFO - 2025-01-13 07:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:09:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:09:57 --> Controller Class Initialized
INFO - 2025-01-13 12:39:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:39:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:39:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:39:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:10:01 --> Config Class Initialized
INFO - 2025-01-13 07:10:01 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:10:01 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:10:01 --> Utf8 Class Initialized
INFO - 2025-01-13 07:10:01 --> URI Class Initialized
INFO - 2025-01-13 07:10:01 --> Router Class Initialized
INFO - 2025-01-13 07:10:01 --> Output Class Initialized
INFO - 2025-01-13 07:10:01 --> Security Class Initialized
DEBUG - 2025-01-13 07:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:10:01 --> Input Class Initialized
INFO - 2025-01-13 07:10:01 --> Language Class Initialized
INFO - 2025-01-13 07:10:01 --> Loader Class Initialized
INFO - 2025-01-13 07:10:01 --> Helper loaded: url_helper
INFO - 2025-01-13 07:10:01 --> Helper loaded: html_helper
INFO - 2025-01-13 07:10:01 --> Helper loaded: file_helper
INFO - 2025-01-13 07:10:01 --> Helper loaded: string_helper
INFO - 2025-01-13 07:10:01 --> Helper loaded: form_helper
INFO - 2025-01-13 07:10:01 --> Helper loaded: my_helper
INFO - 2025-01-13 07:10:01 --> Database Driver Class Initialized
INFO - 2025-01-13 07:10:01 --> Upload Class Initialized
INFO - 2025-01-13 07:10:01 --> Email Class Initialized
INFO - 2025-01-13 07:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:10:01 --> Form Validation Class Initialized
INFO - 2025-01-13 07:10:01 --> Controller Class Initialized
INFO - 2025-01-13 12:40:01 --> Model "ApiModel" initialized
INFO - 2025-01-13 12:40:01 --> Helper loaded: notification_helper
INFO - 2025-01-13 12:40:01 --> Model "MainModel" initialized
INFO - 2025-01-13 07:10:57 --> Config Class Initialized
INFO - 2025-01-13 07:10:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:10:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:10:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:10:57 --> URI Class Initialized
INFO - 2025-01-13 07:10:57 --> Router Class Initialized
INFO - 2025-01-13 07:10:57 --> Output Class Initialized
INFO - 2025-01-13 07:10:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:10:57 --> Input Class Initialized
INFO - 2025-01-13 07:10:57 --> Language Class Initialized
INFO - 2025-01-13 07:10:57 --> Loader Class Initialized
INFO - 2025-01-13 07:10:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:10:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:10:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:10:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:10:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:10:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:10:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:10:57 --> Upload Class Initialized
INFO - 2025-01-13 07:10:57 --> Email Class Initialized
INFO - 2025-01-13 07:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:10:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:10:57 --> Controller Class Initialized
INFO - 2025-01-13 12:40:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:40:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:40:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:11:57 --> Config Class Initialized
INFO - 2025-01-13 07:11:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:11:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:11:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:11:57 --> URI Class Initialized
INFO - 2025-01-13 07:11:57 --> Router Class Initialized
INFO - 2025-01-13 07:11:57 --> Output Class Initialized
INFO - 2025-01-13 07:11:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:11:57 --> Input Class Initialized
INFO - 2025-01-13 07:11:57 --> Language Class Initialized
INFO - 2025-01-13 07:11:57 --> Loader Class Initialized
INFO - 2025-01-13 07:11:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:11:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:11:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:11:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:11:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:11:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:11:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:11:57 --> Upload Class Initialized
INFO - 2025-01-13 07:11:57 --> Email Class Initialized
INFO - 2025-01-13 07:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:11:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:11:57 --> Controller Class Initialized
INFO - 2025-01-13 12:41:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:41:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:41:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:12:57 --> Config Class Initialized
INFO - 2025-01-13 07:12:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:12:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:12:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:12:57 --> URI Class Initialized
INFO - 2025-01-13 07:12:57 --> Router Class Initialized
INFO - 2025-01-13 07:12:57 --> Output Class Initialized
INFO - 2025-01-13 07:12:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:12:57 --> Input Class Initialized
INFO - 2025-01-13 07:12:57 --> Language Class Initialized
INFO - 2025-01-13 07:12:57 --> Loader Class Initialized
INFO - 2025-01-13 07:12:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:12:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:12:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:12:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:12:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:12:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:12:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:12:57 --> Upload Class Initialized
INFO - 2025-01-13 07:12:57 --> Email Class Initialized
INFO - 2025-01-13 07:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:12:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:12:57 --> Controller Class Initialized
INFO - 2025-01-13 12:42:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:42:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:42:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:13:57 --> Config Class Initialized
INFO - 2025-01-13 07:13:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:13:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:13:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:13:57 --> URI Class Initialized
INFO - 2025-01-13 07:13:57 --> Router Class Initialized
INFO - 2025-01-13 07:13:57 --> Output Class Initialized
INFO - 2025-01-13 07:13:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:13:57 --> Input Class Initialized
INFO - 2025-01-13 07:13:57 --> Language Class Initialized
INFO - 2025-01-13 07:13:57 --> Loader Class Initialized
INFO - 2025-01-13 07:13:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:13:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:13:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:13:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:13:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:13:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:13:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:13:57 --> Upload Class Initialized
INFO - 2025-01-13 07:13:57 --> Email Class Initialized
INFO - 2025-01-13 07:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:13:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:13:57 --> Controller Class Initialized
INFO - 2025-01-13 12:43:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:43:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:43:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:14:57 --> Config Class Initialized
INFO - 2025-01-13 07:14:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:14:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:14:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:14:57 --> URI Class Initialized
INFO - 2025-01-13 07:14:57 --> Router Class Initialized
INFO - 2025-01-13 07:14:57 --> Output Class Initialized
INFO - 2025-01-13 07:14:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:14:57 --> Input Class Initialized
INFO - 2025-01-13 07:14:57 --> Language Class Initialized
INFO - 2025-01-13 07:14:57 --> Loader Class Initialized
INFO - 2025-01-13 07:14:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:14:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:14:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:14:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:14:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:14:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:14:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:14:57 --> Upload Class Initialized
INFO - 2025-01-13 07:14:57 --> Email Class Initialized
INFO - 2025-01-13 07:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:14:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:14:57 --> Controller Class Initialized
INFO - 2025-01-13 12:44:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:44:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:44:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:15:57 --> Config Class Initialized
INFO - 2025-01-13 07:15:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:15:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:15:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:15:57 --> URI Class Initialized
INFO - 2025-01-13 07:15:57 --> Router Class Initialized
INFO - 2025-01-13 07:15:57 --> Output Class Initialized
INFO - 2025-01-13 07:15:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:15:57 --> Input Class Initialized
INFO - 2025-01-13 07:15:57 --> Language Class Initialized
INFO - 2025-01-13 07:15:57 --> Loader Class Initialized
INFO - 2025-01-13 07:15:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:15:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:15:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:15:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:15:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:15:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:15:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:15:57 --> Upload Class Initialized
INFO - 2025-01-13 07:15:57 --> Email Class Initialized
INFO - 2025-01-13 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:15:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:15:57 --> Controller Class Initialized
INFO - 2025-01-13 12:45:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:45:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:45:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:16:57 --> Config Class Initialized
INFO - 2025-01-13 07:16:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:16:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:16:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:16:57 --> URI Class Initialized
INFO - 2025-01-13 07:16:57 --> Router Class Initialized
INFO - 2025-01-13 07:16:57 --> Output Class Initialized
INFO - 2025-01-13 07:16:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:16:57 --> Input Class Initialized
INFO - 2025-01-13 07:16:57 --> Language Class Initialized
INFO - 2025-01-13 07:16:57 --> Loader Class Initialized
INFO - 2025-01-13 07:16:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:16:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:16:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:16:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:16:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:16:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:16:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:16:57 --> Upload Class Initialized
INFO - 2025-01-13 07:16:57 --> Email Class Initialized
INFO - 2025-01-13 07:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:16:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:16:57 --> Controller Class Initialized
INFO - 2025-01-13 12:46:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:46:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:46:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:17:57 --> Config Class Initialized
INFO - 2025-01-13 07:17:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:17:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:17:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:17:57 --> URI Class Initialized
INFO - 2025-01-13 07:17:57 --> Router Class Initialized
INFO - 2025-01-13 07:17:57 --> Output Class Initialized
INFO - 2025-01-13 07:17:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:17:57 --> Input Class Initialized
INFO - 2025-01-13 07:17:57 --> Language Class Initialized
INFO - 2025-01-13 07:17:57 --> Loader Class Initialized
INFO - 2025-01-13 07:17:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:17:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:17:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:17:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:17:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:17:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:17:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:17:57 --> Upload Class Initialized
INFO - 2025-01-13 07:17:57 --> Email Class Initialized
INFO - 2025-01-13 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:17:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:17:57 --> Controller Class Initialized
INFO - 2025-01-13 12:47:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:47:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:47:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:03 --> Config Class Initialized
INFO - 2025-01-13 07:18:03 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:03 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:03 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:03 --> URI Class Initialized
INFO - 2025-01-13 07:18:03 --> Router Class Initialized
INFO - 2025-01-13 07:18:03 --> Output Class Initialized
INFO - 2025-01-13 07:18:03 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:03 --> Input Class Initialized
INFO - 2025-01-13 07:18:03 --> Language Class Initialized
INFO - 2025-01-13 07:18:03 --> Loader Class Initialized
INFO - 2025-01-13 07:18:03 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:03 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:03 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:03 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:03 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:03 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:03 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:03 --> Upload Class Initialized
INFO - 2025-01-13 07:18:03 --> Email Class Initialized
INFO - 2025-01-13 07:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:03 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:03 --> Controller Class Initialized
INFO - 2025-01-13 12:48:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:03 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:03 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:04 --> Config Class Initialized
INFO - 2025-01-13 07:18:04 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:04 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:04 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:04 --> URI Class Initialized
INFO - 2025-01-13 07:18:04 --> Router Class Initialized
INFO - 2025-01-13 07:18:04 --> Output Class Initialized
INFO - 2025-01-13 07:18:04 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:04 --> Input Class Initialized
INFO - 2025-01-13 07:18:04 --> Language Class Initialized
INFO - 2025-01-13 07:18:04 --> Loader Class Initialized
INFO - 2025-01-13 07:18:04 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:04 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:04 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:04 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:04 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:04 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:04 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:04 --> Upload Class Initialized
INFO - 2025-01-13 07:18:04 --> Email Class Initialized
INFO - 2025-01-13 07:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:04 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:04 --> Controller Class Initialized
INFO - 2025-01-13 12:48:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:04 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:04 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:09 --> Config Class Initialized
INFO - 2025-01-13 07:18:09 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:09 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:09 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:09 --> URI Class Initialized
INFO - 2025-01-13 07:18:09 --> Router Class Initialized
INFO - 2025-01-13 07:18:09 --> Output Class Initialized
INFO - 2025-01-13 07:18:09 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:09 --> Input Class Initialized
INFO - 2025-01-13 07:18:09 --> Language Class Initialized
INFO - 2025-01-13 07:18:09 --> Loader Class Initialized
INFO - 2025-01-13 07:18:09 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:09 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:09 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:09 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:09 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:09 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:09 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:09 --> Upload Class Initialized
INFO - 2025-01-13 07:18:09 --> Email Class Initialized
INFO - 2025-01-13 07:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:09 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:09 --> Controller Class Initialized
INFO - 2025-01-13 12:48:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:09 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:09 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:14 --> Config Class Initialized
INFO - 2025-01-13 07:18:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:14 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:14 --> URI Class Initialized
INFO - 2025-01-13 07:18:14 --> Router Class Initialized
INFO - 2025-01-13 07:18:14 --> Output Class Initialized
INFO - 2025-01-13 07:18:14 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:14 --> Input Class Initialized
INFO - 2025-01-13 07:18:14 --> Language Class Initialized
INFO - 2025-01-13 07:18:14 --> Loader Class Initialized
INFO - 2025-01-13 07:18:14 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:14 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:14 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:14 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:14 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:14 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:14 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:14 --> Upload Class Initialized
INFO - 2025-01-13 07:18:14 --> Email Class Initialized
INFO - 2025-01-13 07:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:14 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:14 --> Controller Class Initialized
INFO - 2025-01-13 12:48:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:14 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:14 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:19 --> Config Class Initialized
INFO - 2025-01-13 07:18:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:19 --> URI Class Initialized
INFO - 2025-01-13 07:18:19 --> Router Class Initialized
INFO - 2025-01-13 07:18:19 --> Output Class Initialized
INFO - 2025-01-13 07:18:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:19 --> Input Class Initialized
INFO - 2025-01-13 07:18:19 --> Language Class Initialized
INFO - 2025-01-13 07:18:19 --> Loader Class Initialized
INFO - 2025-01-13 07:18:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:19 --> Upload Class Initialized
INFO - 2025-01-13 07:18:19 --> Email Class Initialized
INFO - 2025-01-13 07:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:19 --> Controller Class Initialized
INFO - 2025-01-13 12:48:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:19 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:24 --> Config Class Initialized
INFO - 2025-01-13 07:18:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:24 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:24 --> URI Class Initialized
INFO - 2025-01-13 07:18:24 --> Router Class Initialized
INFO - 2025-01-13 07:18:24 --> Output Class Initialized
INFO - 2025-01-13 07:18:24 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:24 --> Input Class Initialized
INFO - 2025-01-13 07:18:24 --> Language Class Initialized
INFO - 2025-01-13 07:18:24 --> Loader Class Initialized
INFO - 2025-01-13 07:18:24 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:24 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:24 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:24 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:24 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:24 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:24 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:24 --> Upload Class Initialized
INFO - 2025-01-13 07:18:24 --> Email Class Initialized
INFO - 2025-01-13 07:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:24 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:24 --> Controller Class Initialized
INFO - 2025-01-13 12:48:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:24 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:24 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:29 --> Config Class Initialized
INFO - 2025-01-13 07:18:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:29 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:29 --> URI Class Initialized
INFO - 2025-01-13 07:18:29 --> Router Class Initialized
INFO - 2025-01-13 07:18:29 --> Output Class Initialized
INFO - 2025-01-13 07:18:29 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:29 --> Input Class Initialized
INFO - 2025-01-13 07:18:29 --> Language Class Initialized
INFO - 2025-01-13 07:18:29 --> Loader Class Initialized
INFO - 2025-01-13 07:18:29 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:29 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:29 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:29 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:29 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:29 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:29 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:29 --> Upload Class Initialized
INFO - 2025-01-13 07:18:29 --> Email Class Initialized
INFO - 2025-01-13 07:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:29 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:29 --> Controller Class Initialized
INFO - 2025-01-13 12:48:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:29 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:29 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:34 --> Config Class Initialized
INFO - 2025-01-13 07:18:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:34 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:34 --> URI Class Initialized
INFO - 2025-01-13 07:18:34 --> Router Class Initialized
INFO - 2025-01-13 07:18:34 --> Output Class Initialized
INFO - 2025-01-13 07:18:34 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:34 --> Input Class Initialized
INFO - 2025-01-13 07:18:34 --> Language Class Initialized
INFO - 2025-01-13 07:18:34 --> Loader Class Initialized
INFO - 2025-01-13 07:18:34 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:34 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:34 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:34 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:34 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:34 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:34 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:34 --> Upload Class Initialized
INFO - 2025-01-13 07:18:34 --> Email Class Initialized
INFO - 2025-01-13 07:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:34 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:34 --> Controller Class Initialized
INFO - 2025-01-13 12:48:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:34 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:34 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:39 --> Config Class Initialized
INFO - 2025-01-13 07:18:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:39 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:39 --> URI Class Initialized
INFO - 2025-01-13 07:18:39 --> Router Class Initialized
INFO - 2025-01-13 07:18:39 --> Output Class Initialized
INFO - 2025-01-13 07:18:39 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:39 --> Input Class Initialized
INFO - 2025-01-13 07:18:39 --> Language Class Initialized
INFO - 2025-01-13 07:18:39 --> Loader Class Initialized
INFO - 2025-01-13 07:18:39 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:39 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:39 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:39 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:39 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:39 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:39 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:39 --> Upload Class Initialized
INFO - 2025-01-13 07:18:39 --> Email Class Initialized
INFO - 2025-01-13 07:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:39 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:39 --> Controller Class Initialized
INFO - 2025-01-13 12:48:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:39 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:39 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:44 --> Config Class Initialized
INFO - 2025-01-13 07:18:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:44 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:44 --> URI Class Initialized
INFO - 2025-01-13 07:18:44 --> Router Class Initialized
INFO - 2025-01-13 07:18:44 --> Output Class Initialized
INFO - 2025-01-13 07:18:44 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:44 --> Input Class Initialized
INFO - 2025-01-13 07:18:44 --> Language Class Initialized
INFO - 2025-01-13 07:18:44 --> Loader Class Initialized
INFO - 2025-01-13 07:18:44 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:44 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:44 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:44 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:44 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:44 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:44 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:44 --> Upload Class Initialized
INFO - 2025-01-13 07:18:44 --> Email Class Initialized
INFO - 2025-01-13 07:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:44 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:44 --> Controller Class Initialized
INFO - 2025-01-13 12:48:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:44 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:44 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:49 --> Config Class Initialized
INFO - 2025-01-13 07:18:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:49 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:49 --> URI Class Initialized
INFO - 2025-01-13 07:18:49 --> Router Class Initialized
INFO - 2025-01-13 07:18:49 --> Output Class Initialized
INFO - 2025-01-13 07:18:49 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:49 --> Input Class Initialized
INFO - 2025-01-13 07:18:49 --> Language Class Initialized
INFO - 2025-01-13 07:18:49 --> Loader Class Initialized
INFO - 2025-01-13 07:18:49 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:49 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:49 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:49 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:49 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:49 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:49 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:49 --> Upload Class Initialized
INFO - 2025-01-13 07:18:49 --> Email Class Initialized
INFO - 2025-01-13 07:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:49 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:49 --> Controller Class Initialized
INFO - 2025-01-13 12:48:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:49 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:49 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:54 --> Config Class Initialized
INFO - 2025-01-13 07:18:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:54 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:54 --> URI Class Initialized
INFO - 2025-01-13 07:18:54 --> Router Class Initialized
INFO - 2025-01-13 07:18:54 --> Output Class Initialized
INFO - 2025-01-13 07:18:54 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:54 --> Input Class Initialized
INFO - 2025-01-13 07:18:54 --> Language Class Initialized
INFO - 2025-01-13 07:18:54 --> Loader Class Initialized
INFO - 2025-01-13 07:18:54 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:54 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:54 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:54 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:54 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:54 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:54 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:54 --> Upload Class Initialized
INFO - 2025-01-13 07:18:54 --> Email Class Initialized
INFO - 2025-01-13 07:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:54 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:54 --> Controller Class Initialized
INFO - 2025-01-13 12:48:54 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:54 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:54 --> Pagination Class Initialized
INFO - 2025-01-13 07:18:59 --> Config Class Initialized
INFO - 2025-01-13 07:18:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:18:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:18:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:18:59 --> URI Class Initialized
INFO - 2025-01-13 07:18:59 --> Router Class Initialized
INFO - 2025-01-13 07:18:59 --> Output Class Initialized
INFO - 2025-01-13 07:18:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:18:59 --> Input Class Initialized
INFO - 2025-01-13 07:18:59 --> Language Class Initialized
INFO - 2025-01-13 07:18:59 --> Loader Class Initialized
INFO - 2025-01-13 07:18:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:18:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:18:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:18:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:18:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:18:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:18:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:18:59 --> Upload Class Initialized
INFO - 2025-01-13 07:18:59 --> Email Class Initialized
INFO - 2025-01-13 07:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:18:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:18:59 --> Controller Class Initialized
INFO - 2025-01-13 12:48:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:48:59 --> Model "MainModel" initialized
INFO - 2025-01-13 12:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:48:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:19:57 --> Config Class Initialized
INFO - 2025-01-13 07:19:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:19:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:19:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:19:57 --> URI Class Initialized
INFO - 2025-01-13 07:19:57 --> Router Class Initialized
INFO - 2025-01-13 07:19:57 --> Output Class Initialized
INFO - 2025-01-13 07:19:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:19:57 --> Input Class Initialized
INFO - 2025-01-13 07:19:57 --> Language Class Initialized
INFO - 2025-01-13 07:19:57 --> Loader Class Initialized
INFO - 2025-01-13 07:19:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:19:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:19:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:19:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:19:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:19:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:19:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:19:57 --> Upload Class Initialized
INFO - 2025-01-13 07:19:57 --> Email Class Initialized
INFO - 2025-01-13 07:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:19:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:19:57 --> Controller Class Initialized
INFO - 2025-01-13 12:49:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:49:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:49:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:20:57 --> Config Class Initialized
INFO - 2025-01-13 07:20:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:20:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:20:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:20:57 --> URI Class Initialized
INFO - 2025-01-13 07:20:57 --> Router Class Initialized
INFO - 2025-01-13 07:20:57 --> Output Class Initialized
INFO - 2025-01-13 07:20:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:20:57 --> Input Class Initialized
INFO - 2025-01-13 07:20:57 --> Language Class Initialized
INFO - 2025-01-13 07:20:57 --> Loader Class Initialized
INFO - 2025-01-13 07:20:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:20:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:20:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:20:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:20:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:20:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:20:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:20:57 --> Upload Class Initialized
INFO - 2025-01-13 07:20:57 --> Email Class Initialized
INFO - 2025-01-13 07:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:20:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:20:57 --> Controller Class Initialized
INFO - 2025-01-13 12:50:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:50:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:50:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:21:57 --> Config Class Initialized
INFO - 2025-01-13 07:21:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:21:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:21:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:21:57 --> URI Class Initialized
INFO - 2025-01-13 07:21:57 --> Router Class Initialized
INFO - 2025-01-13 07:21:57 --> Output Class Initialized
INFO - 2025-01-13 07:21:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:21:57 --> Input Class Initialized
INFO - 2025-01-13 07:21:57 --> Language Class Initialized
INFO - 2025-01-13 07:21:57 --> Loader Class Initialized
INFO - 2025-01-13 07:21:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:21:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:21:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:21:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:21:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:21:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:21:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:21:57 --> Upload Class Initialized
INFO - 2025-01-13 07:21:57 --> Email Class Initialized
INFO - 2025-01-13 07:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:21:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:21:57 --> Controller Class Initialized
INFO - 2025-01-13 12:51:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:51:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:51:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:22:57 --> Config Class Initialized
INFO - 2025-01-13 07:22:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:22:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:22:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:22:57 --> URI Class Initialized
INFO - 2025-01-13 07:22:57 --> Router Class Initialized
INFO - 2025-01-13 07:22:57 --> Output Class Initialized
INFO - 2025-01-13 07:22:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:22:57 --> Input Class Initialized
INFO - 2025-01-13 07:22:57 --> Language Class Initialized
INFO - 2025-01-13 07:22:57 --> Loader Class Initialized
INFO - 2025-01-13 07:22:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:22:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:22:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:22:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:22:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:22:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:22:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:22:57 --> Upload Class Initialized
INFO - 2025-01-13 07:22:57 --> Email Class Initialized
INFO - 2025-01-13 07:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:22:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:22:57 --> Controller Class Initialized
INFO - 2025-01-13 12:52:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:52:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:52:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:23:57 --> Config Class Initialized
INFO - 2025-01-13 07:23:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:23:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:23:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:23:57 --> URI Class Initialized
INFO - 2025-01-13 07:23:57 --> Router Class Initialized
INFO - 2025-01-13 07:23:57 --> Output Class Initialized
INFO - 2025-01-13 07:23:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:23:57 --> Input Class Initialized
INFO - 2025-01-13 07:23:57 --> Language Class Initialized
INFO - 2025-01-13 07:23:57 --> Loader Class Initialized
INFO - 2025-01-13 07:23:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:23:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:23:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:23:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:23:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:23:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:23:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:23:57 --> Upload Class Initialized
INFO - 2025-01-13 07:23:57 --> Email Class Initialized
INFO - 2025-01-13 07:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:23:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:23:57 --> Controller Class Initialized
INFO - 2025-01-13 12:53:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:53:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:53:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:24:57 --> Config Class Initialized
INFO - 2025-01-13 07:24:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:24:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:24:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:24:57 --> URI Class Initialized
INFO - 2025-01-13 07:24:57 --> Router Class Initialized
INFO - 2025-01-13 07:24:57 --> Output Class Initialized
INFO - 2025-01-13 07:24:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:24:57 --> Input Class Initialized
INFO - 2025-01-13 07:24:57 --> Language Class Initialized
INFO - 2025-01-13 07:24:57 --> Loader Class Initialized
INFO - 2025-01-13 07:24:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:24:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:24:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:24:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:24:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:24:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:24:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:24:57 --> Upload Class Initialized
INFO - 2025-01-13 07:24:57 --> Email Class Initialized
INFO - 2025-01-13 07:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:24:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:24:57 --> Controller Class Initialized
INFO - 2025-01-13 12:54:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:54:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:54:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:25:57 --> Config Class Initialized
INFO - 2025-01-13 07:25:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:25:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:25:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:25:57 --> URI Class Initialized
INFO - 2025-01-13 07:25:57 --> Router Class Initialized
INFO - 2025-01-13 07:25:57 --> Output Class Initialized
INFO - 2025-01-13 07:25:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:25:57 --> Input Class Initialized
INFO - 2025-01-13 07:25:57 --> Language Class Initialized
INFO - 2025-01-13 07:25:57 --> Loader Class Initialized
INFO - 2025-01-13 07:25:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:25:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:25:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:25:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:25:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:25:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:25:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:25:57 --> Upload Class Initialized
INFO - 2025-01-13 07:25:57 --> Email Class Initialized
INFO - 2025-01-13 07:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:25:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:25:57 --> Controller Class Initialized
INFO - 2025-01-13 12:55:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:55:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:55:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:26:57 --> Config Class Initialized
INFO - 2025-01-13 07:26:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:26:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:26:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:26:57 --> URI Class Initialized
INFO - 2025-01-13 07:26:57 --> Router Class Initialized
INFO - 2025-01-13 07:26:57 --> Output Class Initialized
INFO - 2025-01-13 07:26:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:26:57 --> Input Class Initialized
INFO - 2025-01-13 07:26:57 --> Language Class Initialized
INFO - 2025-01-13 07:26:57 --> Loader Class Initialized
INFO - 2025-01-13 07:26:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:26:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:26:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:26:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:26:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:26:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:26:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:26:57 --> Upload Class Initialized
INFO - 2025-01-13 07:26:57 --> Email Class Initialized
INFO - 2025-01-13 07:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:26:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:26:57 --> Controller Class Initialized
INFO - 2025-01-13 12:56:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:56:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:56:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:27:57 --> Config Class Initialized
INFO - 2025-01-13 07:27:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:27:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:27:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:27:57 --> URI Class Initialized
INFO - 2025-01-13 07:27:57 --> Router Class Initialized
INFO - 2025-01-13 07:27:57 --> Output Class Initialized
INFO - 2025-01-13 07:27:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:27:57 --> Input Class Initialized
INFO - 2025-01-13 07:27:57 --> Language Class Initialized
INFO - 2025-01-13 07:27:57 --> Loader Class Initialized
INFO - 2025-01-13 07:27:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:27:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:27:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:27:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:27:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:27:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:27:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:27:57 --> Upload Class Initialized
INFO - 2025-01-13 07:27:57 --> Email Class Initialized
INFO - 2025-01-13 07:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:27:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:27:57 --> Controller Class Initialized
INFO - 2025-01-13 12:57:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:57:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:57:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:28:57 --> Config Class Initialized
INFO - 2025-01-13 07:28:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:28:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:28:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:28:57 --> URI Class Initialized
INFO - 2025-01-13 07:28:57 --> Router Class Initialized
INFO - 2025-01-13 07:28:57 --> Output Class Initialized
INFO - 2025-01-13 07:28:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:28:57 --> Input Class Initialized
INFO - 2025-01-13 07:28:57 --> Language Class Initialized
INFO - 2025-01-13 07:28:57 --> Loader Class Initialized
INFO - 2025-01-13 07:28:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:28:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:28:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:28:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:28:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:28:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:28:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:28:57 --> Upload Class Initialized
INFO - 2025-01-13 07:28:57 --> Email Class Initialized
INFO - 2025-01-13 07:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:28:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:28:57 --> Controller Class Initialized
INFO - 2025-01-13 12:58:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:58:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:58:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:29:57 --> Config Class Initialized
INFO - 2025-01-13 07:29:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:29:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:29:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:29:57 --> URI Class Initialized
INFO - 2025-01-13 07:29:57 --> Router Class Initialized
INFO - 2025-01-13 07:29:57 --> Output Class Initialized
INFO - 2025-01-13 07:29:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:29:57 --> Input Class Initialized
INFO - 2025-01-13 07:29:57 --> Language Class Initialized
INFO - 2025-01-13 07:29:57 --> Loader Class Initialized
INFO - 2025-01-13 07:29:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:29:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:29:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:29:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:29:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:29:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:29:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:29:57 --> Upload Class Initialized
INFO - 2025-01-13 07:29:57 --> Email Class Initialized
INFO - 2025-01-13 07:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:29:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:29:57 --> Controller Class Initialized
INFO - 2025-01-13 12:59:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 12:59:57 --> Model "MainModel" initialized
INFO - 2025-01-13 12:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 12:59:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:30:57 --> Config Class Initialized
INFO - 2025-01-13 07:30:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:30:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:30:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:30:57 --> URI Class Initialized
INFO - 2025-01-13 07:30:57 --> Router Class Initialized
INFO - 2025-01-13 07:30:57 --> Output Class Initialized
INFO - 2025-01-13 07:30:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:30:57 --> Input Class Initialized
INFO - 2025-01-13 07:30:57 --> Language Class Initialized
INFO - 2025-01-13 07:30:57 --> Loader Class Initialized
INFO - 2025-01-13 07:30:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:30:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:30:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:30:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:30:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:30:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:30:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:30:57 --> Upload Class Initialized
INFO - 2025-01-13 07:30:57 --> Email Class Initialized
INFO - 2025-01-13 07:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:30:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:30:57 --> Controller Class Initialized
INFO - 2025-01-13 13:00:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:00:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:00:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:31:57 --> Config Class Initialized
INFO - 2025-01-13 07:31:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:31:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:31:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:31:57 --> URI Class Initialized
INFO - 2025-01-13 07:31:57 --> Router Class Initialized
INFO - 2025-01-13 07:31:57 --> Output Class Initialized
INFO - 2025-01-13 07:31:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:31:57 --> Input Class Initialized
INFO - 2025-01-13 07:31:57 --> Language Class Initialized
INFO - 2025-01-13 07:31:57 --> Loader Class Initialized
INFO - 2025-01-13 07:31:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:31:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:31:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:31:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:31:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:31:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:31:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:31:57 --> Upload Class Initialized
INFO - 2025-01-13 07:31:57 --> Email Class Initialized
INFO - 2025-01-13 07:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:31:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:31:57 --> Controller Class Initialized
INFO - 2025-01-13 13:01:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:01:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:01:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:32:57 --> Config Class Initialized
INFO - 2025-01-13 07:32:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:32:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:32:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:32:57 --> URI Class Initialized
INFO - 2025-01-13 07:32:57 --> Router Class Initialized
INFO - 2025-01-13 07:32:57 --> Output Class Initialized
INFO - 2025-01-13 07:32:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:32:57 --> Input Class Initialized
INFO - 2025-01-13 07:32:57 --> Language Class Initialized
INFO - 2025-01-13 07:32:57 --> Loader Class Initialized
INFO - 2025-01-13 07:32:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:32:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:32:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:32:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:32:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:32:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:32:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:32:57 --> Upload Class Initialized
INFO - 2025-01-13 07:32:57 --> Email Class Initialized
INFO - 2025-01-13 07:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:32:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:32:57 --> Controller Class Initialized
INFO - 2025-01-13 13:02:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:02:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:02:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:33:57 --> Config Class Initialized
INFO - 2025-01-13 07:33:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:33:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:33:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:33:57 --> URI Class Initialized
INFO - 2025-01-13 07:33:57 --> Router Class Initialized
INFO - 2025-01-13 07:33:57 --> Output Class Initialized
INFO - 2025-01-13 07:33:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:33:57 --> Input Class Initialized
INFO - 2025-01-13 07:33:57 --> Language Class Initialized
INFO - 2025-01-13 07:33:57 --> Loader Class Initialized
INFO - 2025-01-13 07:33:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:33:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:33:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:33:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:33:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:33:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:33:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:33:57 --> Upload Class Initialized
INFO - 2025-01-13 07:33:57 --> Email Class Initialized
INFO - 2025-01-13 07:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:33:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:33:57 --> Controller Class Initialized
INFO - 2025-01-13 13:03:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:03:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:03:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:34:57 --> Config Class Initialized
INFO - 2025-01-13 07:34:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:34:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:34:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:34:57 --> URI Class Initialized
INFO - 2025-01-13 07:34:57 --> Router Class Initialized
INFO - 2025-01-13 07:34:57 --> Output Class Initialized
INFO - 2025-01-13 07:34:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:34:57 --> Input Class Initialized
INFO - 2025-01-13 07:34:57 --> Language Class Initialized
INFO - 2025-01-13 07:34:57 --> Loader Class Initialized
INFO - 2025-01-13 07:34:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:34:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:34:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:34:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:34:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:34:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:34:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:34:57 --> Upload Class Initialized
INFO - 2025-01-13 07:34:57 --> Email Class Initialized
INFO - 2025-01-13 07:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:34:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:34:57 --> Controller Class Initialized
INFO - 2025-01-13 13:04:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:04:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:04:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:35:57 --> Config Class Initialized
INFO - 2025-01-13 07:35:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:35:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:35:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:35:57 --> URI Class Initialized
INFO - 2025-01-13 07:35:57 --> Router Class Initialized
INFO - 2025-01-13 07:35:57 --> Output Class Initialized
INFO - 2025-01-13 07:35:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:35:57 --> Input Class Initialized
INFO - 2025-01-13 07:35:57 --> Language Class Initialized
INFO - 2025-01-13 07:35:57 --> Loader Class Initialized
INFO - 2025-01-13 07:35:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:35:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:35:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:35:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:35:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:35:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:35:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:35:57 --> Upload Class Initialized
INFO - 2025-01-13 07:35:57 --> Email Class Initialized
INFO - 2025-01-13 07:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:35:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:35:57 --> Controller Class Initialized
INFO - 2025-01-13 13:05:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:05:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:05:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:36:57 --> Config Class Initialized
INFO - 2025-01-13 07:36:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:36:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:36:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:36:57 --> URI Class Initialized
INFO - 2025-01-13 07:36:57 --> Router Class Initialized
INFO - 2025-01-13 07:36:57 --> Output Class Initialized
INFO - 2025-01-13 07:36:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:36:57 --> Input Class Initialized
INFO - 2025-01-13 07:36:57 --> Language Class Initialized
INFO - 2025-01-13 07:36:57 --> Loader Class Initialized
INFO - 2025-01-13 07:36:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:36:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:36:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:36:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:36:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:36:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:36:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:36:57 --> Upload Class Initialized
INFO - 2025-01-13 07:36:57 --> Email Class Initialized
INFO - 2025-01-13 07:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:36:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:36:57 --> Controller Class Initialized
INFO - 2025-01-13 13:06:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:06:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:06:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:37:57 --> Config Class Initialized
INFO - 2025-01-13 07:37:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:37:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:37:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:37:57 --> URI Class Initialized
INFO - 2025-01-13 07:37:57 --> Router Class Initialized
INFO - 2025-01-13 07:37:57 --> Output Class Initialized
INFO - 2025-01-13 07:37:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:37:57 --> Input Class Initialized
INFO - 2025-01-13 07:37:57 --> Language Class Initialized
INFO - 2025-01-13 07:37:57 --> Loader Class Initialized
INFO - 2025-01-13 07:37:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:37:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:37:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:37:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:37:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:37:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:37:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:37:57 --> Upload Class Initialized
INFO - 2025-01-13 07:37:57 --> Email Class Initialized
INFO - 2025-01-13 07:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:37:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:37:57 --> Controller Class Initialized
INFO - 2025-01-13 13:07:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:07:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:07:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:38:57 --> Config Class Initialized
INFO - 2025-01-13 07:38:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:38:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:38:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:38:57 --> URI Class Initialized
INFO - 2025-01-13 07:38:57 --> Router Class Initialized
INFO - 2025-01-13 07:38:57 --> Output Class Initialized
INFO - 2025-01-13 07:38:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:38:57 --> Input Class Initialized
INFO - 2025-01-13 07:38:57 --> Language Class Initialized
INFO - 2025-01-13 07:38:57 --> Loader Class Initialized
INFO - 2025-01-13 07:38:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:38:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:38:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:38:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:38:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:38:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:38:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:38:57 --> Upload Class Initialized
INFO - 2025-01-13 07:38:57 --> Email Class Initialized
INFO - 2025-01-13 07:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:38:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:38:57 --> Controller Class Initialized
INFO - 2025-01-13 13:08:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:08:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:08:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:39:57 --> Config Class Initialized
INFO - 2025-01-13 07:39:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:39:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:39:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:39:57 --> URI Class Initialized
INFO - 2025-01-13 07:39:57 --> Router Class Initialized
INFO - 2025-01-13 07:39:57 --> Output Class Initialized
INFO - 2025-01-13 07:39:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:39:57 --> Input Class Initialized
INFO - 2025-01-13 07:39:57 --> Language Class Initialized
INFO - 2025-01-13 07:39:57 --> Loader Class Initialized
INFO - 2025-01-13 07:39:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:39:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:39:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:39:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:39:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:39:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:39:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:39:57 --> Upload Class Initialized
INFO - 2025-01-13 07:39:57 --> Email Class Initialized
INFO - 2025-01-13 07:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:39:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:39:57 --> Controller Class Initialized
INFO - 2025-01-13 13:09:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:09:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:09:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:40:57 --> Config Class Initialized
INFO - 2025-01-13 07:40:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:40:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:40:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:40:57 --> URI Class Initialized
INFO - 2025-01-13 07:40:57 --> Router Class Initialized
INFO - 2025-01-13 07:40:57 --> Output Class Initialized
INFO - 2025-01-13 07:40:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:40:57 --> Input Class Initialized
INFO - 2025-01-13 07:40:57 --> Language Class Initialized
INFO - 2025-01-13 07:40:57 --> Loader Class Initialized
INFO - 2025-01-13 07:40:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:40:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:40:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:40:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:40:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:40:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:40:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:40:57 --> Upload Class Initialized
INFO - 2025-01-13 07:40:57 --> Email Class Initialized
INFO - 2025-01-13 07:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:40:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:40:57 --> Controller Class Initialized
INFO - 2025-01-13 13:10:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:10:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:10:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:41:57 --> Config Class Initialized
INFO - 2025-01-13 07:41:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:41:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:41:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:41:57 --> URI Class Initialized
INFO - 2025-01-13 07:41:57 --> Router Class Initialized
INFO - 2025-01-13 07:41:57 --> Output Class Initialized
INFO - 2025-01-13 07:41:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:41:57 --> Input Class Initialized
INFO - 2025-01-13 07:41:57 --> Language Class Initialized
INFO - 2025-01-13 07:41:57 --> Loader Class Initialized
INFO - 2025-01-13 07:41:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:41:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:41:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:41:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:41:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:41:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:41:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:41:57 --> Upload Class Initialized
INFO - 2025-01-13 07:41:57 --> Email Class Initialized
INFO - 2025-01-13 07:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:41:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:41:57 --> Controller Class Initialized
INFO - 2025-01-13 13:11:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:11:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:11:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:42:57 --> Config Class Initialized
INFO - 2025-01-13 07:42:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:42:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:42:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:42:57 --> URI Class Initialized
INFO - 2025-01-13 07:42:57 --> Router Class Initialized
INFO - 2025-01-13 07:42:57 --> Output Class Initialized
INFO - 2025-01-13 07:42:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:42:57 --> Input Class Initialized
INFO - 2025-01-13 07:42:57 --> Language Class Initialized
INFO - 2025-01-13 07:42:57 --> Loader Class Initialized
INFO - 2025-01-13 07:42:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:42:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:42:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:42:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:42:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:42:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:42:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:42:57 --> Upload Class Initialized
INFO - 2025-01-13 07:42:57 --> Email Class Initialized
INFO - 2025-01-13 07:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:42:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:42:57 --> Controller Class Initialized
INFO - 2025-01-13 13:12:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:12:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:12:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:43:57 --> Config Class Initialized
INFO - 2025-01-13 07:43:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:43:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:43:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:43:57 --> URI Class Initialized
INFO - 2025-01-13 07:43:57 --> Router Class Initialized
INFO - 2025-01-13 07:43:57 --> Output Class Initialized
INFO - 2025-01-13 07:43:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:43:57 --> Input Class Initialized
INFO - 2025-01-13 07:43:57 --> Language Class Initialized
INFO - 2025-01-13 07:43:57 --> Loader Class Initialized
INFO - 2025-01-13 07:43:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:43:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:43:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:43:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:43:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:43:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:43:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:43:57 --> Upload Class Initialized
INFO - 2025-01-13 07:43:57 --> Email Class Initialized
INFO - 2025-01-13 07:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:43:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:43:57 --> Controller Class Initialized
INFO - 2025-01-13 13:13:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:13:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:13:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:44:57 --> Config Class Initialized
INFO - 2025-01-13 07:44:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:44:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:44:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:44:57 --> URI Class Initialized
INFO - 2025-01-13 07:44:57 --> Router Class Initialized
INFO - 2025-01-13 07:44:57 --> Output Class Initialized
INFO - 2025-01-13 07:44:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:44:57 --> Input Class Initialized
INFO - 2025-01-13 07:44:57 --> Language Class Initialized
INFO - 2025-01-13 07:44:57 --> Loader Class Initialized
INFO - 2025-01-13 07:44:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:44:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:44:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:44:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:44:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:44:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:44:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:44:57 --> Upload Class Initialized
INFO - 2025-01-13 07:44:57 --> Email Class Initialized
INFO - 2025-01-13 07:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:44:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:44:57 --> Controller Class Initialized
INFO - 2025-01-13 13:14:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:14:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:14:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:45:57 --> Config Class Initialized
INFO - 2025-01-13 07:45:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:45:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:45:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:45:57 --> URI Class Initialized
INFO - 2025-01-13 07:45:57 --> Router Class Initialized
INFO - 2025-01-13 07:45:57 --> Output Class Initialized
INFO - 2025-01-13 07:45:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:45:57 --> Input Class Initialized
INFO - 2025-01-13 07:45:57 --> Language Class Initialized
INFO - 2025-01-13 07:45:57 --> Loader Class Initialized
INFO - 2025-01-13 07:45:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:45:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:45:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:45:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:45:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:45:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:45:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:45:57 --> Upload Class Initialized
INFO - 2025-01-13 07:45:57 --> Email Class Initialized
INFO - 2025-01-13 07:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:45:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:45:57 --> Controller Class Initialized
INFO - 2025-01-13 13:15:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:15:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:15:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:46:57 --> Config Class Initialized
INFO - 2025-01-13 07:46:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:46:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:46:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:46:57 --> URI Class Initialized
INFO - 2025-01-13 07:46:57 --> Router Class Initialized
INFO - 2025-01-13 07:46:57 --> Output Class Initialized
INFO - 2025-01-13 07:46:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:46:57 --> Input Class Initialized
INFO - 2025-01-13 07:46:57 --> Language Class Initialized
INFO - 2025-01-13 07:46:57 --> Loader Class Initialized
INFO - 2025-01-13 07:46:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:46:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:46:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:46:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:46:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:46:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:46:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:46:57 --> Upload Class Initialized
INFO - 2025-01-13 07:46:57 --> Email Class Initialized
INFO - 2025-01-13 07:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:46:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:46:57 --> Controller Class Initialized
INFO - 2025-01-13 13:16:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:16:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:16:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:47:57 --> Config Class Initialized
INFO - 2025-01-13 07:47:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:47:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:47:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:47:57 --> URI Class Initialized
INFO - 2025-01-13 07:47:57 --> Router Class Initialized
INFO - 2025-01-13 07:47:57 --> Output Class Initialized
INFO - 2025-01-13 07:47:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:47:57 --> Input Class Initialized
INFO - 2025-01-13 07:47:57 --> Language Class Initialized
INFO - 2025-01-13 07:47:57 --> Loader Class Initialized
INFO - 2025-01-13 07:47:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:47:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:47:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:47:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:47:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:47:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:47:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:47:57 --> Upload Class Initialized
INFO - 2025-01-13 07:47:57 --> Email Class Initialized
INFO - 2025-01-13 07:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:47:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:47:57 --> Controller Class Initialized
INFO - 2025-01-13 13:17:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:17:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:17:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:48:57 --> Config Class Initialized
INFO - 2025-01-13 07:48:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:48:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:48:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:48:57 --> URI Class Initialized
INFO - 2025-01-13 07:48:57 --> Router Class Initialized
INFO - 2025-01-13 07:48:57 --> Output Class Initialized
INFO - 2025-01-13 07:48:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:48:57 --> Input Class Initialized
INFO - 2025-01-13 07:48:57 --> Language Class Initialized
INFO - 2025-01-13 07:48:57 --> Loader Class Initialized
INFO - 2025-01-13 07:48:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:48:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:48:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:48:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:48:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:48:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:48:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:48:57 --> Upload Class Initialized
INFO - 2025-01-13 07:48:57 --> Email Class Initialized
INFO - 2025-01-13 07:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:48:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:48:57 --> Controller Class Initialized
INFO - 2025-01-13 13:18:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:18:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:18:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:49:57 --> Config Class Initialized
INFO - 2025-01-13 07:49:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:49:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:49:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:49:57 --> URI Class Initialized
INFO - 2025-01-13 07:49:57 --> Router Class Initialized
INFO - 2025-01-13 07:49:57 --> Output Class Initialized
INFO - 2025-01-13 07:49:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:49:57 --> Input Class Initialized
INFO - 2025-01-13 07:49:57 --> Language Class Initialized
INFO - 2025-01-13 07:49:57 --> Loader Class Initialized
INFO - 2025-01-13 07:49:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:49:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:49:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:49:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:49:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:49:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:49:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:49:57 --> Upload Class Initialized
INFO - 2025-01-13 07:49:57 --> Email Class Initialized
INFO - 2025-01-13 07:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:49:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:49:57 --> Controller Class Initialized
INFO - 2025-01-13 13:19:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:19:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:19:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:50:59 --> Config Class Initialized
INFO - 2025-01-13 07:50:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:50:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:50:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:50:59 --> URI Class Initialized
INFO - 2025-01-13 07:50:59 --> Router Class Initialized
INFO - 2025-01-13 07:50:59 --> Output Class Initialized
INFO - 2025-01-13 07:50:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:50:59 --> Input Class Initialized
INFO - 2025-01-13 07:50:59 --> Language Class Initialized
INFO - 2025-01-13 07:50:59 --> Loader Class Initialized
INFO - 2025-01-13 07:50:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:50:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:50:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:50:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:50:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:50:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:50:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:50:59 --> Upload Class Initialized
INFO - 2025-01-13 07:50:59 --> Email Class Initialized
INFO - 2025-01-13 07:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:50:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:50:59 --> Controller Class Initialized
INFO - 2025-01-13 13:20:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:20:59 --> Model "MainModel" initialized
INFO - 2025-01-13 13:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:20:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:51:59 --> Config Class Initialized
INFO - 2025-01-13 07:51:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:51:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:51:59 --> Utf8 Class Initialized
INFO - 2025-01-13 07:51:59 --> URI Class Initialized
INFO - 2025-01-13 07:51:59 --> Router Class Initialized
INFO - 2025-01-13 07:51:59 --> Output Class Initialized
INFO - 2025-01-13 07:51:59 --> Security Class Initialized
DEBUG - 2025-01-13 07:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:51:59 --> Input Class Initialized
INFO - 2025-01-13 07:51:59 --> Language Class Initialized
INFO - 2025-01-13 07:51:59 --> Loader Class Initialized
INFO - 2025-01-13 07:51:59 --> Helper loaded: url_helper
INFO - 2025-01-13 07:51:59 --> Helper loaded: html_helper
INFO - 2025-01-13 07:51:59 --> Helper loaded: file_helper
INFO - 2025-01-13 07:51:59 --> Helper loaded: string_helper
INFO - 2025-01-13 07:51:59 --> Helper loaded: form_helper
INFO - 2025-01-13 07:51:59 --> Helper loaded: my_helper
INFO - 2025-01-13 07:51:59 --> Database Driver Class Initialized
INFO - 2025-01-13 07:51:59 --> Upload Class Initialized
INFO - 2025-01-13 07:51:59 --> Email Class Initialized
INFO - 2025-01-13 07:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:51:59 --> Form Validation Class Initialized
INFO - 2025-01-13 07:51:59 --> Controller Class Initialized
INFO - 2025-01-13 13:21:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:21:59 --> Model "MainModel" initialized
INFO - 2025-01-13 13:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:21:59 --> Pagination Class Initialized
INFO - 2025-01-13 07:52:02 --> Config Class Initialized
INFO - 2025-01-13 07:52:02 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:52:02 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:52:02 --> Utf8 Class Initialized
INFO - 2025-01-13 07:52:02 --> URI Class Initialized
INFO - 2025-01-13 07:52:02 --> Router Class Initialized
INFO - 2025-01-13 07:52:02 --> Output Class Initialized
INFO - 2025-01-13 07:52:02 --> Security Class Initialized
DEBUG - 2025-01-13 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:52:02 --> Input Class Initialized
INFO - 2025-01-13 07:52:02 --> Language Class Initialized
INFO - 2025-01-13 07:52:02 --> Loader Class Initialized
INFO - 2025-01-13 07:52:02 --> Helper loaded: url_helper
INFO - 2025-01-13 07:52:02 --> Helper loaded: html_helper
INFO - 2025-01-13 07:52:02 --> Helper loaded: file_helper
INFO - 2025-01-13 07:52:02 --> Helper loaded: string_helper
INFO - 2025-01-13 07:52:02 --> Helper loaded: form_helper
INFO - 2025-01-13 07:52:02 --> Helper loaded: my_helper
INFO - 2025-01-13 07:52:02 --> Database Driver Class Initialized
INFO - 2025-01-13 07:52:02 --> Upload Class Initialized
INFO - 2025-01-13 07:52:02 --> Email Class Initialized
INFO - 2025-01-13 07:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:52:02 --> Form Validation Class Initialized
INFO - 2025-01-13 07:52:02 --> Controller Class Initialized
INFO - 2025-01-13 13:22:02 --> Model "ApiModel" initialized
INFO - 2025-01-13 13:22:02 --> Helper loaded: notification_helper
INFO - 2025-01-13 13:22:02 --> Model "MainModel" initialized
INFO - 2025-01-13 07:52:57 --> Config Class Initialized
INFO - 2025-01-13 07:52:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:52:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:52:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:52:57 --> URI Class Initialized
INFO - 2025-01-13 07:52:57 --> Router Class Initialized
INFO - 2025-01-13 07:52:57 --> Output Class Initialized
INFO - 2025-01-13 07:52:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:52:57 --> Input Class Initialized
INFO - 2025-01-13 07:52:57 --> Language Class Initialized
INFO - 2025-01-13 07:52:57 --> Loader Class Initialized
INFO - 2025-01-13 07:52:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:52:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:52:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:52:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:52:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:52:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:52:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:52:57 --> Upload Class Initialized
INFO - 2025-01-13 07:52:57 --> Email Class Initialized
INFO - 2025-01-13 07:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:52:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:52:57 --> Controller Class Initialized
INFO - 2025-01-13 13:22:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:22:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:22:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:53:57 --> Config Class Initialized
INFO - 2025-01-13 07:53:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:53:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:53:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:53:57 --> URI Class Initialized
INFO - 2025-01-13 07:53:57 --> Router Class Initialized
INFO - 2025-01-13 07:53:57 --> Output Class Initialized
INFO - 2025-01-13 07:53:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:53:57 --> Input Class Initialized
INFO - 2025-01-13 07:53:57 --> Language Class Initialized
INFO - 2025-01-13 07:53:57 --> Loader Class Initialized
INFO - 2025-01-13 07:53:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:53:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:53:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:53:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:53:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:53:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:53:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:53:57 --> Upload Class Initialized
INFO - 2025-01-13 07:53:57 --> Email Class Initialized
INFO - 2025-01-13 07:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:53:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:53:57 --> Controller Class Initialized
INFO - 2025-01-13 13:23:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:23:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:23:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:54:57 --> Config Class Initialized
INFO - 2025-01-13 07:54:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:54:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:54:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:54:57 --> URI Class Initialized
INFO - 2025-01-13 07:54:57 --> Router Class Initialized
INFO - 2025-01-13 07:54:57 --> Output Class Initialized
INFO - 2025-01-13 07:54:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:54:57 --> Input Class Initialized
INFO - 2025-01-13 07:54:57 --> Language Class Initialized
INFO - 2025-01-13 07:54:57 --> Loader Class Initialized
INFO - 2025-01-13 07:54:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:54:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:54:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:54:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:54:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:54:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:54:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:54:57 --> Upload Class Initialized
INFO - 2025-01-13 07:54:57 --> Email Class Initialized
INFO - 2025-01-13 07:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:54:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:54:57 --> Controller Class Initialized
INFO - 2025-01-13 13:24:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:24:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:24:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:55:17 --> Config Class Initialized
INFO - 2025-01-13 07:55:17 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:55:17 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:55:17 --> Utf8 Class Initialized
INFO - 2025-01-13 07:55:17 --> URI Class Initialized
INFO - 2025-01-13 07:55:17 --> Router Class Initialized
INFO - 2025-01-13 07:55:17 --> Output Class Initialized
INFO - 2025-01-13 07:55:17 --> Security Class Initialized
DEBUG - 2025-01-13 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:55:17 --> Input Class Initialized
INFO - 2025-01-13 07:55:17 --> Language Class Initialized
INFO - 2025-01-13 07:55:17 --> Loader Class Initialized
INFO - 2025-01-13 07:55:17 --> Helper loaded: url_helper
INFO - 2025-01-13 07:55:17 --> Helper loaded: html_helper
INFO - 2025-01-13 07:55:17 --> Helper loaded: file_helper
INFO - 2025-01-13 07:55:17 --> Helper loaded: string_helper
INFO - 2025-01-13 07:55:17 --> Helper loaded: form_helper
INFO - 2025-01-13 07:55:17 --> Helper loaded: my_helper
INFO - 2025-01-13 07:55:17 --> Database Driver Class Initialized
INFO - 2025-01-13 07:55:17 --> Upload Class Initialized
INFO - 2025-01-13 07:55:17 --> Email Class Initialized
INFO - 2025-01-13 07:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:55:17 --> Form Validation Class Initialized
INFO - 2025-01-13 07:55:17 --> Controller Class Initialized
INFO - 2025-01-13 13:25:17 --> Model "ApiModel" initialized
INFO - 2025-01-13 13:25:17 --> Helper loaded: notification_helper
INFO - 2025-01-13 13:25:17 --> Model "MainModel" initialized
INFO - 2025-01-13 07:55:31 --> Config Class Initialized
INFO - 2025-01-13 07:55:31 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:55:31 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:55:31 --> Utf8 Class Initialized
INFO - 2025-01-13 07:55:31 --> URI Class Initialized
INFO - 2025-01-13 07:55:31 --> Router Class Initialized
INFO - 2025-01-13 07:55:31 --> Output Class Initialized
INFO - 2025-01-13 07:55:31 --> Security Class Initialized
DEBUG - 2025-01-13 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:55:31 --> Input Class Initialized
INFO - 2025-01-13 07:55:31 --> Language Class Initialized
INFO - 2025-01-13 07:55:31 --> Loader Class Initialized
INFO - 2025-01-13 07:55:31 --> Helper loaded: url_helper
INFO - 2025-01-13 07:55:31 --> Helper loaded: html_helper
INFO - 2025-01-13 07:55:31 --> Helper loaded: file_helper
INFO - 2025-01-13 07:55:31 --> Helper loaded: string_helper
INFO - 2025-01-13 07:55:31 --> Helper loaded: form_helper
INFO - 2025-01-13 07:55:31 --> Helper loaded: my_helper
INFO - 2025-01-13 07:55:31 --> Database Driver Class Initialized
INFO - 2025-01-13 07:55:31 --> Upload Class Initialized
INFO - 2025-01-13 07:55:31 --> Email Class Initialized
INFO - 2025-01-13 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:55:31 --> Form Validation Class Initialized
INFO - 2025-01-13 07:55:31 --> Controller Class Initialized
INFO - 2025-01-13 13:25:31 --> Model "ApiModel" initialized
INFO - 2025-01-13 13:25:31 --> Helper loaded: notification_helper
INFO - 2025-01-13 13:25:31 --> Model "MainModel" initialized
INFO - 2025-01-13 07:55:50 --> Config Class Initialized
INFO - 2025-01-13 07:55:50 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:55:50 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:55:50 --> Utf8 Class Initialized
INFO - 2025-01-13 07:55:50 --> URI Class Initialized
INFO - 2025-01-13 07:55:50 --> Router Class Initialized
INFO - 2025-01-13 07:55:50 --> Output Class Initialized
INFO - 2025-01-13 07:55:50 --> Security Class Initialized
DEBUG - 2025-01-13 07:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:55:50 --> Input Class Initialized
INFO - 2025-01-13 07:55:50 --> Language Class Initialized
INFO - 2025-01-13 07:55:50 --> Loader Class Initialized
INFO - 2025-01-13 07:55:50 --> Helper loaded: url_helper
INFO - 2025-01-13 07:55:50 --> Helper loaded: html_helper
INFO - 2025-01-13 07:55:50 --> Helper loaded: file_helper
INFO - 2025-01-13 07:55:50 --> Helper loaded: string_helper
INFO - 2025-01-13 07:55:50 --> Helper loaded: form_helper
INFO - 2025-01-13 07:55:50 --> Helper loaded: my_helper
INFO - 2025-01-13 07:55:50 --> Database Driver Class Initialized
INFO - 2025-01-13 07:55:50 --> Upload Class Initialized
INFO - 2025-01-13 07:55:50 --> Email Class Initialized
INFO - 2025-01-13 07:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:55:50 --> Form Validation Class Initialized
INFO - 2025-01-13 07:55:50 --> Controller Class Initialized
INFO - 2025-01-13 13:25:50 --> Model "ApiModel" initialized
INFO - 2025-01-13 13:25:50 --> Helper loaded: notification_helper
INFO - 2025-01-13 13:25:50 --> Model "MainModel" initialized
INFO - 2025-01-13 07:55:57 --> Config Class Initialized
INFO - 2025-01-13 07:55:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:55:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:55:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:55:57 --> URI Class Initialized
INFO - 2025-01-13 07:55:57 --> Router Class Initialized
INFO - 2025-01-13 07:55:57 --> Output Class Initialized
INFO - 2025-01-13 07:55:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:55:57 --> Input Class Initialized
INFO - 2025-01-13 07:55:57 --> Language Class Initialized
INFO - 2025-01-13 07:55:57 --> Loader Class Initialized
INFO - 2025-01-13 07:55:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:55:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:55:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:55:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:55:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:55:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:55:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:55:57 --> Upload Class Initialized
INFO - 2025-01-13 07:55:57 --> Email Class Initialized
INFO - 2025-01-13 07:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:55:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:55:57 --> Controller Class Initialized
INFO - 2025-01-13 13:25:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:25:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:25:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:56:57 --> Config Class Initialized
INFO - 2025-01-13 07:56:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:56:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:56:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:56:57 --> URI Class Initialized
INFO - 2025-01-13 07:56:57 --> Router Class Initialized
INFO - 2025-01-13 07:56:57 --> Output Class Initialized
INFO - 2025-01-13 07:56:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:56:57 --> Input Class Initialized
INFO - 2025-01-13 07:56:57 --> Language Class Initialized
INFO - 2025-01-13 07:56:57 --> Loader Class Initialized
INFO - 2025-01-13 07:56:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:56:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:56:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:56:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:56:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:56:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:56:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:56:57 --> Upload Class Initialized
INFO - 2025-01-13 07:56:57 --> Email Class Initialized
INFO - 2025-01-13 07:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:56:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:56:57 --> Controller Class Initialized
INFO - 2025-01-13 13:26:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:26:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:26:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:57:19 --> Config Class Initialized
INFO - 2025-01-13 07:57:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:57:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:57:19 --> Utf8 Class Initialized
INFO - 2025-01-13 07:57:19 --> URI Class Initialized
INFO - 2025-01-13 07:57:19 --> Router Class Initialized
INFO - 2025-01-13 07:57:19 --> Output Class Initialized
INFO - 2025-01-13 07:57:19 --> Security Class Initialized
DEBUG - 2025-01-13 07:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:57:19 --> Input Class Initialized
INFO - 2025-01-13 07:57:19 --> Language Class Initialized
INFO - 2025-01-13 07:57:19 --> Loader Class Initialized
INFO - 2025-01-13 07:57:19 --> Helper loaded: url_helper
INFO - 2025-01-13 07:57:19 --> Helper loaded: html_helper
INFO - 2025-01-13 07:57:19 --> Helper loaded: file_helper
INFO - 2025-01-13 07:57:19 --> Helper loaded: string_helper
INFO - 2025-01-13 07:57:19 --> Helper loaded: form_helper
INFO - 2025-01-13 07:57:19 --> Helper loaded: my_helper
INFO - 2025-01-13 07:57:19 --> Database Driver Class Initialized
INFO - 2025-01-13 07:57:19 --> Upload Class Initialized
INFO - 2025-01-13 07:57:19 --> Email Class Initialized
INFO - 2025-01-13 07:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:57:19 --> Form Validation Class Initialized
INFO - 2025-01-13 07:57:19 --> Controller Class Initialized
INFO - 2025-01-13 13:27:19 --> Model "ApiModel" initialized
INFO - 2025-01-13 13:27:19 --> Helper loaded: notification_helper
INFO - 2025-01-13 13:27:19 --> Model "MainModel" initialized
INFO - 2025-01-13 07:57:57 --> Config Class Initialized
INFO - 2025-01-13 07:57:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:57:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:57:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:57:57 --> URI Class Initialized
INFO - 2025-01-13 07:57:57 --> Router Class Initialized
INFO - 2025-01-13 07:57:57 --> Output Class Initialized
INFO - 2025-01-13 07:57:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:57:57 --> Input Class Initialized
INFO - 2025-01-13 07:57:57 --> Language Class Initialized
INFO - 2025-01-13 07:57:57 --> Loader Class Initialized
INFO - 2025-01-13 07:57:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:57:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:57:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:57:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:57:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:57:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:57:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:57:57 --> Upload Class Initialized
INFO - 2025-01-13 07:57:57 --> Email Class Initialized
INFO - 2025-01-13 07:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:57:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:57:57 --> Controller Class Initialized
INFO - 2025-01-13 13:27:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:27:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:27:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:58:57 --> Config Class Initialized
INFO - 2025-01-13 07:58:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:58:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:58:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:58:57 --> URI Class Initialized
INFO - 2025-01-13 07:58:57 --> Router Class Initialized
INFO - 2025-01-13 07:58:57 --> Output Class Initialized
INFO - 2025-01-13 07:58:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:58:57 --> Input Class Initialized
INFO - 2025-01-13 07:58:57 --> Language Class Initialized
INFO - 2025-01-13 07:58:57 --> Loader Class Initialized
INFO - 2025-01-13 07:58:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:58:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:58:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:58:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:58:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:58:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:58:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:58:57 --> Upload Class Initialized
INFO - 2025-01-13 07:58:57 --> Email Class Initialized
INFO - 2025-01-13 07:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:58:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:58:57 --> Controller Class Initialized
INFO - 2025-01-13 13:28:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:28:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:28:57 --> Pagination Class Initialized
INFO - 2025-01-13 07:59:57 --> Config Class Initialized
INFO - 2025-01-13 07:59:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 07:59:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 07:59:57 --> Utf8 Class Initialized
INFO - 2025-01-13 07:59:57 --> URI Class Initialized
INFO - 2025-01-13 07:59:57 --> Router Class Initialized
INFO - 2025-01-13 07:59:57 --> Output Class Initialized
INFO - 2025-01-13 07:59:57 --> Security Class Initialized
DEBUG - 2025-01-13 07:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 07:59:57 --> Input Class Initialized
INFO - 2025-01-13 07:59:57 --> Language Class Initialized
INFO - 2025-01-13 07:59:57 --> Loader Class Initialized
INFO - 2025-01-13 07:59:57 --> Helper loaded: url_helper
INFO - 2025-01-13 07:59:57 --> Helper loaded: html_helper
INFO - 2025-01-13 07:59:57 --> Helper loaded: file_helper
INFO - 2025-01-13 07:59:57 --> Helper loaded: string_helper
INFO - 2025-01-13 07:59:57 --> Helper loaded: form_helper
INFO - 2025-01-13 07:59:57 --> Helper loaded: my_helper
INFO - 2025-01-13 07:59:57 --> Database Driver Class Initialized
INFO - 2025-01-13 07:59:57 --> Upload Class Initialized
INFO - 2025-01-13 07:59:57 --> Email Class Initialized
INFO - 2025-01-13 07:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 07:59:57 --> Form Validation Class Initialized
INFO - 2025-01-13 07:59:57 --> Controller Class Initialized
INFO - 2025-01-13 13:29:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:29:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:29:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:00:57 --> Config Class Initialized
INFO - 2025-01-13 08:00:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:00:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:00:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:00:57 --> URI Class Initialized
INFO - 2025-01-13 08:00:57 --> Router Class Initialized
INFO - 2025-01-13 08:00:57 --> Output Class Initialized
INFO - 2025-01-13 08:00:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:00:57 --> Input Class Initialized
INFO - 2025-01-13 08:00:57 --> Language Class Initialized
INFO - 2025-01-13 08:00:57 --> Loader Class Initialized
INFO - 2025-01-13 08:00:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:00:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:00:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:00:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:00:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:00:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:00:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:00:57 --> Upload Class Initialized
INFO - 2025-01-13 08:00:57 --> Email Class Initialized
INFO - 2025-01-13 08:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:00:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:00:57 --> Controller Class Initialized
INFO - 2025-01-13 13:30:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:30:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:30:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:01:57 --> Config Class Initialized
INFO - 2025-01-13 08:01:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:01:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:01:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:01:57 --> URI Class Initialized
INFO - 2025-01-13 08:01:57 --> Router Class Initialized
INFO - 2025-01-13 08:01:57 --> Output Class Initialized
INFO - 2025-01-13 08:01:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:01:57 --> Input Class Initialized
INFO - 2025-01-13 08:01:57 --> Language Class Initialized
INFO - 2025-01-13 08:01:57 --> Loader Class Initialized
INFO - 2025-01-13 08:01:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:01:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:01:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:01:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:01:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:01:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:01:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:01:57 --> Upload Class Initialized
INFO - 2025-01-13 08:01:57 --> Email Class Initialized
INFO - 2025-01-13 08:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:01:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:01:57 --> Controller Class Initialized
INFO - 2025-01-13 13:31:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:31:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:31:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:02:57 --> Config Class Initialized
INFO - 2025-01-13 08:02:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:02:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:02:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:02:57 --> URI Class Initialized
INFO - 2025-01-13 08:02:57 --> Router Class Initialized
INFO - 2025-01-13 08:02:57 --> Output Class Initialized
INFO - 2025-01-13 08:02:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:02:57 --> Input Class Initialized
INFO - 2025-01-13 08:02:57 --> Language Class Initialized
INFO - 2025-01-13 08:02:57 --> Loader Class Initialized
INFO - 2025-01-13 08:02:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:02:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:02:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:02:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:02:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:02:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:02:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:02:57 --> Upload Class Initialized
INFO - 2025-01-13 08:02:57 --> Email Class Initialized
INFO - 2025-01-13 08:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:02:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:02:57 --> Controller Class Initialized
INFO - 2025-01-13 13:32:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:32:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:32:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:03:57 --> Config Class Initialized
INFO - 2025-01-13 08:03:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:03:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:03:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:03:57 --> URI Class Initialized
INFO - 2025-01-13 08:03:57 --> Router Class Initialized
INFO - 2025-01-13 08:03:57 --> Output Class Initialized
INFO - 2025-01-13 08:03:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:03:57 --> Input Class Initialized
INFO - 2025-01-13 08:03:57 --> Language Class Initialized
INFO - 2025-01-13 08:03:57 --> Loader Class Initialized
INFO - 2025-01-13 08:03:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:03:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:03:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:03:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:03:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:03:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:03:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:03:57 --> Upload Class Initialized
INFO - 2025-01-13 08:03:57 --> Email Class Initialized
INFO - 2025-01-13 08:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:03:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:03:57 --> Controller Class Initialized
INFO - 2025-01-13 13:33:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:33:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:33:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:04:57 --> Config Class Initialized
INFO - 2025-01-13 08:04:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:04:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:04:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:04:57 --> URI Class Initialized
INFO - 2025-01-13 08:04:57 --> Router Class Initialized
INFO - 2025-01-13 08:04:57 --> Output Class Initialized
INFO - 2025-01-13 08:04:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:04:57 --> Input Class Initialized
INFO - 2025-01-13 08:04:57 --> Language Class Initialized
INFO - 2025-01-13 08:04:57 --> Loader Class Initialized
INFO - 2025-01-13 08:04:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:04:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:04:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:04:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:04:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:04:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:04:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:04:57 --> Upload Class Initialized
INFO - 2025-01-13 08:04:57 --> Email Class Initialized
INFO - 2025-01-13 08:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:04:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:04:57 --> Controller Class Initialized
INFO - 2025-01-13 13:34:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:34:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:34:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:05:57 --> Config Class Initialized
INFO - 2025-01-13 08:05:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:05:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:05:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:05:57 --> URI Class Initialized
INFO - 2025-01-13 08:05:57 --> Router Class Initialized
INFO - 2025-01-13 08:05:57 --> Output Class Initialized
INFO - 2025-01-13 08:05:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:05:57 --> Input Class Initialized
INFO - 2025-01-13 08:05:57 --> Language Class Initialized
INFO - 2025-01-13 08:05:57 --> Loader Class Initialized
INFO - 2025-01-13 08:05:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:05:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:05:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:05:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:05:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:05:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:05:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:05:57 --> Upload Class Initialized
INFO - 2025-01-13 08:05:57 --> Email Class Initialized
INFO - 2025-01-13 08:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:05:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:05:57 --> Controller Class Initialized
INFO - 2025-01-13 13:35:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:35:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:35:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:06:57 --> Config Class Initialized
INFO - 2025-01-13 08:06:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:06:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:06:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:06:57 --> URI Class Initialized
INFO - 2025-01-13 08:06:57 --> Router Class Initialized
INFO - 2025-01-13 08:06:57 --> Output Class Initialized
INFO - 2025-01-13 08:06:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:06:57 --> Input Class Initialized
INFO - 2025-01-13 08:06:57 --> Language Class Initialized
INFO - 2025-01-13 08:06:57 --> Loader Class Initialized
INFO - 2025-01-13 08:06:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:06:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:06:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:06:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:06:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:06:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:06:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:06:57 --> Upload Class Initialized
INFO - 2025-01-13 08:06:57 --> Email Class Initialized
INFO - 2025-01-13 08:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:06:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:06:57 --> Controller Class Initialized
INFO - 2025-01-13 13:36:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:36:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:36:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:07:57 --> Config Class Initialized
INFO - 2025-01-13 08:07:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:07:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:07:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:07:57 --> URI Class Initialized
INFO - 2025-01-13 08:07:57 --> Router Class Initialized
INFO - 2025-01-13 08:07:57 --> Output Class Initialized
INFO - 2025-01-13 08:07:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:07:57 --> Input Class Initialized
INFO - 2025-01-13 08:07:57 --> Language Class Initialized
INFO - 2025-01-13 08:07:57 --> Loader Class Initialized
INFO - 2025-01-13 08:07:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:07:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:07:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:07:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:07:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:07:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:07:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:07:57 --> Upload Class Initialized
INFO - 2025-01-13 08:07:57 --> Email Class Initialized
INFO - 2025-01-13 08:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:07:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:07:57 --> Controller Class Initialized
INFO - 2025-01-13 13:37:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:37:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:37:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:08:57 --> Config Class Initialized
INFO - 2025-01-13 08:08:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:08:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:08:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:08:57 --> URI Class Initialized
INFO - 2025-01-13 08:08:57 --> Router Class Initialized
INFO - 2025-01-13 08:08:57 --> Output Class Initialized
INFO - 2025-01-13 08:08:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:08:57 --> Input Class Initialized
INFO - 2025-01-13 08:08:57 --> Language Class Initialized
INFO - 2025-01-13 08:08:57 --> Loader Class Initialized
INFO - 2025-01-13 08:08:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:08:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:08:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:08:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:08:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:08:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:08:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:08:57 --> Upload Class Initialized
INFO - 2025-01-13 08:08:57 --> Email Class Initialized
INFO - 2025-01-13 08:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:08:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:08:57 --> Controller Class Initialized
INFO - 2025-01-13 13:38:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:38:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:38:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:09:57 --> Config Class Initialized
INFO - 2025-01-13 08:09:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:09:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:09:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:09:57 --> URI Class Initialized
INFO - 2025-01-13 08:09:57 --> Router Class Initialized
INFO - 2025-01-13 08:09:57 --> Output Class Initialized
INFO - 2025-01-13 08:09:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:09:57 --> Input Class Initialized
INFO - 2025-01-13 08:09:57 --> Language Class Initialized
INFO - 2025-01-13 08:09:57 --> Loader Class Initialized
INFO - 2025-01-13 08:09:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:09:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:09:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:09:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:09:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:09:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:09:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:09:57 --> Upload Class Initialized
INFO - 2025-01-13 08:09:57 --> Email Class Initialized
INFO - 2025-01-13 08:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:09:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:09:57 --> Controller Class Initialized
INFO - 2025-01-13 13:39:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:39:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:39:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:39:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:10:57 --> Config Class Initialized
INFO - 2025-01-13 08:10:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:10:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:10:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:10:57 --> URI Class Initialized
INFO - 2025-01-13 08:10:57 --> Router Class Initialized
INFO - 2025-01-13 08:10:57 --> Output Class Initialized
INFO - 2025-01-13 08:10:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:10:57 --> Input Class Initialized
INFO - 2025-01-13 08:10:57 --> Language Class Initialized
INFO - 2025-01-13 08:10:57 --> Loader Class Initialized
INFO - 2025-01-13 08:10:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:10:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:10:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:10:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:10:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:10:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:10:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:10:57 --> Upload Class Initialized
INFO - 2025-01-13 08:10:57 --> Email Class Initialized
INFO - 2025-01-13 08:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:10:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:10:57 --> Controller Class Initialized
INFO - 2025-01-13 13:40:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:40:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:40:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:11:57 --> Config Class Initialized
INFO - 2025-01-13 08:11:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:11:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:11:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:11:57 --> URI Class Initialized
INFO - 2025-01-13 08:11:57 --> Router Class Initialized
INFO - 2025-01-13 08:11:57 --> Output Class Initialized
INFO - 2025-01-13 08:11:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:11:57 --> Input Class Initialized
INFO - 2025-01-13 08:11:57 --> Language Class Initialized
INFO - 2025-01-13 08:11:57 --> Loader Class Initialized
INFO - 2025-01-13 08:11:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:11:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:11:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:11:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:11:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:11:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:11:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:11:57 --> Upload Class Initialized
INFO - 2025-01-13 08:11:57 --> Email Class Initialized
INFO - 2025-01-13 08:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:11:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:11:57 --> Controller Class Initialized
INFO - 2025-01-13 13:41:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:41:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:41:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:12:57 --> Config Class Initialized
INFO - 2025-01-13 08:12:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:12:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:12:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:12:57 --> URI Class Initialized
INFO - 2025-01-13 08:12:57 --> Router Class Initialized
INFO - 2025-01-13 08:12:57 --> Output Class Initialized
INFO - 2025-01-13 08:12:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:12:57 --> Input Class Initialized
INFO - 2025-01-13 08:12:57 --> Language Class Initialized
INFO - 2025-01-13 08:12:57 --> Loader Class Initialized
INFO - 2025-01-13 08:12:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:12:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:12:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:12:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:12:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:12:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:12:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:12:57 --> Upload Class Initialized
INFO - 2025-01-13 08:12:57 --> Email Class Initialized
INFO - 2025-01-13 08:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:12:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:12:57 --> Controller Class Initialized
INFO - 2025-01-13 13:42:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 13:42:57 --> Model "MainModel" initialized
INFO - 2025-01-13 13:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 13:42:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:46:17 --> Config Class Initialized
INFO - 2025-01-13 08:46:17 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:46:17 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:46:17 --> Utf8 Class Initialized
INFO - 2025-01-13 08:46:17 --> URI Class Initialized
INFO - 2025-01-13 08:46:17 --> Router Class Initialized
INFO - 2025-01-13 08:46:17 --> Output Class Initialized
INFO - 2025-01-13 08:46:17 --> Security Class Initialized
DEBUG - 2025-01-13 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:46:17 --> Input Class Initialized
INFO - 2025-01-13 08:46:17 --> Language Class Initialized
INFO - 2025-01-13 08:46:17 --> Loader Class Initialized
INFO - 2025-01-13 08:46:17 --> Helper loaded: url_helper
INFO - 2025-01-13 08:46:17 --> Helper loaded: html_helper
INFO - 2025-01-13 08:46:17 --> Helper loaded: file_helper
INFO - 2025-01-13 08:46:17 --> Helper loaded: string_helper
INFO - 2025-01-13 08:46:17 --> Helper loaded: form_helper
INFO - 2025-01-13 08:46:17 --> Helper loaded: my_helper
INFO - 2025-01-13 08:46:17 --> Database Driver Class Initialized
INFO - 2025-01-13 08:46:17 --> Upload Class Initialized
INFO - 2025-01-13 08:46:17 --> Email Class Initialized
INFO - 2025-01-13 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:46:17 --> Form Validation Class Initialized
INFO - 2025-01-13 08:46:17 --> Controller Class Initialized
INFO - 2025-01-13 14:16:17 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:16:17 --> Model "MainModel" initialized
INFO - 2025-01-13 14:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:16:17 --> Pagination Class Initialized
INFO - 2025-01-13 08:46:57 --> Config Class Initialized
INFO - 2025-01-13 08:46:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:46:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:46:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:46:57 --> URI Class Initialized
INFO - 2025-01-13 08:46:57 --> Router Class Initialized
INFO - 2025-01-13 08:46:57 --> Output Class Initialized
INFO - 2025-01-13 08:46:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:46:57 --> Input Class Initialized
INFO - 2025-01-13 08:46:57 --> Language Class Initialized
INFO - 2025-01-13 08:46:57 --> Loader Class Initialized
INFO - 2025-01-13 08:46:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:46:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:46:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:46:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:46:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:46:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:46:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:46:57 --> Upload Class Initialized
INFO - 2025-01-13 08:46:57 --> Email Class Initialized
INFO - 2025-01-13 08:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:46:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:46:57 --> Controller Class Initialized
INFO - 2025-01-13 14:16:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:16:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:16:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:47:57 --> Config Class Initialized
INFO - 2025-01-13 08:47:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:47:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:47:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:47:57 --> URI Class Initialized
INFO - 2025-01-13 08:47:57 --> Router Class Initialized
INFO - 2025-01-13 08:47:57 --> Output Class Initialized
INFO - 2025-01-13 08:47:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:47:57 --> Input Class Initialized
INFO - 2025-01-13 08:47:57 --> Language Class Initialized
INFO - 2025-01-13 08:47:57 --> Loader Class Initialized
INFO - 2025-01-13 08:47:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:47:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:47:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:47:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:47:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:47:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:47:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:47:57 --> Upload Class Initialized
INFO - 2025-01-13 08:47:57 --> Email Class Initialized
INFO - 2025-01-13 08:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:47:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:47:57 --> Controller Class Initialized
INFO - 2025-01-13 14:17:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:17:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:17:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:48:57 --> Config Class Initialized
INFO - 2025-01-13 08:48:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:48:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:48:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:48:57 --> URI Class Initialized
INFO - 2025-01-13 08:48:57 --> Router Class Initialized
INFO - 2025-01-13 08:48:57 --> Output Class Initialized
INFO - 2025-01-13 08:48:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:48:57 --> Input Class Initialized
INFO - 2025-01-13 08:48:57 --> Language Class Initialized
INFO - 2025-01-13 08:48:57 --> Loader Class Initialized
INFO - 2025-01-13 08:48:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:48:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:48:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:48:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:48:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:48:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:48:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:48:57 --> Upload Class Initialized
INFO - 2025-01-13 08:48:57 --> Email Class Initialized
INFO - 2025-01-13 08:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:48:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:48:57 --> Controller Class Initialized
INFO - 2025-01-13 14:18:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:18:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:18:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:49:57 --> Config Class Initialized
INFO - 2025-01-13 08:49:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:49:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:49:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:49:57 --> URI Class Initialized
INFO - 2025-01-13 08:49:57 --> Router Class Initialized
INFO - 2025-01-13 08:49:57 --> Output Class Initialized
INFO - 2025-01-13 08:49:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:49:57 --> Input Class Initialized
INFO - 2025-01-13 08:49:57 --> Language Class Initialized
INFO - 2025-01-13 08:49:57 --> Loader Class Initialized
INFO - 2025-01-13 08:49:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:49:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:49:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:49:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:49:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:49:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:49:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:49:57 --> Upload Class Initialized
INFO - 2025-01-13 08:49:57 --> Email Class Initialized
INFO - 2025-01-13 08:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:49:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:49:57 --> Controller Class Initialized
INFO - 2025-01-13 14:19:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:19:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:19:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:50:57 --> Config Class Initialized
INFO - 2025-01-13 08:50:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:50:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:50:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:50:57 --> URI Class Initialized
INFO - 2025-01-13 08:50:57 --> Router Class Initialized
INFO - 2025-01-13 08:50:57 --> Output Class Initialized
INFO - 2025-01-13 08:50:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:50:57 --> Input Class Initialized
INFO - 2025-01-13 08:50:57 --> Language Class Initialized
INFO - 2025-01-13 08:50:57 --> Loader Class Initialized
INFO - 2025-01-13 08:50:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:50:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:50:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:50:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:50:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:50:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:50:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:50:57 --> Upload Class Initialized
INFO - 2025-01-13 08:50:57 --> Email Class Initialized
INFO - 2025-01-13 08:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:50:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:50:57 --> Controller Class Initialized
INFO - 2025-01-13 14:20:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:20:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:20:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:51:57 --> Config Class Initialized
INFO - 2025-01-13 08:51:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:51:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:51:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:51:57 --> URI Class Initialized
INFO - 2025-01-13 08:51:57 --> Router Class Initialized
INFO - 2025-01-13 08:51:57 --> Output Class Initialized
INFO - 2025-01-13 08:51:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:51:57 --> Input Class Initialized
INFO - 2025-01-13 08:51:57 --> Language Class Initialized
INFO - 2025-01-13 08:51:57 --> Loader Class Initialized
INFO - 2025-01-13 08:51:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:51:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:51:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:51:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:51:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:51:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:51:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:51:57 --> Upload Class Initialized
INFO - 2025-01-13 08:51:57 --> Email Class Initialized
INFO - 2025-01-13 08:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:51:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:51:57 --> Controller Class Initialized
INFO - 2025-01-13 14:21:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:21:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:21:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:52:57 --> Config Class Initialized
INFO - 2025-01-13 08:52:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:52:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:52:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:52:57 --> URI Class Initialized
INFO - 2025-01-13 08:52:57 --> Router Class Initialized
INFO - 2025-01-13 08:52:57 --> Output Class Initialized
INFO - 2025-01-13 08:52:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:52:57 --> Input Class Initialized
INFO - 2025-01-13 08:52:57 --> Language Class Initialized
INFO - 2025-01-13 08:52:57 --> Loader Class Initialized
INFO - 2025-01-13 08:52:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:52:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:52:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:52:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:52:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:52:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:52:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:52:57 --> Upload Class Initialized
INFO - 2025-01-13 08:52:57 --> Email Class Initialized
INFO - 2025-01-13 08:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:52:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:52:57 --> Controller Class Initialized
INFO - 2025-01-13 14:22:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:22:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:22:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:53:57 --> Config Class Initialized
INFO - 2025-01-13 08:53:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:53:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:53:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:53:57 --> URI Class Initialized
INFO - 2025-01-13 08:53:57 --> Router Class Initialized
INFO - 2025-01-13 08:53:57 --> Output Class Initialized
INFO - 2025-01-13 08:53:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:53:57 --> Input Class Initialized
INFO - 2025-01-13 08:53:57 --> Language Class Initialized
INFO - 2025-01-13 08:53:57 --> Loader Class Initialized
INFO - 2025-01-13 08:53:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:53:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:53:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:53:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:53:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:53:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:53:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:53:57 --> Upload Class Initialized
INFO - 2025-01-13 08:53:57 --> Email Class Initialized
INFO - 2025-01-13 08:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:53:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:53:57 --> Controller Class Initialized
INFO - 2025-01-13 14:23:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:23:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:23:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:54:57 --> Config Class Initialized
INFO - 2025-01-13 08:54:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:54:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:54:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:54:57 --> URI Class Initialized
INFO - 2025-01-13 08:54:57 --> Router Class Initialized
INFO - 2025-01-13 08:54:57 --> Output Class Initialized
INFO - 2025-01-13 08:54:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:54:57 --> Input Class Initialized
INFO - 2025-01-13 08:54:57 --> Language Class Initialized
INFO - 2025-01-13 08:54:57 --> Loader Class Initialized
INFO - 2025-01-13 08:54:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:54:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:54:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:54:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:54:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:54:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:54:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:54:57 --> Upload Class Initialized
INFO - 2025-01-13 08:54:57 --> Email Class Initialized
INFO - 2025-01-13 08:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:54:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:54:57 --> Controller Class Initialized
INFO - 2025-01-13 14:24:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:24:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:24:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:55:57 --> Config Class Initialized
INFO - 2025-01-13 08:55:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:55:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:55:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:55:57 --> URI Class Initialized
INFO - 2025-01-13 08:55:57 --> Router Class Initialized
INFO - 2025-01-13 08:55:57 --> Output Class Initialized
INFO - 2025-01-13 08:55:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:55:57 --> Input Class Initialized
INFO - 2025-01-13 08:55:57 --> Language Class Initialized
INFO - 2025-01-13 08:55:57 --> Loader Class Initialized
INFO - 2025-01-13 08:55:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:55:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:55:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:55:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:55:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:55:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:55:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:55:57 --> Upload Class Initialized
INFO - 2025-01-13 08:55:57 --> Email Class Initialized
INFO - 2025-01-13 08:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:55:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:55:57 --> Controller Class Initialized
INFO - 2025-01-13 14:25:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:25:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:25:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:56:57 --> Config Class Initialized
INFO - 2025-01-13 08:56:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:56:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:56:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:56:57 --> URI Class Initialized
INFO - 2025-01-13 08:56:57 --> Router Class Initialized
INFO - 2025-01-13 08:56:57 --> Output Class Initialized
INFO - 2025-01-13 08:56:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:56:57 --> Input Class Initialized
INFO - 2025-01-13 08:56:57 --> Language Class Initialized
INFO - 2025-01-13 08:56:57 --> Loader Class Initialized
INFO - 2025-01-13 08:56:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:56:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:56:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:56:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:56:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:56:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:56:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:56:57 --> Upload Class Initialized
INFO - 2025-01-13 08:56:57 --> Email Class Initialized
INFO - 2025-01-13 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:56:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:56:57 --> Controller Class Initialized
INFO - 2025-01-13 14:26:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:26:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:26:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:57:57 --> Config Class Initialized
INFO - 2025-01-13 08:57:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:57:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:57:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:57:57 --> URI Class Initialized
INFO - 2025-01-13 08:57:57 --> Router Class Initialized
INFO - 2025-01-13 08:57:57 --> Output Class Initialized
INFO - 2025-01-13 08:57:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:57:57 --> Input Class Initialized
INFO - 2025-01-13 08:57:57 --> Language Class Initialized
INFO - 2025-01-13 08:57:57 --> Loader Class Initialized
INFO - 2025-01-13 08:57:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:57:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:57:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:57:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:57:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:57:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:57:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:57:57 --> Upload Class Initialized
INFO - 2025-01-13 08:57:57 --> Email Class Initialized
INFO - 2025-01-13 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:57:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:57:57 --> Controller Class Initialized
INFO - 2025-01-13 14:27:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:27:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:27:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:58:57 --> Config Class Initialized
INFO - 2025-01-13 08:58:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:58:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:58:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:58:57 --> URI Class Initialized
INFO - 2025-01-13 08:58:57 --> Router Class Initialized
INFO - 2025-01-13 08:58:57 --> Output Class Initialized
INFO - 2025-01-13 08:58:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:58:57 --> Input Class Initialized
INFO - 2025-01-13 08:58:57 --> Language Class Initialized
INFO - 2025-01-13 08:58:57 --> Loader Class Initialized
INFO - 2025-01-13 08:58:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:58:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:58:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:58:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:58:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:58:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:58:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:58:57 --> Upload Class Initialized
INFO - 2025-01-13 08:58:57 --> Email Class Initialized
INFO - 2025-01-13 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:58:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:58:57 --> Controller Class Initialized
INFO - 2025-01-13 14:28:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:28:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:28:57 --> Pagination Class Initialized
INFO - 2025-01-13 08:59:57 --> Config Class Initialized
INFO - 2025-01-13 08:59:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 08:59:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 08:59:57 --> Utf8 Class Initialized
INFO - 2025-01-13 08:59:57 --> URI Class Initialized
INFO - 2025-01-13 08:59:57 --> Router Class Initialized
INFO - 2025-01-13 08:59:57 --> Output Class Initialized
INFO - 2025-01-13 08:59:57 --> Security Class Initialized
DEBUG - 2025-01-13 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 08:59:57 --> Input Class Initialized
INFO - 2025-01-13 08:59:57 --> Language Class Initialized
INFO - 2025-01-13 08:59:57 --> Loader Class Initialized
INFO - 2025-01-13 08:59:57 --> Helper loaded: url_helper
INFO - 2025-01-13 08:59:57 --> Helper loaded: html_helper
INFO - 2025-01-13 08:59:57 --> Helper loaded: file_helper
INFO - 2025-01-13 08:59:57 --> Helper loaded: string_helper
INFO - 2025-01-13 08:59:57 --> Helper loaded: form_helper
INFO - 2025-01-13 08:59:57 --> Helper loaded: my_helper
INFO - 2025-01-13 08:59:57 --> Database Driver Class Initialized
INFO - 2025-01-13 08:59:57 --> Upload Class Initialized
INFO - 2025-01-13 08:59:57 --> Email Class Initialized
INFO - 2025-01-13 08:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 08:59:57 --> Form Validation Class Initialized
INFO - 2025-01-13 08:59:57 --> Controller Class Initialized
INFO - 2025-01-13 14:29:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:29:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:29:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:00:57 --> Config Class Initialized
INFO - 2025-01-13 09:00:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:00:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:00:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:00:57 --> URI Class Initialized
INFO - 2025-01-13 09:00:57 --> Router Class Initialized
INFO - 2025-01-13 09:00:57 --> Output Class Initialized
INFO - 2025-01-13 09:00:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:00:57 --> Input Class Initialized
INFO - 2025-01-13 09:00:57 --> Language Class Initialized
INFO - 2025-01-13 09:00:57 --> Loader Class Initialized
INFO - 2025-01-13 09:00:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:00:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:00:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:00:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:00:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:00:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:00:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:00:57 --> Upload Class Initialized
INFO - 2025-01-13 09:00:57 --> Email Class Initialized
INFO - 2025-01-13 09:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:00:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:00:57 --> Controller Class Initialized
INFO - 2025-01-13 14:30:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:30:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:30:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:01:49 --> Config Class Initialized
INFO - 2025-01-13 09:01:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:01:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:01:49 --> Utf8 Class Initialized
INFO - 2025-01-13 09:01:49 --> URI Class Initialized
INFO - 2025-01-13 09:01:49 --> Router Class Initialized
INFO - 2025-01-13 09:01:49 --> Output Class Initialized
INFO - 2025-01-13 09:01:49 --> Security Class Initialized
DEBUG - 2025-01-13 09:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:01:49 --> Input Class Initialized
INFO - 2025-01-13 09:01:49 --> Language Class Initialized
INFO - 2025-01-13 09:01:49 --> Loader Class Initialized
INFO - 2025-01-13 09:01:49 --> Helper loaded: url_helper
INFO - 2025-01-13 09:01:49 --> Helper loaded: html_helper
INFO - 2025-01-13 09:01:49 --> Helper loaded: file_helper
INFO - 2025-01-13 09:01:49 --> Helper loaded: string_helper
INFO - 2025-01-13 09:01:49 --> Helper loaded: form_helper
INFO - 2025-01-13 09:01:49 --> Helper loaded: my_helper
INFO - 2025-01-13 09:01:49 --> Database Driver Class Initialized
INFO - 2025-01-13 09:01:49 --> Upload Class Initialized
INFO - 2025-01-13 09:01:49 --> Email Class Initialized
INFO - 2025-01-13 09:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:01:49 --> Form Validation Class Initialized
INFO - 2025-01-13 09:01:49 --> Controller Class Initialized
INFO - 2025-01-13 14:31:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:31:49 --> Model "MainModel" initialized
INFO - 2025-01-13 14:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:31:49 --> Pagination Class Initialized
INFO - 2025-01-13 09:01:54 --> Config Class Initialized
INFO - 2025-01-13 09:01:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:01:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:01:54 --> Utf8 Class Initialized
INFO - 2025-01-13 09:01:54 --> URI Class Initialized
INFO - 2025-01-13 09:01:54 --> Router Class Initialized
INFO - 2025-01-13 09:01:54 --> Output Class Initialized
INFO - 2025-01-13 09:01:54 --> Security Class Initialized
DEBUG - 2025-01-13 09:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:01:54 --> Input Class Initialized
INFO - 2025-01-13 09:01:54 --> Language Class Initialized
INFO - 2025-01-13 09:01:54 --> Loader Class Initialized
INFO - 2025-01-13 09:01:54 --> Helper loaded: url_helper
INFO - 2025-01-13 09:01:54 --> Helper loaded: html_helper
INFO - 2025-01-13 09:01:54 --> Helper loaded: file_helper
INFO - 2025-01-13 09:01:54 --> Helper loaded: string_helper
INFO - 2025-01-13 09:01:54 --> Helper loaded: form_helper
INFO - 2025-01-13 09:01:54 --> Helper loaded: my_helper
INFO - 2025-01-13 09:01:54 --> Database Driver Class Initialized
INFO - 2025-01-13 09:01:54 --> Upload Class Initialized
INFO - 2025-01-13 09:01:54 --> Email Class Initialized
INFO - 2025-01-13 09:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:01:54 --> Form Validation Class Initialized
INFO - 2025-01-13 09:01:54 --> Controller Class Initialized
INFO - 2025-01-13 14:31:54 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:31:54 --> Model "MainModel" initialized
INFO - 2025-01-13 14:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:31:54 --> Pagination Class Initialized
INFO - 2025-01-13 09:01:59 --> Config Class Initialized
INFO - 2025-01-13 09:01:59 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:01:59 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:01:59 --> Utf8 Class Initialized
INFO - 2025-01-13 09:01:59 --> URI Class Initialized
INFO - 2025-01-13 09:01:59 --> Router Class Initialized
INFO - 2025-01-13 09:01:59 --> Output Class Initialized
INFO - 2025-01-13 09:01:59 --> Security Class Initialized
DEBUG - 2025-01-13 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:01:59 --> Input Class Initialized
INFO - 2025-01-13 09:01:59 --> Language Class Initialized
INFO - 2025-01-13 09:01:59 --> Loader Class Initialized
INFO - 2025-01-13 09:01:59 --> Helper loaded: url_helper
INFO - 2025-01-13 09:01:59 --> Helper loaded: html_helper
INFO - 2025-01-13 09:01:59 --> Helper loaded: file_helper
INFO - 2025-01-13 09:01:59 --> Helper loaded: string_helper
INFO - 2025-01-13 09:01:59 --> Helper loaded: form_helper
INFO - 2025-01-13 09:01:59 --> Helper loaded: my_helper
INFO - 2025-01-13 09:01:59 --> Database Driver Class Initialized
INFO - 2025-01-13 09:01:59 --> Upload Class Initialized
INFO - 2025-01-13 09:01:59 --> Email Class Initialized
INFO - 2025-01-13 09:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:01:59 --> Form Validation Class Initialized
INFO - 2025-01-13 09:01:59 --> Controller Class Initialized
INFO - 2025-01-13 14:31:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:31:59 --> Model "MainModel" initialized
INFO - 2025-01-13 14:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:31:59 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:04 --> Config Class Initialized
INFO - 2025-01-13 09:02:04 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:04 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:04 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:04 --> URI Class Initialized
INFO - 2025-01-13 09:02:04 --> Router Class Initialized
INFO - 2025-01-13 09:02:04 --> Output Class Initialized
INFO - 2025-01-13 09:02:04 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:04 --> Input Class Initialized
INFO - 2025-01-13 09:02:04 --> Language Class Initialized
INFO - 2025-01-13 09:02:04 --> Loader Class Initialized
INFO - 2025-01-13 09:02:04 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:04 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:04 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:04 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:04 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:04 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:04 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:04 --> Upload Class Initialized
INFO - 2025-01-13 09:02:04 --> Email Class Initialized
INFO - 2025-01-13 09:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:04 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:04 --> Controller Class Initialized
INFO - 2025-01-13 14:32:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:04 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:04 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:09 --> Config Class Initialized
INFO - 2025-01-13 09:02:09 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:09 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:09 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:09 --> URI Class Initialized
INFO - 2025-01-13 09:02:09 --> Router Class Initialized
INFO - 2025-01-13 09:02:09 --> Output Class Initialized
INFO - 2025-01-13 09:02:09 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:09 --> Input Class Initialized
INFO - 2025-01-13 09:02:09 --> Language Class Initialized
INFO - 2025-01-13 09:02:09 --> Loader Class Initialized
INFO - 2025-01-13 09:02:09 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:09 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:09 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:09 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:09 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:09 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:09 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:09 --> Upload Class Initialized
INFO - 2025-01-13 09:02:09 --> Email Class Initialized
INFO - 2025-01-13 09:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:09 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:09 --> Controller Class Initialized
INFO - 2025-01-13 14:32:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:09 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:09 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:14 --> Config Class Initialized
INFO - 2025-01-13 09:02:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:14 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:14 --> URI Class Initialized
INFO - 2025-01-13 09:02:14 --> Router Class Initialized
INFO - 2025-01-13 09:02:14 --> Output Class Initialized
INFO - 2025-01-13 09:02:14 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:14 --> Input Class Initialized
INFO - 2025-01-13 09:02:14 --> Language Class Initialized
INFO - 2025-01-13 09:02:14 --> Loader Class Initialized
INFO - 2025-01-13 09:02:14 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:14 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:14 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:14 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:14 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:14 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:14 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:14 --> Upload Class Initialized
INFO - 2025-01-13 09:02:14 --> Email Class Initialized
INFO - 2025-01-13 09:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:14 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:14 --> Controller Class Initialized
INFO - 2025-01-13 14:32:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:14 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:14 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:19 --> Config Class Initialized
INFO - 2025-01-13 09:02:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:19 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:19 --> URI Class Initialized
INFO - 2025-01-13 09:02:19 --> Router Class Initialized
INFO - 2025-01-13 09:02:19 --> Output Class Initialized
INFO - 2025-01-13 09:02:19 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:19 --> Input Class Initialized
INFO - 2025-01-13 09:02:19 --> Language Class Initialized
INFO - 2025-01-13 09:02:19 --> Loader Class Initialized
INFO - 2025-01-13 09:02:19 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:19 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:19 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:19 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:19 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:19 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:19 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:19 --> Upload Class Initialized
INFO - 2025-01-13 09:02:19 --> Email Class Initialized
INFO - 2025-01-13 09:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:19 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:19 --> Controller Class Initialized
INFO - 2025-01-13 14:32:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:19 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:19 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:24 --> Config Class Initialized
INFO - 2025-01-13 09:02:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:24 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:24 --> URI Class Initialized
INFO - 2025-01-13 09:02:24 --> Router Class Initialized
INFO - 2025-01-13 09:02:24 --> Output Class Initialized
INFO - 2025-01-13 09:02:24 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:24 --> Input Class Initialized
INFO - 2025-01-13 09:02:24 --> Language Class Initialized
INFO - 2025-01-13 09:02:24 --> Loader Class Initialized
INFO - 2025-01-13 09:02:24 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:24 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:24 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:24 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:24 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:24 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:24 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:24 --> Upload Class Initialized
INFO - 2025-01-13 09:02:24 --> Email Class Initialized
INFO - 2025-01-13 09:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:24 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:24 --> Controller Class Initialized
INFO - 2025-01-13 14:32:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:24 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:24 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:29 --> Config Class Initialized
INFO - 2025-01-13 09:02:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:29 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:29 --> URI Class Initialized
INFO - 2025-01-13 09:02:29 --> Router Class Initialized
INFO - 2025-01-13 09:02:29 --> Output Class Initialized
INFO - 2025-01-13 09:02:29 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:29 --> Input Class Initialized
INFO - 2025-01-13 09:02:29 --> Language Class Initialized
INFO - 2025-01-13 09:02:29 --> Loader Class Initialized
INFO - 2025-01-13 09:02:29 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:29 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:29 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:29 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:29 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:29 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:29 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:29 --> Upload Class Initialized
INFO - 2025-01-13 09:02:29 --> Email Class Initialized
INFO - 2025-01-13 09:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:29 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:29 --> Controller Class Initialized
INFO - 2025-01-13 14:32:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:29 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:29 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:34 --> Config Class Initialized
INFO - 2025-01-13 09:02:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:34 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:34 --> URI Class Initialized
INFO - 2025-01-13 09:02:34 --> Router Class Initialized
INFO - 2025-01-13 09:02:34 --> Output Class Initialized
INFO - 2025-01-13 09:02:34 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:34 --> Input Class Initialized
INFO - 2025-01-13 09:02:34 --> Language Class Initialized
INFO - 2025-01-13 09:02:34 --> Loader Class Initialized
INFO - 2025-01-13 09:02:34 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:34 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:34 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:34 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:34 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:34 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:34 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:34 --> Upload Class Initialized
INFO - 2025-01-13 09:02:34 --> Email Class Initialized
INFO - 2025-01-13 09:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:34 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:34 --> Controller Class Initialized
INFO - 2025-01-13 14:32:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:34 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:34 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:39 --> Config Class Initialized
INFO - 2025-01-13 09:02:39 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:39 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:39 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:39 --> URI Class Initialized
INFO - 2025-01-13 09:02:39 --> Router Class Initialized
INFO - 2025-01-13 09:02:39 --> Output Class Initialized
INFO - 2025-01-13 09:02:39 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:39 --> Input Class Initialized
INFO - 2025-01-13 09:02:39 --> Language Class Initialized
INFO - 2025-01-13 09:02:39 --> Loader Class Initialized
INFO - 2025-01-13 09:02:39 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:39 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:39 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:39 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:39 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:39 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:39 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:39 --> Upload Class Initialized
INFO - 2025-01-13 09:02:39 --> Email Class Initialized
INFO - 2025-01-13 09:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:39 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:39 --> Controller Class Initialized
INFO - 2025-01-13 14:32:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:39 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:39 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:44 --> Config Class Initialized
INFO - 2025-01-13 09:02:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:44 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:44 --> URI Class Initialized
INFO - 2025-01-13 09:02:44 --> Router Class Initialized
INFO - 2025-01-13 09:02:44 --> Output Class Initialized
INFO - 2025-01-13 09:02:44 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:44 --> Input Class Initialized
INFO - 2025-01-13 09:02:44 --> Language Class Initialized
INFO - 2025-01-13 09:02:44 --> Loader Class Initialized
INFO - 2025-01-13 09:02:44 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:44 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:44 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:44 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:44 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:44 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:44 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:44 --> Upload Class Initialized
INFO - 2025-01-13 09:02:44 --> Email Class Initialized
INFO - 2025-01-13 09:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:44 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:44 --> Controller Class Initialized
INFO - 2025-01-13 14:32:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:44 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:44 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:46 --> Config Class Initialized
INFO - 2025-01-13 09:02:46 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:46 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:46 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:46 --> URI Class Initialized
INFO - 2025-01-13 09:02:46 --> Router Class Initialized
INFO - 2025-01-13 09:02:46 --> Output Class Initialized
INFO - 2025-01-13 09:02:46 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:46 --> Input Class Initialized
INFO - 2025-01-13 09:02:46 --> Language Class Initialized
INFO - 2025-01-13 09:02:46 --> Loader Class Initialized
INFO - 2025-01-13 09:02:46 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:46 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:46 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:46 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:46 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:46 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:46 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:46 --> Upload Class Initialized
INFO - 2025-01-13 09:02:46 --> Email Class Initialized
INFO - 2025-01-13 09:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:46 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:46 --> Controller Class Initialized
INFO - 2025-01-13 14:32:46 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:32:46 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:32:46 --> Model "MainModel" initialized
INFO - 2025-01-13 09:02:49 --> Config Class Initialized
INFO - 2025-01-13 09:02:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:49 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:49 --> URI Class Initialized
INFO - 2025-01-13 09:02:49 --> Router Class Initialized
INFO - 2025-01-13 09:02:49 --> Output Class Initialized
INFO - 2025-01-13 09:02:49 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:49 --> Input Class Initialized
INFO - 2025-01-13 09:02:49 --> Language Class Initialized
INFO - 2025-01-13 09:02:49 --> Loader Class Initialized
INFO - 2025-01-13 09:02:49 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:49 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:49 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:49 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:49 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:49 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:49 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:49 --> Upload Class Initialized
INFO - 2025-01-13 09:02:49 --> Email Class Initialized
INFO - 2025-01-13 09:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:49 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:49 --> Controller Class Initialized
INFO - 2025-01-13 14:32:49 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:49 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:49 --> Pagination Class Initialized
INFO - 2025-01-13 09:02:57 --> Config Class Initialized
INFO - 2025-01-13 09:02:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:02:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:02:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:02:57 --> URI Class Initialized
INFO - 2025-01-13 09:02:57 --> Router Class Initialized
INFO - 2025-01-13 09:02:57 --> Output Class Initialized
INFO - 2025-01-13 09:02:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:02:57 --> Input Class Initialized
INFO - 2025-01-13 09:02:57 --> Language Class Initialized
INFO - 2025-01-13 09:02:57 --> Loader Class Initialized
INFO - 2025-01-13 09:02:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:02:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:02:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:02:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:02:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:02:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:02:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:02:57 --> Upload Class Initialized
INFO - 2025-01-13 09:02:57 --> Email Class Initialized
INFO - 2025-01-13 09:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:02:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:02:57 --> Controller Class Initialized
INFO - 2025-01-13 14:32:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:32:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:32:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:03:35 --> Config Class Initialized
INFO - 2025-01-13 09:03:35 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:03:35 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:03:35 --> Utf8 Class Initialized
INFO - 2025-01-13 09:03:35 --> URI Class Initialized
INFO - 2025-01-13 09:03:35 --> Router Class Initialized
INFO - 2025-01-13 09:03:35 --> Output Class Initialized
INFO - 2025-01-13 09:03:35 --> Security Class Initialized
DEBUG - 2025-01-13 09:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:03:35 --> Input Class Initialized
INFO - 2025-01-13 09:03:35 --> Language Class Initialized
INFO - 2025-01-13 09:03:35 --> Loader Class Initialized
INFO - 2025-01-13 09:03:35 --> Helper loaded: url_helper
INFO - 2025-01-13 09:03:35 --> Helper loaded: html_helper
INFO - 2025-01-13 09:03:35 --> Helper loaded: file_helper
INFO - 2025-01-13 09:03:35 --> Helper loaded: string_helper
INFO - 2025-01-13 09:03:35 --> Helper loaded: form_helper
INFO - 2025-01-13 09:03:35 --> Helper loaded: my_helper
INFO - 2025-01-13 09:03:35 --> Database Driver Class Initialized
INFO - 2025-01-13 09:03:35 --> Upload Class Initialized
INFO - 2025-01-13 09:03:35 --> Email Class Initialized
INFO - 2025-01-13 09:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:03:35 --> Form Validation Class Initialized
INFO - 2025-01-13 09:03:35 --> Controller Class Initialized
INFO - 2025-01-13 14:33:35 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:33:35 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:33:35 --> Model "MainModel" initialized
INFO - 2025-01-13 09:03:57 --> Config Class Initialized
INFO - 2025-01-13 09:03:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:03:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:03:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:03:57 --> URI Class Initialized
INFO - 2025-01-13 09:03:57 --> Router Class Initialized
INFO - 2025-01-13 09:03:57 --> Output Class Initialized
INFO - 2025-01-13 09:03:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:03:57 --> Input Class Initialized
INFO - 2025-01-13 09:03:57 --> Language Class Initialized
INFO - 2025-01-13 09:03:57 --> Loader Class Initialized
INFO - 2025-01-13 09:03:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:03:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:03:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:03:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:03:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:03:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:03:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:03:57 --> Upload Class Initialized
INFO - 2025-01-13 09:03:57 --> Email Class Initialized
INFO - 2025-01-13 09:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:03:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:03:57 --> Controller Class Initialized
INFO - 2025-01-13 14:33:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:33:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:33:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:04:48 --> Config Class Initialized
INFO - 2025-01-13 09:04:48 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:04:48 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:04:48 --> Utf8 Class Initialized
INFO - 2025-01-13 09:04:48 --> URI Class Initialized
INFO - 2025-01-13 09:04:48 --> Router Class Initialized
INFO - 2025-01-13 09:04:48 --> Output Class Initialized
INFO - 2025-01-13 09:04:48 --> Security Class Initialized
DEBUG - 2025-01-13 09:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:04:48 --> Input Class Initialized
INFO - 2025-01-13 09:04:48 --> Language Class Initialized
INFO - 2025-01-13 09:04:48 --> Loader Class Initialized
INFO - 2025-01-13 09:04:48 --> Helper loaded: url_helper
INFO - 2025-01-13 09:04:48 --> Helper loaded: html_helper
INFO - 2025-01-13 09:04:48 --> Helper loaded: file_helper
INFO - 2025-01-13 09:04:48 --> Helper loaded: string_helper
INFO - 2025-01-13 09:04:48 --> Helper loaded: form_helper
INFO - 2025-01-13 09:04:48 --> Helper loaded: my_helper
INFO - 2025-01-13 09:04:48 --> Database Driver Class Initialized
INFO - 2025-01-13 09:04:48 --> Upload Class Initialized
INFO - 2025-01-13 09:04:48 --> Email Class Initialized
INFO - 2025-01-13 09:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:04:48 --> Form Validation Class Initialized
INFO - 2025-01-13 09:04:48 --> Controller Class Initialized
INFO - 2025-01-13 14:34:48 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:34:48 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:34:48 --> Model "MainModel" initialized
INFO - 2025-01-13 09:04:49 --> Config Class Initialized
INFO - 2025-01-13 09:04:49 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:04:49 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:04:49 --> Utf8 Class Initialized
INFO - 2025-01-13 09:04:49 --> URI Class Initialized
INFO - 2025-01-13 09:04:49 --> Router Class Initialized
INFO - 2025-01-13 09:04:49 --> Output Class Initialized
INFO - 2025-01-13 09:04:49 --> Security Class Initialized
DEBUG - 2025-01-13 09:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:04:49 --> Input Class Initialized
INFO - 2025-01-13 09:04:49 --> Language Class Initialized
INFO - 2025-01-13 09:04:49 --> Loader Class Initialized
INFO - 2025-01-13 09:04:49 --> Helper loaded: url_helper
INFO - 2025-01-13 09:04:49 --> Helper loaded: html_helper
INFO - 2025-01-13 09:04:49 --> Helper loaded: file_helper
INFO - 2025-01-13 09:04:49 --> Helper loaded: string_helper
INFO - 2025-01-13 09:04:49 --> Helper loaded: form_helper
INFO - 2025-01-13 09:04:49 --> Helper loaded: my_helper
INFO - 2025-01-13 09:04:49 --> Database Driver Class Initialized
INFO - 2025-01-13 09:04:49 --> Upload Class Initialized
INFO - 2025-01-13 09:04:49 --> Email Class Initialized
INFO - 2025-01-13 09:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:04:49 --> Form Validation Class Initialized
INFO - 2025-01-13 09:04:49 --> Controller Class Initialized
INFO - 2025-01-13 14:34:49 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:34:49 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:34:49 --> Model "MainModel" initialized
INFO - 2025-01-13 09:04:57 --> Config Class Initialized
INFO - 2025-01-13 09:04:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:04:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:04:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:04:57 --> URI Class Initialized
INFO - 2025-01-13 09:04:57 --> Router Class Initialized
INFO - 2025-01-13 09:04:57 --> Output Class Initialized
INFO - 2025-01-13 09:04:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:04:57 --> Input Class Initialized
INFO - 2025-01-13 09:04:57 --> Language Class Initialized
INFO - 2025-01-13 09:04:57 --> Loader Class Initialized
INFO - 2025-01-13 09:04:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:04:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:04:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:04:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:04:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:04:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:04:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:04:57 --> Upload Class Initialized
INFO - 2025-01-13 09:04:57 --> Email Class Initialized
INFO - 2025-01-13 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:04:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:04:57 --> Controller Class Initialized
INFO - 2025-01-13 14:34:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:34:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:34:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:05:57 --> Config Class Initialized
INFO - 2025-01-13 09:05:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:05:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:05:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:05:57 --> URI Class Initialized
INFO - 2025-01-13 09:05:57 --> Router Class Initialized
INFO - 2025-01-13 09:05:57 --> Output Class Initialized
INFO - 2025-01-13 09:05:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:05:57 --> Input Class Initialized
INFO - 2025-01-13 09:05:57 --> Language Class Initialized
INFO - 2025-01-13 09:05:57 --> Loader Class Initialized
INFO - 2025-01-13 09:05:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:05:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:05:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:05:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:05:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:05:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:05:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:05:57 --> Upload Class Initialized
INFO - 2025-01-13 09:05:57 --> Email Class Initialized
INFO - 2025-01-13 09:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:05:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:05:57 --> Controller Class Initialized
INFO - 2025-01-13 14:35:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:35:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:35:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:06:57 --> Config Class Initialized
INFO - 2025-01-13 09:06:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:06:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:06:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:06:57 --> URI Class Initialized
INFO - 2025-01-13 09:06:57 --> Router Class Initialized
INFO - 2025-01-13 09:06:57 --> Output Class Initialized
INFO - 2025-01-13 09:06:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:06:57 --> Input Class Initialized
INFO - 2025-01-13 09:06:57 --> Language Class Initialized
INFO - 2025-01-13 09:06:57 --> Loader Class Initialized
INFO - 2025-01-13 09:06:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:06:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:06:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:06:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:06:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:06:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:06:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:06:57 --> Upload Class Initialized
INFO - 2025-01-13 09:06:57 --> Email Class Initialized
INFO - 2025-01-13 09:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:06:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:06:57 --> Controller Class Initialized
INFO - 2025-01-13 14:36:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:36:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:36:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:07:57 --> Config Class Initialized
INFO - 2025-01-13 09:07:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:07:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:07:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:07:57 --> URI Class Initialized
INFO - 2025-01-13 09:07:57 --> Router Class Initialized
INFO - 2025-01-13 09:07:57 --> Output Class Initialized
INFO - 2025-01-13 09:07:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:07:57 --> Input Class Initialized
INFO - 2025-01-13 09:07:57 --> Language Class Initialized
INFO - 2025-01-13 09:07:57 --> Loader Class Initialized
INFO - 2025-01-13 09:07:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:07:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:07:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:07:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:07:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:07:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:07:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:07:57 --> Upload Class Initialized
INFO - 2025-01-13 09:07:57 --> Email Class Initialized
INFO - 2025-01-13 09:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:07:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:07:57 --> Controller Class Initialized
INFO - 2025-01-13 14:37:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:37:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:37:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:08:57 --> Config Class Initialized
INFO - 2025-01-13 09:08:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:08:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:08:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:08:57 --> URI Class Initialized
INFO - 2025-01-13 09:08:57 --> Router Class Initialized
INFO - 2025-01-13 09:08:57 --> Output Class Initialized
INFO - 2025-01-13 09:08:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:08:57 --> Input Class Initialized
INFO - 2025-01-13 09:08:57 --> Language Class Initialized
INFO - 2025-01-13 09:08:57 --> Loader Class Initialized
INFO - 2025-01-13 09:08:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:08:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:08:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:08:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:08:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:08:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:08:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:08:57 --> Upload Class Initialized
INFO - 2025-01-13 09:08:57 --> Email Class Initialized
INFO - 2025-01-13 09:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:08:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:08:57 --> Controller Class Initialized
INFO - 2025-01-13 14:38:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:38:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:38:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:09:57 --> Config Class Initialized
INFO - 2025-01-13 09:09:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:09:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:09:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:09:57 --> URI Class Initialized
INFO - 2025-01-13 09:09:57 --> Router Class Initialized
INFO - 2025-01-13 09:09:57 --> Output Class Initialized
INFO - 2025-01-13 09:09:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:09:57 --> Input Class Initialized
INFO - 2025-01-13 09:09:57 --> Language Class Initialized
INFO - 2025-01-13 09:09:57 --> Loader Class Initialized
INFO - 2025-01-13 09:09:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:09:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:09:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:09:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:09:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:09:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:09:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:09:57 --> Upload Class Initialized
INFO - 2025-01-13 09:09:57 --> Email Class Initialized
INFO - 2025-01-13 09:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:09:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:09:57 --> Controller Class Initialized
INFO - 2025-01-13 14:39:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:39:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:39:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:39:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:10:57 --> Config Class Initialized
INFO - 2025-01-13 09:10:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:10:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:10:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:10:57 --> URI Class Initialized
INFO - 2025-01-13 09:10:57 --> Router Class Initialized
INFO - 2025-01-13 09:10:57 --> Output Class Initialized
INFO - 2025-01-13 09:10:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:10:57 --> Input Class Initialized
INFO - 2025-01-13 09:10:57 --> Language Class Initialized
INFO - 2025-01-13 09:10:57 --> Loader Class Initialized
INFO - 2025-01-13 09:10:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:10:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:10:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:10:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:10:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:10:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:10:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:10:57 --> Upload Class Initialized
INFO - 2025-01-13 09:10:57 --> Email Class Initialized
INFO - 2025-01-13 09:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:10:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:10:57 --> Controller Class Initialized
INFO - 2025-01-13 14:40:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:40:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:40:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:11:57 --> Config Class Initialized
INFO - 2025-01-13 09:11:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:11:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:11:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:11:57 --> URI Class Initialized
INFO - 2025-01-13 09:11:57 --> Router Class Initialized
INFO - 2025-01-13 09:11:57 --> Output Class Initialized
INFO - 2025-01-13 09:11:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:11:57 --> Input Class Initialized
INFO - 2025-01-13 09:11:57 --> Language Class Initialized
INFO - 2025-01-13 09:11:57 --> Loader Class Initialized
INFO - 2025-01-13 09:11:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:11:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:11:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:11:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:11:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:11:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:11:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:11:57 --> Upload Class Initialized
INFO - 2025-01-13 09:11:57 --> Email Class Initialized
INFO - 2025-01-13 09:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:11:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:11:57 --> Controller Class Initialized
INFO - 2025-01-13 14:41:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:41:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:41:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:12:57 --> Config Class Initialized
INFO - 2025-01-13 09:12:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:12:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:12:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:12:57 --> URI Class Initialized
INFO - 2025-01-13 09:12:57 --> Router Class Initialized
INFO - 2025-01-13 09:12:57 --> Output Class Initialized
INFO - 2025-01-13 09:12:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:12:57 --> Input Class Initialized
INFO - 2025-01-13 09:12:57 --> Language Class Initialized
INFO - 2025-01-13 09:12:57 --> Loader Class Initialized
INFO - 2025-01-13 09:12:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:12:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:12:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:12:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:12:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:12:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:12:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:12:57 --> Upload Class Initialized
INFO - 2025-01-13 09:12:57 --> Email Class Initialized
INFO - 2025-01-13 09:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:12:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:12:57 --> Controller Class Initialized
INFO - 2025-01-13 14:42:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:42:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:42:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:13:57 --> Config Class Initialized
INFO - 2025-01-13 09:13:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:13:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:13:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:13:57 --> URI Class Initialized
INFO - 2025-01-13 09:13:57 --> Router Class Initialized
INFO - 2025-01-13 09:13:57 --> Output Class Initialized
INFO - 2025-01-13 09:13:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:13:57 --> Input Class Initialized
INFO - 2025-01-13 09:13:57 --> Language Class Initialized
INFO - 2025-01-13 09:13:57 --> Loader Class Initialized
INFO - 2025-01-13 09:13:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:13:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:13:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:13:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:13:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:13:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:13:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:13:57 --> Upload Class Initialized
INFO - 2025-01-13 09:13:57 --> Email Class Initialized
INFO - 2025-01-13 09:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:13:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:13:57 --> Controller Class Initialized
INFO - 2025-01-13 14:43:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:43:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:43:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:14:37 --> Config Class Initialized
INFO - 2025-01-13 09:14:37 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:14:37 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:14:37 --> Utf8 Class Initialized
INFO - 2025-01-13 09:14:37 --> URI Class Initialized
INFO - 2025-01-13 09:14:37 --> Router Class Initialized
INFO - 2025-01-13 09:14:37 --> Output Class Initialized
INFO - 2025-01-13 09:14:37 --> Security Class Initialized
DEBUG - 2025-01-13 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:14:37 --> Input Class Initialized
INFO - 2025-01-13 09:14:37 --> Language Class Initialized
INFO - 2025-01-13 09:14:37 --> Loader Class Initialized
INFO - 2025-01-13 09:14:37 --> Helper loaded: url_helper
INFO - 2025-01-13 09:14:37 --> Helper loaded: html_helper
INFO - 2025-01-13 09:14:37 --> Helper loaded: file_helper
INFO - 2025-01-13 09:14:37 --> Helper loaded: string_helper
INFO - 2025-01-13 09:14:37 --> Helper loaded: form_helper
INFO - 2025-01-13 09:14:37 --> Helper loaded: my_helper
INFO - 2025-01-13 09:14:37 --> Database Driver Class Initialized
INFO - 2025-01-13 09:14:37 --> Upload Class Initialized
INFO - 2025-01-13 09:14:37 --> Email Class Initialized
INFO - 2025-01-13 09:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:14:37 --> Form Validation Class Initialized
INFO - 2025-01-13 09:14:37 --> Controller Class Initialized
INFO - 2025-01-13 14:44:37 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:44:37 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:44:37 --> Model "MainModel" initialized
INFO - 2025-01-13 09:14:57 --> Config Class Initialized
INFO - 2025-01-13 09:14:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:14:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:14:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:14:57 --> URI Class Initialized
INFO - 2025-01-13 09:14:57 --> Router Class Initialized
INFO - 2025-01-13 09:14:57 --> Output Class Initialized
INFO - 2025-01-13 09:14:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:14:57 --> Input Class Initialized
INFO - 2025-01-13 09:14:57 --> Language Class Initialized
INFO - 2025-01-13 09:14:57 --> Loader Class Initialized
INFO - 2025-01-13 09:14:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:14:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:14:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:14:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:14:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:14:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:14:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:14:57 --> Upload Class Initialized
INFO - 2025-01-13 09:14:57 --> Email Class Initialized
INFO - 2025-01-13 09:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:14:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:14:57 --> Controller Class Initialized
INFO - 2025-01-13 14:44:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:44:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:44:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:15:15 --> Config Class Initialized
INFO - 2025-01-13 09:15:15 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:15:15 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:15:15 --> Utf8 Class Initialized
INFO - 2025-01-13 09:15:15 --> URI Class Initialized
INFO - 2025-01-13 09:15:15 --> Router Class Initialized
INFO - 2025-01-13 09:15:15 --> Output Class Initialized
INFO - 2025-01-13 09:15:15 --> Security Class Initialized
DEBUG - 2025-01-13 09:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:15:15 --> Input Class Initialized
INFO - 2025-01-13 09:15:15 --> Language Class Initialized
INFO - 2025-01-13 09:15:15 --> Loader Class Initialized
INFO - 2025-01-13 09:15:15 --> Helper loaded: url_helper
INFO - 2025-01-13 09:15:15 --> Helper loaded: html_helper
INFO - 2025-01-13 09:15:15 --> Helper loaded: file_helper
INFO - 2025-01-13 09:15:15 --> Helper loaded: string_helper
INFO - 2025-01-13 09:15:15 --> Helper loaded: form_helper
INFO - 2025-01-13 09:15:15 --> Helper loaded: my_helper
INFO - 2025-01-13 09:15:15 --> Database Driver Class Initialized
INFO - 2025-01-13 09:15:15 --> Upload Class Initialized
INFO - 2025-01-13 09:15:15 --> Email Class Initialized
INFO - 2025-01-13 09:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:15:15 --> Form Validation Class Initialized
INFO - 2025-01-13 09:15:15 --> Controller Class Initialized
INFO - 2025-01-13 14:45:15 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:45:15 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:45:15 --> Model "MainModel" initialized
INFO - 2025-01-13 09:15:57 --> Config Class Initialized
INFO - 2025-01-13 09:15:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:15:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:15:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:15:57 --> URI Class Initialized
INFO - 2025-01-13 09:15:57 --> Router Class Initialized
INFO - 2025-01-13 09:15:57 --> Output Class Initialized
INFO - 2025-01-13 09:15:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:15:57 --> Input Class Initialized
INFO - 2025-01-13 09:15:57 --> Language Class Initialized
INFO - 2025-01-13 09:15:57 --> Loader Class Initialized
INFO - 2025-01-13 09:15:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:15:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:15:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:15:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:15:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:15:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:15:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:15:57 --> Upload Class Initialized
INFO - 2025-01-13 09:15:57 --> Email Class Initialized
INFO - 2025-01-13 09:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:15:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:15:57 --> Controller Class Initialized
INFO - 2025-01-13 14:45:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:45:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:45:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:16:57 --> Config Class Initialized
INFO - 2025-01-13 09:16:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:16:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:16:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:16:57 --> URI Class Initialized
INFO - 2025-01-13 09:16:57 --> Router Class Initialized
INFO - 2025-01-13 09:16:57 --> Output Class Initialized
INFO - 2025-01-13 09:16:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:16:57 --> Input Class Initialized
INFO - 2025-01-13 09:16:57 --> Language Class Initialized
INFO - 2025-01-13 09:16:57 --> Loader Class Initialized
INFO - 2025-01-13 09:16:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:16:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:16:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:16:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:16:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:16:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:16:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:16:57 --> Upload Class Initialized
INFO - 2025-01-13 09:16:57 --> Email Class Initialized
INFO - 2025-01-13 09:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:16:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:16:57 --> Controller Class Initialized
INFO - 2025-01-13 14:46:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:46:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:46:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:17:43 --> Config Class Initialized
INFO - 2025-01-13 09:17:43 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:17:43 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:17:43 --> Utf8 Class Initialized
INFO - 2025-01-13 09:17:43 --> URI Class Initialized
INFO - 2025-01-13 09:17:43 --> Router Class Initialized
INFO - 2025-01-13 09:17:43 --> Output Class Initialized
INFO - 2025-01-13 09:17:43 --> Security Class Initialized
DEBUG - 2025-01-13 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:17:43 --> Input Class Initialized
INFO - 2025-01-13 09:17:43 --> Language Class Initialized
INFO - 2025-01-13 09:17:43 --> Loader Class Initialized
INFO - 2025-01-13 09:17:43 --> Helper loaded: url_helper
INFO - 2025-01-13 09:17:43 --> Helper loaded: html_helper
INFO - 2025-01-13 09:17:43 --> Helper loaded: file_helper
INFO - 2025-01-13 09:17:43 --> Helper loaded: string_helper
INFO - 2025-01-13 09:17:43 --> Helper loaded: form_helper
INFO - 2025-01-13 09:17:43 --> Helper loaded: my_helper
INFO - 2025-01-13 09:17:43 --> Database Driver Class Initialized
INFO - 2025-01-13 09:17:43 --> Upload Class Initialized
INFO - 2025-01-13 09:17:43 --> Email Class Initialized
INFO - 2025-01-13 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:17:43 --> Form Validation Class Initialized
INFO - 2025-01-13 09:17:43 --> Controller Class Initialized
INFO - 2025-01-13 14:47:43 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:47:43 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:47:43 --> Model "MainModel" initialized
INFO - 2025-01-13 09:17:57 --> Config Class Initialized
INFO - 2025-01-13 09:17:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:17:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:17:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:17:57 --> URI Class Initialized
INFO - 2025-01-13 09:17:57 --> Router Class Initialized
INFO - 2025-01-13 09:17:57 --> Output Class Initialized
INFO - 2025-01-13 09:17:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:17:57 --> Input Class Initialized
INFO - 2025-01-13 09:17:57 --> Language Class Initialized
INFO - 2025-01-13 09:17:57 --> Loader Class Initialized
INFO - 2025-01-13 09:17:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:17:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:17:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:17:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:17:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:17:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:17:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:17:57 --> Upload Class Initialized
INFO - 2025-01-13 09:17:57 --> Email Class Initialized
INFO - 2025-01-13 09:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:17:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:17:57 --> Controller Class Initialized
INFO - 2025-01-13 14:47:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:47:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:47:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:18:57 --> Config Class Initialized
INFO - 2025-01-13 09:18:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:18:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:18:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:18:57 --> URI Class Initialized
INFO - 2025-01-13 09:18:57 --> Router Class Initialized
INFO - 2025-01-13 09:18:57 --> Output Class Initialized
INFO - 2025-01-13 09:18:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:18:57 --> Input Class Initialized
INFO - 2025-01-13 09:18:57 --> Language Class Initialized
INFO - 2025-01-13 09:18:57 --> Loader Class Initialized
INFO - 2025-01-13 09:18:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:18:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:18:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:18:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:18:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:18:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:18:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:18:57 --> Upload Class Initialized
INFO - 2025-01-13 09:18:57 --> Email Class Initialized
INFO - 2025-01-13 09:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:18:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:18:57 --> Controller Class Initialized
INFO - 2025-01-13 14:48:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:48:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:48:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:19:48 --> Config Class Initialized
INFO - 2025-01-13 09:19:48 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:19:48 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:19:48 --> Utf8 Class Initialized
INFO - 2025-01-13 09:19:48 --> URI Class Initialized
INFO - 2025-01-13 09:19:48 --> Router Class Initialized
INFO - 2025-01-13 09:19:48 --> Output Class Initialized
INFO - 2025-01-13 09:19:48 --> Security Class Initialized
DEBUG - 2025-01-13 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:19:48 --> Input Class Initialized
INFO - 2025-01-13 09:19:48 --> Language Class Initialized
INFO - 2025-01-13 09:19:48 --> Loader Class Initialized
INFO - 2025-01-13 09:19:48 --> Helper loaded: url_helper
INFO - 2025-01-13 09:19:48 --> Helper loaded: html_helper
INFO - 2025-01-13 09:19:48 --> Helper loaded: file_helper
INFO - 2025-01-13 09:19:48 --> Helper loaded: string_helper
INFO - 2025-01-13 09:19:48 --> Helper loaded: form_helper
INFO - 2025-01-13 09:19:48 --> Helper loaded: my_helper
INFO - 2025-01-13 09:19:48 --> Database Driver Class Initialized
INFO - 2025-01-13 09:19:48 --> Upload Class Initialized
INFO - 2025-01-13 09:19:48 --> Email Class Initialized
INFO - 2025-01-13 09:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:19:48 --> Form Validation Class Initialized
INFO - 2025-01-13 09:19:48 --> Controller Class Initialized
INFO - 2025-01-13 14:49:48 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:49:48 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:49:48 --> Model "MainModel" initialized
INFO - 2025-01-13 09:19:57 --> Config Class Initialized
INFO - 2025-01-13 09:19:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:19:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:19:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:19:57 --> URI Class Initialized
INFO - 2025-01-13 09:19:57 --> Router Class Initialized
INFO - 2025-01-13 09:19:57 --> Output Class Initialized
INFO - 2025-01-13 09:19:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:19:57 --> Input Class Initialized
INFO - 2025-01-13 09:19:57 --> Language Class Initialized
INFO - 2025-01-13 09:19:57 --> Loader Class Initialized
INFO - 2025-01-13 09:19:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:19:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:19:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:19:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:19:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:19:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:19:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:19:57 --> Upload Class Initialized
INFO - 2025-01-13 09:19:57 --> Email Class Initialized
INFO - 2025-01-13 09:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:19:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:19:57 --> Controller Class Initialized
INFO - 2025-01-13 14:49:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:49:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:49:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:20:10 --> Config Class Initialized
INFO - 2025-01-13 09:20:10 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:20:10 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:20:10 --> Utf8 Class Initialized
INFO - 2025-01-13 09:20:10 --> URI Class Initialized
INFO - 2025-01-13 09:20:10 --> Router Class Initialized
INFO - 2025-01-13 09:20:10 --> Output Class Initialized
INFO - 2025-01-13 09:20:10 --> Security Class Initialized
DEBUG - 2025-01-13 09:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:20:10 --> Input Class Initialized
INFO - 2025-01-13 09:20:10 --> Language Class Initialized
INFO - 2025-01-13 09:20:10 --> Loader Class Initialized
INFO - 2025-01-13 09:20:10 --> Helper loaded: url_helper
INFO - 2025-01-13 09:20:10 --> Helper loaded: html_helper
INFO - 2025-01-13 09:20:10 --> Helper loaded: file_helper
INFO - 2025-01-13 09:20:10 --> Helper loaded: string_helper
INFO - 2025-01-13 09:20:10 --> Helper loaded: form_helper
INFO - 2025-01-13 09:20:10 --> Helper loaded: my_helper
INFO - 2025-01-13 09:20:10 --> Database Driver Class Initialized
INFO - 2025-01-13 09:20:10 --> Upload Class Initialized
INFO - 2025-01-13 09:20:10 --> Email Class Initialized
INFO - 2025-01-13 09:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:20:10 --> Form Validation Class Initialized
INFO - 2025-01-13 09:20:10 --> Controller Class Initialized
INFO - 2025-01-13 14:50:10 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:50:10 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:50:10 --> Model "MainModel" initialized
INFO - 2025-01-13 09:20:57 --> Config Class Initialized
INFO - 2025-01-13 09:20:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:20:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:20:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:20:57 --> URI Class Initialized
INFO - 2025-01-13 09:20:57 --> Router Class Initialized
INFO - 2025-01-13 09:20:57 --> Output Class Initialized
INFO - 2025-01-13 09:20:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:20:57 --> Input Class Initialized
INFO - 2025-01-13 09:20:57 --> Language Class Initialized
INFO - 2025-01-13 09:20:57 --> Loader Class Initialized
INFO - 2025-01-13 09:20:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:20:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:20:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:20:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:20:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:20:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:20:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:20:57 --> Upload Class Initialized
INFO - 2025-01-13 09:20:57 --> Email Class Initialized
INFO - 2025-01-13 09:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:20:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:20:57 --> Controller Class Initialized
INFO - 2025-01-13 14:50:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:50:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:50:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:21:57 --> Config Class Initialized
INFO - 2025-01-13 09:21:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:21:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:21:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:21:57 --> URI Class Initialized
INFO - 2025-01-13 09:21:57 --> Router Class Initialized
INFO - 2025-01-13 09:21:57 --> Output Class Initialized
INFO - 2025-01-13 09:21:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:21:57 --> Input Class Initialized
INFO - 2025-01-13 09:21:57 --> Language Class Initialized
INFO - 2025-01-13 09:21:57 --> Loader Class Initialized
INFO - 2025-01-13 09:21:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:21:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:21:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:21:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:21:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:21:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:21:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:21:57 --> Upload Class Initialized
INFO - 2025-01-13 09:21:57 --> Email Class Initialized
INFO - 2025-01-13 09:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:21:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:21:57 --> Controller Class Initialized
INFO - 2025-01-13 14:51:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:51:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:51:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:22:57 --> Config Class Initialized
INFO - 2025-01-13 09:22:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:22:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:22:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:22:57 --> URI Class Initialized
INFO - 2025-01-13 09:22:57 --> Router Class Initialized
INFO - 2025-01-13 09:22:57 --> Output Class Initialized
INFO - 2025-01-13 09:22:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:22:57 --> Input Class Initialized
INFO - 2025-01-13 09:22:57 --> Language Class Initialized
INFO - 2025-01-13 09:22:57 --> Loader Class Initialized
INFO - 2025-01-13 09:22:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:22:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:22:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:22:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:22:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:22:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:22:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:22:57 --> Upload Class Initialized
INFO - 2025-01-13 09:22:57 --> Email Class Initialized
INFO - 2025-01-13 09:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:22:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:22:57 --> Controller Class Initialized
INFO - 2025-01-13 14:52:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:52:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:52:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:23:57 --> Config Class Initialized
INFO - 2025-01-13 09:23:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:23:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:23:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:23:57 --> URI Class Initialized
INFO - 2025-01-13 09:23:57 --> Router Class Initialized
INFO - 2025-01-13 09:23:57 --> Output Class Initialized
INFO - 2025-01-13 09:23:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:23:57 --> Input Class Initialized
INFO - 2025-01-13 09:23:57 --> Language Class Initialized
INFO - 2025-01-13 09:23:57 --> Loader Class Initialized
INFO - 2025-01-13 09:23:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:23:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:23:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:23:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:23:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:23:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:23:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:23:57 --> Upload Class Initialized
INFO - 2025-01-13 09:23:57 --> Email Class Initialized
INFO - 2025-01-13 09:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:23:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:23:57 --> Controller Class Initialized
INFO - 2025-01-13 14:53:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:53:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:53:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:24:57 --> Config Class Initialized
INFO - 2025-01-13 09:24:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:24:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:24:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:24:57 --> URI Class Initialized
INFO - 2025-01-13 09:24:57 --> Router Class Initialized
INFO - 2025-01-13 09:24:57 --> Output Class Initialized
INFO - 2025-01-13 09:24:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:24:57 --> Input Class Initialized
INFO - 2025-01-13 09:24:57 --> Language Class Initialized
INFO - 2025-01-13 09:24:57 --> Loader Class Initialized
INFO - 2025-01-13 09:24:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:24:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:24:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:24:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:24:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:24:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:24:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:24:57 --> Upload Class Initialized
INFO - 2025-01-13 09:24:57 --> Email Class Initialized
INFO - 2025-01-13 09:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:24:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:24:57 --> Controller Class Initialized
INFO - 2025-01-13 14:54:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:54:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:54:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:25:57 --> Config Class Initialized
INFO - 2025-01-13 09:25:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:25:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:25:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:25:57 --> URI Class Initialized
INFO - 2025-01-13 09:25:57 --> Router Class Initialized
INFO - 2025-01-13 09:25:57 --> Output Class Initialized
INFO - 2025-01-13 09:25:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:25:57 --> Input Class Initialized
INFO - 2025-01-13 09:25:57 --> Language Class Initialized
INFO - 2025-01-13 09:25:57 --> Loader Class Initialized
INFO - 2025-01-13 09:25:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:25:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:25:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:25:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:25:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:25:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:25:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:25:57 --> Upload Class Initialized
INFO - 2025-01-13 09:25:57 --> Email Class Initialized
INFO - 2025-01-13 09:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:25:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:25:57 --> Controller Class Initialized
INFO - 2025-01-13 14:55:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:55:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:55:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:26:57 --> Config Class Initialized
INFO - 2025-01-13 09:26:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:26:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:26:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:26:57 --> URI Class Initialized
INFO - 2025-01-13 09:26:57 --> Router Class Initialized
INFO - 2025-01-13 09:26:57 --> Output Class Initialized
INFO - 2025-01-13 09:26:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:26:57 --> Input Class Initialized
INFO - 2025-01-13 09:26:57 --> Language Class Initialized
INFO - 2025-01-13 09:26:57 --> Loader Class Initialized
INFO - 2025-01-13 09:26:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:26:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:26:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:26:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:26:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:26:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:26:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:26:57 --> Upload Class Initialized
INFO - 2025-01-13 09:26:57 --> Email Class Initialized
INFO - 2025-01-13 09:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:26:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:26:57 --> Controller Class Initialized
INFO - 2025-01-13 14:56:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:56:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:56:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:27:57 --> Config Class Initialized
INFO - 2025-01-13 09:27:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:27:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:27:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:27:57 --> URI Class Initialized
INFO - 2025-01-13 09:27:57 --> Router Class Initialized
INFO - 2025-01-13 09:27:57 --> Output Class Initialized
INFO - 2025-01-13 09:27:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:27:57 --> Input Class Initialized
INFO - 2025-01-13 09:27:57 --> Language Class Initialized
INFO - 2025-01-13 09:27:57 --> Loader Class Initialized
INFO - 2025-01-13 09:27:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:27:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:27:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:27:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:27:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:27:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:27:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:27:57 --> Upload Class Initialized
INFO - 2025-01-13 09:27:57 --> Email Class Initialized
INFO - 2025-01-13 09:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:27:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:27:57 --> Controller Class Initialized
INFO - 2025-01-13 14:57:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:57:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:57:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:28:57 --> Config Class Initialized
INFO - 2025-01-13 09:28:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:28:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:28:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:28:57 --> URI Class Initialized
INFO - 2025-01-13 09:28:57 --> Router Class Initialized
INFO - 2025-01-13 09:28:57 --> Output Class Initialized
INFO - 2025-01-13 09:28:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:28:57 --> Input Class Initialized
INFO - 2025-01-13 09:28:57 --> Language Class Initialized
INFO - 2025-01-13 09:28:57 --> Loader Class Initialized
INFO - 2025-01-13 09:28:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:28:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:28:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:28:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:28:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:28:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:28:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:28:57 --> Upload Class Initialized
INFO - 2025-01-13 09:28:57 --> Email Class Initialized
INFO - 2025-01-13 09:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:28:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:28:57 --> Controller Class Initialized
INFO - 2025-01-13 14:58:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:58:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:58:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:29:35 --> Config Class Initialized
INFO - 2025-01-13 09:29:35 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:29:35 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:29:35 --> Utf8 Class Initialized
INFO - 2025-01-13 09:29:35 --> URI Class Initialized
INFO - 2025-01-13 09:29:35 --> Router Class Initialized
INFO - 2025-01-13 09:29:35 --> Output Class Initialized
INFO - 2025-01-13 09:29:35 --> Security Class Initialized
DEBUG - 2025-01-13 09:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:29:35 --> Input Class Initialized
INFO - 2025-01-13 09:29:35 --> Language Class Initialized
INFO - 2025-01-13 09:29:35 --> Loader Class Initialized
INFO - 2025-01-13 09:29:35 --> Helper loaded: url_helper
INFO - 2025-01-13 09:29:35 --> Helper loaded: html_helper
INFO - 2025-01-13 09:29:35 --> Helper loaded: file_helper
INFO - 2025-01-13 09:29:35 --> Helper loaded: string_helper
INFO - 2025-01-13 09:29:35 --> Helper loaded: form_helper
INFO - 2025-01-13 09:29:35 --> Helper loaded: my_helper
INFO - 2025-01-13 09:29:35 --> Database Driver Class Initialized
INFO - 2025-01-13 09:29:35 --> Upload Class Initialized
INFO - 2025-01-13 09:29:35 --> Email Class Initialized
INFO - 2025-01-13 09:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:29:35 --> Form Validation Class Initialized
INFO - 2025-01-13 09:29:35 --> Controller Class Initialized
INFO - 2025-01-13 14:59:35 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:59:35 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:59:35 --> Model "MainModel" initialized
INFO - 2025-01-13 09:29:44 --> Config Class Initialized
INFO - 2025-01-13 09:29:44 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:29:44 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:29:44 --> Utf8 Class Initialized
INFO - 2025-01-13 09:29:44 --> URI Class Initialized
INFO - 2025-01-13 09:29:44 --> Router Class Initialized
INFO - 2025-01-13 09:29:44 --> Output Class Initialized
INFO - 2025-01-13 09:29:44 --> Security Class Initialized
DEBUG - 2025-01-13 09:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:29:44 --> Input Class Initialized
INFO - 2025-01-13 09:29:44 --> Language Class Initialized
INFO - 2025-01-13 09:29:44 --> Loader Class Initialized
INFO - 2025-01-13 09:29:44 --> Helper loaded: url_helper
INFO - 2025-01-13 09:29:44 --> Helper loaded: html_helper
INFO - 2025-01-13 09:29:44 --> Helper loaded: file_helper
INFO - 2025-01-13 09:29:44 --> Helper loaded: string_helper
INFO - 2025-01-13 09:29:44 --> Helper loaded: form_helper
INFO - 2025-01-13 09:29:44 --> Helper loaded: my_helper
INFO - 2025-01-13 09:29:44 --> Database Driver Class Initialized
INFO - 2025-01-13 09:29:44 --> Upload Class Initialized
INFO - 2025-01-13 09:29:44 --> Email Class Initialized
INFO - 2025-01-13 09:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:29:44 --> Form Validation Class Initialized
INFO - 2025-01-13 09:29:44 --> Controller Class Initialized
INFO - 2025-01-13 14:59:44 --> Model "ApiModel" initialized
INFO - 2025-01-13 14:59:44 --> Helper loaded: notification_helper
INFO - 2025-01-13 14:59:44 --> Model "MainModel" initialized
INFO - 2025-01-13 09:29:57 --> Config Class Initialized
INFO - 2025-01-13 09:29:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:29:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:29:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:29:57 --> URI Class Initialized
INFO - 2025-01-13 09:29:57 --> Router Class Initialized
INFO - 2025-01-13 09:29:57 --> Output Class Initialized
INFO - 2025-01-13 09:29:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:29:57 --> Input Class Initialized
INFO - 2025-01-13 09:29:57 --> Language Class Initialized
INFO - 2025-01-13 09:29:57 --> Loader Class Initialized
INFO - 2025-01-13 09:29:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:29:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:29:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:29:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:29:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:29:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:29:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:29:57 --> Upload Class Initialized
INFO - 2025-01-13 09:29:57 --> Email Class Initialized
INFO - 2025-01-13 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:29:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:29:57 --> Controller Class Initialized
INFO - 2025-01-13 14:59:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 14:59:57 --> Model "MainModel" initialized
INFO - 2025-01-13 14:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 14:59:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:30:57 --> Config Class Initialized
INFO - 2025-01-13 09:30:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:30:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:30:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:30:57 --> URI Class Initialized
INFO - 2025-01-13 09:30:57 --> Router Class Initialized
INFO - 2025-01-13 09:30:57 --> Output Class Initialized
INFO - 2025-01-13 09:30:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:30:57 --> Input Class Initialized
INFO - 2025-01-13 09:30:57 --> Language Class Initialized
INFO - 2025-01-13 09:30:57 --> Loader Class Initialized
INFO - 2025-01-13 09:30:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:30:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:30:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:30:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:30:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:30:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:30:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:30:57 --> Upload Class Initialized
INFO - 2025-01-13 09:30:57 --> Email Class Initialized
INFO - 2025-01-13 09:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:30:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:30:57 --> Controller Class Initialized
INFO - 2025-01-13 15:00:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:00:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:00:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:31:57 --> Config Class Initialized
INFO - 2025-01-13 09:31:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:31:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:31:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:31:57 --> URI Class Initialized
INFO - 2025-01-13 09:31:57 --> Router Class Initialized
INFO - 2025-01-13 09:31:57 --> Output Class Initialized
INFO - 2025-01-13 09:31:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:31:57 --> Input Class Initialized
INFO - 2025-01-13 09:31:57 --> Language Class Initialized
INFO - 2025-01-13 09:31:57 --> Loader Class Initialized
INFO - 2025-01-13 09:31:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:31:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:31:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:31:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:31:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:31:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:31:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:31:57 --> Upload Class Initialized
INFO - 2025-01-13 09:31:57 --> Email Class Initialized
INFO - 2025-01-13 09:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:31:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:31:57 --> Controller Class Initialized
INFO - 2025-01-13 15:01:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:01:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:01:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:32:57 --> Config Class Initialized
INFO - 2025-01-13 09:32:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:32:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:32:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:32:57 --> URI Class Initialized
INFO - 2025-01-13 09:32:57 --> Router Class Initialized
INFO - 2025-01-13 09:32:57 --> Output Class Initialized
INFO - 2025-01-13 09:32:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:32:57 --> Input Class Initialized
INFO - 2025-01-13 09:32:57 --> Language Class Initialized
INFO - 2025-01-13 09:32:57 --> Loader Class Initialized
INFO - 2025-01-13 09:32:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:32:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:32:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:32:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:32:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:32:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:32:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:32:57 --> Upload Class Initialized
INFO - 2025-01-13 09:32:57 --> Email Class Initialized
INFO - 2025-01-13 09:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:32:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:32:57 --> Controller Class Initialized
INFO - 2025-01-13 15:02:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:02:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:02:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:33:15 --> Config Class Initialized
INFO - 2025-01-13 09:33:15 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:33:15 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:33:15 --> Utf8 Class Initialized
INFO - 2025-01-13 09:33:15 --> URI Class Initialized
INFO - 2025-01-13 09:33:15 --> Router Class Initialized
INFO - 2025-01-13 09:33:15 --> Output Class Initialized
INFO - 2025-01-13 09:33:15 --> Security Class Initialized
DEBUG - 2025-01-13 09:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:33:15 --> Input Class Initialized
INFO - 2025-01-13 09:33:15 --> Language Class Initialized
INFO - 2025-01-13 09:33:15 --> Loader Class Initialized
INFO - 2025-01-13 09:33:15 --> Helper loaded: url_helper
INFO - 2025-01-13 09:33:15 --> Helper loaded: html_helper
INFO - 2025-01-13 09:33:15 --> Helper loaded: file_helper
INFO - 2025-01-13 09:33:15 --> Helper loaded: string_helper
INFO - 2025-01-13 09:33:15 --> Helper loaded: form_helper
INFO - 2025-01-13 09:33:15 --> Helper loaded: my_helper
INFO - 2025-01-13 09:33:15 --> Database Driver Class Initialized
INFO - 2025-01-13 09:33:15 --> Upload Class Initialized
INFO - 2025-01-13 09:33:15 --> Email Class Initialized
INFO - 2025-01-13 09:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:33:15 --> Form Validation Class Initialized
INFO - 2025-01-13 09:33:15 --> Controller Class Initialized
INFO - 2025-01-13 15:03:15 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:03:15 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:03:15 --> Model "MainModel" initialized
INFO - 2025-01-13 09:33:57 --> Config Class Initialized
INFO - 2025-01-13 09:33:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:33:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:33:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:33:57 --> URI Class Initialized
INFO - 2025-01-13 09:33:57 --> Router Class Initialized
INFO - 2025-01-13 09:33:57 --> Output Class Initialized
INFO - 2025-01-13 09:33:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:33:57 --> Input Class Initialized
INFO - 2025-01-13 09:33:57 --> Language Class Initialized
INFO - 2025-01-13 09:33:57 --> Loader Class Initialized
INFO - 2025-01-13 09:33:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:33:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:33:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:33:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:33:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:33:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:33:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:33:57 --> Upload Class Initialized
INFO - 2025-01-13 09:33:57 --> Email Class Initialized
INFO - 2025-01-13 09:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:33:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:33:57 --> Controller Class Initialized
INFO - 2025-01-13 15:03:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:03:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:03:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:34:10 --> Config Class Initialized
INFO - 2025-01-13 09:34:10 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:34:10 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:34:10 --> Utf8 Class Initialized
INFO - 2025-01-13 09:34:10 --> URI Class Initialized
INFO - 2025-01-13 09:34:10 --> Router Class Initialized
INFO - 2025-01-13 09:34:10 --> Output Class Initialized
INFO - 2025-01-13 09:34:10 --> Security Class Initialized
DEBUG - 2025-01-13 09:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:34:10 --> Input Class Initialized
INFO - 2025-01-13 09:34:10 --> Language Class Initialized
INFO - 2025-01-13 09:34:10 --> Loader Class Initialized
INFO - 2025-01-13 09:34:10 --> Helper loaded: url_helper
INFO - 2025-01-13 09:34:10 --> Helper loaded: html_helper
INFO - 2025-01-13 09:34:10 --> Helper loaded: file_helper
INFO - 2025-01-13 09:34:10 --> Helper loaded: string_helper
INFO - 2025-01-13 09:34:10 --> Helper loaded: form_helper
INFO - 2025-01-13 09:34:10 --> Helper loaded: my_helper
INFO - 2025-01-13 09:34:10 --> Database Driver Class Initialized
INFO - 2025-01-13 09:34:10 --> Upload Class Initialized
INFO - 2025-01-13 09:34:10 --> Email Class Initialized
INFO - 2025-01-13 09:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:34:10 --> Form Validation Class Initialized
INFO - 2025-01-13 09:34:10 --> Controller Class Initialized
INFO - 2025-01-13 15:04:10 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:04:10 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:04:10 --> Model "MainModel" initialized
INFO - 2025-01-13 09:34:57 --> Config Class Initialized
INFO - 2025-01-13 09:34:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:34:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:34:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:34:57 --> URI Class Initialized
INFO - 2025-01-13 09:34:57 --> Router Class Initialized
INFO - 2025-01-13 09:34:57 --> Output Class Initialized
INFO - 2025-01-13 09:34:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:34:57 --> Input Class Initialized
INFO - 2025-01-13 09:34:57 --> Language Class Initialized
INFO - 2025-01-13 09:34:57 --> Loader Class Initialized
INFO - 2025-01-13 09:34:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:34:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:34:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:34:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:34:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:34:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:34:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:34:57 --> Upload Class Initialized
INFO - 2025-01-13 09:34:57 --> Email Class Initialized
INFO - 2025-01-13 09:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:34:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:34:57 --> Controller Class Initialized
INFO - 2025-01-13 15:04:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:04:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:04:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:35:57 --> Config Class Initialized
INFO - 2025-01-13 09:35:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:35:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:35:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:35:57 --> URI Class Initialized
INFO - 2025-01-13 09:35:57 --> Router Class Initialized
INFO - 2025-01-13 09:35:57 --> Output Class Initialized
INFO - 2025-01-13 09:35:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:35:57 --> Input Class Initialized
INFO - 2025-01-13 09:35:57 --> Language Class Initialized
INFO - 2025-01-13 09:35:57 --> Loader Class Initialized
INFO - 2025-01-13 09:35:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:35:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:35:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:35:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:35:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:35:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:35:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:35:57 --> Upload Class Initialized
INFO - 2025-01-13 09:35:57 --> Email Class Initialized
INFO - 2025-01-13 09:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:35:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:35:57 --> Controller Class Initialized
INFO - 2025-01-13 15:05:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:05:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:05:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:36:57 --> Config Class Initialized
INFO - 2025-01-13 09:36:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:36:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:36:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:36:57 --> URI Class Initialized
INFO - 2025-01-13 09:36:57 --> Router Class Initialized
INFO - 2025-01-13 09:36:57 --> Output Class Initialized
INFO - 2025-01-13 09:36:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:36:57 --> Input Class Initialized
INFO - 2025-01-13 09:36:57 --> Language Class Initialized
INFO - 2025-01-13 09:36:57 --> Loader Class Initialized
INFO - 2025-01-13 09:36:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:36:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:36:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:36:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:36:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:36:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:36:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:36:57 --> Upload Class Initialized
INFO - 2025-01-13 09:36:57 --> Email Class Initialized
INFO - 2025-01-13 09:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:36:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:36:57 --> Controller Class Initialized
INFO - 2025-01-13 15:06:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:06:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:06:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:37:57 --> Config Class Initialized
INFO - 2025-01-13 09:37:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:37:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:37:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:37:57 --> URI Class Initialized
INFO - 2025-01-13 09:37:57 --> Router Class Initialized
INFO - 2025-01-13 09:37:57 --> Output Class Initialized
INFO - 2025-01-13 09:37:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:37:57 --> Input Class Initialized
INFO - 2025-01-13 09:37:57 --> Language Class Initialized
INFO - 2025-01-13 09:37:57 --> Loader Class Initialized
INFO - 2025-01-13 09:37:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:37:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:37:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:37:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:37:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:37:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:37:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:37:57 --> Upload Class Initialized
INFO - 2025-01-13 09:37:57 --> Email Class Initialized
INFO - 2025-01-13 09:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:37:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:37:57 --> Controller Class Initialized
INFO - 2025-01-13 15:07:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:07:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:07:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:38:57 --> Config Class Initialized
INFO - 2025-01-13 09:38:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:38:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:38:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:38:57 --> URI Class Initialized
INFO - 2025-01-13 09:38:57 --> Router Class Initialized
INFO - 2025-01-13 09:38:57 --> Output Class Initialized
INFO - 2025-01-13 09:38:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:38:57 --> Input Class Initialized
INFO - 2025-01-13 09:38:57 --> Language Class Initialized
INFO - 2025-01-13 09:38:57 --> Loader Class Initialized
INFO - 2025-01-13 09:38:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:38:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:38:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:38:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:38:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:38:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:38:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:38:57 --> Upload Class Initialized
INFO - 2025-01-13 09:38:57 --> Email Class Initialized
INFO - 2025-01-13 09:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:38:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:38:57 --> Controller Class Initialized
INFO - 2025-01-13 15:08:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:08:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:08:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:39:57 --> Config Class Initialized
INFO - 2025-01-13 09:39:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:39:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:39:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:39:57 --> URI Class Initialized
INFO - 2025-01-13 09:39:57 --> Router Class Initialized
INFO - 2025-01-13 09:39:57 --> Output Class Initialized
INFO - 2025-01-13 09:39:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:39:57 --> Input Class Initialized
INFO - 2025-01-13 09:39:57 --> Language Class Initialized
INFO - 2025-01-13 09:39:57 --> Loader Class Initialized
INFO - 2025-01-13 09:39:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:39:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:39:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:39:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:39:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:39:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:39:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:39:57 --> Upload Class Initialized
INFO - 2025-01-13 09:39:57 --> Email Class Initialized
INFO - 2025-01-13 09:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:39:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:39:57 --> Controller Class Initialized
INFO - 2025-01-13 15:09:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:09:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:09:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:40:57 --> Config Class Initialized
INFO - 2025-01-13 09:40:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:40:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:40:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:40:57 --> URI Class Initialized
INFO - 2025-01-13 09:40:57 --> Router Class Initialized
INFO - 2025-01-13 09:40:57 --> Output Class Initialized
INFO - 2025-01-13 09:40:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:40:57 --> Input Class Initialized
INFO - 2025-01-13 09:40:57 --> Language Class Initialized
INFO - 2025-01-13 09:40:57 --> Loader Class Initialized
INFO - 2025-01-13 09:40:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:40:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:40:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:40:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:40:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:40:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:40:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:40:57 --> Upload Class Initialized
INFO - 2025-01-13 09:40:57 --> Email Class Initialized
INFO - 2025-01-13 09:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:40:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:40:57 --> Controller Class Initialized
INFO - 2025-01-13 15:10:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:10:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:10:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:41:57 --> Config Class Initialized
INFO - 2025-01-13 09:41:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:41:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:41:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:41:57 --> URI Class Initialized
INFO - 2025-01-13 09:41:57 --> Router Class Initialized
INFO - 2025-01-13 09:41:57 --> Output Class Initialized
INFO - 2025-01-13 09:41:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:41:57 --> Input Class Initialized
INFO - 2025-01-13 09:41:57 --> Language Class Initialized
INFO - 2025-01-13 09:41:57 --> Loader Class Initialized
INFO - 2025-01-13 09:41:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:41:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:41:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:41:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:41:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:41:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:41:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:41:57 --> Upload Class Initialized
INFO - 2025-01-13 09:41:57 --> Email Class Initialized
INFO - 2025-01-13 09:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:41:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:41:57 --> Controller Class Initialized
INFO - 2025-01-13 15:11:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:11:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:11:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:42:54 --> Config Class Initialized
INFO - 2025-01-13 09:42:54 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:42:54 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:42:54 --> Utf8 Class Initialized
INFO - 2025-01-13 09:42:54 --> URI Class Initialized
INFO - 2025-01-13 09:42:54 --> Router Class Initialized
INFO - 2025-01-13 09:42:54 --> Output Class Initialized
INFO - 2025-01-13 09:42:54 --> Security Class Initialized
DEBUG - 2025-01-13 09:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:42:54 --> Input Class Initialized
INFO - 2025-01-13 09:42:54 --> Language Class Initialized
INFO - 2025-01-13 09:42:54 --> Loader Class Initialized
INFO - 2025-01-13 09:42:54 --> Helper loaded: url_helper
INFO - 2025-01-13 09:42:54 --> Helper loaded: html_helper
INFO - 2025-01-13 09:42:54 --> Helper loaded: file_helper
INFO - 2025-01-13 09:42:54 --> Helper loaded: string_helper
INFO - 2025-01-13 09:42:54 --> Helper loaded: form_helper
INFO - 2025-01-13 09:42:54 --> Helper loaded: my_helper
INFO - 2025-01-13 09:42:54 --> Database Driver Class Initialized
INFO - 2025-01-13 09:42:54 --> Upload Class Initialized
INFO - 2025-01-13 09:42:54 --> Email Class Initialized
INFO - 2025-01-13 09:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:42:54 --> Form Validation Class Initialized
INFO - 2025-01-13 09:42:54 --> Controller Class Initialized
INFO - 2025-01-13 15:12:54 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:12:54 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:12:54 --> Model "MainModel" initialized
INFO - 2025-01-13 09:42:57 --> Config Class Initialized
INFO - 2025-01-13 09:42:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:42:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:42:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:42:57 --> URI Class Initialized
INFO - 2025-01-13 09:42:57 --> Router Class Initialized
INFO - 2025-01-13 09:42:57 --> Output Class Initialized
INFO - 2025-01-13 09:42:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:42:57 --> Input Class Initialized
INFO - 2025-01-13 09:42:57 --> Language Class Initialized
INFO - 2025-01-13 09:42:57 --> Loader Class Initialized
INFO - 2025-01-13 09:42:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:42:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:42:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:42:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:42:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:42:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:42:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:42:57 --> Upload Class Initialized
INFO - 2025-01-13 09:42:57 --> Email Class Initialized
INFO - 2025-01-13 09:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:42:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:42:57 --> Controller Class Initialized
INFO - 2025-01-13 15:12:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:12:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:12:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:43:57 --> Config Class Initialized
INFO - 2025-01-13 09:43:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:43:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:43:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:43:57 --> URI Class Initialized
INFO - 2025-01-13 09:43:57 --> Router Class Initialized
INFO - 2025-01-13 09:43:57 --> Output Class Initialized
INFO - 2025-01-13 09:43:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:43:57 --> Input Class Initialized
INFO - 2025-01-13 09:43:57 --> Language Class Initialized
INFO - 2025-01-13 09:43:57 --> Loader Class Initialized
INFO - 2025-01-13 09:43:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:43:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:43:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:43:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:43:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:43:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:43:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:43:57 --> Upload Class Initialized
INFO - 2025-01-13 09:43:57 --> Email Class Initialized
INFO - 2025-01-13 09:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:43:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:43:57 --> Controller Class Initialized
INFO - 2025-01-13 15:13:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:13:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:13:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:44:57 --> Config Class Initialized
INFO - 2025-01-13 09:44:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:44:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:44:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:44:57 --> URI Class Initialized
INFO - 2025-01-13 09:44:57 --> Router Class Initialized
INFO - 2025-01-13 09:44:57 --> Output Class Initialized
INFO - 2025-01-13 09:44:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:44:57 --> Input Class Initialized
INFO - 2025-01-13 09:44:57 --> Language Class Initialized
INFO - 2025-01-13 09:44:57 --> Loader Class Initialized
INFO - 2025-01-13 09:44:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:44:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:44:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:44:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:44:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:44:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:44:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:44:57 --> Upload Class Initialized
INFO - 2025-01-13 09:44:57 --> Email Class Initialized
INFO - 2025-01-13 09:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:44:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:44:57 --> Controller Class Initialized
INFO - 2025-01-13 15:14:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:14:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:14:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:45:57 --> Config Class Initialized
INFO - 2025-01-13 09:45:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:45:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:45:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:45:57 --> URI Class Initialized
INFO - 2025-01-13 09:45:57 --> Router Class Initialized
INFO - 2025-01-13 09:45:57 --> Output Class Initialized
INFO - 2025-01-13 09:45:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:45:57 --> Input Class Initialized
INFO - 2025-01-13 09:45:57 --> Language Class Initialized
INFO - 2025-01-13 09:45:57 --> Loader Class Initialized
INFO - 2025-01-13 09:45:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:45:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:45:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:45:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:45:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:45:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:45:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:45:57 --> Upload Class Initialized
INFO - 2025-01-13 09:45:57 --> Email Class Initialized
INFO - 2025-01-13 09:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:45:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:45:57 --> Controller Class Initialized
INFO - 2025-01-13 15:15:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:15:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:15:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:46:57 --> Config Class Initialized
INFO - 2025-01-13 09:46:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:46:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:46:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:46:57 --> URI Class Initialized
INFO - 2025-01-13 09:46:57 --> Router Class Initialized
INFO - 2025-01-13 09:46:57 --> Output Class Initialized
INFO - 2025-01-13 09:46:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:46:57 --> Input Class Initialized
INFO - 2025-01-13 09:46:57 --> Language Class Initialized
INFO - 2025-01-13 09:46:57 --> Loader Class Initialized
INFO - 2025-01-13 09:46:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:46:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:46:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:46:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:46:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:46:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:46:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:46:57 --> Upload Class Initialized
INFO - 2025-01-13 09:46:57 --> Email Class Initialized
INFO - 2025-01-13 09:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:46:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:46:57 --> Controller Class Initialized
INFO - 2025-01-13 15:16:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:16:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:16:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:47:57 --> Config Class Initialized
INFO - 2025-01-13 09:47:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:47:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:47:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:47:57 --> URI Class Initialized
INFO - 2025-01-13 09:47:57 --> Router Class Initialized
INFO - 2025-01-13 09:47:57 --> Output Class Initialized
INFO - 2025-01-13 09:47:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:47:57 --> Input Class Initialized
INFO - 2025-01-13 09:47:57 --> Language Class Initialized
INFO - 2025-01-13 09:47:57 --> Loader Class Initialized
INFO - 2025-01-13 09:47:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:47:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:47:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:47:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:47:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:47:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:47:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:47:57 --> Upload Class Initialized
INFO - 2025-01-13 09:47:57 --> Email Class Initialized
INFO - 2025-01-13 09:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:47:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:47:57 --> Controller Class Initialized
INFO - 2025-01-13 15:17:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:17:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:17:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:48:57 --> Config Class Initialized
INFO - 2025-01-13 09:48:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:48:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:48:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:48:57 --> URI Class Initialized
INFO - 2025-01-13 09:48:57 --> Router Class Initialized
INFO - 2025-01-13 09:48:57 --> Output Class Initialized
INFO - 2025-01-13 09:48:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:48:57 --> Input Class Initialized
INFO - 2025-01-13 09:48:57 --> Language Class Initialized
INFO - 2025-01-13 09:48:57 --> Loader Class Initialized
INFO - 2025-01-13 09:48:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:48:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:48:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:48:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:48:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:48:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:48:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:48:57 --> Upload Class Initialized
INFO - 2025-01-13 09:48:57 --> Email Class Initialized
INFO - 2025-01-13 09:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:48:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:48:57 --> Controller Class Initialized
INFO - 2025-01-13 15:18:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:18:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:18:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:49:43 --> Config Class Initialized
INFO - 2025-01-13 09:49:43 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:49:43 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:49:43 --> Utf8 Class Initialized
INFO - 2025-01-13 09:49:43 --> URI Class Initialized
INFO - 2025-01-13 09:49:43 --> Router Class Initialized
INFO - 2025-01-13 09:49:43 --> Output Class Initialized
INFO - 2025-01-13 09:49:43 --> Security Class Initialized
DEBUG - 2025-01-13 09:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:49:43 --> Input Class Initialized
INFO - 2025-01-13 09:49:43 --> Language Class Initialized
INFO - 2025-01-13 09:49:43 --> Loader Class Initialized
INFO - 2025-01-13 09:49:43 --> Helper loaded: url_helper
INFO - 2025-01-13 09:49:43 --> Helper loaded: html_helper
INFO - 2025-01-13 09:49:43 --> Helper loaded: file_helper
INFO - 2025-01-13 09:49:43 --> Helper loaded: string_helper
INFO - 2025-01-13 09:49:43 --> Helper loaded: form_helper
INFO - 2025-01-13 09:49:43 --> Helper loaded: my_helper
INFO - 2025-01-13 09:49:43 --> Database Driver Class Initialized
INFO - 2025-01-13 09:49:43 --> Upload Class Initialized
INFO - 2025-01-13 09:49:43 --> Email Class Initialized
INFO - 2025-01-13 09:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:49:43 --> Form Validation Class Initialized
INFO - 2025-01-13 09:49:43 --> Controller Class Initialized
INFO - 2025-01-13 15:19:43 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:19:43 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:19:43 --> Model "MainModel" initialized
INFO - 2025-01-13 09:49:57 --> Config Class Initialized
INFO - 2025-01-13 09:49:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:49:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:49:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:49:57 --> URI Class Initialized
INFO - 2025-01-13 09:49:57 --> Router Class Initialized
INFO - 2025-01-13 09:49:57 --> Output Class Initialized
INFO - 2025-01-13 09:49:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:49:57 --> Input Class Initialized
INFO - 2025-01-13 09:49:57 --> Language Class Initialized
INFO - 2025-01-13 09:49:57 --> Loader Class Initialized
INFO - 2025-01-13 09:49:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:49:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:49:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:49:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:49:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:49:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:49:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:49:57 --> Upload Class Initialized
INFO - 2025-01-13 09:49:57 --> Email Class Initialized
INFO - 2025-01-13 09:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:49:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:49:57 --> Controller Class Initialized
INFO - 2025-01-13 15:19:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:19:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:19:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:50:57 --> Config Class Initialized
INFO - 2025-01-13 09:50:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:50:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:50:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:50:57 --> URI Class Initialized
INFO - 2025-01-13 09:50:57 --> Router Class Initialized
INFO - 2025-01-13 09:50:57 --> Output Class Initialized
INFO - 2025-01-13 09:50:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:50:57 --> Input Class Initialized
INFO - 2025-01-13 09:50:57 --> Language Class Initialized
INFO - 2025-01-13 09:50:57 --> Loader Class Initialized
INFO - 2025-01-13 09:50:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:50:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:50:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:50:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:50:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:50:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:50:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:50:57 --> Upload Class Initialized
INFO - 2025-01-13 09:50:57 --> Email Class Initialized
INFO - 2025-01-13 09:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:50:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:50:57 --> Controller Class Initialized
INFO - 2025-01-13 15:20:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:20:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:20:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:51:57 --> Config Class Initialized
INFO - 2025-01-13 09:51:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:51:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:51:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:51:57 --> URI Class Initialized
INFO - 2025-01-13 09:51:57 --> Router Class Initialized
INFO - 2025-01-13 09:51:57 --> Output Class Initialized
INFO - 2025-01-13 09:51:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:51:57 --> Input Class Initialized
INFO - 2025-01-13 09:51:57 --> Language Class Initialized
INFO - 2025-01-13 09:51:57 --> Loader Class Initialized
INFO - 2025-01-13 09:51:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:51:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:51:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:51:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:51:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:51:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:51:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:51:57 --> Upload Class Initialized
INFO - 2025-01-13 09:51:57 --> Email Class Initialized
INFO - 2025-01-13 09:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:51:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:51:57 --> Controller Class Initialized
INFO - 2025-01-13 15:21:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:21:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:21:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:52:57 --> Config Class Initialized
INFO - 2025-01-13 09:52:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:52:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:52:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:52:57 --> URI Class Initialized
INFO - 2025-01-13 09:52:57 --> Router Class Initialized
INFO - 2025-01-13 09:52:57 --> Output Class Initialized
INFO - 2025-01-13 09:52:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:52:57 --> Input Class Initialized
INFO - 2025-01-13 09:52:57 --> Language Class Initialized
INFO - 2025-01-13 09:52:57 --> Loader Class Initialized
INFO - 2025-01-13 09:52:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:52:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:52:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:52:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:52:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:52:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:52:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:52:57 --> Upload Class Initialized
INFO - 2025-01-13 09:52:57 --> Email Class Initialized
INFO - 2025-01-13 09:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:52:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:52:57 --> Controller Class Initialized
INFO - 2025-01-13 15:22:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:22:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:22:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:53:12 --> Config Class Initialized
INFO - 2025-01-13 09:53:12 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:53:12 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:53:12 --> Utf8 Class Initialized
INFO - 2025-01-13 09:53:12 --> URI Class Initialized
INFO - 2025-01-13 09:53:12 --> Router Class Initialized
INFO - 2025-01-13 09:53:12 --> Output Class Initialized
INFO - 2025-01-13 09:53:12 --> Security Class Initialized
DEBUG - 2025-01-13 09:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:53:12 --> Input Class Initialized
INFO - 2025-01-13 09:53:12 --> Language Class Initialized
INFO - 2025-01-13 09:53:12 --> Loader Class Initialized
INFO - 2025-01-13 09:53:12 --> Helper loaded: url_helper
INFO - 2025-01-13 09:53:12 --> Helper loaded: html_helper
INFO - 2025-01-13 09:53:12 --> Helper loaded: file_helper
INFO - 2025-01-13 09:53:12 --> Helper loaded: string_helper
INFO - 2025-01-13 09:53:12 --> Helper loaded: form_helper
INFO - 2025-01-13 09:53:12 --> Helper loaded: my_helper
INFO - 2025-01-13 09:53:12 --> Database Driver Class Initialized
INFO - 2025-01-13 09:53:12 --> Upload Class Initialized
INFO - 2025-01-13 09:53:12 --> Email Class Initialized
INFO - 2025-01-13 09:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:53:12 --> Form Validation Class Initialized
INFO - 2025-01-13 09:53:12 --> Controller Class Initialized
INFO - 2025-01-13 15:23:12 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:23:12 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:23:12 --> Model "MainModel" initialized
INFO - 2025-01-13 09:53:57 --> Config Class Initialized
INFO - 2025-01-13 09:53:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:53:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:53:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:53:57 --> URI Class Initialized
INFO - 2025-01-13 09:53:57 --> Router Class Initialized
INFO - 2025-01-13 09:53:57 --> Output Class Initialized
INFO - 2025-01-13 09:53:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:53:57 --> Input Class Initialized
INFO - 2025-01-13 09:53:57 --> Language Class Initialized
INFO - 2025-01-13 09:53:57 --> Loader Class Initialized
INFO - 2025-01-13 09:53:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:53:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:53:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:53:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:53:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:53:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:53:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:53:57 --> Upload Class Initialized
INFO - 2025-01-13 09:53:57 --> Email Class Initialized
INFO - 2025-01-13 09:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:53:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:53:57 --> Controller Class Initialized
INFO - 2025-01-13 15:23:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:23:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:23:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:54:57 --> Config Class Initialized
INFO - 2025-01-13 09:54:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:54:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:54:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:54:57 --> URI Class Initialized
INFO - 2025-01-13 09:54:57 --> Router Class Initialized
INFO - 2025-01-13 09:54:57 --> Output Class Initialized
INFO - 2025-01-13 09:54:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:54:57 --> Input Class Initialized
INFO - 2025-01-13 09:54:57 --> Language Class Initialized
INFO - 2025-01-13 09:54:57 --> Loader Class Initialized
INFO - 2025-01-13 09:54:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:54:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:54:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:54:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:54:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:54:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:54:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:54:57 --> Upload Class Initialized
INFO - 2025-01-13 09:54:57 --> Email Class Initialized
INFO - 2025-01-13 09:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:54:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:54:57 --> Controller Class Initialized
INFO - 2025-01-13 15:24:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:24:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:24:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:55:57 --> Config Class Initialized
INFO - 2025-01-13 09:55:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:55:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:55:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:55:57 --> URI Class Initialized
INFO - 2025-01-13 09:55:57 --> Router Class Initialized
INFO - 2025-01-13 09:55:57 --> Output Class Initialized
INFO - 2025-01-13 09:55:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:55:57 --> Input Class Initialized
INFO - 2025-01-13 09:55:57 --> Language Class Initialized
INFO - 2025-01-13 09:55:57 --> Loader Class Initialized
INFO - 2025-01-13 09:55:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:55:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:55:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:55:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:55:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:55:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:55:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:55:57 --> Upload Class Initialized
INFO - 2025-01-13 09:55:57 --> Email Class Initialized
INFO - 2025-01-13 09:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:55:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:55:57 --> Controller Class Initialized
INFO - 2025-01-13 15:25:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:25:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:25:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:56:57 --> Config Class Initialized
INFO - 2025-01-13 09:56:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:56:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:56:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:56:57 --> URI Class Initialized
INFO - 2025-01-13 09:56:57 --> Router Class Initialized
INFO - 2025-01-13 09:56:57 --> Output Class Initialized
INFO - 2025-01-13 09:56:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:56:57 --> Input Class Initialized
INFO - 2025-01-13 09:56:57 --> Language Class Initialized
INFO - 2025-01-13 09:56:57 --> Loader Class Initialized
INFO - 2025-01-13 09:56:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:56:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:56:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:56:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:56:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:56:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:56:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:56:57 --> Upload Class Initialized
INFO - 2025-01-13 09:56:57 --> Email Class Initialized
INFO - 2025-01-13 09:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:56:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:56:57 --> Controller Class Initialized
INFO - 2025-01-13 15:26:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:26:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:26:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:57:57 --> Config Class Initialized
INFO - 2025-01-13 09:57:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:57:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:57:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:57:57 --> URI Class Initialized
INFO - 2025-01-13 09:57:57 --> Router Class Initialized
INFO - 2025-01-13 09:57:57 --> Output Class Initialized
INFO - 2025-01-13 09:57:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:57:57 --> Input Class Initialized
INFO - 2025-01-13 09:57:57 --> Language Class Initialized
INFO - 2025-01-13 09:57:57 --> Loader Class Initialized
INFO - 2025-01-13 09:57:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:57:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:57:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:57:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:57:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:57:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:57:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:57:57 --> Upload Class Initialized
INFO - 2025-01-13 09:57:57 --> Email Class Initialized
INFO - 2025-01-13 09:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:57:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:57:57 --> Controller Class Initialized
INFO - 2025-01-13 15:27:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:27:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:27:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:58:57 --> Config Class Initialized
INFO - 2025-01-13 09:58:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:58:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:58:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:58:57 --> URI Class Initialized
INFO - 2025-01-13 09:58:57 --> Router Class Initialized
INFO - 2025-01-13 09:58:57 --> Output Class Initialized
INFO - 2025-01-13 09:58:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:58:57 --> Input Class Initialized
INFO - 2025-01-13 09:58:57 --> Language Class Initialized
INFO - 2025-01-13 09:58:57 --> Loader Class Initialized
INFO - 2025-01-13 09:58:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:58:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:58:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:58:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:58:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:58:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:58:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:58:57 --> Upload Class Initialized
INFO - 2025-01-13 09:58:57 --> Email Class Initialized
INFO - 2025-01-13 09:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:58:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:58:57 --> Controller Class Initialized
INFO - 2025-01-13 15:28:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:28:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:28:57 --> Pagination Class Initialized
INFO - 2025-01-13 09:59:57 --> Config Class Initialized
INFO - 2025-01-13 09:59:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 09:59:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 09:59:57 --> Utf8 Class Initialized
INFO - 2025-01-13 09:59:57 --> URI Class Initialized
INFO - 2025-01-13 09:59:57 --> Router Class Initialized
INFO - 2025-01-13 09:59:57 --> Output Class Initialized
INFO - 2025-01-13 09:59:57 --> Security Class Initialized
DEBUG - 2025-01-13 09:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 09:59:57 --> Input Class Initialized
INFO - 2025-01-13 09:59:57 --> Language Class Initialized
INFO - 2025-01-13 09:59:57 --> Loader Class Initialized
INFO - 2025-01-13 09:59:57 --> Helper loaded: url_helper
INFO - 2025-01-13 09:59:57 --> Helper loaded: html_helper
INFO - 2025-01-13 09:59:57 --> Helper loaded: file_helper
INFO - 2025-01-13 09:59:57 --> Helper loaded: string_helper
INFO - 2025-01-13 09:59:57 --> Helper loaded: form_helper
INFO - 2025-01-13 09:59:57 --> Helper loaded: my_helper
INFO - 2025-01-13 09:59:57 --> Database Driver Class Initialized
INFO - 2025-01-13 09:59:57 --> Upload Class Initialized
INFO - 2025-01-13 09:59:57 --> Email Class Initialized
INFO - 2025-01-13 09:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 09:59:57 --> Form Validation Class Initialized
INFO - 2025-01-13 09:59:57 --> Controller Class Initialized
INFO - 2025-01-13 15:29:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:29:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:29:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:00:57 --> Config Class Initialized
INFO - 2025-01-13 10:00:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:00:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:00:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:00:57 --> URI Class Initialized
INFO - 2025-01-13 10:00:57 --> Router Class Initialized
INFO - 2025-01-13 10:00:57 --> Output Class Initialized
INFO - 2025-01-13 10:00:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:00:57 --> Input Class Initialized
INFO - 2025-01-13 10:00:57 --> Language Class Initialized
INFO - 2025-01-13 10:00:57 --> Loader Class Initialized
INFO - 2025-01-13 10:00:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:00:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:00:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:00:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:00:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:00:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:00:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:00:57 --> Upload Class Initialized
INFO - 2025-01-13 10:00:57 --> Email Class Initialized
INFO - 2025-01-13 10:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:00:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:00:57 --> Controller Class Initialized
INFO - 2025-01-13 15:30:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:30:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:30:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:01:57 --> Config Class Initialized
INFO - 2025-01-13 10:01:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:01:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:01:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:01:57 --> URI Class Initialized
INFO - 2025-01-13 10:01:57 --> Router Class Initialized
INFO - 2025-01-13 10:01:57 --> Output Class Initialized
INFO - 2025-01-13 10:01:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:01:57 --> Input Class Initialized
INFO - 2025-01-13 10:01:57 --> Language Class Initialized
INFO - 2025-01-13 10:01:57 --> Loader Class Initialized
INFO - 2025-01-13 10:01:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:01:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:01:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:01:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:01:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:01:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:01:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:01:57 --> Upload Class Initialized
INFO - 2025-01-13 10:01:57 --> Email Class Initialized
INFO - 2025-01-13 10:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:01:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:01:57 --> Controller Class Initialized
INFO - 2025-01-13 15:31:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:31:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:31:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:02:57 --> Config Class Initialized
INFO - 2025-01-13 10:02:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:02:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:02:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:02:57 --> URI Class Initialized
INFO - 2025-01-13 10:02:57 --> Router Class Initialized
INFO - 2025-01-13 10:02:57 --> Output Class Initialized
INFO - 2025-01-13 10:02:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:02:57 --> Input Class Initialized
INFO - 2025-01-13 10:02:57 --> Language Class Initialized
INFO - 2025-01-13 10:02:57 --> Loader Class Initialized
INFO - 2025-01-13 10:02:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:02:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:02:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:02:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:02:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:02:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:02:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:02:57 --> Upload Class Initialized
INFO - 2025-01-13 10:02:57 --> Email Class Initialized
INFO - 2025-01-13 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:02:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:02:57 --> Controller Class Initialized
INFO - 2025-01-13 15:32:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:32:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:32:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:03:23 --> Config Class Initialized
INFO - 2025-01-13 10:03:23 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:03:23 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:03:23 --> Utf8 Class Initialized
INFO - 2025-01-13 10:03:23 --> URI Class Initialized
INFO - 2025-01-13 10:03:23 --> Router Class Initialized
INFO - 2025-01-13 10:03:23 --> Output Class Initialized
INFO - 2025-01-13 10:03:23 --> Security Class Initialized
DEBUG - 2025-01-13 10:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:03:23 --> Input Class Initialized
INFO - 2025-01-13 10:03:23 --> Language Class Initialized
INFO - 2025-01-13 10:03:23 --> Loader Class Initialized
INFO - 2025-01-13 10:03:23 --> Helper loaded: url_helper
INFO - 2025-01-13 10:03:23 --> Helper loaded: html_helper
INFO - 2025-01-13 10:03:23 --> Helper loaded: file_helper
INFO - 2025-01-13 10:03:23 --> Helper loaded: string_helper
INFO - 2025-01-13 10:03:23 --> Helper loaded: form_helper
INFO - 2025-01-13 10:03:23 --> Helper loaded: my_helper
INFO - 2025-01-13 10:03:23 --> Database Driver Class Initialized
INFO - 2025-01-13 10:03:23 --> Upload Class Initialized
INFO - 2025-01-13 10:03:23 --> Email Class Initialized
INFO - 2025-01-13 10:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:03:23 --> Form Validation Class Initialized
INFO - 2025-01-13 10:03:23 --> Controller Class Initialized
INFO - 2025-01-13 15:33:23 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:33:23 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:33:23 --> Model "MainModel" initialized
INFO - 2025-01-13 10:03:57 --> Config Class Initialized
INFO - 2025-01-13 10:03:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:03:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:03:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:03:57 --> URI Class Initialized
INFO - 2025-01-13 10:03:57 --> Router Class Initialized
INFO - 2025-01-13 10:03:57 --> Output Class Initialized
INFO - 2025-01-13 10:03:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:03:57 --> Input Class Initialized
INFO - 2025-01-13 10:03:57 --> Language Class Initialized
INFO - 2025-01-13 10:03:57 --> Loader Class Initialized
INFO - 2025-01-13 10:03:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:03:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:03:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:03:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:03:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:03:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:03:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:03:57 --> Upload Class Initialized
INFO - 2025-01-13 10:03:57 --> Email Class Initialized
INFO - 2025-01-13 10:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:03:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:03:57 --> Controller Class Initialized
INFO - 2025-01-13 15:33:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:33:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:33:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:04:57 --> Config Class Initialized
INFO - 2025-01-13 10:04:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:04:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:04:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:04:57 --> URI Class Initialized
INFO - 2025-01-13 10:04:57 --> Router Class Initialized
INFO - 2025-01-13 10:04:57 --> Output Class Initialized
INFO - 2025-01-13 10:04:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:04:57 --> Input Class Initialized
INFO - 2025-01-13 10:04:57 --> Language Class Initialized
INFO - 2025-01-13 10:04:57 --> Loader Class Initialized
INFO - 2025-01-13 10:04:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:04:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:04:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:04:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:04:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:04:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:04:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:04:57 --> Upload Class Initialized
INFO - 2025-01-13 10:04:57 --> Email Class Initialized
INFO - 2025-01-13 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:04:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:04:57 --> Controller Class Initialized
INFO - 2025-01-13 15:34:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:34:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:34:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:05:35 --> Config Class Initialized
INFO - 2025-01-13 10:05:35 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:05:35 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:05:35 --> Utf8 Class Initialized
INFO - 2025-01-13 10:05:35 --> URI Class Initialized
INFO - 2025-01-13 10:05:35 --> Router Class Initialized
INFO - 2025-01-13 10:05:35 --> Output Class Initialized
INFO - 2025-01-13 10:05:35 --> Security Class Initialized
DEBUG - 2025-01-13 10:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:05:35 --> Input Class Initialized
INFO - 2025-01-13 10:05:35 --> Language Class Initialized
INFO - 2025-01-13 10:05:35 --> Loader Class Initialized
INFO - 2025-01-13 10:05:35 --> Helper loaded: url_helper
INFO - 2025-01-13 10:05:35 --> Helper loaded: html_helper
INFO - 2025-01-13 10:05:35 --> Helper loaded: file_helper
INFO - 2025-01-13 10:05:35 --> Helper loaded: string_helper
INFO - 2025-01-13 10:05:35 --> Helper loaded: form_helper
INFO - 2025-01-13 10:05:35 --> Helper loaded: my_helper
INFO - 2025-01-13 10:05:35 --> Database Driver Class Initialized
INFO - 2025-01-13 10:05:35 --> Upload Class Initialized
INFO - 2025-01-13 10:05:35 --> Email Class Initialized
INFO - 2025-01-13 10:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:05:35 --> Form Validation Class Initialized
INFO - 2025-01-13 10:05:35 --> Controller Class Initialized
INFO - 2025-01-13 15:35:35 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:35:35 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:35:35 --> Model "MainModel" initialized
INFO - 2025-01-13 10:05:36 --> Config Class Initialized
INFO - 2025-01-13 10:05:36 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:05:36 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:05:36 --> Utf8 Class Initialized
INFO - 2025-01-13 10:05:36 --> URI Class Initialized
INFO - 2025-01-13 10:05:36 --> Router Class Initialized
INFO - 2025-01-13 10:05:36 --> Output Class Initialized
INFO - 2025-01-13 10:05:36 --> Security Class Initialized
DEBUG - 2025-01-13 10:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:05:36 --> Input Class Initialized
INFO - 2025-01-13 10:05:36 --> Language Class Initialized
INFO - 2025-01-13 10:05:36 --> Loader Class Initialized
INFO - 2025-01-13 10:05:36 --> Helper loaded: url_helper
INFO - 2025-01-13 10:05:36 --> Helper loaded: html_helper
INFO - 2025-01-13 10:05:36 --> Helper loaded: file_helper
INFO - 2025-01-13 10:05:36 --> Helper loaded: string_helper
INFO - 2025-01-13 10:05:36 --> Helper loaded: form_helper
INFO - 2025-01-13 10:05:36 --> Helper loaded: my_helper
INFO - 2025-01-13 10:05:36 --> Database Driver Class Initialized
INFO - 2025-01-13 10:05:36 --> Upload Class Initialized
INFO - 2025-01-13 10:05:36 --> Email Class Initialized
INFO - 2025-01-13 10:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:05:36 --> Form Validation Class Initialized
INFO - 2025-01-13 10:05:36 --> Controller Class Initialized
INFO - 2025-01-13 15:35:36 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:35:36 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:35:36 --> Model "MainModel" initialized
INFO - 2025-01-13 10:05:57 --> Config Class Initialized
INFO - 2025-01-13 10:05:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:05:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:05:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:05:57 --> URI Class Initialized
INFO - 2025-01-13 10:05:57 --> Router Class Initialized
INFO - 2025-01-13 10:05:57 --> Output Class Initialized
INFO - 2025-01-13 10:05:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:05:57 --> Input Class Initialized
INFO - 2025-01-13 10:05:57 --> Language Class Initialized
INFO - 2025-01-13 10:05:57 --> Loader Class Initialized
INFO - 2025-01-13 10:05:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:05:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:05:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:05:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:05:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:05:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:05:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:05:57 --> Upload Class Initialized
INFO - 2025-01-13 10:05:57 --> Email Class Initialized
INFO - 2025-01-13 10:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:05:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:05:57 --> Controller Class Initialized
INFO - 2025-01-13 15:35:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:35:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:35:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:06:57 --> Config Class Initialized
INFO - 2025-01-13 10:06:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:06:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:06:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:06:57 --> URI Class Initialized
INFO - 2025-01-13 10:06:57 --> Router Class Initialized
INFO - 2025-01-13 10:06:57 --> Output Class Initialized
INFO - 2025-01-13 10:06:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:06:57 --> Input Class Initialized
INFO - 2025-01-13 10:06:57 --> Language Class Initialized
INFO - 2025-01-13 10:06:57 --> Loader Class Initialized
INFO - 2025-01-13 10:06:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:06:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:06:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:06:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:06:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:06:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:06:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:06:57 --> Upload Class Initialized
INFO - 2025-01-13 10:06:57 --> Email Class Initialized
INFO - 2025-01-13 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:06:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:06:57 --> Controller Class Initialized
INFO - 2025-01-13 15:36:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:36:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:36:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:07:57 --> Config Class Initialized
INFO - 2025-01-13 10:07:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:07:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:07:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:07:57 --> URI Class Initialized
INFO - 2025-01-13 10:07:57 --> Router Class Initialized
INFO - 2025-01-13 10:07:57 --> Output Class Initialized
INFO - 2025-01-13 10:07:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:07:57 --> Input Class Initialized
INFO - 2025-01-13 10:07:57 --> Language Class Initialized
INFO - 2025-01-13 10:07:57 --> Loader Class Initialized
INFO - 2025-01-13 10:07:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:07:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:07:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:07:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:07:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:07:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:07:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:07:57 --> Upload Class Initialized
INFO - 2025-01-13 10:07:57 --> Email Class Initialized
INFO - 2025-01-13 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:07:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:07:57 --> Controller Class Initialized
INFO - 2025-01-13 15:37:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:37:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:37:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:08:57 --> Config Class Initialized
INFO - 2025-01-13 10:08:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:08:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:08:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:08:57 --> URI Class Initialized
INFO - 2025-01-13 10:08:57 --> Router Class Initialized
INFO - 2025-01-13 10:08:57 --> Output Class Initialized
INFO - 2025-01-13 10:08:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:08:57 --> Input Class Initialized
INFO - 2025-01-13 10:08:57 --> Language Class Initialized
INFO - 2025-01-13 10:08:57 --> Loader Class Initialized
INFO - 2025-01-13 10:08:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:08:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:08:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:08:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:08:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:08:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:08:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:08:57 --> Upload Class Initialized
INFO - 2025-01-13 10:08:57 --> Email Class Initialized
INFO - 2025-01-13 10:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:08:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:08:57 --> Controller Class Initialized
INFO - 2025-01-13 15:38:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:38:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:38:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:09:57 --> Config Class Initialized
INFO - 2025-01-13 10:09:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:09:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:09:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:09:57 --> URI Class Initialized
INFO - 2025-01-13 10:09:57 --> Router Class Initialized
INFO - 2025-01-13 10:09:57 --> Output Class Initialized
INFO - 2025-01-13 10:09:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:09:57 --> Input Class Initialized
INFO - 2025-01-13 10:09:57 --> Language Class Initialized
INFO - 2025-01-13 10:09:57 --> Loader Class Initialized
INFO - 2025-01-13 10:09:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:09:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:09:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:09:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:09:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:09:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:09:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:09:57 --> Upload Class Initialized
INFO - 2025-01-13 10:09:57 --> Email Class Initialized
INFO - 2025-01-13 10:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:09:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:09:57 --> Controller Class Initialized
INFO - 2025-01-13 15:39:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:39:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:39:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:39:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:10:19 --> Config Class Initialized
INFO - 2025-01-13 10:10:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:10:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:10:19 --> Utf8 Class Initialized
INFO - 2025-01-13 10:10:19 --> URI Class Initialized
INFO - 2025-01-13 10:10:19 --> Router Class Initialized
INFO - 2025-01-13 10:10:19 --> Output Class Initialized
INFO - 2025-01-13 10:10:19 --> Security Class Initialized
DEBUG - 2025-01-13 10:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:10:19 --> Input Class Initialized
INFO - 2025-01-13 10:10:19 --> Language Class Initialized
INFO - 2025-01-13 10:10:19 --> Loader Class Initialized
INFO - 2025-01-13 10:10:19 --> Helper loaded: url_helper
INFO - 2025-01-13 10:10:19 --> Helper loaded: html_helper
INFO - 2025-01-13 10:10:19 --> Helper loaded: file_helper
INFO - 2025-01-13 10:10:19 --> Helper loaded: string_helper
INFO - 2025-01-13 10:10:19 --> Helper loaded: form_helper
INFO - 2025-01-13 10:10:19 --> Helper loaded: my_helper
INFO - 2025-01-13 10:10:19 --> Database Driver Class Initialized
INFO - 2025-01-13 10:10:19 --> Upload Class Initialized
INFO - 2025-01-13 10:10:19 --> Email Class Initialized
INFO - 2025-01-13 10:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:10:19 --> Form Validation Class Initialized
INFO - 2025-01-13 10:10:19 --> Controller Class Initialized
INFO - 2025-01-13 15:40:19 --> Model "ApiModel" initialized
INFO - 2025-01-13 15:40:19 --> Helper loaded: notification_helper
INFO - 2025-01-13 15:40:19 --> Model "MainModel" initialized
INFO - 2025-01-13 10:10:57 --> Config Class Initialized
INFO - 2025-01-13 10:10:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:10:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:10:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:10:57 --> URI Class Initialized
INFO - 2025-01-13 10:10:57 --> Router Class Initialized
INFO - 2025-01-13 10:10:57 --> Output Class Initialized
INFO - 2025-01-13 10:10:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:10:57 --> Input Class Initialized
INFO - 2025-01-13 10:10:57 --> Language Class Initialized
INFO - 2025-01-13 10:10:57 --> Loader Class Initialized
INFO - 2025-01-13 10:10:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:10:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:10:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:10:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:10:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:10:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:10:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:10:57 --> Upload Class Initialized
INFO - 2025-01-13 10:10:57 --> Email Class Initialized
INFO - 2025-01-13 10:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:10:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:10:57 --> Controller Class Initialized
INFO - 2025-01-13 15:40:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:40:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:40:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:11:57 --> Config Class Initialized
INFO - 2025-01-13 10:11:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:11:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:11:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:11:57 --> URI Class Initialized
INFO - 2025-01-13 10:11:57 --> Router Class Initialized
INFO - 2025-01-13 10:11:57 --> Output Class Initialized
INFO - 2025-01-13 10:11:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:11:57 --> Input Class Initialized
INFO - 2025-01-13 10:11:57 --> Language Class Initialized
INFO - 2025-01-13 10:11:57 --> Loader Class Initialized
INFO - 2025-01-13 10:11:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:11:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:11:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:11:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:11:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:11:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:11:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:11:57 --> Upload Class Initialized
INFO - 2025-01-13 10:11:57 --> Email Class Initialized
INFO - 2025-01-13 10:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:11:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:11:57 --> Controller Class Initialized
INFO - 2025-01-13 15:41:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:41:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:41:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:12:57 --> Config Class Initialized
INFO - 2025-01-13 10:12:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:12:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:12:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:12:57 --> URI Class Initialized
INFO - 2025-01-13 10:12:57 --> Router Class Initialized
INFO - 2025-01-13 10:12:57 --> Output Class Initialized
INFO - 2025-01-13 10:12:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:12:57 --> Input Class Initialized
INFO - 2025-01-13 10:12:57 --> Language Class Initialized
INFO - 2025-01-13 10:12:57 --> Loader Class Initialized
INFO - 2025-01-13 10:12:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:12:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:12:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:12:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:12:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:12:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:12:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:12:57 --> Upload Class Initialized
INFO - 2025-01-13 10:12:57 --> Email Class Initialized
INFO - 2025-01-13 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:12:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:12:57 --> Controller Class Initialized
INFO - 2025-01-13 15:42:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:42:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:42:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:13:57 --> Config Class Initialized
INFO - 2025-01-13 10:13:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:13:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:13:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:13:57 --> URI Class Initialized
INFO - 2025-01-13 10:13:57 --> Router Class Initialized
INFO - 2025-01-13 10:13:57 --> Output Class Initialized
INFO - 2025-01-13 10:13:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:13:57 --> Input Class Initialized
INFO - 2025-01-13 10:13:57 --> Language Class Initialized
INFO - 2025-01-13 10:13:57 --> Loader Class Initialized
INFO - 2025-01-13 10:13:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:13:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:13:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:13:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:13:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:13:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:13:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:13:57 --> Upload Class Initialized
INFO - 2025-01-13 10:13:57 --> Email Class Initialized
INFO - 2025-01-13 10:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:13:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:13:57 --> Controller Class Initialized
INFO - 2025-01-13 15:43:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:43:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:43:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:14:57 --> Config Class Initialized
INFO - 2025-01-13 10:14:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:14:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:14:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:14:57 --> URI Class Initialized
INFO - 2025-01-13 10:14:57 --> Router Class Initialized
INFO - 2025-01-13 10:14:57 --> Output Class Initialized
INFO - 2025-01-13 10:14:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:14:57 --> Input Class Initialized
INFO - 2025-01-13 10:14:57 --> Language Class Initialized
INFO - 2025-01-13 10:14:57 --> Loader Class Initialized
INFO - 2025-01-13 10:14:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:14:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:14:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:14:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:14:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:14:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:14:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:14:57 --> Upload Class Initialized
INFO - 2025-01-13 10:14:57 --> Email Class Initialized
INFO - 2025-01-13 10:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:14:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:14:57 --> Controller Class Initialized
INFO - 2025-01-13 15:44:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:44:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:44:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:15:57 --> Config Class Initialized
INFO - 2025-01-13 10:15:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:15:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:15:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:15:57 --> URI Class Initialized
INFO - 2025-01-13 10:15:57 --> Router Class Initialized
INFO - 2025-01-13 10:15:57 --> Output Class Initialized
INFO - 2025-01-13 10:15:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:15:57 --> Input Class Initialized
INFO - 2025-01-13 10:15:57 --> Language Class Initialized
INFO - 2025-01-13 10:15:57 --> Loader Class Initialized
INFO - 2025-01-13 10:15:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:15:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:15:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:15:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:15:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:15:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:15:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:15:57 --> Upload Class Initialized
INFO - 2025-01-13 10:15:57 --> Email Class Initialized
INFO - 2025-01-13 10:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:15:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:15:57 --> Controller Class Initialized
INFO - 2025-01-13 15:45:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:45:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:45:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:17:07 --> Config Class Initialized
INFO - 2025-01-13 10:17:07 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:17:07 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:17:07 --> Utf8 Class Initialized
INFO - 2025-01-13 10:17:07 --> URI Class Initialized
INFO - 2025-01-13 10:17:07 --> Router Class Initialized
INFO - 2025-01-13 10:17:07 --> Output Class Initialized
INFO - 2025-01-13 10:17:07 --> Security Class Initialized
DEBUG - 2025-01-13 10:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:17:07 --> Input Class Initialized
INFO - 2025-01-13 10:17:07 --> Language Class Initialized
INFO - 2025-01-13 10:17:07 --> Loader Class Initialized
INFO - 2025-01-13 10:17:07 --> Helper loaded: url_helper
INFO - 2025-01-13 10:17:07 --> Helper loaded: html_helper
INFO - 2025-01-13 10:17:07 --> Helper loaded: file_helper
INFO - 2025-01-13 10:17:07 --> Helper loaded: string_helper
INFO - 2025-01-13 10:17:07 --> Helper loaded: form_helper
INFO - 2025-01-13 10:17:07 --> Helper loaded: my_helper
INFO - 2025-01-13 10:17:07 --> Database Driver Class Initialized
INFO - 2025-01-13 10:17:07 --> Upload Class Initialized
INFO - 2025-01-13 10:17:07 --> Email Class Initialized
INFO - 2025-01-13 10:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:17:07 --> Form Validation Class Initialized
INFO - 2025-01-13 10:17:07 --> Controller Class Initialized
INFO - 2025-01-13 15:47:07 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:47:07 --> Model "MainModel" initialized
INFO - 2025-01-13 15:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:47:07 --> Pagination Class Initialized
INFO - 2025-01-13 10:17:57 --> Config Class Initialized
INFO - 2025-01-13 10:17:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:17:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:17:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:17:57 --> URI Class Initialized
INFO - 2025-01-13 10:17:57 --> Router Class Initialized
INFO - 2025-01-13 10:17:57 --> Output Class Initialized
INFO - 2025-01-13 10:17:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:17:57 --> Input Class Initialized
INFO - 2025-01-13 10:17:57 --> Language Class Initialized
INFO - 2025-01-13 10:17:57 --> Loader Class Initialized
INFO - 2025-01-13 10:17:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:17:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:17:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:17:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:17:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:17:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:17:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:17:57 --> Upload Class Initialized
INFO - 2025-01-13 10:17:57 --> Email Class Initialized
INFO - 2025-01-13 10:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:17:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:17:57 --> Controller Class Initialized
INFO - 2025-01-13 15:47:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:47:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:47:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:18:57 --> Config Class Initialized
INFO - 2025-01-13 10:18:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:18:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:18:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:18:57 --> URI Class Initialized
INFO - 2025-01-13 10:18:57 --> Router Class Initialized
INFO - 2025-01-13 10:18:57 --> Output Class Initialized
INFO - 2025-01-13 10:18:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:18:57 --> Input Class Initialized
INFO - 2025-01-13 10:18:57 --> Language Class Initialized
INFO - 2025-01-13 10:18:57 --> Loader Class Initialized
INFO - 2025-01-13 10:18:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:18:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:18:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:18:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:18:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:18:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:18:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:18:57 --> Upload Class Initialized
INFO - 2025-01-13 10:18:57 --> Email Class Initialized
INFO - 2025-01-13 10:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:18:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:18:57 --> Controller Class Initialized
INFO - 2025-01-13 15:48:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:48:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:48:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:19:57 --> Config Class Initialized
INFO - 2025-01-13 10:19:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:19:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:19:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:19:57 --> URI Class Initialized
INFO - 2025-01-13 10:19:57 --> Router Class Initialized
INFO - 2025-01-13 10:19:57 --> Output Class Initialized
INFO - 2025-01-13 10:19:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:19:57 --> Input Class Initialized
INFO - 2025-01-13 10:19:57 --> Language Class Initialized
INFO - 2025-01-13 10:19:57 --> Loader Class Initialized
INFO - 2025-01-13 10:19:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:19:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:19:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:19:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:19:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:19:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:19:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:19:57 --> Upload Class Initialized
INFO - 2025-01-13 10:19:57 --> Email Class Initialized
INFO - 2025-01-13 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:19:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:19:57 --> Controller Class Initialized
INFO - 2025-01-13 15:49:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:49:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:49:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:20:57 --> Config Class Initialized
INFO - 2025-01-13 10:20:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:20:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:20:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:20:57 --> URI Class Initialized
INFO - 2025-01-13 10:20:57 --> Router Class Initialized
INFO - 2025-01-13 10:20:57 --> Output Class Initialized
INFO - 2025-01-13 10:20:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:20:57 --> Input Class Initialized
INFO - 2025-01-13 10:20:57 --> Language Class Initialized
INFO - 2025-01-13 10:20:57 --> Loader Class Initialized
INFO - 2025-01-13 10:20:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:20:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:20:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:20:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:20:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:20:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:20:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:20:57 --> Upload Class Initialized
INFO - 2025-01-13 10:20:57 --> Email Class Initialized
INFO - 2025-01-13 10:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:20:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:20:57 --> Controller Class Initialized
INFO - 2025-01-13 15:50:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:50:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:50:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:21:57 --> Config Class Initialized
INFO - 2025-01-13 10:21:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:21:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:21:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:21:57 --> URI Class Initialized
INFO - 2025-01-13 10:21:57 --> Router Class Initialized
INFO - 2025-01-13 10:21:57 --> Output Class Initialized
INFO - 2025-01-13 10:21:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:21:57 --> Input Class Initialized
INFO - 2025-01-13 10:21:57 --> Language Class Initialized
INFO - 2025-01-13 10:21:57 --> Loader Class Initialized
INFO - 2025-01-13 10:21:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:21:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:21:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:21:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:21:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:21:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:21:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:21:57 --> Upload Class Initialized
INFO - 2025-01-13 10:21:57 --> Email Class Initialized
INFO - 2025-01-13 10:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:21:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:21:57 --> Controller Class Initialized
INFO - 2025-01-13 15:51:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:51:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:51:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:22:57 --> Config Class Initialized
INFO - 2025-01-13 10:22:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:22:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:22:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:22:57 --> URI Class Initialized
INFO - 2025-01-13 10:22:57 --> Router Class Initialized
INFO - 2025-01-13 10:22:57 --> Output Class Initialized
INFO - 2025-01-13 10:22:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:22:57 --> Input Class Initialized
INFO - 2025-01-13 10:22:57 --> Language Class Initialized
INFO - 2025-01-13 10:22:57 --> Loader Class Initialized
INFO - 2025-01-13 10:22:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:22:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:22:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:22:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:22:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:22:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:22:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:22:57 --> Upload Class Initialized
INFO - 2025-01-13 10:22:57 --> Email Class Initialized
INFO - 2025-01-13 10:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:22:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:22:57 --> Controller Class Initialized
INFO - 2025-01-13 15:52:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:52:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:52:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:23:57 --> Config Class Initialized
INFO - 2025-01-13 10:23:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:23:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:23:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:23:57 --> URI Class Initialized
INFO - 2025-01-13 10:23:57 --> Router Class Initialized
INFO - 2025-01-13 10:23:57 --> Output Class Initialized
INFO - 2025-01-13 10:23:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:23:57 --> Input Class Initialized
INFO - 2025-01-13 10:23:57 --> Language Class Initialized
INFO - 2025-01-13 10:23:57 --> Loader Class Initialized
INFO - 2025-01-13 10:23:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:23:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:23:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:23:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:23:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:23:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:23:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:23:57 --> Upload Class Initialized
INFO - 2025-01-13 10:23:57 --> Email Class Initialized
INFO - 2025-01-13 10:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:23:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:23:57 --> Controller Class Initialized
INFO - 2025-01-13 15:53:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:53:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:53:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:24:57 --> Config Class Initialized
INFO - 2025-01-13 10:24:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:24:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:24:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:24:57 --> URI Class Initialized
INFO - 2025-01-13 10:24:57 --> Router Class Initialized
INFO - 2025-01-13 10:24:57 --> Output Class Initialized
INFO - 2025-01-13 10:24:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:24:57 --> Input Class Initialized
INFO - 2025-01-13 10:24:57 --> Language Class Initialized
INFO - 2025-01-13 10:24:57 --> Loader Class Initialized
INFO - 2025-01-13 10:24:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:24:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:24:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:24:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:24:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:24:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:24:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:24:57 --> Upload Class Initialized
INFO - 2025-01-13 10:24:57 --> Email Class Initialized
INFO - 2025-01-13 10:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:24:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:24:57 --> Controller Class Initialized
INFO - 2025-01-13 15:54:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:54:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:54:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:25:57 --> Config Class Initialized
INFO - 2025-01-13 10:25:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:25:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:25:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:25:57 --> URI Class Initialized
INFO - 2025-01-13 10:25:57 --> Router Class Initialized
INFO - 2025-01-13 10:25:57 --> Output Class Initialized
INFO - 2025-01-13 10:25:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:25:57 --> Input Class Initialized
INFO - 2025-01-13 10:25:57 --> Language Class Initialized
INFO - 2025-01-13 10:25:57 --> Loader Class Initialized
INFO - 2025-01-13 10:25:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:25:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:25:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:25:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:25:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:25:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:25:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:25:57 --> Upload Class Initialized
INFO - 2025-01-13 10:25:57 --> Email Class Initialized
INFO - 2025-01-13 10:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:25:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:25:57 --> Controller Class Initialized
INFO - 2025-01-13 15:55:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:55:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:55:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:26:57 --> Config Class Initialized
INFO - 2025-01-13 10:26:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:26:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:26:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:26:57 --> URI Class Initialized
INFO - 2025-01-13 10:26:57 --> Router Class Initialized
INFO - 2025-01-13 10:26:57 --> Output Class Initialized
INFO - 2025-01-13 10:26:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:26:57 --> Input Class Initialized
INFO - 2025-01-13 10:26:57 --> Language Class Initialized
INFO - 2025-01-13 10:26:57 --> Loader Class Initialized
INFO - 2025-01-13 10:26:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:26:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:26:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:26:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:26:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:26:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:26:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:26:57 --> Upload Class Initialized
INFO - 2025-01-13 10:26:57 --> Email Class Initialized
INFO - 2025-01-13 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:26:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:26:57 --> Controller Class Initialized
INFO - 2025-01-13 15:56:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:56:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:56:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:27:57 --> Config Class Initialized
INFO - 2025-01-13 10:27:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:27:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:27:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:27:57 --> URI Class Initialized
INFO - 2025-01-13 10:27:57 --> Router Class Initialized
INFO - 2025-01-13 10:27:57 --> Output Class Initialized
INFO - 2025-01-13 10:27:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:27:57 --> Input Class Initialized
INFO - 2025-01-13 10:27:57 --> Language Class Initialized
INFO - 2025-01-13 10:27:57 --> Loader Class Initialized
INFO - 2025-01-13 10:27:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:27:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:27:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:27:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:27:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:27:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:27:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:27:57 --> Upload Class Initialized
INFO - 2025-01-13 10:27:57 --> Email Class Initialized
INFO - 2025-01-13 10:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:27:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:27:57 --> Controller Class Initialized
INFO - 2025-01-13 15:57:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:57:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:57:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:28:57 --> Config Class Initialized
INFO - 2025-01-13 10:28:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:28:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:28:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:28:57 --> URI Class Initialized
INFO - 2025-01-13 10:28:57 --> Router Class Initialized
INFO - 2025-01-13 10:28:57 --> Output Class Initialized
INFO - 2025-01-13 10:28:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:28:57 --> Input Class Initialized
INFO - 2025-01-13 10:28:57 --> Language Class Initialized
INFO - 2025-01-13 10:28:57 --> Loader Class Initialized
INFO - 2025-01-13 10:28:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:28:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:28:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:28:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:28:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:28:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:28:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:28:57 --> Upload Class Initialized
INFO - 2025-01-13 10:28:57 --> Email Class Initialized
INFO - 2025-01-13 10:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:28:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:28:57 --> Controller Class Initialized
INFO - 2025-01-13 15:58:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:58:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:58:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:29:57 --> Config Class Initialized
INFO - 2025-01-13 10:29:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:29:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:29:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:29:57 --> URI Class Initialized
INFO - 2025-01-13 10:29:57 --> Router Class Initialized
INFO - 2025-01-13 10:29:57 --> Output Class Initialized
INFO - 2025-01-13 10:29:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:29:57 --> Input Class Initialized
INFO - 2025-01-13 10:29:57 --> Language Class Initialized
INFO - 2025-01-13 10:29:57 --> Loader Class Initialized
INFO - 2025-01-13 10:29:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:29:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:29:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:29:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:29:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:29:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:29:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:29:57 --> Upload Class Initialized
INFO - 2025-01-13 10:29:57 --> Email Class Initialized
INFO - 2025-01-13 10:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:29:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:29:57 --> Controller Class Initialized
INFO - 2025-01-13 15:59:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 15:59:57 --> Model "MainModel" initialized
INFO - 2025-01-13 15:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 15:59:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:30:57 --> Config Class Initialized
INFO - 2025-01-13 10:30:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:30:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:30:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:30:57 --> URI Class Initialized
INFO - 2025-01-13 10:30:57 --> Router Class Initialized
INFO - 2025-01-13 10:30:57 --> Output Class Initialized
INFO - 2025-01-13 10:30:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:30:57 --> Input Class Initialized
INFO - 2025-01-13 10:30:57 --> Language Class Initialized
INFO - 2025-01-13 10:30:57 --> Loader Class Initialized
INFO - 2025-01-13 10:30:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:30:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:30:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:30:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:30:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:30:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:30:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:30:57 --> Upload Class Initialized
INFO - 2025-01-13 10:30:57 --> Email Class Initialized
INFO - 2025-01-13 10:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:30:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:30:57 --> Controller Class Initialized
INFO - 2025-01-13 16:00:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:00:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:00:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:32:19 --> Config Class Initialized
INFO - 2025-01-13 10:32:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:32:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:32:19 --> Utf8 Class Initialized
INFO - 2025-01-13 10:32:19 --> URI Class Initialized
INFO - 2025-01-13 10:32:19 --> Router Class Initialized
INFO - 2025-01-13 10:32:19 --> Output Class Initialized
INFO - 2025-01-13 10:32:19 --> Security Class Initialized
DEBUG - 2025-01-13 10:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:32:19 --> Input Class Initialized
INFO - 2025-01-13 10:32:19 --> Language Class Initialized
INFO - 2025-01-13 10:32:19 --> Loader Class Initialized
INFO - 2025-01-13 10:32:19 --> Helper loaded: url_helper
INFO - 2025-01-13 10:32:19 --> Helper loaded: html_helper
INFO - 2025-01-13 10:32:19 --> Helper loaded: file_helper
INFO - 2025-01-13 10:32:19 --> Helper loaded: string_helper
INFO - 2025-01-13 10:32:19 --> Helper loaded: form_helper
INFO - 2025-01-13 10:32:19 --> Helper loaded: my_helper
INFO - 2025-01-13 10:32:19 --> Database Driver Class Initialized
INFO - 2025-01-13 10:32:20 --> Upload Class Initialized
INFO - 2025-01-13 10:32:20 --> Email Class Initialized
INFO - 2025-01-13 10:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:32:20 --> Form Validation Class Initialized
INFO - 2025-01-13 10:32:20 --> Controller Class Initialized
INFO - 2025-01-13 16:02:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:02:20 --> Model "MainModel" initialized
INFO - 2025-01-13 16:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:02:20 --> Pagination Class Initialized
INFO - 2025-01-13 10:32:57 --> Config Class Initialized
INFO - 2025-01-13 10:32:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:32:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:32:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:32:57 --> URI Class Initialized
INFO - 2025-01-13 10:32:57 --> Router Class Initialized
INFO - 2025-01-13 10:32:57 --> Output Class Initialized
INFO - 2025-01-13 10:32:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:32:57 --> Input Class Initialized
INFO - 2025-01-13 10:32:57 --> Language Class Initialized
INFO - 2025-01-13 10:32:57 --> Loader Class Initialized
INFO - 2025-01-13 10:32:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:32:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:32:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:32:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:32:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:32:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:32:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:32:57 --> Upload Class Initialized
INFO - 2025-01-13 10:32:57 --> Email Class Initialized
INFO - 2025-01-13 10:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:32:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:32:57 --> Controller Class Initialized
INFO - 2025-01-13 16:02:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:02:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:02:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:33:57 --> Config Class Initialized
INFO - 2025-01-13 10:33:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:33:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:33:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:33:57 --> URI Class Initialized
INFO - 2025-01-13 10:33:57 --> Router Class Initialized
INFO - 2025-01-13 10:33:57 --> Output Class Initialized
INFO - 2025-01-13 10:33:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:33:57 --> Input Class Initialized
INFO - 2025-01-13 10:33:57 --> Language Class Initialized
INFO - 2025-01-13 10:33:57 --> Loader Class Initialized
INFO - 2025-01-13 10:33:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:33:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:33:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:33:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:33:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:33:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:33:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:33:57 --> Upload Class Initialized
INFO - 2025-01-13 10:33:57 --> Email Class Initialized
INFO - 2025-01-13 10:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:33:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:33:57 --> Controller Class Initialized
INFO - 2025-01-13 16:03:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:03:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:03:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:34:07 --> Config Class Initialized
INFO - 2025-01-13 10:34:07 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:34:07 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:34:07 --> Utf8 Class Initialized
INFO - 2025-01-13 10:34:07 --> URI Class Initialized
INFO - 2025-01-13 10:34:07 --> Router Class Initialized
INFO - 2025-01-13 10:34:07 --> Output Class Initialized
INFO - 2025-01-13 10:34:07 --> Security Class Initialized
DEBUG - 2025-01-13 10:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:34:07 --> Input Class Initialized
INFO - 2025-01-13 10:34:07 --> Language Class Initialized
INFO - 2025-01-13 10:34:07 --> Loader Class Initialized
INFO - 2025-01-13 10:34:07 --> Helper loaded: url_helper
INFO - 2025-01-13 10:34:07 --> Helper loaded: html_helper
INFO - 2025-01-13 10:34:07 --> Helper loaded: file_helper
INFO - 2025-01-13 10:34:07 --> Helper loaded: string_helper
INFO - 2025-01-13 10:34:07 --> Helper loaded: form_helper
INFO - 2025-01-13 10:34:07 --> Helper loaded: my_helper
INFO - 2025-01-13 10:34:07 --> Database Driver Class Initialized
INFO - 2025-01-13 10:34:07 --> Upload Class Initialized
INFO - 2025-01-13 10:34:07 --> Email Class Initialized
INFO - 2025-01-13 10:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:34:07 --> Form Validation Class Initialized
INFO - 2025-01-13 10:34:07 --> Controller Class Initialized
INFO - 2025-01-13 16:04:07 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:04:07 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:04:07 --> Model "MainModel" initialized
INFO - 2025-01-13 10:34:33 --> Config Class Initialized
INFO - 2025-01-13 10:34:33 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:34:33 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:34:33 --> Utf8 Class Initialized
INFO - 2025-01-13 10:34:33 --> URI Class Initialized
INFO - 2025-01-13 10:34:33 --> Router Class Initialized
INFO - 2025-01-13 10:34:33 --> Output Class Initialized
INFO - 2025-01-13 10:34:33 --> Security Class Initialized
DEBUG - 2025-01-13 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:34:33 --> Input Class Initialized
INFO - 2025-01-13 10:34:33 --> Language Class Initialized
INFO - 2025-01-13 10:34:33 --> Loader Class Initialized
INFO - 2025-01-13 10:34:33 --> Helper loaded: url_helper
INFO - 2025-01-13 10:34:33 --> Helper loaded: html_helper
INFO - 2025-01-13 10:34:33 --> Helper loaded: file_helper
INFO - 2025-01-13 10:34:33 --> Helper loaded: string_helper
INFO - 2025-01-13 10:34:33 --> Helper loaded: form_helper
INFO - 2025-01-13 10:34:33 --> Helper loaded: my_helper
INFO - 2025-01-13 10:34:33 --> Database Driver Class Initialized
INFO - 2025-01-13 10:34:33 --> Upload Class Initialized
INFO - 2025-01-13 10:34:33 --> Email Class Initialized
INFO - 2025-01-13 10:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:34:33 --> Form Validation Class Initialized
INFO - 2025-01-13 10:34:33 --> Controller Class Initialized
INFO - 2025-01-13 16:04:33 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:04:33 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:04:33 --> Model "MainModel" initialized
INFO - 2025-01-13 10:34:57 --> Config Class Initialized
INFO - 2025-01-13 10:34:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:34:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:34:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:34:57 --> URI Class Initialized
INFO - 2025-01-13 10:34:57 --> Router Class Initialized
INFO - 2025-01-13 10:34:57 --> Output Class Initialized
INFO - 2025-01-13 10:34:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:34:57 --> Input Class Initialized
INFO - 2025-01-13 10:34:57 --> Language Class Initialized
INFO - 2025-01-13 10:34:57 --> Loader Class Initialized
INFO - 2025-01-13 10:34:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:34:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:34:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:34:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:34:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:34:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:34:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:34:57 --> Upload Class Initialized
INFO - 2025-01-13 10:34:57 --> Email Class Initialized
INFO - 2025-01-13 10:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:34:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:34:57 --> Controller Class Initialized
INFO - 2025-01-13 16:04:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:04:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:04:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:35:29 --> Config Class Initialized
INFO - 2025-01-13 10:35:29 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:35:29 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:35:29 --> Utf8 Class Initialized
INFO - 2025-01-13 10:35:29 --> URI Class Initialized
INFO - 2025-01-13 10:35:29 --> Router Class Initialized
INFO - 2025-01-13 10:35:29 --> Output Class Initialized
INFO - 2025-01-13 10:35:29 --> Security Class Initialized
DEBUG - 2025-01-13 10:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:35:29 --> Input Class Initialized
INFO - 2025-01-13 10:35:29 --> Language Class Initialized
INFO - 2025-01-13 10:35:29 --> Loader Class Initialized
INFO - 2025-01-13 10:35:29 --> Helper loaded: url_helper
INFO - 2025-01-13 10:35:29 --> Helper loaded: html_helper
INFO - 2025-01-13 10:35:29 --> Helper loaded: file_helper
INFO - 2025-01-13 10:35:29 --> Helper loaded: string_helper
INFO - 2025-01-13 10:35:29 --> Helper loaded: form_helper
INFO - 2025-01-13 10:35:29 --> Helper loaded: my_helper
INFO - 2025-01-13 10:35:29 --> Database Driver Class Initialized
INFO - 2025-01-13 10:35:29 --> Upload Class Initialized
INFO - 2025-01-13 10:35:29 --> Email Class Initialized
INFO - 2025-01-13 10:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:35:29 --> Form Validation Class Initialized
INFO - 2025-01-13 10:35:29 --> Controller Class Initialized
INFO - 2025-01-13 16:05:29 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:05:29 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:05:29 --> Model "MainModel" initialized
INFO - 2025-01-13 10:35:50 --> Config Class Initialized
INFO - 2025-01-13 10:35:50 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:35:50 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:35:50 --> Utf8 Class Initialized
INFO - 2025-01-13 10:35:50 --> URI Class Initialized
INFO - 2025-01-13 10:35:50 --> Router Class Initialized
INFO - 2025-01-13 10:35:50 --> Output Class Initialized
INFO - 2025-01-13 10:35:50 --> Security Class Initialized
DEBUG - 2025-01-13 10:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:35:50 --> Input Class Initialized
INFO - 2025-01-13 10:35:50 --> Language Class Initialized
INFO - 2025-01-13 10:35:50 --> Loader Class Initialized
INFO - 2025-01-13 10:35:50 --> Helper loaded: url_helper
INFO - 2025-01-13 10:35:50 --> Helper loaded: html_helper
INFO - 2025-01-13 10:35:50 --> Helper loaded: file_helper
INFO - 2025-01-13 10:35:50 --> Helper loaded: string_helper
INFO - 2025-01-13 10:35:50 --> Helper loaded: form_helper
INFO - 2025-01-13 10:35:50 --> Helper loaded: my_helper
INFO - 2025-01-13 10:35:50 --> Database Driver Class Initialized
INFO - 2025-01-13 10:35:50 --> Upload Class Initialized
INFO - 2025-01-13 10:35:50 --> Email Class Initialized
INFO - 2025-01-13 10:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:35:50 --> Form Validation Class Initialized
INFO - 2025-01-13 10:35:50 --> Controller Class Initialized
INFO - 2025-01-13 16:05:50 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:05:50 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:05:50 --> Model "MainModel" initialized
INFO - 2025-01-13 10:35:57 --> Config Class Initialized
INFO - 2025-01-13 10:35:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:35:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:35:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:35:57 --> URI Class Initialized
INFO - 2025-01-13 10:35:57 --> Router Class Initialized
INFO - 2025-01-13 10:35:57 --> Output Class Initialized
INFO - 2025-01-13 10:35:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:35:57 --> Input Class Initialized
INFO - 2025-01-13 10:35:57 --> Language Class Initialized
INFO - 2025-01-13 10:35:57 --> Loader Class Initialized
INFO - 2025-01-13 10:35:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:35:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:35:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:35:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:35:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:35:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:35:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:35:57 --> Upload Class Initialized
INFO - 2025-01-13 10:35:57 --> Email Class Initialized
INFO - 2025-01-13 10:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:35:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:35:57 --> Controller Class Initialized
INFO - 2025-01-13 16:05:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:05:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:05:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:36:13 --> Config Class Initialized
INFO - 2025-01-13 10:36:13 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:36:13 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:36:13 --> Utf8 Class Initialized
INFO - 2025-01-13 10:36:13 --> URI Class Initialized
INFO - 2025-01-13 10:36:13 --> Router Class Initialized
INFO - 2025-01-13 10:36:13 --> Output Class Initialized
INFO - 2025-01-13 10:36:13 --> Security Class Initialized
DEBUG - 2025-01-13 10:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:36:13 --> Input Class Initialized
INFO - 2025-01-13 10:36:13 --> Language Class Initialized
INFO - 2025-01-13 10:36:13 --> Loader Class Initialized
INFO - 2025-01-13 10:36:13 --> Helper loaded: url_helper
INFO - 2025-01-13 10:36:13 --> Helper loaded: html_helper
INFO - 2025-01-13 10:36:13 --> Helper loaded: file_helper
INFO - 2025-01-13 10:36:13 --> Helper loaded: string_helper
INFO - 2025-01-13 10:36:13 --> Helper loaded: form_helper
INFO - 2025-01-13 10:36:13 --> Helper loaded: my_helper
INFO - 2025-01-13 10:36:13 --> Database Driver Class Initialized
INFO - 2025-01-13 10:36:13 --> Upload Class Initialized
INFO - 2025-01-13 10:36:13 --> Email Class Initialized
INFO - 2025-01-13 10:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:36:13 --> Form Validation Class Initialized
INFO - 2025-01-13 10:36:13 --> Controller Class Initialized
INFO - 2025-01-13 16:06:13 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:06:13 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:06:13 --> Model "MainModel" initialized
INFO - 2025-01-13 10:36:57 --> Config Class Initialized
INFO - 2025-01-13 10:36:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:36:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:36:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:36:57 --> URI Class Initialized
INFO - 2025-01-13 10:36:57 --> Router Class Initialized
INFO - 2025-01-13 10:36:57 --> Output Class Initialized
INFO - 2025-01-13 10:36:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:36:57 --> Input Class Initialized
INFO - 2025-01-13 10:36:57 --> Language Class Initialized
INFO - 2025-01-13 10:36:57 --> Loader Class Initialized
INFO - 2025-01-13 10:36:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:36:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:36:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:36:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:36:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:36:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:36:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:36:57 --> Upload Class Initialized
INFO - 2025-01-13 10:36:57 --> Email Class Initialized
INFO - 2025-01-13 10:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:36:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:36:57 --> Controller Class Initialized
INFO - 2025-01-13 16:06:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:06:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:06:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:37:57 --> Config Class Initialized
INFO - 2025-01-13 10:37:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:37:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:37:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:37:57 --> URI Class Initialized
INFO - 2025-01-13 10:37:57 --> Router Class Initialized
INFO - 2025-01-13 10:37:57 --> Output Class Initialized
INFO - 2025-01-13 10:37:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:37:57 --> Input Class Initialized
INFO - 2025-01-13 10:37:57 --> Language Class Initialized
INFO - 2025-01-13 10:37:57 --> Loader Class Initialized
INFO - 2025-01-13 10:37:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:37:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:37:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:37:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:37:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:37:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:37:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:37:57 --> Upload Class Initialized
INFO - 2025-01-13 10:37:57 --> Email Class Initialized
INFO - 2025-01-13 10:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:37:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:37:57 --> Controller Class Initialized
INFO - 2025-01-13 16:07:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:07:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:07:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:38:57 --> Config Class Initialized
INFO - 2025-01-13 10:38:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:38:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:38:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:38:57 --> URI Class Initialized
INFO - 2025-01-13 10:38:57 --> Router Class Initialized
INFO - 2025-01-13 10:38:57 --> Output Class Initialized
INFO - 2025-01-13 10:38:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:38:57 --> Input Class Initialized
INFO - 2025-01-13 10:38:57 --> Language Class Initialized
INFO - 2025-01-13 10:38:57 --> Loader Class Initialized
INFO - 2025-01-13 10:38:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:38:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:38:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:38:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:38:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:38:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:38:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:38:57 --> Upload Class Initialized
INFO - 2025-01-13 10:38:57 --> Email Class Initialized
INFO - 2025-01-13 10:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:38:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:38:57 --> Controller Class Initialized
INFO - 2025-01-13 16:08:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:08:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:08:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:39:03 --> Config Class Initialized
INFO - 2025-01-13 10:39:03 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:39:03 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:39:03 --> Utf8 Class Initialized
INFO - 2025-01-13 10:39:03 --> URI Class Initialized
INFO - 2025-01-13 10:39:03 --> Router Class Initialized
INFO - 2025-01-13 10:39:03 --> Output Class Initialized
INFO - 2025-01-13 10:39:03 --> Security Class Initialized
DEBUG - 2025-01-13 10:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:39:03 --> Input Class Initialized
INFO - 2025-01-13 10:39:03 --> Language Class Initialized
INFO - 2025-01-13 10:39:03 --> Loader Class Initialized
INFO - 2025-01-13 10:39:03 --> Helper loaded: url_helper
INFO - 2025-01-13 10:39:03 --> Helper loaded: html_helper
INFO - 2025-01-13 10:39:03 --> Helper loaded: file_helper
INFO - 2025-01-13 10:39:03 --> Helper loaded: string_helper
INFO - 2025-01-13 10:39:03 --> Helper loaded: form_helper
INFO - 2025-01-13 10:39:03 --> Helper loaded: my_helper
INFO - 2025-01-13 10:39:03 --> Database Driver Class Initialized
INFO - 2025-01-13 10:39:03 --> Upload Class Initialized
INFO - 2025-01-13 10:39:03 --> Email Class Initialized
INFO - 2025-01-13 10:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:39:03 --> Form Validation Class Initialized
INFO - 2025-01-13 10:39:03 --> Controller Class Initialized
INFO - 2025-01-13 16:09:03 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:09:03 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:09:03 --> Model "MainModel" initialized
INFO - 2025-01-13 10:39:57 --> Config Class Initialized
INFO - 2025-01-13 10:39:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:39:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:39:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:39:57 --> URI Class Initialized
INFO - 2025-01-13 10:39:57 --> Router Class Initialized
INFO - 2025-01-13 10:39:57 --> Output Class Initialized
INFO - 2025-01-13 10:39:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:39:57 --> Input Class Initialized
INFO - 2025-01-13 10:39:57 --> Language Class Initialized
INFO - 2025-01-13 10:39:57 --> Loader Class Initialized
INFO - 2025-01-13 10:39:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:39:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:39:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:39:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:39:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:39:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:39:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:39:57 --> Upload Class Initialized
INFO - 2025-01-13 10:39:57 --> Email Class Initialized
INFO - 2025-01-13 10:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:39:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:39:57 --> Controller Class Initialized
INFO - 2025-01-13 16:09:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:09:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:09:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:40:24 --> Config Class Initialized
INFO - 2025-01-13 10:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:40:24 --> Utf8 Class Initialized
INFO - 2025-01-13 10:40:24 --> URI Class Initialized
INFO - 2025-01-13 10:40:24 --> Router Class Initialized
INFO - 2025-01-13 10:40:24 --> Output Class Initialized
INFO - 2025-01-13 10:40:24 --> Security Class Initialized
DEBUG - 2025-01-13 10:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:40:24 --> Input Class Initialized
INFO - 2025-01-13 10:40:24 --> Language Class Initialized
INFO - 2025-01-13 10:40:24 --> Loader Class Initialized
INFO - 2025-01-13 10:40:24 --> Helper loaded: url_helper
INFO - 2025-01-13 10:40:24 --> Helper loaded: html_helper
INFO - 2025-01-13 10:40:24 --> Helper loaded: file_helper
INFO - 2025-01-13 10:40:24 --> Helper loaded: string_helper
INFO - 2025-01-13 10:40:24 --> Helper loaded: form_helper
INFO - 2025-01-13 10:40:24 --> Helper loaded: my_helper
INFO - 2025-01-13 10:40:24 --> Database Driver Class Initialized
INFO - 2025-01-13 10:40:24 --> Upload Class Initialized
INFO - 2025-01-13 10:40:24 --> Email Class Initialized
INFO - 2025-01-13 10:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:40:24 --> Form Validation Class Initialized
INFO - 2025-01-13 10:40:24 --> Controller Class Initialized
INFO - 2025-01-13 16:10:24 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:10:24 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:10:24 --> Model "MainModel" initialized
INFO - 2025-01-13 10:40:57 --> Config Class Initialized
INFO - 2025-01-13 10:40:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:40:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:40:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:40:57 --> URI Class Initialized
INFO - 2025-01-13 10:40:57 --> Router Class Initialized
INFO - 2025-01-13 10:40:57 --> Output Class Initialized
INFO - 2025-01-13 10:40:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:40:57 --> Input Class Initialized
INFO - 2025-01-13 10:40:57 --> Language Class Initialized
INFO - 2025-01-13 10:40:57 --> Loader Class Initialized
INFO - 2025-01-13 10:40:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:40:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:40:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:40:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:40:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:40:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:40:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:40:57 --> Upload Class Initialized
INFO - 2025-01-13 10:40:57 --> Email Class Initialized
INFO - 2025-01-13 10:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:40:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:40:57 --> Controller Class Initialized
INFO - 2025-01-13 16:10:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:10:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:10:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:41:53 --> Config Class Initialized
INFO - 2025-01-13 10:41:53 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:41:53 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:41:53 --> Utf8 Class Initialized
INFO - 2025-01-13 10:41:53 --> URI Class Initialized
INFO - 2025-01-13 10:41:53 --> Router Class Initialized
INFO - 2025-01-13 10:41:53 --> Output Class Initialized
INFO - 2025-01-13 10:41:53 --> Security Class Initialized
DEBUG - 2025-01-13 10:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:41:53 --> Input Class Initialized
INFO - 2025-01-13 10:41:53 --> Language Class Initialized
INFO - 2025-01-13 10:41:53 --> Loader Class Initialized
INFO - 2025-01-13 10:41:53 --> Helper loaded: url_helper
INFO - 2025-01-13 10:41:53 --> Helper loaded: html_helper
INFO - 2025-01-13 10:41:53 --> Helper loaded: file_helper
INFO - 2025-01-13 10:41:53 --> Helper loaded: string_helper
INFO - 2025-01-13 10:41:53 --> Helper loaded: form_helper
INFO - 2025-01-13 10:41:53 --> Helper loaded: my_helper
INFO - 2025-01-13 10:41:53 --> Database Driver Class Initialized
INFO - 2025-01-13 10:41:53 --> Upload Class Initialized
INFO - 2025-01-13 10:41:53 --> Email Class Initialized
INFO - 2025-01-13 10:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:41:53 --> Form Validation Class Initialized
INFO - 2025-01-13 10:41:53 --> Controller Class Initialized
INFO - 2025-01-13 16:11:53 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:11:53 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:11:53 --> Model "MainModel" initialized
INFO - 2025-01-13 10:41:57 --> Config Class Initialized
INFO - 2025-01-13 10:41:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:41:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:41:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:41:57 --> URI Class Initialized
INFO - 2025-01-13 10:41:57 --> Router Class Initialized
INFO - 2025-01-13 10:41:57 --> Output Class Initialized
INFO - 2025-01-13 10:41:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:41:57 --> Input Class Initialized
INFO - 2025-01-13 10:41:57 --> Language Class Initialized
INFO - 2025-01-13 10:41:57 --> Loader Class Initialized
INFO - 2025-01-13 10:41:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:41:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:41:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:41:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:41:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:41:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:41:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:41:57 --> Upload Class Initialized
INFO - 2025-01-13 10:41:57 --> Email Class Initialized
INFO - 2025-01-13 10:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:41:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:41:57 --> Controller Class Initialized
INFO - 2025-01-13 16:11:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:11:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:11:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:42:57 --> Config Class Initialized
INFO - 2025-01-13 10:42:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:42:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:42:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:42:57 --> URI Class Initialized
INFO - 2025-01-13 10:42:57 --> Router Class Initialized
INFO - 2025-01-13 10:42:57 --> Output Class Initialized
INFO - 2025-01-13 10:42:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:42:57 --> Input Class Initialized
INFO - 2025-01-13 10:42:57 --> Language Class Initialized
INFO - 2025-01-13 10:42:57 --> Loader Class Initialized
INFO - 2025-01-13 10:42:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:42:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:42:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:42:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:42:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:42:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:42:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:42:57 --> Upload Class Initialized
INFO - 2025-01-13 10:42:57 --> Email Class Initialized
INFO - 2025-01-13 10:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:42:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:42:57 --> Controller Class Initialized
INFO - 2025-01-13 16:12:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:12:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:12:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:43:57 --> Config Class Initialized
INFO - 2025-01-13 10:43:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:43:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:43:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:43:57 --> URI Class Initialized
INFO - 2025-01-13 10:43:57 --> Router Class Initialized
INFO - 2025-01-13 10:43:57 --> Output Class Initialized
INFO - 2025-01-13 10:43:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:43:57 --> Input Class Initialized
INFO - 2025-01-13 10:43:57 --> Language Class Initialized
INFO - 2025-01-13 10:43:57 --> Loader Class Initialized
INFO - 2025-01-13 10:43:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:43:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:43:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:43:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:43:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:43:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:43:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:43:57 --> Upload Class Initialized
INFO - 2025-01-13 10:43:57 --> Email Class Initialized
INFO - 2025-01-13 10:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:43:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:43:57 --> Controller Class Initialized
INFO - 2025-01-13 16:13:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:13:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:13:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:44:57 --> Config Class Initialized
INFO - 2025-01-13 10:44:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:44:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:44:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:44:57 --> URI Class Initialized
INFO - 2025-01-13 10:44:57 --> Router Class Initialized
INFO - 2025-01-13 10:44:57 --> Output Class Initialized
INFO - 2025-01-13 10:44:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:44:57 --> Input Class Initialized
INFO - 2025-01-13 10:44:57 --> Language Class Initialized
INFO - 2025-01-13 10:44:57 --> Loader Class Initialized
INFO - 2025-01-13 10:44:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:44:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:44:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:44:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:44:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:44:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:44:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:44:57 --> Upload Class Initialized
INFO - 2025-01-13 10:44:57 --> Email Class Initialized
INFO - 2025-01-13 10:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:44:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:44:57 --> Controller Class Initialized
INFO - 2025-01-13 16:14:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:14:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:14:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:45:57 --> Config Class Initialized
INFO - 2025-01-13 10:45:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:45:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:45:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:45:57 --> URI Class Initialized
INFO - 2025-01-13 10:45:57 --> Router Class Initialized
INFO - 2025-01-13 10:45:57 --> Output Class Initialized
INFO - 2025-01-13 10:45:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:45:57 --> Input Class Initialized
INFO - 2025-01-13 10:45:57 --> Language Class Initialized
INFO - 2025-01-13 10:45:57 --> Loader Class Initialized
INFO - 2025-01-13 10:45:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:45:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:45:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:45:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:45:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:45:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:45:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:45:57 --> Upload Class Initialized
INFO - 2025-01-13 10:45:57 --> Email Class Initialized
INFO - 2025-01-13 10:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:45:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:45:57 --> Controller Class Initialized
INFO - 2025-01-13 16:15:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:15:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:15:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:46:57 --> Config Class Initialized
INFO - 2025-01-13 10:46:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:46:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:46:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:46:57 --> URI Class Initialized
INFO - 2025-01-13 10:46:57 --> Router Class Initialized
INFO - 2025-01-13 10:46:57 --> Output Class Initialized
INFO - 2025-01-13 10:46:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:46:57 --> Input Class Initialized
INFO - 2025-01-13 10:46:57 --> Language Class Initialized
INFO - 2025-01-13 10:46:57 --> Loader Class Initialized
INFO - 2025-01-13 10:46:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:46:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:46:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:46:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:46:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:46:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:46:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:46:57 --> Upload Class Initialized
INFO - 2025-01-13 10:46:57 --> Email Class Initialized
INFO - 2025-01-13 10:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:46:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:46:57 --> Controller Class Initialized
INFO - 2025-01-13 16:16:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:16:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:16:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:49:35 --> Config Class Initialized
INFO - 2025-01-13 10:49:35 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:49:35 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:49:35 --> Utf8 Class Initialized
INFO - 2025-01-13 10:49:35 --> URI Class Initialized
INFO - 2025-01-13 10:49:35 --> Router Class Initialized
INFO - 2025-01-13 10:49:35 --> Output Class Initialized
INFO - 2025-01-13 10:49:35 --> Security Class Initialized
DEBUG - 2025-01-13 10:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:49:35 --> Input Class Initialized
INFO - 2025-01-13 10:49:35 --> Language Class Initialized
INFO - 2025-01-13 10:49:35 --> Loader Class Initialized
INFO - 2025-01-13 10:49:35 --> Helper loaded: url_helper
INFO - 2025-01-13 10:49:35 --> Helper loaded: html_helper
INFO - 2025-01-13 10:49:35 --> Helper loaded: file_helper
INFO - 2025-01-13 10:49:35 --> Helper loaded: string_helper
INFO - 2025-01-13 10:49:35 --> Helper loaded: form_helper
INFO - 2025-01-13 10:49:35 --> Helper loaded: my_helper
INFO - 2025-01-13 10:49:35 --> Database Driver Class Initialized
INFO - 2025-01-13 10:49:35 --> Upload Class Initialized
INFO - 2025-01-13 10:49:35 --> Email Class Initialized
INFO - 2025-01-13 10:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:49:35 --> Form Validation Class Initialized
INFO - 2025-01-13 10:49:35 --> Controller Class Initialized
INFO - 2025-01-13 16:19:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:19:35 --> Model "MainModel" initialized
INFO - 2025-01-13 16:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:19:35 --> Pagination Class Initialized
INFO - 2025-01-13 10:49:57 --> Config Class Initialized
INFO - 2025-01-13 10:49:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:49:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:49:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:49:57 --> URI Class Initialized
INFO - 2025-01-13 10:49:57 --> Router Class Initialized
INFO - 2025-01-13 10:49:57 --> Output Class Initialized
INFO - 2025-01-13 10:49:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:49:57 --> Input Class Initialized
INFO - 2025-01-13 10:49:57 --> Language Class Initialized
INFO - 2025-01-13 10:49:57 --> Loader Class Initialized
INFO - 2025-01-13 10:49:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:49:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:49:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:49:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:49:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:49:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:49:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:49:57 --> Upload Class Initialized
INFO - 2025-01-13 10:49:57 --> Email Class Initialized
INFO - 2025-01-13 10:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:49:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:49:57 --> Controller Class Initialized
INFO - 2025-01-13 16:19:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:19:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:19:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:50:57 --> Config Class Initialized
INFO - 2025-01-13 10:50:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:50:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:50:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:50:57 --> URI Class Initialized
INFO - 2025-01-13 10:50:57 --> Router Class Initialized
INFO - 2025-01-13 10:50:57 --> Output Class Initialized
INFO - 2025-01-13 10:50:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:50:57 --> Input Class Initialized
INFO - 2025-01-13 10:50:57 --> Language Class Initialized
INFO - 2025-01-13 10:50:57 --> Loader Class Initialized
INFO - 2025-01-13 10:50:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:50:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:50:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:50:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:50:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:50:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:50:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:50:57 --> Upload Class Initialized
INFO - 2025-01-13 10:50:57 --> Email Class Initialized
INFO - 2025-01-13 10:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:50:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:50:57 --> Controller Class Initialized
INFO - 2025-01-13 16:20:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:20:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:20:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:51:57 --> Config Class Initialized
INFO - 2025-01-13 10:51:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:51:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:51:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:51:57 --> URI Class Initialized
INFO - 2025-01-13 10:51:57 --> Router Class Initialized
INFO - 2025-01-13 10:51:57 --> Output Class Initialized
INFO - 2025-01-13 10:51:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:51:57 --> Input Class Initialized
INFO - 2025-01-13 10:51:57 --> Language Class Initialized
INFO - 2025-01-13 10:51:57 --> Loader Class Initialized
INFO - 2025-01-13 10:51:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:51:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:51:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:51:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:51:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:51:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:51:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:51:57 --> Upload Class Initialized
INFO - 2025-01-13 10:51:57 --> Email Class Initialized
INFO - 2025-01-13 10:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:51:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:51:57 --> Controller Class Initialized
INFO - 2025-01-13 16:21:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:21:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:21:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:52:57 --> Config Class Initialized
INFO - 2025-01-13 10:52:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:52:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:52:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:52:57 --> URI Class Initialized
INFO - 2025-01-13 10:52:57 --> Router Class Initialized
INFO - 2025-01-13 10:52:57 --> Output Class Initialized
INFO - 2025-01-13 10:52:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:52:57 --> Input Class Initialized
INFO - 2025-01-13 10:52:57 --> Language Class Initialized
INFO - 2025-01-13 10:52:57 --> Loader Class Initialized
INFO - 2025-01-13 10:52:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:52:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:52:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:52:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:52:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:52:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:52:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:52:57 --> Upload Class Initialized
INFO - 2025-01-13 10:52:57 --> Email Class Initialized
INFO - 2025-01-13 10:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:52:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:52:57 --> Controller Class Initialized
INFO - 2025-01-13 16:22:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:22:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:22:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:53:57 --> Config Class Initialized
INFO - 2025-01-13 10:53:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:53:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:53:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:53:57 --> URI Class Initialized
INFO - 2025-01-13 10:53:57 --> Router Class Initialized
INFO - 2025-01-13 10:53:57 --> Output Class Initialized
INFO - 2025-01-13 10:53:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:53:57 --> Input Class Initialized
INFO - 2025-01-13 10:53:57 --> Language Class Initialized
INFO - 2025-01-13 10:53:57 --> Loader Class Initialized
INFO - 2025-01-13 10:53:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:53:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:53:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:53:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:53:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:53:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:53:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:53:57 --> Upload Class Initialized
INFO - 2025-01-13 10:53:57 --> Email Class Initialized
INFO - 2025-01-13 10:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:53:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:53:57 --> Controller Class Initialized
INFO - 2025-01-13 16:23:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:23:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:23:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:54:32 --> Config Class Initialized
INFO - 2025-01-13 10:54:32 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:54:32 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:54:32 --> Utf8 Class Initialized
INFO - 2025-01-13 10:54:32 --> URI Class Initialized
INFO - 2025-01-13 10:54:32 --> Router Class Initialized
INFO - 2025-01-13 10:54:32 --> Output Class Initialized
INFO - 2025-01-13 10:54:32 --> Security Class Initialized
DEBUG - 2025-01-13 10:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:54:32 --> Input Class Initialized
INFO - 2025-01-13 10:54:32 --> Language Class Initialized
INFO - 2025-01-13 10:54:32 --> Loader Class Initialized
INFO - 2025-01-13 10:54:32 --> Helper loaded: url_helper
INFO - 2025-01-13 10:54:32 --> Helper loaded: html_helper
INFO - 2025-01-13 10:54:32 --> Helper loaded: file_helper
INFO - 2025-01-13 10:54:32 --> Helper loaded: string_helper
INFO - 2025-01-13 10:54:32 --> Helper loaded: form_helper
INFO - 2025-01-13 10:54:32 --> Helper loaded: my_helper
INFO - 2025-01-13 10:54:32 --> Database Driver Class Initialized
INFO - 2025-01-13 10:54:32 --> Upload Class Initialized
INFO - 2025-01-13 10:54:32 --> Email Class Initialized
INFO - 2025-01-13 10:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:54:32 --> Form Validation Class Initialized
INFO - 2025-01-13 10:54:32 --> Controller Class Initialized
INFO - 2025-01-13 16:24:32 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:24:32 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:24:32 --> Model "MainModel" initialized
INFO - 2025-01-13 10:54:57 --> Config Class Initialized
INFO - 2025-01-13 10:54:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:54:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:54:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:54:57 --> URI Class Initialized
INFO - 2025-01-13 10:54:57 --> Router Class Initialized
INFO - 2025-01-13 10:54:57 --> Output Class Initialized
INFO - 2025-01-13 10:54:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:54:57 --> Input Class Initialized
INFO - 2025-01-13 10:54:57 --> Language Class Initialized
INFO - 2025-01-13 10:54:57 --> Loader Class Initialized
INFO - 2025-01-13 10:54:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:54:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:54:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:54:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:54:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:54:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:54:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:54:57 --> Upload Class Initialized
INFO - 2025-01-13 10:54:57 --> Email Class Initialized
INFO - 2025-01-13 10:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:54:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:54:57 --> Controller Class Initialized
INFO - 2025-01-13 16:24:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:24:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:24:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:55:57 --> Config Class Initialized
INFO - 2025-01-13 10:55:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:55:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:55:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:55:57 --> URI Class Initialized
INFO - 2025-01-13 10:55:57 --> Router Class Initialized
INFO - 2025-01-13 10:55:57 --> Output Class Initialized
INFO - 2025-01-13 10:55:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:55:57 --> Input Class Initialized
INFO - 2025-01-13 10:55:57 --> Language Class Initialized
INFO - 2025-01-13 10:55:57 --> Loader Class Initialized
INFO - 2025-01-13 10:55:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:55:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:55:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:55:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:55:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:55:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:55:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:55:57 --> Upload Class Initialized
INFO - 2025-01-13 10:55:57 --> Email Class Initialized
INFO - 2025-01-13 10:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:55:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:55:57 --> Controller Class Initialized
INFO - 2025-01-13 16:25:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:25:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:25:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:56:57 --> Config Class Initialized
INFO - 2025-01-13 10:56:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:56:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:56:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:56:57 --> URI Class Initialized
INFO - 2025-01-13 10:56:57 --> Router Class Initialized
INFO - 2025-01-13 10:56:57 --> Output Class Initialized
INFO - 2025-01-13 10:56:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:56:57 --> Input Class Initialized
INFO - 2025-01-13 10:56:57 --> Language Class Initialized
INFO - 2025-01-13 10:56:57 --> Loader Class Initialized
INFO - 2025-01-13 10:56:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:56:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:56:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:56:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:56:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:56:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:56:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:56:57 --> Upload Class Initialized
INFO - 2025-01-13 10:56:57 --> Email Class Initialized
INFO - 2025-01-13 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:56:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:56:57 --> Controller Class Initialized
INFO - 2025-01-13 16:26:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:26:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:26:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:57:57 --> Config Class Initialized
INFO - 2025-01-13 10:57:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:57:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:57:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:57:57 --> URI Class Initialized
INFO - 2025-01-13 10:57:57 --> Router Class Initialized
INFO - 2025-01-13 10:57:57 --> Output Class Initialized
INFO - 2025-01-13 10:57:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:57:57 --> Input Class Initialized
INFO - 2025-01-13 10:57:57 --> Language Class Initialized
INFO - 2025-01-13 10:57:57 --> Loader Class Initialized
INFO - 2025-01-13 10:57:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:57:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:57:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:57:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:57:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:57:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:57:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:57:57 --> Upload Class Initialized
INFO - 2025-01-13 10:57:57 --> Email Class Initialized
INFO - 2025-01-13 10:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:57:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:57:57 --> Controller Class Initialized
INFO - 2025-01-13 16:27:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:27:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:27:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:58:57 --> Config Class Initialized
INFO - 2025-01-13 10:58:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:58:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:58:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:58:57 --> URI Class Initialized
INFO - 2025-01-13 10:58:57 --> Router Class Initialized
INFO - 2025-01-13 10:58:57 --> Output Class Initialized
INFO - 2025-01-13 10:58:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:58:57 --> Input Class Initialized
INFO - 2025-01-13 10:58:57 --> Language Class Initialized
INFO - 2025-01-13 10:58:57 --> Loader Class Initialized
INFO - 2025-01-13 10:58:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:58:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:58:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:58:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:58:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:58:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:58:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:58:57 --> Upload Class Initialized
INFO - 2025-01-13 10:58:57 --> Email Class Initialized
INFO - 2025-01-13 10:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:58:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:58:57 --> Controller Class Initialized
INFO - 2025-01-13 16:28:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:28:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:28:57 --> Pagination Class Initialized
INFO - 2025-01-13 10:59:57 --> Config Class Initialized
INFO - 2025-01-13 10:59:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 10:59:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 10:59:57 --> Utf8 Class Initialized
INFO - 2025-01-13 10:59:57 --> URI Class Initialized
INFO - 2025-01-13 10:59:57 --> Router Class Initialized
INFO - 2025-01-13 10:59:57 --> Output Class Initialized
INFO - 2025-01-13 10:59:57 --> Security Class Initialized
DEBUG - 2025-01-13 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 10:59:57 --> Input Class Initialized
INFO - 2025-01-13 10:59:57 --> Language Class Initialized
INFO - 2025-01-13 10:59:57 --> Loader Class Initialized
INFO - 2025-01-13 10:59:57 --> Helper loaded: url_helper
INFO - 2025-01-13 10:59:57 --> Helper loaded: html_helper
INFO - 2025-01-13 10:59:57 --> Helper loaded: file_helper
INFO - 2025-01-13 10:59:57 --> Helper loaded: string_helper
INFO - 2025-01-13 10:59:57 --> Helper loaded: form_helper
INFO - 2025-01-13 10:59:57 --> Helper loaded: my_helper
INFO - 2025-01-13 10:59:57 --> Database Driver Class Initialized
INFO - 2025-01-13 10:59:57 --> Upload Class Initialized
INFO - 2025-01-13 10:59:57 --> Email Class Initialized
INFO - 2025-01-13 10:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 10:59:57 --> Form Validation Class Initialized
INFO - 2025-01-13 10:59:57 --> Controller Class Initialized
INFO - 2025-01-13 16:29:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:29:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:29:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:00:57 --> Config Class Initialized
INFO - 2025-01-13 11:00:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:00:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:00:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:00:57 --> URI Class Initialized
INFO - 2025-01-13 11:00:57 --> Router Class Initialized
INFO - 2025-01-13 11:00:57 --> Output Class Initialized
INFO - 2025-01-13 11:00:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:00:57 --> Input Class Initialized
INFO - 2025-01-13 11:00:57 --> Language Class Initialized
INFO - 2025-01-13 11:00:57 --> Loader Class Initialized
INFO - 2025-01-13 11:00:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:00:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:00:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:00:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:00:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:00:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:00:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:00:57 --> Upload Class Initialized
INFO - 2025-01-13 11:00:57 --> Email Class Initialized
INFO - 2025-01-13 11:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:00:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:00:57 --> Controller Class Initialized
INFO - 2025-01-13 16:30:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:30:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:30:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:01:57 --> Config Class Initialized
INFO - 2025-01-13 11:01:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:01:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:01:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:01:57 --> URI Class Initialized
INFO - 2025-01-13 11:01:57 --> Router Class Initialized
INFO - 2025-01-13 11:01:57 --> Output Class Initialized
INFO - 2025-01-13 11:01:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:01:57 --> Input Class Initialized
INFO - 2025-01-13 11:01:57 --> Language Class Initialized
INFO - 2025-01-13 11:01:57 --> Loader Class Initialized
INFO - 2025-01-13 11:01:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:01:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:01:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:01:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:01:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:01:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:01:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:01:57 --> Upload Class Initialized
INFO - 2025-01-13 11:01:57 --> Email Class Initialized
INFO - 2025-01-13 11:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:01:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:01:57 --> Controller Class Initialized
INFO - 2025-01-13 16:31:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:31:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:31:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:20:57 --> Config Class Initialized
INFO - 2025-01-13 11:20:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:20:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:20:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:20:57 --> URI Class Initialized
INFO - 2025-01-13 11:20:57 --> Router Class Initialized
INFO - 2025-01-13 11:20:57 --> Output Class Initialized
INFO - 2025-01-13 11:20:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:20:57 --> Input Class Initialized
INFO - 2025-01-13 11:20:57 --> Language Class Initialized
INFO - 2025-01-13 11:20:57 --> Loader Class Initialized
INFO - 2025-01-13 11:20:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:20:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:20:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:20:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:20:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:20:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:20:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:20:57 --> Upload Class Initialized
INFO - 2025-01-13 11:20:57 --> Email Class Initialized
INFO - 2025-01-13 11:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:20:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:20:57 --> Controller Class Initialized
INFO - 2025-01-13 16:50:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:50:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:50:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:21:31 --> Config Class Initialized
INFO - 2025-01-13 11:21:31 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:21:31 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:21:31 --> Utf8 Class Initialized
INFO - 2025-01-13 11:21:31 --> URI Class Initialized
INFO - 2025-01-13 11:21:31 --> Router Class Initialized
INFO - 2025-01-13 11:21:31 --> Output Class Initialized
INFO - 2025-01-13 11:21:31 --> Security Class Initialized
DEBUG - 2025-01-13 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:21:31 --> Input Class Initialized
INFO - 2025-01-13 11:21:31 --> Language Class Initialized
INFO - 2025-01-13 11:21:31 --> Loader Class Initialized
INFO - 2025-01-13 11:21:31 --> Helper loaded: url_helper
INFO - 2025-01-13 11:21:31 --> Helper loaded: html_helper
INFO - 2025-01-13 11:21:31 --> Helper loaded: file_helper
INFO - 2025-01-13 11:21:31 --> Helper loaded: string_helper
INFO - 2025-01-13 11:21:31 --> Helper loaded: form_helper
INFO - 2025-01-13 11:21:31 --> Helper loaded: my_helper
INFO - 2025-01-13 11:21:31 --> Database Driver Class Initialized
INFO - 2025-01-13 11:21:31 --> Upload Class Initialized
INFO - 2025-01-13 11:21:31 --> Email Class Initialized
INFO - 2025-01-13 11:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:21:31 --> Form Validation Class Initialized
INFO - 2025-01-13 11:21:31 --> Controller Class Initialized
INFO - 2025-01-13 16:51:31 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:51:31 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:51:31 --> Model "MainModel" initialized
INFO - 2025-01-13 11:21:56 --> Config Class Initialized
INFO - 2025-01-13 11:21:56 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:21:56 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:21:56 --> Utf8 Class Initialized
INFO - 2025-01-13 11:21:56 --> URI Class Initialized
INFO - 2025-01-13 11:21:56 --> Router Class Initialized
INFO - 2025-01-13 11:21:56 --> Output Class Initialized
INFO - 2025-01-13 11:21:56 --> Security Class Initialized
DEBUG - 2025-01-13 11:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:21:56 --> Input Class Initialized
INFO - 2025-01-13 11:21:56 --> Language Class Initialized
INFO - 2025-01-13 11:21:56 --> Loader Class Initialized
INFO - 2025-01-13 11:21:56 --> Helper loaded: url_helper
INFO - 2025-01-13 11:21:56 --> Helper loaded: html_helper
INFO - 2025-01-13 11:21:56 --> Helper loaded: file_helper
INFO - 2025-01-13 11:21:56 --> Helper loaded: string_helper
INFO - 2025-01-13 11:21:56 --> Helper loaded: form_helper
INFO - 2025-01-13 11:21:56 --> Helper loaded: my_helper
INFO - 2025-01-13 11:21:56 --> Database Driver Class Initialized
INFO - 2025-01-13 11:21:56 --> Upload Class Initialized
INFO - 2025-01-13 11:21:56 --> Email Class Initialized
INFO - 2025-01-13 11:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:21:56 --> Form Validation Class Initialized
INFO - 2025-01-13 11:21:56 --> Controller Class Initialized
INFO - 2025-01-13 16:51:56 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:51:56 --> Model "MainModel" initialized
INFO - 2025-01-13 16:51:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:51:56 --> Pagination Class Initialized
INFO - 2025-01-13 11:22:37 --> Config Class Initialized
INFO - 2025-01-13 11:22:37 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:22:37 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:22:37 --> Utf8 Class Initialized
INFO - 2025-01-13 11:22:37 --> URI Class Initialized
INFO - 2025-01-13 11:22:37 --> Router Class Initialized
INFO - 2025-01-13 11:22:37 --> Output Class Initialized
INFO - 2025-01-13 11:22:37 --> Security Class Initialized
DEBUG - 2025-01-13 11:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:22:37 --> Input Class Initialized
INFO - 2025-01-13 11:22:37 --> Language Class Initialized
INFO - 2025-01-13 11:22:37 --> Loader Class Initialized
INFO - 2025-01-13 11:22:37 --> Helper loaded: url_helper
INFO - 2025-01-13 11:22:37 --> Helper loaded: html_helper
INFO - 2025-01-13 11:22:37 --> Helper loaded: file_helper
INFO - 2025-01-13 11:22:37 --> Helper loaded: string_helper
INFO - 2025-01-13 11:22:37 --> Helper loaded: form_helper
INFO - 2025-01-13 11:22:37 --> Helper loaded: my_helper
INFO - 2025-01-13 11:22:37 --> Database Driver Class Initialized
INFO - 2025-01-13 11:22:37 --> Upload Class Initialized
INFO - 2025-01-13 11:22:37 --> Email Class Initialized
INFO - 2025-01-13 11:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:22:37 --> Form Validation Class Initialized
INFO - 2025-01-13 11:22:37 --> Controller Class Initialized
INFO - 2025-01-13 16:52:37 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:52:37 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:52:37 --> Model "MainModel" initialized
INFO - 2025-01-13 11:22:57 --> Config Class Initialized
INFO - 2025-01-13 11:22:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:22:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:22:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:22:57 --> URI Class Initialized
INFO - 2025-01-13 11:22:57 --> Router Class Initialized
INFO - 2025-01-13 11:22:57 --> Output Class Initialized
INFO - 2025-01-13 11:22:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:22:57 --> Input Class Initialized
INFO - 2025-01-13 11:22:57 --> Language Class Initialized
INFO - 2025-01-13 11:22:57 --> Loader Class Initialized
INFO - 2025-01-13 11:22:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:22:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:22:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:22:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:22:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:22:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:22:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:22:57 --> Upload Class Initialized
INFO - 2025-01-13 11:22:57 --> Email Class Initialized
INFO - 2025-01-13 11:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:22:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:22:57 --> Controller Class Initialized
INFO - 2025-01-13 16:52:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:52:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:52:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:23:57 --> Config Class Initialized
INFO - 2025-01-13 11:23:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:23:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:23:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:23:57 --> URI Class Initialized
INFO - 2025-01-13 11:23:57 --> Router Class Initialized
INFO - 2025-01-13 11:23:57 --> Output Class Initialized
INFO - 2025-01-13 11:23:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:23:57 --> Input Class Initialized
INFO - 2025-01-13 11:23:57 --> Language Class Initialized
INFO - 2025-01-13 11:23:57 --> Loader Class Initialized
INFO - 2025-01-13 11:23:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:23:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:23:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:23:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:23:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:23:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:23:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:23:57 --> Upload Class Initialized
INFO - 2025-01-13 11:23:57 --> Email Class Initialized
INFO - 2025-01-13 11:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:23:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:23:57 --> Controller Class Initialized
INFO - 2025-01-13 16:53:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:53:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:53:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:24:57 --> Config Class Initialized
INFO - 2025-01-13 11:24:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:24:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:24:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:24:57 --> URI Class Initialized
INFO - 2025-01-13 11:24:57 --> Router Class Initialized
INFO - 2025-01-13 11:24:57 --> Output Class Initialized
INFO - 2025-01-13 11:24:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:24:57 --> Input Class Initialized
INFO - 2025-01-13 11:24:57 --> Language Class Initialized
INFO - 2025-01-13 11:24:57 --> Loader Class Initialized
INFO - 2025-01-13 11:24:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:24:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:24:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:24:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:24:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:24:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:24:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:24:57 --> Upload Class Initialized
INFO - 2025-01-13 11:24:57 --> Email Class Initialized
INFO - 2025-01-13 11:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:24:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:24:57 --> Controller Class Initialized
INFO - 2025-01-13 16:54:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:54:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:54:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:25:57 --> Config Class Initialized
INFO - 2025-01-13 11:25:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:25:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:25:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:25:57 --> URI Class Initialized
INFO - 2025-01-13 11:25:57 --> Router Class Initialized
INFO - 2025-01-13 11:25:57 --> Output Class Initialized
INFO - 2025-01-13 11:25:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:25:57 --> Input Class Initialized
INFO - 2025-01-13 11:25:57 --> Language Class Initialized
INFO - 2025-01-13 11:25:57 --> Loader Class Initialized
INFO - 2025-01-13 11:25:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:25:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:25:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:25:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:25:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:25:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:25:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:25:57 --> Upload Class Initialized
INFO - 2025-01-13 11:25:57 --> Email Class Initialized
INFO - 2025-01-13 11:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:25:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:25:57 --> Controller Class Initialized
INFO - 2025-01-13 16:55:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:55:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:55:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:26:57 --> Config Class Initialized
INFO - 2025-01-13 11:26:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:26:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:26:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:26:57 --> URI Class Initialized
INFO - 2025-01-13 11:26:57 --> Router Class Initialized
INFO - 2025-01-13 11:26:57 --> Output Class Initialized
INFO - 2025-01-13 11:26:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:26:57 --> Input Class Initialized
INFO - 2025-01-13 11:26:57 --> Language Class Initialized
INFO - 2025-01-13 11:26:57 --> Loader Class Initialized
INFO - 2025-01-13 11:26:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:26:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:26:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:26:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:26:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:26:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:26:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:26:57 --> Upload Class Initialized
INFO - 2025-01-13 11:26:57 --> Email Class Initialized
INFO - 2025-01-13 11:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:26:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:26:57 --> Controller Class Initialized
INFO - 2025-01-13 16:56:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:56:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:56:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:27:57 --> Config Class Initialized
INFO - 2025-01-13 11:27:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:27:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:27:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:27:57 --> URI Class Initialized
INFO - 2025-01-13 11:27:57 --> Router Class Initialized
INFO - 2025-01-13 11:27:57 --> Output Class Initialized
INFO - 2025-01-13 11:27:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:27:57 --> Input Class Initialized
INFO - 2025-01-13 11:27:57 --> Language Class Initialized
INFO - 2025-01-13 11:27:57 --> Loader Class Initialized
INFO - 2025-01-13 11:27:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:27:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:27:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:27:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:27:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:27:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:27:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:27:57 --> Upload Class Initialized
INFO - 2025-01-13 11:27:57 --> Email Class Initialized
INFO - 2025-01-13 11:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:27:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:27:57 --> Controller Class Initialized
INFO - 2025-01-13 16:57:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:57:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:57:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:57:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:28:14 --> Config Class Initialized
INFO - 2025-01-13 11:28:14 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:28:14 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:28:14 --> Utf8 Class Initialized
INFO - 2025-01-13 11:28:14 --> URI Class Initialized
INFO - 2025-01-13 11:28:14 --> Router Class Initialized
INFO - 2025-01-13 11:28:14 --> Output Class Initialized
INFO - 2025-01-13 11:28:14 --> Security Class Initialized
DEBUG - 2025-01-13 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:28:14 --> Input Class Initialized
INFO - 2025-01-13 11:28:14 --> Language Class Initialized
INFO - 2025-01-13 11:28:14 --> Loader Class Initialized
INFO - 2025-01-13 11:28:14 --> Helper loaded: url_helper
INFO - 2025-01-13 11:28:14 --> Helper loaded: html_helper
INFO - 2025-01-13 11:28:14 --> Helper loaded: file_helper
INFO - 2025-01-13 11:28:14 --> Helper loaded: string_helper
INFO - 2025-01-13 11:28:14 --> Helper loaded: form_helper
INFO - 2025-01-13 11:28:14 --> Helper loaded: my_helper
INFO - 2025-01-13 11:28:14 --> Database Driver Class Initialized
INFO - 2025-01-13 11:28:14 --> Upload Class Initialized
INFO - 2025-01-13 11:28:14 --> Email Class Initialized
INFO - 2025-01-13 11:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:28:14 --> Form Validation Class Initialized
INFO - 2025-01-13 11:28:14 --> Controller Class Initialized
INFO - 2025-01-13 16:58:14 --> Model "ApiModel" initialized
INFO - 2025-01-13 16:58:14 --> Helper loaded: notification_helper
INFO - 2025-01-13 16:58:14 --> Model "MainModel" initialized
INFO - 2025-01-13 11:28:57 --> Config Class Initialized
INFO - 2025-01-13 11:28:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:28:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:28:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:28:57 --> URI Class Initialized
INFO - 2025-01-13 11:28:57 --> Router Class Initialized
INFO - 2025-01-13 11:28:57 --> Output Class Initialized
INFO - 2025-01-13 11:28:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:28:57 --> Input Class Initialized
INFO - 2025-01-13 11:28:57 --> Language Class Initialized
INFO - 2025-01-13 11:28:57 --> Loader Class Initialized
INFO - 2025-01-13 11:28:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:28:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:28:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:28:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:28:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:28:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:28:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:28:57 --> Upload Class Initialized
INFO - 2025-01-13 11:28:57 --> Email Class Initialized
INFO - 2025-01-13 11:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:28:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:28:57 --> Controller Class Initialized
INFO - 2025-01-13 16:58:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:58:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:58:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:29:57 --> Config Class Initialized
INFO - 2025-01-13 11:29:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:29:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:29:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:29:57 --> URI Class Initialized
INFO - 2025-01-13 11:29:57 --> Router Class Initialized
INFO - 2025-01-13 11:29:57 --> Output Class Initialized
INFO - 2025-01-13 11:29:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:29:57 --> Input Class Initialized
INFO - 2025-01-13 11:29:57 --> Language Class Initialized
INFO - 2025-01-13 11:29:57 --> Loader Class Initialized
INFO - 2025-01-13 11:29:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:29:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:29:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:29:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:29:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:29:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:29:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:29:57 --> Upload Class Initialized
INFO - 2025-01-13 11:29:57 --> Email Class Initialized
INFO - 2025-01-13 11:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:29:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:29:57 --> Controller Class Initialized
INFO - 2025-01-13 16:59:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 16:59:57 --> Model "MainModel" initialized
INFO - 2025-01-13 16:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 16:59:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:30:57 --> Config Class Initialized
INFO - 2025-01-13 11:30:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:30:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:30:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:30:57 --> URI Class Initialized
INFO - 2025-01-13 11:30:57 --> Router Class Initialized
INFO - 2025-01-13 11:30:57 --> Output Class Initialized
INFO - 2025-01-13 11:30:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:30:57 --> Input Class Initialized
INFO - 2025-01-13 11:30:57 --> Language Class Initialized
INFO - 2025-01-13 11:30:57 --> Loader Class Initialized
INFO - 2025-01-13 11:30:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:30:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:30:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:30:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:30:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:30:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:30:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:30:57 --> Upload Class Initialized
INFO - 2025-01-13 11:30:57 --> Email Class Initialized
INFO - 2025-01-13 11:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:30:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:30:57 --> Controller Class Initialized
INFO - 2025-01-13 17:00:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:00:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:00:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:31:57 --> Config Class Initialized
INFO - 2025-01-13 11:31:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:31:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:31:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:31:57 --> URI Class Initialized
INFO - 2025-01-13 11:31:57 --> Router Class Initialized
INFO - 2025-01-13 11:31:57 --> Output Class Initialized
INFO - 2025-01-13 11:31:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:31:57 --> Input Class Initialized
INFO - 2025-01-13 11:31:57 --> Language Class Initialized
INFO - 2025-01-13 11:31:57 --> Loader Class Initialized
INFO - 2025-01-13 11:31:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:31:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:31:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:31:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:31:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:31:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:31:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:31:57 --> Upload Class Initialized
INFO - 2025-01-13 11:31:57 --> Email Class Initialized
INFO - 2025-01-13 11:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:31:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:31:57 --> Controller Class Initialized
INFO - 2025-01-13 17:01:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:01:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:01:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:32:57 --> Config Class Initialized
INFO - 2025-01-13 11:32:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:32:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:32:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:32:57 --> URI Class Initialized
INFO - 2025-01-13 11:32:57 --> Router Class Initialized
INFO - 2025-01-13 11:32:57 --> Output Class Initialized
INFO - 2025-01-13 11:32:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:32:57 --> Input Class Initialized
INFO - 2025-01-13 11:32:57 --> Language Class Initialized
INFO - 2025-01-13 11:32:57 --> Loader Class Initialized
INFO - 2025-01-13 11:32:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:32:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:32:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:32:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:32:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:32:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:32:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:32:57 --> Upload Class Initialized
INFO - 2025-01-13 11:32:57 --> Email Class Initialized
INFO - 2025-01-13 11:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:32:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:32:57 --> Controller Class Initialized
INFO - 2025-01-13 17:02:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:02:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:02:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:39:34 --> Config Class Initialized
INFO - 2025-01-13 11:39:34 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:39:34 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:39:34 --> Utf8 Class Initialized
INFO - 2025-01-13 11:39:34 --> URI Class Initialized
INFO - 2025-01-13 11:39:34 --> Router Class Initialized
INFO - 2025-01-13 11:39:34 --> Output Class Initialized
INFO - 2025-01-13 11:39:34 --> Security Class Initialized
DEBUG - 2025-01-13 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:39:34 --> Input Class Initialized
INFO - 2025-01-13 11:39:34 --> Language Class Initialized
INFO - 2025-01-13 11:39:34 --> Loader Class Initialized
INFO - 2025-01-13 11:39:34 --> Helper loaded: url_helper
INFO - 2025-01-13 11:39:34 --> Helper loaded: html_helper
INFO - 2025-01-13 11:39:34 --> Helper loaded: file_helper
INFO - 2025-01-13 11:39:34 --> Helper loaded: string_helper
INFO - 2025-01-13 11:39:34 --> Helper loaded: form_helper
INFO - 2025-01-13 11:39:34 --> Helper loaded: my_helper
INFO - 2025-01-13 11:39:34 --> Database Driver Class Initialized
INFO - 2025-01-13 11:39:34 --> Upload Class Initialized
INFO - 2025-01-13 11:39:34 --> Email Class Initialized
INFO - 2025-01-13 11:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:39:34 --> Form Validation Class Initialized
INFO - 2025-01-13 11:39:34 --> Controller Class Initialized
INFO - 2025-01-13 17:09:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:09:34 --> Model "MainModel" initialized
INFO - 2025-01-13 17:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:09:34 --> Pagination Class Initialized
INFO - 2025-01-13 11:39:57 --> Config Class Initialized
INFO - 2025-01-13 11:39:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:39:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:39:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:39:57 --> URI Class Initialized
INFO - 2025-01-13 11:39:57 --> Router Class Initialized
INFO - 2025-01-13 11:39:57 --> Output Class Initialized
INFO - 2025-01-13 11:39:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:39:57 --> Input Class Initialized
INFO - 2025-01-13 11:39:57 --> Language Class Initialized
INFO - 2025-01-13 11:39:57 --> Loader Class Initialized
INFO - 2025-01-13 11:39:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:39:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:39:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:39:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:39:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:39:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:39:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:39:57 --> Upload Class Initialized
INFO - 2025-01-13 11:39:57 --> Email Class Initialized
INFO - 2025-01-13 11:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:39:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:39:57 --> Controller Class Initialized
INFO - 2025-01-13 17:09:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:09:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:09:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:40:57 --> Config Class Initialized
INFO - 2025-01-13 11:40:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:40:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:40:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:40:57 --> URI Class Initialized
INFO - 2025-01-13 11:40:57 --> Router Class Initialized
INFO - 2025-01-13 11:40:57 --> Output Class Initialized
INFO - 2025-01-13 11:40:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:40:57 --> Input Class Initialized
INFO - 2025-01-13 11:40:57 --> Language Class Initialized
INFO - 2025-01-13 11:40:57 --> Loader Class Initialized
INFO - 2025-01-13 11:40:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:40:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:40:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:40:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:40:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:40:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:40:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:40:57 --> Upload Class Initialized
INFO - 2025-01-13 11:40:57 --> Email Class Initialized
INFO - 2025-01-13 11:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:40:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:40:57 --> Controller Class Initialized
INFO - 2025-01-13 17:10:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:10:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:10:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:41:57 --> Config Class Initialized
INFO - 2025-01-13 11:41:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:41:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:41:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:41:57 --> URI Class Initialized
INFO - 2025-01-13 11:41:57 --> Router Class Initialized
INFO - 2025-01-13 11:41:57 --> Output Class Initialized
INFO - 2025-01-13 11:41:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:41:57 --> Input Class Initialized
INFO - 2025-01-13 11:41:57 --> Language Class Initialized
INFO - 2025-01-13 11:41:57 --> Loader Class Initialized
INFO - 2025-01-13 11:41:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:41:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:41:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:41:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:41:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:41:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:41:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:41:57 --> Upload Class Initialized
INFO - 2025-01-13 11:41:57 --> Email Class Initialized
INFO - 2025-01-13 11:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:41:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:41:57 --> Controller Class Initialized
INFO - 2025-01-13 17:11:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:11:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:11:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:42:57 --> Config Class Initialized
INFO - 2025-01-13 11:42:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:42:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:42:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:42:57 --> URI Class Initialized
INFO - 2025-01-13 11:42:57 --> Router Class Initialized
INFO - 2025-01-13 11:42:57 --> Output Class Initialized
INFO - 2025-01-13 11:42:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:42:57 --> Input Class Initialized
INFO - 2025-01-13 11:42:57 --> Language Class Initialized
INFO - 2025-01-13 11:42:57 --> Loader Class Initialized
INFO - 2025-01-13 11:42:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:42:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:42:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:42:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:42:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:42:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:42:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:42:57 --> Upload Class Initialized
INFO - 2025-01-13 11:42:57 --> Email Class Initialized
INFO - 2025-01-13 11:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:42:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:42:57 --> Controller Class Initialized
INFO - 2025-01-13 17:12:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:12:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:12:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:43:13 --> Config Class Initialized
INFO - 2025-01-13 11:43:13 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:43:13 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:43:13 --> Utf8 Class Initialized
INFO - 2025-01-13 11:43:13 --> URI Class Initialized
INFO - 2025-01-13 11:43:13 --> Router Class Initialized
INFO - 2025-01-13 11:43:13 --> Output Class Initialized
INFO - 2025-01-13 11:43:13 --> Security Class Initialized
DEBUG - 2025-01-13 11:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:43:13 --> Input Class Initialized
INFO - 2025-01-13 11:43:13 --> Language Class Initialized
INFO - 2025-01-13 11:43:13 --> Loader Class Initialized
INFO - 2025-01-13 11:43:13 --> Helper loaded: url_helper
INFO - 2025-01-13 11:43:13 --> Helper loaded: html_helper
INFO - 2025-01-13 11:43:13 --> Helper loaded: file_helper
INFO - 2025-01-13 11:43:13 --> Helper loaded: string_helper
INFO - 2025-01-13 11:43:13 --> Helper loaded: form_helper
INFO - 2025-01-13 11:43:13 --> Helper loaded: my_helper
INFO - 2025-01-13 11:43:13 --> Database Driver Class Initialized
INFO - 2025-01-13 11:43:13 --> Upload Class Initialized
INFO - 2025-01-13 11:43:13 --> Email Class Initialized
INFO - 2025-01-13 11:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:43:13 --> Form Validation Class Initialized
INFO - 2025-01-13 11:43:13 --> Controller Class Initialized
INFO - 2025-01-13 17:13:13 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:13:13 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:13:13 --> Model "MainModel" initialized
INFO - 2025-01-13 11:43:57 --> Config Class Initialized
INFO - 2025-01-13 11:43:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:43:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:43:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:43:57 --> URI Class Initialized
INFO - 2025-01-13 11:43:57 --> Router Class Initialized
INFO - 2025-01-13 11:43:57 --> Output Class Initialized
INFO - 2025-01-13 11:43:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:43:57 --> Input Class Initialized
INFO - 2025-01-13 11:43:57 --> Language Class Initialized
INFO - 2025-01-13 11:43:57 --> Loader Class Initialized
INFO - 2025-01-13 11:43:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:43:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:43:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:43:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:43:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:43:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:43:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:43:57 --> Upload Class Initialized
INFO - 2025-01-13 11:43:57 --> Email Class Initialized
INFO - 2025-01-13 11:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:43:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:43:57 --> Controller Class Initialized
INFO - 2025-01-13 17:13:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:13:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:13:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:44:57 --> Config Class Initialized
INFO - 2025-01-13 11:44:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:44:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:44:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:44:57 --> URI Class Initialized
INFO - 2025-01-13 11:44:57 --> Router Class Initialized
INFO - 2025-01-13 11:44:57 --> Output Class Initialized
INFO - 2025-01-13 11:44:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:44:57 --> Input Class Initialized
INFO - 2025-01-13 11:44:57 --> Language Class Initialized
INFO - 2025-01-13 11:44:57 --> Loader Class Initialized
INFO - 2025-01-13 11:44:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:44:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:44:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:44:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:44:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:44:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:44:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:44:57 --> Upload Class Initialized
INFO - 2025-01-13 11:44:57 --> Email Class Initialized
INFO - 2025-01-13 11:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:44:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:44:57 --> Controller Class Initialized
INFO - 2025-01-13 17:14:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:14:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:14:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:14:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:45:57 --> Config Class Initialized
INFO - 2025-01-13 11:45:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:45:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:45:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:45:57 --> URI Class Initialized
INFO - 2025-01-13 11:45:57 --> Router Class Initialized
INFO - 2025-01-13 11:45:57 --> Output Class Initialized
INFO - 2025-01-13 11:45:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:45:57 --> Input Class Initialized
INFO - 2025-01-13 11:45:57 --> Language Class Initialized
INFO - 2025-01-13 11:45:57 --> Loader Class Initialized
INFO - 2025-01-13 11:45:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:45:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:45:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:45:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:45:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:45:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:45:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:45:57 --> Upload Class Initialized
INFO - 2025-01-13 11:45:57 --> Email Class Initialized
INFO - 2025-01-13 11:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:45:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:45:57 --> Controller Class Initialized
INFO - 2025-01-13 17:15:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:15:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:15:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:46:57 --> Config Class Initialized
INFO - 2025-01-13 11:46:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:46:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:46:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:46:57 --> URI Class Initialized
INFO - 2025-01-13 11:46:57 --> Router Class Initialized
INFO - 2025-01-13 11:46:57 --> Output Class Initialized
INFO - 2025-01-13 11:46:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:46:57 --> Input Class Initialized
INFO - 2025-01-13 11:46:57 --> Language Class Initialized
INFO - 2025-01-13 11:46:57 --> Loader Class Initialized
INFO - 2025-01-13 11:46:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:46:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:46:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:46:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:46:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:46:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:46:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:46:57 --> Upload Class Initialized
INFO - 2025-01-13 11:46:57 --> Email Class Initialized
INFO - 2025-01-13 11:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:46:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:46:57 --> Controller Class Initialized
INFO - 2025-01-13 17:16:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:16:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:16:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:47:57 --> Config Class Initialized
INFO - 2025-01-13 11:47:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:47:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:47:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:47:57 --> URI Class Initialized
INFO - 2025-01-13 11:47:57 --> Router Class Initialized
INFO - 2025-01-13 11:47:57 --> Output Class Initialized
INFO - 2025-01-13 11:47:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:47:57 --> Input Class Initialized
INFO - 2025-01-13 11:47:57 --> Language Class Initialized
INFO - 2025-01-13 11:47:57 --> Loader Class Initialized
INFO - 2025-01-13 11:47:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:47:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:47:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:47:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:47:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:47:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:47:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:47:57 --> Upload Class Initialized
INFO - 2025-01-13 11:47:57 --> Email Class Initialized
INFO - 2025-01-13 11:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:47:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:47:57 --> Controller Class Initialized
INFO - 2025-01-13 17:17:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:17:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:17:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:48:57 --> Config Class Initialized
INFO - 2025-01-13 11:48:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:48:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:48:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:48:57 --> URI Class Initialized
INFO - 2025-01-13 11:48:57 --> Router Class Initialized
INFO - 2025-01-13 11:48:57 --> Output Class Initialized
INFO - 2025-01-13 11:48:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:48:57 --> Input Class Initialized
INFO - 2025-01-13 11:48:57 --> Language Class Initialized
INFO - 2025-01-13 11:48:57 --> Loader Class Initialized
INFO - 2025-01-13 11:48:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:48:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:48:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:48:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:48:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:48:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:48:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:48:57 --> Upload Class Initialized
INFO - 2025-01-13 11:48:57 --> Email Class Initialized
INFO - 2025-01-13 11:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:48:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:48:57 --> Controller Class Initialized
INFO - 2025-01-13 17:18:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:18:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:18:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:50:11 --> Config Class Initialized
INFO - 2025-01-13 11:50:11 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:50:11 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:50:11 --> Utf8 Class Initialized
INFO - 2025-01-13 11:50:11 --> URI Class Initialized
INFO - 2025-01-13 11:50:11 --> Router Class Initialized
INFO - 2025-01-13 11:50:11 --> Output Class Initialized
INFO - 2025-01-13 11:50:11 --> Security Class Initialized
DEBUG - 2025-01-13 11:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:50:11 --> Input Class Initialized
INFO - 2025-01-13 11:50:11 --> Language Class Initialized
INFO - 2025-01-13 11:50:11 --> Loader Class Initialized
INFO - 2025-01-13 11:50:11 --> Helper loaded: url_helper
INFO - 2025-01-13 11:50:11 --> Helper loaded: html_helper
INFO - 2025-01-13 11:50:11 --> Helper loaded: file_helper
INFO - 2025-01-13 11:50:11 --> Helper loaded: string_helper
INFO - 2025-01-13 11:50:11 --> Helper loaded: form_helper
INFO - 2025-01-13 11:50:11 --> Helper loaded: my_helper
INFO - 2025-01-13 11:50:11 --> Database Driver Class Initialized
INFO - 2025-01-13 11:50:11 --> Upload Class Initialized
INFO - 2025-01-13 11:50:11 --> Email Class Initialized
INFO - 2025-01-13 11:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:50:11 --> Form Validation Class Initialized
INFO - 2025-01-13 11:50:11 --> Controller Class Initialized
INFO - 2025-01-13 17:20:11 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:20:11 --> Model "MainModel" initialized
INFO - 2025-01-13 17:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:20:11 --> Pagination Class Initialized
INFO - 2025-01-13 11:50:57 --> Config Class Initialized
INFO - 2025-01-13 11:50:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:50:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:50:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:50:57 --> URI Class Initialized
INFO - 2025-01-13 11:50:57 --> Router Class Initialized
INFO - 2025-01-13 11:50:57 --> Output Class Initialized
INFO - 2025-01-13 11:50:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:50:57 --> Input Class Initialized
INFO - 2025-01-13 11:50:57 --> Language Class Initialized
INFO - 2025-01-13 11:50:57 --> Loader Class Initialized
INFO - 2025-01-13 11:50:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:50:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:50:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:50:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:50:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:50:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:50:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:50:57 --> Upload Class Initialized
INFO - 2025-01-13 11:50:57 --> Email Class Initialized
INFO - 2025-01-13 11:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:50:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:50:57 --> Controller Class Initialized
INFO - 2025-01-13 17:20:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:20:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:20:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:51:57 --> Config Class Initialized
INFO - 2025-01-13 11:51:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:51:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:51:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:51:57 --> URI Class Initialized
INFO - 2025-01-13 11:51:57 --> Router Class Initialized
INFO - 2025-01-13 11:51:57 --> Output Class Initialized
INFO - 2025-01-13 11:51:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:51:57 --> Input Class Initialized
INFO - 2025-01-13 11:51:57 --> Language Class Initialized
INFO - 2025-01-13 11:51:57 --> Loader Class Initialized
INFO - 2025-01-13 11:51:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:51:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:51:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:51:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:51:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:51:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:51:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:51:57 --> Upload Class Initialized
INFO - 2025-01-13 11:51:57 --> Email Class Initialized
INFO - 2025-01-13 11:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:51:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:51:57 --> Controller Class Initialized
INFO - 2025-01-13 17:21:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:21:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:21:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:52:57 --> Config Class Initialized
INFO - 2025-01-13 11:52:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:52:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:52:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:52:57 --> URI Class Initialized
INFO - 2025-01-13 11:52:57 --> Router Class Initialized
INFO - 2025-01-13 11:52:57 --> Output Class Initialized
INFO - 2025-01-13 11:52:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:52:57 --> Input Class Initialized
INFO - 2025-01-13 11:52:57 --> Language Class Initialized
INFO - 2025-01-13 11:52:57 --> Loader Class Initialized
INFO - 2025-01-13 11:52:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:52:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:52:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:52:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:52:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:52:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:52:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:52:57 --> Upload Class Initialized
INFO - 2025-01-13 11:52:57 --> Email Class Initialized
INFO - 2025-01-13 11:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:52:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:52:57 --> Controller Class Initialized
INFO - 2025-01-13 17:22:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:22:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:22:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:53:57 --> Config Class Initialized
INFO - 2025-01-13 11:53:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:53:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:53:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:53:57 --> URI Class Initialized
INFO - 2025-01-13 11:53:57 --> Router Class Initialized
INFO - 2025-01-13 11:53:57 --> Output Class Initialized
INFO - 2025-01-13 11:53:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:53:57 --> Input Class Initialized
INFO - 2025-01-13 11:53:57 --> Language Class Initialized
INFO - 2025-01-13 11:53:57 --> Loader Class Initialized
INFO - 2025-01-13 11:53:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:53:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:53:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:53:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:53:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:53:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:53:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:53:57 --> Upload Class Initialized
INFO - 2025-01-13 11:53:57 --> Email Class Initialized
INFO - 2025-01-13 11:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:53:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:53:57 --> Controller Class Initialized
INFO - 2025-01-13 17:23:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:23:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:23:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:54:00 --> Config Class Initialized
INFO - 2025-01-13 11:54:00 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:54:00 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:54:00 --> Utf8 Class Initialized
INFO - 2025-01-13 11:54:00 --> URI Class Initialized
INFO - 2025-01-13 11:54:00 --> Router Class Initialized
INFO - 2025-01-13 11:54:00 --> Output Class Initialized
INFO - 2025-01-13 11:54:00 --> Security Class Initialized
DEBUG - 2025-01-13 11:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:54:00 --> Input Class Initialized
INFO - 2025-01-13 11:54:00 --> Language Class Initialized
INFO - 2025-01-13 11:54:00 --> Loader Class Initialized
INFO - 2025-01-13 11:54:00 --> Helper loaded: url_helper
INFO - 2025-01-13 11:54:00 --> Helper loaded: html_helper
INFO - 2025-01-13 11:54:00 --> Helper loaded: file_helper
INFO - 2025-01-13 11:54:00 --> Helper loaded: string_helper
INFO - 2025-01-13 11:54:00 --> Helper loaded: form_helper
INFO - 2025-01-13 11:54:00 --> Helper loaded: my_helper
INFO - 2025-01-13 11:54:00 --> Database Driver Class Initialized
INFO - 2025-01-13 11:54:00 --> Upload Class Initialized
INFO - 2025-01-13 11:54:00 --> Email Class Initialized
INFO - 2025-01-13 11:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:54:00 --> Form Validation Class Initialized
INFO - 2025-01-13 11:54:00 --> Controller Class Initialized
INFO - 2025-01-13 17:24:00 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:24:00 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:24:00 --> Model "MainModel" initialized
INFO - 2025-01-13 11:54:35 --> Config Class Initialized
INFO - 2025-01-13 11:54:35 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:54:35 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:54:35 --> Utf8 Class Initialized
INFO - 2025-01-13 11:54:35 --> URI Class Initialized
INFO - 2025-01-13 11:54:35 --> Router Class Initialized
INFO - 2025-01-13 11:54:35 --> Output Class Initialized
INFO - 2025-01-13 11:54:35 --> Security Class Initialized
DEBUG - 2025-01-13 11:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:54:35 --> Input Class Initialized
INFO - 2025-01-13 11:54:35 --> Language Class Initialized
INFO - 2025-01-13 11:54:35 --> Loader Class Initialized
INFO - 2025-01-13 11:54:35 --> Helper loaded: url_helper
INFO - 2025-01-13 11:54:35 --> Helper loaded: html_helper
INFO - 2025-01-13 11:54:35 --> Helper loaded: file_helper
INFO - 2025-01-13 11:54:35 --> Helper loaded: string_helper
INFO - 2025-01-13 11:54:35 --> Helper loaded: form_helper
INFO - 2025-01-13 11:54:35 --> Helper loaded: my_helper
INFO - 2025-01-13 11:54:35 --> Database Driver Class Initialized
INFO - 2025-01-13 11:54:35 --> Upload Class Initialized
INFO - 2025-01-13 11:54:35 --> Email Class Initialized
INFO - 2025-01-13 11:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:54:35 --> Form Validation Class Initialized
INFO - 2025-01-13 11:54:35 --> Controller Class Initialized
INFO - 2025-01-13 17:24:35 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:24:35 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:24:35 --> Model "MainModel" initialized
INFO - 2025-01-13 11:54:57 --> Config Class Initialized
INFO - 2025-01-13 11:54:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:54:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:54:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:54:57 --> URI Class Initialized
INFO - 2025-01-13 11:54:57 --> Router Class Initialized
INFO - 2025-01-13 11:54:57 --> Output Class Initialized
INFO - 2025-01-13 11:54:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:54:57 --> Input Class Initialized
INFO - 2025-01-13 11:54:57 --> Language Class Initialized
INFO - 2025-01-13 11:54:57 --> Loader Class Initialized
INFO - 2025-01-13 11:54:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:54:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:54:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:54:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:54:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:54:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:54:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:54:57 --> Upload Class Initialized
INFO - 2025-01-13 11:54:57 --> Email Class Initialized
INFO - 2025-01-13 11:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:54:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:54:57 --> Controller Class Initialized
INFO - 2025-01-13 17:24:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:24:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:24:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:55:57 --> Config Class Initialized
INFO - 2025-01-13 11:55:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:55:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:55:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:55:57 --> URI Class Initialized
INFO - 2025-01-13 11:55:57 --> Router Class Initialized
INFO - 2025-01-13 11:55:57 --> Output Class Initialized
INFO - 2025-01-13 11:55:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:55:57 --> Input Class Initialized
INFO - 2025-01-13 11:55:57 --> Language Class Initialized
INFO - 2025-01-13 11:55:57 --> Loader Class Initialized
INFO - 2025-01-13 11:55:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:55:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:55:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:55:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:55:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:55:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:55:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:55:57 --> Upload Class Initialized
INFO - 2025-01-13 11:55:57 --> Email Class Initialized
INFO - 2025-01-13 11:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:55:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:55:57 --> Controller Class Initialized
INFO - 2025-01-13 17:25:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:25:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:25:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:56:57 --> Config Class Initialized
INFO - 2025-01-13 11:56:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:56:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:56:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:56:57 --> URI Class Initialized
INFO - 2025-01-13 11:56:57 --> Router Class Initialized
INFO - 2025-01-13 11:56:57 --> Output Class Initialized
INFO - 2025-01-13 11:56:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:56:57 --> Input Class Initialized
INFO - 2025-01-13 11:56:57 --> Language Class Initialized
INFO - 2025-01-13 11:56:57 --> Loader Class Initialized
INFO - 2025-01-13 11:56:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:56:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:56:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:56:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:56:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:56:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:56:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:56:57 --> Upload Class Initialized
INFO - 2025-01-13 11:56:57 --> Email Class Initialized
INFO - 2025-01-13 11:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:56:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:56:57 --> Controller Class Initialized
INFO - 2025-01-13 17:26:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:26:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:26:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:57:57 --> Config Class Initialized
INFO - 2025-01-13 11:57:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:57:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:57:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:57:57 --> URI Class Initialized
INFO - 2025-01-13 11:57:57 --> Router Class Initialized
INFO - 2025-01-13 11:57:57 --> Output Class Initialized
INFO - 2025-01-13 11:57:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:57:57 --> Input Class Initialized
INFO - 2025-01-13 11:57:57 --> Language Class Initialized
INFO - 2025-01-13 11:57:57 --> Loader Class Initialized
INFO - 2025-01-13 11:57:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:57:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:57:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:57:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:57:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:57:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:57:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:57:57 --> Upload Class Initialized
INFO - 2025-01-13 11:57:57 --> Email Class Initialized
INFO - 2025-01-13 11:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:57:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:57:57 --> Controller Class Initialized
INFO - 2025-01-13 17:27:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:27:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:27:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:58:57 --> Config Class Initialized
INFO - 2025-01-13 11:58:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:58:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:58:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:58:57 --> URI Class Initialized
INFO - 2025-01-13 11:58:57 --> Router Class Initialized
INFO - 2025-01-13 11:58:57 --> Output Class Initialized
INFO - 2025-01-13 11:58:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:58:57 --> Input Class Initialized
INFO - 2025-01-13 11:58:57 --> Language Class Initialized
INFO - 2025-01-13 11:58:57 --> Loader Class Initialized
INFO - 2025-01-13 11:58:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:58:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:58:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:58:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:58:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:58:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:58:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:58:57 --> Upload Class Initialized
INFO - 2025-01-13 11:58:57 --> Email Class Initialized
INFO - 2025-01-13 11:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:58:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:58:57 --> Controller Class Initialized
INFO - 2025-01-13 17:28:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:28:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:28:57 --> Pagination Class Initialized
INFO - 2025-01-13 11:59:57 --> Config Class Initialized
INFO - 2025-01-13 11:59:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 11:59:57 --> Utf8 Class Initialized
INFO - 2025-01-13 11:59:57 --> URI Class Initialized
INFO - 2025-01-13 11:59:57 --> Router Class Initialized
INFO - 2025-01-13 11:59:57 --> Output Class Initialized
INFO - 2025-01-13 11:59:57 --> Security Class Initialized
DEBUG - 2025-01-13 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 11:59:57 --> Input Class Initialized
INFO - 2025-01-13 11:59:57 --> Language Class Initialized
INFO - 2025-01-13 11:59:57 --> Loader Class Initialized
INFO - 2025-01-13 11:59:57 --> Helper loaded: url_helper
INFO - 2025-01-13 11:59:57 --> Helper loaded: html_helper
INFO - 2025-01-13 11:59:57 --> Helper loaded: file_helper
INFO - 2025-01-13 11:59:57 --> Helper loaded: string_helper
INFO - 2025-01-13 11:59:57 --> Helper loaded: form_helper
INFO - 2025-01-13 11:59:57 --> Helper loaded: my_helper
INFO - 2025-01-13 11:59:57 --> Database Driver Class Initialized
INFO - 2025-01-13 11:59:57 --> Upload Class Initialized
INFO - 2025-01-13 11:59:57 --> Email Class Initialized
INFO - 2025-01-13 11:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 11:59:57 --> Form Validation Class Initialized
INFO - 2025-01-13 11:59:57 --> Controller Class Initialized
INFO - 2025-01-13 17:29:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:29:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:29:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:00:57 --> Config Class Initialized
INFO - 2025-01-13 12:00:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:00:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:00:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:00:57 --> URI Class Initialized
INFO - 2025-01-13 12:00:57 --> Router Class Initialized
INFO - 2025-01-13 12:00:57 --> Output Class Initialized
INFO - 2025-01-13 12:00:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:00:57 --> Input Class Initialized
INFO - 2025-01-13 12:00:57 --> Language Class Initialized
INFO - 2025-01-13 12:00:57 --> Loader Class Initialized
INFO - 2025-01-13 12:00:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:00:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:00:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:00:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:00:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:00:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:00:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:00:57 --> Upload Class Initialized
INFO - 2025-01-13 12:00:57 --> Email Class Initialized
INFO - 2025-01-13 12:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:00:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:00:57 --> Controller Class Initialized
INFO - 2025-01-13 17:30:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:30:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:30:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:01:08 --> Config Class Initialized
INFO - 2025-01-13 12:01:08 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:01:08 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:01:08 --> Utf8 Class Initialized
INFO - 2025-01-13 12:01:08 --> URI Class Initialized
INFO - 2025-01-13 12:01:08 --> Router Class Initialized
INFO - 2025-01-13 12:01:08 --> Output Class Initialized
INFO - 2025-01-13 12:01:08 --> Security Class Initialized
DEBUG - 2025-01-13 12:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:01:08 --> Input Class Initialized
INFO - 2025-01-13 12:01:08 --> Language Class Initialized
INFO - 2025-01-13 12:01:08 --> Loader Class Initialized
INFO - 2025-01-13 12:01:08 --> Helper loaded: url_helper
INFO - 2025-01-13 12:01:08 --> Helper loaded: html_helper
INFO - 2025-01-13 12:01:08 --> Helper loaded: file_helper
INFO - 2025-01-13 12:01:08 --> Helper loaded: string_helper
INFO - 2025-01-13 12:01:08 --> Helper loaded: form_helper
INFO - 2025-01-13 12:01:08 --> Helper loaded: my_helper
INFO - 2025-01-13 12:01:08 --> Database Driver Class Initialized
INFO - 2025-01-13 12:01:08 --> Upload Class Initialized
INFO - 2025-01-13 12:01:08 --> Email Class Initialized
INFO - 2025-01-13 12:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:01:08 --> Form Validation Class Initialized
INFO - 2025-01-13 12:01:08 --> Controller Class Initialized
INFO - 2025-01-13 17:31:08 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:31:08 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:31:08 --> Model "MainModel" initialized
INFO - 2025-01-13 12:01:57 --> Config Class Initialized
INFO - 2025-01-13 12:01:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:01:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:01:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:01:57 --> URI Class Initialized
INFO - 2025-01-13 12:01:57 --> Router Class Initialized
INFO - 2025-01-13 12:01:57 --> Output Class Initialized
INFO - 2025-01-13 12:01:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:01:57 --> Input Class Initialized
INFO - 2025-01-13 12:01:57 --> Language Class Initialized
INFO - 2025-01-13 12:01:57 --> Loader Class Initialized
INFO - 2025-01-13 12:01:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:01:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:01:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:01:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:01:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:01:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:01:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:01:57 --> Upload Class Initialized
INFO - 2025-01-13 12:01:57 --> Email Class Initialized
INFO - 2025-01-13 12:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:01:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:01:57 --> Controller Class Initialized
INFO - 2025-01-13 17:31:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:31:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:31:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:02:57 --> Config Class Initialized
INFO - 2025-01-13 12:02:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:02:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:02:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:02:57 --> URI Class Initialized
INFO - 2025-01-13 12:02:57 --> Router Class Initialized
INFO - 2025-01-13 12:02:57 --> Output Class Initialized
INFO - 2025-01-13 12:02:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:02:57 --> Input Class Initialized
INFO - 2025-01-13 12:02:57 --> Language Class Initialized
INFO - 2025-01-13 12:02:57 --> Loader Class Initialized
INFO - 2025-01-13 12:02:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:02:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:02:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:02:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:02:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:02:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:02:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:02:57 --> Upload Class Initialized
INFO - 2025-01-13 12:02:57 --> Email Class Initialized
INFO - 2025-01-13 12:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:02:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:02:57 --> Controller Class Initialized
INFO - 2025-01-13 17:32:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:32:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:32:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:03:57 --> Config Class Initialized
INFO - 2025-01-13 12:03:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:03:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:03:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:03:57 --> URI Class Initialized
INFO - 2025-01-13 12:03:57 --> Router Class Initialized
INFO - 2025-01-13 12:03:57 --> Output Class Initialized
INFO - 2025-01-13 12:03:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:03:57 --> Input Class Initialized
INFO - 2025-01-13 12:03:57 --> Language Class Initialized
INFO - 2025-01-13 12:03:57 --> Loader Class Initialized
INFO - 2025-01-13 12:03:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:03:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:03:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:03:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:03:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:03:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:03:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:03:57 --> Upload Class Initialized
INFO - 2025-01-13 12:03:57 --> Email Class Initialized
INFO - 2025-01-13 12:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:03:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:03:57 --> Controller Class Initialized
INFO - 2025-01-13 17:33:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:33:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:33:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:04:57 --> Config Class Initialized
INFO - 2025-01-13 12:04:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:04:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:04:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:04:57 --> URI Class Initialized
INFO - 2025-01-13 12:04:57 --> Router Class Initialized
INFO - 2025-01-13 12:04:57 --> Output Class Initialized
INFO - 2025-01-13 12:04:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:04:57 --> Input Class Initialized
INFO - 2025-01-13 12:04:57 --> Language Class Initialized
INFO - 2025-01-13 12:04:57 --> Loader Class Initialized
INFO - 2025-01-13 12:04:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:04:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:04:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:04:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:04:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:04:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:04:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:04:57 --> Upload Class Initialized
INFO - 2025-01-13 12:04:57 --> Email Class Initialized
INFO - 2025-01-13 12:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:04:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:04:57 --> Controller Class Initialized
INFO - 2025-01-13 17:34:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:34:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:34:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:05:57 --> Config Class Initialized
INFO - 2025-01-13 12:05:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:05:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:05:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:05:57 --> URI Class Initialized
INFO - 2025-01-13 12:05:57 --> Router Class Initialized
INFO - 2025-01-13 12:05:57 --> Output Class Initialized
INFO - 2025-01-13 12:05:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:05:57 --> Input Class Initialized
INFO - 2025-01-13 12:05:57 --> Language Class Initialized
INFO - 2025-01-13 12:05:57 --> Loader Class Initialized
INFO - 2025-01-13 12:05:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:05:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:05:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:05:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:05:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:05:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:05:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:05:57 --> Upload Class Initialized
INFO - 2025-01-13 12:05:57 --> Email Class Initialized
INFO - 2025-01-13 12:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:05:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:05:57 --> Controller Class Initialized
INFO - 2025-01-13 17:35:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:35:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:35:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:06:57 --> Config Class Initialized
INFO - 2025-01-13 12:06:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:06:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:06:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:06:57 --> URI Class Initialized
INFO - 2025-01-13 12:06:57 --> Router Class Initialized
INFO - 2025-01-13 12:06:57 --> Output Class Initialized
INFO - 2025-01-13 12:06:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:06:57 --> Input Class Initialized
INFO - 2025-01-13 12:06:57 --> Language Class Initialized
INFO - 2025-01-13 12:06:57 --> Loader Class Initialized
INFO - 2025-01-13 12:06:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:06:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:06:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:06:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:06:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:06:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:06:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:06:57 --> Upload Class Initialized
INFO - 2025-01-13 12:06:57 --> Email Class Initialized
INFO - 2025-01-13 12:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:06:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:06:57 --> Controller Class Initialized
INFO - 2025-01-13 17:36:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:36:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:36:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:07:57 --> Config Class Initialized
INFO - 2025-01-13 12:07:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:07:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:07:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:07:57 --> URI Class Initialized
INFO - 2025-01-13 12:07:57 --> Router Class Initialized
INFO - 2025-01-13 12:07:57 --> Output Class Initialized
INFO - 2025-01-13 12:07:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:07:57 --> Input Class Initialized
INFO - 2025-01-13 12:07:57 --> Language Class Initialized
INFO - 2025-01-13 12:07:57 --> Loader Class Initialized
INFO - 2025-01-13 12:07:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:07:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:07:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:07:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:07:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:07:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:07:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:07:57 --> Upload Class Initialized
INFO - 2025-01-13 12:07:57 --> Email Class Initialized
INFO - 2025-01-13 12:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:07:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:07:57 --> Controller Class Initialized
INFO - 2025-01-13 17:37:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:37:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:37:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:08:57 --> Config Class Initialized
INFO - 2025-01-13 12:08:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:08:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:08:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:08:57 --> URI Class Initialized
INFO - 2025-01-13 12:08:57 --> Router Class Initialized
INFO - 2025-01-13 12:08:57 --> Output Class Initialized
INFO - 2025-01-13 12:08:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:08:57 --> Input Class Initialized
INFO - 2025-01-13 12:08:57 --> Language Class Initialized
INFO - 2025-01-13 12:08:57 --> Loader Class Initialized
INFO - 2025-01-13 12:08:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:08:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:08:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:08:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:08:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:08:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:08:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:08:57 --> Upload Class Initialized
INFO - 2025-01-13 12:08:57 --> Email Class Initialized
INFO - 2025-01-13 12:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:08:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:08:57 --> Controller Class Initialized
INFO - 2025-01-13 17:38:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:38:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:38:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:09:57 --> Config Class Initialized
INFO - 2025-01-13 12:09:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:09:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:09:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:09:57 --> URI Class Initialized
INFO - 2025-01-13 12:09:57 --> Router Class Initialized
INFO - 2025-01-13 12:09:57 --> Output Class Initialized
INFO - 2025-01-13 12:09:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:09:57 --> Input Class Initialized
INFO - 2025-01-13 12:09:57 --> Language Class Initialized
INFO - 2025-01-13 12:09:57 --> Loader Class Initialized
INFO - 2025-01-13 12:09:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:09:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:09:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:09:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:09:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:09:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:09:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:09:57 --> Upload Class Initialized
INFO - 2025-01-13 12:09:57 --> Email Class Initialized
INFO - 2025-01-13 12:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:09:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:09:57 --> Controller Class Initialized
INFO - 2025-01-13 17:39:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:39:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:39:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:39:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:10:57 --> Config Class Initialized
INFO - 2025-01-13 12:10:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:10:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:10:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:10:57 --> URI Class Initialized
INFO - 2025-01-13 12:10:57 --> Router Class Initialized
INFO - 2025-01-13 12:10:57 --> Output Class Initialized
INFO - 2025-01-13 12:10:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:10:57 --> Input Class Initialized
INFO - 2025-01-13 12:10:57 --> Language Class Initialized
INFO - 2025-01-13 12:10:57 --> Loader Class Initialized
INFO - 2025-01-13 12:10:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:10:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:10:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:10:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:10:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:10:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:10:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:10:57 --> Upload Class Initialized
INFO - 2025-01-13 12:10:57 --> Email Class Initialized
INFO - 2025-01-13 12:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:10:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:10:57 --> Controller Class Initialized
INFO - 2025-01-13 17:40:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:40:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:40:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:40:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:11:06 --> Config Class Initialized
INFO - 2025-01-13 12:11:06 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:11:06 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:11:06 --> Utf8 Class Initialized
INFO - 2025-01-13 12:11:06 --> URI Class Initialized
INFO - 2025-01-13 12:11:06 --> Router Class Initialized
INFO - 2025-01-13 12:11:06 --> Output Class Initialized
INFO - 2025-01-13 12:11:06 --> Security Class Initialized
DEBUG - 2025-01-13 12:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:11:06 --> Input Class Initialized
INFO - 2025-01-13 12:11:06 --> Language Class Initialized
INFO - 2025-01-13 12:11:06 --> Loader Class Initialized
INFO - 2025-01-13 12:11:06 --> Helper loaded: url_helper
INFO - 2025-01-13 12:11:06 --> Helper loaded: html_helper
INFO - 2025-01-13 12:11:06 --> Helper loaded: file_helper
INFO - 2025-01-13 12:11:06 --> Helper loaded: string_helper
INFO - 2025-01-13 12:11:06 --> Helper loaded: form_helper
INFO - 2025-01-13 12:11:06 --> Helper loaded: my_helper
INFO - 2025-01-13 12:11:06 --> Database Driver Class Initialized
INFO - 2025-01-13 12:11:06 --> Upload Class Initialized
INFO - 2025-01-13 12:11:06 --> Email Class Initialized
INFO - 2025-01-13 12:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:11:06 --> Form Validation Class Initialized
INFO - 2025-01-13 12:11:06 --> Controller Class Initialized
INFO - 2025-01-13 17:41:06 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:41:06 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:41:06 --> Model "MainModel" initialized
INFO - 2025-01-13 12:11:42 --> Config Class Initialized
INFO - 2025-01-13 12:11:42 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:11:42 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:11:42 --> Utf8 Class Initialized
INFO - 2025-01-13 12:11:42 --> URI Class Initialized
INFO - 2025-01-13 12:11:42 --> Router Class Initialized
INFO - 2025-01-13 12:11:42 --> Output Class Initialized
INFO - 2025-01-13 12:11:42 --> Security Class Initialized
DEBUG - 2025-01-13 12:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:11:42 --> Input Class Initialized
INFO - 2025-01-13 12:11:42 --> Language Class Initialized
INFO - 2025-01-13 12:11:42 --> Loader Class Initialized
INFO - 2025-01-13 12:11:42 --> Helper loaded: url_helper
INFO - 2025-01-13 12:11:42 --> Helper loaded: html_helper
INFO - 2025-01-13 12:11:42 --> Helper loaded: file_helper
INFO - 2025-01-13 12:11:42 --> Helper loaded: string_helper
INFO - 2025-01-13 12:11:42 --> Helper loaded: form_helper
INFO - 2025-01-13 12:11:42 --> Helper loaded: my_helper
INFO - 2025-01-13 12:11:42 --> Database Driver Class Initialized
INFO - 2025-01-13 12:11:42 --> Upload Class Initialized
INFO - 2025-01-13 12:11:42 --> Email Class Initialized
INFO - 2025-01-13 12:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:11:42 --> Form Validation Class Initialized
INFO - 2025-01-13 12:11:42 --> Controller Class Initialized
INFO - 2025-01-13 17:41:42 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:41:42 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:41:42 --> Model "MainModel" initialized
INFO - 2025-01-13 12:11:47 --> Config Class Initialized
INFO - 2025-01-13 12:11:47 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:11:47 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:11:47 --> Utf8 Class Initialized
INFO - 2025-01-13 12:11:47 --> URI Class Initialized
INFO - 2025-01-13 12:11:47 --> Router Class Initialized
INFO - 2025-01-13 12:11:47 --> Output Class Initialized
INFO - 2025-01-13 12:11:47 --> Security Class Initialized
DEBUG - 2025-01-13 12:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:11:47 --> Input Class Initialized
INFO - 2025-01-13 12:11:47 --> Language Class Initialized
INFO - 2025-01-13 12:11:47 --> Loader Class Initialized
INFO - 2025-01-13 12:11:47 --> Helper loaded: url_helper
INFO - 2025-01-13 12:11:47 --> Helper loaded: html_helper
INFO - 2025-01-13 12:11:47 --> Helper loaded: file_helper
INFO - 2025-01-13 12:11:47 --> Helper loaded: string_helper
INFO - 2025-01-13 12:11:47 --> Helper loaded: form_helper
INFO - 2025-01-13 12:11:47 --> Helper loaded: my_helper
INFO - 2025-01-13 12:11:47 --> Database Driver Class Initialized
INFO - 2025-01-13 12:11:47 --> Upload Class Initialized
INFO - 2025-01-13 12:11:47 --> Email Class Initialized
INFO - 2025-01-13 12:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:11:47 --> Form Validation Class Initialized
INFO - 2025-01-13 12:11:47 --> Controller Class Initialized
INFO - 2025-01-13 17:41:47 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:41:47 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:41:47 --> Model "MainModel" initialized
INFO - 2025-01-13 12:11:57 --> Config Class Initialized
INFO - 2025-01-13 12:11:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:11:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:11:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:11:57 --> URI Class Initialized
INFO - 2025-01-13 12:11:57 --> Router Class Initialized
INFO - 2025-01-13 12:11:57 --> Output Class Initialized
INFO - 2025-01-13 12:11:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:11:57 --> Input Class Initialized
INFO - 2025-01-13 12:11:57 --> Language Class Initialized
INFO - 2025-01-13 12:11:57 --> Loader Class Initialized
INFO - 2025-01-13 12:11:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:11:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:11:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:11:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:11:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:11:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:11:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:11:57 --> Upload Class Initialized
INFO - 2025-01-13 12:11:57 --> Email Class Initialized
INFO - 2025-01-13 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:11:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:11:57 --> Controller Class Initialized
INFO - 2025-01-13 17:41:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:41:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:41:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:12:19 --> Config Class Initialized
INFO - 2025-01-13 12:12:19 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:12:19 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:12:19 --> Utf8 Class Initialized
INFO - 2025-01-13 12:12:19 --> URI Class Initialized
INFO - 2025-01-13 12:12:19 --> Router Class Initialized
INFO - 2025-01-13 12:12:19 --> Output Class Initialized
INFO - 2025-01-13 12:12:19 --> Security Class Initialized
DEBUG - 2025-01-13 12:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:12:19 --> Input Class Initialized
INFO - 2025-01-13 12:12:19 --> Language Class Initialized
INFO - 2025-01-13 12:12:19 --> Loader Class Initialized
INFO - 2025-01-13 12:12:19 --> Helper loaded: url_helper
INFO - 2025-01-13 12:12:19 --> Helper loaded: html_helper
INFO - 2025-01-13 12:12:19 --> Helper loaded: file_helper
INFO - 2025-01-13 12:12:19 --> Helper loaded: string_helper
INFO - 2025-01-13 12:12:19 --> Helper loaded: form_helper
INFO - 2025-01-13 12:12:19 --> Helper loaded: my_helper
INFO - 2025-01-13 12:12:19 --> Database Driver Class Initialized
INFO - 2025-01-13 12:12:19 --> Upload Class Initialized
INFO - 2025-01-13 12:12:19 --> Email Class Initialized
INFO - 2025-01-13 12:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:12:19 --> Form Validation Class Initialized
INFO - 2025-01-13 12:12:19 --> Controller Class Initialized
INFO - 2025-01-13 17:42:19 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:42:19 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:42:19 --> Model "MainModel" initialized
INFO - 2025-01-13 12:12:57 --> Config Class Initialized
INFO - 2025-01-13 12:12:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:12:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:12:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:12:57 --> URI Class Initialized
INFO - 2025-01-13 12:12:57 --> Router Class Initialized
INFO - 2025-01-13 12:12:57 --> Output Class Initialized
INFO - 2025-01-13 12:12:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:12:57 --> Input Class Initialized
INFO - 2025-01-13 12:12:57 --> Language Class Initialized
INFO - 2025-01-13 12:12:57 --> Loader Class Initialized
INFO - 2025-01-13 12:12:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:12:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:12:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:12:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:12:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:12:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:12:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:12:57 --> Upload Class Initialized
INFO - 2025-01-13 12:12:57 --> Email Class Initialized
INFO - 2025-01-13 12:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:12:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:12:57 --> Controller Class Initialized
INFO - 2025-01-13 17:42:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:42:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:42:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:13:57 --> Config Class Initialized
INFO - 2025-01-13 12:13:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:13:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:13:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:13:57 --> URI Class Initialized
INFO - 2025-01-13 12:13:57 --> Router Class Initialized
INFO - 2025-01-13 12:13:57 --> Output Class Initialized
INFO - 2025-01-13 12:13:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:13:57 --> Input Class Initialized
INFO - 2025-01-13 12:13:57 --> Language Class Initialized
INFO - 2025-01-13 12:13:57 --> Loader Class Initialized
INFO - 2025-01-13 12:13:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:13:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:13:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:13:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:13:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:13:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:13:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:13:57 --> Upload Class Initialized
INFO - 2025-01-13 12:13:57 --> Email Class Initialized
INFO - 2025-01-13 12:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:13:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:13:57 --> Controller Class Initialized
INFO - 2025-01-13 17:43:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:43:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:43:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:14:57 --> Config Class Initialized
INFO - 2025-01-13 12:14:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:14:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:14:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:14:57 --> URI Class Initialized
INFO - 2025-01-13 12:14:57 --> Router Class Initialized
INFO - 2025-01-13 12:14:57 --> Output Class Initialized
INFO - 2025-01-13 12:14:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:14:57 --> Input Class Initialized
INFO - 2025-01-13 12:14:57 --> Language Class Initialized
INFO - 2025-01-13 12:14:57 --> Loader Class Initialized
INFO - 2025-01-13 12:14:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:14:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:14:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:14:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:14:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:14:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:14:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:14:57 --> Upload Class Initialized
INFO - 2025-01-13 12:14:57 --> Email Class Initialized
INFO - 2025-01-13 12:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:14:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:14:57 --> Controller Class Initialized
INFO - 2025-01-13 17:44:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:44:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:44:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:15:57 --> Config Class Initialized
INFO - 2025-01-13 12:15:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:15:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:15:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:15:57 --> URI Class Initialized
INFO - 2025-01-13 12:15:57 --> Router Class Initialized
INFO - 2025-01-13 12:15:57 --> Output Class Initialized
INFO - 2025-01-13 12:15:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:15:57 --> Input Class Initialized
INFO - 2025-01-13 12:15:57 --> Language Class Initialized
INFO - 2025-01-13 12:15:57 --> Loader Class Initialized
INFO - 2025-01-13 12:15:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:15:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:15:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:15:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:15:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:15:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:15:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:15:57 --> Upload Class Initialized
INFO - 2025-01-13 12:15:57 --> Email Class Initialized
INFO - 2025-01-13 12:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:15:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:15:57 --> Controller Class Initialized
INFO - 2025-01-13 17:45:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:45:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:45:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:16:57 --> Config Class Initialized
INFO - 2025-01-13 12:16:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:16:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:16:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:16:57 --> URI Class Initialized
INFO - 2025-01-13 12:16:57 --> Router Class Initialized
INFO - 2025-01-13 12:16:57 --> Output Class Initialized
INFO - 2025-01-13 12:16:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:16:57 --> Input Class Initialized
INFO - 2025-01-13 12:16:57 --> Language Class Initialized
INFO - 2025-01-13 12:16:57 --> Loader Class Initialized
INFO - 2025-01-13 12:16:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:16:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:16:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:16:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:16:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:16:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:16:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:16:57 --> Upload Class Initialized
INFO - 2025-01-13 12:16:57 --> Email Class Initialized
INFO - 2025-01-13 12:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:16:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:16:57 --> Controller Class Initialized
INFO - 2025-01-13 17:46:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:46:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:46:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:17:57 --> Config Class Initialized
INFO - 2025-01-13 12:17:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:17:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:17:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:17:57 --> URI Class Initialized
INFO - 2025-01-13 12:17:57 --> Router Class Initialized
INFO - 2025-01-13 12:17:57 --> Output Class Initialized
INFO - 2025-01-13 12:17:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:17:57 --> Input Class Initialized
INFO - 2025-01-13 12:17:57 --> Language Class Initialized
INFO - 2025-01-13 12:17:57 --> Loader Class Initialized
INFO - 2025-01-13 12:17:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:17:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:17:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:17:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:17:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:17:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:17:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:17:57 --> Upload Class Initialized
INFO - 2025-01-13 12:17:57 --> Email Class Initialized
INFO - 2025-01-13 12:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:17:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:17:57 --> Controller Class Initialized
INFO - 2025-01-13 17:47:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:47:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:47:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:18:57 --> Config Class Initialized
INFO - 2025-01-13 12:18:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:18:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:18:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:18:57 --> URI Class Initialized
INFO - 2025-01-13 12:18:57 --> Router Class Initialized
INFO - 2025-01-13 12:18:57 --> Output Class Initialized
INFO - 2025-01-13 12:18:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:18:57 --> Input Class Initialized
INFO - 2025-01-13 12:18:57 --> Language Class Initialized
INFO - 2025-01-13 12:18:57 --> Loader Class Initialized
INFO - 2025-01-13 12:18:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:18:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:18:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:18:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:18:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:18:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:18:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:18:57 --> Upload Class Initialized
INFO - 2025-01-13 12:18:57 --> Email Class Initialized
INFO - 2025-01-13 12:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:18:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:18:57 --> Controller Class Initialized
INFO - 2025-01-13 17:48:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:48:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:48:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:19:57 --> Config Class Initialized
INFO - 2025-01-13 12:19:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:19:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:19:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:19:57 --> URI Class Initialized
INFO - 2025-01-13 12:19:57 --> Router Class Initialized
INFO - 2025-01-13 12:19:57 --> Output Class Initialized
INFO - 2025-01-13 12:19:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:19:57 --> Input Class Initialized
INFO - 2025-01-13 12:19:57 --> Language Class Initialized
INFO - 2025-01-13 12:19:57 --> Loader Class Initialized
INFO - 2025-01-13 12:19:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:19:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:19:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:19:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:19:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:19:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:19:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:19:57 --> Upload Class Initialized
INFO - 2025-01-13 12:19:57 --> Email Class Initialized
INFO - 2025-01-13 12:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:19:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:19:57 --> Controller Class Initialized
INFO - 2025-01-13 17:49:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:49:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:49:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:20:57 --> Config Class Initialized
INFO - 2025-01-13 12:20:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:20:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:20:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:20:57 --> URI Class Initialized
INFO - 2025-01-13 12:20:57 --> Router Class Initialized
INFO - 2025-01-13 12:20:57 --> Output Class Initialized
INFO - 2025-01-13 12:20:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:20:57 --> Input Class Initialized
INFO - 2025-01-13 12:20:57 --> Language Class Initialized
INFO - 2025-01-13 12:20:57 --> Loader Class Initialized
INFO - 2025-01-13 12:20:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:20:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:20:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:20:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:20:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:20:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:20:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:20:57 --> Upload Class Initialized
INFO - 2025-01-13 12:20:57 --> Email Class Initialized
INFO - 2025-01-13 12:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:20:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:20:57 --> Controller Class Initialized
INFO - 2025-01-13 17:50:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:50:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:50:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:50:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:21:57 --> Config Class Initialized
INFO - 2025-01-13 12:21:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:21:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:21:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:21:57 --> URI Class Initialized
INFO - 2025-01-13 12:21:57 --> Router Class Initialized
INFO - 2025-01-13 12:21:57 --> Output Class Initialized
INFO - 2025-01-13 12:21:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:21:57 --> Input Class Initialized
INFO - 2025-01-13 12:21:57 --> Language Class Initialized
INFO - 2025-01-13 12:21:57 --> Loader Class Initialized
INFO - 2025-01-13 12:21:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:21:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:21:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:21:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:21:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:21:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:21:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:21:57 --> Upload Class Initialized
INFO - 2025-01-13 12:21:57 --> Email Class Initialized
INFO - 2025-01-13 12:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:21:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:21:57 --> Controller Class Initialized
INFO - 2025-01-13 17:51:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:51:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:51:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:22:57 --> Config Class Initialized
INFO - 2025-01-13 12:22:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:22:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:22:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:22:57 --> URI Class Initialized
INFO - 2025-01-13 12:22:57 --> Router Class Initialized
INFO - 2025-01-13 12:22:57 --> Output Class Initialized
INFO - 2025-01-13 12:22:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:22:57 --> Input Class Initialized
INFO - 2025-01-13 12:22:57 --> Language Class Initialized
INFO - 2025-01-13 12:22:57 --> Loader Class Initialized
INFO - 2025-01-13 12:22:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:22:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:22:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:22:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:22:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:22:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:22:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:22:57 --> Upload Class Initialized
INFO - 2025-01-13 12:22:57 --> Email Class Initialized
INFO - 2025-01-13 12:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:22:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:22:57 --> Controller Class Initialized
INFO - 2025-01-13 17:52:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:52:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:52:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:23:03 --> Config Class Initialized
INFO - 2025-01-13 12:23:03 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:23:03 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:23:03 --> Utf8 Class Initialized
INFO - 2025-01-13 12:23:03 --> URI Class Initialized
INFO - 2025-01-13 12:23:03 --> Router Class Initialized
INFO - 2025-01-13 12:23:03 --> Output Class Initialized
INFO - 2025-01-13 12:23:03 --> Security Class Initialized
DEBUG - 2025-01-13 12:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:23:03 --> Input Class Initialized
INFO - 2025-01-13 12:23:03 --> Language Class Initialized
INFO - 2025-01-13 12:23:03 --> Loader Class Initialized
INFO - 2025-01-13 12:23:03 --> Helper loaded: url_helper
INFO - 2025-01-13 12:23:03 --> Helper loaded: html_helper
INFO - 2025-01-13 12:23:03 --> Helper loaded: file_helper
INFO - 2025-01-13 12:23:03 --> Helper loaded: string_helper
INFO - 2025-01-13 12:23:03 --> Helper loaded: form_helper
INFO - 2025-01-13 12:23:03 --> Helper loaded: my_helper
INFO - 2025-01-13 12:23:03 --> Database Driver Class Initialized
INFO - 2025-01-13 12:23:03 --> Upload Class Initialized
INFO - 2025-01-13 12:23:03 --> Email Class Initialized
INFO - 2025-01-13 12:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:23:03 --> Form Validation Class Initialized
INFO - 2025-01-13 12:23:03 --> Controller Class Initialized
INFO - 2025-01-13 17:53:03 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:53:03 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:53:03 --> Model "MainModel" initialized
INFO - 2025-01-13 12:23:22 --> Config Class Initialized
INFO - 2025-01-13 12:23:22 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:23:22 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:23:22 --> Utf8 Class Initialized
INFO - 2025-01-13 12:23:22 --> URI Class Initialized
INFO - 2025-01-13 12:23:22 --> Router Class Initialized
INFO - 2025-01-13 12:23:22 --> Output Class Initialized
INFO - 2025-01-13 12:23:22 --> Security Class Initialized
DEBUG - 2025-01-13 12:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:23:22 --> Input Class Initialized
INFO - 2025-01-13 12:23:22 --> Language Class Initialized
INFO - 2025-01-13 12:23:22 --> Loader Class Initialized
INFO - 2025-01-13 12:23:22 --> Helper loaded: url_helper
INFO - 2025-01-13 12:23:22 --> Helper loaded: html_helper
INFO - 2025-01-13 12:23:22 --> Helper loaded: file_helper
INFO - 2025-01-13 12:23:22 --> Helper loaded: string_helper
INFO - 2025-01-13 12:23:22 --> Helper loaded: form_helper
INFO - 2025-01-13 12:23:22 --> Helper loaded: my_helper
INFO - 2025-01-13 12:23:22 --> Database Driver Class Initialized
INFO - 2025-01-13 12:23:22 --> Upload Class Initialized
INFO - 2025-01-13 12:23:22 --> Email Class Initialized
INFO - 2025-01-13 12:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:23:22 --> Form Validation Class Initialized
INFO - 2025-01-13 12:23:22 --> Controller Class Initialized
INFO - 2025-01-13 17:53:22 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:53:22 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:53:22 --> Model "MainModel" initialized
INFO - 2025-01-13 12:23:33 --> Config Class Initialized
INFO - 2025-01-13 12:23:33 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:23:33 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:23:33 --> Utf8 Class Initialized
INFO - 2025-01-13 12:23:33 --> URI Class Initialized
INFO - 2025-01-13 12:23:33 --> Router Class Initialized
INFO - 2025-01-13 12:23:33 --> Output Class Initialized
INFO - 2025-01-13 12:23:33 --> Security Class Initialized
DEBUG - 2025-01-13 12:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:23:33 --> Input Class Initialized
INFO - 2025-01-13 12:23:33 --> Language Class Initialized
INFO - 2025-01-13 12:23:33 --> Loader Class Initialized
INFO - 2025-01-13 12:23:33 --> Helper loaded: url_helper
INFO - 2025-01-13 12:23:33 --> Helper loaded: html_helper
INFO - 2025-01-13 12:23:33 --> Helper loaded: file_helper
INFO - 2025-01-13 12:23:33 --> Helper loaded: string_helper
INFO - 2025-01-13 12:23:33 --> Helper loaded: form_helper
INFO - 2025-01-13 12:23:33 --> Helper loaded: my_helper
INFO - 2025-01-13 12:23:33 --> Database Driver Class Initialized
INFO - 2025-01-13 12:23:33 --> Upload Class Initialized
INFO - 2025-01-13 12:23:33 --> Email Class Initialized
INFO - 2025-01-13 12:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:23:33 --> Form Validation Class Initialized
INFO - 2025-01-13 12:23:33 --> Controller Class Initialized
INFO - 2025-01-13 17:53:33 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:53:33 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:53:33 --> Model "MainModel" initialized
INFO - 2025-01-13 12:23:41 --> Config Class Initialized
INFO - 2025-01-13 12:23:41 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:23:41 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:23:41 --> Utf8 Class Initialized
INFO - 2025-01-13 12:23:41 --> URI Class Initialized
INFO - 2025-01-13 12:23:41 --> Router Class Initialized
INFO - 2025-01-13 12:23:41 --> Output Class Initialized
INFO - 2025-01-13 12:23:41 --> Security Class Initialized
DEBUG - 2025-01-13 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:23:41 --> Input Class Initialized
INFO - 2025-01-13 12:23:41 --> Language Class Initialized
INFO - 2025-01-13 12:23:41 --> Loader Class Initialized
INFO - 2025-01-13 12:23:41 --> Helper loaded: url_helper
INFO - 2025-01-13 12:23:41 --> Helper loaded: html_helper
INFO - 2025-01-13 12:23:41 --> Helper loaded: file_helper
INFO - 2025-01-13 12:23:41 --> Helper loaded: string_helper
INFO - 2025-01-13 12:23:41 --> Helper loaded: form_helper
INFO - 2025-01-13 12:23:41 --> Helper loaded: my_helper
INFO - 2025-01-13 12:23:41 --> Database Driver Class Initialized
INFO - 2025-01-13 12:23:41 --> Upload Class Initialized
INFO - 2025-01-13 12:23:41 --> Email Class Initialized
INFO - 2025-01-13 12:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:23:41 --> Form Validation Class Initialized
INFO - 2025-01-13 12:23:41 --> Controller Class Initialized
INFO - 2025-01-13 17:53:41 --> Model "ApiModel" initialized
INFO - 2025-01-13 17:53:41 --> Helper loaded: notification_helper
INFO - 2025-01-13 17:53:41 --> Model "MainModel" initialized
INFO - 2025-01-13 12:23:57 --> Config Class Initialized
INFO - 2025-01-13 12:23:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:23:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:23:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:23:57 --> URI Class Initialized
INFO - 2025-01-13 12:23:57 --> Router Class Initialized
INFO - 2025-01-13 12:23:57 --> Output Class Initialized
INFO - 2025-01-13 12:23:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:23:57 --> Input Class Initialized
INFO - 2025-01-13 12:23:57 --> Language Class Initialized
INFO - 2025-01-13 12:23:57 --> Loader Class Initialized
INFO - 2025-01-13 12:23:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:23:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:23:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:23:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:23:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:23:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:23:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:23:57 --> Upload Class Initialized
INFO - 2025-01-13 12:23:57 --> Email Class Initialized
INFO - 2025-01-13 12:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:23:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:23:57 --> Controller Class Initialized
INFO - 2025-01-13 17:53:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:53:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:53:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:24:57 --> Config Class Initialized
INFO - 2025-01-13 12:24:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:24:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:24:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:24:57 --> URI Class Initialized
INFO - 2025-01-13 12:24:57 --> Router Class Initialized
INFO - 2025-01-13 12:24:57 --> Output Class Initialized
INFO - 2025-01-13 12:24:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:24:57 --> Input Class Initialized
INFO - 2025-01-13 12:24:57 --> Language Class Initialized
INFO - 2025-01-13 12:24:57 --> Loader Class Initialized
INFO - 2025-01-13 12:24:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:24:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:24:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:24:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:24:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:24:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:24:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:24:57 --> Upload Class Initialized
INFO - 2025-01-13 12:24:57 --> Email Class Initialized
INFO - 2025-01-13 12:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:24:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:24:57 --> Controller Class Initialized
INFO - 2025-01-13 17:54:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:54:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:54:57 --> Pagination Class Initialized
INFO - 2025-01-13 12:25:57 --> Config Class Initialized
INFO - 2025-01-13 12:25:57 --> Hooks Class Initialized
DEBUG - 2025-01-13 12:25:57 --> UTF-8 Support Enabled
INFO - 2025-01-13 12:25:57 --> Utf8 Class Initialized
INFO - 2025-01-13 12:25:57 --> URI Class Initialized
INFO - 2025-01-13 12:25:57 --> Router Class Initialized
INFO - 2025-01-13 12:25:57 --> Output Class Initialized
INFO - 2025-01-13 12:25:57 --> Security Class Initialized
DEBUG - 2025-01-13 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-13 12:25:57 --> Input Class Initialized
INFO - 2025-01-13 12:25:57 --> Language Class Initialized
INFO - 2025-01-13 12:25:57 --> Loader Class Initialized
INFO - 2025-01-13 12:25:57 --> Helper loaded: url_helper
INFO - 2025-01-13 12:25:57 --> Helper loaded: html_helper
INFO - 2025-01-13 12:25:57 --> Helper loaded: file_helper
INFO - 2025-01-13 12:25:57 --> Helper loaded: string_helper
INFO - 2025-01-13 12:25:57 --> Helper loaded: form_helper
INFO - 2025-01-13 12:25:57 --> Helper loaded: my_helper
INFO - 2025-01-13 12:25:57 --> Database Driver Class Initialized
INFO - 2025-01-13 12:25:57 --> Upload Class Initialized
INFO - 2025-01-13 12:25:57 --> Email Class Initialized
INFO - 2025-01-13 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-13 12:25:57 --> Form Validation Class Initialized
INFO - 2025-01-13 12:25:57 --> Controller Class Initialized
INFO - 2025-01-13 17:55:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-13 17:55:57 --> Model "MainModel" initialized
INFO - 2025-01-13 17:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-13 17:55:57 --> Pagination Class Initialized
