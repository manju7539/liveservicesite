<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-28 02:07:07 --> Model "MainModel" initialized
INFO - 2024-10-28 02:07:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 02:07:07 --> Final output sent to browser
DEBUG - 2024-10-28 02:07:07 --> Total execution time: 2.4670
INFO - 2024-10-28 02:07:10 --> Model "MainModel" initialized
INFO - 2024-10-28 02:07:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 02:07:10 --> Final output sent to browser
DEBUG - 2024-10-28 02:07:10 --> Total execution time: 2.2278
INFO - 2024-10-28 02:15:20 --> Model "MainModel" initialized
INFO - 2024-10-28 02:15:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 02:15:20 --> Final output sent to browser
DEBUG - 2024-10-28 02:15:20 --> Total execution time: 2.3096
INFO - 2024-10-28 02:15:23 --> Model "MainModel" initialized
INFO - 2024-10-28 02:15:23 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 02:15:23 --> Final output sent to browser
DEBUG - 2024-10-28 02:15:23 --> Total execution time: 2.1973
INFO - 2024-10-28 02:16:16 --> Model "MainModel" initialized
INFO - 2024-10-28 02:16:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 02:16:16 --> Final output sent to browser
DEBUG - 2024-10-28 02:16:16 --> Total execution time: 2.2002
INFO - 2024-10-28 02:16:18 --> Model "MainModel" initialized
INFO - 2024-10-28 02:16:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 02:16:18 --> Final output sent to browser
DEBUG - 2024-10-28 02:16:18 --> Total execution time: 2.1488
INFO - 2024-10-28 02:36:38 --> Model "MainModel" initialized
INFO - 2024-10-28 02:36:38 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 02:36:38 --> Final output sent to browser
DEBUG - 2024-10-28 02:36:38 --> Total execution time: 2.2493
INFO - 2024-10-28 04:10:07 --> Model "MainModel" initialized
INFO - 2024-10-28 04:10:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 04:10:07 --> Final output sent to browser
DEBUG - 2024-10-28 04:10:07 --> Total execution time: 2.2771
INFO - 2024-10-28 04:10:13 --> Model "MainModel" initialized
INFO - 2024-10-28 04:10:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 04:10:13 --> Final output sent to browser
DEBUG - 2024-10-28 04:10:13 --> Total execution time: 2.1706
INFO - 2024-10-28 04:25:16 --> Model "MainModel" initialized
INFO - 2024-10-28 04:25:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 04:25:16 --> Final output sent to browser
DEBUG - 2024-10-28 04:25:16 --> Total execution time: 2.2332
INFO - 2024-10-28 05:01:39 --> Model "MainModel" initialized
INFO - 2024-10-28 05:01:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 05:01:39 --> Final output sent to browser
DEBUG - 2024-10-28 05:01:39 --> Total execution time: 2.2370
INFO - 2024-10-28 02:51:20 --> Config Class Initialized
INFO - 2024-10-28 02:51:20 --> Hooks Class Initialized
DEBUG - 2024-10-28 02:51:20 --> UTF-8 Support Enabled
INFO - 2024-10-28 02:51:20 --> Utf8 Class Initialized
INFO - 2024-10-28 02:51:20 --> URI Class Initialized
DEBUG - 2024-10-28 02:51:20 --> No URI present. Default controller set.
INFO - 2024-10-28 02:51:20 --> Router Class Initialized
INFO - 2024-10-28 02:51:20 --> Output Class Initialized
INFO - 2024-10-28 02:51:20 --> Security Class Initialized
DEBUG - 2024-10-28 02:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 02:51:20 --> Input Class Initialized
INFO - 2024-10-28 02:51:20 --> Language Class Initialized
INFO - 2024-10-28 02:51:20 --> Loader Class Initialized
INFO - 2024-10-28 02:51:20 --> Helper loaded: url_helper
INFO - 2024-10-28 02:51:20 --> Helper loaded: html_helper
INFO - 2024-10-28 02:51:20 --> Helper loaded: file_helper
INFO - 2024-10-28 02:51:20 --> Helper loaded: string_helper
INFO - 2024-10-28 02:51:20 --> Helper loaded: form_helper
INFO - 2024-10-28 02:51:20 --> Helper loaded: my_helper
INFO - 2024-10-28 02:51:20 --> Database Driver Class Initialized
INFO - 2024-10-28 02:51:22 --> Upload Class Initialized
INFO - 2024-10-28 02:51:22 --> Email Class Initialized
INFO - 2024-10-28 02:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 02:51:22 --> Form Validation Class Initialized
INFO - 2024-10-28 02:51:22 --> Controller Class Initialized
INFO - 2024-10-28 08:21:22 --> Model "MainModel" initialized
INFO - 2024-10-28 08:21:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 08:21:22 --> Final output sent to browser
DEBUG - 2024-10-28 08:21:22 --> Total execution time: 2.3930
INFO - 2024-10-28 05:26:11 --> Config Class Initialized
INFO - 2024-10-28 05:26:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 05:26:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 05:26:11 --> Utf8 Class Initialized
INFO - 2024-10-28 05:26:11 --> URI Class Initialized
DEBUG - 2024-10-28 05:26:11 --> No URI present. Default controller set.
INFO - 2024-10-28 05:26:11 --> Router Class Initialized
INFO - 2024-10-28 05:26:11 --> Output Class Initialized
INFO - 2024-10-28 05:26:11 --> Security Class Initialized
DEBUG - 2024-10-28 05:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 05:26:11 --> Input Class Initialized
INFO - 2024-10-28 05:26:11 --> Language Class Initialized
INFO - 2024-10-28 05:26:11 --> Loader Class Initialized
INFO - 2024-10-28 05:26:11 --> Helper loaded: url_helper
INFO - 2024-10-28 05:26:12 --> Helper loaded: html_helper
INFO - 2024-10-28 05:26:12 --> Helper loaded: file_helper
INFO - 2024-10-28 05:26:12 --> Helper loaded: string_helper
INFO - 2024-10-28 05:26:12 --> Helper loaded: form_helper
INFO - 2024-10-28 05:26:12 --> Helper loaded: my_helper
INFO - 2024-10-28 05:26:12 --> Database Driver Class Initialized
INFO - 2024-10-28 05:26:14 --> Upload Class Initialized
INFO - 2024-10-28 05:26:14 --> Email Class Initialized
INFO - 2024-10-28 05:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 05:26:15 --> Form Validation Class Initialized
INFO - 2024-10-28 05:26:15 --> Controller Class Initialized
INFO - 2024-10-28 10:56:15 --> Model "MainModel" initialized
INFO - 2024-10-28 10:56:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 10:56:15 --> Final output sent to browser
DEBUG - 2024-10-28 10:56:15 --> Total execution time: 4.1421
INFO - 2024-10-28 05:59:15 --> Config Class Initialized
INFO - 2024-10-28 05:59:15 --> Hooks Class Initialized
DEBUG - 2024-10-28 05:59:15 --> UTF-8 Support Enabled
INFO - 2024-10-28 05:59:15 --> Utf8 Class Initialized
INFO - 2024-10-28 05:59:15 --> URI Class Initialized
DEBUG - 2024-10-28 05:59:15 --> No URI present. Default controller set.
INFO - 2024-10-28 05:59:15 --> Router Class Initialized
INFO - 2024-10-28 05:59:15 --> Output Class Initialized
INFO - 2024-10-28 05:59:15 --> Security Class Initialized
DEBUG - 2024-10-28 05:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 05:59:15 --> Input Class Initialized
INFO - 2024-10-28 05:59:15 --> Language Class Initialized
INFO - 2024-10-28 05:59:15 --> Loader Class Initialized
INFO - 2024-10-28 05:59:15 --> Helper loaded: url_helper
INFO - 2024-10-28 05:59:15 --> Helper loaded: html_helper
INFO - 2024-10-28 05:59:15 --> Helper loaded: file_helper
INFO - 2024-10-28 05:59:15 --> Helper loaded: string_helper
INFO - 2024-10-28 05:59:15 --> Helper loaded: form_helper
INFO - 2024-10-28 05:59:15 --> Helper loaded: my_helper
INFO - 2024-10-28 05:59:15 --> Database Driver Class Initialized
INFO - 2024-10-28 05:59:17 --> Upload Class Initialized
INFO - 2024-10-28 05:59:17 --> Email Class Initialized
INFO - 2024-10-28 05:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 05:59:17 --> Form Validation Class Initialized
INFO - 2024-10-28 05:59:17 --> Controller Class Initialized
INFO - 2024-10-28 11:29:17 --> Model "MainModel" initialized
INFO - 2024-10-28 11:29:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 11:29:17 --> Final output sent to browser
DEBUG - 2024-10-28 11:29:17 --> Total execution time: 2.2400
INFO - 2024-10-28 06:46:22 --> Config Class Initialized
INFO - 2024-10-28 06:46:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:22 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:22 --> URI Class Initialized
DEBUG - 2024-10-28 06:46:22 --> No URI present. Default controller set.
INFO - 2024-10-28 06:46:22 --> Router Class Initialized
INFO - 2024-10-28 06:46:22 --> Output Class Initialized
INFO - 2024-10-28 06:46:22 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:22 --> Input Class Initialized
INFO - 2024-10-28 06:46:22 --> Language Class Initialized
INFO - 2024-10-28 06:46:22 --> Loader Class Initialized
INFO - 2024-10-28 06:46:22 --> Helper loaded: url_helper
INFO - 2024-10-28 06:46:22 --> Helper loaded: html_helper
INFO - 2024-10-28 06:46:22 --> Helper loaded: file_helper
INFO - 2024-10-28 06:46:22 --> Helper loaded: string_helper
INFO - 2024-10-28 06:46:22 --> Helper loaded: form_helper
INFO - 2024-10-28 06:46:22 --> Helper loaded: my_helper
INFO - 2024-10-28 06:46:23 --> Database Driver Class Initialized
INFO - 2024-10-28 06:46:25 --> Upload Class Initialized
INFO - 2024-10-28 06:46:25 --> Email Class Initialized
INFO - 2024-10-28 06:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 06:46:25 --> Form Validation Class Initialized
INFO - 2024-10-28 06:46:25 --> Controller Class Initialized
INFO - 2024-10-28 12:16:25 --> Model "MainModel" initialized
INFO - 2024-10-28 12:16:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 12:16:25 --> Final output sent to browser
DEBUG - 2024-10-28 12:16:25 --> Total execution time: 2.5198
INFO - 2024-10-28 06:46:25 --> Config Class Initialized
INFO - 2024-10-28 06:46:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:25 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:25 --> URI Class Initialized
INFO - 2024-10-28 06:46:25 --> Router Class Initialized
INFO - 2024-10-28 06:46:25 --> Output Class Initialized
INFO - 2024-10-28 06:46:25 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:25 --> Input Class Initialized
INFO - 2024-10-28 06:46:25 --> Language Class Initialized
ERROR - 2024-10-28 06:46:25 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-28 06:46:25 --> Config Class Initialized
INFO - 2024-10-28 06:46:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:25 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:25 --> URI Class Initialized
INFO - 2024-10-28 06:46:25 --> Router Class Initialized
INFO - 2024-10-28 06:46:25 --> Output Class Initialized
INFO - 2024-10-28 06:46:25 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:25 --> Input Class Initialized
INFO - 2024-10-28 06:46:25 --> Language Class Initialized
ERROR - 2024-10-28 06:46:25 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-28 06:46:26 --> Config Class Initialized
INFO - 2024-10-28 06:46:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:26 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:26 --> URI Class Initialized
DEBUG - 2024-10-28 06:46:26 --> No URI present. Default controller set.
INFO - 2024-10-28 06:46:26 --> Router Class Initialized
INFO - 2024-10-28 06:46:26 --> Output Class Initialized
INFO - 2024-10-28 06:46:26 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:26 --> Input Class Initialized
INFO - 2024-10-28 06:46:26 --> Language Class Initialized
INFO - 2024-10-28 06:46:26 --> Loader Class Initialized
INFO - 2024-10-28 06:46:26 --> Helper loaded: url_helper
INFO - 2024-10-28 06:46:26 --> Helper loaded: html_helper
INFO - 2024-10-28 06:46:26 --> Helper loaded: file_helper
INFO - 2024-10-28 06:46:26 --> Helper loaded: string_helper
INFO - 2024-10-28 06:46:26 --> Helper loaded: form_helper
INFO - 2024-10-28 06:46:26 --> Helper loaded: my_helper
INFO - 2024-10-28 06:46:26 --> Database Driver Class Initialized
INFO - 2024-10-28 06:46:28 --> Upload Class Initialized
INFO - 2024-10-28 06:46:28 --> Email Class Initialized
INFO - 2024-10-28 06:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 06:46:28 --> Form Validation Class Initialized
INFO - 2024-10-28 06:46:28 --> Controller Class Initialized
INFO - 2024-10-28 12:16:28 --> Model "MainModel" initialized
INFO - 2024-10-28 12:16:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 12:16:28 --> Final output sent to browser
DEBUG - 2024-10-28 12:16:28 --> Total execution time: 2.1987
INFO - 2024-10-28 06:46:28 --> Config Class Initialized
INFO - 2024-10-28 06:46:28 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:28 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:28 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:28 --> URI Class Initialized
INFO - 2024-10-28 06:46:28 --> Router Class Initialized
INFO - 2024-10-28 06:46:28 --> Output Class Initialized
INFO - 2024-10-28 06:46:28 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:28 --> Input Class Initialized
INFO - 2024-10-28 06:46:28 --> Language Class Initialized
ERROR - 2024-10-28 06:46:28 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-28 06:46:28 --> Config Class Initialized
INFO - 2024-10-28 06:46:28 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:28 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:28 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:28 --> URI Class Initialized
INFO - 2024-10-28 06:46:28 --> Router Class Initialized
INFO - 2024-10-28 06:46:28 --> Output Class Initialized
INFO - 2024-10-28 06:46:29 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:29 --> Input Class Initialized
INFO - 2024-10-28 06:46:29 --> Language Class Initialized
ERROR - 2024-10-28 06:46:29 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-28 06:46:29 --> Config Class Initialized
INFO - 2024-10-28 06:46:29 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:29 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:29 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:29 --> URI Class Initialized
INFO - 2024-10-28 06:46:29 --> Router Class Initialized
INFO - 2024-10-28 06:46:29 --> Output Class Initialized
INFO - 2024-10-28 06:46:29 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:29 --> Input Class Initialized
INFO - 2024-10-28 06:46:29 --> Language Class Initialized
ERROR - 2024-10-28 06:46:29 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-28 06:46:29 --> Config Class Initialized
INFO - 2024-10-28 06:46:29 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:29 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:29 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:29 --> URI Class Initialized
INFO - 2024-10-28 06:46:29 --> Router Class Initialized
INFO - 2024-10-28 06:46:29 --> Output Class Initialized
INFO - 2024-10-28 06:46:29 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:29 --> Input Class Initialized
INFO - 2024-10-28 06:46:29 --> Language Class Initialized
ERROR - 2024-10-28 06:46:29 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-28 06:46:29 --> Config Class Initialized
INFO - 2024-10-28 06:46:29 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:29 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:29 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:29 --> URI Class Initialized
INFO - 2024-10-28 06:46:29 --> Router Class Initialized
INFO - 2024-10-28 06:46:29 --> Output Class Initialized
INFO - 2024-10-28 06:46:29 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:29 --> Input Class Initialized
INFO - 2024-10-28 06:46:29 --> Language Class Initialized
ERROR - 2024-10-28 06:46:29 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-28 06:46:30 --> Config Class Initialized
INFO - 2024-10-28 06:46:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:30 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:30 --> URI Class Initialized
INFO - 2024-10-28 06:46:30 --> Router Class Initialized
INFO - 2024-10-28 06:46:30 --> Output Class Initialized
INFO - 2024-10-28 06:46:30 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:30 --> Input Class Initialized
INFO - 2024-10-28 06:46:30 --> Language Class Initialized
ERROR - 2024-10-28 06:46:30 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-28 06:46:30 --> Config Class Initialized
INFO - 2024-10-28 06:46:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:30 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:30 --> URI Class Initialized
INFO - 2024-10-28 06:46:30 --> Router Class Initialized
INFO - 2024-10-28 06:46:30 --> Output Class Initialized
INFO - 2024-10-28 06:46:30 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:30 --> Input Class Initialized
INFO - 2024-10-28 06:46:30 --> Language Class Initialized
ERROR - 2024-10-28 06:46:30 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-28 06:46:30 --> Config Class Initialized
INFO - 2024-10-28 06:46:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:30 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:30 --> URI Class Initialized
INFO - 2024-10-28 06:46:30 --> Router Class Initialized
INFO - 2024-10-28 06:46:30 --> Output Class Initialized
INFO - 2024-10-28 06:46:30 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:30 --> Input Class Initialized
INFO - 2024-10-28 06:46:30 --> Language Class Initialized
ERROR - 2024-10-28 06:46:30 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-28 06:46:31 --> Config Class Initialized
INFO - 2024-10-28 06:46:31 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:31 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:31 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:31 --> URI Class Initialized
INFO - 2024-10-28 06:46:31 --> Router Class Initialized
INFO - 2024-10-28 06:46:31 --> Output Class Initialized
INFO - 2024-10-28 06:46:31 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:31 --> Input Class Initialized
INFO - 2024-10-28 06:46:31 --> Language Class Initialized
ERROR - 2024-10-28 06:46:31 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-28 06:46:31 --> Config Class Initialized
INFO - 2024-10-28 06:46:31 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:31 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:31 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:31 --> URI Class Initialized
INFO - 2024-10-28 06:46:31 --> Router Class Initialized
INFO - 2024-10-28 06:46:31 --> Output Class Initialized
INFO - 2024-10-28 06:46:31 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:31 --> Input Class Initialized
INFO - 2024-10-28 06:46:31 --> Language Class Initialized
ERROR - 2024-10-28 06:46:31 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-28 06:46:31 --> Config Class Initialized
INFO - 2024-10-28 06:46:31 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:31 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:31 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:31 --> URI Class Initialized
INFO - 2024-10-28 06:46:31 --> Router Class Initialized
INFO - 2024-10-28 06:46:31 --> Output Class Initialized
INFO - 2024-10-28 06:46:31 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:31 --> Input Class Initialized
INFO - 2024-10-28 06:46:31 --> Language Class Initialized
ERROR - 2024-10-28 06:46:31 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-28 06:46:32 --> Config Class Initialized
INFO - 2024-10-28 06:46:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:32 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:32 --> URI Class Initialized
INFO - 2024-10-28 06:46:32 --> Router Class Initialized
INFO - 2024-10-28 06:46:32 --> Output Class Initialized
INFO - 2024-10-28 06:46:32 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:32 --> Input Class Initialized
INFO - 2024-10-28 06:46:32 --> Language Class Initialized
ERROR - 2024-10-28 06:46:32 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-28 06:46:32 --> Config Class Initialized
INFO - 2024-10-28 06:46:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:32 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:32 --> URI Class Initialized
INFO - 2024-10-28 06:46:32 --> Router Class Initialized
INFO - 2024-10-28 06:46:32 --> Output Class Initialized
INFO - 2024-10-28 06:46:32 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:32 --> Input Class Initialized
INFO - 2024-10-28 06:46:32 --> Language Class Initialized
ERROR - 2024-10-28 06:46:32 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-28 06:46:33 --> Config Class Initialized
INFO - 2024-10-28 06:46:33 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:33 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:33 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:33 --> URI Class Initialized
INFO - 2024-10-28 06:46:33 --> Router Class Initialized
INFO - 2024-10-28 06:46:33 --> Output Class Initialized
INFO - 2024-10-28 06:46:33 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:33 --> Input Class Initialized
INFO - 2024-10-28 06:46:33 --> Language Class Initialized
ERROR - 2024-10-28 06:46:33 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-28 06:46:34 --> Config Class Initialized
INFO - 2024-10-28 06:46:34 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:34 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:34 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:34 --> URI Class Initialized
INFO - 2024-10-28 06:46:34 --> Router Class Initialized
INFO - 2024-10-28 06:46:34 --> Output Class Initialized
INFO - 2024-10-28 06:46:34 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:34 --> Input Class Initialized
INFO - 2024-10-28 06:46:34 --> Language Class Initialized
ERROR - 2024-10-28 06:46:34 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-28 06:46:34 --> Config Class Initialized
INFO - 2024-10-28 06:46:34 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:46:34 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:46:34 --> Utf8 Class Initialized
INFO - 2024-10-28 06:46:34 --> URI Class Initialized
INFO - 2024-10-28 06:46:34 --> Router Class Initialized
INFO - 2024-10-28 06:46:34 --> Output Class Initialized
INFO - 2024-10-28 06:46:34 --> Security Class Initialized
DEBUG - 2024-10-28 06:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:46:34 --> Input Class Initialized
INFO - 2024-10-28 06:46:34 --> Language Class Initialized
ERROR - 2024-10-28 06:46:34 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-28 09:30:15 --> Config Class Initialized
INFO - 2024-10-28 09:30:15 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:15 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:15 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:15 --> URI Class Initialized
DEBUG - 2024-10-28 09:30:15 --> No URI present. Default controller set.
INFO - 2024-10-28 09:30:15 --> Router Class Initialized
INFO - 2024-10-28 09:30:15 --> Output Class Initialized
INFO - 2024-10-28 09:30:15 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:15 --> Input Class Initialized
INFO - 2024-10-28 09:30:15 --> Language Class Initialized
INFO - 2024-10-28 09:30:15 --> Loader Class Initialized
INFO - 2024-10-28 09:30:15 --> Helper loaded: url_helper
INFO - 2024-10-28 09:30:15 --> Helper loaded: html_helper
INFO - 2024-10-28 09:30:15 --> Helper loaded: file_helper
INFO - 2024-10-28 09:30:15 --> Helper loaded: string_helper
INFO - 2024-10-28 09:30:15 --> Helper loaded: form_helper
INFO - 2024-10-28 09:30:15 --> Helper loaded: my_helper
INFO - 2024-10-28 09:30:15 --> Database Driver Class Initialized
INFO - 2024-10-28 09:30:17 --> Upload Class Initialized
INFO - 2024-10-28 09:30:17 --> Email Class Initialized
INFO - 2024-10-28 09:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:30:17 --> Form Validation Class Initialized
INFO - 2024-10-28 09:30:17 --> Controller Class Initialized
INFO - 2024-10-28 15:00:17 --> Model "MainModel" initialized
INFO - 2024-10-28 15:00:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 15:00:17 --> Final output sent to browser
DEBUG - 2024-10-28 15:00:17 --> Total execution time: 2.2627
INFO - 2024-10-28 09:30:17 --> Config Class Initialized
INFO - 2024-10-28 09:30:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:17 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:17 --> URI Class Initialized
INFO - 2024-10-28 09:30:17 --> Router Class Initialized
INFO - 2024-10-28 09:30:17 --> Output Class Initialized
INFO - 2024-10-28 09:30:17 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:17 --> Input Class Initialized
INFO - 2024-10-28 09:30:17 --> Language Class Initialized
ERROR - 2024-10-28 09:30:17 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-28 09:30:17 --> Config Class Initialized
INFO - 2024-10-28 09:30:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:17 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:17 --> URI Class Initialized
INFO - 2024-10-28 09:30:17 --> Router Class Initialized
INFO - 2024-10-28 09:30:17 --> Output Class Initialized
INFO - 2024-10-28 09:30:17 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:17 --> Input Class Initialized
INFO - 2024-10-28 09:30:17 --> Language Class Initialized
ERROR - 2024-10-28 09:30:17 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-28 09:30:18 --> Config Class Initialized
INFO - 2024-10-28 09:30:18 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:18 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:18 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:18 --> URI Class Initialized
DEBUG - 2024-10-28 09:30:18 --> No URI present. Default controller set.
INFO - 2024-10-28 09:30:18 --> Router Class Initialized
INFO - 2024-10-28 09:30:18 --> Output Class Initialized
INFO - 2024-10-28 09:30:18 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:18 --> Input Class Initialized
INFO - 2024-10-28 09:30:18 --> Language Class Initialized
INFO - 2024-10-28 09:30:18 --> Loader Class Initialized
INFO - 2024-10-28 09:30:18 --> Helper loaded: url_helper
INFO - 2024-10-28 09:30:18 --> Helper loaded: html_helper
INFO - 2024-10-28 09:30:18 --> Helper loaded: file_helper
INFO - 2024-10-28 09:30:18 --> Helper loaded: string_helper
INFO - 2024-10-28 09:30:18 --> Helper loaded: form_helper
INFO - 2024-10-28 09:30:18 --> Helper loaded: my_helper
INFO - 2024-10-28 09:30:18 --> Database Driver Class Initialized
INFO - 2024-10-28 09:30:20 --> Upload Class Initialized
INFO - 2024-10-28 09:30:20 --> Email Class Initialized
INFO - 2024-10-28 09:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:30:20 --> Form Validation Class Initialized
INFO - 2024-10-28 09:30:20 --> Controller Class Initialized
INFO - 2024-10-28 15:00:20 --> Model "MainModel" initialized
INFO - 2024-10-28 15:00:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 15:00:20 --> Final output sent to browser
DEBUG - 2024-10-28 15:00:20 --> Total execution time: 2.0990
INFO - 2024-10-28 09:30:20 --> Config Class Initialized
INFO - 2024-10-28 09:30:20 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:20 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:20 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:20 --> URI Class Initialized
INFO - 2024-10-28 09:30:20 --> Router Class Initialized
INFO - 2024-10-28 09:30:20 --> Output Class Initialized
INFO - 2024-10-28 09:30:20 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:20 --> Input Class Initialized
INFO - 2024-10-28 09:30:20 --> Language Class Initialized
ERROR - 2024-10-28 09:30:20 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-28 09:30:20 --> Config Class Initialized
INFO - 2024-10-28 09:30:20 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:20 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:20 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:20 --> URI Class Initialized
INFO - 2024-10-28 09:30:20 --> Router Class Initialized
INFO - 2024-10-28 09:30:20 --> Output Class Initialized
INFO - 2024-10-28 09:30:20 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:20 --> Input Class Initialized
INFO - 2024-10-28 09:30:20 --> Language Class Initialized
ERROR - 2024-10-28 09:30:20 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-28 09:30:21 --> Config Class Initialized
INFO - 2024-10-28 09:30:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:21 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:21 --> URI Class Initialized
INFO - 2024-10-28 09:30:21 --> Router Class Initialized
INFO - 2024-10-28 09:30:21 --> Output Class Initialized
INFO - 2024-10-28 09:30:21 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:21 --> Input Class Initialized
INFO - 2024-10-28 09:30:21 --> Language Class Initialized
ERROR - 2024-10-28 09:30:21 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-28 09:30:21 --> Config Class Initialized
INFO - 2024-10-28 09:30:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:21 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:21 --> URI Class Initialized
INFO - 2024-10-28 09:30:21 --> Router Class Initialized
INFO - 2024-10-28 09:30:21 --> Output Class Initialized
INFO - 2024-10-28 09:30:21 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:21 --> Input Class Initialized
INFO - 2024-10-28 09:30:21 --> Language Class Initialized
ERROR - 2024-10-28 09:30:21 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-28 09:30:21 --> Config Class Initialized
INFO - 2024-10-28 09:30:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:21 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:21 --> URI Class Initialized
INFO - 2024-10-28 09:30:21 --> Router Class Initialized
INFO - 2024-10-28 09:30:21 --> Output Class Initialized
INFO - 2024-10-28 09:30:21 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:21 --> Input Class Initialized
INFO - 2024-10-28 09:30:21 --> Language Class Initialized
ERROR - 2024-10-28 09:30:21 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-28 09:30:21 --> Config Class Initialized
INFO - 2024-10-28 09:30:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:21 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:21 --> URI Class Initialized
INFO - 2024-10-28 09:30:21 --> Router Class Initialized
INFO - 2024-10-28 09:30:21 --> Output Class Initialized
INFO - 2024-10-28 09:30:21 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:21 --> Input Class Initialized
INFO - 2024-10-28 09:30:21 --> Language Class Initialized
ERROR - 2024-10-28 09:30:21 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-28 09:30:22 --> Config Class Initialized
INFO - 2024-10-28 09:30:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:22 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:22 --> URI Class Initialized
INFO - 2024-10-28 09:30:22 --> Router Class Initialized
INFO - 2024-10-28 09:30:22 --> Output Class Initialized
INFO - 2024-10-28 09:30:22 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:22 --> Input Class Initialized
INFO - 2024-10-28 09:30:22 --> Language Class Initialized
ERROR - 2024-10-28 09:30:22 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-28 09:30:22 --> Config Class Initialized
INFO - 2024-10-28 09:30:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:22 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:22 --> URI Class Initialized
INFO - 2024-10-28 09:30:22 --> Router Class Initialized
INFO - 2024-10-28 09:30:22 --> Output Class Initialized
INFO - 2024-10-28 09:30:22 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:22 --> Input Class Initialized
INFO - 2024-10-28 09:30:22 --> Language Class Initialized
ERROR - 2024-10-28 09:30:22 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-28 09:30:22 --> Config Class Initialized
INFO - 2024-10-28 09:30:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:22 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:22 --> URI Class Initialized
INFO - 2024-10-28 09:30:22 --> Router Class Initialized
INFO - 2024-10-28 09:30:22 --> Output Class Initialized
INFO - 2024-10-28 09:30:22 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:22 --> Input Class Initialized
INFO - 2024-10-28 09:30:22 --> Language Class Initialized
ERROR - 2024-10-28 09:30:22 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-28 09:30:22 --> Config Class Initialized
INFO - 2024-10-28 09:30:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:22 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:22 --> URI Class Initialized
INFO - 2024-10-28 09:30:22 --> Router Class Initialized
INFO - 2024-10-28 09:30:22 --> Output Class Initialized
INFO - 2024-10-28 09:30:22 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:22 --> Input Class Initialized
INFO - 2024-10-28 09:30:22 --> Language Class Initialized
ERROR - 2024-10-28 09:30:22 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-28 09:30:23 --> Config Class Initialized
INFO - 2024-10-28 09:30:23 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:23 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:23 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:23 --> URI Class Initialized
INFO - 2024-10-28 09:30:23 --> Router Class Initialized
INFO - 2024-10-28 09:30:23 --> Output Class Initialized
INFO - 2024-10-28 09:30:23 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:23 --> Input Class Initialized
INFO - 2024-10-28 09:30:23 --> Language Class Initialized
ERROR - 2024-10-28 09:30:23 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-28 09:30:23 --> Config Class Initialized
INFO - 2024-10-28 09:30:23 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:23 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:23 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:23 --> URI Class Initialized
INFO - 2024-10-28 09:30:23 --> Router Class Initialized
INFO - 2024-10-28 09:30:23 --> Output Class Initialized
INFO - 2024-10-28 09:30:23 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:23 --> Input Class Initialized
INFO - 2024-10-28 09:30:23 --> Language Class Initialized
ERROR - 2024-10-28 09:30:23 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-28 09:30:23 --> Config Class Initialized
INFO - 2024-10-28 09:30:23 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:23 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:23 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:23 --> URI Class Initialized
INFO - 2024-10-28 09:30:23 --> Router Class Initialized
INFO - 2024-10-28 09:30:23 --> Output Class Initialized
INFO - 2024-10-28 09:30:23 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:23 --> Input Class Initialized
INFO - 2024-10-28 09:30:23 --> Language Class Initialized
ERROR - 2024-10-28 09:30:23 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-28 09:30:23 --> Config Class Initialized
INFO - 2024-10-28 09:30:23 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:23 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:23 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:23 --> URI Class Initialized
INFO - 2024-10-28 09:30:23 --> Router Class Initialized
INFO - 2024-10-28 09:30:23 --> Output Class Initialized
INFO - 2024-10-28 09:30:23 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:24 --> Input Class Initialized
INFO - 2024-10-28 09:30:24 --> Language Class Initialized
ERROR - 2024-10-28 09:30:24 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-28 09:30:24 --> Config Class Initialized
INFO - 2024-10-28 09:30:24 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:24 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:24 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:24 --> URI Class Initialized
INFO - 2024-10-28 09:30:24 --> Router Class Initialized
INFO - 2024-10-28 09:30:24 --> Output Class Initialized
INFO - 2024-10-28 09:30:24 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:24 --> Input Class Initialized
INFO - 2024-10-28 09:30:24 --> Language Class Initialized
ERROR - 2024-10-28 09:30:24 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-28 09:30:24 --> Config Class Initialized
INFO - 2024-10-28 09:30:24 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:30:24 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:30:24 --> Utf8 Class Initialized
INFO - 2024-10-28 09:30:24 --> URI Class Initialized
INFO - 2024-10-28 09:30:24 --> Router Class Initialized
INFO - 2024-10-28 09:30:24 --> Output Class Initialized
INFO - 2024-10-28 09:30:24 --> Security Class Initialized
DEBUG - 2024-10-28 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:30:24 --> Input Class Initialized
INFO - 2024-10-28 09:30:24 --> Language Class Initialized
ERROR - 2024-10-28 09:30:24 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-28 10:02:40 --> Config Class Initialized
INFO - 2024-10-28 10:02:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:40 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:40 --> URI Class Initialized
DEBUG - 2024-10-28 10:02:40 --> No URI present. Default controller set.
INFO - 2024-10-28 10:02:40 --> Router Class Initialized
INFO - 2024-10-28 10:02:40 --> Output Class Initialized
INFO - 2024-10-28 10:02:40 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:40 --> Input Class Initialized
INFO - 2024-10-28 10:02:40 --> Language Class Initialized
INFO - 2024-10-28 10:02:40 --> Loader Class Initialized
INFO - 2024-10-28 10:02:40 --> Helper loaded: url_helper
INFO - 2024-10-28 10:02:40 --> Helper loaded: html_helper
INFO - 2024-10-28 10:02:40 --> Helper loaded: file_helper
INFO - 2024-10-28 10:02:40 --> Helper loaded: string_helper
INFO - 2024-10-28 10:02:40 --> Helper loaded: form_helper
INFO - 2024-10-28 10:02:40 --> Helper loaded: my_helper
INFO - 2024-10-28 10:02:40 --> Database Driver Class Initialized
INFO - 2024-10-28 10:02:42 --> Upload Class Initialized
INFO - 2024-10-28 10:02:42 --> Email Class Initialized
INFO - 2024-10-28 10:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 10:02:42 --> Form Validation Class Initialized
INFO - 2024-10-28 10:02:42 --> Controller Class Initialized
INFO - 2024-10-28 15:32:42 --> Model "MainModel" initialized
INFO - 2024-10-28 15:32:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 15:32:42 --> Final output sent to browser
DEBUG - 2024-10-28 15:32:42 --> Total execution time: 2.3071
INFO - 2024-10-28 10:02:42 --> Config Class Initialized
INFO - 2024-10-28 10:02:42 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:42 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:42 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:42 --> URI Class Initialized
INFO - 2024-10-28 10:02:42 --> Router Class Initialized
INFO - 2024-10-28 10:02:42 --> Output Class Initialized
INFO - 2024-10-28 10:02:42 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:42 --> Input Class Initialized
INFO - 2024-10-28 10:02:42 --> Language Class Initialized
ERROR - 2024-10-28 10:02:42 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-28 10:02:42 --> Config Class Initialized
INFO - 2024-10-28 10:02:42 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:42 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:42 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:42 --> URI Class Initialized
INFO - 2024-10-28 10:02:42 --> Router Class Initialized
INFO - 2024-10-28 10:02:43 --> Output Class Initialized
INFO - 2024-10-28 10:02:43 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:43 --> Input Class Initialized
INFO - 2024-10-28 10:02:43 --> Language Class Initialized
ERROR - 2024-10-28 10:02:43 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-28 10:02:43 --> Config Class Initialized
INFO - 2024-10-28 10:02:43 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:43 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:43 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:43 --> URI Class Initialized
DEBUG - 2024-10-28 10:02:43 --> No URI present. Default controller set.
INFO - 2024-10-28 10:02:43 --> Router Class Initialized
INFO - 2024-10-28 10:02:43 --> Output Class Initialized
INFO - 2024-10-28 10:02:43 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:43 --> Input Class Initialized
INFO - 2024-10-28 10:02:43 --> Language Class Initialized
INFO - 2024-10-28 10:02:43 --> Loader Class Initialized
INFO - 2024-10-28 10:02:43 --> Helper loaded: url_helper
INFO - 2024-10-28 10:02:43 --> Helper loaded: html_helper
INFO - 2024-10-28 10:02:43 --> Helper loaded: file_helper
INFO - 2024-10-28 10:02:43 --> Helper loaded: string_helper
INFO - 2024-10-28 10:02:43 --> Helper loaded: form_helper
INFO - 2024-10-28 10:02:43 --> Helper loaded: my_helper
INFO - 2024-10-28 10:02:43 --> Database Driver Class Initialized
INFO - 2024-10-28 10:02:45 --> Upload Class Initialized
INFO - 2024-10-28 10:02:45 --> Email Class Initialized
INFO - 2024-10-28 10:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 10:02:45 --> Form Validation Class Initialized
INFO - 2024-10-28 10:02:45 --> Controller Class Initialized
INFO - 2024-10-28 15:32:45 --> Model "MainModel" initialized
INFO - 2024-10-28 15:32:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 15:32:45 --> Final output sent to browser
DEBUG - 2024-10-28 15:32:45 --> Total execution time: 2.1559
INFO - 2024-10-28 10:02:45 --> Config Class Initialized
INFO - 2024-10-28 10:02:45 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:45 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:45 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:45 --> URI Class Initialized
INFO - 2024-10-28 10:02:45 --> Router Class Initialized
INFO - 2024-10-28 10:02:45 --> Output Class Initialized
INFO - 2024-10-28 10:02:45 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:45 --> Input Class Initialized
INFO - 2024-10-28 10:02:45 --> Language Class Initialized
ERROR - 2024-10-28 10:02:45 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-28 10:02:45 --> Config Class Initialized
INFO - 2024-10-28 10:02:45 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:45 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:45 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:45 --> URI Class Initialized
INFO - 2024-10-28 10:02:45 --> Router Class Initialized
INFO - 2024-10-28 10:02:45 --> Output Class Initialized
INFO - 2024-10-28 10:02:45 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:45 --> Input Class Initialized
INFO - 2024-10-28 10:02:46 --> Language Class Initialized
ERROR - 2024-10-28 10:02:46 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-28 10:02:46 --> Config Class Initialized
INFO - 2024-10-28 10:02:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:46 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:46 --> URI Class Initialized
INFO - 2024-10-28 10:02:46 --> Router Class Initialized
INFO - 2024-10-28 10:02:46 --> Output Class Initialized
INFO - 2024-10-28 10:02:46 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:46 --> Input Class Initialized
INFO - 2024-10-28 10:02:46 --> Language Class Initialized
ERROR - 2024-10-28 10:02:46 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-28 10:02:46 --> Config Class Initialized
INFO - 2024-10-28 10:02:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:46 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:46 --> URI Class Initialized
INFO - 2024-10-28 10:02:46 --> Router Class Initialized
INFO - 2024-10-28 10:02:46 --> Output Class Initialized
INFO - 2024-10-28 10:02:46 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:46 --> Input Class Initialized
INFO - 2024-10-28 10:02:46 --> Language Class Initialized
ERROR - 2024-10-28 10:02:46 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-28 10:02:46 --> Config Class Initialized
INFO - 2024-10-28 10:02:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:46 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:46 --> URI Class Initialized
INFO - 2024-10-28 10:02:46 --> Router Class Initialized
INFO - 2024-10-28 10:02:46 --> Output Class Initialized
INFO - 2024-10-28 10:02:46 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:46 --> Input Class Initialized
INFO - 2024-10-28 10:02:46 --> Language Class Initialized
ERROR - 2024-10-28 10:02:46 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-28 10:02:47 --> Config Class Initialized
INFO - 2024-10-28 10:02:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:47 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:47 --> URI Class Initialized
INFO - 2024-10-28 10:02:47 --> Router Class Initialized
INFO - 2024-10-28 10:02:47 --> Output Class Initialized
INFO - 2024-10-28 10:02:47 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:47 --> Input Class Initialized
INFO - 2024-10-28 10:02:47 --> Language Class Initialized
ERROR - 2024-10-28 10:02:47 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-28 10:02:47 --> Config Class Initialized
INFO - 2024-10-28 10:02:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:47 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:47 --> URI Class Initialized
INFO - 2024-10-28 10:02:47 --> Router Class Initialized
INFO - 2024-10-28 10:02:47 --> Output Class Initialized
INFO - 2024-10-28 10:02:47 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:47 --> Input Class Initialized
INFO - 2024-10-28 10:02:47 --> Language Class Initialized
ERROR - 2024-10-28 10:02:47 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-28 10:02:47 --> Config Class Initialized
INFO - 2024-10-28 10:02:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:47 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:47 --> URI Class Initialized
INFO - 2024-10-28 10:02:47 --> Router Class Initialized
INFO - 2024-10-28 10:02:47 --> Output Class Initialized
INFO - 2024-10-28 10:02:47 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:47 --> Input Class Initialized
INFO - 2024-10-28 10:02:47 --> Language Class Initialized
ERROR - 2024-10-28 10:02:47 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-28 10:02:47 --> Config Class Initialized
INFO - 2024-10-28 10:02:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:47 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:47 --> URI Class Initialized
INFO - 2024-10-28 10:02:47 --> Router Class Initialized
INFO - 2024-10-28 10:02:47 --> Output Class Initialized
INFO - 2024-10-28 10:02:47 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:47 --> Input Class Initialized
INFO - 2024-10-28 10:02:47 --> Language Class Initialized
ERROR - 2024-10-28 10:02:47 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-28 10:02:48 --> Config Class Initialized
INFO - 2024-10-28 10:02:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:48 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:48 --> URI Class Initialized
INFO - 2024-10-28 10:02:48 --> Router Class Initialized
INFO - 2024-10-28 10:02:48 --> Output Class Initialized
INFO - 2024-10-28 10:02:48 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:48 --> Input Class Initialized
INFO - 2024-10-28 10:02:48 --> Language Class Initialized
ERROR - 2024-10-28 10:02:48 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-28 10:02:48 --> Config Class Initialized
INFO - 2024-10-28 10:02:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:48 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:48 --> URI Class Initialized
INFO - 2024-10-28 10:02:48 --> Router Class Initialized
INFO - 2024-10-28 10:02:48 --> Output Class Initialized
INFO - 2024-10-28 10:02:48 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:48 --> Input Class Initialized
INFO - 2024-10-28 10:02:48 --> Language Class Initialized
ERROR - 2024-10-28 10:02:48 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-28 10:02:48 --> Config Class Initialized
INFO - 2024-10-28 10:02:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:48 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:48 --> URI Class Initialized
INFO - 2024-10-28 10:02:48 --> Router Class Initialized
INFO - 2024-10-28 10:02:48 --> Output Class Initialized
INFO - 2024-10-28 10:02:48 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:48 --> Input Class Initialized
INFO - 2024-10-28 10:02:48 --> Language Class Initialized
ERROR - 2024-10-28 10:02:48 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-28 10:02:48 --> Config Class Initialized
INFO - 2024-10-28 10:02:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:48 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:49 --> URI Class Initialized
INFO - 2024-10-28 10:02:49 --> Router Class Initialized
INFO - 2024-10-28 10:02:49 --> Output Class Initialized
INFO - 2024-10-28 10:02:49 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:49 --> Input Class Initialized
INFO - 2024-10-28 10:02:49 --> Language Class Initialized
ERROR - 2024-10-28 10:02:49 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-28 10:02:49 --> Config Class Initialized
INFO - 2024-10-28 10:02:49 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:49 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:49 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:49 --> URI Class Initialized
INFO - 2024-10-28 10:02:49 --> Router Class Initialized
INFO - 2024-10-28 10:02:49 --> Output Class Initialized
INFO - 2024-10-28 10:02:49 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:49 --> Input Class Initialized
INFO - 2024-10-28 10:02:49 --> Language Class Initialized
ERROR - 2024-10-28 10:02:49 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-28 10:02:49 --> Config Class Initialized
INFO - 2024-10-28 10:02:49 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:49 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:49 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:49 --> URI Class Initialized
INFO - 2024-10-28 10:02:49 --> Router Class Initialized
INFO - 2024-10-28 10:02:49 --> Output Class Initialized
INFO - 2024-10-28 10:02:49 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:49 --> Input Class Initialized
INFO - 2024-10-28 10:02:49 --> Language Class Initialized
ERROR - 2024-10-28 10:02:49 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-28 10:02:49 --> Config Class Initialized
INFO - 2024-10-28 10:02:49 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:02:49 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:02:49 --> Utf8 Class Initialized
INFO - 2024-10-28 10:02:49 --> URI Class Initialized
INFO - 2024-10-28 10:02:49 --> Router Class Initialized
INFO - 2024-10-28 10:02:49 --> Output Class Initialized
INFO - 2024-10-28 10:02:49 --> Security Class Initialized
DEBUG - 2024-10-28 10:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:02:49 --> Input Class Initialized
INFO - 2024-10-28 10:02:49 --> Language Class Initialized
ERROR - 2024-10-28 10:02:49 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-28 11:24:49 --> Config Class Initialized
INFO - 2024-10-28 11:24:49 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:24:49 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:24:49 --> Utf8 Class Initialized
INFO - 2024-10-28 11:24:49 --> URI Class Initialized
DEBUG - 2024-10-28 11:24:49 --> No URI present. Default controller set.
INFO - 2024-10-28 11:24:49 --> Router Class Initialized
INFO - 2024-10-28 11:24:49 --> Output Class Initialized
INFO - 2024-10-28 11:24:49 --> Security Class Initialized
DEBUG - 2024-10-28 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:24:49 --> Input Class Initialized
INFO - 2024-10-28 11:24:49 --> Language Class Initialized
INFO - 2024-10-28 11:24:49 --> Loader Class Initialized
INFO - 2024-10-28 11:24:49 --> Helper loaded: url_helper
INFO - 2024-10-28 11:24:49 --> Helper loaded: html_helper
INFO - 2024-10-28 11:24:49 --> Helper loaded: file_helper
INFO - 2024-10-28 11:24:49 --> Helper loaded: string_helper
INFO - 2024-10-28 11:24:49 --> Helper loaded: form_helper
INFO - 2024-10-28 11:24:49 --> Helper loaded: my_helper
INFO - 2024-10-28 11:24:49 --> Database Driver Class Initialized
INFO - 2024-10-28 11:24:51 --> Upload Class Initialized
INFO - 2024-10-28 11:24:51 --> Email Class Initialized
INFO - 2024-10-28 11:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:24:51 --> Form Validation Class Initialized
INFO - 2024-10-28 11:24:51 --> Controller Class Initialized
INFO - 2024-10-28 16:54:51 --> Model "MainModel" initialized
INFO - 2024-10-28 16:54:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 16:54:51 --> Final output sent to browser
DEBUG - 2024-10-28 16:54:51 --> Total execution time: 2.3187
INFO - 2024-10-28 14:51:53 --> Config Class Initialized
INFO - 2024-10-28 14:51:53 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:51:53 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:51:53 --> Utf8 Class Initialized
INFO - 2024-10-28 14:51:53 --> URI Class Initialized
DEBUG - 2024-10-28 14:51:53 --> No URI present. Default controller set.
INFO - 2024-10-28 14:51:53 --> Router Class Initialized
INFO - 2024-10-28 14:51:53 --> Output Class Initialized
INFO - 2024-10-28 14:51:53 --> Security Class Initialized
DEBUG - 2024-10-28 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:51:53 --> Input Class Initialized
INFO - 2024-10-28 14:51:53 --> Language Class Initialized
INFO - 2024-10-28 14:51:53 --> Loader Class Initialized
INFO - 2024-10-28 14:51:53 --> Helper loaded: url_helper
INFO - 2024-10-28 14:51:53 --> Helper loaded: html_helper
INFO - 2024-10-28 14:51:53 --> Helper loaded: file_helper
INFO - 2024-10-28 14:51:53 --> Helper loaded: string_helper
INFO - 2024-10-28 14:51:53 --> Helper loaded: form_helper
INFO - 2024-10-28 14:51:53 --> Helper loaded: my_helper
INFO - 2024-10-28 14:51:53 --> Database Driver Class Initialized
INFO - 2024-10-28 14:51:55 --> Upload Class Initialized
INFO - 2024-10-28 14:51:55 --> Email Class Initialized
INFO - 2024-10-28 14:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:51:55 --> Form Validation Class Initialized
INFO - 2024-10-28 14:51:55 --> Controller Class Initialized
INFO - 2024-10-28 20:21:55 --> Model "MainModel" initialized
INFO - 2024-10-28 20:21:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 20:21:55 --> Final output sent to browser
DEBUG - 2024-10-28 20:21:55 --> Total execution time: 2.2896
INFO - 2024-10-28 16:44:52 --> Config Class Initialized
INFO - 2024-10-28 16:44:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 16:44:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 16:44:52 --> Utf8 Class Initialized
INFO - 2024-10-28 16:44:52 --> URI Class Initialized
DEBUG - 2024-10-28 16:44:52 --> No URI present. Default controller set.
INFO - 2024-10-28 16:44:52 --> Router Class Initialized
INFO - 2024-10-28 16:44:52 --> Output Class Initialized
INFO - 2024-10-28 16:44:52 --> Security Class Initialized
DEBUG - 2024-10-28 16:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 16:44:52 --> Input Class Initialized
INFO - 2024-10-28 16:44:52 --> Language Class Initialized
INFO - 2024-10-28 16:44:52 --> Loader Class Initialized
INFO - 2024-10-28 16:44:52 --> Helper loaded: url_helper
INFO - 2024-10-28 16:44:52 --> Helper loaded: html_helper
INFO - 2024-10-28 16:44:52 --> Helper loaded: file_helper
INFO - 2024-10-28 16:44:52 --> Helper loaded: string_helper
INFO - 2024-10-28 16:44:52 --> Helper loaded: form_helper
INFO - 2024-10-28 16:44:52 --> Helper loaded: my_helper
INFO - 2024-10-28 16:44:52 --> Database Driver Class Initialized
INFO - 2024-10-28 16:44:55 --> Upload Class Initialized
INFO - 2024-10-28 16:44:55 --> Email Class Initialized
INFO - 2024-10-28 16:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 16:44:55 --> Form Validation Class Initialized
INFO - 2024-10-28 16:44:55 --> Controller Class Initialized
INFO - 2024-10-28 22:14:55 --> Model "MainModel" initialized
INFO - 2024-10-28 22:14:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-28 22:14:55 --> Final output sent to browser
DEBUG - 2024-10-28 22:14:55 --> Total execution time: 2.1962
INFO - 2024-10-28 19:40:11 --> Config Class Initialized
INFO - 2024-10-28 19:40:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 19:40:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 19:40:11 --> Utf8 Class Initialized
INFO - 2024-10-28 19:40:11 --> URI Class Initialized
DEBUG - 2024-10-28 19:40:11 --> No URI present. Default controller set.
INFO - 2024-10-28 19:40:11 --> Router Class Initialized
INFO - 2024-10-28 19:40:11 --> Output Class Initialized
INFO - 2024-10-28 19:40:11 --> Security Class Initialized
DEBUG - 2024-10-28 19:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 19:40:11 --> Input Class Initialized
INFO - 2024-10-28 19:40:11 --> Language Class Initialized
INFO - 2024-10-28 19:40:11 --> Loader Class Initialized
INFO - 2024-10-28 19:40:11 --> Helper loaded: url_helper
INFO - 2024-10-28 19:40:11 --> Helper loaded: html_helper
INFO - 2024-10-28 19:40:11 --> Helper loaded: file_helper
INFO - 2024-10-28 19:40:11 --> Helper loaded: string_helper
INFO - 2024-10-28 19:40:11 --> Helper loaded: form_helper
INFO - 2024-10-28 19:40:11 --> Helper loaded: my_helper
INFO - 2024-10-28 19:40:11 --> Database Driver Class Initialized
INFO - 2024-10-28 19:40:13 --> Upload Class Initialized
INFO - 2024-10-28 19:40:13 --> Email Class Initialized
INFO - 2024-10-28 19:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 19:40:13 --> Form Validation Class Initialized
INFO - 2024-10-28 19:40:13 --> Controller Class Initialized
INFO - 2024-10-28 21:21:35 --> Config Class Initialized
INFO - 2024-10-28 21:21:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:21:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:21:35 --> Utf8 Class Initialized
INFO - 2024-10-28 21:21:35 --> URI Class Initialized
DEBUG - 2024-10-28 21:21:35 --> No URI present. Default controller set.
INFO - 2024-10-28 21:21:35 --> Router Class Initialized
INFO - 2024-10-28 21:21:35 --> Output Class Initialized
INFO - 2024-10-28 21:21:35 --> Security Class Initialized
DEBUG - 2024-10-28 21:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:21:35 --> Input Class Initialized
INFO - 2024-10-28 21:21:35 --> Language Class Initialized
INFO - 2024-10-28 21:21:35 --> Loader Class Initialized
INFO - 2024-10-28 21:21:35 --> Helper loaded: url_helper
INFO - 2024-10-28 21:21:35 --> Helper loaded: html_helper
INFO - 2024-10-28 21:21:35 --> Helper loaded: file_helper
INFO - 2024-10-28 21:21:35 --> Helper loaded: string_helper
INFO - 2024-10-28 21:21:35 --> Helper loaded: form_helper
INFO - 2024-10-28 21:21:35 --> Helper loaded: my_helper
INFO - 2024-10-28 21:21:35 --> Database Driver Class Initialized
INFO - 2024-10-28 21:21:37 --> Upload Class Initialized
INFO - 2024-10-28 21:21:37 --> Email Class Initialized
INFO - 2024-10-28 21:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:21:37 --> Form Validation Class Initialized
INFO - 2024-10-28 21:21:37 --> Controller Class Initialized
INFO - 2024-10-28 21:21:38 --> Config Class Initialized
INFO - 2024-10-28 21:21:38 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:21:38 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:21:38 --> Utf8 Class Initialized
INFO - 2024-10-28 21:21:38 --> URI Class Initialized
INFO - 2024-10-28 21:21:38 --> Router Class Initialized
INFO - 2024-10-28 21:21:38 --> Output Class Initialized
INFO - 2024-10-28 21:21:38 --> Security Class Initialized
DEBUG - 2024-10-28 21:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:21:38 --> Input Class Initialized
INFO - 2024-10-28 21:21:38 --> Language Class Initialized
ERROR - 2024-10-28 21:21:38 --> 404 Page Not Found: Https:/livservice.in
