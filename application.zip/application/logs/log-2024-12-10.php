<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-10 00:53:29 --> Config Class Initialized
INFO - 2024-12-10 00:53:29 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:53:29 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:53:29 --> Utf8 Class Initialized
INFO - 2024-12-10 00:53:29 --> URI Class Initialized
DEBUG - 2024-12-10 00:53:29 --> No URI present. Default controller set.
INFO - 2024-12-10 00:53:29 --> Router Class Initialized
INFO - 2024-12-10 00:53:29 --> Output Class Initialized
INFO - 2024-12-10 00:53:29 --> Security Class Initialized
DEBUG - 2024-12-10 00:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:53:29 --> Input Class Initialized
INFO - 2024-12-10 00:53:29 --> Language Class Initialized
INFO - 2024-12-10 00:53:29 --> Loader Class Initialized
INFO - 2024-12-10 00:53:29 --> Helper loaded: url_helper
INFO - 2024-12-10 00:53:29 --> Helper loaded: html_helper
INFO - 2024-12-10 00:53:29 --> Helper loaded: file_helper
INFO - 2024-12-10 00:53:29 --> Helper loaded: string_helper
INFO - 2024-12-10 00:53:29 --> Helper loaded: form_helper
INFO - 2024-12-10 00:53:29 --> Helper loaded: my_helper
INFO - 2024-12-10 00:53:29 --> Database Driver Class Initialized
INFO - 2024-12-10 00:53:31 --> Upload Class Initialized
INFO - 2024-12-10 00:53:31 --> Email Class Initialized
INFO - 2024-12-10 00:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:53:32 --> Form Validation Class Initialized
INFO - 2024-12-10 00:53:32 --> Controller Class Initialized
INFO - 2024-12-10 06:23:32 --> Model "MainModel" initialized
INFO - 2024-12-10 06:23:32 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 06:23:32 --> Final output sent to browser
DEBUG - 2024-12-10 06:23:32 --> Total execution time: 2.6263
INFO - 2024-12-10 00:53:33 --> Config Class Initialized
INFO - 2024-12-10 00:53:33 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:53:33 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:53:33 --> Utf8 Class Initialized
INFO - 2024-12-10 00:53:33 --> URI Class Initialized
DEBUG - 2024-12-10 00:53:33 --> No URI present. Default controller set.
INFO - 2024-12-10 00:53:33 --> Router Class Initialized
INFO - 2024-12-10 00:53:33 --> Output Class Initialized
INFO - 2024-12-10 00:53:33 --> Security Class Initialized
DEBUG - 2024-12-10 00:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:53:33 --> Input Class Initialized
INFO - 2024-12-10 00:53:33 --> Language Class Initialized
INFO - 2024-12-10 00:53:33 --> Loader Class Initialized
INFO - 2024-12-10 00:53:33 --> Helper loaded: url_helper
INFO - 2024-12-10 00:53:33 --> Helper loaded: html_helper
INFO - 2024-12-10 00:53:33 --> Helper loaded: file_helper
INFO - 2024-12-10 00:53:33 --> Helper loaded: string_helper
INFO - 2024-12-10 00:53:33 --> Helper loaded: form_helper
INFO - 2024-12-10 00:53:33 --> Helper loaded: my_helper
INFO - 2024-12-10 00:53:33 --> Database Driver Class Initialized
INFO - 2024-12-10 00:53:35 --> Upload Class Initialized
INFO - 2024-12-10 00:53:35 --> Email Class Initialized
INFO - 2024-12-10 00:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:53:35 --> Form Validation Class Initialized
INFO - 2024-12-10 00:53:35 --> Controller Class Initialized
INFO - 2024-12-10 06:23:35 --> Model "MainModel" initialized
INFO - 2024-12-10 06:23:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 06:23:35 --> Final output sent to browser
DEBUG - 2024-12-10 06:23:35 --> Total execution time: 2.1377
INFO - 2024-12-10 00:53:37 --> Config Class Initialized
INFO - 2024-12-10 00:53:37 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:53:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:53:37 --> Utf8 Class Initialized
INFO - 2024-12-10 00:53:37 --> URI Class Initialized
DEBUG - 2024-12-10 00:53:37 --> No URI present. Default controller set.
INFO - 2024-12-10 00:53:37 --> Router Class Initialized
INFO - 2024-12-10 00:53:37 --> Output Class Initialized
INFO - 2024-12-10 00:53:37 --> Security Class Initialized
DEBUG - 2024-12-10 00:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:53:37 --> Input Class Initialized
INFO - 2024-12-10 00:53:37 --> Language Class Initialized
INFO - 2024-12-10 00:53:37 --> Loader Class Initialized
INFO - 2024-12-10 00:53:37 --> Helper loaded: url_helper
INFO - 2024-12-10 00:53:37 --> Helper loaded: html_helper
INFO - 2024-12-10 00:53:37 --> Helper loaded: file_helper
INFO - 2024-12-10 00:53:37 --> Helper loaded: string_helper
INFO - 2024-12-10 00:53:37 --> Helper loaded: form_helper
INFO - 2024-12-10 00:53:37 --> Helper loaded: my_helper
INFO - 2024-12-10 00:53:37 --> Database Driver Class Initialized
INFO - 2024-12-10 00:53:39 --> Upload Class Initialized
INFO - 2024-12-10 00:53:39 --> Email Class Initialized
INFO - 2024-12-10 00:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:53:39 --> Form Validation Class Initialized
INFO - 2024-12-10 00:53:39 --> Controller Class Initialized
INFO - 2024-12-10 06:23:39 --> Model "MainModel" initialized
INFO - 2024-12-10 06:23:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 06:23:39 --> Final output sent to browser
DEBUG - 2024-12-10 06:23:39 --> Total execution time: 2.1416
INFO - 2024-12-10 00:53:40 --> Config Class Initialized
INFO - 2024-12-10 00:53:40 --> Hooks Class Initialized
DEBUG - 2024-12-10 00:53:40 --> UTF-8 Support Enabled
INFO - 2024-12-10 00:53:40 --> Utf8 Class Initialized
INFO - 2024-12-10 00:53:40 --> URI Class Initialized
DEBUG - 2024-12-10 00:53:40 --> No URI present. Default controller set.
INFO - 2024-12-10 00:53:40 --> Router Class Initialized
INFO - 2024-12-10 00:53:40 --> Output Class Initialized
INFO - 2024-12-10 00:53:40 --> Security Class Initialized
DEBUG - 2024-12-10 00:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 00:53:40 --> Input Class Initialized
INFO - 2024-12-10 00:53:40 --> Language Class Initialized
INFO - 2024-12-10 00:53:40 --> Loader Class Initialized
INFO - 2024-12-10 00:53:40 --> Helper loaded: url_helper
INFO - 2024-12-10 00:53:40 --> Helper loaded: html_helper
INFO - 2024-12-10 00:53:40 --> Helper loaded: file_helper
INFO - 2024-12-10 00:53:40 --> Helper loaded: string_helper
INFO - 2024-12-10 00:53:40 --> Helper loaded: form_helper
INFO - 2024-12-10 00:53:40 --> Helper loaded: my_helper
INFO - 2024-12-10 00:53:40 --> Database Driver Class Initialized
INFO - 2024-12-10 00:53:42 --> Upload Class Initialized
INFO - 2024-12-10 00:53:42 --> Email Class Initialized
INFO - 2024-12-10 00:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 00:53:42 --> Form Validation Class Initialized
INFO - 2024-12-10 00:53:42 --> Controller Class Initialized
INFO - 2024-12-10 06:23:42 --> Model "MainModel" initialized
INFO - 2024-12-10 06:23:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 06:23:42 --> Final output sent to browser
DEBUG - 2024-12-10 06:23:42 --> Total execution time: 2.1449
INFO - 2024-12-10 08:17:34 --> Config Class Initialized
INFO - 2024-12-10 08:17:35 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:35 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:35 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:35 --> URI Class Initialized
DEBUG - 2024-12-10 08:17:35 --> No URI present. Default controller set.
INFO - 2024-12-10 08:17:35 --> Router Class Initialized
INFO - 2024-12-10 08:17:35 --> Output Class Initialized
INFO - 2024-12-10 08:17:35 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:35 --> Input Class Initialized
INFO - 2024-12-10 08:17:35 --> Language Class Initialized
INFO - 2024-12-10 08:17:35 --> Loader Class Initialized
INFO - 2024-12-10 08:17:36 --> Helper loaded: url_helper
INFO - 2024-12-10 08:17:36 --> Helper loaded: html_helper
INFO - 2024-12-10 08:17:36 --> Helper loaded: file_helper
INFO - 2024-12-10 08:17:36 --> Helper loaded: string_helper
INFO - 2024-12-10 08:17:36 --> Helper loaded: form_helper
INFO - 2024-12-10 08:17:36 --> Helper loaded: my_helper
INFO - 2024-12-10 08:17:37 --> Database Driver Class Initialized
INFO - 2024-12-10 08:17:39 --> Upload Class Initialized
INFO - 2024-12-10 08:17:39 --> Email Class Initialized
INFO - 2024-12-10 08:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 08:17:40 --> Form Validation Class Initialized
INFO - 2024-12-10 08:17:40 --> Controller Class Initialized
INFO - 2024-12-10 13:47:40 --> Model "MainModel" initialized
INFO - 2024-12-10 13:47:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 13:47:41 --> Final output sent to browser
DEBUG - 2024-12-10 13:47:41 --> Total execution time: 6.3748
INFO - 2024-12-10 08:17:41 --> Config Class Initialized
INFO - 2024-12-10 08:17:41 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:41 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:41 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:41 --> URI Class Initialized
INFO - 2024-12-10 08:17:41 --> Router Class Initialized
INFO - 2024-12-10 08:17:41 --> Output Class Initialized
INFO - 2024-12-10 08:17:41 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:41 --> Input Class Initialized
INFO - 2024-12-10 08:17:41 --> Language Class Initialized
ERROR - 2024-12-10 08:17:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-10 08:17:42 --> Config Class Initialized
INFO - 2024-12-10 08:17:42 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:42 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:42 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:42 --> URI Class Initialized
INFO - 2024-12-10 08:17:42 --> Router Class Initialized
INFO - 2024-12-10 08:17:42 --> Output Class Initialized
INFO - 2024-12-10 08:17:42 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:42 --> Input Class Initialized
INFO - 2024-12-10 08:17:42 --> Language Class Initialized
ERROR - 2024-12-10 08:17:42 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-10 08:17:42 --> Config Class Initialized
INFO - 2024-12-10 08:17:42 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:42 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:42 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:42 --> URI Class Initialized
DEBUG - 2024-12-10 08:17:42 --> No URI present. Default controller set.
INFO - 2024-12-10 08:17:42 --> Router Class Initialized
INFO - 2024-12-10 08:17:42 --> Output Class Initialized
INFO - 2024-12-10 08:17:42 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:42 --> Input Class Initialized
INFO - 2024-12-10 08:17:42 --> Language Class Initialized
INFO - 2024-12-10 08:17:42 --> Loader Class Initialized
INFO - 2024-12-10 08:17:42 --> Helper loaded: url_helper
INFO - 2024-12-10 08:17:42 --> Helper loaded: html_helper
INFO - 2024-12-10 08:17:42 --> Helper loaded: file_helper
INFO - 2024-12-10 08:17:42 --> Helper loaded: string_helper
INFO - 2024-12-10 08:17:42 --> Helper loaded: form_helper
INFO - 2024-12-10 08:17:42 --> Helper loaded: my_helper
INFO - 2024-12-10 08:17:42 --> Database Driver Class Initialized
INFO - 2024-12-10 08:17:44 --> Upload Class Initialized
INFO - 2024-12-10 08:17:44 --> Email Class Initialized
INFO - 2024-12-10 08:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 08:17:44 --> Form Validation Class Initialized
INFO - 2024-12-10 08:17:44 --> Controller Class Initialized
INFO - 2024-12-10 13:47:44 --> Model "MainModel" initialized
INFO - 2024-12-10 13:47:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 13:47:44 --> Final output sent to browser
DEBUG - 2024-12-10 13:47:44 --> Total execution time: 2.2446
INFO - 2024-12-10 08:17:44 --> Config Class Initialized
INFO - 2024-12-10 08:17:44 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:44 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:44 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:44 --> URI Class Initialized
INFO - 2024-12-10 08:17:44 --> Router Class Initialized
INFO - 2024-12-10 08:17:44 --> Output Class Initialized
INFO - 2024-12-10 08:17:44 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:44 --> Input Class Initialized
INFO - 2024-12-10 08:17:44 --> Language Class Initialized
ERROR - 2024-12-10 08:17:44 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-10 08:17:45 --> Config Class Initialized
INFO - 2024-12-10 08:17:45 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:45 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:45 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:45 --> URI Class Initialized
INFO - 2024-12-10 08:17:45 --> Router Class Initialized
INFO - 2024-12-10 08:17:45 --> Output Class Initialized
INFO - 2024-12-10 08:17:45 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:45 --> Input Class Initialized
INFO - 2024-12-10 08:17:45 --> Language Class Initialized
ERROR - 2024-12-10 08:17:45 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-10 08:17:45 --> Config Class Initialized
INFO - 2024-12-10 08:17:45 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:45 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:45 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:45 --> URI Class Initialized
INFO - 2024-12-10 08:17:45 --> Router Class Initialized
INFO - 2024-12-10 08:17:45 --> Output Class Initialized
INFO - 2024-12-10 08:17:45 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:45 --> Input Class Initialized
INFO - 2024-12-10 08:17:45 --> Language Class Initialized
ERROR - 2024-12-10 08:17:45 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-10 08:17:45 --> Config Class Initialized
INFO - 2024-12-10 08:17:45 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:45 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:45 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:45 --> URI Class Initialized
INFO - 2024-12-10 08:17:45 --> Router Class Initialized
INFO - 2024-12-10 08:17:45 --> Output Class Initialized
INFO - 2024-12-10 08:17:45 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:45 --> Input Class Initialized
INFO - 2024-12-10 08:17:45 --> Language Class Initialized
ERROR - 2024-12-10 08:17:45 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-10 08:17:46 --> Config Class Initialized
INFO - 2024-12-10 08:17:46 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:46 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:46 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:46 --> URI Class Initialized
INFO - 2024-12-10 08:17:46 --> Router Class Initialized
INFO - 2024-12-10 08:17:46 --> Output Class Initialized
INFO - 2024-12-10 08:17:46 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:46 --> Input Class Initialized
INFO - 2024-12-10 08:17:46 --> Language Class Initialized
ERROR - 2024-12-10 08:17:46 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-10 08:17:46 --> Config Class Initialized
INFO - 2024-12-10 08:17:46 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:46 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:46 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:46 --> URI Class Initialized
INFO - 2024-12-10 08:17:46 --> Router Class Initialized
INFO - 2024-12-10 08:17:46 --> Output Class Initialized
INFO - 2024-12-10 08:17:46 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:46 --> Input Class Initialized
INFO - 2024-12-10 08:17:46 --> Language Class Initialized
ERROR - 2024-12-10 08:17:46 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-10 08:17:46 --> Config Class Initialized
INFO - 2024-12-10 08:17:46 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:46 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:46 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:46 --> URI Class Initialized
INFO - 2024-12-10 08:17:46 --> Router Class Initialized
INFO - 2024-12-10 08:17:46 --> Output Class Initialized
INFO - 2024-12-10 08:17:46 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:46 --> Input Class Initialized
INFO - 2024-12-10 08:17:46 --> Language Class Initialized
ERROR - 2024-12-10 08:17:46 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-12-10 08:17:47 --> Config Class Initialized
INFO - 2024-12-10 08:17:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:47 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:47 --> URI Class Initialized
INFO - 2024-12-10 08:17:47 --> Router Class Initialized
INFO - 2024-12-10 08:17:47 --> Output Class Initialized
INFO - 2024-12-10 08:17:47 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:47 --> Input Class Initialized
INFO - 2024-12-10 08:17:47 --> Language Class Initialized
ERROR - 2024-12-10 08:17:47 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-10 08:17:47 --> Config Class Initialized
INFO - 2024-12-10 08:17:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:47 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:47 --> URI Class Initialized
INFO - 2024-12-10 08:17:47 --> Router Class Initialized
INFO - 2024-12-10 08:17:47 --> Output Class Initialized
INFO - 2024-12-10 08:17:47 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:47 --> Input Class Initialized
INFO - 2024-12-10 08:17:47 --> Language Class Initialized
ERROR - 2024-12-10 08:17:47 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-10 08:17:47 --> Config Class Initialized
INFO - 2024-12-10 08:17:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:47 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:47 --> URI Class Initialized
INFO - 2024-12-10 08:17:47 --> Router Class Initialized
INFO - 2024-12-10 08:17:47 --> Output Class Initialized
INFO - 2024-12-10 08:17:47 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:47 --> Input Class Initialized
INFO - 2024-12-10 08:17:47 --> Language Class Initialized
ERROR - 2024-12-10 08:17:47 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-10 08:17:47 --> Config Class Initialized
INFO - 2024-12-10 08:17:47 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:47 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:47 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:47 --> URI Class Initialized
INFO - 2024-12-10 08:17:47 --> Router Class Initialized
INFO - 2024-12-10 08:17:47 --> Output Class Initialized
INFO - 2024-12-10 08:17:47 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:48 --> Input Class Initialized
INFO - 2024-12-10 08:17:48 --> Language Class Initialized
ERROR - 2024-12-10 08:17:48 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-10 08:17:48 --> Config Class Initialized
INFO - 2024-12-10 08:17:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:48 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:48 --> URI Class Initialized
INFO - 2024-12-10 08:17:48 --> Router Class Initialized
INFO - 2024-12-10 08:17:48 --> Output Class Initialized
INFO - 2024-12-10 08:17:48 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:48 --> Input Class Initialized
INFO - 2024-12-10 08:17:48 --> Language Class Initialized
ERROR - 2024-12-10 08:17:48 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-12-10 08:17:48 --> Config Class Initialized
INFO - 2024-12-10 08:17:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:48 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:48 --> URI Class Initialized
INFO - 2024-12-10 08:17:48 --> Router Class Initialized
INFO - 2024-12-10 08:17:48 --> Output Class Initialized
INFO - 2024-12-10 08:17:48 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:48 --> Input Class Initialized
INFO - 2024-12-10 08:17:48 --> Language Class Initialized
ERROR - 2024-12-10 08:17:48 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-10 08:17:48 --> Config Class Initialized
INFO - 2024-12-10 08:17:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:48 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:48 --> URI Class Initialized
INFO - 2024-12-10 08:17:48 --> Router Class Initialized
INFO - 2024-12-10 08:17:48 --> Output Class Initialized
INFO - 2024-12-10 08:17:48 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:48 --> Input Class Initialized
INFO - 2024-12-10 08:17:48 --> Language Class Initialized
ERROR - 2024-12-10 08:17:48 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-10 08:17:49 --> Config Class Initialized
INFO - 2024-12-10 08:17:49 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:49 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:49 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:49 --> URI Class Initialized
INFO - 2024-12-10 08:17:49 --> Router Class Initialized
INFO - 2024-12-10 08:17:49 --> Output Class Initialized
INFO - 2024-12-10 08:17:49 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:49 --> Input Class Initialized
INFO - 2024-12-10 08:17:49 --> Language Class Initialized
ERROR - 2024-12-10 08:17:49 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-10 08:17:49 --> Config Class Initialized
INFO - 2024-12-10 08:17:49 --> Hooks Class Initialized
DEBUG - 2024-12-10 08:17:49 --> UTF-8 Support Enabled
INFO - 2024-12-10 08:17:49 --> Utf8 Class Initialized
INFO - 2024-12-10 08:17:49 --> URI Class Initialized
INFO - 2024-12-10 08:17:49 --> Router Class Initialized
INFO - 2024-12-10 08:17:49 --> Output Class Initialized
INFO - 2024-12-10 08:17:49 --> Security Class Initialized
DEBUG - 2024-12-10 08:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 08:17:49 --> Input Class Initialized
INFO - 2024-12-10 08:17:49 --> Language Class Initialized
ERROR - 2024-12-10 08:17:49 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-12-10 10:05:33 --> Config Class Initialized
INFO - 2024-12-10 10:05:33 --> Hooks Class Initialized
DEBUG - 2024-12-10 10:05:33 --> UTF-8 Support Enabled
INFO - 2024-12-10 10:05:33 --> Utf8 Class Initialized
INFO - 2024-12-10 10:05:33 --> URI Class Initialized
DEBUG - 2024-12-10 10:05:33 --> No URI present. Default controller set.
INFO - 2024-12-10 10:05:33 --> Router Class Initialized
INFO - 2024-12-10 10:05:33 --> Output Class Initialized
INFO - 2024-12-10 10:05:33 --> Security Class Initialized
DEBUG - 2024-12-10 10:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 10:05:33 --> Input Class Initialized
INFO - 2024-12-10 10:05:33 --> Language Class Initialized
INFO - 2024-12-10 10:05:33 --> Loader Class Initialized
INFO - 2024-12-10 10:05:33 --> Helper loaded: url_helper
INFO - 2024-12-10 10:05:33 --> Helper loaded: html_helper
INFO - 2024-12-10 10:05:33 --> Helper loaded: file_helper
INFO - 2024-12-10 10:05:33 --> Helper loaded: string_helper
INFO - 2024-12-10 10:05:33 --> Helper loaded: form_helper
INFO - 2024-12-10 10:05:33 --> Helper loaded: my_helper
INFO - 2024-12-10 10:05:33 --> Database Driver Class Initialized
INFO - 2024-12-10 10:05:35 --> Upload Class Initialized
INFO - 2024-12-10 10:05:35 --> Email Class Initialized
INFO - 2024-12-10 10:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 10:05:35 --> Form Validation Class Initialized
INFO - 2024-12-10 10:05:35 --> Controller Class Initialized
INFO - 2024-12-10 15:35:35 --> Model "MainModel" initialized
INFO - 2024-12-10 15:35:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 15:35:35 --> Final output sent to browser
DEBUG - 2024-12-10 15:35:35 --> Total execution time: 2.2179
INFO - 2024-12-10 10:05:39 --> Config Class Initialized
INFO - 2024-12-10 10:05:39 --> Hooks Class Initialized
DEBUG - 2024-12-10 10:05:39 --> UTF-8 Support Enabled
INFO - 2024-12-10 10:05:39 --> Utf8 Class Initialized
INFO - 2024-12-10 10:05:39 --> URI Class Initialized
INFO - 2024-12-10 10:05:39 --> Router Class Initialized
INFO - 2024-12-10 10:05:39 --> Output Class Initialized
INFO - 2024-12-10 10:05:39 --> Security Class Initialized
DEBUG - 2024-12-10 10:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 10:05:39 --> Input Class Initialized
INFO - 2024-12-10 10:05:39 --> Language Class Initialized
ERROR - 2024-12-10 10:05:39 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-10 10:10:35 --> Config Class Initialized
INFO - 2024-12-10 10:10:35 --> Hooks Class Initialized
DEBUG - 2024-12-10 10:10:35 --> UTF-8 Support Enabled
INFO - 2024-12-10 10:10:35 --> Utf8 Class Initialized
INFO - 2024-12-10 10:10:35 --> URI Class Initialized
DEBUG - 2024-12-10 10:10:35 --> No URI present. Default controller set.
INFO - 2024-12-10 10:10:35 --> Router Class Initialized
INFO - 2024-12-10 10:10:35 --> Output Class Initialized
INFO - 2024-12-10 10:10:35 --> Security Class Initialized
DEBUG - 2024-12-10 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 10:10:35 --> Input Class Initialized
INFO - 2024-12-10 10:10:35 --> Language Class Initialized
INFO - 2024-12-10 10:10:35 --> Loader Class Initialized
INFO - 2024-12-10 10:10:35 --> Helper loaded: url_helper
INFO - 2024-12-10 10:10:35 --> Helper loaded: html_helper
INFO - 2024-12-10 10:10:35 --> Helper loaded: file_helper
INFO - 2024-12-10 10:10:35 --> Helper loaded: string_helper
INFO - 2024-12-10 10:10:35 --> Helper loaded: form_helper
INFO - 2024-12-10 10:10:35 --> Helper loaded: my_helper
INFO - 2024-12-10 10:10:35 --> Database Driver Class Initialized
INFO - 2024-12-10 10:10:37 --> Upload Class Initialized
INFO - 2024-12-10 10:10:37 --> Email Class Initialized
INFO - 2024-12-10 10:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 10:10:37 --> Form Validation Class Initialized
INFO - 2024-12-10 10:10:37 --> Controller Class Initialized
INFO - 2024-12-10 15:40:37 --> Model "MainModel" initialized
INFO - 2024-12-10 15:40:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 15:40:37 --> Final output sent to browser
DEBUG - 2024-12-10 15:40:37 --> Total execution time: 2.2590
INFO - 2024-12-10 10:10:42 --> Config Class Initialized
INFO - 2024-12-10 10:10:42 --> Hooks Class Initialized
DEBUG - 2024-12-10 10:10:42 --> UTF-8 Support Enabled
INFO - 2024-12-10 10:10:42 --> Utf8 Class Initialized
INFO - 2024-12-10 10:10:42 --> URI Class Initialized
INFO - 2024-12-10 10:10:42 --> Router Class Initialized
INFO - 2024-12-10 10:10:42 --> Output Class Initialized
INFO - 2024-12-10 10:10:42 --> Security Class Initialized
DEBUG - 2024-12-10 10:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 10:10:42 --> Input Class Initialized
INFO - 2024-12-10 10:10:42 --> Language Class Initialized
ERROR - 2024-12-10 10:10:42 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-10 14:38:39 --> Config Class Initialized
INFO - 2024-12-10 14:38:39 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:38:39 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:38:39 --> Utf8 Class Initialized
INFO - 2024-12-10 14:38:39 --> URI Class Initialized
DEBUG - 2024-12-10 14:38:40 --> No URI present. Default controller set.
INFO - 2024-12-10 14:38:40 --> Router Class Initialized
INFO - 2024-12-10 14:38:40 --> Output Class Initialized
INFO - 2024-12-10 14:38:40 --> Security Class Initialized
DEBUG - 2024-12-10 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:38:40 --> Input Class Initialized
INFO - 2024-12-10 14:38:40 --> Language Class Initialized
INFO - 2024-12-10 14:38:40 --> Loader Class Initialized
INFO - 2024-12-10 14:38:40 --> Helper loaded: url_helper
INFO - 2024-12-10 14:38:40 --> Helper loaded: html_helper
INFO - 2024-12-10 14:38:40 --> Helper loaded: file_helper
INFO - 2024-12-10 14:38:40 --> Helper loaded: string_helper
INFO - 2024-12-10 14:38:40 --> Helper loaded: form_helper
INFO - 2024-12-10 14:38:40 --> Helper loaded: my_helper
INFO - 2024-12-10 14:38:40 --> Database Driver Class Initialized
INFO - 2024-12-10 14:38:42 --> Upload Class Initialized
INFO - 2024-12-10 14:38:42 --> Email Class Initialized
INFO - 2024-12-10 14:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 14:38:42 --> Form Validation Class Initialized
INFO - 2024-12-10 14:38:42 --> Controller Class Initialized
INFO - 2024-12-10 20:08:42 --> Model "MainModel" initialized
INFO - 2024-12-10 20:08:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 20:08:42 --> Final output sent to browser
DEBUG - 2024-12-10 20:08:42 --> Total execution time: 3.0882
INFO - 2024-12-10 14:38:43 --> Config Class Initialized
INFO - 2024-12-10 14:38:43 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:38:43 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:38:43 --> Utf8 Class Initialized
INFO - 2024-12-10 14:38:43 --> URI Class Initialized
INFO - 2024-12-10 14:38:43 --> Router Class Initialized
INFO - 2024-12-10 14:38:43 --> Output Class Initialized
INFO - 2024-12-10 14:38:43 --> Security Class Initialized
DEBUG - 2024-12-10 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:38:43 --> Input Class Initialized
INFO - 2024-12-10 14:38:43 --> Language Class Initialized
INFO - 2024-12-10 14:38:43 --> Loader Class Initialized
INFO - 2024-12-10 14:38:43 --> Helper loaded: url_helper
INFO - 2024-12-10 14:38:43 --> Helper loaded: html_helper
INFO - 2024-12-10 14:38:43 --> Helper loaded: file_helper
INFO - 2024-12-10 14:38:43 --> Helper loaded: string_helper
INFO - 2024-12-10 14:38:43 --> Helper loaded: form_helper
INFO - 2024-12-10 14:38:43 --> Helper loaded: my_helper
INFO - 2024-12-10 14:38:43 --> Database Driver Class Initialized
INFO - 2024-12-10 14:38:45 --> Upload Class Initialized
INFO - 2024-12-10 14:38:45 --> Email Class Initialized
INFO - 2024-12-10 14:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 14:38:45 --> Form Validation Class Initialized
INFO - 2024-12-10 14:38:45 --> Controller Class Initialized
INFO - 2024-12-10 20:08:45 --> Model "MainModel" initialized
DEBUG - 2024-12-10 20:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-10 20:08:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-12-10 20:08:45 --> Final output sent to browser
DEBUG - 2024-12-10 20:08:45 --> Total execution time: 2.1853
INFO - 2024-12-10 14:38:45 --> Config Class Initialized
INFO - 2024-12-10 14:38:45 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:38:45 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:38:45 --> Utf8 Class Initialized
INFO - 2024-12-10 14:38:45 --> URI Class Initialized
INFO - 2024-12-10 14:38:45 --> Router Class Initialized
INFO - 2024-12-10 14:38:45 --> Output Class Initialized
INFO - 2024-12-10 14:38:45 --> Security Class Initialized
DEBUG - 2024-12-10 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:38:45 --> Input Class Initialized
INFO - 2024-12-10 14:38:45 --> Language Class Initialized
INFO - 2024-12-10 14:38:45 --> Loader Class Initialized
INFO - 2024-12-10 14:38:45 --> Helper loaded: url_helper
INFO - 2024-12-10 14:38:45 --> Helper loaded: html_helper
INFO - 2024-12-10 14:38:45 --> Helper loaded: file_helper
INFO - 2024-12-10 14:38:45 --> Helper loaded: string_helper
INFO - 2024-12-10 14:38:45 --> Helper loaded: form_helper
INFO - 2024-12-10 14:38:45 --> Helper loaded: my_helper
INFO - 2024-12-10 14:38:45 --> Database Driver Class Initialized
INFO - 2024-12-10 14:38:47 --> Upload Class Initialized
INFO - 2024-12-10 14:38:47 --> Email Class Initialized
INFO - 2024-12-10 14:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 14:38:47 --> Form Validation Class Initialized
INFO - 2024-12-10 14:38:47 --> Controller Class Initialized
INFO - 2024-12-10 20:08:47 --> Model "MainModel" initialized
INFO - 2024-12-10 14:38:48 --> Config Class Initialized
INFO - 2024-12-10 14:38:48 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:38:48 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:38:48 --> Utf8 Class Initialized
INFO - 2024-12-10 14:38:48 --> URI Class Initialized
DEBUG - 2024-12-10 14:38:48 --> No URI present. Default controller set.
INFO - 2024-12-10 14:38:48 --> Router Class Initialized
INFO - 2024-12-10 14:38:48 --> Output Class Initialized
INFO - 2024-12-10 14:38:48 --> Security Class Initialized
DEBUG - 2024-12-10 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:38:48 --> Input Class Initialized
INFO - 2024-12-10 14:38:48 --> Language Class Initialized
INFO - 2024-12-10 14:38:48 --> Loader Class Initialized
INFO - 2024-12-10 14:38:48 --> Helper loaded: url_helper
INFO - 2024-12-10 14:38:48 --> Helper loaded: html_helper
INFO - 2024-12-10 14:38:48 --> Helper loaded: file_helper
INFO - 2024-12-10 14:38:48 --> Helper loaded: string_helper
INFO - 2024-12-10 14:38:48 --> Helper loaded: form_helper
INFO - 2024-12-10 14:38:48 --> Helper loaded: my_helper
INFO - 2024-12-10 14:38:48 --> Database Driver Class Initialized
INFO - 2024-12-10 14:38:50 --> Upload Class Initialized
INFO - 2024-12-10 14:38:50 --> Email Class Initialized
INFO - 2024-12-10 14:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 14:38:50 --> Form Validation Class Initialized
INFO - 2024-12-10 14:38:50 --> Controller Class Initialized
INFO - 2024-12-10 20:08:50 --> Model "MainModel" initialized
INFO - 2024-12-10 20:08:50 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 20:08:50 --> Final output sent to browser
DEBUG - 2024-12-10 20:08:50 --> Total execution time: 2.1445
INFO - 2024-12-10 14:38:50 --> Config Class Initialized
INFO - 2024-12-10 14:38:50 --> Hooks Class Initialized
DEBUG - 2024-12-10 14:38:50 --> UTF-8 Support Enabled
INFO - 2024-12-10 14:38:50 --> Utf8 Class Initialized
INFO - 2024-12-10 14:38:50 --> URI Class Initialized
DEBUG - 2024-12-10 14:38:50 --> No URI present. Default controller set.
INFO - 2024-12-10 14:38:50 --> Router Class Initialized
INFO - 2024-12-10 14:38:50 --> Output Class Initialized
INFO - 2024-12-10 14:38:50 --> Security Class Initialized
DEBUG - 2024-12-10 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 14:38:50 --> Input Class Initialized
INFO - 2024-12-10 14:38:50 --> Language Class Initialized
INFO - 2024-12-10 14:38:50 --> Loader Class Initialized
INFO - 2024-12-10 14:38:50 --> Helper loaded: url_helper
INFO - 2024-12-10 14:38:50 --> Helper loaded: html_helper
INFO - 2024-12-10 14:38:50 --> Helper loaded: file_helper
INFO - 2024-12-10 14:38:50 --> Helper loaded: string_helper
INFO - 2024-12-10 14:38:50 --> Helper loaded: form_helper
INFO - 2024-12-10 14:38:50 --> Helper loaded: my_helper
INFO - 2024-12-10 14:38:50 --> Database Driver Class Initialized
INFO - 2024-12-10 14:38:52 --> Upload Class Initialized
INFO - 2024-12-10 14:38:52 --> Email Class Initialized
INFO - 2024-12-10 14:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 14:38:52 --> Form Validation Class Initialized
INFO - 2024-12-10 14:38:52 --> Controller Class Initialized
INFO - 2024-12-10 20:08:52 --> Model "MainModel" initialized
INFO - 2024-12-10 20:08:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-10 20:08:52 --> Final output sent to browser
DEBUG - 2024-12-10 20:08:52 --> Total execution time: 2.1642
INFO - 2024-12-10 19:48:37 --> Config Class Initialized
INFO - 2024-12-10 19:48:37 --> Hooks Class Initialized
DEBUG - 2024-12-10 19:48:37 --> UTF-8 Support Enabled
INFO - 2024-12-10 19:48:37 --> Utf8 Class Initialized
INFO - 2024-12-10 19:48:37 --> URI Class Initialized
DEBUG - 2024-12-10 19:48:37 --> No URI present. Default controller set.
INFO - 2024-12-10 19:48:37 --> Router Class Initialized
INFO - 2024-12-10 19:48:37 --> Output Class Initialized
INFO - 2024-12-10 19:48:37 --> Security Class Initialized
DEBUG - 2024-12-10 19:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-10 19:48:37 --> Input Class Initialized
INFO - 2024-12-10 19:48:37 --> Language Class Initialized
INFO - 2024-12-10 19:48:37 --> Loader Class Initialized
INFO - 2024-12-10 19:48:37 --> Helper loaded: url_helper
INFO - 2024-12-10 19:48:37 --> Helper loaded: html_helper
INFO - 2024-12-10 19:48:37 --> Helper loaded: file_helper
INFO - 2024-12-10 19:48:37 --> Helper loaded: string_helper
INFO - 2024-12-10 19:48:37 --> Helper loaded: form_helper
INFO - 2024-12-10 19:48:37 --> Helper loaded: my_helper
INFO - 2024-12-10 19:48:37 --> Database Driver Class Initialized
INFO - 2024-12-10 19:48:39 --> Upload Class Initialized
INFO - 2024-12-10 19:48:39 --> Email Class Initialized
INFO - 2024-12-10 19:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-10 19:48:39 --> Form Validation Class Initialized
INFO - 2024-12-10 19:48:39 --> Controller Class Initialized
