<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-04 08:00:40 --> Config Class Initialized
INFO - 2024-11-04 08:00:40 --> Hooks Class Initialized
DEBUG - 2024-11-04 08:00:41 --> UTF-8 Support Enabled
INFO - 2024-11-04 08:00:41 --> Utf8 Class Initialized
INFO - 2024-11-04 08:00:41 --> URI Class Initialized
DEBUG - 2024-11-04 08:00:41 --> No URI present. Default controller set.
INFO - 2024-11-04 08:00:41 --> Router Class Initialized
INFO - 2024-11-04 08:00:41 --> Output Class Initialized
INFO - 2024-11-04 08:00:41 --> Security Class Initialized
DEBUG - 2024-11-04 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 08:00:41 --> Input Class Initialized
INFO - 2024-11-04 08:00:41 --> Language Class Initialized
INFO - 2024-11-04 08:00:41 --> Loader Class Initialized
INFO - 2024-11-04 08:00:41 --> Helper loaded: url_helper
INFO - 2024-11-04 08:00:41 --> Helper loaded: html_helper
INFO - 2024-11-04 08:00:41 --> Helper loaded: file_helper
INFO - 2024-11-04 08:00:41 --> Helper loaded: string_helper
INFO - 2024-11-04 08:00:41 --> Helper loaded: form_helper
INFO - 2024-11-04 08:00:41 --> Helper loaded: my_helper
INFO - 2024-11-04 08:00:41 --> Database Driver Class Initialized
INFO - 2024-11-04 08:00:43 --> Upload Class Initialized
INFO - 2024-11-04 08:00:43 --> Email Class Initialized
INFO - 2024-11-04 08:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 08:00:43 --> Form Validation Class Initialized
INFO - 2024-11-04 08:00:43 --> Controller Class Initialized
INFO - 2024-11-04 13:30:43 --> Model "MainModel" initialized
INFO - 2024-11-04 13:30:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-04 13:30:44 --> Final output sent to browser
DEBUG - 2024-11-04 13:30:44 --> Total execution time: 3.4793
INFO - 2024-11-04 09:58:41 --> Config Class Initialized
INFO - 2024-11-04 09:58:41 --> Hooks Class Initialized
DEBUG - 2024-11-04 09:58:41 --> UTF-8 Support Enabled
INFO - 2024-11-04 09:58:41 --> Utf8 Class Initialized
INFO - 2024-11-04 09:58:41 --> URI Class Initialized
DEBUG - 2024-11-04 09:58:41 --> No URI present. Default controller set.
INFO - 2024-11-04 09:58:41 --> Router Class Initialized
INFO - 2024-11-04 09:58:41 --> Output Class Initialized
INFO - 2024-11-04 09:58:41 --> Security Class Initialized
DEBUG - 2024-11-04 09:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-04 09:58:41 --> Input Class Initialized
INFO - 2024-11-04 09:58:41 --> Language Class Initialized
INFO - 2024-11-04 09:58:41 --> Loader Class Initialized
INFO - 2024-11-04 09:58:41 --> Helper loaded: url_helper
INFO - 2024-11-04 09:58:41 --> Helper loaded: html_helper
INFO - 2024-11-04 09:58:41 --> Helper loaded: file_helper
INFO - 2024-11-04 09:58:41 --> Helper loaded: string_helper
INFO - 2024-11-04 09:58:41 --> Helper loaded: form_helper
INFO - 2024-11-04 09:58:41 --> Helper loaded: my_helper
INFO - 2024-11-04 09:58:41 --> Database Driver Class Initialized
INFO - 2024-11-04 09:58:43 --> Upload Class Initialized
INFO - 2024-11-04 09:58:43 --> Email Class Initialized
INFO - 2024-11-04 09:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-04 09:58:43 --> Form Validation Class Initialized
INFO - 2024-11-04 09:58:43 --> Controller Class Initialized
INFO - 2024-11-04 15:28:43 --> Model "MainModel" initialized
INFO - 2024-11-04 15:28:43 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-04 15:28:43 --> Final output sent to browser
DEBUG - 2024-11-04 15:28:43 --> Total execution time: 2.7389
