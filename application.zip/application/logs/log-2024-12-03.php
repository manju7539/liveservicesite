<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-03 14:01:22 --> Config Class Initialized
INFO - 2024-12-03 14:01:22 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:01:23 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:01:23 --> Utf8 Class Initialized
INFO - 2024-12-03 14:01:23 --> URI Class Initialized
DEBUG - 2024-12-03 14:01:23 --> No URI present. Default controller set.
INFO - 2024-12-03 14:01:23 --> Router Class Initialized
INFO - 2024-12-03 14:01:23 --> Output Class Initialized
INFO - 2024-12-03 14:01:23 --> Security Class Initialized
DEBUG - 2024-12-03 14:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:01:23 --> Input Class Initialized
INFO - 2024-12-03 14:01:23 --> Language Class Initialized
INFO - 2024-12-03 14:01:23 --> Loader Class Initialized
INFO - 2024-12-03 14:01:23 --> Helper loaded: url_helper
INFO - 2024-12-03 14:01:24 --> Helper loaded: html_helper
INFO - 2024-12-03 14:01:24 --> Helper loaded: file_helper
INFO - 2024-12-03 14:01:24 --> Helper loaded: string_helper
INFO - 2024-12-03 14:01:24 --> Helper loaded: form_helper
INFO - 2024-12-03 14:01:24 --> Helper loaded: my_helper
INFO - 2024-12-03 14:01:24 --> Database Driver Class Initialized
INFO - 2024-12-03 14:01:26 --> Upload Class Initialized
INFO - 2024-12-03 14:01:27 --> Email Class Initialized
INFO - 2024-12-03 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:01:28 --> Form Validation Class Initialized
INFO - 2024-12-03 14:01:28 --> Controller Class Initialized
INFO - 2024-12-03 19:31:29 --> Model "MainModel" initialized
INFO - 2024-12-03 19:31:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-03 19:31:29 --> Final output sent to browser
DEBUG - 2024-12-03 19:31:29 --> Total execution time: 6.7413
