<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-28 06:58:50 --> Config Class Initialized
INFO - 2025-01-28 06:58:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 06:58:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 06:58:50 --> Utf8 Class Initialized
INFO - 2025-01-28 06:58:50 --> URI Class Initialized
INFO - 2025-01-28 06:58:50 --> Router Class Initialized
INFO - 2025-01-28 06:58:51 --> Output Class Initialized
INFO - 2025-01-28 06:58:51 --> Security Class Initialized
DEBUG - 2025-01-28 06:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 06:58:51 --> Input Class Initialized
INFO - 2025-01-28 06:58:51 --> Language Class Initialized
INFO - 2025-01-28 06:58:51 --> Loader Class Initialized
INFO - 2025-01-28 06:58:51 --> Helper loaded: url_helper
INFO - 2025-01-28 06:58:51 --> Helper loaded: html_helper
INFO - 2025-01-28 06:58:51 --> Helper loaded: file_helper
INFO - 2025-01-28 06:58:51 --> Helper loaded: string_helper
INFO - 2025-01-28 06:58:51 --> Helper loaded: form_helper
INFO - 2025-01-28 06:58:51 --> Helper loaded: my_helper
INFO - 2025-01-28 06:58:52 --> Database Driver Class Initialized
ERROR - 2025-01-28 06:58:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) C:\wamp64\www\liveservicesite\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-28 06:58:52 --> Unable to connect to the database
INFO - 2025-01-28 06:58:52 --> Language file loaded: language/english/db_lang.php
INFO - 2025-01-28 07:13:30 --> Config Class Initialized
INFO - 2025-01-28 07:13:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 07:13:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 07:13:30 --> Utf8 Class Initialized
INFO - 2025-01-28 07:13:30 --> URI Class Initialized
INFO - 2025-01-28 07:13:30 --> Router Class Initialized
INFO - 2025-01-28 07:13:30 --> Output Class Initialized
INFO - 2025-01-28 07:13:30 --> Security Class Initialized
DEBUG - 2025-01-28 07:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 07:13:30 --> Input Class Initialized
INFO - 2025-01-28 07:13:30 --> Language Class Initialized
INFO - 2025-01-28 07:13:30 --> Loader Class Initialized
INFO - 2025-01-28 07:13:30 --> Helper loaded: url_helper
INFO - 2025-01-28 07:13:30 --> Helper loaded: html_helper
INFO - 2025-01-28 07:13:30 --> Helper loaded: file_helper
INFO - 2025-01-28 07:13:30 --> Helper loaded: string_helper
INFO - 2025-01-28 07:13:30 --> Helper loaded: form_helper
INFO - 2025-01-28 07:13:30 --> Helper loaded: my_helper
INFO - 2025-01-28 07:13:30 --> Database Driver Class Initialized
ERROR - 2025-01-28 07:13:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) C:\wamp64\www\liveservicesite\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-28 07:13:30 --> Unable to connect to the database
INFO - 2025-01-28 07:13:30 --> Language file loaded: language/english/db_lang.php
INFO - 2025-01-28 09:21:26 --> Config Class Initialized
INFO - 2025-01-28 09:21:26 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:21:26 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:21:26 --> Utf8 Class Initialized
INFO - 2025-01-28 09:21:26 --> URI Class Initialized
INFO - 2025-01-28 09:21:26 --> Router Class Initialized
INFO - 2025-01-28 09:21:26 --> Output Class Initialized
INFO - 2025-01-28 09:21:26 --> Security Class Initialized
DEBUG - 2025-01-28 09:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:21:26 --> Input Class Initialized
INFO - 2025-01-28 09:21:26 --> Language Class Initialized
INFO - 2025-01-28 09:21:27 --> Loader Class Initialized
INFO - 2025-01-28 09:21:27 --> Helper loaded: url_helper
INFO - 2025-01-28 09:21:27 --> Helper loaded: html_helper
INFO - 2025-01-28 09:21:27 --> Helper loaded: file_helper
INFO - 2025-01-28 09:21:27 --> Helper loaded: string_helper
INFO - 2025-01-28 09:21:27 --> Helper loaded: form_helper
INFO - 2025-01-28 09:21:27 --> Helper loaded: my_helper
INFO - 2025-01-28 09:21:27 --> Database Driver Class Initialized
ERROR - 2025-01-28 09:21:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) C:\wamp64\www\liveservicesite\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-28 09:21:27 --> Unable to connect to the database
INFO - 2025-01-28 09:21:27 --> Language file loaded: language/english/db_lang.php
INFO - 2025-01-28 09:21:46 --> Config Class Initialized
INFO - 2025-01-28 09:21:46 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:21:46 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:21:46 --> Utf8 Class Initialized
INFO - 2025-01-28 09:21:46 --> URI Class Initialized
INFO - 2025-01-28 09:21:46 --> Router Class Initialized
INFO - 2025-01-28 09:21:46 --> Output Class Initialized
INFO - 2025-01-28 09:21:46 --> Security Class Initialized
DEBUG - 2025-01-28 09:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:21:46 --> Input Class Initialized
INFO - 2025-01-28 09:21:46 --> Language Class Initialized
INFO - 2025-01-28 09:21:46 --> Loader Class Initialized
INFO - 2025-01-28 09:21:46 --> Helper loaded: url_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: html_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: file_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: string_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: form_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: my_helper
INFO - 2025-01-28 09:21:46 --> Database Driver Class Initialized
ERROR - 2025-01-28 09:21:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) C:\wamp64\www\liveservicesite\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-28 09:21:46 --> Unable to connect to the database
INFO - 2025-01-28 09:21:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-01-28 09:21:46 --> Config Class Initialized
INFO - 2025-01-28 09:21:46 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:21:46 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:21:46 --> Utf8 Class Initialized
INFO - 2025-01-28 09:21:46 --> URI Class Initialized
INFO - 2025-01-28 09:21:46 --> Router Class Initialized
INFO - 2025-01-28 09:21:46 --> Output Class Initialized
INFO - 2025-01-28 09:21:46 --> Security Class Initialized
DEBUG - 2025-01-28 09:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:21:46 --> Input Class Initialized
INFO - 2025-01-28 09:21:46 --> Language Class Initialized
INFO - 2025-01-28 09:21:46 --> Loader Class Initialized
INFO - 2025-01-28 09:21:46 --> Helper loaded: url_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: html_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: file_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: string_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: form_helper
INFO - 2025-01-28 09:21:46 --> Helper loaded: my_helper
INFO - 2025-01-28 09:21:46 --> Database Driver Class Initialized
ERROR - 2025-01-28 09:21:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) C:\wamp64\www\liveservicesite\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-28 09:21:46 --> Unable to connect to the database
INFO - 2025-01-28 09:21:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-01-28 09:24:35 --> Config Class Initialized
INFO - 2025-01-28 09:24:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:24:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:24:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:24:35 --> URI Class Initialized
INFO - 2025-01-28 09:24:35 --> Router Class Initialized
INFO - 2025-01-28 09:24:35 --> Output Class Initialized
INFO - 2025-01-28 09:24:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:24:35 --> Input Class Initialized
INFO - 2025-01-28 09:24:35 --> Language Class Initialized
INFO - 2025-01-28 09:24:36 --> Loader Class Initialized
INFO - 2025-01-28 09:24:36 --> Helper loaded: url_helper
INFO - 2025-01-28 09:24:36 --> Helper loaded: html_helper
INFO - 2025-01-28 09:24:36 --> Helper loaded: file_helper
INFO - 2025-01-28 09:24:36 --> Helper loaded: string_helper
INFO - 2025-01-28 09:24:36 --> Helper loaded: form_helper
INFO - 2025-01-28 09:24:36 --> Helper loaded: my_helper
INFO - 2025-01-28 09:24:36 --> Database Driver Class Initialized
ERROR - 2025-01-28 09:24:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) C:\wamp64\www\liveservicesite\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-01-28 09:24:36 --> Unable to connect to the database
INFO - 2025-01-28 09:24:36 --> Language file loaded: language/english/db_lang.php
INFO - 2025-01-28 09:31:12 --> Config Class Initialized
INFO - 2025-01-28 09:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:12 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:12 --> URI Class Initialized
INFO - 2025-01-28 09:31:12 --> Router Class Initialized
INFO - 2025-01-28 09:31:12 --> Output Class Initialized
INFO - 2025-01-28 09:31:12 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:12 --> Input Class Initialized
INFO - 2025-01-28 09:31:12 --> Language Class Initialized
INFO - 2025-01-28 09:31:12 --> Loader Class Initialized
INFO - 2025-01-28 09:31:12 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:12 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:12 --> Upload Class Initialized
INFO - 2025-01-28 09:31:12 --> Email Class Initialized
INFO - 2025-01-28 09:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:12 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:12 --> Controller Class Initialized
INFO - 2025-01-28 15:01:12 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:01:12 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:01:12 --> Model "MainModel" initialized
INFO - 2025-01-28 09:31:12 --> Config Class Initialized
INFO - 2025-01-28 09:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:12 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:12 --> URI Class Initialized
DEBUG - 2025-01-28 09:31:12 --> No URI present. Default controller set.
INFO - 2025-01-28 09:31:12 --> Router Class Initialized
INFO - 2025-01-28 09:31:12 --> Output Class Initialized
INFO - 2025-01-28 09:31:12 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:12 --> Input Class Initialized
INFO - 2025-01-28 09:31:12 --> Language Class Initialized
INFO - 2025-01-28 09:31:12 --> Loader Class Initialized
INFO - 2025-01-28 09:31:12 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:12 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:12 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:12 --> Upload Class Initialized
INFO - 2025-01-28 09:31:12 --> Email Class Initialized
INFO - 2025-01-28 09:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:12 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:12 --> Controller Class Initialized
INFO - 2025-01-28 15:01:12 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:01:12 --> Pagination Class Initialized
INFO - 2025-01-28 15:01:13 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-28 15:01:13 --> Final output sent to browser
DEBUG - 2025-01-28 15:01:13 --> Total execution time: 0.1713
INFO - 2025-01-28 09:31:43 --> Config Class Initialized
INFO - 2025-01-28 09:31:43 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:43 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:43 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:43 --> URI Class Initialized
INFO - 2025-01-28 09:31:43 --> Router Class Initialized
INFO - 2025-01-28 09:31:43 --> Output Class Initialized
INFO - 2025-01-28 09:31:43 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:43 --> Input Class Initialized
INFO - 2025-01-28 09:31:43 --> Language Class Initialized
INFO - 2025-01-28 09:31:43 --> Loader Class Initialized
INFO - 2025-01-28 09:31:43 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:43 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:43 --> Upload Class Initialized
INFO - 2025-01-28 09:31:43 --> Email Class Initialized
INFO - 2025-01-28 09:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:43 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:43 --> Controller Class Initialized
INFO - 2025-01-28 15:01:43 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:01:43 --> Pagination Class Initialized
INFO - 2025-01-28 09:31:43 --> Config Class Initialized
INFO - 2025-01-28 09:31:43 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:43 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:43 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:43 --> URI Class Initialized
DEBUG - 2025-01-28 09:31:43 --> No URI present. Default controller set.
INFO - 2025-01-28 09:31:43 --> Router Class Initialized
INFO - 2025-01-28 09:31:43 --> Output Class Initialized
INFO - 2025-01-28 09:31:43 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:43 --> Input Class Initialized
INFO - 2025-01-28 09:31:43 --> Language Class Initialized
INFO - 2025-01-28 09:31:43 --> Loader Class Initialized
INFO - 2025-01-28 09:31:43 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:43 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:43 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:43 --> Upload Class Initialized
INFO - 2025-01-28 09:31:43 --> Email Class Initialized
INFO - 2025-01-28 09:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:43 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:43 --> Controller Class Initialized
INFO - 2025-01-28 15:01:43 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:01:43 --> Pagination Class Initialized
INFO - 2025-01-28 15:01:43 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-28 15:01:43 --> Final output sent to browser
DEBUG - 2025-01-28 15:01:43 --> Total execution time: 0.0417
INFO - 2025-01-28 09:31:47 --> Config Class Initialized
INFO - 2025-01-28 09:31:47 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:47 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:47 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:47 --> URI Class Initialized
INFO - 2025-01-28 09:31:47 --> Router Class Initialized
INFO - 2025-01-28 09:31:47 --> Output Class Initialized
INFO - 2025-01-28 09:31:47 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:47 --> Input Class Initialized
INFO - 2025-01-28 09:31:47 --> Language Class Initialized
INFO - 2025-01-28 09:31:47 --> Loader Class Initialized
INFO - 2025-01-28 09:31:47 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:47 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:47 --> Upload Class Initialized
INFO - 2025-01-28 09:31:47 --> Email Class Initialized
INFO - 2025-01-28 09:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:47 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:47 --> Controller Class Initialized
INFO - 2025-01-28 15:01:47 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:01:47 --> Pagination Class Initialized
INFO - 2025-01-28 09:31:47 --> Config Class Initialized
INFO - 2025-01-28 09:31:47 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:47 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:47 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:47 --> URI Class Initialized
INFO - 2025-01-28 09:31:47 --> Router Class Initialized
INFO - 2025-01-28 09:31:47 --> Output Class Initialized
INFO - 2025-01-28 09:31:47 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:47 --> Input Class Initialized
INFO - 2025-01-28 09:31:47 --> Language Class Initialized
INFO - 2025-01-28 09:31:47 --> Loader Class Initialized
INFO - 2025-01-28 09:31:47 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:47 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:47 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:47 --> Upload Class Initialized
INFO - 2025-01-28 09:31:47 --> Email Class Initialized
INFO - 2025-01-28 09:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:47 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:47 --> Controller Class Initialized
INFO - 2025-01-28 15:01:47 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:47 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:01:47 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:01:47 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:01:47 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:01:47 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:01:47 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:01:47 --> Helper loaded: array_helper
INFO - 2025-01-28 15:01:49 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-28 15:01:49 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-28 15:01:49 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-28 15:01:49 --> Final output sent to browser
DEBUG - 2025-01-28 15:01:49 --> Total execution time: 1.8314
INFO - 2025-01-28 09:31:49 --> Config Class Initialized
INFO - 2025-01-28 09:31:49 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:49 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:49 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:49 --> URI Class Initialized
INFO - 2025-01-28 09:31:49 --> Router Class Initialized
INFO - 2025-01-28 09:31:49 --> Output Class Initialized
INFO - 2025-01-28 09:31:49 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:49 --> Input Class Initialized
INFO - 2025-01-28 09:31:49 --> Language Class Initialized
ERROR - 2025-01-28 09:31:49 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-28 09:31:49 --> Config Class Initialized
INFO - 2025-01-28 09:31:49 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:49 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:49 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:49 --> URI Class Initialized
INFO - 2025-01-28 09:31:49 --> Router Class Initialized
INFO - 2025-01-28 09:31:49 --> Output Class Initialized
INFO - 2025-01-28 09:31:49 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:49 --> Input Class Initialized
INFO - 2025-01-28 09:31:49 --> Language Class Initialized
ERROR - 2025-01-28 09:31:49 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-28 09:31:49 --> Config Class Initialized
INFO - 2025-01-28 09:31:49 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:49 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:49 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:49 --> URI Class Initialized
INFO - 2025-01-28 09:31:49 --> Router Class Initialized
INFO - 2025-01-28 09:31:49 --> Output Class Initialized
INFO - 2025-01-28 09:31:49 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:49 --> Input Class Initialized
INFO - 2025-01-28 09:31:49 --> Language Class Initialized
ERROR - 2025-01-28 09:31:49 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-28 09:31:49 --> Config Class Initialized
INFO - 2025-01-28 09:31:49 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:49 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:49 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:49 --> URI Class Initialized
INFO - 2025-01-28 09:31:49 --> Router Class Initialized
INFO - 2025-01-28 09:31:49 --> Output Class Initialized
INFO - 2025-01-28 09:31:49 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:49 --> Input Class Initialized
INFO - 2025-01-28 09:31:49 --> Language Class Initialized
INFO - 2025-01-28 09:31:49 --> Loader Class Initialized
INFO - 2025-01-28 09:31:49 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:49 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:49 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:49 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:49 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:49 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:49 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:49 --> Upload Class Initialized
INFO - 2025-01-28 09:31:49 --> Email Class Initialized
INFO - 2025-01-28 09:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:49 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:49 --> Controller Class Initialized
INFO - 2025-01-28 15:01:49 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:49 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:01:49 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:01:49 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:01:49 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:01:49 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:01:49 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:01:49 --> Helper loaded: array_helper
INFO - 2025-01-28 15:01:49 --> Final output sent to browser
DEBUG - 2025-01-28 15:01:49 --> Total execution time: 0.0378
INFO - 2025-01-28 09:31:54 --> Config Class Initialized
INFO - 2025-01-28 09:31:54 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:54 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:54 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:54 --> URI Class Initialized
INFO - 2025-01-28 09:31:54 --> Router Class Initialized
INFO - 2025-01-28 09:31:54 --> Output Class Initialized
INFO - 2025-01-28 09:31:54 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:54 --> Input Class Initialized
INFO - 2025-01-28 09:31:54 --> Language Class Initialized
INFO - 2025-01-28 09:31:55 --> Loader Class Initialized
INFO - 2025-01-28 09:31:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:55 --> Upload Class Initialized
INFO - 2025-01-28 09:31:55 --> Email Class Initialized
INFO - 2025-01-28 09:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:55 --> Controller Class Initialized
INFO - 2025-01-28 15:01:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:01:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:01:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:31:59 --> Config Class Initialized
INFO - 2025-01-28 09:31:59 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:31:59 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:31:59 --> Utf8 Class Initialized
INFO - 2025-01-28 09:31:59 --> URI Class Initialized
INFO - 2025-01-28 09:31:59 --> Router Class Initialized
INFO - 2025-01-28 09:31:59 --> Output Class Initialized
INFO - 2025-01-28 09:31:59 --> Security Class Initialized
DEBUG - 2025-01-28 09:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:31:59 --> Input Class Initialized
INFO - 2025-01-28 09:31:59 --> Language Class Initialized
INFO - 2025-01-28 09:31:59 --> Loader Class Initialized
INFO - 2025-01-28 09:31:59 --> Helper loaded: url_helper
INFO - 2025-01-28 09:31:59 --> Helper loaded: html_helper
INFO - 2025-01-28 09:31:59 --> Helper loaded: file_helper
INFO - 2025-01-28 09:31:59 --> Helper loaded: string_helper
INFO - 2025-01-28 09:31:59 --> Helper loaded: form_helper
INFO - 2025-01-28 09:31:59 --> Helper loaded: my_helper
INFO - 2025-01-28 09:31:59 --> Database Driver Class Initialized
INFO - 2025-01-28 09:31:59 --> Upload Class Initialized
INFO - 2025-01-28 09:31:59 --> Email Class Initialized
INFO - 2025-01-28 09:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:31:59 --> Form Validation Class Initialized
INFO - 2025-01-28 09:31:59 --> Controller Class Initialized
INFO - 2025-01-28 15:01:59 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:01:59 --> Model "MainModel" initialized
INFO - 2025-01-28 15:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:01:59 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:04 --> Config Class Initialized
INFO - 2025-01-28 09:32:04 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:04 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:04 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:04 --> URI Class Initialized
INFO - 2025-01-28 09:32:04 --> Router Class Initialized
INFO - 2025-01-28 09:32:04 --> Output Class Initialized
INFO - 2025-01-28 09:32:04 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:04 --> Input Class Initialized
INFO - 2025-01-28 09:32:04 --> Language Class Initialized
INFO - 2025-01-28 09:32:04 --> Loader Class Initialized
INFO - 2025-01-28 09:32:04 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:04 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:04 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:04 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:04 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:04 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:04 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:04 --> Upload Class Initialized
INFO - 2025-01-28 09:32:04 --> Email Class Initialized
INFO - 2025-01-28 09:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:04 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:04 --> Controller Class Initialized
INFO - 2025-01-28 15:02:04 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:04 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:04 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:05 --> Config Class Initialized
INFO - 2025-01-28 09:32:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:05 --> URI Class Initialized
INFO - 2025-01-28 09:32:05 --> Router Class Initialized
INFO - 2025-01-28 09:32:05 --> Config Class Initialized
INFO - 2025-01-28 09:32:05 --> Output Class Initialized
INFO - 2025-01-28 09:32:05 --> Hooks Class Initialized
INFO - 2025-01-28 09:32:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:05 --> Utf8 Class Initialized
DEBUG - 2025-01-28 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:05 --> Input Class Initialized
INFO - 2025-01-28 09:32:05 --> Language Class Initialized
INFO - 2025-01-28 09:32:05 --> URI Class Initialized
ERROR - 2025-01-28 09:32:05 --> 404 Page Not Found: Assets/plugins
INFO - 2025-01-28 09:32:05 --> Router Class Initialized
INFO - 2025-01-28 09:32:05 --> Output Class Initialized
INFO - 2025-01-28 09:32:05 --> Config Class Initialized
INFO - 2025-01-28 09:32:05 --> Hooks Class Initialized
INFO - 2025-01-28 09:32:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2025-01-28 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:05 --> Input Class Initialized
INFO - 2025-01-28 09:32:05 --> Language Class Initialized
INFO - 2025-01-28 09:32:05 --> URI Class Initialized
ERROR - 2025-01-28 09:32:05 --> 404 Page Not Found: Assets/plugins
INFO - 2025-01-28 09:32:05 --> Router Class Initialized
INFO - 2025-01-28 09:32:05 --> Output Class Initialized
INFO - 2025-01-28 09:32:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:05 --> Input Class Initialized
INFO - 2025-01-28 09:32:05 --> Language Class Initialized
ERROR - 2025-01-28 09:32:05 --> 404 Page Not Found: Assets/plugins
INFO - 2025-01-28 09:32:09 --> Config Class Initialized
INFO - 2025-01-28 09:32:09 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:09 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:09 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:09 --> URI Class Initialized
INFO - 2025-01-28 09:32:09 --> Router Class Initialized
INFO - 2025-01-28 09:32:09 --> Output Class Initialized
INFO - 2025-01-28 09:32:09 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:09 --> Input Class Initialized
INFO - 2025-01-28 09:32:09 --> Language Class Initialized
INFO - 2025-01-28 09:32:09 --> Loader Class Initialized
INFO - 2025-01-28 09:32:09 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:09 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:09 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:09 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:09 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:09 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:09 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:09 --> Upload Class Initialized
INFO - 2025-01-28 09:32:09 --> Email Class Initialized
INFO - 2025-01-28 09:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:09 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:09 --> Controller Class Initialized
INFO - 2025-01-28 15:02:09 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:09 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:09 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:10 --> Config Class Initialized
INFO - 2025-01-28 09:32:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:10 --> URI Class Initialized
DEBUG - 2025-01-28 09:32:10 --> No URI present. Default controller set.
INFO - 2025-01-28 09:32:10 --> Router Class Initialized
INFO - 2025-01-28 09:32:10 --> Output Class Initialized
INFO - 2025-01-28 09:32:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:10 --> Input Class Initialized
INFO - 2025-01-28 09:32:10 --> Language Class Initialized
INFO - 2025-01-28 09:32:10 --> Loader Class Initialized
INFO - 2025-01-28 09:32:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:10 --> Upload Class Initialized
INFO - 2025-01-28 09:32:10 --> Email Class Initialized
INFO - 2025-01-28 09:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:10 --> Controller Class Initialized
INFO - 2025-01-28 15:02:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:10 --> Pagination Class Initialized
INFO - 2025-01-28 15:02:10 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-28 15:02:10 --> Final output sent to browser
DEBUG - 2025-01-28 15:02:10 --> Total execution time: 0.0365
INFO - 2025-01-28 09:32:24 --> Config Class Initialized
INFO - 2025-01-28 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:24 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:24 --> URI Class Initialized
INFO - 2025-01-28 09:32:24 --> Router Class Initialized
INFO - 2025-01-28 09:32:24 --> Output Class Initialized
INFO - 2025-01-28 09:32:24 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:24 --> Input Class Initialized
INFO - 2025-01-28 09:32:24 --> Language Class Initialized
INFO - 2025-01-28 09:32:24 --> Loader Class Initialized
INFO - 2025-01-28 09:32:24 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:24 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:24 --> Upload Class Initialized
INFO - 2025-01-28 09:32:24 --> Email Class Initialized
INFO - 2025-01-28 09:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:24 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:24 --> Controller Class Initialized
INFO - 2025-01-28 15:02:24 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:24 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:24 --> Config Class Initialized
INFO - 2025-01-28 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:24 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:24 --> URI Class Initialized
INFO - 2025-01-28 09:32:24 --> Router Class Initialized
INFO - 2025-01-28 09:32:24 --> Output Class Initialized
INFO - 2025-01-28 09:32:24 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:24 --> Input Class Initialized
INFO - 2025-01-28 09:32:24 --> Language Class Initialized
INFO - 2025-01-28 09:32:24 --> Loader Class Initialized
INFO - 2025-01-28 09:32:24 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:24 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:24 --> Upload Class Initialized
INFO - 2025-01-28 09:32:24 --> Email Class Initialized
INFO - 2025-01-28 09:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:24 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:24 --> Controller Class Initialized
INFO - 2025-01-28 15:02:24 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:24 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:02:24 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:02:24 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:02:24 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:02:24 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:02:24 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:02:24 --> Helper loaded: array_helper
INFO - 2025-01-28 15:02:24 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-28 15:02:24 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-28 15:02:24 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-28 15:02:24 --> Final output sent to browser
DEBUG - 2025-01-28 15:02:24 --> Total execution time: 0.2257
INFO - 2025-01-28 09:32:24 --> Config Class Initialized
INFO - 2025-01-28 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:24 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:24 --> URI Class Initialized
INFO - 2025-01-28 09:32:24 --> Router Class Initialized
INFO - 2025-01-28 09:32:24 --> Output Class Initialized
INFO - 2025-01-28 09:32:24 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:24 --> Input Class Initialized
INFO - 2025-01-28 09:32:24 --> Language Class Initialized
ERROR - 2025-01-28 09:32:24 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-28 09:32:24 --> Config Class Initialized
INFO - 2025-01-28 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:24 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:24 --> URI Class Initialized
INFO - 2025-01-28 09:32:24 --> Router Class Initialized
INFO - 2025-01-28 09:32:24 --> Output Class Initialized
INFO - 2025-01-28 09:32:24 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:24 --> Input Class Initialized
INFO - 2025-01-28 09:32:24 --> Language Class Initialized
ERROR - 2025-01-28 09:32:24 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-28 09:32:24 --> Config Class Initialized
INFO - 2025-01-28 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:24 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:24 --> URI Class Initialized
INFO - 2025-01-28 09:32:24 --> Router Class Initialized
INFO - 2025-01-28 09:32:24 --> Output Class Initialized
INFO - 2025-01-28 09:32:24 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:24 --> Input Class Initialized
INFO - 2025-01-28 09:32:24 --> Language Class Initialized
ERROR - 2025-01-28 09:32:24 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-28 09:32:24 --> Config Class Initialized
INFO - 2025-01-28 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:24 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:24 --> URI Class Initialized
INFO - 2025-01-28 09:32:24 --> Router Class Initialized
INFO - 2025-01-28 09:32:24 --> Output Class Initialized
INFO - 2025-01-28 09:32:24 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:24 --> Input Class Initialized
INFO - 2025-01-28 09:32:24 --> Language Class Initialized
INFO - 2025-01-28 09:32:24 --> Loader Class Initialized
INFO - 2025-01-28 09:32:24 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:24 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:24 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:24 --> Upload Class Initialized
INFO - 2025-01-28 09:32:24 --> Email Class Initialized
INFO - 2025-01-28 09:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:25 --> Controller Class Initialized
INFO - 2025-01-28 15:02:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:25 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:02:25 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:02:25 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:02:25 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:02:25 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:02:25 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:02:25 --> Helper loaded: array_helper
INFO - 2025-01-28 15:02:25 --> Final output sent to browser
DEBUG - 2025-01-28 15:02:25 --> Total execution time: 0.0289
INFO - 2025-01-28 09:32:25 --> Config Class Initialized
INFO - 2025-01-28 09:32:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:25 --> URI Class Initialized
INFO - 2025-01-28 09:32:25 --> Router Class Initialized
INFO - 2025-01-28 09:32:25 --> Output Class Initialized
INFO - 2025-01-28 09:32:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:25 --> Input Class Initialized
INFO - 2025-01-28 09:32:25 --> Language Class Initialized
ERROR - 2025-01-28 09:32:25 --> 404 Page Not Found: Assets/plugins
INFO - 2025-01-28 09:32:25 --> Config Class Initialized
INFO - 2025-01-28 09:32:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:25 --> URI Class Initialized
INFO - 2025-01-28 09:32:25 --> Router Class Initialized
INFO - 2025-01-28 09:32:25 --> Output Class Initialized
INFO - 2025-01-28 09:32:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:25 --> Input Class Initialized
INFO - 2025-01-28 09:32:25 --> Language Class Initialized
ERROR - 2025-01-28 09:32:25 --> 404 Page Not Found: Assets/plugins
INFO - 2025-01-28 09:32:25 --> Config Class Initialized
INFO - 2025-01-28 09:32:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:25 --> URI Class Initialized
INFO - 2025-01-28 09:32:25 --> Router Class Initialized
INFO - 2025-01-28 09:32:25 --> Output Class Initialized
INFO - 2025-01-28 09:32:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:25 --> Input Class Initialized
INFO - 2025-01-28 09:32:25 --> Language Class Initialized
ERROR - 2025-01-28 09:32:25 --> 404 Page Not Found: Assets/plugins
INFO - 2025-01-28 09:32:30 --> Config Class Initialized
INFO - 2025-01-28 09:32:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:30 --> URI Class Initialized
INFO - 2025-01-28 09:32:30 --> Router Class Initialized
INFO - 2025-01-28 09:32:30 --> Output Class Initialized
INFO - 2025-01-28 09:32:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:30 --> Input Class Initialized
INFO - 2025-01-28 09:32:30 --> Language Class Initialized
INFO - 2025-01-28 09:32:30 --> Loader Class Initialized
INFO - 2025-01-28 09:32:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:30 --> Upload Class Initialized
INFO - 2025-01-28 09:32:30 --> Email Class Initialized
INFO - 2025-01-28 09:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:30 --> Controller Class Initialized
INFO - 2025-01-28 15:02:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:35 --> Config Class Initialized
INFO - 2025-01-28 09:32:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:35 --> URI Class Initialized
INFO - 2025-01-28 09:32:35 --> Router Class Initialized
INFO - 2025-01-28 09:32:35 --> Output Class Initialized
INFO - 2025-01-28 09:32:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:35 --> Input Class Initialized
INFO - 2025-01-28 09:32:35 --> Language Class Initialized
INFO - 2025-01-28 09:32:35 --> Loader Class Initialized
INFO - 2025-01-28 09:32:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:35 --> Upload Class Initialized
INFO - 2025-01-28 09:32:35 --> Email Class Initialized
INFO - 2025-01-28 09:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:35 --> Controller Class Initialized
INFO - 2025-01-28 15:02:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:40 --> Config Class Initialized
INFO - 2025-01-28 09:32:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:40 --> URI Class Initialized
INFO - 2025-01-28 09:32:40 --> Router Class Initialized
INFO - 2025-01-28 09:32:40 --> Output Class Initialized
INFO - 2025-01-28 09:32:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:40 --> Input Class Initialized
INFO - 2025-01-28 09:32:40 --> Language Class Initialized
INFO - 2025-01-28 09:32:40 --> Loader Class Initialized
INFO - 2025-01-28 09:32:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:40 --> Upload Class Initialized
INFO - 2025-01-28 09:32:40 --> Email Class Initialized
INFO - 2025-01-28 09:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:40 --> Controller Class Initialized
INFO - 2025-01-28 15:02:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:45 --> Config Class Initialized
INFO - 2025-01-28 09:32:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:45 --> URI Class Initialized
INFO - 2025-01-28 09:32:45 --> Router Class Initialized
INFO - 2025-01-28 09:32:45 --> Output Class Initialized
INFO - 2025-01-28 09:32:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:45 --> Input Class Initialized
INFO - 2025-01-28 09:32:45 --> Language Class Initialized
INFO - 2025-01-28 09:32:45 --> Loader Class Initialized
INFO - 2025-01-28 09:32:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:45 --> Upload Class Initialized
INFO - 2025-01-28 09:32:45 --> Email Class Initialized
INFO - 2025-01-28 09:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:45 --> Controller Class Initialized
INFO - 2025-01-28 15:02:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:50 --> Config Class Initialized
INFO - 2025-01-28 09:32:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:50 --> URI Class Initialized
INFO - 2025-01-28 09:32:50 --> Router Class Initialized
INFO - 2025-01-28 09:32:50 --> Output Class Initialized
INFO - 2025-01-28 09:32:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:50 --> Input Class Initialized
INFO - 2025-01-28 09:32:50 --> Language Class Initialized
INFO - 2025-01-28 09:32:50 --> Loader Class Initialized
INFO - 2025-01-28 09:32:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:50 --> Upload Class Initialized
INFO - 2025-01-28 09:32:50 --> Email Class Initialized
INFO - 2025-01-28 09:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:50 --> Controller Class Initialized
INFO - 2025-01-28 15:02:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:32:55 --> Config Class Initialized
INFO - 2025-01-28 09:32:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:32:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:32:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:32:55 --> URI Class Initialized
INFO - 2025-01-28 09:32:55 --> Router Class Initialized
INFO - 2025-01-28 09:32:55 --> Output Class Initialized
INFO - 2025-01-28 09:32:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:32:55 --> Input Class Initialized
INFO - 2025-01-28 09:32:55 --> Language Class Initialized
INFO - 2025-01-28 09:32:55 --> Loader Class Initialized
INFO - 2025-01-28 09:32:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:32:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:32:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:32:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:32:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:32:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:32:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:32:55 --> Upload Class Initialized
INFO - 2025-01-28 09:32:55 --> Email Class Initialized
INFO - 2025-01-28 09:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:32:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:32:55 --> Controller Class Initialized
INFO - 2025-01-28 15:02:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:02:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:02:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:00 --> Config Class Initialized
INFO - 2025-01-28 09:33:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:00 --> URI Class Initialized
INFO - 2025-01-28 09:33:00 --> Router Class Initialized
INFO - 2025-01-28 09:33:00 --> Output Class Initialized
INFO - 2025-01-28 09:33:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:00 --> Input Class Initialized
INFO - 2025-01-28 09:33:00 --> Language Class Initialized
INFO - 2025-01-28 09:33:00 --> Loader Class Initialized
INFO - 2025-01-28 09:33:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:00 --> Upload Class Initialized
INFO - 2025-01-28 09:33:00 --> Email Class Initialized
INFO - 2025-01-28 09:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:00 --> Controller Class Initialized
INFO - 2025-01-28 15:03:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:05 --> Config Class Initialized
INFO - 2025-01-28 09:33:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:05 --> URI Class Initialized
INFO - 2025-01-28 09:33:05 --> Router Class Initialized
INFO - 2025-01-28 09:33:05 --> Output Class Initialized
INFO - 2025-01-28 09:33:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:05 --> Input Class Initialized
INFO - 2025-01-28 09:33:05 --> Language Class Initialized
INFO - 2025-01-28 09:33:05 --> Loader Class Initialized
INFO - 2025-01-28 09:33:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:05 --> Upload Class Initialized
INFO - 2025-01-28 09:33:05 --> Email Class Initialized
INFO - 2025-01-28 09:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:05 --> Controller Class Initialized
INFO - 2025-01-28 15:03:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:10 --> Config Class Initialized
INFO - 2025-01-28 09:33:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:10 --> URI Class Initialized
INFO - 2025-01-28 09:33:10 --> Router Class Initialized
INFO - 2025-01-28 09:33:10 --> Output Class Initialized
INFO - 2025-01-28 09:33:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:10 --> Input Class Initialized
INFO - 2025-01-28 09:33:10 --> Language Class Initialized
INFO - 2025-01-28 09:33:10 --> Loader Class Initialized
INFO - 2025-01-28 09:33:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:10 --> Upload Class Initialized
INFO - 2025-01-28 09:33:10 --> Email Class Initialized
INFO - 2025-01-28 09:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:10 --> Controller Class Initialized
INFO - 2025-01-28 15:03:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:15 --> Config Class Initialized
INFO - 2025-01-28 09:33:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:15 --> URI Class Initialized
INFO - 2025-01-28 09:33:15 --> Router Class Initialized
INFO - 2025-01-28 09:33:15 --> Output Class Initialized
INFO - 2025-01-28 09:33:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:15 --> Input Class Initialized
INFO - 2025-01-28 09:33:15 --> Language Class Initialized
INFO - 2025-01-28 09:33:15 --> Loader Class Initialized
INFO - 2025-01-28 09:33:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:15 --> Upload Class Initialized
INFO - 2025-01-28 09:33:15 --> Email Class Initialized
INFO - 2025-01-28 09:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:15 --> Controller Class Initialized
INFO - 2025-01-28 15:03:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:20 --> Config Class Initialized
INFO - 2025-01-28 09:33:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:20 --> URI Class Initialized
INFO - 2025-01-28 09:33:20 --> Router Class Initialized
INFO - 2025-01-28 09:33:20 --> Output Class Initialized
INFO - 2025-01-28 09:33:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:20 --> Input Class Initialized
INFO - 2025-01-28 09:33:20 --> Language Class Initialized
INFO - 2025-01-28 09:33:20 --> Loader Class Initialized
INFO - 2025-01-28 09:33:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:20 --> Upload Class Initialized
INFO - 2025-01-28 09:33:20 --> Email Class Initialized
INFO - 2025-01-28 09:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:20 --> Controller Class Initialized
INFO - 2025-01-28 15:03:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:25 --> Config Class Initialized
INFO - 2025-01-28 09:33:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:25 --> URI Class Initialized
INFO - 2025-01-28 09:33:25 --> Router Class Initialized
INFO - 2025-01-28 09:33:25 --> Output Class Initialized
INFO - 2025-01-28 09:33:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:25 --> Input Class Initialized
INFO - 2025-01-28 09:33:25 --> Language Class Initialized
INFO - 2025-01-28 09:33:25 --> Loader Class Initialized
INFO - 2025-01-28 09:33:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:25 --> Upload Class Initialized
INFO - 2025-01-28 09:33:25 --> Email Class Initialized
INFO - 2025-01-28 09:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:25 --> Controller Class Initialized
INFO - 2025-01-28 15:03:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:30 --> Config Class Initialized
INFO - 2025-01-28 09:33:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:30 --> URI Class Initialized
INFO - 2025-01-28 09:33:30 --> Router Class Initialized
INFO - 2025-01-28 09:33:30 --> Output Class Initialized
INFO - 2025-01-28 09:33:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:30 --> Input Class Initialized
INFO - 2025-01-28 09:33:30 --> Language Class Initialized
INFO - 2025-01-28 09:33:30 --> Loader Class Initialized
INFO - 2025-01-28 09:33:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:30 --> Upload Class Initialized
INFO - 2025-01-28 09:33:30 --> Email Class Initialized
INFO - 2025-01-28 09:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:30 --> Controller Class Initialized
INFO - 2025-01-28 15:03:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:35 --> Config Class Initialized
INFO - 2025-01-28 09:33:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:35 --> URI Class Initialized
INFO - 2025-01-28 09:33:35 --> Router Class Initialized
INFO - 2025-01-28 09:33:35 --> Output Class Initialized
INFO - 2025-01-28 09:33:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:35 --> Input Class Initialized
INFO - 2025-01-28 09:33:35 --> Language Class Initialized
INFO - 2025-01-28 09:33:35 --> Loader Class Initialized
INFO - 2025-01-28 09:33:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:35 --> Upload Class Initialized
INFO - 2025-01-28 09:33:35 --> Email Class Initialized
INFO - 2025-01-28 09:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:35 --> Controller Class Initialized
INFO - 2025-01-28 15:03:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:40 --> Config Class Initialized
INFO - 2025-01-28 09:33:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:40 --> URI Class Initialized
INFO - 2025-01-28 09:33:40 --> Router Class Initialized
INFO - 2025-01-28 09:33:40 --> Output Class Initialized
INFO - 2025-01-28 09:33:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:40 --> Input Class Initialized
INFO - 2025-01-28 09:33:40 --> Language Class Initialized
INFO - 2025-01-28 09:33:40 --> Loader Class Initialized
INFO - 2025-01-28 09:33:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:40 --> Upload Class Initialized
INFO - 2025-01-28 09:33:40 --> Email Class Initialized
INFO - 2025-01-28 09:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:40 --> Controller Class Initialized
INFO - 2025-01-28 15:03:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:45 --> Config Class Initialized
INFO - 2025-01-28 09:33:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:45 --> URI Class Initialized
INFO - 2025-01-28 09:33:45 --> Router Class Initialized
INFO - 2025-01-28 09:33:45 --> Output Class Initialized
INFO - 2025-01-28 09:33:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:45 --> Input Class Initialized
INFO - 2025-01-28 09:33:45 --> Language Class Initialized
INFO - 2025-01-28 09:33:45 --> Loader Class Initialized
INFO - 2025-01-28 09:33:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:45 --> Upload Class Initialized
INFO - 2025-01-28 09:33:45 --> Email Class Initialized
INFO - 2025-01-28 09:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:45 --> Controller Class Initialized
INFO - 2025-01-28 15:03:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:50 --> Config Class Initialized
INFO - 2025-01-28 09:33:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:50 --> URI Class Initialized
INFO - 2025-01-28 09:33:50 --> Router Class Initialized
INFO - 2025-01-28 09:33:50 --> Output Class Initialized
INFO - 2025-01-28 09:33:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:50 --> Input Class Initialized
INFO - 2025-01-28 09:33:50 --> Language Class Initialized
INFO - 2025-01-28 09:33:50 --> Loader Class Initialized
INFO - 2025-01-28 09:33:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:50 --> Upload Class Initialized
INFO - 2025-01-28 09:33:50 --> Email Class Initialized
INFO - 2025-01-28 09:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:50 --> Controller Class Initialized
INFO - 2025-01-28 15:03:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:33:55 --> Config Class Initialized
INFO - 2025-01-28 09:33:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:33:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:33:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:33:55 --> URI Class Initialized
INFO - 2025-01-28 09:33:55 --> Router Class Initialized
INFO - 2025-01-28 09:33:55 --> Output Class Initialized
INFO - 2025-01-28 09:33:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:33:55 --> Input Class Initialized
INFO - 2025-01-28 09:33:55 --> Language Class Initialized
INFO - 2025-01-28 09:33:55 --> Loader Class Initialized
INFO - 2025-01-28 09:33:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:33:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:33:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:33:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:33:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:33:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:33:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:33:55 --> Upload Class Initialized
INFO - 2025-01-28 09:33:55 --> Email Class Initialized
INFO - 2025-01-28 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:33:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:33:55 --> Controller Class Initialized
INFO - 2025-01-28 15:03:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:03:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:03:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:00 --> Config Class Initialized
INFO - 2025-01-28 09:34:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:00 --> URI Class Initialized
INFO - 2025-01-28 09:34:00 --> Router Class Initialized
INFO - 2025-01-28 09:34:00 --> Output Class Initialized
INFO - 2025-01-28 09:34:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:00 --> Input Class Initialized
INFO - 2025-01-28 09:34:00 --> Language Class Initialized
INFO - 2025-01-28 09:34:00 --> Loader Class Initialized
INFO - 2025-01-28 09:34:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:00 --> Upload Class Initialized
INFO - 2025-01-28 09:34:00 --> Email Class Initialized
INFO - 2025-01-28 09:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:00 --> Controller Class Initialized
INFO - 2025-01-28 15:04:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:05 --> Config Class Initialized
INFO - 2025-01-28 09:34:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:05 --> URI Class Initialized
INFO - 2025-01-28 09:34:05 --> Router Class Initialized
INFO - 2025-01-28 09:34:05 --> Output Class Initialized
INFO - 2025-01-28 09:34:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:05 --> Input Class Initialized
INFO - 2025-01-28 09:34:05 --> Language Class Initialized
INFO - 2025-01-28 09:34:05 --> Loader Class Initialized
INFO - 2025-01-28 09:34:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:05 --> Upload Class Initialized
INFO - 2025-01-28 09:34:05 --> Email Class Initialized
INFO - 2025-01-28 09:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:05 --> Controller Class Initialized
INFO - 2025-01-28 15:04:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:10 --> Config Class Initialized
INFO - 2025-01-28 09:34:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:10 --> URI Class Initialized
INFO - 2025-01-28 09:34:10 --> Router Class Initialized
INFO - 2025-01-28 09:34:10 --> Output Class Initialized
INFO - 2025-01-28 09:34:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:10 --> Input Class Initialized
INFO - 2025-01-28 09:34:10 --> Language Class Initialized
INFO - 2025-01-28 09:34:10 --> Loader Class Initialized
INFO - 2025-01-28 09:34:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:10 --> Upload Class Initialized
INFO - 2025-01-28 09:34:10 --> Email Class Initialized
INFO - 2025-01-28 09:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:10 --> Controller Class Initialized
INFO - 2025-01-28 15:04:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:15 --> Config Class Initialized
INFO - 2025-01-28 09:34:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:15 --> URI Class Initialized
INFO - 2025-01-28 09:34:15 --> Router Class Initialized
INFO - 2025-01-28 09:34:15 --> Output Class Initialized
INFO - 2025-01-28 09:34:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:15 --> Input Class Initialized
INFO - 2025-01-28 09:34:15 --> Language Class Initialized
INFO - 2025-01-28 09:34:15 --> Loader Class Initialized
INFO - 2025-01-28 09:34:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:15 --> Upload Class Initialized
INFO - 2025-01-28 09:34:15 --> Email Class Initialized
INFO - 2025-01-28 09:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:15 --> Controller Class Initialized
INFO - 2025-01-28 15:04:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:20 --> Config Class Initialized
INFO - 2025-01-28 09:34:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:20 --> URI Class Initialized
INFO - 2025-01-28 09:34:20 --> Router Class Initialized
INFO - 2025-01-28 09:34:20 --> Output Class Initialized
INFO - 2025-01-28 09:34:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:20 --> Input Class Initialized
INFO - 2025-01-28 09:34:20 --> Language Class Initialized
INFO - 2025-01-28 09:34:20 --> Loader Class Initialized
INFO - 2025-01-28 09:34:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:20 --> Upload Class Initialized
INFO - 2025-01-28 09:34:20 --> Email Class Initialized
INFO - 2025-01-28 09:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:20 --> Controller Class Initialized
INFO - 2025-01-28 15:04:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:25 --> Config Class Initialized
INFO - 2025-01-28 09:34:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:25 --> URI Class Initialized
INFO - 2025-01-28 09:34:25 --> Router Class Initialized
INFO - 2025-01-28 09:34:25 --> Output Class Initialized
INFO - 2025-01-28 09:34:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:25 --> Input Class Initialized
INFO - 2025-01-28 09:34:25 --> Language Class Initialized
INFO - 2025-01-28 09:34:25 --> Loader Class Initialized
INFO - 2025-01-28 09:34:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:25 --> Upload Class Initialized
INFO - 2025-01-28 09:34:25 --> Email Class Initialized
INFO - 2025-01-28 09:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:25 --> Controller Class Initialized
INFO - 2025-01-28 15:04:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:30 --> Config Class Initialized
INFO - 2025-01-28 09:34:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:30 --> URI Class Initialized
INFO - 2025-01-28 09:34:30 --> Router Class Initialized
INFO - 2025-01-28 09:34:30 --> Output Class Initialized
INFO - 2025-01-28 09:34:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:30 --> Input Class Initialized
INFO - 2025-01-28 09:34:30 --> Language Class Initialized
INFO - 2025-01-28 09:34:30 --> Loader Class Initialized
INFO - 2025-01-28 09:34:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:30 --> Upload Class Initialized
INFO - 2025-01-28 09:34:30 --> Email Class Initialized
INFO - 2025-01-28 09:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:30 --> Controller Class Initialized
INFO - 2025-01-28 15:04:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:35 --> Config Class Initialized
INFO - 2025-01-28 09:34:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:35 --> URI Class Initialized
INFO - 2025-01-28 09:34:35 --> Router Class Initialized
INFO - 2025-01-28 09:34:35 --> Output Class Initialized
INFO - 2025-01-28 09:34:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:35 --> Input Class Initialized
INFO - 2025-01-28 09:34:35 --> Language Class Initialized
INFO - 2025-01-28 09:34:35 --> Loader Class Initialized
INFO - 2025-01-28 09:34:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:35 --> Upload Class Initialized
INFO - 2025-01-28 09:34:35 --> Email Class Initialized
INFO - 2025-01-28 09:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:35 --> Controller Class Initialized
INFO - 2025-01-28 15:04:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:40 --> Config Class Initialized
INFO - 2025-01-28 09:34:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:40 --> URI Class Initialized
INFO - 2025-01-28 09:34:40 --> Router Class Initialized
INFO - 2025-01-28 09:34:40 --> Output Class Initialized
INFO - 2025-01-28 09:34:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:40 --> Input Class Initialized
INFO - 2025-01-28 09:34:40 --> Language Class Initialized
INFO - 2025-01-28 09:34:40 --> Loader Class Initialized
INFO - 2025-01-28 09:34:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:40 --> Upload Class Initialized
INFO - 2025-01-28 09:34:40 --> Email Class Initialized
INFO - 2025-01-28 09:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:40 --> Controller Class Initialized
INFO - 2025-01-28 15:04:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:45 --> Config Class Initialized
INFO - 2025-01-28 09:34:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:45 --> URI Class Initialized
INFO - 2025-01-28 09:34:45 --> Router Class Initialized
INFO - 2025-01-28 09:34:45 --> Output Class Initialized
INFO - 2025-01-28 09:34:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:45 --> Input Class Initialized
INFO - 2025-01-28 09:34:45 --> Language Class Initialized
INFO - 2025-01-28 09:34:45 --> Loader Class Initialized
INFO - 2025-01-28 09:34:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:45 --> Upload Class Initialized
INFO - 2025-01-28 09:34:45 --> Email Class Initialized
INFO - 2025-01-28 09:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:45 --> Controller Class Initialized
INFO - 2025-01-28 15:04:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:50 --> Config Class Initialized
INFO - 2025-01-28 09:34:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:50 --> URI Class Initialized
INFO - 2025-01-28 09:34:50 --> Router Class Initialized
INFO - 2025-01-28 09:34:50 --> Output Class Initialized
INFO - 2025-01-28 09:34:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:50 --> Input Class Initialized
INFO - 2025-01-28 09:34:50 --> Language Class Initialized
INFO - 2025-01-28 09:34:50 --> Loader Class Initialized
INFO - 2025-01-28 09:34:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:50 --> Upload Class Initialized
INFO - 2025-01-28 09:34:50 --> Email Class Initialized
INFO - 2025-01-28 09:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:50 --> Controller Class Initialized
INFO - 2025-01-28 15:04:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:34:55 --> Config Class Initialized
INFO - 2025-01-28 09:34:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:34:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:34:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:34:55 --> URI Class Initialized
INFO - 2025-01-28 09:34:55 --> Router Class Initialized
INFO - 2025-01-28 09:34:55 --> Output Class Initialized
INFO - 2025-01-28 09:34:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:34:55 --> Input Class Initialized
INFO - 2025-01-28 09:34:55 --> Language Class Initialized
INFO - 2025-01-28 09:34:55 --> Loader Class Initialized
INFO - 2025-01-28 09:34:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:34:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:34:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:34:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:34:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:34:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:34:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:34:55 --> Upload Class Initialized
INFO - 2025-01-28 09:34:55 --> Email Class Initialized
INFO - 2025-01-28 09:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:34:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:34:55 --> Controller Class Initialized
INFO - 2025-01-28 15:04:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:04:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:04:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:00 --> Config Class Initialized
INFO - 2025-01-28 09:35:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:00 --> URI Class Initialized
INFO - 2025-01-28 09:35:00 --> Router Class Initialized
INFO - 2025-01-28 09:35:00 --> Output Class Initialized
INFO - 2025-01-28 09:35:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:00 --> Input Class Initialized
INFO - 2025-01-28 09:35:00 --> Language Class Initialized
INFO - 2025-01-28 09:35:00 --> Loader Class Initialized
INFO - 2025-01-28 09:35:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:00 --> Upload Class Initialized
INFO - 2025-01-28 09:35:00 --> Email Class Initialized
INFO - 2025-01-28 09:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:00 --> Controller Class Initialized
INFO - 2025-01-28 15:05:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:05 --> Config Class Initialized
INFO - 2025-01-28 09:35:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:05 --> URI Class Initialized
INFO - 2025-01-28 09:35:05 --> Router Class Initialized
INFO - 2025-01-28 09:35:05 --> Output Class Initialized
INFO - 2025-01-28 09:35:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:05 --> Input Class Initialized
INFO - 2025-01-28 09:35:05 --> Language Class Initialized
INFO - 2025-01-28 09:35:05 --> Loader Class Initialized
INFO - 2025-01-28 09:35:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:05 --> Upload Class Initialized
INFO - 2025-01-28 09:35:05 --> Email Class Initialized
INFO - 2025-01-28 09:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:05 --> Controller Class Initialized
INFO - 2025-01-28 15:05:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:10 --> Config Class Initialized
INFO - 2025-01-28 09:35:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:10 --> URI Class Initialized
INFO - 2025-01-28 09:35:10 --> Router Class Initialized
INFO - 2025-01-28 09:35:10 --> Output Class Initialized
INFO - 2025-01-28 09:35:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:10 --> Input Class Initialized
INFO - 2025-01-28 09:35:10 --> Language Class Initialized
INFO - 2025-01-28 09:35:10 --> Loader Class Initialized
INFO - 2025-01-28 09:35:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:10 --> Upload Class Initialized
INFO - 2025-01-28 09:35:10 --> Email Class Initialized
INFO - 2025-01-28 09:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:10 --> Controller Class Initialized
INFO - 2025-01-28 15:05:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:15 --> Config Class Initialized
INFO - 2025-01-28 09:35:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:15 --> URI Class Initialized
INFO - 2025-01-28 09:35:15 --> Router Class Initialized
INFO - 2025-01-28 09:35:15 --> Output Class Initialized
INFO - 2025-01-28 09:35:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:15 --> Input Class Initialized
INFO - 2025-01-28 09:35:15 --> Language Class Initialized
INFO - 2025-01-28 09:35:15 --> Loader Class Initialized
INFO - 2025-01-28 09:35:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:15 --> Upload Class Initialized
INFO - 2025-01-28 09:35:15 --> Email Class Initialized
INFO - 2025-01-28 09:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:15 --> Controller Class Initialized
INFO - 2025-01-28 15:05:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:20 --> Config Class Initialized
INFO - 2025-01-28 09:35:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:20 --> URI Class Initialized
INFO - 2025-01-28 09:35:20 --> Router Class Initialized
INFO - 2025-01-28 09:35:20 --> Output Class Initialized
INFO - 2025-01-28 09:35:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:20 --> Input Class Initialized
INFO - 2025-01-28 09:35:20 --> Language Class Initialized
INFO - 2025-01-28 09:35:20 --> Loader Class Initialized
INFO - 2025-01-28 09:35:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:20 --> Upload Class Initialized
INFO - 2025-01-28 09:35:20 --> Email Class Initialized
INFO - 2025-01-28 09:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:20 --> Controller Class Initialized
INFO - 2025-01-28 15:05:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:25 --> Config Class Initialized
INFO - 2025-01-28 09:35:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:25 --> URI Class Initialized
INFO - 2025-01-28 09:35:25 --> Router Class Initialized
INFO - 2025-01-28 09:35:25 --> Output Class Initialized
INFO - 2025-01-28 09:35:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:25 --> Input Class Initialized
INFO - 2025-01-28 09:35:25 --> Language Class Initialized
INFO - 2025-01-28 09:35:25 --> Loader Class Initialized
INFO - 2025-01-28 09:35:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:25 --> Upload Class Initialized
INFO - 2025-01-28 09:35:25 --> Email Class Initialized
INFO - 2025-01-28 09:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:25 --> Controller Class Initialized
INFO - 2025-01-28 15:05:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:30 --> Config Class Initialized
INFO - 2025-01-28 09:35:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:30 --> URI Class Initialized
INFO - 2025-01-28 09:35:30 --> Router Class Initialized
INFO - 2025-01-28 09:35:30 --> Output Class Initialized
INFO - 2025-01-28 09:35:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:30 --> Input Class Initialized
INFO - 2025-01-28 09:35:30 --> Language Class Initialized
INFO - 2025-01-28 09:35:30 --> Loader Class Initialized
INFO - 2025-01-28 09:35:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:30 --> Upload Class Initialized
INFO - 2025-01-28 09:35:30 --> Email Class Initialized
INFO - 2025-01-28 09:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:30 --> Controller Class Initialized
INFO - 2025-01-28 15:05:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:35 --> Config Class Initialized
INFO - 2025-01-28 09:35:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:35 --> URI Class Initialized
INFO - 2025-01-28 09:35:35 --> Router Class Initialized
INFO - 2025-01-28 09:35:35 --> Output Class Initialized
INFO - 2025-01-28 09:35:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:35 --> Input Class Initialized
INFO - 2025-01-28 09:35:35 --> Language Class Initialized
INFO - 2025-01-28 09:35:35 --> Loader Class Initialized
INFO - 2025-01-28 09:35:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:35 --> Upload Class Initialized
INFO - 2025-01-28 09:35:35 --> Email Class Initialized
INFO - 2025-01-28 09:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:35 --> Controller Class Initialized
INFO - 2025-01-28 15:05:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:40 --> Config Class Initialized
INFO - 2025-01-28 09:35:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:40 --> URI Class Initialized
INFO - 2025-01-28 09:35:40 --> Router Class Initialized
INFO - 2025-01-28 09:35:40 --> Output Class Initialized
INFO - 2025-01-28 09:35:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:40 --> Input Class Initialized
INFO - 2025-01-28 09:35:40 --> Language Class Initialized
INFO - 2025-01-28 09:35:40 --> Loader Class Initialized
INFO - 2025-01-28 09:35:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:40 --> Upload Class Initialized
INFO - 2025-01-28 09:35:40 --> Email Class Initialized
INFO - 2025-01-28 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:40 --> Controller Class Initialized
INFO - 2025-01-28 15:05:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:45 --> Config Class Initialized
INFO - 2025-01-28 09:35:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:45 --> URI Class Initialized
INFO - 2025-01-28 09:35:45 --> Router Class Initialized
INFO - 2025-01-28 09:35:45 --> Output Class Initialized
INFO - 2025-01-28 09:35:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:45 --> Input Class Initialized
INFO - 2025-01-28 09:35:45 --> Language Class Initialized
INFO - 2025-01-28 09:35:45 --> Loader Class Initialized
INFO - 2025-01-28 09:35:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:45 --> Upload Class Initialized
INFO - 2025-01-28 09:35:45 --> Email Class Initialized
INFO - 2025-01-28 09:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:45 --> Controller Class Initialized
INFO - 2025-01-28 15:05:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:50 --> Config Class Initialized
INFO - 2025-01-28 09:35:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:50 --> URI Class Initialized
INFO - 2025-01-28 09:35:50 --> Router Class Initialized
INFO - 2025-01-28 09:35:50 --> Output Class Initialized
INFO - 2025-01-28 09:35:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:50 --> Input Class Initialized
INFO - 2025-01-28 09:35:50 --> Language Class Initialized
INFO - 2025-01-28 09:35:50 --> Loader Class Initialized
INFO - 2025-01-28 09:35:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:50 --> Upload Class Initialized
INFO - 2025-01-28 09:35:50 --> Email Class Initialized
INFO - 2025-01-28 09:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:50 --> Controller Class Initialized
INFO - 2025-01-28 15:05:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:35:55 --> Config Class Initialized
INFO - 2025-01-28 09:35:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:35:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:35:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:35:55 --> URI Class Initialized
INFO - 2025-01-28 09:35:55 --> Router Class Initialized
INFO - 2025-01-28 09:35:55 --> Output Class Initialized
INFO - 2025-01-28 09:35:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:35:55 --> Input Class Initialized
INFO - 2025-01-28 09:35:55 --> Language Class Initialized
INFO - 2025-01-28 09:35:55 --> Loader Class Initialized
INFO - 2025-01-28 09:35:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:35:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:35:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:35:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:35:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:35:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:35:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:35:55 --> Upload Class Initialized
INFO - 2025-01-28 09:35:55 --> Email Class Initialized
INFO - 2025-01-28 09:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:35:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:35:55 --> Controller Class Initialized
INFO - 2025-01-28 15:05:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:05:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:05:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:00 --> Config Class Initialized
INFO - 2025-01-28 09:36:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:00 --> URI Class Initialized
INFO - 2025-01-28 09:36:00 --> Router Class Initialized
INFO - 2025-01-28 09:36:00 --> Output Class Initialized
INFO - 2025-01-28 09:36:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:00 --> Input Class Initialized
INFO - 2025-01-28 09:36:00 --> Language Class Initialized
INFO - 2025-01-28 09:36:00 --> Loader Class Initialized
INFO - 2025-01-28 09:36:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:00 --> Upload Class Initialized
INFO - 2025-01-28 09:36:00 --> Email Class Initialized
INFO - 2025-01-28 09:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:00 --> Controller Class Initialized
INFO - 2025-01-28 15:06:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:05 --> Config Class Initialized
INFO - 2025-01-28 09:36:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:05 --> URI Class Initialized
INFO - 2025-01-28 09:36:05 --> Router Class Initialized
INFO - 2025-01-28 09:36:05 --> Output Class Initialized
INFO - 2025-01-28 09:36:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:05 --> Input Class Initialized
INFO - 2025-01-28 09:36:05 --> Language Class Initialized
INFO - 2025-01-28 09:36:05 --> Loader Class Initialized
INFO - 2025-01-28 09:36:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:05 --> Upload Class Initialized
INFO - 2025-01-28 09:36:05 --> Email Class Initialized
INFO - 2025-01-28 09:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:05 --> Controller Class Initialized
INFO - 2025-01-28 15:06:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:10 --> Config Class Initialized
INFO - 2025-01-28 09:36:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:10 --> URI Class Initialized
INFO - 2025-01-28 09:36:10 --> Router Class Initialized
INFO - 2025-01-28 09:36:10 --> Output Class Initialized
INFO - 2025-01-28 09:36:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:10 --> Input Class Initialized
INFO - 2025-01-28 09:36:10 --> Language Class Initialized
INFO - 2025-01-28 09:36:10 --> Loader Class Initialized
INFO - 2025-01-28 09:36:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:10 --> Upload Class Initialized
INFO - 2025-01-28 09:36:10 --> Email Class Initialized
INFO - 2025-01-28 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:10 --> Controller Class Initialized
INFO - 2025-01-28 15:06:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:15 --> Config Class Initialized
INFO - 2025-01-28 09:36:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:15 --> URI Class Initialized
INFO - 2025-01-28 09:36:15 --> Router Class Initialized
INFO - 2025-01-28 09:36:15 --> Output Class Initialized
INFO - 2025-01-28 09:36:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:15 --> Input Class Initialized
INFO - 2025-01-28 09:36:15 --> Language Class Initialized
INFO - 2025-01-28 09:36:15 --> Loader Class Initialized
INFO - 2025-01-28 09:36:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:15 --> Upload Class Initialized
INFO - 2025-01-28 09:36:15 --> Email Class Initialized
INFO - 2025-01-28 09:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:15 --> Controller Class Initialized
INFO - 2025-01-28 15:06:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:20 --> Config Class Initialized
INFO - 2025-01-28 09:36:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:20 --> URI Class Initialized
INFO - 2025-01-28 09:36:20 --> Router Class Initialized
INFO - 2025-01-28 09:36:20 --> Output Class Initialized
INFO - 2025-01-28 09:36:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:20 --> Input Class Initialized
INFO - 2025-01-28 09:36:20 --> Language Class Initialized
INFO - 2025-01-28 09:36:20 --> Loader Class Initialized
INFO - 2025-01-28 09:36:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:20 --> Upload Class Initialized
INFO - 2025-01-28 09:36:20 --> Email Class Initialized
INFO - 2025-01-28 09:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:20 --> Controller Class Initialized
INFO - 2025-01-28 15:06:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:25 --> Config Class Initialized
INFO - 2025-01-28 09:36:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:25 --> URI Class Initialized
INFO - 2025-01-28 09:36:25 --> Router Class Initialized
INFO - 2025-01-28 09:36:25 --> Output Class Initialized
INFO - 2025-01-28 09:36:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:25 --> Input Class Initialized
INFO - 2025-01-28 09:36:25 --> Language Class Initialized
INFO - 2025-01-28 09:36:25 --> Loader Class Initialized
INFO - 2025-01-28 09:36:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:25 --> Upload Class Initialized
INFO - 2025-01-28 09:36:25 --> Email Class Initialized
INFO - 2025-01-28 09:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:25 --> Controller Class Initialized
INFO - 2025-01-28 15:06:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:30 --> Config Class Initialized
INFO - 2025-01-28 09:36:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:30 --> URI Class Initialized
INFO - 2025-01-28 09:36:30 --> Router Class Initialized
INFO - 2025-01-28 09:36:30 --> Output Class Initialized
INFO - 2025-01-28 09:36:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:30 --> Input Class Initialized
INFO - 2025-01-28 09:36:30 --> Language Class Initialized
INFO - 2025-01-28 09:36:30 --> Loader Class Initialized
INFO - 2025-01-28 09:36:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:30 --> Upload Class Initialized
INFO - 2025-01-28 09:36:30 --> Email Class Initialized
INFO - 2025-01-28 09:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:30 --> Controller Class Initialized
INFO - 2025-01-28 15:06:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:35 --> Config Class Initialized
INFO - 2025-01-28 09:36:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:35 --> URI Class Initialized
INFO - 2025-01-28 09:36:35 --> Router Class Initialized
INFO - 2025-01-28 09:36:35 --> Output Class Initialized
INFO - 2025-01-28 09:36:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:35 --> Input Class Initialized
INFO - 2025-01-28 09:36:35 --> Language Class Initialized
INFO - 2025-01-28 09:36:35 --> Loader Class Initialized
INFO - 2025-01-28 09:36:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:35 --> Upload Class Initialized
INFO - 2025-01-28 09:36:35 --> Email Class Initialized
INFO - 2025-01-28 09:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:35 --> Controller Class Initialized
INFO - 2025-01-28 15:06:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:40 --> Config Class Initialized
INFO - 2025-01-28 09:36:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:40 --> URI Class Initialized
INFO - 2025-01-28 09:36:40 --> Router Class Initialized
INFO - 2025-01-28 09:36:40 --> Output Class Initialized
INFO - 2025-01-28 09:36:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:40 --> Input Class Initialized
INFO - 2025-01-28 09:36:40 --> Language Class Initialized
INFO - 2025-01-28 09:36:40 --> Loader Class Initialized
INFO - 2025-01-28 09:36:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:40 --> Upload Class Initialized
INFO - 2025-01-28 09:36:40 --> Email Class Initialized
INFO - 2025-01-28 09:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:40 --> Controller Class Initialized
INFO - 2025-01-28 15:06:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:36:50 --> Config Class Initialized
INFO - 2025-01-28 09:36:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:36:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:36:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:36:50 --> URI Class Initialized
INFO - 2025-01-28 09:36:50 --> Router Class Initialized
INFO - 2025-01-28 09:36:50 --> Output Class Initialized
INFO - 2025-01-28 09:36:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:36:50 --> Input Class Initialized
INFO - 2025-01-28 09:36:50 --> Language Class Initialized
INFO - 2025-01-28 09:36:50 --> Loader Class Initialized
INFO - 2025-01-28 09:36:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:36:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:36:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:36:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:36:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:36:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:36:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:36:50 --> Upload Class Initialized
INFO - 2025-01-28 09:36:50 --> Email Class Initialized
INFO - 2025-01-28 09:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:36:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:36:50 --> Controller Class Initialized
INFO - 2025-01-28 15:06:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:06:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:06:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:37:50 --> Config Class Initialized
INFO - 2025-01-28 09:37:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:37:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:37:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:37:50 --> URI Class Initialized
INFO - 2025-01-28 09:37:50 --> Router Class Initialized
INFO - 2025-01-28 09:37:50 --> Output Class Initialized
INFO - 2025-01-28 09:37:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:37:50 --> Input Class Initialized
INFO - 2025-01-28 09:37:50 --> Language Class Initialized
INFO - 2025-01-28 09:37:50 --> Loader Class Initialized
INFO - 2025-01-28 09:37:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:37:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:37:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:37:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:37:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:37:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:37:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:37:50 --> Upload Class Initialized
INFO - 2025-01-28 09:37:50 --> Email Class Initialized
INFO - 2025-01-28 09:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:37:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:37:50 --> Controller Class Initialized
INFO - 2025-01-28 15:07:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:07:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:07:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:38:50 --> Config Class Initialized
INFO - 2025-01-28 09:38:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:38:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:38:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:38:50 --> URI Class Initialized
INFO - 2025-01-28 09:38:50 --> Router Class Initialized
INFO - 2025-01-28 09:38:50 --> Output Class Initialized
INFO - 2025-01-28 09:38:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:38:50 --> Input Class Initialized
INFO - 2025-01-28 09:38:50 --> Language Class Initialized
INFO - 2025-01-28 09:38:50 --> Loader Class Initialized
INFO - 2025-01-28 09:38:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:38:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:38:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:38:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:38:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:38:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:38:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:38:50 --> Upload Class Initialized
INFO - 2025-01-28 09:38:50 --> Email Class Initialized
INFO - 2025-01-28 09:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:38:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:38:50 --> Controller Class Initialized
INFO - 2025-01-28 15:08:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:08:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:08:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:39:50 --> Config Class Initialized
INFO - 2025-01-28 09:39:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:39:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:39:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:39:50 --> URI Class Initialized
INFO - 2025-01-28 09:39:50 --> Router Class Initialized
INFO - 2025-01-28 09:39:50 --> Output Class Initialized
INFO - 2025-01-28 09:39:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:39:50 --> Input Class Initialized
INFO - 2025-01-28 09:39:50 --> Language Class Initialized
INFO - 2025-01-28 09:39:50 --> Loader Class Initialized
INFO - 2025-01-28 09:39:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:39:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:39:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:39:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:39:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:39:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:39:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:39:50 --> Upload Class Initialized
INFO - 2025-01-28 09:39:50 --> Email Class Initialized
INFO - 2025-01-28 09:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:39:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:39:50 --> Controller Class Initialized
INFO - 2025-01-28 15:09:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:09:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:09:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:40:50 --> Config Class Initialized
INFO - 2025-01-28 09:40:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:40:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:40:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:40:50 --> URI Class Initialized
INFO - 2025-01-28 09:40:50 --> Router Class Initialized
INFO - 2025-01-28 09:40:50 --> Output Class Initialized
INFO - 2025-01-28 09:40:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:40:50 --> Input Class Initialized
INFO - 2025-01-28 09:40:50 --> Language Class Initialized
INFO - 2025-01-28 09:40:50 --> Loader Class Initialized
INFO - 2025-01-28 09:40:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:40:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:40:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:40:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:40:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:40:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:40:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:40:50 --> Upload Class Initialized
INFO - 2025-01-28 09:40:50 --> Email Class Initialized
INFO - 2025-01-28 09:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:40:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:40:50 --> Controller Class Initialized
INFO - 2025-01-28 15:10:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:10:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:10:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:41:50 --> Config Class Initialized
INFO - 2025-01-28 09:41:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:41:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:41:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:41:50 --> URI Class Initialized
INFO - 2025-01-28 09:41:50 --> Router Class Initialized
INFO - 2025-01-28 09:41:50 --> Output Class Initialized
INFO - 2025-01-28 09:41:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:41:50 --> Input Class Initialized
INFO - 2025-01-28 09:41:50 --> Language Class Initialized
INFO - 2025-01-28 09:41:50 --> Loader Class Initialized
INFO - 2025-01-28 09:41:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:41:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:41:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:41:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:41:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:41:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:41:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:41:50 --> Upload Class Initialized
INFO - 2025-01-28 09:41:50 --> Email Class Initialized
INFO - 2025-01-28 09:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:41:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:41:50 --> Controller Class Initialized
INFO - 2025-01-28 15:11:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:11:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:11:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:42:50 --> Config Class Initialized
INFO - 2025-01-28 09:42:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:42:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:42:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:42:50 --> URI Class Initialized
INFO - 2025-01-28 09:42:50 --> Router Class Initialized
INFO - 2025-01-28 09:42:50 --> Output Class Initialized
INFO - 2025-01-28 09:42:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:42:50 --> Input Class Initialized
INFO - 2025-01-28 09:42:50 --> Language Class Initialized
INFO - 2025-01-28 09:42:50 --> Loader Class Initialized
INFO - 2025-01-28 09:42:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:42:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:42:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:42:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:42:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:42:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:42:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:42:50 --> Upload Class Initialized
INFO - 2025-01-28 09:42:50 --> Email Class Initialized
INFO - 2025-01-28 09:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:42:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:42:50 --> Controller Class Initialized
INFO - 2025-01-28 15:12:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:12:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:12:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:43:38 --> Config Class Initialized
INFO - 2025-01-28 09:43:38 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:43:38 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:43:38 --> Utf8 Class Initialized
INFO - 2025-01-28 09:43:38 --> URI Class Initialized
INFO - 2025-01-28 09:43:38 --> Router Class Initialized
INFO - 2025-01-28 09:43:38 --> Output Class Initialized
INFO - 2025-01-28 09:43:38 --> Security Class Initialized
DEBUG - 2025-01-28 09:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:43:38 --> Input Class Initialized
INFO - 2025-01-28 09:43:38 --> Language Class Initialized
ERROR - 2025-01-28 09:43:38 --> 404 Page Not Found: Page_login/index  
ERROR - 2025-01-28 09:43:38 --> 404 Page Not Found: index app_login/index  
INFO - 2025-01-28 09:43:50 --> Config Class Initialized
INFO - 2025-01-28 09:43:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:43:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:43:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:43:50 --> URI Class Initialized
INFO - 2025-01-28 09:43:50 --> Router Class Initialized
INFO - 2025-01-28 09:43:50 --> Output Class Initialized
INFO - 2025-01-28 09:43:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:43:50 --> Input Class Initialized
INFO - 2025-01-28 09:43:50 --> Language Class Initialized
INFO - 2025-01-28 09:43:50 --> Loader Class Initialized
INFO - 2025-01-28 09:43:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:43:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:43:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:43:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:43:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:43:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:43:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:43:50 --> Upload Class Initialized
INFO - 2025-01-28 09:43:50 --> Email Class Initialized
INFO - 2025-01-28 09:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:43:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:43:50 --> Controller Class Initialized
INFO - 2025-01-28 15:13:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:13:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:13:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:14 --> Config Class Initialized
INFO - 2025-01-28 09:44:14 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:14 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:14 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:14 --> URI Class Initialized
INFO - 2025-01-28 09:44:14 --> Router Class Initialized
INFO - 2025-01-28 09:44:14 --> Output Class Initialized
INFO - 2025-01-28 09:44:14 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:14 --> Input Class Initialized
INFO - 2025-01-28 09:44:14 --> Language Class Initialized
INFO - 2025-01-28 09:44:14 --> Loader Class Initialized
INFO - 2025-01-28 09:44:14 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:14 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:14 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:14 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:14 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:14 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:14 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:14 --> Upload Class Initialized
INFO - 2025-01-28 09:44:14 --> Email Class Initialized
INFO - 2025-01-28 09:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:14 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:14 --> Controller Class Initialized
INFO - 2025-01-28 15:14:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:14 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:14 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:15 --> Config Class Initialized
INFO - 2025-01-28 09:44:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:15 --> URI Class Initialized
INFO - 2025-01-28 09:44:15 --> Router Class Initialized
INFO - 2025-01-28 09:44:15 --> Output Class Initialized
INFO - 2025-01-28 09:44:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:15 --> Input Class Initialized
INFO - 2025-01-28 09:44:15 --> Language Class Initialized
INFO - 2025-01-28 09:44:15 --> Loader Class Initialized
INFO - 2025-01-28 09:44:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:15 --> Upload Class Initialized
INFO - 2025-01-28 09:44:15 --> Email Class Initialized
INFO - 2025-01-28 09:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:15 --> Controller Class Initialized
INFO - 2025-01-28 15:14:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:20 --> Config Class Initialized
INFO - 2025-01-28 09:44:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:20 --> URI Class Initialized
INFO - 2025-01-28 09:44:20 --> Router Class Initialized
INFO - 2025-01-28 09:44:20 --> Output Class Initialized
INFO - 2025-01-28 09:44:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:20 --> Input Class Initialized
INFO - 2025-01-28 09:44:20 --> Language Class Initialized
INFO - 2025-01-28 09:44:20 --> Loader Class Initialized
INFO - 2025-01-28 09:44:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:20 --> Upload Class Initialized
INFO - 2025-01-28 09:44:20 --> Email Class Initialized
INFO - 2025-01-28 09:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:20 --> Controller Class Initialized
INFO - 2025-01-28 15:14:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:25 --> Config Class Initialized
INFO - 2025-01-28 09:44:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:25 --> URI Class Initialized
INFO - 2025-01-28 09:44:25 --> Router Class Initialized
INFO - 2025-01-28 09:44:25 --> Output Class Initialized
INFO - 2025-01-28 09:44:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:25 --> Input Class Initialized
INFO - 2025-01-28 09:44:25 --> Language Class Initialized
INFO - 2025-01-28 09:44:25 --> Loader Class Initialized
INFO - 2025-01-28 09:44:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:25 --> Upload Class Initialized
INFO - 2025-01-28 09:44:25 --> Email Class Initialized
INFO - 2025-01-28 09:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:25 --> Controller Class Initialized
INFO - 2025-01-28 15:14:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:30 --> Config Class Initialized
INFO - 2025-01-28 09:44:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:30 --> URI Class Initialized
INFO - 2025-01-28 09:44:30 --> Router Class Initialized
INFO - 2025-01-28 09:44:30 --> Output Class Initialized
INFO - 2025-01-28 09:44:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:30 --> Input Class Initialized
INFO - 2025-01-28 09:44:30 --> Language Class Initialized
INFO - 2025-01-28 09:44:30 --> Loader Class Initialized
INFO - 2025-01-28 09:44:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:30 --> Upload Class Initialized
INFO - 2025-01-28 09:44:30 --> Email Class Initialized
INFO - 2025-01-28 09:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:30 --> Controller Class Initialized
INFO - 2025-01-28 15:14:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:35 --> Config Class Initialized
INFO - 2025-01-28 09:44:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:35 --> URI Class Initialized
INFO - 2025-01-28 09:44:35 --> Router Class Initialized
INFO - 2025-01-28 09:44:35 --> Output Class Initialized
INFO - 2025-01-28 09:44:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:35 --> Input Class Initialized
INFO - 2025-01-28 09:44:35 --> Language Class Initialized
INFO - 2025-01-28 09:44:35 --> Loader Class Initialized
INFO - 2025-01-28 09:44:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:35 --> Upload Class Initialized
INFO - 2025-01-28 09:44:35 --> Email Class Initialized
INFO - 2025-01-28 09:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:35 --> Controller Class Initialized
INFO - 2025-01-28 15:14:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:40 --> Config Class Initialized
INFO - 2025-01-28 09:44:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:40 --> URI Class Initialized
INFO - 2025-01-28 09:44:40 --> Router Class Initialized
INFO - 2025-01-28 09:44:40 --> Output Class Initialized
INFO - 2025-01-28 09:44:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:40 --> Input Class Initialized
INFO - 2025-01-28 09:44:40 --> Language Class Initialized
INFO - 2025-01-28 09:44:40 --> Loader Class Initialized
INFO - 2025-01-28 09:44:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:40 --> Upload Class Initialized
INFO - 2025-01-28 09:44:40 --> Email Class Initialized
INFO - 2025-01-28 09:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:40 --> Controller Class Initialized
INFO - 2025-01-28 15:14:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:45 --> Config Class Initialized
INFO - 2025-01-28 09:44:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:45 --> URI Class Initialized
INFO - 2025-01-28 09:44:45 --> Router Class Initialized
INFO - 2025-01-28 09:44:45 --> Output Class Initialized
INFO - 2025-01-28 09:44:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:45 --> Input Class Initialized
INFO - 2025-01-28 09:44:45 --> Language Class Initialized
INFO - 2025-01-28 09:44:45 --> Loader Class Initialized
INFO - 2025-01-28 09:44:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:45 --> Upload Class Initialized
INFO - 2025-01-28 09:44:45 --> Email Class Initialized
INFO - 2025-01-28 09:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:45 --> Controller Class Initialized
INFO - 2025-01-28 15:14:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:48 --> Config Class Initialized
INFO - 2025-01-28 09:44:48 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:48 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:48 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:48 --> URI Class Initialized
INFO - 2025-01-28 09:44:48 --> Router Class Initialized
INFO - 2025-01-28 09:44:48 --> Output Class Initialized
INFO - 2025-01-28 09:44:48 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:48 --> Input Class Initialized
INFO - 2025-01-28 09:44:48 --> Language Class Initialized
INFO - 2025-01-28 09:44:48 --> Loader Class Initialized
INFO - 2025-01-28 09:44:48 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:48 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:48 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:48 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:48 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:48 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:48 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:48 --> Upload Class Initialized
INFO - 2025-01-28 09:44:48 --> Email Class Initialized
INFO - 2025-01-28 09:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:48 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:48 --> Controller Class Initialized
INFO - 2025-01-28 15:14:48 --> Model "ApiModel" initialized
INFO - 2025-01-28 15:14:48 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:14:48 --> Model "MainModel" initialized
INFO - 2025-01-28 09:44:50 --> Config Class Initialized
INFO - 2025-01-28 09:44:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:50 --> URI Class Initialized
INFO - 2025-01-28 09:44:50 --> Router Class Initialized
INFO - 2025-01-28 09:44:50 --> Output Class Initialized
INFO - 2025-01-28 09:44:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:50 --> Input Class Initialized
INFO - 2025-01-28 09:44:50 --> Language Class Initialized
INFO - 2025-01-28 09:44:50 --> Loader Class Initialized
INFO - 2025-01-28 09:44:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:50 --> Upload Class Initialized
INFO - 2025-01-28 09:44:50 --> Email Class Initialized
INFO - 2025-01-28 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:50 --> Controller Class Initialized
INFO - 2025-01-28 15:14:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:44:55 --> Config Class Initialized
INFO - 2025-01-28 09:44:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:44:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:44:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:44:55 --> URI Class Initialized
INFO - 2025-01-28 09:44:55 --> Router Class Initialized
INFO - 2025-01-28 09:44:55 --> Output Class Initialized
INFO - 2025-01-28 09:44:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:44:55 --> Input Class Initialized
INFO - 2025-01-28 09:44:55 --> Language Class Initialized
INFO - 2025-01-28 09:44:55 --> Loader Class Initialized
INFO - 2025-01-28 09:44:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:44:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:44:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:44:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:44:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:44:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:44:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:44:55 --> Upload Class Initialized
INFO - 2025-01-28 09:44:55 --> Email Class Initialized
INFO - 2025-01-28 09:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:44:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:44:55 --> Controller Class Initialized
INFO - 2025-01-28 15:14:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:14:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:14:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:00 --> Config Class Initialized
INFO - 2025-01-28 09:45:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:00 --> URI Class Initialized
INFO - 2025-01-28 09:45:00 --> Router Class Initialized
INFO - 2025-01-28 09:45:00 --> Output Class Initialized
INFO - 2025-01-28 09:45:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:00 --> Input Class Initialized
INFO - 2025-01-28 09:45:00 --> Language Class Initialized
INFO - 2025-01-28 09:45:00 --> Loader Class Initialized
INFO - 2025-01-28 09:45:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:00 --> Upload Class Initialized
INFO - 2025-01-28 09:45:00 --> Email Class Initialized
INFO - 2025-01-28 09:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:00 --> Controller Class Initialized
INFO - 2025-01-28 15:15:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:05 --> Config Class Initialized
INFO - 2025-01-28 09:45:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:05 --> URI Class Initialized
INFO - 2025-01-28 09:45:05 --> Router Class Initialized
INFO - 2025-01-28 09:45:05 --> Output Class Initialized
INFO - 2025-01-28 09:45:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:05 --> Input Class Initialized
INFO - 2025-01-28 09:45:05 --> Language Class Initialized
INFO - 2025-01-28 09:45:05 --> Loader Class Initialized
INFO - 2025-01-28 09:45:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:05 --> Upload Class Initialized
INFO - 2025-01-28 09:45:05 --> Email Class Initialized
INFO - 2025-01-28 09:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:05 --> Controller Class Initialized
INFO - 2025-01-28 15:15:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:10 --> Config Class Initialized
INFO - 2025-01-28 09:45:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:10 --> URI Class Initialized
INFO - 2025-01-28 09:45:10 --> Router Class Initialized
INFO - 2025-01-28 09:45:10 --> Output Class Initialized
INFO - 2025-01-28 09:45:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:10 --> Input Class Initialized
INFO - 2025-01-28 09:45:10 --> Language Class Initialized
INFO - 2025-01-28 09:45:10 --> Loader Class Initialized
INFO - 2025-01-28 09:45:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:10 --> Upload Class Initialized
INFO - 2025-01-28 09:45:10 --> Email Class Initialized
INFO - 2025-01-28 09:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:10 --> Controller Class Initialized
INFO - 2025-01-28 15:15:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:15 --> Config Class Initialized
INFO - 2025-01-28 09:45:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:15 --> URI Class Initialized
INFO - 2025-01-28 09:45:15 --> Router Class Initialized
INFO - 2025-01-28 09:45:15 --> Output Class Initialized
INFO - 2025-01-28 09:45:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:15 --> Input Class Initialized
INFO - 2025-01-28 09:45:15 --> Language Class Initialized
INFO - 2025-01-28 09:45:15 --> Loader Class Initialized
INFO - 2025-01-28 09:45:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:15 --> Upload Class Initialized
INFO - 2025-01-28 09:45:15 --> Email Class Initialized
INFO - 2025-01-28 09:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:15 --> Controller Class Initialized
INFO - 2025-01-28 15:15:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:20 --> Config Class Initialized
INFO - 2025-01-28 09:45:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:20 --> URI Class Initialized
INFO - 2025-01-28 09:45:20 --> Router Class Initialized
INFO - 2025-01-28 09:45:20 --> Output Class Initialized
INFO - 2025-01-28 09:45:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:20 --> Input Class Initialized
INFO - 2025-01-28 09:45:20 --> Language Class Initialized
INFO - 2025-01-28 09:45:20 --> Loader Class Initialized
INFO - 2025-01-28 09:45:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:20 --> Upload Class Initialized
INFO - 2025-01-28 09:45:20 --> Email Class Initialized
INFO - 2025-01-28 09:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:20 --> Controller Class Initialized
INFO - 2025-01-28 15:15:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:25 --> Config Class Initialized
INFO - 2025-01-28 09:45:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:25 --> URI Class Initialized
INFO - 2025-01-28 09:45:25 --> Router Class Initialized
INFO - 2025-01-28 09:45:25 --> Output Class Initialized
INFO - 2025-01-28 09:45:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:25 --> Input Class Initialized
INFO - 2025-01-28 09:45:25 --> Language Class Initialized
INFO - 2025-01-28 09:45:25 --> Loader Class Initialized
INFO - 2025-01-28 09:45:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:25 --> Upload Class Initialized
INFO - 2025-01-28 09:45:25 --> Email Class Initialized
INFO - 2025-01-28 09:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:25 --> Controller Class Initialized
INFO - 2025-01-28 15:15:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:30 --> Config Class Initialized
INFO - 2025-01-28 09:45:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:30 --> URI Class Initialized
INFO - 2025-01-28 09:45:30 --> Router Class Initialized
INFO - 2025-01-28 09:45:30 --> Output Class Initialized
INFO - 2025-01-28 09:45:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:30 --> Input Class Initialized
INFO - 2025-01-28 09:45:30 --> Language Class Initialized
INFO - 2025-01-28 09:45:30 --> Loader Class Initialized
INFO - 2025-01-28 09:45:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:30 --> Upload Class Initialized
INFO - 2025-01-28 09:45:30 --> Email Class Initialized
INFO - 2025-01-28 09:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:30 --> Controller Class Initialized
INFO - 2025-01-28 15:15:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:35 --> Config Class Initialized
INFO - 2025-01-28 09:45:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:35 --> URI Class Initialized
INFO - 2025-01-28 09:45:35 --> Router Class Initialized
INFO - 2025-01-28 09:45:35 --> Output Class Initialized
INFO - 2025-01-28 09:45:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:35 --> Input Class Initialized
INFO - 2025-01-28 09:45:35 --> Language Class Initialized
INFO - 2025-01-28 09:45:35 --> Loader Class Initialized
INFO - 2025-01-28 09:45:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:35 --> Upload Class Initialized
INFO - 2025-01-28 09:45:35 --> Email Class Initialized
INFO - 2025-01-28 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:35 --> Controller Class Initialized
INFO - 2025-01-28 15:15:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:45:50 --> Config Class Initialized
INFO - 2025-01-28 09:45:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:45:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:45:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:45:50 --> URI Class Initialized
INFO - 2025-01-28 09:45:50 --> Router Class Initialized
INFO - 2025-01-28 09:45:50 --> Output Class Initialized
INFO - 2025-01-28 09:45:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:45:50 --> Input Class Initialized
INFO - 2025-01-28 09:45:50 --> Language Class Initialized
INFO - 2025-01-28 09:45:50 --> Loader Class Initialized
INFO - 2025-01-28 09:45:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:45:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:45:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:45:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:45:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:45:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:45:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:45:50 --> Upload Class Initialized
INFO - 2025-01-28 09:45:50 --> Email Class Initialized
INFO - 2025-01-28 09:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:45:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:45:50 --> Controller Class Initialized
INFO - 2025-01-28 15:15:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:15:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:15:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:46:50 --> Config Class Initialized
INFO - 2025-01-28 09:46:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:46:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:46:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:46:50 --> URI Class Initialized
INFO - 2025-01-28 09:46:50 --> Router Class Initialized
INFO - 2025-01-28 09:46:50 --> Output Class Initialized
INFO - 2025-01-28 09:46:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:46:50 --> Input Class Initialized
INFO - 2025-01-28 09:46:50 --> Language Class Initialized
INFO - 2025-01-28 09:46:50 --> Loader Class Initialized
INFO - 2025-01-28 09:46:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:46:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:46:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:46:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:46:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:46:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:46:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:46:50 --> Upload Class Initialized
INFO - 2025-01-28 09:46:50 --> Email Class Initialized
INFO - 2025-01-28 09:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:46:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:46:50 --> Controller Class Initialized
INFO - 2025-01-28 15:16:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:16:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:16:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:21 --> Config Class Initialized
INFO - 2025-01-28 09:47:21 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:21 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:21 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:21 --> URI Class Initialized
INFO - 2025-01-28 09:47:21 --> Router Class Initialized
INFO - 2025-01-28 09:47:21 --> Output Class Initialized
INFO - 2025-01-28 09:47:21 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:21 --> Input Class Initialized
INFO - 2025-01-28 09:47:21 --> Language Class Initialized
INFO - 2025-01-28 09:47:21 --> Loader Class Initialized
INFO - 2025-01-28 09:47:21 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:21 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:21 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:21 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:21 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:21 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:21 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:21 --> Upload Class Initialized
INFO - 2025-01-28 09:47:21 --> Email Class Initialized
INFO - 2025-01-28 09:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:21 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:21 --> Controller Class Initialized
INFO - 2025-01-28 15:17:21 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:21 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:21 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:25 --> Config Class Initialized
INFO - 2025-01-28 09:47:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:25 --> URI Class Initialized
INFO - 2025-01-28 09:47:25 --> Router Class Initialized
INFO - 2025-01-28 09:47:25 --> Output Class Initialized
INFO - 2025-01-28 09:47:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:25 --> Input Class Initialized
INFO - 2025-01-28 09:47:25 --> Language Class Initialized
INFO - 2025-01-28 09:47:25 --> Loader Class Initialized
INFO - 2025-01-28 09:47:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:25 --> Upload Class Initialized
INFO - 2025-01-28 09:47:25 --> Email Class Initialized
INFO - 2025-01-28 09:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:25 --> Controller Class Initialized
INFO - 2025-01-28 15:17:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:30 --> Config Class Initialized
INFO - 2025-01-28 09:47:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:30 --> URI Class Initialized
INFO - 2025-01-28 09:47:30 --> Router Class Initialized
INFO - 2025-01-28 09:47:30 --> Output Class Initialized
INFO - 2025-01-28 09:47:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:30 --> Input Class Initialized
INFO - 2025-01-28 09:47:30 --> Language Class Initialized
INFO - 2025-01-28 09:47:30 --> Loader Class Initialized
INFO - 2025-01-28 09:47:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:30 --> Upload Class Initialized
INFO - 2025-01-28 09:47:30 --> Email Class Initialized
INFO - 2025-01-28 09:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:30 --> Controller Class Initialized
INFO - 2025-01-28 15:17:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:35 --> Config Class Initialized
INFO - 2025-01-28 09:47:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:35 --> URI Class Initialized
INFO - 2025-01-28 09:47:35 --> Router Class Initialized
INFO - 2025-01-28 09:47:35 --> Output Class Initialized
INFO - 2025-01-28 09:47:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:35 --> Input Class Initialized
INFO - 2025-01-28 09:47:35 --> Language Class Initialized
INFO - 2025-01-28 09:47:35 --> Loader Class Initialized
INFO - 2025-01-28 09:47:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:35 --> Upload Class Initialized
INFO - 2025-01-28 09:47:35 --> Email Class Initialized
INFO - 2025-01-28 09:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:35 --> Controller Class Initialized
INFO - 2025-01-28 15:17:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:40 --> Config Class Initialized
INFO - 2025-01-28 09:47:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:40 --> URI Class Initialized
INFO - 2025-01-28 09:47:40 --> Router Class Initialized
INFO - 2025-01-28 09:47:40 --> Output Class Initialized
INFO - 2025-01-28 09:47:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:40 --> Input Class Initialized
INFO - 2025-01-28 09:47:40 --> Language Class Initialized
INFO - 2025-01-28 09:47:40 --> Loader Class Initialized
INFO - 2025-01-28 09:47:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:40 --> Upload Class Initialized
INFO - 2025-01-28 09:47:40 --> Email Class Initialized
INFO - 2025-01-28 09:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:40 --> Controller Class Initialized
INFO - 2025-01-28 15:17:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:45 --> Config Class Initialized
INFO - 2025-01-28 09:47:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:45 --> URI Class Initialized
INFO - 2025-01-28 09:47:45 --> Router Class Initialized
INFO - 2025-01-28 09:47:45 --> Output Class Initialized
INFO - 2025-01-28 09:47:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:45 --> Input Class Initialized
INFO - 2025-01-28 09:47:45 --> Language Class Initialized
INFO - 2025-01-28 09:47:45 --> Loader Class Initialized
INFO - 2025-01-28 09:47:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:45 --> Upload Class Initialized
INFO - 2025-01-28 09:47:45 --> Email Class Initialized
INFO - 2025-01-28 09:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:45 --> Controller Class Initialized
INFO - 2025-01-28 15:17:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:50 --> Config Class Initialized
INFO - 2025-01-28 09:47:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:50 --> URI Class Initialized
INFO - 2025-01-28 09:47:50 --> Router Class Initialized
INFO - 2025-01-28 09:47:50 --> Output Class Initialized
INFO - 2025-01-28 09:47:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:50 --> Input Class Initialized
INFO - 2025-01-28 09:47:50 --> Language Class Initialized
INFO - 2025-01-28 09:47:50 --> Loader Class Initialized
INFO - 2025-01-28 09:47:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:50 --> Upload Class Initialized
INFO - 2025-01-28 09:47:50 --> Email Class Initialized
INFO - 2025-01-28 09:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:50 --> Controller Class Initialized
INFO - 2025-01-28 15:17:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:47:55 --> Config Class Initialized
INFO - 2025-01-28 09:47:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:47:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:47:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:47:55 --> URI Class Initialized
INFO - 2025-01-28 09:47:55 --> Router Class Initialized
INFO - 2025-01-28 09:47:55 --> Output Class Initialized
INFO - 2025-01-28 09:47:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:47:55 --> Input Class Initialized
INFO - 2025-01-28 09:47:55 --> Language Class Initialized
INFO - 2025-01-28 09:47:55 --> Loader Class Initialized
INFO - 2025-01-28 09:47:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:47:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:47:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:47:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:47:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:47:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:47:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:47:55 --> Upload Class Initialized
INFO - 2025-01-28 09:47:55 --> Email Class Initialized
INFO - 2025-01-28 09:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:47:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:47:55 --> Controller Class Initialized
INFO - 2025-01-28 15:17:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:17:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:17:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:00 --> Config Class Initialized
INFO - 2025-01-28 09:48:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:00 --> URI Class Initialized
INFO - 2025-01-28 09:48:00 --> Router Class Initialized
INFO - 2025-01-28 09:48:00 --> Output Class Initialized
INFO - 2025-01-28 09:48:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:00 --> Input Class Initialized
INFO - 2025-01-28 09:48:00 --> Language Class Initialized
INFO - 2025-01-28 09:48:00 --> Loader Class Initialized
INFO - 2025-01-28 09:48:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:00 --> Upload Class Initialized
INFO - 2025-01-28 09:48:00 --> Email Class Initialized
INFO - 2025-01-28 09:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:00 --> Controller Class Initialized
INFO - 2025-01-28 15:18:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:05 --> Config Class Initialized
INFO - 2025-01-28 09:48:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:05 --> URI Class Initialized
INFO - 2025-01-28 09:48:05 --> Router Class Initialized
INFO - 2025-01-28 09:48:05 --> Output Class Initialized
INFO - 2025-01-28 09:48:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:05 --> Input Class Initialized
INFO - 2025-01-28 09:48:05 --> Language Class Initialized
INFO - 2025-01-28 09:48:05 --> Loader Class Initialized
INFO - 2025-01-28 09:48:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:05 --> Upload Class Initialized
INFO - 2025-01-28 09:48:05 --> Email Class Initialized
INFO - 2025-01-28 09:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:05 --> Controller Class Initialized
INFO - 2025-01-28 15:18:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:10 --> Config Class Initialized
INFO - 2025-01-28 09:48:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:10 --> URI Class Initialized
INFO - 2025-01-28 09:48:10 --> Router Class Initialized
INFO - 2025-01-28 09:48:10 --> Output Class Initialized
INFO - 2025-01-28 09:48:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:10 --> Input Class Initialized
INFO - 2025-01-28 09:48:10 --> Language Class Initialized
INFO - 2025-01-28 09:48:10 --> Loader Class Initialized
INFO - 2025-01-28 09:48:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:10 --> Upload Class Initialized
INFO - 2025-01-28 09:48:10 --> Email Class Initialized
INFO - 2025-01-28 09:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:10 --> Controller Class Initialized
INFO - 2025-01-28 15:18:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:15 --> Config Class Initialized
INFO - 2025-01-28 09:48:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:15 --> URI Class Initialized
INFO - 2025-01-28 09:48:15 --> Router Class Initialized
INFO - 2025-01-28 09:48:15 --> Output Class Initialized
INFO - 2025-01-28 09:48:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:15 --> Input Class Initialized
INFO - 2025-01-28 09:48:15 --> Language Class Initialized
INFO - 2025-01-28 09:48:15 --> Loader Class Initialized
INFO - 2025-01-28 09:48:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:15 --> Upload Class Initialized
INFO - 2025-01-28 09:48:15 --> Email Class Initialized
INFO - 2025-01-28 09:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:15 --> Controller Class Initialized
INFO - 2025-01-28 15:18:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:20 --> Config Class Initialized
INFO - 2025-01-28 09:48:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:20 --> URI Class Initialized
INFO - 2025-01-28 09:48:20 --> Router Class Initialized
INFO - 2025-01-28 09:48:20 --> Output Class Initialized
INFO - 2025-01-28 09:48:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:20 --> Input Class Initialized
INFO - 2025-01-28 09:48:20 --> Language Class Initialized
INFO - 2025-01-28 09:48:20 --> Loader Class Initialized
INFO - 2025-01-28 09:48:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:20 --> Upload Class Initialized
INFO - 2025-01-28 09:48:20 --> Email Class Initialized
INFO - 2025-01-28 09:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:20 --> Controller Class Initialized
INFO - 2025-01-28 15:18:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:25 --> Config Class Initialized
INFO - 2025-01-28 09:48:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:25 --> URI Class Initialized
INFO - 2025-01-28 09:48:25 --> Router Class Initialized
INFO - 2025-01-28 09:48:25 --> Output Class Initialized
INFO - 2025-01-28 09:48:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:25 --> Input Class Initialized
INFO - 2025-01-28 09:48:25 --> Language Class Initialized
INFO - 2025-01-28 09:48:25 --> Loader Class Initialized
INFO - 2025-01-28 09:48:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:25 --> Upload Class Initialized
INFO - 2025-01-28 09:48:25 --> Email Class Initialized
INFO - 2025-01-28 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:25 --> Controller Class Initialized
INFO - 2025-01-28 15:18:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:30 --> Config Class Initialized
INFO - 2025-01-28 09:48:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:30 --> URI Class Initialized
INFO - 2025-01-28 09:48:30 --> Router Class Initialized
INFO - 2025-01-28 09:48:30 --> Output Class Initialized
INFO - 2025-01-28 09:48:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:30 --> Input Class Initialized
INFO - 2025-01-28 09:48:30 --> Language Class Initialized
INFO - 2025-01-28 09:48:30 --> Loader Class Initialized
INFO - 2025-01-28 09:48:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:30 --> Upload Class Initialized
INFO - 2025-01-28 09:48:30 --> Email Class Initialized
INFO - 2025-01-28 09:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:30 --> Controller Class Initialized
INFO - 2025-01-28 15:18:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:35 --> Config Class Initialized
INFO - 2025-01-28 09:48:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:35 --> URI Class Initialized
INFO - 2025-01-28 09:48:35 --> Router Class Initialized
INFO - 2025-01-28 09:48:35 --> Output Class Initialized
INFO - 2025-01-28 09:48:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:35 --> Input Class Initialized
INFO - 2025-01-28 09:48:35 --> Language Class Initialized
INFO - 2025-01-28 09:48:35 --> Loader Class Initialized
INFO - 2025-01-28 09:48:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:35 --> Upload Class Initialized
INFO - 2025-01-28 09:48:35 --> Email Class Initialized
INFO - 2025-01-28 09:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:35 --> Controller Class Initialized
INFO - 2025-01-28 15:18:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:40 --> Config Class Initialized
INFO - 2025-01-28 09:48:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:40 --> URI Class Initialized
INFO - 2025-01-28 09:48:40 --> Router Class Initialized
INFO - 2025-01-28 09:48:40 --> Output Class Initialized
INFO - 2025-01-28 09:48:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:40 --> Input Class Initialized
INFO - 2025-01-28 09:48:40 --> Language Class Initialized
INFO - 2025-01-28 09:48:40 --> Loader Class Initialized
INFO - 2025-01-28 09:48:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:40 --> Upload Class Initialized
INFO - 2025-01-28 09:48:40 --> Email Class Initialized
INFO - 2025-01-28 09:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:40 --> Controller Class Initialized
INFO - 2025-01-28 15:18:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:45 --> Config Class Initialized
INFO - 2025-01-28 09:48:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:45 --> URI Class Initialized
INFO - 2025-01-28 09:48:45 --> Router Class Initialized
INFO - 2025-01-28 09:48:45 --> Output Class Initialized
INFO - 2025-01-28 09:48:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:45 --> Input Class Initialized
INFO - 2025-01-28 09:48:45 --> Language Class Initialized
INFO - 2025-01-28 09:48:45 --> Loader Class Initialized
INFO - 2025-01-28 09:48:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:45 --> Upload Class Initialized
INFO - 2025-01-28 09:48:45 --> Email Class Initialized
INFO - 2025-01-28 09:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:45 --> Controller Class Initialized
INFO - 2025-01-28 15:18:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:50 --> Config Class Initialized
INFO - 2025-01-28 09:48:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:50 --> URI Class Initialized
INFO - 2025-01-28 09:48:50 --> Router Class Initialized
INFO - 2025-01-28 09:48:50 --> Output Class Initialized
INFO - 2025-01-28 09:48:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:50 --> Input Class Initialized
INFO - 2025-01-28 09:48:50 --> Language Class Initialized
INFO - 2025-01-28 09:48:50 --> Loader Class Initialized
INFO - 2025-01-28 09:48:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:50 --> Upload Class Initialized
INFO - 2025-01-28 09:48:50 --> Email Class Initialized
INFO - 2025-01-28 09:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:50 --> Controller Class Initialized
INFO - 2025-01-28 15:18:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:48:55 --> Config Class Initialized
INFO - 2025-01-28 09:48:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:48:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:48:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:48:55 --> URI Class Initialized
INFO - 2025-01-28 09:48:55 --> Router Class Initialized
INFO - 2025-01-28 09:48:55 --> Output Class Initialized
INFO - 2025-01-28 09:48:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:48:55 --> Input Class Initialized
INFO - 2025-01-28 09:48:55 --> Language Class Initialized
INFO - 2025-01-28 09:48:55 --> Loader Class Initialized
INFO - 2025-01-28 09:48:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:48:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:48:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:48:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:48:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:48:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:48:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:48:55 --> Upload Class Initialized
INFO - 2025-01-28 09:48:55 --> Email Class Initialized
INFO - 2025-01-28 09:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:48:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:48:55 --> Controller Class Initialized
INFO - 2025-01-28 15:18:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:18:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:18:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:18:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:00 --> Config Class Initialized
INFO - 2025-01-28 09:49:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:00 --> URI Class Initialized
INFO - 2025-01-28 09:49:00 --> Router Class Initialized
INFO - 2025-01-28 09:49:00 --> Output Class Initialized
INFO - 2025-01-28 09:49:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:00 --> Input Class Initialized
INFO - 2025-01-28 09:49:00 --> Language Class Initialized
INFO - 2025-01-28 09:49:00 --> Loader Class Initialized
INFO - 2025-01-28 09:49:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:00 --> Upload Class Initialized
INFO - 2025-01-28 09:49:00 --> Email Class Initialized
INFO - 2025-01-28 09:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:00 --> Controller Class Initialized
INFO - 2025-01-28 15:19:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:05 --> Config Class Initialized
INFO - 2025-01-28 09:49:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:05 --> URI Class Initialized
INFO - 2025-01-28 09:49:05 --> Router Class Initialized
INFO - 2025-01-28 09:49:05 --> Output Class Initialized
INFO - 2025-01-28 09:49:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:05 --> Input Class Initialized
INFO - 2025-01-28 09:49:05 --> Language Class Initialized
INFO - 2025-01-28 09:49:05 --> Loader Class Initialized
INFO - 2025-01-28 09:49:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:05 --> Upload Class Initialized
INFO - 2025-01-28 09:49:05 --> Email Class Initialized
INFO - 2025-01-28 09:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:05 --> Controller Class Initialized
INFO - 2025-01-28 15:19:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:10 --> Config Class Initialized
INFO - 2025-01-28 09:49:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:10 --> URI Class Initialized
INFO - 2025-01-28 09:49:10 --> Router Class Initialized
INFO - 2025-01-28 09:49:10 --> Output Class Initialized
INFO - 2025-01-28 09:49:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:10 --> Input Class Initialized
INFO - 2025-01-28 09:49:10 --> Language Class Initialized
INFO - 2025-01-28 09:49:10 --> Loader Class Initialized
INFO - 2025-01-28 09:49:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:10 --> Upload Class Initialized
INFO - 2025-01-28 09:49:10 --> Email Class Initialized
INFO - 2025-01-28 09:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:10 --> Controller Class Initialized
INFO - 2025-01-28 15:19:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:15 --> Config Class Initialized
INFO - 2025-01-28 09:49:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:15 --> URI Class Initialized
INFO - 2025-01-28 09:49:15 --> Router Class Initialized
INFO - 2025-01-28 09:49:15 --> Output Class Initialized
INFO - 2025-01-28 09:49:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:15 --> Input Class Initialized
INFO - 2025-01-28 09:49:15 --> Language Class Initialized
INFO - 2025-01-28 09:49:15 --> Loader Class Initialized
INFO - 2025-01-28 09:49:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:15 --> Upload Class Initialized
INFO - 2025-01-28 09:49:15 --> Email Class Initialized
INFO - 2025-01-28 09:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:15 --> Controller Class Initialized
INFO - 2025-01-28 15:19:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:20 --> Config Class Initialized
INFO - 2025-01-28 09:49:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:20 --> URI Class Initialized
INFO - 2025-01-28 09:49:20 --> Router Class Initialized
INFO - 2025-01-28 09:49:20 --> Output Class Initialized
INFO - 2025-01-28 09:49:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:20 --> Input Class Initialized
INFO - 2025-01-28 09:49:20 --> Language Class Initialized
INFO - 2025-01-28 09:49:20 --> Loader Class Initialized
INFO - 2025-01-28 09:49:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:20 --> Upload Class Initialized
INFO - 2025-01-28 09:49:20 --> Email Class Initialized
INFO - 2025-01-28 09:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:20 --> Controller Class Initialized
INFO - 2025-01-28 15:19:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:25 --> Config Class Initialized
INFO - 2025-01-28 09:49:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:25 --> URI Class Initialized
INFO - 2025-01-28 09:49:25 --> Router Class Initialized
INFO - 2025-01-28 09:49:25 --> Output Class Initialized
INFO - 2025-01-28 09:49:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:25 --> Input Class Initialized
INFO - 2025-01-28 09:49:25 --> Language Class Initialized
INFO - 2025-01-28 09:49:25 --> Loader Class Initialized
INFO - 2025-01-28 09:49:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:25 --> Upload Class Initialized
INFO - 2025-01-28 09:49:25 --> Email Class Initialized
INFO - 2025-01-28 09:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:25 --> Controller Class Initialized
INFO - 2025-01-28 15:19:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:30 --> Config Class Initialized
INFO - 2025-01-28 09:49:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:30 --> URI Class Initialized
INFO - 2025-01-28 09:49:30 --> Router Class Initialized
INFO - 2025-01-28 09:49:30 --> Output Class Initialized
INFO - 2025-01-28 09:49:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:30 --> Input Class Initialized
INFO - 2025-01-28 09:49:30 --> Language Class Initialized
INFO - 2025-01-28 09:49:30 --> Loader Class Initialized
INFO - 2025-01-28 09:49:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:30 --> Upload Class Initialized
INFO - 2025-01-28 09:49:30 --> Email Class Initialized
INFO - 2025-01-28 09:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:30 --> Controller Class Initialized
INFO - 2025-01-28 15:19:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:35 --> Config Class Initialized
INFO - 2025-01-28 09:49:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:35 --> URI Class Initialized
INFO - 2025-01-28 09:49:35 --> Router Class Initialized
INFO - 2025-01-28 09:49:35 --> Output Class Initialized
INFO - 2025-01-28 09:49:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:35 --> Input Class Initialized
INFO - 2025-01-28 09:49:35 --> Language Class Initialized
INFO - 2025-01-28 09:49:35 --> Loader Class Initialized
INFO - 2025-01-28 09:49:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:35 --> Upload Class Initialized
INFO - 2025-01-28 09:49:35 --> Email Class Initialized
INFO - 2025-01-28 09:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:35 --> Controller Class Initialized
INFO - 2025-01-28 15:19:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:40 --> Config Class Initialized
INFO - 2025-01-28 09:49:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:40 --> URI Class Initialized
INFO - 2025-01-28 09:49:40 --> Router Class Initialized
INFO - 2025-01-28 09:49:40 --> Output Class Initialized
INFO - 2025-01-28 09:49:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:40 --> Input Class Initialized
INFO - 2025-01-28 09:49:40 --> Language Class Initialized
INFO - 2025-01-28 09:49:40 --> Loader Class Initialized
INFO - 2025-01-28 09:49:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:40 --> Upload Class Initialized
INFO - 2025-01-28 09:49:40 --> Email Class Initialized
INFO - 2025-01-28 09:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:40 --> Controller Class Initialized
INFO - 2025-01-28 15:19:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:45 --> Config Class Initialized
INFO - 2025-01-28 09:49:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:45 --> URI Class Initialized
INFO - 2025-01-28 09:49:45 --> Router Class Initialized
INFO - 2025-01-28 09:49:45 --> Output Class Initialized
INFO - 2025-01-28 09:49:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:45 --> Input Class Initialized
INFO - 2025-01-28 09:49:45 --> Language Class Initialized
INFO - 2025-01-28 09:49:45 --> Loader Class Initialized
INFO - 2025-01-28 09:49:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:45 --> Upload Class Initialized
INFO - 2025-01-28 09:49:45 --> Email Class Initialized
INFO - 2025-01-28 09:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:45 --> Controller Class Initialized
INFO - 2025-01-28 15:19:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:50 --> Config Class Initialized
INFO - 2025-01-28 09:49:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:50 --> URI Class Initialized
INFO - 2025-01-28 09:49:50 --> Router Class Initialized
INFO - 2025-01-28 09:49:50 --> Output Class Initialized
INFO - 2025-01-28 09:49:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:50 --> Input Class Initialized
INFO - 2025-01-28 09:49:50 --> Language Class Initialized
INFO - 2025-01-28 09:49:50 --> Loader Class Initialized
INFO - 2025-01-28 09:49:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:50 --> Upload Class Initialized
INFO - 2025-01-28 09:49:50 --> Email Class Initialized
INFO - 2025-01-28 09:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:50 --> Controller Class Initialized
INFO - 2025-01-28 15:19:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:49:55 --> Config Class Initialized
INFO - 2025-01-28 09:49:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:49:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:49:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:49:55 --> URI Class Initialized
INFO - 2025-01-28 09:49:55 --> Router Class Initialized
INFO - 2025-01-28 09:49:55 --> Output Class Initialized
INFO - 2025-01-28 09:49:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:49:55 --> Input Class Initialized
INFO - 2025-01-28 09:49:55 --> Language Class Initialized
INFO - 2025-01-28 09:49:55 --> Loader Class Initialized
INFO - 2025-01-28 09:49:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:49:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:49:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:49:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:49:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:49:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:49:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:49:55 --> Upload Class Initialized
INFO - 2025-01-28 09:49:55 --> Email Class Initialized
INFO - 2025-01-28 09:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:49:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:49:55 --> Controller Class Initialized
INFO - 2025-01-28 15:19:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:19:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:19:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:50:50 --> Config Class Initialized
INFO - 2025-01-28 09:50:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:50:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:50:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:50:50 --> URI Class Initialized
INFO - 2025-01-28 09:50:50 --> Router Class Initialized
INFO - 2025-01-28 09:50:50 --> Output Class Initialized
INFO - 2025-01-28 09:50:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:50:50 --> Input Class Initialized
INFO - 2025-01-28 09:50:50 --> Language Class Initialized
INFO - 2025-01-28 09:50:50 --> Loader Class Initialized
INFO - 2025-01-28 09:50:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:50:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:50:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:50:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:50:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:50:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:50:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:50:50 --> Upload Class Initialized
INFO - 2025-01-28 09:50:50 --> Email Class Initialized
INFO - 2025-01-28 09:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:50:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:50:50 --> Controller Class Initialized
INFO - 2025-01-28 15:20:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:20:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:20:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:07 --> Config Class Initialized
INFO - 2025-01-28 09:51:07 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:07 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:07 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:07 --> URI Class Initialized
INFO - 2025-01-28 09:51:07 --> Router Class Initialized
INFO - 2025-01-28 09:51:07 --> Output Class Initialized
INFO - 2025-01-28 09:51:07 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:07 --> Input Class Initialized
INFO - 2025-01-28 09:51:07 --> Language Class Initialized
INFO - 2025-01-28 09:51:07 --> Loader Class Initialized
INFO - 2025-01-28 09:51:07 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:07 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:07 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:07 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:07 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:07 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:07 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:07 --> Upload Class Initialized
INFO - 2025-01-28 09:51:07 --> Email Class Initialized
INFO - 2025-01-28 09:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:07 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:07 --> Controller Class Initialized
INFO - 2025-01-28 15:21:07 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:07 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:07 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:10 --> Config Class Initialized
INFO - 2025-01-28 09:51:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:10 --> URI Class Initialized
INFO - 2025-01-28 09:51:10 --> Router Class Initialized
INFO - 2025-01-28 09:51:10 --> Output Class Initialized
INFO - 2025-01-28 09:51:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:10 --> Input Class Initialized
INFO - 2025-01-28 09:51:10 --> Language Class Initialized
INFO - 2025-01-28 09:51:10 --> Loader Class Initialized
INFO - 2025-01-28 09:51:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:10 --> Upload Class Initialized
INFO - 2025-01-28 09:51:10 --> Email Class Initialized
INFO - 2025-01-28 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:10 --> Controller Class Initialized
INFO - 2025-01-28 15:21:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:15 --> Config Class Initialized
INFO - 2025-01-28 09:51:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:15 --> URI Class Initialized
INFO - 2025-01-28 09:51:15 --> Router Class Initialized
INFO - 2025-01-28 09:51:15 --> Output Class Initialized
INFO - 2025-01-28 09:51:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:15 --> Input Class Initialized
INFO - 2025-01-28 09:51:15 --> Language Class Initialized
INFO - 2025-01-28 09:51:15 --> Loader Class Initialized
INFO - 2025-01-28 09:51:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:15 --> Upload Class Initialized
INFO - 2025-01-28 09:51:15 --> Email Class Initialized
INFO - 2025-01-28 09:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:15 --> Controller Class Initialized
INFO - 2025-01-28 15:21:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:20 --> Config Class Initialized
INFO - 2025-01-28 09:51:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:20 --> URI Class Initialized
INFO - 2025-01-28 09:51:20 --> Router Class Initialized
INFO - 2025-01-28 09:51:20 --> Output Class Initialized
INFO - 2025-01-28 09:51:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:20 --> Input Class Initialized
INFO - 2025-01-28 09:51:20 --> Language Class Initialized
INFO - 2025-01-28 09:51:20 --> Loader Class Initialized
INFO - 2025-01-28 09:51:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:20 --> Upload Class Initialized
INFO - 2025-01-28 09:51:20 --> Email Class Initialized
INFO - 2025-01-28 09:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:20 --> Controller Class Initialized
INFO - 2025-01-28 15:21:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:25 --> Config Class Initialized
INFO - 2025-01-28 09:51:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:25 --> URI Class Initialized
INFO - 2025-01-28 09:51:25 --> Router Class Initialized
INFO - 2025-01-28 09:51:25 --> Output Class Initialized
INFO - 2025-01-28 09:51:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:25 --> Input Class Initialized
INFO - 2025-01-28 09:51:25 --> Language Class Initialized
INFO - 2025-01-28 09:51:25 --> Loader Class Initialized
INFO - 2025-01-28 09:51:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:25 --> Upload Class Initialized
INFO - 2025-01-28 09:51:25 --> Email Class Initialized
INFO - 2025-01-28 09:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:25 --> Controller Class Initialized
INFO - 2025-01-28 15:21:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:30 --> Config Class Initialized
INFO - 2025-01-28 09:51:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:30 --> URI Class Initialized
INFO - 2025-01-28 09:51:30 --> Router Class Initialized
INFO - 2025-01-28 09:51:30 --> Output Class Initialized
INFO - 2025-01-28 09:51:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:30 --> Input Class Initialized
INFO - 2025-01-28 09:51:30 --> Language Class Initialized
INFO - 2025-01-28 09:51:30 --> Loader Class Initialized
INFO - 2025-01-28 09:51:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:30 --> Upload Class Initialized
INFO - 2025-01-28 09:51:30 --> Email Class Initialized
INFO - 2025-01-28 09:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:30 --> Controller Class Initialized
INFO - 2025-01-28 15:21:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:35 --> Config Class Initialized
INFO - 2025-01-28 09:51:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:35 --> URI Class Initialized
INFO - 2025-01-28 09:51:35 --> Router Class Initialized
INFO - 2025-01-28 09:51:35 --> Output Class Initialized
INFO - 2025-01-28 09:51:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:35 --> Input Class Initialized
INFO - 2025-01-28 09:51:35 --> Language Class Initialized
INFO - 2025-01-28 09:51:35 --> Loader Class Initialized
INFO - 2025-01-28 09:51:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:35 --> Upload Class Initialized
INFO - 2025-01-28 09:51:35 --> Email Class Initialized
INFO - 2025-01-28 09:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:35 --> Controller Class Initialized
INFO - 2025-01-28 15:21:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:40 --> Config Class Initialized
INFO - 2025-01-28 09:51:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:40 --> URI Class Initialized
INFO - 2025-01-28 09:51:40 --> Router Class Initialized
INFO - 2025-01-28 09:51:40 --> Output Class Initialized
INFO - 2025-01-28 09:51:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:40 --> Input Class Initialized
INFO - 2025-01-28 09:51:40 --> Language Class Initialized
INFO - 2025-01-28 09:51:40 --> Loader Class Initialized
INFO - 2025-01-28 09:51:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:40 --> Upload Class Initialized
INFO - 2025-01-28 09:51:40 --> Email Class Initialized
INFO - 2025-01-28 09:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:40 --> Controller Class Initialized
INFO - 2025-01-28 15:21:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:45 --> Config Class Initialized
INFO - 2025-01-28 09:51:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:45 --> URI Class Initialized
INFO - 2025-01-28 09:51:45 --> Router Class Initialized
INFO - 2025-01-28 09:51:45 --> Output Class Initialized
INFO - 2025-01-28 09:51:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:45 --> Input Class Initialized
INFO - 2025-01-28 09:51:45 --> Language Class Initialized
INFO - 2025-01-28 09:51:45 --> Loader Class Initialized
INFO - 2025-01-28 09:51:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:45 --> Upload Class Initialized
INFO - 2025-01-28 09:51:45 --> Email Class Initialized
INFO - 2025-01-28 09:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:45 --> Controller Class Initialized
INFO - 2025-01-28 15:21:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:50 --> Config Class Initialized
INFO - 2025-01-28 09:51:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:50 --> URI Class Initialized
INFO - 2025-01-28 09:51:50 --> Router Class Initialized
INFO - 2025-01-28 09:51:50 --> Output Class Initialized
INFO - 2025-01-28 09:51:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:50 --> Input Class Initialized
INFO - 2025-01-28 09:51:50 --> Language Class Initialized
INFO - 2025-01-28 09:51:50 --> Loader Class Initialized
INFO - 2025-01-28 09:51:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:50 --> Upload Class Initialized
INFO - 2025-01-28 09:51:50 --> Email Class Initialized
INFO - 2025-01-28 09:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:50 --> Controller Class Initialized
INFO - 2025-01-28 15:21:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:51:55 --> Config Class Initialized
INFO - 2025-01-28 09:51:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:51:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:51:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:51:55 --> URI Class Initialized
INFO - 2025-01-28 09:51:55 --> Router Class Initialized
INFO - 2025-01-28 09:51:55 --> Output Class Initialized
INFO - 2025-01-28 09:51:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:51:55 --> Input Class Initialized
INFO - 2025-01-28 09:51:55 --> Language Class Initialized
INFO - 2025-01-28 09:51:55 --> Loader Class Initialized
INFO - 2025-01-28 09:51:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:51:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:51:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:51:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:51:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:51:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:51:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:51:55 --> Upload Class Initialized
INFO - 2025-01-28 09:51:55 --> Email Class Initialized
INFO - 2025-01-28 09:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:51:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:51:55 --> Controller Class Initialized
INFO - 2025-01-28 15:21:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:21:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:21:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:52:00 --> Config Class Initialized
INFO - 2025-01-28 09:52:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:52:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:52:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:52:00 --> URI Class Initialized
INFO - 2025-01-28 09:52:00 --> Router Class Initialized
INFO - 2025-01-28 09:52:00 --> Output Class Initialized
INFO - 2025-01-28 09:52:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:52:00 --> Input Class Initialized
INFO - 2025-01-28 09:52:00 --> Language Class Initialized
INFO - 2025-01-28 09:52:00 --> Loader Class Initialized
INFO - 2025-01-28 09:52:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:52:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:52:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:52:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:52:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:52:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:52:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:52:00 --> Upload Class Initialized
INFO - 2025-01-28 09:52:00 --> Email Class Initialized
INFO - 2025-01-28 09:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:52:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:52:00 --> Controller Class Initialized
INFO - 2025-01-28 15:22:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:22:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:22:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:52:05 --> Config Class Initialized
INFO - 2025-01-28 09:52:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:52:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:52:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:52:05 --> URI Class Initialized
INFO - 2025-01-28 09:52:05 --> Router Class Initialized
INFO - 2025-01-28 09:52:05 --> Output Class Initialized
INFO - 2025-01-28 09:52:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:52:05 --> Input Class Initialized
INFO - 2025-01-28 09:52:05 --> Language Class Initialized
INFO - 2025-01-28 09:52:05 --> Loader Class Initialized
INFO - 2025-01-28 09:52:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:52:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:52:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:52:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:52:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:52:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:52:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:52:05 --> Upload Class Initialized
INFO - 2025-01-28 09:52:05 --> Email Class Initialized
INFO - 2025-01-28 09:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:52:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:52:05 --> Controller Class Initialized
INFO - 2025-01-28 15:22:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:22:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:22:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:52:50 --> Config Class Initialized
INFO - 2025-01-28 09:52:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:52:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:52:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:52:50 --> URI Class Initialized
INFO - 2025-01-28 09:52:50 --> Router Class Initialized
INFO - 2025-01-28 09:52:50 --> Output Class Initialized
INFO - 2025-01-28 09:52:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:52:50 --> Input Class Initialized
INFO - 2025-01-28 09:52:50 --> Language Class Initialized
INFO - 2025-01-28 09:52:50 --> Loader Class Initialized
INFO - 2025-01-28 09:52:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:52:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:52:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:52:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:52:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:52:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:52:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:52:50 --> Upload Class Initialized
INFO - 2025-01-28 09:52:50 --> Email Class Initialized
INFO - 2025-01-28 09:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:52:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:52:50 --> Controller Class Initialized
INFO - 2025-01-28 15:22:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:22:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:22:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:53:50 --> Config Class Initialized
INFO - 2025-01-28 09:53:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:53:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:53:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:53:50 --> URI Class Initialized
INFO - 2025-01-28 09:53:50 --> Router Class Initialized
INFO - 2025-01-28 09:53:50 --> Output Class Initialized
INFO - 2025-01-28 09:53:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:53:50 --> Input Class Initialized
INFO - 2025-01-28 09:53:50 --> Language Class Initialized
INFO - 2025-01-28 09:53:50 --> Loader Class Initialized
INFO - 2025-01-28 09:53:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:53:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:53:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:53:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:53:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:53:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:53:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:53:50 --> Upload Class Initialized
INFO - 2025-01-28 09:53:50 --> Email Class Initialized
INFO - 2025-01-28 09:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:53:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:53:50 --> Controller Class Initialized
INFO - 2025-01-28 15:23:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:23:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:23:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:53:56 --> Config Class Initialized
INFO - 2025-01-28 09:53:56 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:53:56 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:53:56 --> Utf8 Class Initialized
INFO - 2025-01-28 09:53:56 --> URI Class Initialized
INFO - 2025-01-28 09:53:56 --> Router Class Initialized
INFO - 2025-01-28 09:53:56 --> Output Class Initialized
INFO - 2025-01-28 09:53:56 --> Security Class Initialized
DEBUG - 2025-01-28 09:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:53:56 --> Input Class Initialized
INFO - 2025-01-28 09:53:56 --> Language Class Initialized
INFO - 2025-01-28 09:53:56 --> Loader Class Initialized
INFO - 2025-01-28 09:53:56 --> Helper loaded: url_helper
INFO - 2025-01-28 09:53:56 --> Helper loaded: html_helper
INFO - 2025-01-28 09:53:56 --> Helper loaded: file_helper
INFO - 2025-01-28 09:53:56 --> Helper loaded: string_helper
INFO - 2025-01-28 09:53:56 --> Helper loaded: form_helper
INFO - 2025-01-28 09:53:56 --> Helper loaded: my_helper
INFO - 2025-01-28 09:53:56 --> Database Driver Class Initialized
INFO - 2025-01-28 09:53:56 --> Upload Class Initialized
INFO - 2025-01-28 09:53:56 --> Email Class Initialized
INFO - 2025-01-28 09:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:53:56 --> Form Validation Class Initialized
INFO - 2025-01-28 09:53:56 --> Controller Class Initialized
INFO - 2025-01-28 15:23:56 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:23:56 --> Model "MainModel" initialized
INFO - 2025-01-28 15:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:23:56 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:00 --> Config Class Initialized
INFO - 2025-01-28 09:54:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:00 --> URI Class Initialized
INFO - 2025-01-28 09:54:00 --> Router Class Initialized
INFO - 2025-01-28 09:54:00 --> Output Class Initialized
INFO - 2025-01-28 09:54:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:00 --> Input Class Initialized
INFO - 2025-01-28 09:54:00 --> Language Class Initialized
INFO - 2025-01-28 09:54:00 --> Loader Class Initialized
INFO - 2025-01-28 09:54:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:00 --> Upload Class Initialized
INFO - 2025-01-28 09:54:00 --> Email Class Initialized
INFO - 2025-01-28 09:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:00 --> Controller Class Initialized
INFO - 2025-01-28 15:24:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:05 --> Config Class Initialized
INFO - 2025-01-28 09:54:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:05 --> URI Class Initialized
INFO - 2025-01-28 09:54:05 --> Router Class Initialized
INFO - 2025-01-28 09:54:05 --> Output Class Initialized
INFO - 2025-01-28 09:54:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:05 --> Input Class Initialized
INFO - 2025-01-28 09:54:05 --> Language Class Initialized
INFO - 2025-01-28 09:54:05 --> Loader Class Initialized
INFO - 2025-01-28 09:54:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:05 --> Upload Class Initialized
INFO - 2025-01-28 09:54:05 --> Email Class Initialized
INFO - 2025-01-28 09:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:05 --> Controller Class Initialized
INFO - 2025-01-28 15:24:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:10 --> Config Class Initialized
INFO - 2025-01-28 09:54:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:10 --> URI Class Initialized
INFO - 2025-01-28 09:54:10 --> Router Class Initialized
INFO - 2025-01-28 09:54:10 --> Output Class Initialized
INFO - 2025-01-28 09:54:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:10 --> Input Class Initialized
INFO - 2025-01-28 09:54:10 --> Language Class Initialized
INFO - 2025-01-28 09:54:10 --> Loader Class Initialized
INFO - 2025-01-28 09:54:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:10 --> Upload Class Initialized
INFO - 2025-01-28 09:54:10 --> Email Class Initialized
INFO - 2025-01-28 09:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:10 --> Controller Class Initialized
INFO - 2025-01-28 15:24:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:15 --> Config Class Initialized
INFO - 2025-01-28 09:54:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:15 --> URI Class Initialized
INFO - 2025-01-28 09:54:15 --> Router Class Initialized
INFO - 2025-01-28 09:54:15 --> Output Class Initialized
INFO - 2025-01-28 09:54:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:15 --> Input Class Initialized
INFO - 2025-01-28 09:54:15 --> Language Class Initialized
INFO - 2025-01-28 09:54:15 --> Loader Class Initialized
INFO - 2025-01-28 09:54:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:15 --> Upload Class Initialized
INFO - 2025-01-28 09:54:15 --> Email Class Initialized
INFO - 2025-01-28 09:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:15 --> Controller Class Initialized
INFO - 2025-01-28 15:24:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:20 --> Config Class Initialized
INFO - 2025-01-28 09:54:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:20 --> URI Class Initialized
INFO - 2025-01-28 09:54:20 --> Router Class Initialized
INFO - 2025-01-28 09:54:20 --> Output Class Initialized
INFO - 2025-01-28 09:54:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:20 --> Input Class Initialized
INFO - 2025-01-28 09:54:20 --> Language Class Initialized
INFO - 2025-01-28 09:54:20 --> Loader Class Initialized
INFO - 2025-01-28 09:54:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:20 --> Upload Class Initialized
INFO - 2025-01-28 09:54:20 --> Email Class Initialized
INFO - 2025-01-28 09:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:20 --> Controller Class Initialized
INFO - 2025-01-28 15:24:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:25 --> Config Class Initialized
INFO - 2025-01-28 09:54:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:25 --> URI Class Initialized
INFO - 2025-01-28 09:54:25 --> Router Class Initialized
INFO - 2025-01-28 09:54:25 --> Output Class Initialized
INFO - 2025-01-28 09:54:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:25 --> Input Class Initialized
INFO - 2025-01-28 09:54:25 --> Language Class Initialized
INFO - 2025-01-28 09:54:25 --> Loader Class Initialized
INFO - 2025-01-28 09:54:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:25 --> Upload Class Initialized
INFO - 2025-01-28 09:54:25 --> Email Class Initialized
INFO - 2025-01-28 09:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:25 --> Controller Class Initialized
INFO - 2025-01-28 15:24:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:30 --> Config Class Initialized
INFO - 2025-01-28 09:54:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:30 --> URI Class Initialized
INFO - 2025-01-28 09:54:30 --> Router Class Initialized
INFO - 2025-01-28 09:54:30 --> Output Class Initialized
INFO - 2025-01-28 09:54:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:30 --> Input Class Initialized
INFO - 2025-01-28 09:54:30 --> Language Class Initialized
INFO - 2025-01-28 09:54:30 --> Loader Class Initialized
INFO - 2025-01-28 09:54:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:30 --> Upload Class Initialized
INFO - 2025-01-28 09:54:30 --> Email Class Initialized
INFO - 2025-01-28 09:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:30 --> Controller Class Initialized
INFO - 2025-01-28 15:24:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:35 --> Config Class Initialized
INFO - 2025-01-28 09:54:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:35 --> URI Class Initialized
INFO - 2025-01-28 09:54:35 --> Router Class Initialized
INFO - 2025-01-28 09:54:35 --> Output Class Initialized
INFO - 2025-01-28 09:54:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:35 --> Input Class Initialized
INFO - 2025-01-28 09:54:35 --> Language Class Initialized
INFO - 2025-01-28 09:54:35 --> Loader Class Initialized
INFO - 2025-01-28 09:54:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:35 --> Upload Class Initialized
INFO - 2025-01-28 09:54:35 --> Email Class Initialized
INFO - 2025-01-28 09:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:35 --> Controller Class Initialized
INFO - 2025-01-28 15:24:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:40 --> Config Class Initialized
INFO - 2025-01-28 09:54:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:40 --> URI Class Initialized
INFO - 2025-01-28 09:54:40 --> Router Class Initialized
INFO - 2025-01-28 09:54:40 --> Output Class Initialized
INFO - 2025-01-28 09:54:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:40 --> Input Class Initialized
INFO - 2025-01-28 09:54:40 --> Language Class Initialized
INFO - 2025-01-28 09:54:40 --> Loader Class Initialized
INFO - 2025-01-28 09:54:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:40 --> Upload Class Initialized
INFO - 2025-01-28 09:54:40 --> Email Class Initialized
INFO - 2025-01-28 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:40 --> Controller Class Initialized
INFO - 2025-01-28 15:24:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:45 --> Config Class Initialized
INFO - 2025-01-28 09:54:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:45 --> URI Class Initialized
INFO - 2025-01-28 09:54:45 --> Router Class Initialized
INFO - 2025-01-28 09:54:45 --> Output Class Initialized
INFO - 2025-01-28 09:54:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:45 --> Input Class Initialized
INFO - 2025-01-28 09:54:45 --> Language Class Initialized
INFO - 2025-01-28 09:54:45 --> Loader Class Initialized
INFO - 2025-01-28 09:54:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:45 --> Upload Class Initialized
INFO - 2025-01-28 09:54:45 --> Email Class Initialized
INFO - 2025-01-28 09:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:45 --> Controller Class Initialized
INFO - 2025-01-28 15:24:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:50 --> Config Class Initialized
INFO - 2025-01-28 09:54:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:50 --> URI Class Initialized
INFO - 2025-01-28 09:54:50 --> Router Class Initialized
INFO - 2025-01-28 09:54:50 --> Output Class Initialized
INFO - 2025-01-28 09:54:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:50 --> Input Class Initialized
INFO - 2025-01-28 09:54:50 --> Language Class Initialized
INFO - 2025-01-28 09:54:50 --> Loader Class Initialized
INFO - 2025-01-28 09:54:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:50 --> Upload Class Initialized
INFO - 2025-01-28 09:54:50 --> Email Class Initialized
INFO - 2025-01-28 09:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:50 --> Controller Class Initialized
INFO - 2025-01-28 15:24:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:55 --> Config Class Initialized
INFO - 2025-01-28 09:54:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:55 --> URI Class Initialized
INFO - 2025-01-28 09:54:55 --> Router Class Initialized
INFO - 2025-01-28 09:54:55 --> Output Class Initialized
INFO - 2025-01-28 09:54:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:55 --> Input Class Initialized
INFO - 2025-01-28 09:54:55 --> Language Class Initialized
INFO - 2025-01-28 09:54:55 --> Loader Class Initialized
INFO - 2025-01-28 09:54:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:54:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:54:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:54:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:54:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:54:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:54:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:54:55 --> Upload Class Initialized
INFO - 2025-01-28 09:54:55 --> Email Class Initialized
INFO - 2025-01-28 09:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:54:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:54:55 --> Controller Class Initialized
INFO - 2025-01-28 15:24:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:24:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:24:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:54:57 --> Config Class Initialized
INFO - 2025-01-28 09:54:57 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:54:57 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:54:57 --> Utf8 Class Initialized
INFO - 2025-01-28 09:54:57 --> URI Class Initialized
INFO - 2025-01-28 09:54:57 --> Router Class Initialized
INFO - 2025-01-28 09:54:57 --> Output Class Initialized
INFO - 2025-01-28 09:54:57 --> Security Class Initialized
DEBUG - 2025-01-28 09:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:54:57 --> Input Class Initialized
INFO - 2025-01-28 09:54:57 --> Language Class Initialized
ERROR - 2025-01-28 09:54:57 --> 404 Page Not Found: Page_login/index
INFO - 2025-01-28 09:55:00 --> Config Class Initialized
INFO - 2025-01-28 09:55:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:00 --> URI Class Initialized
INFO - 2025-01-28 09:55:00 --> Router Class Initialized
INFO - 2025-01-28 09:55:00 --> Output Class Initialized
INFO - 2025-01-28 09:55:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:00 --> Input Class Initialized
INFO - 2025-01-28 09:55:00 --> Language Class Initialized
INFO - 2025-01-28 09:55:00 --> Loader Class Initialized
INFO - 2025-01-28 09:55:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:00 --> Upload Class Initialized
INFO - 2025-01-28 09:55:00 --> Email Class Initialized
INFO - 2025-01-28 09:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:00 --> Controller Class Initialized
INFO - 2025-01-28 15:25:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:05 --> Config Class Initialized
INFO - 2025-01-28 09:55:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:05 --> URI Class Initialized
INFO - 2025-01-28 09:55:05 --> Router Class Initialized
INFO - 2025-01-28 09:55:05 --> Output Class Initialized
INFO - 2025-01-28 09:55:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:05 --> Input Class Initialized
INFO - 2025-01-28 09:55:05 --> Language Class Initialized
INFO - 2025-01-28 09:55:05 --> Loader Class Initialized
INFO - 2025-01-28 09:55:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:05 --> Upload Class Initialized
INFO - 2025-01-28 09:55:05 --> Email Class Initialized
INFO - 2025-01-28 09:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:05 --> Controller Class Initialized
INFO - 2025-01-28 15:25:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:08 --> Config Class Initialized
INFO - 2025-01-28 09:55:08 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:08 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:08 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:08 --> URI Class Initialized
INFO - 2025-01-28 09:55:08 --> Router Class Initialized
INFO - 2025-01-28 09:55:08 --> Output Class Initialized
INFO - 2025-01-28 09:55:08 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:08 --> Input Class Initialized
INFO - 2025-01-28 09:55:08 --> Language Class Initialized
ERROR - 2025-01-28 09:55:08 --> 404 Page Not Found: Page_login/index
INFO - 2025-01-28 09:55:10 --> Config Class Initialized
INFO - 2025-01-28 09:55:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:10 --> URI Class Initialized
INFO - 2025-01-28 09:55:10 --> Router Class Initialized
INFO - 2025-01-28 09:55:10 --> Output Class Initialized
INFO - 2025-01-28 09:55:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:10 --> Input Class Initialized
INFO - 2025-01-28 09:55:10 --> Language Class Initialized
INFO - 2025-01-28 09:55:10 --> Loader Class Initialized
INFO - 2025-01-28 09:55:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:10 --> Upload Class Initialized
INFO - 2025-01-28 09:55:10 --> Email Class Initialized
INFO - 2025-01-28 09:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:10 --> Controller Class Initialized
INFO - 2025-01-28 15:25:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:15 --> Config Class Initialized
INFO - 2025-01-28 09:55:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:15 --> URI Class Initialized
INFO - 2025-01-28 09:55:15 --> Router Class Initialized
INFO - 2025-01-28 09:55:15 --> Output Class Initialized
INFO - 2025-01-28 09:55:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:15 --> Input Class Initialized
INFO - 2025-01-28 09:55:15 --> Language Class Initialized
INFO - 2025-01-28 09:55:15 --> Loader Class Initialized
INFO - 2025-01-28 09:55:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:15 --> Upload Class Initialized
INFO - 2025-01-28 09:55:15 --> Email Class Initialized
INFO - 2025-01-28 09:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:15 --> Controller Class Initialized
INFO - 2025-01-28 15:25:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:20 --> Config Class Initialized
INFO - 2025-01-28 09:55:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:20 --> URI Class Initialized
INFO - 2025-01-28 09:55:20 --> Router Class Initialized
INFO - 2025-01-28 09:55:20 --> Output Class Initialized
INFO - 2025-01-28 09:55:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:20 --> Input Class Initialized
INFO - 2025-01-28 09:55:20 --> Language Class Initialized
INFO - 2025-01-28 09:55:20 --> Loader Class Initialized
INFO - 2025-01-28 09:55:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:20 --> Upload Class Initialized
INFO - 2025-01-28 09:55:20 --> Email Class Initialized
INFO - 2025-01-28 09:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:20 --> Controller Class Initialized
INFO - 2025-01-28 15:25:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:25 --> Config Class Initialized
INFO - 2025-01-28 09:55:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:25 --> URI Class Initialized
INFO - 2025-01-28 09:55:25 --> Router Class Initialized
INFO - 2025-01-28 09:55:25 --> Output Class Initialized
INFO - 2025-01-28 09:55:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:25 --> Input Class Initialized
INFO - 2025-01-28 09:55:25 --> Language Class Initialized
INFO - 2025-01-28 09:55:25 --> Loader Class Initialized
INFO - 2025-01-28 09:55:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:25 --> Upload Class Initialized
INFO - 2025-01-28 09:55:25 --> Email Class Initialized
INFO - 2025-01-28 09:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:25 --> Controller Class Initialized
INFO - 2025-01-28 15:25:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:30 --> Config Class Initialized
INFO - 2025-01-28 09:55:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:30 --> URI Class Initialized
INFO - 2025-01-28 09:55:30 --> Router Class Initialized
INFO - 2025-01-28 09:55:30 --> Output Class Initialized
INFO - 2025-01-28 09:55:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:30 --> Input Class Initialized
INFO - 2025-01-28 09:55:30 --> Language Class Initialized
INFO - 2025-01-28 09:55:30 --> Loader Class Initialized
INFO - 2025-01-28 09:55:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:30 --> Upload Class Initialized
INFO - 2025-01-28 09:55:30 --> Email Class Initialized
INFO - 2025-01-28 09:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:30 --> Controller Class Initialized
INFO - 2025-01-28 15:25:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:35 --> Config Class Initialized
INFO - 2025-01-28 09:55:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:35 --> URI Class Initialized
INFO - 2025-01-28 09:55:35 --> Router Class Initialized
INFO - 2025-01-28 09:55:35 --> Output Class Initialized
INFO - 2025-01-28 09:55:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:35 --> Input Class Initialized
INFO - 2025-01-28 09:55:35 --> Language Class Initialized
INFO - 2025-01-28 09:55:35 --> Loader Class Initialized
INFO - 2025-01-28 09:55:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:35 --> Upload Class Initialized
INFO - 2025-01-28 09:55:35 --> Email Class Initialized
INFO - 2025-01-28 09:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:35 --> Controller Class Initialized
INFO - 2025-01-28 15:25:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:40 --> Config Class Initialized
INFO - 2025-01-28 09:55:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:40 --> URI Class Initialized
INFO - 2025-01-28 09:55:40 --> Router Class Initialized
INFO - 2025-01-28 09:55:40 --> Output Class Initialized
INFO - 2025-01-28 09:55:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:40 --> Input Class Initialized
INFO - 2025-01-28 09:55:40 --> Language Class Initialized
INFO - 2025-01-28 09:55:40 --> Loader Class Initialized
INFO - 2025-01-28 09:55:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:40 --> Upload Class Initialized
INFO - 2025-01-28 09:55:40 --> Email Class Initialized
INFO - 2025-01-28 09:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:40 --> Controller Class Initialized
INFO - 2025-01-28 15:25:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:45 --> Config Class Initialized
INFO - 2025-01-28 09:55:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:45 --> URI Class Initialized
INFO - 2025-01-28 09:55:45 --> Router Class Initialized
INFO - 2025-01-28 09:55:45 --> Output Class Initialized
INFO - 2025-01-28 09:55:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:45 --> Input Class Initialized
INFO - 2025-01-28 09:55:45 --> Language Class Initialized
INFO - 2025-01-28 09:55:45 --> Loader Class Initialized
INFO - 2025-01-28 09:55:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:45 --> Upload Class Initialized
INFO - 2025-01-28 09:55:45 --> Email Class Initialized
INFO - 2025-01-28 09:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:45 --> Controller Class Initialized
INFO - 2025-01-28 15:25:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:50 --> Config Class Initialized
INFO - 2025-01-28 09:55:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:50 --> URI Class Initialized
INFO - 2025-01-28 09:55:50 --> Router Class Initialized
INFO - 2025-01-28 09:55:50 --> Output Class Initialized
INFO - 2025-01-28 09:55:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:50 --> Input Class Initialized
INFO - 2025-01-28 09:55:50 --> Language Class Initialized
INFO - 2025-01-28 09:55:50 --> Loader Class Initialized
INFO - 2025-01-28 09:55:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:50 --> Upload Class Initialized
INFO - 2025-01-28 09:55:50 --> Email Class Initialized
INFO - 2025-01-28 09:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:50 --> Controller Class Initialized
INFO - 2025-01-28 15:25:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:55:55 --> Config Class Initialized
INFO - 2025-01-28 09:55:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:55:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:55:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:55:55 --> URI Class Initialized
INFO - 2025-01-28 09:55:55 --> Router Class Initialized
INFO - 2025-01-28 09:55:55 --> Output Class Initialized
INFO - 2025-01-28 09:55:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:55:55 --> Input Class Initialized
INFO - 2025-01-28 09:55:55 --> Language Class Initialized
INFO - 2025-01-28 09:55:55 --> Loader Class Initialized
INFO - 2025-01-28 09:55:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:55:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:55:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:55:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:55:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:55:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:55:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:55:55 --> Upload Class Initialized
INFO - 2025-01-28 09:55:55 --> Email Class Initialized
INFO - 2025-01-28 09:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:55:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:55:55 --> Controller Class Initialized
INFO - 2025-01-28 15:25:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:25:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:25:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:00 --> Config Class Initialized
INFO - 2025-01-28 09:56:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:00 --> URI Class Initialized
INFO - 2025-01-28 09:56:00 --> Router Class Initialized
INFO - 2025-01-28 09:56:00 --> Output Class Initialized
INFO - 2025-01-28 09:56:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:00 --> Input Class Initialized
INFO - 2025-01-28 09:56:00 --> Language Class Initialized
INFO - 2025-01-28 09:56:00 --> Loader Class Initialized
INFO - 2025-01-28 09:56:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:00 --> Upload Class Initialized
INFO - 2025-01-28 09:56:00 --> Email Class Initialized
INFO - 2025-01-28 09:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:00 --> Controller Class Initialized
INFO - 2025-01-28 15:26:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:05 --> Config Class Initialized
INFO - 2025-01-28 09:56:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:05 --> URI Class Initialized
INFO - 2025-01-28 09:56:05 --> Router Class Initialized
INFO - 2025-01-28 09:56:05 --> Output Class Initialized
INFO - 2025-01-28 09:56:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:05 --> Input Class Initialized
INFO - 2025-01-28 09:56:05 --> Language Class Initialized
INFO - 2025-01-28 09:56:05 --> Loader Class Initialized
INFO - 2025-01-28 09:56:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:05 --> Upload Class Initialized
INFO - 2025-01-28 09:56:05 --> Email Class Initialized
INFO - 2025-01-28 09:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:05 --> Controller Class Initialized
INFO - 2025-01-28 15:26:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:10 --> Config Class Initialized
INFO - 2025-01-28 09:56:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:10 --> URI Class Initialized
INFO - 2025-01-28 09:56:10 --> Router Class Initialized
INFO - 2025-01-28 09:56:10 --> Output Class Initialized
INFO - 2025-01-28 09:56:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:10 --> Input Class Initialized
INFO - 2025-01-28 09:56:10 --> Language Class Initialized
INFO - 2025-01-28 09:56:10 --> Loader Class Initialized
INFO - 2025-01-28 09:56:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:10 --> Upload Class Initialized
INFO - 2025-01-28 09:56:10 --> Email Class Initialized
INFO - 2025-01-28 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:10 --> Controller Class Initialized
INFO - 2025-01-28 15:26:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:15 --> Config Class Initialized
INFO - 2025-01-28 09:56:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:15 --> URI Class Initialized
INFO - 2025-01-28 09:56:15 --> Router Class Initialized
INFO - 2025-01-28 09:56:15 --> Output Class Initialized
INFO - 2025-01-28 09:56:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:15 --> Input Class Initialized
INFO - 2025-01-28 09:56:15 --> Language Class Initialized
INFO - 2025-01-28 09:56:15 --> Loader Class Initialized
INFO - 2025-01-28 09:56:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:15 --> Upload Class Initialized
INFO - 2025-01-28 09:56:15 --> Email Class Initialized
INFO - 2025-01-28 09:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:15 --> Controller Class Initialized
INFO - 2025-01-28 15:26:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:20 --> Config Class Initialized
INFO - 2025-01-28 09:56:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:20 --> URI Class Initialized
INFO - 2025-01-28 09:56:20 --> Router Class Initialized
INFO - 2025-01-28 09:56:20 --> Output Class Initialized
INFO - 2025-01-28 09:56:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:20 --> Input Class Initialized
INFO - 2025-01-28 09:56:20 --> Language Class Initialized
INFO - 2025-01-28 09:56:20 --> Loader Class Initialized
INFO - 2025-01-28 09:56:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:20 --> Upload Class Initialized
INFO - 2025-01-28 09:56:20 --> Email Class Initialized
INFO - 2025-01-28 09:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:20 --> Controller Class Initialized
INFO - 2025-01-28 15:26:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:25 --> Config Class Initialized
INFO - 2025-01-28 09:56:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:25 --> URI Class Initialized
INFO - 2025-01-28 09:56:25 --> Router Class Initialized
INFO - 2025-01-28 09:56:25 --> Output Class Initialized
INFO - 2025-01-28 09:56:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:25 --> Input Class Initialized
INFO - 2025-01-28 09:56:25 --> Language Class Initialized
INFO - 2025-01-28 09:56:25 --> Loader Class Initialized
INFO - 2025-01-28 09:56:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:25 --> Upload Class Initialized
INFO - 2025-01-28 09:56:25 --> Email Class Initialized
INFO - 2025-01-28 09:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:25 --> Controller Class Initialized
INFO - 2025-01-28 15:26:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:30 --> Config Class Initialized
INFO - 2025-01-28 09:56:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:30 --> URI Class Initialized
INFO - 2025-01-28 09:56:30 --> Router Class Initialized
INFO - 2025-01-28 09:56:30 --> Output Class Initialized
INFO - 2025-01-28 09:56:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:30 --> Input Class Initialized
INFO - 2025-01-28 09:56:30 --> Language Class Initialized
INFO - 2025-01-28 09:56:30 --> Loader Class Initialized
INFO - 2025-01-28 09:56:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:30 --> Upload Class Initialized
INFO - 2025-01-28 09:56:30 --> Email Class Initialized
INFO - 2025-01-28 09:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:30 --> Controller Class Initialized
INFO - 2025-01-28 15:26:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:35 --> Config Class Initialized
INFO - 2025-01-28 09:56:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:35 --> URI Class Initialized
INFO - 2025-01-28 09:56:35 --> Router Class Initialized
INFO - 2025-01-28 09:56:35 --> Output Class Initialized
INFO - 2025-01-28 09:56:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:35 --> Input Class Initialized
INFO - 2025-01-28 09:56:35 --> Language Class Initialized
INFO - 2025-01-28 09:56:35 --> Loader Class Initialized
INFO - 2025-01-28 09:56:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:35 --> Upload Class Initialized
INFO - 2025-01-28 09:56:35 --> Email Class Initialized
INFO - 2025-01-28 09:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:35 --> Controller Class Initialized
INFO - 2025-01-28 15:26:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:40 --> Config Class Initialized
INFO - 2025-01-28 09:56:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:40 --> URI Class Initialized
INFO - 2025-01-28 09:56:40 --> Router Class Initialized
INFO - 2025-01-28 09:56:40 --> Output Class Initialized
INFO - 2025-01-28 09:56:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:40 --> Input Class Initialized
INFO - 2025-01-28 09:56:40 --> Language Class Initialized
INFO - 2025-01-28 09:56:40 --> Loader Class Initialized
INFO - 2025-01-28 09:56:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:40 --> Upload Class Initialized
INFO - 2025-01-28 09:56:40 --> Email Class Initialized
INFO - 2025-01-28 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:40 --> Controller Class Initialized
INFO - 2025-01-28 15:26:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:45 --> Config Class Initialized
INFO - 2025-01-28 09:56:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:45 --> URI Class Initialized
INFO - 2025-01-28 09:56:45 --> Router Class Initialized
INFO - 2025-01-28 09:56:45 --> Output Class Initialized
INFO - 2025-01-28 09:56:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:45 --> Input Class Initialized
INFO - 2025-01-28 09:56:45 --> Language Class Initialized
INFO - 2025-01-28 09:56:45 --> Loader Class Initialized
INFO - 2025-01-28 09:56:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:45 --> Upload Class Initialized
INFO - 2025-01-28 09:56:45 --> Email Class Initialized
INFO - 2025-01-28 09:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:45 --> Controller Class Initialized
INFO - 2025-01-28 15:26:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:50 --> Config Class Initialized
INFO - 2025-01-28 09:56:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:50 --> URI Class Initialized
INFO - 2025-01-28 09:56:50 --> Router Class Initialized
INFO - 2025-01-28 09:56:50 --> Output Class Initialized
INFO - 2025-01-28 09:56:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:50 --> Input Class Initialized
INFO - 2025-01-28 09:56:50 --> Language Class Initialized
INFO - 2025-01-28 09:56:50 --> Loader Class Initialized
INFO - 2025-01-28 09:56:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:50 --> Upload Class Initialized
INFO - 2025-01-28 09:56:50 --> Email Class Initialized
INFO - 2025-01-28 09:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:50 --> Controller Class Initialized
INFO - 2025-01-28 15:26:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:56:55 --> Config Class Initialized
INFO - 2025-01-28 09:56:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:56:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:56:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:56:55 --> URI Class Initialized
INFO - 2025-01-28 09:56:55 --> Router Class Initialized
INFO - 2025-01-28 09:56:55 --> Output Class Initialized
INFO - 2025-01-28 09:56:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:56:55 --> Input Class Initialized
INFO - 2025-01-28 09:56:55 --> Language Class Initialized
INFO - 2025-01-28 09:56:55 --> Loader Class Initialized
INFO - 2025-01-28 09:56:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:56:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:56:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:56:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:56:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:56:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:56:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:56:55 --> Upload Class Initialized
INFO - 2025-01-28 09:56:55 --> Email Class Initialized
INFO - 2025-01-28 09:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:56:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:56:55 --> Controller Class Initialized
INFO - 2025-01-28 15:26:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:26:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:26:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:00 --> Config Class Initialized
INFO - 2025-01-28 09:57:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:00 --> URI Class Initialized
INFO - 2025-01-28 09:57:00 --> Router Class Initialized
INFO - 2025-01-28 09:57:00 --> Output Class Initialized
INFO - 2025-01-28 09:57:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:00 --> Input Class Initialized
INFO - 2025-01-28 09:57:00 --> Language Class Initialized
INFO - 2025-01-28 09:57:00 --> Loader Class Initialized
INFO - 2025-01-28 09:57:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:00 --> Upload Class Initialized
INFO - 2025-01-28 09:57:00 --> Email Class Initialized
INFO - 2025-01-28 09:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:00 --> Controller Class Initialized
INFO - 2025-01-28 15:27:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:05 --> Config Class Initialized
INFO - 2025-01-28 09:57:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:05 --> URI Class Initialized
INFO - 2025-01-28 09:57:05 --> Router Class Initialized
INFO - 2025-01-28 09:57:05 --> Output Class Initialized
INFO - 2025-01-28 09:57:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:05 --> Input Class Initialized
INFO - 2025-01-28 09:57:05 --> Language Class Initialized
INFO - 2025-01-28 09:57:05 --> Loader Class Initialized
INFO - 2025-01-28 09:57:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:05 --> Upload Class Initialized
INFO - 2025-01-28 09:57:05 --> Email Class Initialized
INFO - 2025-01-28 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:05 --> Controller Class Initialized
INFO - 2025-01-28 15:27:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:10 --> Config Class Initialized
INFO - 2025-01-28 09:57:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:10 --> URI Class Initialized
INFO - 2025-01-28 09:57:10 --> Router Class Initialized
INFO - 2025-01-28 09:57:10 --> Output Class Initialized
INFO - 2025-01-28 09:57:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:10 --> Input Class Initialized
INFO - 2025-01-28 09:57:10 --> Language Class Initialized
INFO - 2025-01-28 09:57:10 --> Loader Class Initialized
INFO - 2025-01-28 09:57:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:10 --> Upload Class Initialized
INFO - 2025-01-28 09:57:10 --> Email Class Initialized
INFO - 2025-01-28 09:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:10 --> Controller Class Initialized
INFO - 2025-01-28 15:27:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:15 --> Config Class Initialized
INFO - 2025-01-28 09:57:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:15 --> URI Class Initialized
INFO - 2025-01-28 09:57:15 --> Router Class Initialized
INFO - 2025-01-28 09:57:15 --> Output Class Initialized
INFO - 2025-01-28 09:57:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:15 --> Input Class Initialized
INFO - 2025-01-28 09:57:15 --> Language Class Initialized
INFO - 2025-01-28 09:57:15 --> Loader Class Initialized
INFO - 2025-01-28 09:57:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:15 --> Upload Class Initialized
INFO - 2025-01-28 09:57:15 --> Email Class Initialized
INFO - 2025-01-28 09:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:15 --> Controller Class Initialized
INFO - 2025-01-28 15:27:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:20 --> Config Class Initialized
INFO - 2025-01-28 09:57:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:20 --> URI Class Initialized
INFO - 2025-01-28 09:57:20 --> Router Class Initialized
INFO - 2025-01-28 09:57:20 --> Output Class Initialized
INFO - 2025-01-28 09:57:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:20 --> Input Class Initialized
INFO - 2025-01-28 09:57:20 --> Language Class Initialized
INFO - 2025-01-28 09:57:20 --> Loader Class Initialized
INFO - 2025-01-28 09:57:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:20 --> Upload Class Initialized
INFO - 2025-01-28 09:57:20 --> Email Class Initialized
INFO - 2025-01-28 09:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:20 --> Controller Class Initialized
INFO - 2025-01-28 15:27:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:25 --> Config Class Initialized
INFO - 2025-01-28 09:57:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:25 --> URI Class Initialized
INFO - 2025-01-28 09:57:25 --> Router Class Initialized
INFO - 2025-01-28 09:57:25 --> Output Class Initialized
INFO - 2025-01-28 09:57:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:25 --> Input Class Initialized
INFO - 2025-01-28 09:57:25 --> Language Class Initialized
INFO - 2025-01-28 09:57:25 --> Loader Class Initialized
INFO - 2025-01-28 09:57:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:25 --> Upload Class Initialized
INFO - 2025-01-28 09:57:25 --> Email Class Initialized
INFO - 2025-01-28 09:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:25 --> Controller Class Initialized
INFO - 2025-01-28 15:27:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:30 --> Config Class Initialized
INFO - 2025-01-28 09:57:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:30 --> URI Class Initialized
INFO - 2025-01-28 09:57:30 --> Router Class Initialized
INFO - 2025-01-28 09:57:30 --> Output Class Initialized
INFO - 2025-01-28 09:57:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:30 --> Input Class Initialized
INFO - 2025-01-28 09:57:30 --> Language Class Initialized
INFO - 2025-01-28 09:57:30 --> Loader Class Initialized
INFO - 2025-01-28 09:57:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:30 --> Upload Class Initialized
INFO - 2025-01-28 09:57:30 --> Email Class Initialized
INFO - 2025-01-28 09:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:30 --> Controller Class Initialized
INFO - 2025-01-28 15:27:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:35 --> Config Class Initialized
INFO - 2025-01-28 09:57:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:35 --> URI Class Initialized
INFO - 2025-01-28 09:57:35 --> Router Class Initialized
INFO - 2025-01-28 09:57:35 --> Output Class Initialized
INFO - 2025-01-28 09:57:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:35 --> Input Class Initialized
INFO - 2025-01-28 09:57:35 --> Language Class Initialized
INFO - 2025-01-28 09:57:35 --> Loader Class Initialized
INFO - 2025-01-28 09:57:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:35 --> Upload Class Initialized
INFO - 2025-01-28 09:57:35 --> Email Class Initialized
INFO - 2025-01-28 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:35 --> Controller Class Initialized
INFO - 2025-01-28 15:27:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:40 --> Config Class Initialized
INFO - 2025-01-28 09:57:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:40 --> URI Class Initialized
INFO - 2025-01-28 09:57:40 --> Router Class Initialized
INFO - 2025-01-28 09:57:40 --> Output Class Initialized
INFO - 2025-01-28 09:57:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:40 --> Input Class Initialized
INFO - 2025-01-28 09:57:40 --> Language Class Initialized
INFO - 2025-01-28 09:57:40 --> Loader Class Initialized
INFO - 2025-01-28 09:57:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:40 --> Upload Class Initialized
INFO - 2025-01-28 09:57:40 --> Email Class Initialized
INFO - 2025-01-28 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:40 --> Controller Class Initialized
INFO - 2025-01-28 15:27:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:45 --> Config Class Initialized
INFO - 2025-01-28 09:57:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:45 --> URI Class Initialized
INFO - 2025-01-28 09:57:45 --> Router Class Initialized
INFO - 2025-01-28 09:57:45 --> Output Class Initialized
INFO - 2025-01-28 09:57:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:45 --> Input Class Initialized
INFO - 2025-01-28 09:57:45 --> Language Class Initialized
INFO - 2025-01-28 09:57:45 --> Loader Class Initialized
INFO - 2025-01-28 09:57:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:45 --> Upload Class Initialized
INFO - 2025-01-28 09:57:45 --> Email Class Initialized
INFO - 2025-01-28 09:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:45 --> Controller Class Initialized
INFO - 2025-01-28 15:27:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:50 --> Config Class Initialized
INFO - 2025-01-28 09:57:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:50 --> URI Class Initialized
INFO - 2025-01-28 09:57:50 --> Router Class Initialized
INFO - 2025-01-28 09:57:50 --> Output Class Initialized
INFO - 2025-01-28 09:57:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:50 --> Input Class Initialized
INFO - 2025-01-28 09:57:50 --> Language Class Initialized
INFO - 2025-01-28 09:57:50 --> Loader Class Initialized
INFO - 2025-01-28 09:57:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:50 --> Upload Class Initialized
INFO - 2025-01-28 09:57:50 --> Email Class Initialized
INFO - 2025-01-28 09:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:50 --> Controller Class Initialized
INFO - 2025-01-28 15:27:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:57:55 --> Config Class Initialized
INFO - 2025-01-28 09:57:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:57:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:57:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:57:55 --> URI Class Initialized
INFO - 2025-01-28 09:57:55 --> Router Class Initialized
INFO - 2025-01-28 09:57:55 --> Output Class Initialized
INFO - 2025-01-28 09:57:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:57:55 --> Input Class Initialized
INFO - 2025-01-28 09:57:55 --> Language Class Initialized
INFO - 2025-01-28 09:57:55 --> Loader Class Initialized
INFO - 2025-01-28 09:57:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:57:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:57:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:57:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:57:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:57:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:57:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:57:55 --> Upload Class Initialized
INFO - 2025-01-28 09:57:55 --> Email Class Initialized
INFO - 2025-01-28 09:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:57:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:57:55 --> Controller Class Initialized
INFO - 2025-01-28 15:27:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:27:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:27:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:27:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:00 --> Config Class Initialized
INFO - 2025-01-28 09:58:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:00 --> URI Class Initialized
INFO - 2025-01-28 09:58:00 --> Router Class Initialized
INFO - 2025-01-28 09:58:00 --> Output Class Initialized
INFO - 2025-01-28 09:58:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:00 --> Input Class Initialized
INFO - 2025-01-28 09:58:00 --> Language Class Initialized
INFO - 2025-01-28 09:58:00 --> Loader Class Initialized
INFO - 2025-01-28 09:58:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:00 --> Upload Class Initialized
INFO - 2025-01-28 09:58:00 --> Email Class Initialized
INFO - 2025-01-28 09:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:00 --> Controller Class Initialized
INFO - 2025-01-28 15:28:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:05 --> Config Class Initialized
INFO - 2025-01-28 09:58:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:05 --> URI Class Initialized
INFO - 2025-01-28 09:58:05 --> Router Class Initialized
INFO - 2025-01-28 09:58:05 --> Output Class Initialized
INFO - 2025-01-28 09:58:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:05 --> Input Class Initialized
INFO - 2025-01-28 09:58:05 --> Language Class Initialized
INFO - 2025-01-28 09:58:05 --> Loader Class Initialized
INFO - 2025-01-28 09:58:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:05 --> Upload Class Initialized
INFO - 2025-01-28 09:58:05 --> Email Class Initialized
INFO - 2025-01-28 09:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:05 --> Controller Class Initialized
INFO - 2025-01-28 15:28:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:10 --> Config Class Initialized
INFO - 2025-01-28 09:58:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:10 --> URI Class Initialized
INFO - 2025-01-28 09:58:10 --> Router Class Initialized
INFO - 2025-01-28 09:58:10 --> Output Class Initialized
INFO - 2025-01-28 09:58:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:10 --> Input Class Initialized
INFO - 2025-01-28 09:58:10 --> Language Class Initialized
INFO - 2025-01-28 09:58:10 --> Loader Class Initialized
INFO - 2025-01-28 09:58:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:10 --> Upload Class Initialized
INFO - 2025-01-28 09:58:10 --> Email Class Initialized
INFO - 2025-01-28 09:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:10 --> Controller Class Initialized
INFO - 2025-01-28 15:28:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:15 --> Config Class Initialized
INFO - 2025-01-28 09:58:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:15 --> URI Class Initialized
INFO - 2025-01-28 09:58:15 --> Router Class Initialized
INFO - 2025-01-28 09:58:15 --> Output Class Initialized
INFO - 2025-01-28 09:58:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:15 --> Input Class Initialized
INFO - 2025-01-28 09:58:15 --> Language Class Initialized
INFO - 2025-01-28 09:58:15 --> Loader Class Initialized
INFO - 2025-01-28 09:58:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:15 --> Upload Class Initialized
INFO - 2025-01-28 09:58:15 --> Email Class Initialized
INFO - 2025-01-28 09:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:15 --> Controller Class Initialized
INFO - 2025-01-28 15:28:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:20 --> Config Class Initialized
INFO - 2025-01-28 09:58:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:20 --> URI Class Initialized
INFO - 2025-01-28 09:58:20 --> Router Class Initialized
INFO - 2025-01-28 09:58:20 --> Output Class Initialized
INFO - 2025-01-28 09:58:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:20 --> Input Class Initialized
INFO - 2025-01-28 09:58:20 --> Language Class Initialized
INFO - 2025-01-28 09:58:20 --> Loader Class Initialized
INFO - 2025-01-28 09:58:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:20 --> Upload Class Initialized
INFO - 2025-01-28 09:58:20 --> Email Class Initialized
INFO - 2025-01-28 09:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:20 --> Controller Class Initialized
INFO - 2025-01-28 15:28:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:25 --> Config Class Initialized
INFO - 2025-01-28 09:58:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:25 --> URI Class Initialized
INFO - 2025-01-28 09:58:25 --> Router Class Initialized
INFO - 2025-01-28 09:58:25 --> Output Class Initialized
INFO - 2025-01-28 09:58:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:25 --> Input Class Initialized
INFO - 2025-01-28 09:58:25 --> Language Class Initialized
INFO - 2025-01-28 09:58:25 --> Loader Class Initialized
INFO - 2025-01-28 09:58:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:25 --> Upload Class Initialized
INFO - 2025-01-28 09:58:25 --> Email Class Initialized
INFO - 2025-01-28 09:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:25 --> Controller Class Initialized
INFO - 2025-01-28 15:28:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:30 --> Config Class Initialized
INFO - 2025-01-28 09:58:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:30 --> URI Class Initialized
INFO - 2025-01-28 09:58:30 --> Router Class Initialized
INFO - 2025-01-28 09:58:30 --> Output Class Initialized
INFO - 2025-01-28 09:58:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:30 --> Input Class Initialized
INFO - 2025-01-28 09:58:30 --> Language Class Initialized
INFO - 2025-01-28 09:58:30 --> Loader Class Initialized
INFO - 2025-01-28 09:58:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:30 --> Upload Class Initialized
INFO - 2025-01-28 09:58:30 --> Email Class Initialized
INFO - 2025-01-28 09:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:30 --> Controller Class Initialized
INFO - 2025-01-28 15:28:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:35 --> Config Class Initialized
INFO - 2025-01-28 09:58:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:35 --> URI Class Initialized
INFO - 2025-01-28 09:58:35 --> Router Class Initialized
INFO - 2025-01-28 09:58:35 --> Output Class Initialized
INFO - 2025-01-28 09:58:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:35 --> Input Class Initialized
INFO - 2025-01-28 09:58:35 --> Language Class Initialized
INFO - 2025-01-28 09:58:35 --> Loader Class Initialized
INFO - 2025-01-28 09:58:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:35 --> Upload Class Initialized
INFO - 2025-01-28 09:58:35 --> Email Class Initialized
INFO - 2025-01-28 09:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:35 --> Controller Class Initialized
INFO - 2025-01-28 15:28:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:40 --> Config Class Initialized
INFO - 2025-01-28 09:58:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:40 --> URI Class Initialized
INFO - 2025-01-28 09:58:40 --> Router Class Initialized
INFO - 2025-01-28 09:58:40 --> Output Class Initialized
INFO - 2025-01-28 09:58:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:40 --> Input Class Initialized
INFO - 2025-01-28 09:58:40 --> Language Class Initialized
INFO - 2025-01-28 09:58:40 --> Loader Class Initialized
INFO - 2025-01-28 09:58:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:40 --> Upload Class Initialized
INFO - 2025-01-28 09:58:40 --> Email Class Initialized
INFO - 2025-01-28 09:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:40 --> Controller Class Initialized
INFO - 2025-01-28 15:28:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:45 --> Config Class Initialized
INFO - 2025-01-28 09:58:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:45 --> URI Class Initialized
INFO - 2025-01-28 09:58:45 --> Router Class Initialized
INFO - 2025-01-28 09:58:45 --> Output Class Initialized
INFO - 2025-01-28 09:58:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:45 --> Input Class Initialized
INFO - 2025-01-28 09:58:45 --> Language Class Initialized
INFO - 2025-01-28 09:58:45 --> Loader Class Initialized
INFO - 2025-01-28 09:58:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:45 --> Upload Class Initialized
INFO - 2025-01-28 09:58:45 --> Email Class Initialized
INFO - 2025-01-28 09:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:45 --> Controller Class Initialized
INFO - 2025-01-28 15:28:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:50 --> Config Class Initialized
INFO - 2025-01-28 09:58:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:50 --> URI Class Initialized
INFO - 2025-01-28 09:58:50 --> Router Class Initialized
INFO - 2025-01-28 09:58:50 --> Output Class Initialized
INFO - 2025-01-28 09:58:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:50 --> Input Class Initialized
INFO - 2025-01-28 09:58:50 --> Language Class Initialized
INFO - 2025-01-28 09:58:50 --> Loader Class Initialized
INFO - 2025-01-28 09:58:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:50 --> Upload Class Initialized
INFO - 2025-01-28 09:58:50 --> Email Class Initialized
INFO - 2025-01-28 09:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:50 --> Controller Class Initialized
INFO - 2025-01-28 15:28:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:58:55 --> Config Class Initialized
INFO - 2025-01-28 09:58:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:58:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:58:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:58:55 --> URI Class Initialized
INFO - 2025-01-28 09:58:55 --> Router Class Initialized
INFO - 2025-01-28 09:58:55 --> Output Class Initialized
INFO - 2025-01-28 09:58:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:58:55 --> Input Class Initialized
INFO - 2025-01-28 09:58:55 --> Language Class Initialized
INFO - 2025-01-28 09:58:55 --> Loader Class Initialized
INFO - 2025-01-28 09:58:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:58:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:58:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:58:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:58:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:58:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:58:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:58:55 --> Upload Class Initialized
INFO - 2025-01-28 09:58:55 --> Email Class Initialized
INFO - 2025-01-28 09:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:58:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:58:55 --> Controller Class Initialized
INFO - 2025-01-28 15:28:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:28:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:28:55 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:00 --> Config Class Initialized
INFO - 2025-01-28 09:59:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:00 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:00 --> URI Class Initialized
INFO - 2025-01-28 09:59:00 --> Router Class Initialized
INFO - 2025-01-28 09:59:00 --> Output Class Initialized
INFO - 2025-01-28 09:59:00 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:00 --> Input Class Initialized
INFO - 2025-01-28 09:59:00 --> Language Class Initialized
INFO - 2025-01-28 09:59:00 --> Loader Class Initialized
INFO - 2025-01-28 09:59:00 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:00 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:00 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:00 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:00 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:00 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:00 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:00 --> Upload Class Initialized
INFO - 2025-01-28 09:59:00 --> Email Class Initialized
INFO - 2025-01-28 09:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:00 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:00 --> Controller Class Initialized
INFO - 2025-01-28 15:29:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:00 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:05 --> Config Class Initialized
INFO - 2025-01-28 09:59:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:05 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:05 --> URI Class Initialized
INFO - 2025-01-28 09:59:05 --> Router Class Initialized
INFO - 2025-01-28 09:59:05 --> Output Class Initialized
INFO - 2025-01-28 09:59:05 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:05 --> Input Class Initialized
INFO - 2025-01-28 09:59:05 --> Language Class Initialized
INFO - 2025-01-28 09:59:05 --> Loader Class Initialized
INFO - 2025-01-28 09:59:05 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:05 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:05 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:05 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:05 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:05 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:05 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:05 --> Upload Class Initialized
INFO - 2025-01-28 09:59:05 --> Email Class Initialized
INFO - 2025-01-28 09:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:05 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:05 --> Controller Class Initialized
INFO - 2025-01-28 15:29:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:05 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:10 --> Config Class Initialized
INFO - 2025-01-28 09:59:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:10 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:10 --> URI Class Initialized
INFO - 2025-01-28 09:59:10 --> Router Class Initialized
INFO - 2025-01-28 09:59:10 --> Output Class Initialized
INFO - 2025-01-28 09:59:10 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:10 --> Input Class Initialized
INFO - 2025-01-28 09:59:10 --> Language Class Initialized
INFO - 2025-01-28 09:59:10 --> Loader Class Initialized
INFO - 2025-01-28 09:59:10 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:10 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:10 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:10 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:10 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:10 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:10 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:10 --> Upload Class Initialized
INFO - 2025-01-28 09:59:10 --> Email Class Initialized
INFO - 2025-01-28 09:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:10 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:10 --> Controller Class Initialized
INFO - 2025-01-28 15:29:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:10 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:15 --> Config Class Initialized
INFO - 2025-01-28 09:59:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:15 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:15 --> URI Class Initialized
INFO - 2025-01-28 09:59:15 --> Router Class Initialized
INFO - 2025-01-28 09:59:15 --> Output Class Initialized
INFO - 2025-01-28 09:59:15 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:15 --> Input Class Initialized
INFO - 2025-01-28 09:59:15 --> Language Class Initialized
INFO - 2025-01-28 09:59:15 --> Loader Class Initialized
INFO - 2025-01-28 09:59:15 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:15 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:15 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:15 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:15 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:15 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:15 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:15 --> Upload Class Initialized
INFO - 2025-01-28 09:59:15 --> Email Class Initialized
INFO - 2025-01-28 09:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:15 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:15 --> Controller Class Initialized
INFO - 2025-01-28 15:29:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:15 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:20 --> Config Class Initialized
INFO - 2025-01-28 09:59:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:20 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:20 --> URI Class Initialized
INFO - 2025-01-28 09:59:20 --> Router Class Initialized
INFO - 2025-01-28 09:59:20 --> Output Class Initialized
INFO - 2025-01-28 09:59:20 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:20 --> Input Class Initialized
INFO - 2025-01-28 09:59:20 --> Language Class Initialized
INFO - 2025-01-28 09:59:20 --> Loader Class Initialized
INFO - 2025-01-28 09:59:20 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:20 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:20 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:20 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:20 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:20 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:20 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:20 --> Upload Class Initialized
INFO - 2025-01-28 09:59:20 --> Email Class Initialized
INFO - 2025-01-28 09:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:20 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:20 --> Controller Class Initialized
INFO - 2025-01-28 15:29:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:20 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:25 --> Config Class Initialized
INFO - 2025-01-28 09:59:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:25 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:25 --> URI Class Initialized
INFO - 2025-01-28 09:59:25 --> Router Class Initialized
INFO - 2025-01-28 09:59:25 --> Output Class Initialized
INFO - 2025-01-28 09:59:25 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:25 --> Input Class Initialized
INFO - 2025-01-28 09:59:25 --> Language Class Initialized
INFO - 2025-01-28 09:59:25 --> Loader Class Initialized
INFO - 2025-01-28 09:59:25 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:25 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:25 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:25 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:25 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:25 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:25 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:25 --> Upload Class Initialized
INFO - 2025-01-28 09:59:25 --> Email Class Initialized
INFO - 2025-01-28 09:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:25 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:25 --> Controller Class Initialized
INFO - 2025-01-28 15:29:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:25 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:30 --> Config Class Initialized
INFO - 2025-01-28 09:59:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:30 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:30 --> URI Class Initialized
INFO - 2025-01-28 09:59:30 --> Router Class Initialized
INFO - 2025-01-28 09:59:30 --> Output Class Initialized
INFO - 2025-01-28 09:59:30 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:30 --> Input Class Initialized
INFO - 2025-01-28 09:59:30 --> Language Class Initialized
INFO - 2025-01-28 09:59:30 --> Loader Class Initialized
INFO - 2025-01-28 09:59:30 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:30 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:30 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:30 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:30 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:30 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:30 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:30 --> Upload Class Initialized
INFO - 2025-01-28 09:59:30 --> Email Class Initialized
INFO - 2025-01-28 09:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:30 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:30 --> Controller Class Initialized
INFO - 2025-01-28 15:29:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:30 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:35 --> Config Class Initialized
INFO - 2025-01-28 09:59:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:35 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:35 --> URI Class Initialized
INFO - 2025-01-28 09:59:35 --> Router Class Initialized
INFO - 2025-01-28 09:59:35 --> Output Class Initialized
INFO - 2025-01-28 09:59:35 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:35 --> Input Class Initialized
INFO - 2025-01-28 09:59:35 --> Language Class Initialized
INFO - 2025-01-28 09:59:35 --> Loader Class Initialized
INFO - 2025-01-28 09:59:35 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:35 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:35 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:35 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:35 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:35 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:35 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:35 --> Upload Class Initialized
INFO - 2025-01-28 09:59:35 --> Email Class Initialized
INFO - 2025-01-28 09:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:35 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:35 --> Controller Class Initialized
INFO - 2025-01-28 15:29:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:35 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:40 --> Config Class Initialized
INFO - 2025-01-28 09:59:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:40 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:40 --> URI Class Initialized
INFO - 2025-01-28 09:59:40 --> Router Class Initialized
INFO - 2025-01-28 09:59:40 --> Output Class Initialized
INFO - 2025-01-28 09:59:40 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:40 --> Input Class Initialized
INFO - 2025-01-28 09:59:40 --> Language Class Initialized
INFO - 2025-01-28 09:59:40 --> Loader Class Initialized
INFO - 2025-01-28 09:59:40 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:40 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:40 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:40 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:40 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:40 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:40 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:40 --> Upload Class Initialized
INFO - 2025-01-28 09:59:40 --> Email Class Initialized
INFO - 2025-01-28 09:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:40 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:40 --> Controller Class Initialized
INFO - 2025-01-28 15:29:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:40 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:45 --> Config Class Initialized
INFO - 2025-01-28 09:59:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:45 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:45 --> URI Class Initialized
INFO - 2025-01-28 09:59:45 --> Router Class Initialized
INFO - 2025-01-28 09:59:45 --> Output Class Initialized
INFO - 2025-01-28 09:59:45 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:45 --> Input Class Initialized
INFO - 2025-01-28 09:59:45 --> Language Class Initialized
INFO - 2025-01-28 09:59:45 --> Loader Class Initialized
INFO - 2025-01-28 09:59:45 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:45 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:45 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:45 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:45 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:45 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:45 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:45 --> Upload Class Initialized
INFO - 2025-01-28 09:59:45 --> Email Class Initialized
INFO - 2025-01-28 09:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:45 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:45 --> Controller Class Initialized
INFO - 2025-01-28 15:29:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:45 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:50 --> Config Class Initialized
INFO - 2025-01-28 09:59:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:50 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:50 --> URI Class Initialized
INFO - 2025-01-28 09:59:50 --> Router Class Initialized
INFO - 2025-01-28 09:59:50 --> Output Class Initialized
INFO - 2025-01-28 09:59:50 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:50 --> Input Class Initialized
INFO - 2025-01-28 09:59:50 --> Language Class Initialized
INFO - 2025-01-28 09:59:50 --> Loader Class Initialized
INFO - 2025-01-28 09:59:50 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:50 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:50 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:50 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:50 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:50 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:50 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:50 --> Upload Class Initialized
INFO - 2025-01-28 09:59:50 --> Email Class Initialized
INFO - 2025-01-28 09:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:50 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:50 --> Controller Class Initialized
INFO - 2025-01-28 15:29:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:50 --> Pagination Class Initialized
INFO - 2025-01-28 09:59:55 --> Config Class Initialized
INFO - 2025-01-28 09:59:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 09:59:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 09:59:55 --> Utf8 Class Initialized
INFO - 2025-01-28 09:59:55 --> URI Class Initialized
INFO - 2025-01-28 09:59:55 --> Router Class Initialized
INFO - 2025-01-28 09:59:55 --> Output Class Initialized
INFO - 2025-01-28 09:59:55 --> Security Class Initialized
DEBUG - 2025-01-28 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 09:59:55 --> Input Class Initialized
INFO - 2025-01-28 09:59:55 --> Language Class Initialized
INFO - 2025-01-28 09:59:55 --> Loader Class Initialized
INFO - 2025-01-28 09:59:55 --> Helper loaded: url_helper
INFO - 2025-01-28 09:59:55 --> Helper loaded: html_helper
INFO - 2025-01-28 09:59:55 --> Helper loaded: file_helper
INFO - 2025-01-28 09:59:55 --> Helper loaded: string_helper
INFO - 2025-01-28 09:59:55 --> Helper loaded: form_helper
INFO - 2025-01-28 09:59:55 --> Helper loaded: my_helper
INFO - 2025-01-28 09:59:55 --> Database Driver Class Initialized
INFO - 2025-01-28 09:59:55 --> Upload Class Initialized
INFO - 2025-01-28 09:59:55 --> Email Class Initialized
INFO - 2025-01-28 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 09:59:55 --> Form Validation Class Initialized
INFO - 2025-01-28 09:59:55 --> Controller Class Initialized
INFO - 2025-01-28 15:29:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:29:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:29:55 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:00 --> Config Class Initialized
INFO - 2025-01-28 10:00:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:00 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:00 --> URI Class Initialized
INFO - 2025-01-28 10:00:00 --> Router Class Initialized
INFO - 2025-01-28 10:00:00 --> Output Class Initialized
INFO - 2025-01-28 10:00:00 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:00 --> Input Class Initialized
INFO - 2025-01-28 10:00:00 --> Language Class Initialized
INFO - 2025-01-28 10:00:00 --> Loader Class Initialized
INFO - 2025-01-28 10:00:00 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:00 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:00 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:00 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:00 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:00 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:00 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:00 --> Upload Class Initialized
INFO - 2025-01-28 10:00:00 --> Email Class Initialized
INFO - 2025-01-28 10:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:00 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:00 --> Controller Class Initialized
INFO - 2025-01-28 15:30:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:00 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:05 --> Config Class Initialized
INFO - 2025-01-28 10:00:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:05 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:05 --> URI Class Initialized
INFO - 2025-01-28 10:00:05 --> Router Class Initialized
INFO - 2025-01-28 10:00:05 --> Output Class Initialized
INFO - 2025-01-28 10:00:05 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:05 --> Input Class Initialized
INFO - 2025-01-28 10:00:05 --> Language Class Initialized
INFO - 2025-01-28 10:00:05 --> Loader Class Initialized
INFO - 2025-01-28 10:00:05 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:05 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:05 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:05 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:05 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:05 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:05 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:05 --> Upload Class Initialized
INFO - 2025-01-28 10:00:05 --> Email Class Initialized
INFO - 2025-01-28 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:05 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:05 --> Controller Class Initialized
INFO - 2025-01-28 15:30:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:05 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:10 --> Config Class Initialized
INFO - 2025-01-28 10:00:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:10 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:10 --> URI Class Initialized
INFO - 2025-01-28 10:00:10 --> Router Class Initialized
INFO - 2025-01-28 10:00:10 --> Output Class Initialized
INFO - 2025-01-28 10:00:10 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:10 --> Input Class Initialized
INFO - 2025-01-28 10:00:10 --> Language Class Initialized
INFO - 2025-01-28 10:00:10 --> Loader Class Initialized
INFO - 2025-01-28 10:00:10 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:10 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:10 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:10 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:10 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:10 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:10 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:10 --> Upload Class Initialized
INFO - 2025-01-28 10:00:10 --> Email Class Initialized
INFO - 2025-01-28 10:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:10 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:10 --> Controller Class Initialized
INFO - 2025-01-28 15:30:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:10 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:15 --> Config Class Initialized
INFO - 2025-01-28 10:00:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:15 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:15 --> URI Class Initialized
INFO - 2025-01-28 10:00:15 --> Router Class Initialized
INFO - 2025-01-28 10:00:15 --> Output Class Initialized
INFO - 2025-01-28 10:00:15 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:15 --> Input Class Initialized
INFO - 2025-01-28 10:00:15 --> Language Class Initialized
INFO - 2025-01-28 10:00:15 --> Loader Class Initialized
INFO - 2025-01-28 10:00:15 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:15 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:15 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:15 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:15 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:15 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:15 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:15 --> Upload Class Initialized
INFO - 2025-01-28 10:00:15 --> Email Class Initialized
INFO - 2025-01-28 10:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:15 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:15 --> Controller Class Initialized
INFO - 2025-01-28 15:30:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:15 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:20 --> Config Class Initialized
INFO - 2025-01-28 10:00:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:20 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:20 --> URI Class Initialized
INFO - 2025-01-28 10:00:20 --> Router Class Initialized
INFO - 2025-01-28 10:00:20 --> Output Class Initialized
INFO - 2025-01-28 10:00:20 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:20 --> Input Class Initialized
INFO - 2025-01-28 10:00:20 --> Language Class Initialized
INFO - 2025-01-28 10:00:20 --> Loader Class Initialized
INFO - 2025-01-28 10:00:20 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:20 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:20 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:20 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:20 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:20 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:20 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:20 --> Upload Class Initialized
INFO - 2025-01-28 10:00:20 --> Email Class Initialized
INFO - 2025-01-28 10:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:20 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:20 --> Controller Class Initialized
INFO - 2025-01-28 15:30:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:20 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:25 --> Config Class Initialized
INFO - 2025-01-28 10:00:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:25 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:25 --> URI Class Initialized
INFO - 2025-01-28 10:00:25 --> Router Class Initialized
INFO - 2025-01-28 10:00:25 --> Output Class Initialized
INFO - 2025-01-28 10:00:25 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:25 --> Input Class Initialized
INFO - 2025-01-28 10:00:25 --> Language Class Initialized
INFO - 2025-01-28 10:00:25 --> Loader Class Initialized
INFO - 2025-01-28 10:00:25 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:25 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:25 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:25 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:25 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:25 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:25 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:25 --> Upload Class Initialized
INFO - 2025-01-28 10:00:25 --> Email Class Initialized
INFO - 2025-01-28 10:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:25 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:25 --> Controller Class Initialized
INFO - 2025-01-28 15:30:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:25 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:30 --> Config Class Initialized
INFO - 2025-01-28 10:00:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:30 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:30 --> URI Class Initialized
INFO - 2025-01-28 10:00:30 --> Router Class Initialized
INFO - 2025-01-28 10:00:30 --> Output Class Initialized
INFO - 2025-01-28 10:00:30 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:30 --> Input Class Initialized
INFO - 2025-01-28 10:00:30 --> Language Class Initialized
INFO - 2025-01-28 10:00:30 --> Loader Class Initialized
INFO - 2025-01-28 10:00:30 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:30 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:30 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:30 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:30 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:30 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:30 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:30 --> Upload Class Initialized
INFO - 2025-01-28 10:00:30 --> Email Class Initialized
INFO - 2025-01-28 10:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:30 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:30 --> Controller Class Initialized
INFO - 2025-01-28 15:30:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:30 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:35 --> Config Class Initialized
INFO - 2025-01-28 10:00:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:35 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:35 --> URI Class Initialized
INFO - 2025-01-28 10:00:35 --> Router Class Initialized
INFO - 2025-01-28 10:00:35 --> Output Class Initialized
INFO - 2025-01-28 10:00:35 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:35 --> Input Class Initialized
INFO - 2025-01-28 10:00:35 --> Language Class Initialized
INFO - 2025-01-28 10:00:35 --> Loader Class Initialized
INFO - 2025-01-28 10:00:35 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:35 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:35 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:35 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:35 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:35 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:35 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:35 --> Upload Class Initialized
INFO - 2025-01-28 10:00:35 --> Email Class Initialized
INFO - 2025-01-28 10:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:35 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:35 --> Controller Class Initialized
INFO - 2025-01-28 15:30:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:35 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:40 --> Config Class Initialized
INFO - 2025-01-28 10:00:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:40 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:40 --> URI Class Initialized
INFO - 2025-01-28 10:00:40 --> Router Class Initialized
INFO - 2025-01-28 10:00:40 --> Output Class Initialized
INFO - 2025-01-28 10:00:40 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:40 --> Input Class Initialized
INFO - 2025-01-28 10:00:40 --> Language Class Initialized
INFO - 2025-01-28 10:00:40 --> Loader Class Initialized
INFO - 2025-01-28 10:00:40 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:40 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:40 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:40 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:40 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:40 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:40 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:40 --> Upload Class Initialized
INFO - 2025-01-28 10:00:40 --> Email Class Initialized
INFO - 2025-01-28 10:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:40 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:40 --> Controller Class Initialized
INFO - 2025-01-28 15:30:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:40 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:45 --> Config Class Initialized
INFO - 2025-01-28 10:00:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:45 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:45 --> URI Class Initialized
INFO - 2025-01-28 10:00:45 --> Router Class Initialized
INFO - 2025-01-28 10:00:45 --> Output Class Initialized
INFO - 2025-01-28 10:00:45 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:45 --> Input Class Initialized
INFO - 2025-01-28 10:00:45 --> Language Class Initialized
INFO - 2025-01-28 10:00:45 --> Loader Class Initialized
INFO - 2025-01-28 10:00:45 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:45 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:45 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:45 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:45 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:45 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:45 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:45 --> Upload Class Initialized
INFO - 2025-01-28 10:00:45 --> Email Class Initialized
INFO - 2025-01-28 10:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:45 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:45 --> Controller Class Initialized
INFO - 2025-01-28 15:30:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:45 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:50 --> Config Class Initialized
INFO - 2025-01-28 10:00:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:50 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:50 --> URI Class Initialized
INFO - 2025-01-28 10:00:50 --> Router Class Initialized
INFO - 2025-01-28 10:00:50 --> Output Class Initialized
INFO - 2025-01-28 10:00:50 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:50 --> Input Class Initialized
INFO - 2025-01-28 10:00:50 --> Language Class Initialized
INFO - 2025-01-28 10:00:50 --> Loader Class Initialized
INFO - 2025-01-28 10:00:50 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:50 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:50 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:50 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:50 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:50 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:50 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:50 --> Upload Class Initialized
INFO - 2025-01-28 10:00:50 --> Email Class Initialized
INFO - 2025-01-28 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:50 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:50 --> Controller Class Initialized
INFO - 2025-01-28 15:30:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:50 --> Pagination Class Initialized
INFO - 2025-01-28 10:00:55 --> Config Class Initialized
INFO - 2025-01-28 10:00:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:00:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:00:55 --> Utf8 Class Initialized
INFO - 2025-01-28 10:00:55 --> URI Class Initialized
INFO - 2025-01-28 10:00:55 --> Router Class Initialized
INFO - 2025-01-28 10:00:55 --> Output Class Initialized
INFO - 2025-01-28 10:00:55 --> Security Class Initialized
DEBUG - 2025-01-28 10:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:00:55 --> Input Class Initialized
INFO - 2025-01-28 10:00:55 --> Language Class Initialized
INFO - 2025-01-28 10:00:55 --> Loader Class Initialized
INFO - 2025-01-28 10:00:55 --> Helper loaded: url_helper
INFO - 2025-01-28 10:00:55 --> Helper loaded: html_helper
INFO - 2025-01-28 10:00:55 --> Helper loaded: file_helper
INFO - 2025-01-28 10:00:55 --> Helper loaded: string_helper
INFO - 2025-01-28 10:00:55 --> Helper loaded: form_helper
INFO - 2025-01-28 10:00:55 --> Helper loaded: my_helper
INFO - 2025-01-28 10:00:55 --> Database Driver Class Initialized
INFO - 2025-01-28 10:00:55 --> Upload Class Initialized
INFO - 2025-01-28 10:00:55 --> Email Class Initialized
INFO - 2025-01-28 10:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:00:55 --> Form Validation Class Initialized
INFO - 2025-01-28 10:00:55 --> Controller Class Initialized
INFO - 2025-01-28 15:30:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:30:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:30:55 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:00 --> Config Class Initialized
INFO - 2025-01-28 10:01:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:00 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:00 --> URI Class Initialized
INFO - 2025-01-28 10:01:00 --> Router Class Initialized
INFO - 2025-01-28 10:01:00 --> Output Class Initialized
INFO - 2025-01-28 10:01:00 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:00 --> Input Class Initialized
INFO - 2025-01-28 10:01:00 --> Language Class Initialized
INFO - 2025-01-28 10:01:00 --> Loader Class Initialized
INFO - 2025-01-28 10:01:00 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:00 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:00 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:00 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:00 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:00 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:00 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:00 --> Upload Class Initialized
INFO - 2025-01-28 10:01:00 --> Email Class Initialized
INFO - 2025-01-28 10:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:00 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:00 --> Controller Class Initialized
INFO - 2025-01-28 15:31:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:00 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:05 --> Config Class Initialized
INFO - 2025-01-28 10:01:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:05 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:05 --> URI Class Initialized
INFO - 2025-01-28 10:01:05 --> Router Class Initialized
INFO - 2025-01-28 10:01:05 --> Output Class Initialized
INFO - 2025-01-28 10:01:05 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:05 --> Input Class Initialized
INFO - 2025-01-28 10:01:05 --> Language Class Initialized
INFO - 2025-01-28 10:01:05 --> Loader Class Initialized
INFO - 2025-01-28 10:01:05 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:05 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:05 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:05 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:05 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:05 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:05 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:05 --> Upload Class Initialized
INFO - 2025-01-28 10:01:05 --> Email Class Initialized
INFO - 2025-01-28 10:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:05 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:05 --> Controller Class Initialized
INFO - 2025-01-28 15:31:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:05 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:10 --> Config Class Initialized
INFO - 2025-01-28 10:01:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:10 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:10 --> URI Class Initialized
INFO - 2025-01-28 10:01:10 --> Router Class Initialized
INFO - 2025-01-28 10:01:10 --> Output Class Initialized
INFO - 2025-01-28 10:01:10 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:10 --> Input Class Initialized
INFO - 2025-01-28 10:01:10 --> Language Class Initialized
INFO - 2025-01-28 10:01:10 --> Loader Class Initialized
INFO - 2025-01-28 10:01:10 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:10 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:10 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:10 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:10 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:10 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:10 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:10 --> Upload Class Initialized
INFO - 2025-01-28 10:01:10 --> Email Class Initialized
INFO - 2025-01-28 10:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:10 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:10 --> Controller Class Initialized
INFO - 2025-01-28 15:31:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:10 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:15 --> Config Class Initialized
INFO - 2025-01-28 10:01:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:15 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:15 --> URI Class Initialized
INFO - 2025-01-28 10:01:15 --> Router Class Initialized
INFO - 2025-01-28 10:01:15 --> Output Class Initialized
INFO - 2025-01-28 10:01:15 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:15 --> Input Class Initialized
INFO - 2025-01-28 10:01:15 --> Language Class Initialized
INFO - 2025-01-28 10:01:15 --> Loader Class Initialized
INFO - 2025-01-28 10:01:15 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:15 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:15 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:15 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:15 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:15 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:15 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:15 --> Upload Class Initialized
INFO - 2025-01-28 10:01:15 --> Email Class Initialized
INFO - 2025-01-28 10:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:15 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:15 --> Controller Class Initialized
INFO - 2025-01-28 15:31:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:15 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:20 --> Config Class Initialized
INFO - 2025-01-28 10:01:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:20 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:20 --> URI Class Initialized
INFO - 2025-01-28 10:01:20 --> Router Class Initialized
INFO - 2025-01-28 10:01:20 --> Output Class Initialized
INFO - 2025-01-28 10:01:20 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:20 --> Input Class Initialized
INFO - 2025-01-28 10:01:20 --> Language Class Initialized
INFO - 2025-01-28 10:01:20 --> Loader Class Initialized
INFO - 2025-01-28 10:01:20 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:20 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:20 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:20 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:20 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:20 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:20 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:20 --> Upload Class Initialized
INFO - 2025-01-28 10:01:20 --> Email Class Initialized
INFO - 2025-01-28 10:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:20 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:20 --> Controller Class Initialized
INFO - 2025-01-28 15:31:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:20 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:25 --> Config Class Initialized
INFO - 2025-01-28 10:01:25 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:25 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:25 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:25 --> URI Class Initialized
INFO - 2025-01-28 10:01:25 --> Router Class Initialized
INFO - 2025-01-28 10:01:25 --> Output Class Initialized
INFO - 2025-01-28 10:01:25 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:25 --> Input Class Initialized
INFO - 2025-01-28 10:01:25 --> Language Class Initialized
INFO - 2025-01-28 10:01:25 --> Loader Class Initialized
INFO - 2025-01-28 10:01:25 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:25 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:25 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:25 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:25 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:25 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:25 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:25 --> Upload Class Initialized
INFO - 2025-01-28 10:01:25 --> Email Class Initialized
INFO - 2025-01-28 10:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:25 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:25 --> Controller Class Initialized
INFO - 2025-01-28 15:31:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:25 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:25 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:30 --> Config Class Initialized
INFO - 2025-01-28 10:01:30 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:30 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:30 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:30 --> URI Class Initialized
INFO - 2025-01-28 10:01:30 --> Router Class Initialized
INFO - 2025-01-28 10:01:30 --> Output Class Initialized
INFO - 2025-01-28 10:01:30 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:30 --> Input Class Initialized
INFO - 2025-01-28 10:01:30 --> Language Class Initialized
INFO - 2025-01-28 10:01:30 --> Loader Class Initialized
INFO - 2025-01-28 10:01:30 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:30 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:30 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:30 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:30 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:30 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:30 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:30 --> Upload Class Initialized
INFO - 2025-01-28 10:01:30 --> Email Class Initialized
INFO - 2025-01-28 10:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:30 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:30 --> Controller Class Initialized
INFO - 2025-01-28 15:31:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:30 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:30 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:35 --> Config Class Initialized
INFO - 2025-01-28 10:01:35 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:35 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:35 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:35 --> URI Class Initialized
INFO - 2025-01-28 10:01:35 --> Router Class Initialized
INFO - 2025-01-28 10:01:35 --> Output Class Initialized
INFO - 2025-01-28 10:01:35 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:35 --> Input Class Initialized
INFO - 2025-01-28 10:01:35 --> Language Class Initialized
INFO - 2025-01-28 10:01:35 --> Loader Class Initialized
INFO - 2025-01-28 10:01:35 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:35 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:35 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:35 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:35 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:35 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:35 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:35 --> Upload Class Initialized
INFO - 2025-01-28 10:01:35 --> Email Class Initialized
INFO - 2025-01-28 10:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:35 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:35 --> Controller Class Initialized
INFO - 2025-01-28 15:31:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:35 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:35 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:40 --> Config Class Initialized
INFO - 2025-01-28 10:01:40 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:40 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:40 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:40 --> URI Class Initialized
INFO - 2025-01-28 10:01:40 --> Router Class Initialized
INFO - 2025-01-28 10:01:40 --> Output Class Initialized
INFO - 2025-01-28 10:01:40 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:40 --> Input Class Initialized
INFO - 2025-01-28 10:01:40 --> Language Class Initialized
INFO - 2025-01-28 10:01:40 --> Loader Class Initialized
INFO - 2025-01-28 10:01:40 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:40 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:40 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:40 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:40 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:40 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:40 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:40 --> Upload Class Initialized
INFO - 2025-01-28 10:01:40 --> Email Class Initialized
INFO - 2025-01-28 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:40 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:40 --> Controller Class Initialized
INFO - 2025-01-28 15:31:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:40 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:40 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:41 --> Config Class Initialized
INFO - 2025-01-28 10:01:41 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:41 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:41 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:41 --> URI Class Initialized
INFO - 2025-01-28 10:01:41 --> Router Class Initialized
INFO - 2025-01-28 10:01:41 --> Output Class Initialized
INFO - 2025-01-28 10:01:41 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:41 --> Input Class Initialized
INFO - 2025-01-28 10:01:41 --> Language Class Initialized
ERROR - 2025-01-28 10:01:41 --> 404 Page Not Found: Page_login/index
INFO - 2025-01-28 10:01:45 --> Config Class Initialized
INFO - 2025-01-28 10:01:45 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:45 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:45 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:45 --> URI Class Initialized
INFO - 2025-01-28 10:01:45 --> Router Class Initialized
INFO - 2025-01-28 10:01:45 --> Output Class Initialized
INFO - 2025-01-28 10:01:45 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:45 --> Input Class Initialized
INFO - 2025-01-28 10:01:45 --> Language Class Initialized
INFO - 2025-01-28 10:01:45 --> Loader Class Initialized
INFO - 2025-01-28 10:01:45 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:45 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:45 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:45 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:45 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:45 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:45 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:45 --> Upload Class Initialized
INFO - 2025-01-28 10:01:45 --> Email Class Initialized
INFO - 2025-01-28 10:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:45 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:45 --> Controller Class Initialized
INFO - 2025-01-28 15:31:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:45 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:45 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:50 --> Config Class Initialized
INFO - 2025-01-28 10:01:50 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:50 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:50 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:50 --> URI Class Initialized
INFO - 2025-01-28 10:01:50 --> Router Class Initialized
INFO - 2025-01-28 10:01:50 --> Output Class Initialized
INFO - 2025-01-28 10:01:50 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:50 --> Input Class Initialized
INFO - 2025-01-28 10:01:50 --> Language Class Initialized
INFO - 2025-01-28 10:01:50 --> Loader Class Initialized
INFO - 2025-01-28 10:01:50 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:50 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:50 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:50 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:50 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:50 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:50 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:50 --> Upload Class Initialized
INFO - 2025-01-28 10:01:50 --> Email Class Initialized
INFO - 2025-01-28 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:50 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:50 --> Controller Class Initialized
INFO - 2025-01-28 15:31:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:50 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:50 --> Pagination Class Initialized
INFO - 2025-01-28 10:01:55 --> Config Class Initialized
INFO - 2025-01-28 10:01:55 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:01:55 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:01:55 --> Utf8 Class Initialized
INFO - 2025-01-28 10:01:55 --> URI Class Initialized
INFO - 2025-01-28 10:01:55 --> Router Class Initialized
INFO - 2025-01-28 10:01:55 --> Output Class Initialized
INFO - 2025-01-28 10:01:55 --> Security Class Initialized
DEBUG - 2025-01-28 10:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:01:55 --> Input Class Initialized
INFO - 2025-01-28 10:01:55 --> Language Class Initialized
INFO - 2025-01-28 10:01:55 --> Loader Class Initialized
INFO - 2025-01-28 10:01:55 --> Helper loaded: url_helper
INFO - 2025-01-28 10:01:55 --> Helper loaded: html_helper
INFO - 2025-01-28 10:01:55 --> Helper loaded: file_helper
INFO - 2025-01-28 10:01:55 --> Helper loaded: string_helper
INFO - 2025-01-28 10:01:55 --> Helper loaded: form_helper
INFO - 2025-01-28 10:01:55 --> Helper loaded: my_helper
INFO - 2025-01-28 10:01:55 --> Database Driver Class Initialized
INFO - 2025-01-28 10:01:55 --> Upload Class Initialized
INFO - 2025-01-28 10:01:55 --> Email Class Initialized
INFO - 2025-01-28 10:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:01:55 --> Form Validation Class Initialized
INFO - 2025-01-28 10:01:55 --> Controller Class Initialized
INFO - 2025-01-28 15:31:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:31:55 --> Model "MainModel" initialized
INFO - 2025-01-28 15:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:31:55 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:00 --> Config Class Initialized
INFO - 2025-01-28 10:02:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:00 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:00 --> URI Class Initialized
INFO - 2025-01-28 10:02:00 --> Router Class Initialized
INFO - 2025-01-28 10:02:00 --> Output Class Initialized
INFO - 2025-01-28 10:02:00 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:00 --> Input Class Initialized
INFO - 2025-01-28 10:02:00 --> Language Class Initialized
INFO - 2025-01-28 10:02:00 --> Loader Class Initialized
INFO - 2025-01-28 10:02:00 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:00 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:00 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:00 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:00 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:00 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:00 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:00 --> Upload Class Initialized
INFO - 2025-01-28 10:02:00 --> Email Class Initialized
INFO - 2025-01-28 10:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:00 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:00 --> Controller Class Initialized
INFO - 2025-01-28 15:32:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:32:00 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:00 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:05 --> Config Class Initialized
INFO - 2025-01-28 10:02:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:05 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:05 --> URI Class Initialized
INFO - 2025-01-28 10:02:05 --> Router Class Initialized
INFO - 2025-01-28 10:02:05 --> Output Class Initialized
INFO - 2025-01-28 10:02:05 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:05 --> Input Class Initialized
INFO - 2025-01-28 10:02:05 --> Language Class Initialized
INFO - 2025-01-28 10:02:05 --> Loader Class Initialized
INFO - 2025-01-28 10:02:05 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:05 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:05 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:05 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:05 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:05 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:05 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:05 --> Upload Class Initialized
INFO - 2025-01-28 10:02:05 --> Email Class Initialized
INFO - 2025-01-28 10:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:05 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:05 --> Controller Class Initialized
INFO - 2025-01-28 15:32:05 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:32:05 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:05 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:10 --> Config Class Initialized
INFO - 2025-01-28 10:02:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:10 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:10 --> URI Class Initialized
INFO - 2025-01-28 10:02:10 --> Router Class Initialized
INFO - 2025-01-28 10:02:10 --> Output Class Initialized
INFO - 2025-01-28 10:02:10 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:10 --> Input Class Initialized
INFO - 2025-01-28 10:02:10 --> Language Class Initialized
INFO - 2025-01-28 10:02:10 --> Loader Class Initialized
INFO - 2025-01-28 10:02:10 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:10 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:10 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:10 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:10 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:10 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:10 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:10 --> Upload Class Initialized
INFO - 2025-01-28 10:02:10 --> Email Class Initialized
INFO - 2025-01-28 10:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:10 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:10 --> Controller Class Initialized
INFO - 2025-01-28 15:32:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:32:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:10 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:15 --> Config Class Initialized
INFO - 2025-01-28 10:02:15 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:15 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:15 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:15 --> URI Class Initialized
INFO - 2025-01-28 10:02:15 --> Router Class Initialized
INFO - 2025-01-28 10:02:15 --> Output Class Initialized
INFO - 2025-01-28 10:02:15 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:15 --> Input Class Initialized
INFO - 2025-01-28 10:02:15 --> Language Class Initialized
INFO - 2025-01-28 10:02:15 --> Loader Class Initialized
INFO - 2025-01-28 10:02:15 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:15 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:15 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:15 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:15 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:15 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:15 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:15 --> Upload Class Initialized
INFO - 2025-01-28 10:02:15 --> Email Class Initialized
INFO - 2025-01-28 10:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:15 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:15 --> Controller Class Initialized
INFO - 2025-01-28 15:32:15 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:32:15 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:15 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:20 --> Config Class Initialized
INFO - 2025-01-28 10:02:20 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:20 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:20 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:20 --> URI Class Initialized
INFO - 2025-01-28 10:02:20 --> Router Class Initialized
INFO - 2025-01-28 10:02:20 --> Output Class Initialized
INFO - 2025-01-28 10:02:20 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:20 --> Input Class Initialized
INFO - 2025-01-28 10:02:20 --> Language Class Initialized
INFO - 2025-01-28 10:02:20 --> Loader Class Initialized
INFO - 2025-01-28 10:02:20 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:20 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:20 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:20 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:20 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:20 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:20 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:20 --> Upload Class Initialized
INFO - 2025-01-28 10:02:20 --> Email Class Initialized
INFO - 2025-01-28 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:20 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:20 --> Controller Class Initialized
INFO - 2025-01-28 15:32:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-28 15:32:20 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:20 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:22 --> Config Class Initialized
INFO - 2025-01-28 10:02:22 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:22 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:22 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:22 --> URI Class Initialized
INFO - 2025-01-28 10:02:22 --> Router Class Initialized
INFO - 2025-01-28 10:02:22 --> Output Class Initialized
INFO - 2025-01-28 10:02:22 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:22 --> Input Class Initialized
INFO - 2025-01-28 10:02:22 --> Language Class Initialized
INFO - 2025-01-28 10:02:22 --> Loader Class Initialized
INFO - 2025-01-28 10:02:22 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:22 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:22 --> Upload Class Initialized
INFO - 2025-01-28 10:02:22 --> Email Class Initialized
INFO - 2025-01-28 10:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:22 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:22 --> Controller Class Initialized
INFO - 2025-01-28 15:32:22 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:22 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:22 --> Config Class Initialized
INFO - 2025-01-28 10:02:22 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:22 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:22 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:22 --> URI Class Initialized
DEBUG - 2025-01-28 10:02:22 --> No URI present. Default controller set.
INFO - 2025-01-28 10:02:22 --> Router Class Initialized
INFO - 2025-01-28 10:02:22 --> Output Class Initialized
INFO - 2025-01-28 10:02:22 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:22 --> Input Class Initialized
INFO - 2025-01-28 10:02:22 --> Language Class Initialized
INFO - 2025-01-28 10:02:22 --> Loader Class Initialized
INFO - 2025-01-28 10:02:22 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:22 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:22 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:22 --> Upload Class Initialized
INFO - 2025-01-28 10:02:22 --> Email Class Initialized
INFO - 2025-01-28 10:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:22 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:22 --> Controller Class Initialized
INFO - 2025-01-28 15:32:22 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:22 --> Pagination Class Initialized
INFO - 2025-01-28 15:32:22 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-28 15:32:22 --> Final output sent to browser
DEBUG - 2025-01-28 15:32:22 --> Total execution time: 0.0396
INFO - 2025-01-28 10:02:38 --> Config Class Initialized
INFO - 2025-01-28 10:02:38 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:38 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:38 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:38 --> URI Class Initialized
INFO - 2025-01-28 10:02:38 --> Router Class Initialized
INFO - 2025-01-28 10:02:38 --> Output Class Initialized
INFO - 2025-01-28 10:02:38 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:38 --> Input Class Initialized
INFO - 2025-01-28 10:02:38 --> Language Class Initialized
INFO - 2025-01-28 10:02:38 --> Loader Class Initialized
INFO - 2025-01-28 10:02:38 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:38 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:38 --> Upload Class Initialized
INFO - 2025-01-28 10:02:38 --> Email Class Initialized
INFO - 2025-01-28 10:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:38 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:38 --> Controller Class Initialized
INFO - 2025-01-28 15:32:38 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:38 --> Pagination Class Initialized
INFO - 2025-01-28 10:02:38 --> Config Class Initialized
INFO - 2025-01-28 10:02:38 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:02:38 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:02:38 --> Utf8 Class Initialized
INFO - 2025-01-28 10:02:38 --> URI Class Initialized
DEBUG - 2025-01-28 10:02:38 --> No URI present. Default controller set.
INFO - 2025-01-28 10:02:38 --> Router Class Initialized
INFO - 2025-01-28 10:02:38 --> Output Class Initialized
INFO - 2025-01-28 10:02:38 --> Security Class Initialized
DEBUG - 2025-01-28 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:02:38 --> Input Class Initialized
INFO - 2025-01-28 10:02:38 --> Language Class Initialized
INFO - 2025-01-28 10:02:38 --> Loader Class Initialized
INFO - 2025-01-28 10:02:38 --> Helper loaded: url_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: html_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: file_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: string_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: form_helper
INFO - 2025-01-28 10:02:38 --> Helper loaded: my_helper
INFO - 2025-01-28 10:02:38 --> Database Driver Class Initialized
INFO - 2025-01-28 10:02:38 --> Upload Class Initialized
INFO - 2025-01-28 10:02:38 --> Email Class Initialized
INFO - 2025-01-28 10:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:02:38 --> Form Validation Class Initialized
INFO - 2025-01-28 10:02:38 --> Controller Class Initialized
INFO - 2025-01-28 15:32:38 --> Model "MainModel" initialized
INFO - 2025-01-28 15:32:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:32:38 --> Pagination Class Initialized
INFO - 2025-01-28 15:32:38 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-28 15:32:38 --> Final output sent to browser
DEBUG - 2025-01-28 15:32:38 --> Total execution time: 0.0221
INFO - 2025-01-28 10:03:10 --> Config Class Initialized
INFO - 2025-01-28 10:03:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:03:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:03:10 --> Utf8 Class Initialized
INFO - 2025-01-28 10:03:10 --> URI Class Initialized
INFO - 2025-01-28 10:03:10 --> Router Class Initialized
INFO - 2025-01-28 10:03:10 --> Output Class Initialized
INFO - 2025-01-28 10:03:10 --> Security Class Initialized
DEBUG - 2025-01-28 10:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:03:10 --> Input Class Initialized
INFO - 2025-01-28 10:03:10 --> Language Class Initialized
INFO - 2025-01-28 10:03:10 --> Loader Class Initialized
INFO - 2025-01-28 10:03:10 --> Helper loaded: url_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: html_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: file_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: string_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: form_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: my_helper
INFO - 2025-01-28 10:03:10 --> Database Driver Class Initialized
INFO - 2025-01-28 10:03:10 --> Upload Class Initialized
INFO - 2025-01-28 10:03:10 --> Email Class Initialized
INFO - 2025-01-28 10:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:03:10 --> Form Validation Class Initialized
INFO - 2025-01-28 10:03:10 --> Controller Class Initialized
INFO - 2025-01-28 15:33:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:33:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-28 15:33:10 --> Pagination Class Initialized
INFO - 2025-01-28 10:03:10 --> Config Class Initialized
INFO - 2025-01-28 10:03:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:03:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:03:10 --> Utf8 Class Initialized
INFO - 2025-01-28 10:03:10 --> URI Class Initialized
INFO - 2025-01-28 10:03:10 --> Router Class Initialized
INFO - 2025-01-28 10:03:10 --> Output Class Initialized
INFO - 2025-01-28 10:03:10 --> Security Class Initialized
DEBUG - 2025-01-28 10:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:03:10 --> Input Class Initialized
INFO - 2025-01-28 10:03:10 --> Language Class Initialized
INFO - 2025-01-28 10:03:10 --> Loader Class Initialized
INFO - 2025-01-28 10:03:10 --> Helper loaded: url_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: html_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: file_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: string_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: form_helper
INFO - 2025-01-28 10:03:10 --> Helper loaded: my_helper
INFO - 2025-01-28 10:03:10 --> Database Driver Class Initialized
INFO - 2025-01-28 10:03:10 --> Upload Class Initialized
INFO - 2025-01-28 10:03:10 --> Email Class Initialized
INFO - 2025-01-28 10:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:03:10 --> Form Validation Class Initialized
INFO - 2025-01-28 10:03:10 --> Controller Class Initialized
INFO - 2025-01-28 15:33:10 --> Model "MainModel" initialized
INFO - 2025-01-28 15:33:10 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:33:10 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:33:10 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:33:10 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:33:10 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:33:10 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:33:10 --> Helper loaded: array_helper
INFO - 2025-01-28 15:33:10 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-28 15:33:10 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-28 15:33:10 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-28 15:33:10 --> Final output sent to browser
DEBUG - 2025-01-28 15:33:10 --> Total execution time: 0.2409
INFO - 2025-01-28 10:18:32 --> Config Class Initialized
INFO - 2025-01-28 10:18:32 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:18:32 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:18:32 --> Utf8 Class Initialized
INFO - 2025-01-28 10:18:32 --> URI Class Initialized
INFO - 2025-01-28 10:18:32 --> Router Class Initialized
INFO - 2025-01-28 10:18:32 --> Output Class Initialized
INFO - 2025-01-28 10:18:32 --> Security Class Initialized
DEBUG - 2025-01-28 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:18:32 --> Input Class Initialized
INFO - 2025-01-28 10:18:32 --> Language Class Initialized
INFO - 2025-01-28 10:18:32 --> Loader Class Initialized
INFO - 2025-01-28 10:18:32 --> Helper loaded: url_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: html_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: file_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: string_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: form_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: my_helper
INFO - 2025-01-28 10:18:32 --> Database Driver Class Initialized
INFO - 2025-01-28 10:18:32 --> Upload Class Initialized
INFO - 2025-01-28 10:18:32 --> Email Class Initialized
INFO - 2025-01-28 10:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:18:32 --> Form Validation Class Initialized
INFO - 2025-01-28 10:18:32 --> Controller Class Initialized
INFO - 2025-01-28 15:48:32 --> Model "MainModel" initialized
INFO - 2025-01-28 10:18:32 --> Config Class Initialized
INFO - 2025-01-28 10:18:32 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:18:32 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:18:32 --> Utf8 Class Initialized
INFO - 2025-01-28 10:18:32 --> URI Class Initialized
INFO - 2025-01-28 10:18:32 --> Router Class Initialized
INFO - 2025-01-28 10:18:32 --> Output Class Initialized
INFO - 2025-01-28 10:18:32 --> Security Class Initialized
DEBUG - 2025-01-28 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:18:32 --> Input Class Initialized
INFO - 2025-01-28 10:18:32 --> Language Class Initialized
INFO - 2025-01-28 10:18:32 --> Loader Class Initialized
INFO - 2025-01-28 10:18:32 --> Helper loaded: url_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: html_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: file_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: string_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: form_helper
INFO - 2025-01-28 10:18:32 --> Helper loaded: my_helper
INFO - 2025-01-28 10:18:32 --> Database Driver Class Initialized
INFO - 2025-01-28 10:18:32 --> Upload Class Initialized
INFO - 2025-01-28 10:18:32 --> Email Class Initialized
INFO - 2025-01-28 10:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:18:32 --> Form Validation Class Initialized
INFO - 2025-01-28 10:18:32 --> Controller Class Initialized
INFO - 2025-01-28 15:48:32 --> Model "MainModel" initialized
INFO - 2025-01-28 15:48:32 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:48:32 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:48:32 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:48:32 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:48:32 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:48:32 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:48:32 --> Helper loaded: array_helper
INFO - 2025-01-28 15:48:33 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-28 15:48:33 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-28 15:48:33 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-28 15:48:33 --> Final output sent to browser
DEBUG - 2025-01-28 15:48:33 --> Total execution time: 0.3003
INFO - 2025-01-28 10:22:16 --> Config Class Initialized
INFO - 2025-01-28 10:22:16 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:22:16 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:22:16 --> Utf8 Class Initialized
INFO - 2025-01-28 10:22:16 --> URI Class Initialized
INFO - 2025-01-28 10:22:16 --> Router Class Initialized
INFO - 2025-01-28 10:22:16 --> Output Class Initialized
INFO - 2025-01-28 10:22:16 --> Security Class Initialized
DEBUG - 2025-01-28 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:22:16 --> Input Class Initialized
INFO - 2025-01-28 10:22:16 --> Language Class Initialized
INFO - 2025-01-28 10:22:16 --> Loader Class Initialized
INFO - 2025-01-28 10:22:16 --> Helper loaded: url_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: html_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: file_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: string_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: form_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: my_helper
INFO - 2025-01-28 10:22:16 --> Database Driver Class Initialized
INFO - 2025-01-28 10:22:16 --> Upload Class Initialized
INFO - 2025-01-28 10:22:16 --> Email Class Initialized
INFO - 2025-01-28 10:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:22:16 --> Form Validation Class Initialized
INFO - 2025-01-28 10:22:16 --> Controller Class Initialized
INFO - 2025-01-28 15:52:16 --> Model "MainModel" initialized
INFO - 2025-01-28 10:22:16 --> Config Class Initialized
INFO - 2025-01-28 10:22:16 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:22:16 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:22:16 --> Utf8 Class Initialized
INFO - 2025-01-28 10:22:16 --> URI Class Initialized
INFO - 2025-01-28 10:22:16 --> Router Class Initialized
INFO - 2025-01-28 10:22:16 --> Output Class Initialized
INFO - 2025-01-28 10:22:16 --> Security Class Initialized
DEBUG - 2025-01-28 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:22:16 --> Input Class Initialized
INFO - 2025-01-28 10:22:16 --> Language Class Initialized
INFO - 2025-01-28 10:22:16 --> Loader Class Initialized
INFO - 2025-01-28 10:22:16 --> Helper loaded: url_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: html_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: file_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: string_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: form_helper
INFO - 2025-01-28 10:22:16 --> Helper loaded: my_helper
INFO - 2025-01-28 10:22:16 --> Database Driver Class Initialized
INFO - 2025-01-28 10:22:16 --> Upload Class Initialized
INFO - 2025-01-28 10:22:16 --> Email Class Initialized
INFO - 2025-01-28 10:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:22:16 --> Form Validation Class Initialized
INFO - 2025-01-28 10:22:16 --> Controller Class Initialized
INFO - 2025-01-28 15:52:16 --> Model "MainModel" initialized
INFO - 2025-01-28 15:52:16 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:52:16 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:52:16 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:52:16 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:52:16 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:52:16 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:52:16 --> Helper loaded: array_helper
INFO - 2025-01-28 15:52:16 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-28 15:52:16 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-28 15:52:16 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-28 15:52:16 --> Final output sent to browser
DEBUG - 2025-01-28 15:52:16 --> Total execution time: 0.2866
INFO - 2025-01-28 10:26:44 --> Config Class Initialized
INFO - 2025-01-28 10:26:44 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:26:44 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:26:44 --> Utf8 Class Initialized
INFO - 2025-01-28 10:26:44 --> URI Class Initialized
INFO - 2025-01-28 10:26:44 --> Router Class Initialized
INFO - 2025-01-28 10:26:44 --> Output Class Initialized
INFO - 2025-01-28 10:26:44 --> Security Class Initialized
DEBUG - 2025-01-28 10:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:26:44 --> Input Class Initialized
INFO - 2025-01-28 10:26:44 --> Language Class Initialized
INFO - 2025-01-28 10:26:44 --> Loader Class Initialized
INFO - 2025-01-28 10:26:44 --> Helper loaded: url_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: html_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: file_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: string_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: form_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: my_helper
INFO - 2025-01-28 10:26:44 --> Database Driver Class Initialized
INFO - 2025-01-28 10:26:44 --> Upload Class Initialized
INFO - 2025-01-28 10:26:44 --> Email Class Initialized
INFO - 2025-01-28 10:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:26:44 --> Form Validation Class Initialized
INFO - 2025-01-28 10:26:44 --> Controller Class Initialized
INFO - 2025-01-28 15:56:44 --> Model "MainModel" initialized
INFO - 2025-01-28 10:26:44 --> Config Class Initialized
INFO - 2025-01-28 10:26:44 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:26:44 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:26:44 --> Utf8 Class Initialized
INFO - 2025-01-28 10:26:44 --> URI Class Initialized
INFO - 2025-01-28 10:26:44 --> Router Class Initialized
INFO - 2025-01-28 10:26:44 --> Output Class Initialized
INFO - 2025-01-28 10:26:44 --> Security Class Initialized
DEBUG - 2025-01-28 10:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:26:44 --> Input Class Initialized
INFO - 2025-01-28 10:26:44 --> Language Class Initialized
INFO - 2025-01-28 10:26:44 --> Loader Class Initialized
INFO - 2025-01-28 10:26:44 --> Helper loaded: url_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: html_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: file_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: string_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: form_helper
INFO - 2025-01-28 10:26:44 --> Helper loaded: my_helper
INFO - 2025-01-28 10:26:44 --> Database Driver Class Initialized
INFO - 2025-01-28 10:26:44 --> Upload Class Initialized
INFO - 2025-01-28 10:26:44 --> Email Class Initialized
INFO - 2025-01-28 10:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:26:44 --> Form Validation Class Initialized
INFO - 2025-01-28 10:26:44 --> Controller Class Initialized
INFO - 2025-01-28 15:56:44 --> Model "MainModel" initialized
INFO - 2025-01-28 15:56:44 --> Model "FrontofficeModel" initialized
INFO - 2025-01-28 15:56:44 --> Model "HotelAdminModel" initialized
INFO - 2025-01-28 15:56:44 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-28 15:56:44 --> Model "FoodAdminModel" initialized
INFO - 2025-01-28 15:56:44 --> Model "SuperAdminModel" initialized
INFO - 2025-01-28 15:56:44 --> Helper loaded: notification_helper
INFO - 2025-01-28 15:56:44 --> Helper loaded: array_helper
INFO - 2025-01-28 15:56:45 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-28 15:56:45 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-28 15:56:45 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-28 15:56:45 --> Final output sent to browser
DEBUG - 2025-01-28 15:56:45 --> Total execution time: 0.3025
INFO - 2025-01-28 10:28:51 --> Config Class Initialized
INFO - 2025-01-28 10:28:51 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:28:51 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:28:51 --> Utf8 Class Initialized
INFO - 2025-01-28 10:28:51 --> URI Class Initialized
INFO - 2025-01-28 10:28:51 --> Router Class Initialized
INFO - 2025-01-28 10:28:51 --> Output Class Initialized
INFO - 2025-01-28 10:28:51 --> Security Class Initialized
DEBUG - 2025-01-28 10:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:28:51 --> Input Class Initialized
INFO - 2025-01-28 10:28:51 --> Language Class Initialized
ERROR - 2025-01-28 10:28:51 --> 404 Page Not Found: StafApi/verify_otp
INFO - 2025-01-28 10:29:04 --> Config Class Initialized
INFO - 2025-01-28 10:29:04 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:29:04 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:29:04 --> Utf8 Class Initialized
INFO - 2025-01-28 10:29:04 --> URI Class Initialized
INFO - 2025-01-28 10:29:04 --> Router Class Initialized
INFO - 2025-01-28 10:29:04 --> Output Class Initialized
INFO - 2025-01-28 10:29:04 --> Security Class Initialized
DEBUG - 2025-01-28 10:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:29:04 --> Input Class Initialized
INFO - 2025-01-28 10:29:04 --> Language Class Initialized
INFO - 2025-01-28 10:29:04 --> Loader Class Initialized
INFO - 2025-01-28 10:29:04 --> Helper loaded: url_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: html_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: file_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: string_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: form_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: my_helper
INFO - 2025-01-28 10:29:04 --> Database Driver Class Initialized
INFO - 2025-01-28 10:29:04 --> Upload Class Initialized
INFO - 2025-01-28 10:29:04 --> Email Class Initialized
INFO - 2025-01-28 10:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:29:04 --> Form Validation Class Initialized
INFO - 2025-01-28 10:29:04 --> Controller Class Initialized
INFO - 2025-01-28 15:59:04 --> Model "MainModel" initialized
INFO - 2025-01-28 10:29:04 --> Config Class Initialized
INFO - 2025-01-28 10:29:04 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:29:04 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:29:04 --> Utf8 Class Initialized
INFO - 2025-01-28 10:29:04 --> URI Class Initialized
DEBUG - 2025-01-28 10:29:04 --> No URI present. Default controller set.
INFO - 2025-01-28 10:29:04 --> Router Class Initialized
INFO - 2025-01-28 10:29:04 --> Output Class Initialized
INFO - 2025-01-28 10:29:04 --> Security Class Initialized
DEBUG - 2025-01-28 10:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:29:04 --> Input Class Initialized
INFO - 2025-01-28 10:29:04 --> Language Class Initialized
INFO - 2025-01-28 10:29:04 --> Loader Class Initialized
INFO - 2025-01-28 10:29:04 --> Helper loaded: url_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: html_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: file_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: string_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: form_helper
INFO - 2025-01-28 10:29:04 --> Helper loaded: my_helper
INFO - 2025-01-28 10:29:04 --> Database Driver Class Initialized
INFO - 2025-01-28 10:29:04 --> Upload Class Initialized
INFO - 2025-01-28 10:29:04 --> Email Class Initialized
INFO - 2025-01-28 10:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:29:04 --> Form Validation Class Initialized
INFO - 2025-01-28 10:29:04 --> Controller Class Initialized
INFO - 2025-01-28 15:59:04 --> Model "MainModel" initialized
INFO - 2025-01-28 15:59:04 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-28 15:59:04 --> Final output sent to browser
DEBUG - 2025-01-28 15:59:04 --> Total execution time: 0.0298
INFO - 2025-01-28 10:31:42 --> Config Class Initialized
INFO - 2025-01-28 10:31:42 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:31:42 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:31:42 --> Utf8 Class Initialized
INFO - 2025-01-28 10:31:42 --> URI Class Initialized
INFO - 2025-01-28 10:31:42 --> Router Class Initialized
INFO - 2025-01-28 10:31:42 --> Output Class Initialized
INFO - 2025-01-28 10:31:42 --> Security Class Initialized
DEBUG - 2025-01-28 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:31:42 --> Input Class Initialized
INFO - 2025-01-28 10:31:42 --> Language Class Initialized
INFO - 2025-01-28 10:31:42 --> Loader Class Initialized
INFO - 2025-01-28 10:31:42 --> Helper loaded: url_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: html_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: file_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: string_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: form_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: my_helper
INFO - 2025-01-28 10:31:42 --> Database Driver Class Initialized
INFO - 2025-01-28 10:31:42 --> Upload Class Initialized
INFO - 2025-01-28 10:31:42 --> Email Class Initialized
INFO - 2025-01-28 10:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:31:42 --> Form Validation Class Initialized
INFO - 2025-01-28 10:31:42 --> Controller Class Initialized
INFO - 2025-01-28 16:01:42 --> Model "MainModel" initialized
INFO - 2025-01-28 10:31:42 --> Config Class Initialized
INFO - 2025-01-28 10:31:42 --> Hooks Class Initialized
DEBUG - 2025-01-28 10:31:42 --> UTF-8 Support Enabled
INFO - 2025-01-28 10:31:42 --> Utf8 Class Initialized
INFO - 2025-01-28 10:31:42 --> URI Class Initialized
DEBUG - 2025-01-28 10:31:42 --> No URI present. Default controller set.
INFO - 2025-01-28 10:31:42 --> Router Class Initialized
INFO - 2025-01-28 10:31:42 --> Output Class Initialized
INFO - 2025-01-28 10:31:42 --> Security Class Initialized
DEBUG - 2025-01-28 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 10:31:42 --> Input Class Initialized
INFO - 2025-01-28 10:31:42 --> Language Class Initialized
INFO - 2025-01-28 10:31:42 --> Loader Class Initialized
INFO - 2025-01-28 10:31:42 --> Helper loaded: url_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: html_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: file_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: string_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: form_helper
INFO - 2025-01-28 10:31:42 --> Helper loaded: my_helper
INFO - 2025-01-28 10:31:42 --> Database Driver Class Initialized
INFO - 2025-01-28 10:31:42 --> Upload Class Initialized
INFO - 2025-01-28 10:31:42 --> Email Class Initialized
INFO - 2025-01-28 10:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 10:31:42 --> Form Validation Class Initialized
INFO - 2025-01-28 10:31:42 --> Controller Class Initialized
INFO - 2025-01-28 16:01:42 --> Model "MainModel" initialized
INFO - 2025-01-28 16:01:42 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-28 16:01:42 --> Final output sent to browser
DEBUG - 2025-01-28 16:01:42 --> Total execution time: 0.0358
INFO - 2025-01-28 11:02:51 --> Config Class Initialized
INFO - 2025-01-28 11:02:51 --> Hooks Class Initialized
DEBUG - 2025-01-28 11:02:51 --> UTF-8 Support Enabled
INFO - 2025-01-28 11:02:51 --> Utf8 Class Initialized
INFO - 2025-01-28 11:02:51 --> URI Class Initialized
INFO - 2025-01-28 11:02:51 --> Router Class Initialized
INFO - 2025-01-28 11:02:51 --> Output Class Initialized
INFO - 2025-01-28 11:02:51 --> Security Class Initialized
DEBUG - 2025-01-28 11:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 11:02:51 --> Input Class Initialized
INFO - 2025-01-28 11:02:51 --> Language Class Initialized
INFO - 2025-01-28 11:02:51 --> Loader Class Initialized
INFO - 2025-01-28 11:02:51 --> Helper loaded: url_helper
INFO - 2025-01-28 11:02:51 --> Helper loaded: html_helper
INFO - 2025-01-28 11:02:51 --> Helper loaded: file_helper
INFO - 2025-01-28 11:02:51 --> Helper loaded: string_helper
INFO - 2025-01-28 11:02:51 --> Helper loaded: form_helper
INFO - 2025-01-28 11:02:51 --> Helper loaded: my_helper
INFO - 2025-01-28 11:02:51 --> Database Driver Class Initialized
INFO - 2025-01-28 11:02:51 --> Upload Class Initialized
INFO - 2025-01-28 11:02:51 --> Email Class Initialized
INFO - 2025-01-28 11:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 11:02:51 --> Form Validation Class Initialized
INFO - 2025-01-28 11:02:51 --> Controller Class Initialized
INFO - 2025-01-28 16:32:51 --> Model "ApiModel" initialized
INFO - 2025-01-28 16:32:51 --> Helper loaded: notification_helper
INFO - 2025-01-28 16:32:51 --> Model "MainModel" initialized
INFO - 2025-01-28 11:03:01 --> Config Class Initialized
INFO - 2025-01-28 11:03:01 --> Hooks Class Initialized
DEBUG - 2025-01-28 11:03:01 --> UTF-8 Support Enabled
INFO - 2025-01-28 11:03:01 --> Utf8 Class Initialized
INFO - 2025-01-28 11:03:01 --> URI Class Initialized
INFO - 2025-01-28 11:03:01 --> Router Class Initialized
INFO - 2025-01-28 11:03:01 --> Output Class Initialized
INFO - 2025-01-28 11:03:01 --> Security Class Initialized
DEBUG - 2025-01-28 11:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 11:03:01 --> Input Class Initialized
INFO - 2025-01-28 11:03:01 --> Language Class Initialized
INFO - 2025-01-28 11:03:01 --> Loader Class Initialized
INFO - 2025-01-28 11:03:01 --> Helper loaded: url_helper
INFO - 2025-01-28 11:03:01 --> Helper loaded: html_helper
INFO - 2025-01-28 11:03:01 --> Helper loaded: file_helper
INFO - 2025-01-28 11:03:01 --> Helper loaded: string_helper
INFO - 2025-01-28 11:03:01 --> Helper loaded: form_helper
INFO - 2025-01-28 11:03:01 --> Helper loaded: my_helper
INFO - 2025-01-28 11:03:01 --> Database Driver Class Initialized
INFO - 2025-01-28 11:03:01 --> Upload Class Initialized
INFO - 2025-01-28 11:03:01 --> Email Class Initialized
INFO - 2025-01-28 11:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 11:03:01 --> Form Validation Class Initialized
INFO - 2025-01-28 11:03:01 --> Controller Class Initialized
INFO - 2025-01-28 16:33:01 --> Model "ApiModel" initialized
INFO - 2025-01-28 16:33:01 --> Helper loaded: notification_helper
INFO - 2025-01-28 16:33:01 --> Model "MainModel" initialized
INFO - 2025-01-28 11:12:14 --> Config Class Initialized
INFO - 2025-01-28 11:12:14 --> Hooks Class Initialized
DEBUG - 2025-01-28 11:12:14 --> UTF-8 Support Enabled
INFO - 2025-01-28 11:12:14 --> Utf8 Class Initialized
INFO - 2025-01-28 11:12:14 --> URI Class Initialized
INFO - 2025-01-28 11:12:14 --> Router Class Initialized
INFO - 2025-01-28 11:12:14 --> Output Class Initialized
INFO - 2025-01-28 11:12:14 --> Security Class Initialized
DEBUG - 2025-01-28 11:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 11:12:14 --> Input Class Initialized
INFO - 2025-01-28 11:12:14 --> Language Class Initialized
INFO - 2025-01-28 11:12:14 --> Loader Class Initialized
INFO - 2025-01-28 11:12:14 --> Helper loaded: url_helper
INFO - 2025-01-28 11:12:14 --> Helper loaded: html_helper
INFO - 2025-01-28 11:12:14 --> Helper loaded: file_helper
INFO - 2025-01-28 11:12:14 --> Helper loaded: string_helper
INFO - 2025-01-28 11:12:14 --> Helper loaded: form_helper
INFO - 2025-01-28 11:12:14 --> Helper loaded: my_helper
INFO - 2025-01-28 11:12:14 --> Database Driver Class Initialized
INFO - 2025-01-28 11:12:14 --> Upload Class Initialized
INFO - 2025-01-28 11:12:14 --> Email Class Initialized
INFO - 2025-01-28 11:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 11:12:14 --> Form Validation Class Initialized
INFO - 2025-01-28 11:12:14 --> Controller Class Initialized
ERROR - 2025-01-28 16:42:14 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 11:47:27 --> Config Class Initialized
INFO - 2025-01-28 11:47:27 --> Hooks Class Initialized
DEBUG - 2025-01-28 11:47:27 --> UTF-8 Support Enabled
INFO - 2025-01-28 11:47:27 --> Utf8 Class Initialized
INFO - 2025-01-28 11:47:27 --> URI Class Initialized
INFO - 2025-01-28 11:47:27 --> Router Class Initialized
INFO - 2025-01-28 11:47:27 --> Output Class Initialized
INFO - 2025-01-28 11:47:27 --> Security Class Initialized
DEBUG - 2025-01-28 11:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 11:47:27 --> Input Class Initialized
INFO - 2025-01-28 11:47:27 --> Language Class Initialized
INFO - 2025-01-28 11:47:27 --> Loader Class Initialized
INFO - 2025-01-28 11:47:27 --> Helper loaded: url_helper
INFO - 2025-01-28 11:47:27 --> Helper loaded: html_helper
INFO - 2025-01-28 11:47:27 --> Helper loaded: file_helper
INFO - 2025-01-28 11:47:27 --> Helper loaded: string_helper
INFO - 2025-01-28 11:47:27 --> Helper loaded: form_helper
INFO - 2025-01-28 11:47:27 --> Helper loaded: my_helper
INFO - 2025-01-28 11:47:27 --> Database Driver Class Initialized
INFO - 2025-01-28 11:47:27 --> Upload Class Initialized
INFO - 2025-01-28 11:47:27 --> Email Class Initialized
INFO - 2025-01-28 11:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 11:47:27 --> Form Validation Class Initialized
INFO - 2025-01-28 11:47:27 --> Controller Class Initialized
ERROR - 2025-01-28 17:17:27 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 15:05:03 --> Config Class Initialized
INFO - 2025-01-28 15:05:03 --> Hooks Class Initialized
DEBUG - 2025-01-28 15:05:03 --> UTF-8 Support Enabled
INFO - 2025-01-28 15:05:03 --> Utf8 Class Initialized
INFO - 2025-01-28 15:05:03 --> URI Class Initialized
INFO - 2025-01-28 15:05:03 --> Router Class Initialized
INFO - 2025-01-28 15:05:03 --> Output Class Initialized
INFO - 2025-01-28 15:05:03 --> Security Class Initialized
DEBUG - 2025-01-28 15:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 15:05:03 --> Input Class Initialized
INFO - 2025-01-28 15:05:03 --> Language Class Initialized
INFO - 2025-01-28 15:05:03 --> Loader Class Initialized
INFO - 2025-01-28 15:05:03 --> Helper loaded: url_helper
INFO - 2025-01-28 15:05:03 --> Helper loaded: html_helper
INFO - 2025-01-28 15:05:03 --> Helper loaded: file_helper
INFO - 2025-01-28 15:05:03 --> Helper loaded: string_helper
INFO - 2025-01-28 15:05:03 --> Helper loaded: form_helper
INFO - 2025-01-28 15:05:03 --> Helper loaded: my_helper
INFO - 2025-01-28 15:05:03 --> Database Driver Class Initialized
INFO - 2025-01-28 15:05:03 --> Upload Class Initialized
INFO - 2025-01-28 15:05:03 --> Email Class Initialized
INFO - 2025-01-28 15:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 15:05:03 --> Form Validation Class Initialized
INFO - 2025-01-28 15:05:03 --> Controller Class Initialized
ERROR - 2025-01-28 20:35:03 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 15:06:00 --> Config Class Initialized
INFO - 2025-01-28 15:06:00 --> Hooks Class Initialized
DEBUG - 2025-01-28 15:06:00 --> UTF-8 Support Enabled
INFO - 2025-01-28 15:06:00 --> Utf8 Class Initialized
INFO - 2025-01-28 15:06:00 --> URI Class Initialized
INFO - 2025-01-28 15:06:00 --> Router Class Initialized
INFO - 2025-01-28 15:06:00 --> Output Class Initialized
INFO - 2025-01-28 15:06:00 --> Security Class Initialized
DEBUG - 2025-01-28 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 15:06:00 --> Input Class Initialized
INFO - 2025-01-28 15:06:00 --> Language Class Initialized
INFO - 2025-01-28 15:06:00 --> Loader Class Initialized
INFO - 2025-01-28 15:06:00 --> Helper loaded: url_helper
INFO - 2025-01-28 15:06:00 --> Helper loaded: html_helper
INFO - 2025-01-28 15:06:00 --> Helper loaded: file_helper
INFO - 2025-01-28 15:06:00 --> Helper loaded: string_helper
INFO - 2025-01-28 15:06:00 --> Helper loaded: form_helper
INFO - 2025-01-28 15:06:00 --> Helper loaded: my_helper
INFO - 2025-01-28 15:06:00 --> Database Driver Class Initialized
INFO - 2025-01-28 15:06:00 --> Upload Class Initialized
INFO - 2025-01-28 15:06:00 --> Email Class Initialized
INFO - 2025-01-28 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 15:06:00 --> Form Validation Class Initialized
INFO - 2025-01-28 15:06:00 --> Controller Class Initialized
ERROR - 2025-01-28 20:36:00 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 15:13:01 --> Config Class Initialized
INFO - 2025-01-28 15:13:01 --> Hooks Class Initialized
DEBUG - 2025-01-28 15:13:01 --> UTF-8 Support Enabled
INFO - 2025-01-28 15:13:01 --> Utf8 Class Initialized
INFO - 2025-01-28 15:13:01 --> URI Class Initialized
INFO - 2025-01-28 15:13:01 --> Router Class Initialized
INFO - 2025-01-28 15:13:01 --> Output Class Initialized
INFO - 2025-01-28 15:13:01 --> Security Class Initialized
DEBUG - 2025-01-28 15:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 15:13:01 --> Input Class Initialized
INFO - 2025-01-28 15:13:01 --> Language Class Initialized
INFO - 2025-01-28 15:13:01 --> Loader Class Initialized
INFO - 2025-01-28 15:13:01 --> Helper loaded: url_helper
INFO - 2025-01-28 15:13:01 --> Helper loaded: html_helper
INFO - 2025-01-28 15:13:01 --> Helper loaded: file_helper
INFO - 2025-01-28 15:13:01 --> Helper loaded: string_helper
INFO - 2025-01-28 15:13:01 --> Helper loaded: form_helper
INFO - 2025-01-28 15:13:01 --> Helper loaded: my_helper
INFO - 2025-01-28 15:13:01 --> Database Driver Class Initialized
INFO - 2025-01-28 15:13:01 --> Upload Class Initialized
INFO - 2025-01-28 15:13:01 --> Email Class Initialized
INFO - 2025-01-28 15:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 15:13:01 --> Form Validation Class Initialized
INFO - 2025-01-28 15:13:01 --> Controller Class Initialized
ERROR - 2025-01-28 20:43:01 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 15:13:05 --> Config Class Initialized
INFO - 2025-01-28 15:13:05 --> Hooks Class Initialized
DEBUG - 2025-01-28 15:13:05 --> UTF-8 Support Enabled
INFO - 2025-01-28 15:13:05 --> Utf8 Class Initialized
INFO - 2025-01-28 15:13:05 --> URI Class Initialized
INFO - 2025-01-28 15:13:05 --> Router Class Initialized
INFO - 2025-01-28 15:13:05 --> Output Class Initialized
INFO - 2025-01-28 15:13:05 --> Security Class Initialized
DEBUG - 2025-01-28 15:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 15:13:05 --> Input Class Initialized
INFO - 2025-01-28 15:13:05 --> Language Class Initialized
INFO - 2025-01-28 15:13:05 --> Loader Class Initialized
INFO - 2025-01-28 15:13:05 --> Helper loaded: url_helper
INFO - 2025-01-28 15:13:05 --> Helper loaded: html_helper
INFO - 2025-01-28 15:13:05 --> Helper loaded: file_helper
INFO - 2025-01-28 15:13:05 --> Helper loaded: string_helper
INFO - 2025-01-28 15:13:05 --> Helper loaded: form_helper
INFO - 2025-01-28 15:13:05 --> Helper loaded: my_helper
INFO - 2025-01-28 15:13:05 --> Database Driver Class Initialized
INFO - 2025-01-28 15:13:05 --> Upload Class Initialized
INFO - 2025-01-28 15:13:05 --> Email Class Initialized
INFO - 2025-01-28 15:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 15:13:05 --> Form Validation Class Initialized
INFO - 2025-01-28 15:13:05 --> Controller Class Initialized
ERROR - 2025-01-28 20:43:05 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 15:14:10 --> Config Class Initialized
INFO - 2025-01-28 15:14:10 --> Hooks Class Initialized
DEBUG - 2025-01-28 15:14:10 --> UTF-8 Support Enabled
INFO - 2025-01-28 15:14:10 --> Utf8 Class Initialized
INFO - 2025-01-28 15:14:10 --> URI Class Initialized
INFO - 2025-01-28 15:14:10 --> Router Class Initialized
INFO - 2025-01-28 15:14:10 --> Output Class Initialized
INFO - 2025-01-28 15:14:10 --> Security Class Initialized
DEBUG - 2025-01-28 15:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 15:14:10 --> Input Class Initialized
INFO - 2025-01-28 15:14:10 --> Language Class Initialized
INFO - 2025-01-28 15:14:10 --> Loader Class Initialized
INFO - 2025-01-28 15:14:10 --> Helper loaded: url_helper
INFO - 2025-01-28 15:14:10 --> Helper loaded: html_helper
INFO - 2025-01-28 15:14:10 --> Helper loaded: file_helper
INFO - 2025-01-28 15:14:10 --> Helper loaded: string_helper
INFO - 2025-01-28 15:14:10 --> Helper loaded: form_helper
INFO - 2025-01-28 15:14:10 --> Helper loaded: my_helper
INFO - 2025-01-28 15:14:10 --> Database Driver Class Initialized
INFO - 2025-01-28 15:14:10 --> Upload Class Initialized
INFO - 2025-01-28 15:14:10 --> Email Class Initialized
INFO - 2025-01-28 15:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 15:14:10 --> Form Validation Class Initialized
INFO - 2025-01-28 15:14:10 --> Controller Class Initialized
ERROR - 2025-01-28 20:44:10 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 15:15:29 --> Config Class Initialized
INFO - 2025-01-28 15:15:29 --> Hooks Class Initialized
DEBUG - 2025-01-28 15:15:29 --> UTF-8 Support Enabled
INFO - 2025-01-28 15:15:29 --> Utf8 Class Initialized
INFO - 2025-01-28 15:15:29 --> URI Class Initialized
INFO - 2025-01-28 15:15:29 --> Router Class Initialized
INFO - 2025-01-28 15:15:29 --> Output Class Initialized
INFO - 2025-01-28 15:15:29 --> Security Class Initialized
DEBUG - 2025-01-28 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 15:15:29 --> Input Class Initialized
INFO - 2025-01-28 15:15:29 --> Language Class Initialized
INFO - 2025-01-28 15:15:29 --> Loader Class Initialized
INFO - 2025-01-28 15:15:29 --> Helper loaded: url_helper
INFO - 2025-01-28 15:15:29 --> Helper loaded: html_helper
INFO - 2025-01-28 15:15:29 --> Helper loaded: file_helper
INFO - 2025-01-28 15:15:29 --> Helper loaded: string_helper
INFO - 2025-01-28 15:15:29 --> Helper loaded: form_helper
INFO - 2025-01-28 15:15:29 --> Helper loaded: my_helper
INFO - 2025-01-28 15:15:29 --> Database Driver Class Initialized
INFO - 2025-01-28 15:15:29 --> Upload Class Initialized
INFO - 2025-01-28 15:15:29 --> Email Class Initialized
INFO - 2025-01-28 15:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 15:15:29 --> Form Validation Class Initialized
INFO - 2025-01-28 15:15:29 --> Controller Class Initialized
ERROR - 2025-01-28 20:45:29 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
INFO - 2025-01-28 15:15:42 --> Config Class Initialized
INFO - 2025-01-28 15:15:42 --> Hooks Class Initialized
DEBUG - 2025-01-28 15:15:42 --> UTF-8 Support Enabled
INFO - 2025-01-28 15:15:42 --> Utf8 Class Initialized
INFO - 2025-01-28 15:15:42 --> URI Class Initialized
INFO - 2025-01-28 15:15:42 --> Router Class Initialized
INFO - 2025-01-28 15:15:42 --> Output Class Initialized
INFO - 2025-01-28 15:15:42 --> Security Class Initialized
DEBUG - 2025-01-28 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-28 15:15:42 --> Input Class Initialized
INFO - 2025-01-28 15:15:42 --> Language Class Initialized
INFO - 2025-01-28 15:15:42 --> Loader Class Initialized
INFO - 2025-01-28 15:15:42 --> Helper loaded: url_helper
INFO - 2025-01-28 15:15:42 --> Helper loaded: html_helper
INFO - 2025-01-28 15:15:42 --> Helper loaded: file_helper
INFO - 2025-01-28 15:15:42 --> Helper loaded: string_helper
INFO - 2025-01-28 15:15:42 --> Helper loaded: form_helper
INFO - 2025-01-28 15:15:42 --> Helper loaded: my_helper
INFO - 2025-01-28 15:15:42 --> Database Driver Class Initialized
INFO - 2025-01-28 15:15:42 --> Upload Class Initialized
INFO - 2025-01-28 15:15:42 --> Email Class Initialized
INFO - 2025-01-28 15:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-28 15:15:42 --> Form Validation Class Initialized
INFO - 2025-01-28 15:15:42 --> Controller Class Initialized
ERROR - 2025-01-28 20:45:42 --> Severity: error --> Exception: Cannot access private property LoginController::$MainModel C:\wamp64\www\liveservicesite\system\core\Loader.php 359
