<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-26 03:25:50 --> Config Class Initialized
INFO - 2023-10-26 03:25:50 --> Hooks Class Initialized
DEBUG - 2023-10-26 03:25:50 --> UTF-8 Support Enabled
INFO - 2023-10-26 03:25:50 --> Utf8 Class Initialized
INFO - 2023-10-26 03:25:50 --> URI Class Initialized
INFO - 2023-10-26 03:25:50 --> Router Class Initialized
INFO - 2023-10-26 03:25:50 --> Output Class Initialized
INFO - 2023-10-26 03:25:50 --> Security Class Initialized
DEBUG - 2023-10-26 03:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 03:25:50 --> Input Class Initialized
INFO - 2023-10-26 03:25:50 --> Language Class Initialized
INFO - 2023-10-26 03:25:50 --> Loader Class Initialized
INFO - 2023-10-26 03:25:50 --> Helper loaded: url_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: html_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: file_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: string_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: form_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: my_helper
INFO - 2023-10-26 03:25:50 --> Database Driver Class Initialized
INFO - 2023-10-26 03:25:50 --> Upload Class Initialized
INFO - 2023-10-26 03:25:50 --> Email Class Initialized
DEBUG - 2023-10-26 03:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 03:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 03:25:50 --> Form Validation Class Initialized
INFO - 2023-10-26 03:25:50 --> Controller Class Initialized
INFO - 2023-10-26 08:55:50 --> Model "FrontofficeModel" initialized
INFO - 2023-10-26 08:55:50 --> Model "MainModel" initialized
INFO - 2023-10-26 08:55:50 --> Model "ApiModel" initialized
INFO - 2023-10-26 08:55:50 --> Helper loaded: notification_helper
INFO - 2023-10-26 03:25:50 --> Config Class Initialized
INFO - 2023-10-26 03:25:50 --> Hooks Class Initialized
DEBUG - 2023-10-26 03:25:50 --> UTF-8 Support Enabled
INFO - 2023-10-26 03:25:50 --> Utf8 Class Initialized
INFO - 2023-10-26 03:25:50 --> URI Class Initialized
DEBUG - 2023-10-26 03:25:50 --> No URI present. Default controller set.
INFO - 2023-10-26 03:25:50 --> Router Class Initialized
INFO - 2023-10-26 03:25:50 --> Output Class Initialized
INFO - 2023-10-26 03:25:50 --> Security Class Initialized
DEBUG - 2023-10-26 03:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 03:25:50 --> Input Class Initialized
INFO - 2023-10-26 03:25:50 --> Language Class Initialized
INFO - 2023-10-26 03:25:50 --> Loader Class Initialized
INFO - 2023-10-26 03:25:50 --> Helper loaded: url_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: html_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: file_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: string_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: form_helper
INFO - 2023-10-26 03:25:50 --> Helper loaded: my_helper
INFO - 2023-10-26 03:25:50 --> Database Driver Class Initialized
INFO - 2023-10-26 03:25:50 --> Upload Class Initialized
INFO - 2023-10-26 03:25:50 --> Email Class Initialized
DEBUG - 2023-10-26 03:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 03:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 03:25:50 --> Form Validation Class Initialized
INFO - 2023-10-26 03:25:50 --> Controller Class Initialized
INFO - 2023-10-26 08:55:50 --> Model "MainModel" initialized
INFO - 2023-10-26 08:55:50 --> File loaded: /home/demo/public_html/hotel_management/application/views/auth/login.php
INFO - 2023-10-26 08:55:50 --> Final output sent to browser
DEBUG - 2023-10-26 08:55:50 --> Total execution time: 0.0138
INFO - 2023-10-26 04:47:03 --> Config Class Initialized
INFO - 2023-10-26 04:47:03 --> Hooks Class Initialized
DEBUG - 2023-10-26 04:47:03 --> UTF-8 Support Enabled
INFO - 2023-10-26 04:47:03 --> Utf8 Class Initialized
INFO - 2023-10-26 04:47:03 --> URI Class Initialized
DEBUG - 2023-10-26 04:47:03 --> No URI present. Default controller set.
INFO - 2023-10-26 04:47:03 --> Router Class Initialized
INFO - 2023-10-26 04:47:03 --> Output Class Initialized
INFO - 2023-10-26 04:47:03 --> Security Class Initialized
DEBUG - 2023-10-26 04:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 04:47:03 --> Input Class Initialized
INFO - 2023-10-26 04:47:03 --> Language Class Initialized
INFO - 2023-10-26 04:47:03 --> Loader Class Initialized
INFO - 2023-10-26 04:47:03 --> Helper loaded: url_helper
INFO - 2023-10-26 04:47:03 --> Helper loaded: html_helper
INFO - 2023-10-26 04:47:03 --> Helper loaded: file_helper
INFO - 2023-10-26 04:47:03 --> Helper loaded: string_helper
INFO - 2023-10-26 04:47:03 --> Helper loaded: form_helper
INFO - 2023-10-26 04:47:03 --> Helper loaded: my_helper
INFO - 2023-10-26 04:47:03 --> Database Driver Class Initialized
INFO - 2023-10-26 04:47:03 --> Upload Class Initialized
INFO - 2023-10-26 04:47:03 --> Email Class Initialized
DEBUG - 2023-10-26 04:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-10-26 04:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 04:47:03 --> Form Validation Class Initialized
INFO - 2023-10-26 04:47:03 --> Controller Class Initialized
INFO - 2023-10-26 10:17:03 --> Model "MainModel" initialized
INFO - 2023-10-26 10:17:03 --> File loaded: /home/demo/public_html/hotel_management/application/views/auth/login.php
INFO - 2023-10-26 10:17:03 --> Final output sent to browser
DEBUG - 2023-10-26 10:17:03 --> Total execution time: 0.0196
