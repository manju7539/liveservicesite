<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-22 00:23:23 --> Model "MainModel" initialized
INFO - 2024-12-22 00:23:23 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 00:23:23 --> Final output sent to browser
DEBUG - 2024-12-22 00:23:23 --> Total execution time: 2.3718
INFO - 2024-12-22 00:29:40 --> Model "MainModel" initialized
INFO - 2024-12-22 00:29:40 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 00:29:40 --> Final output sent to browser
DEBUG - 2024-12-22 00:29:40 --> Total execution time: 2.2773
INFO - 2024-12-22 04:39:48 --> Model "MainModel" initialized
INFO - 2024-12-22 04:39:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 04:39:48 --> Final output sent to browser
DEBUG - 2024-12-22 04:39:48 --> Total execution time: 15.5778
INFO - 2024-12-22 04:44:42 --> Model "MainModel" initialized
INFO - 2024-12-22 04:44:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 04:44:42 --> Final output sent to browser
DEBUG - 2024-12-22 04:44:42 --> Total execution time: 54.1131
INFO - 2024-12-22 01:24:04 --> Config Class Initialized
INFO - 2024-12-22 01:24:04 --> Hooks Class Initialized
DEBUG - 2024-12-22 01:24:04 --> UTF-8 Support Enabled
INFO - 2024-12-22 01:24:04 --> Utf8 Class Initialized
INFO - 2024-12-22 01:24:04 --> URI Class Initialized
INFO - 2024-12-22 01:24:04 --> Router Class Initialized
INFO - 2024-12-22 01:24:04 --> Output Class Initialized
INFO - 2024-12-22 01:24:04 --> Security Class Initialized
DEBUG - 2024-12-22 01:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 01:24:04 --> Input Class Initialized
INFO - 2024-12-22 01:24:04 --> Language Class Initialized
ERROR - 2024-12-22 01:24:04 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-22 01:24:04 --> Config Class Initialized
INFO - 2024-12-22 01:24:04 --> Hooks Class Initialized
DEBUG - 2024-12-22 01:24:04 --> UTF-8 Support Enabled
INFO - 2024-12-22 01:24:04 --> Utf8 Class Initialized
INFO - 2024-12-22 01:24:04 --> URI Class Initialized
DEBUG - 2024-12-22 01:24:04 --> No URI present. Default controller set.
INFO - 2024-12-22 01:24:04 --> Router Class Initialized
INFO - 2024-12-22 01:24:04 --> Output Class Initialized
INFO - 2024-12-22 01:24:04 --> Security Class Initialized
DEBUG - 2024-12-22 01:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 01:24:04 --> Input Class Initialized
INFO - 2024-12-22 01:24:04 --> Language Class Initialized
INFO - 2024-12-22 01:24:04 --> Loader Class Initialized
INFO - 2024-12-22 01:24:04 --> Helper loaded: url_helper
INFO - 2024-12-22 01:24:04 --> Helper loaded: html_helper
INFO - 2024-12-22 01:24:04 --> Helper loaded: file_helper
INFO - 2024-12-22 01:24:04 --> Helper loaded: string_helper
INFO - 2024-12-22 01:24:04 --> Helper loaded: form_helper
INFO - 2024-12-22 01:24:04 --> Helper loaded: my_helper
INFO - 2024-12-22 01:24:04 --> Database Driver Class Initialized
INFO - 2024-12-22 01:24:06 --> Upload Class Initialized
INFO - 2024-12-22 01:24:06 --> Email Class Initialized
INFO - 2024-12-22 01:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 01:24:06 --> Form Validation Class Initialized
INFO - 2024-12-22 01:24:06 --> Controller Class Initialized
INFO - 2024-12-22 06:54:06 --> Model "MainModel" initialized
INFO - 2024-12-22 06:54:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 06:54:06 --> Final output sent to browser
DEBUG - 2024-12-22 06:54:06 --> Total execution time: 2.2745
INFO - 2024-12-22 04:25:55 --> Config Class Initialized
INFO - 2024-12-22 04:25:55 --> Hooks Class Initialized
DEBUG - 2024-12-22 04:25:55 --> UTF-8 Support Enabled
INFO - 2024-12-22 04:25:55 --> Utf8 Class Initialized
INFO - 2024-12-22 04:25:55 --> URI Class Initialized
DEBUG - 2024-12-22 04:25:55 --> No URI present. Default controller set.
INFO - 2024-12-22 04:25:55 --> Router Class Initialized
INFO - 2024-12-22 04:25:55 --> Output Class Initialized
INFO - 2024-12-22 04:25:55 --> Security Class Initialized
DEBUG - 2024-12-22 04:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 04:25:55 --> Input Class Initialized
INFO - 2024-12-22 04:25:55 --> Language Class Initialized
INFO - 2024-12-22 04:25:55 --> Loader Class Initialized
INFO - 2024-12-22 04:25:55 --> Helper loaded: url_helper
INFO - 2024-12-22 04:25:55 --> Helper loaded: html_helper
INFO - 2024-12-22 04:25:55 --> Helper loaded: file_helper
INFO - 2024-12-22 04:25:55 --> Helper loaded: string_helper
INFO - 2024-12-22 04:25:55 --> Helper loaded: form_helper
INFO - 2024-12-22 04:25:55 --> Helper loaded: my_helper
INFO - 2024-12-22 04:25:55 --> Database Driver Class Initialized
INFO - 2024-12-22 04:25:57 --> Upload Class Initialized
INFO - 2024-12-22 04:25:57 --> Email Class Initialized
INFO - 2024-12-22 04:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 04:25:57 --> Form Validation Class Initialized
INFO - 2024-12-22 04:25:57 --> Controller Class Initialized
INFO - 2024-12-22 09:55:57 --> Model "MainModel" initialized
INFO - 2024-12-22 09:55:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 09:55:57 --> Final output sent to browser
DEBUG - 2024-12-22 09:55:57 --> Total execution time: 2.2013
INFO - 2024-12-22 04:26:05 --> Config Class Initialized
INFO - 2024-12-22 04:26:05 --> Hooks Class Initialized
DEBUG - 2024-12-22 04:26:05 --> UTF-8 Support Enabled
INFO - 2024-12-22 04:26:05 --> Utf8 Class Initialized
INFO - 2024-12-22 04:26:05 --> URI Class Initialized
DEBUG - 2024-12-22 04:26:05 --> No URI present. Default controller set.
INFO - 2024-12-22 04:26:05 --> Router Class Initialized
INFO - 2024-12-22 04:26:05 --> Output Class Initialized
INFO - 2024-12-22 04:26:05 --> Security Class Initialized
DEBUG - 2024-12-22 04:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 04:26:05 --> Input Class Initialized
INFO - 2024-12-22 04:26:05 --> Language Class Initialized
INFO - 2024-12-22 04:26:05 --> Loader Class Initialized
INFO - 2024-12-22 04:26:05 --> Helper loaded: url_helper
INFO - 2024-12-22 04:26:05 --> Helper loaded: html_helper
INFO - 2024-12-22 04:26:05 --> Helper loaded: file_helper
INFO - 2024-12-22 04:26:05 --> Helper loaded: string_helper
INFO - 2024-12-22 04:26:05 --> Helper loaded: form_helper
INFO - 2024-12-22 04:26:05 --> Helper loaded: my_helper
INFO - 2024-12-22 04:26:05 --> Database Driver Class Initialized
INFO - 2024-12-22 04:26:07 --> Upload Class Initialized
INFO - 2024-12-22 04:26:07 --> Email Class Initialized
INFO - 2024-12-22 04:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 04:26:07 --> Form Validation Class Initialized
INFO - 2024-12-22 04:26:07 --> Controller Class Initialized
INFO - 2024-12-22 09:56:07 --> Model "MainModel" initialized
INFO - 2024-12-22 09:56:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 09:56:07 --> Final output sent to browser
DEBUG - 2024-12-22 09:56:07 --> Total execution time: 2.1808
INFO - 2024-12-22 06:55:37 --> Config Class Initialized
INFO - 2024-12-22 06:55:37 --> Hooks Class Initialized
DEBUG - 2024-12-22 06:55:37 --> UTF-8 Support Enabled
INFO - 2024-12-22 06:55:37 --> Utf8 Class Initialized
INFO - 2024-12-22 06:55:37 --> URI Class Initialized
DEBUG - 2024-12-22 06:55:37 --> No URI present. Default controller set.
INFO - 2024-12-22 06:55:37 --> Router Class Initialized
INFO - 2024-12-22 06:55:37 --> Output Class Initialized
INFO - 2024-12-22 06:55:37 --> Security Class Initialized
DEBUG - 2024-12-22 06:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 06:55:37 --> Input Class Initialized
INFO - 2024-12-22 06:55:37 --> Language Class Initialized
INFO - 2024-12-22 06:55:37 --> Loader Class Initialized
INFO - 2024-12-22 06:55:37 --> Helper loaded: url_helper
INFO - 2024-12-22 06:55:37 --> Helper loaded: html_helper
INFO - 2024-12-22 06:55:37 --> Helper loaded: file_helper
INFO - 2024-12-22 06:55:37 --> Helper loaded: string_helper
INFO - 2024-12-22 06:55:37 --> Helper loaded: form_helper
INFO - 2024-12-22 06:55:37 --> Helper loaded: my_helper
INFO - 2024-12-22 06:55:37 --> Database Driver Class Initialized
INFO - 2024-12-22 06:55:39 --> Upload Class Initialized
INFO - 2024-12-22 06:55:39 --> Email Class Initialized
INFO - 2024-12-22 06:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 06:55:39 --> Form Validation Class Initialized
INFO - 2024-12-22 06:55:39 --> Controller Class Initialized
INFO - 2024-12-22 12:25:39 --> Model "MainModel" initialized
INFO - 2024-12-22 12:25:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 12:25:39 --> Final output sent to browser
DEBUG - 2024-12-22 12:25:39 --> Total execution time: 2.3719
INFO - 2024-12-22 07:17:08 --> Config Class Initialized
INFO - 2024-12-22 07:17:08 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:08 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:08 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:08 --> URI Class Initialized
INFO - 2024-12-22 07:17:08 --> Router Class Initialized
INFO - 2024-12-22 07:17:08 --> Output Class Initialized
INFO - 2024-12-22 07:17:08 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:08 --> Input Class Initialized
INFO - 2024-12-22 07:17:08 --> Language Class Initialized
ERROR - 2024-12-22 07:17:08 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2024-12-22 07:17:09 --> Config Class Initialized
INFO - 2024-12-22 07:17:09 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:09 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:09 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:09 --> URI Class Initialized
INFO - 2024-12-22 07:17:09 --> Router Class Initialized
INFO - 2024-12-22 07:17:09 --> Output Class Initialized
INFO - 2024-12-22 07:17:09 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:09 --> Input Class Initialized
INFO - 2024-12-22 07:17:09 --> Language Class Initialized
ERROR - 2024-12-22 07:17:09 --> 404 Page Not Found: Feed/index
INFO - 2024-12-22 07:17:09 --> Config Class Initialized
INFO - 2024-12-22 07:17:09 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:09 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:09 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:09 --> URI Class Initialized
INFO - 2024-12-22 07:17:09 --> Router Class Initialized
INFO - 2024-12-22 07:17:09 --> Output Class Initialized
INFO - 2024-12-22 07:17:09 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:09 --> Input Class Initialized
INFO - 2024-12-22 07:17:09 --> Language Class Initialized
ERROR - 2024-12-22 07:17:09 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-22 07:17:10 --> Config Class Initialized
INFO - 2024-12-22 07:17:10 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:10 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:10 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:10 --> URI Class Initialized
INFO - 2024-12-22 07:17:10 --> Router Class Initialized
INFO - 2024-12-22 07:17:10 --> Output Class Initialized
INFO - 2024-12-22 07:17:10 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:10 --> Input Class Initialized
INFO - 2024-12-22 07:17:10 --> Language Class Initialized
ERROR - 2024-12-22 07:17:10 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-22 07:17:10 --> Config Class Initialized
INFO - 2024-12-22 07:17:10 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:10 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:10 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:10 --> URI Class Initialized
INFO - 2024-12-22 07:17:10 --> Router Class Initialized
INFO - 2024-12-22 07:17:10 --> Output Class Initialized
INFO - 2024-12-22 07:17:10 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:10 --> Input Class Initialized
INFO - 2024-12-22 07:17:10 --> Language Class Initialized
ERROR - 2024-12-22 07:17:10 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-22 07:17:11 --> Config Class Initialized
INFO - 2024-12-22 07:17:11 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:11 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:11 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:11 --> URI Class Initialized
INFO - 2024-12-22 07:17:11 --> Router Class Initialized
INFO - 2024-12-22 07:17:11 --> Output Class Initialized
INFO - 2024-12-22 07:17:11 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:11 --> Input Class Initialized
INFO - 2024-12-22 07:17:11 --> Language Class Initialized
ERROR - 2024-12-22 07:17:11 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-22 07:17:11 --> Config Class Initialized
INFO - 2024-12-22 07:17:11 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:11 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:11 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:11 --> URI Class Initialized
INFO - 2024-12-22 07:17:11 --> Router Class Initialized
INFO - 2024-12-22 07:17:11 --> Output Class Initialized
INFO - 2024-12-22 07:17:11 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:11 --> Input Class Initialized
INFO - 2024-12-22 07:17:11 --> Language Class Initialized
ERROR - 2024-12-22 07:17:11 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-22 07:17:12 --> Config Class Initialized
INFO - 2024-12-22 07:17:12 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:12 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:12 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:12 --> URI Class Initialized
INFO - 2024-12-22 07:17:12 --> Router Class Initialized
INFO - 2024-12-22 07:17:12 --> Output Class Initialized
INFO - 2024-12-22 07:17:12 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:12 --> Input Class Initialized
INFO - 2024-12-22 07:17:12 --> Language Class Initialized
ERROR - 2024-12-22 07:17:12 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-22 07:17:12 --> Config Class Initialized
INFO - 2024-12-22 07:17:12 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:12 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:12 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:12 --> URI Class Initialized
INFO - 2024-12-22 07:17:12 --> Router Class Initialized
INFO - 2024-12-22 07:17:12 --> Output Class Initialized
INFO - 2024-12-22 07:17:12 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:12 --> Input Class Initialized
INFO - 2024-12-22 07:17:12 --> Language Class Initialized
ERROR - 2024-12-22 07:17:12 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-22 07:17:12 --> Config Class Initialized
INFO - 2024-12-22 07:17:12 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:12 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:12 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:12 --> URI Class Initialized
INFO - 2024-12-22 07:17:12 --> Router Class Initialized
INFO - 2024-12-22 07:17:12 --> Output Class Initialized
INFO - 2024-12-22 07:17:12 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:12 --> Input Class Initialized
INFO - 2024-12-22 07:17:12 --> Language Class Initialized
ERROR - 2024-12-22 07:17:12 --> 404 Page Not Found: 2021/wp-includes
INFO - 2024-12-22 07:17:13 --> Config Class Initialized
INFO - 2024-12-22 07:17:13 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:13 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:13 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:13 --> URI Class Initialized
INFO - 2024-12-22 07:17:13 --> Router Class Initialized
INFO - 2024-12-22 07:17:13 --> Output Class Initialized
INFO - 2024-12-22 07:17:13 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:13 --> Input Class Initialized
INFO - 2024-12-22 07:17:13 --> Language Class Initialized
ERROR - 2024-12-22 07:17:13 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-22 07:17:13 --> Config Class Initialized
INFO - 2024-12-22 07:17:13 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:13 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:13 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:13 --> URI Class Initialized
INFO - 2024-12-22 07:17:13 --> Router Class Initialized
INFO - 2024-12-22 07:17:13 --> Output Class Initialized
INFO - 2024-12-22 07:17:13 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:13 --> Input Class Initialized
INFO - 2024-12-22 07:17:13 --> Language Class Initialized
ERROR - 2024-12-22 07:17:13 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-22 07:17:14 --> Config Class Initialized
INFO - 2024-12-22 07:17:14 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:14 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:14 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:14 --> URI Class Initialized
INFO - 2024-12-22 07:17:14 --> Router Class Initialized
INFO - 2024-12-22 07:17:14 --> Output Class Initialized
INFO - 2024-12-22 07:17:14 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:14 --> Input Class Initialized
INFO - 2024-12-22 07:17:14 --> Language Class Initialized
ERROR - 2024-12-22 07:17:14 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-22 07:17:14 --> Config Class Initialized
INFO - 2024-12-22 07:17:14 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:14 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:14 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:14 --> URI Class Initialized
INFO - 2024-12-22 07:17:14 --> Router Class Initialized
INFO - 2024-12-22 07:17:14 --> Output Class Initialized
INFO - 2024-12-22 07:17:14 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:14 --> Input Class Initialized
INFO - 2024-12-22 07:17:14 --> Language Class Initialized
ERROR - 2024-12-22 07:17:14 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-22 07:17:15 --> Config Class Initialized
INFO - 2024-12-22 07:17:15 --> Hooks Class Initialized
DEBUG - 2024-12-22 07:17:15 --> UTF-8 Support Enabled
INFO - 2024-12-22 07:17:15 --> Utf8 Class Initialized
INFO - 2024-12-22 07:17:15 --> URI Class Initialized
INFO - 2024-12-22 07:17:15 --> Router Class Initialized
INFO - 2024-12-22 07:17:15 --> Output Class Initialized
INFO - 2024-12-22 07:17:15 --> Security Class Initialized
DEBUG - 2024-12-22 07:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 07:17:15 --> Input Class Initialized
INFO - 2024-12-22 07:17:15 --> Language Class Initialized
ERROR - 2024-12-22 07:17:15 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-22 12:19:50 --> Config Class Initialized
INFO - 2024-12-22 12:19:50 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:50 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:50 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:50 --> URI Class Initialized
DEBUG - 2024-12-22 12:19:50 --> No URI present. Default controller set.
INFO - 2024-12-22 12:19:50 --> Router Class Initialized
INFO - 2024-12-22 12:19:50 --> Output Class Initialized
INFO - 2024-12-22 12:19:50 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:50 --> Input Class Initialized
INFO - 2024-12-22 12:19:50 --> Language Class Initialized
INFO - 2024-12-22 12:19:50 --> Loader Class Initialized
INFO - 2024-12-22 12:19:50 --> Helper loaded: url_helper
INFO - 2024-12-22 12:19:50 --> Helper loaded: html_helper
INFO - 2024-12-22 12:19:50 --> Helper loaded: file_helper
INFO - 2024-12-22 12:19:50 --> Helper loaded: string_helper
INFO - 2024-12-22 12:19:50 --> Helper loaded: form_helper
INFO - 2024-12-22 12:19:50 --> Helper loaded: my_helper
INFO - 2024-12-22 12:19:50 --> Database Driver Class Initialized
INFO - 2024-12-22 12:19:52 --> Upload Class Initialized
INFO - 2024-12-22 12:19:52 --> Email Class Initialized
INFO - 2024-12-22 12:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 12:19:52 --> Form Validation Class Initialized
INFO - 2024-12-22 12:19:52 --> Controller Class Initialized
INFO - 2024-12-22 17:49:52 --> Model "MainModel" initialized
INFO - 2024-12-22 17:49:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 17:49:52 --> Final output sent to browser
DEBUG - 2024-12-22 17:49:52 --> Total execution time: 2.2831
INFO - 2024-12-22 12:19:52 --> Config Class Initialized
INFO - 2024-12-22 12:19:52 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:52 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:52 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:52 --> URI Class Initialized
INFO - 2024-12-22 12:19:52 --> Router Class Initialized
INFO - 2024-12-22 12:19:52 --> Output Class Initialized
INFO - 2024-12-22 12:19:52 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:52 --> Input Class Initialized
INFO - 2024-12-22 12:19:52 --> Language Class Initialized
ERROR - 2024-12-22 12:19:52 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-22 12:19:53 --> Config Class Initialized
INFO - 2024-12-22 12:19:53 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:53 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:53 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:53 --> URI Class Initialized
INFO - 2024-12-22 12:19:53 --> Router Class Initialized
INFO - 2024-12-22 12:19:53 --> Output Class Initialized
INFO - 2024-12-22 12:19:53 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:53 --> Input Class Initialized
INFO - 2024-12-22 12:19:53 --> Language Class Initialized
ERROR - 2024-12-22 12:19:53 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-22 12:19:53 --> Config Class Initialized
INFO - 2024-12-22 12:19:53 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:54 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:54 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:54 --> URI Class Initialized
DEBUG - 2024-12-22 12:19:54 --> No URI present. Default controller set.
INFO - 2024-12-22 12:19:54 --> Router Class Initialized
INFO - 2024-12-22 12:19:54 --> Output Class Initialized
INFO - 2024-12-22 12:19:54 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:54 --> Input Class Initialized
INFO - 2024-12-22 12:19:54 --> Language Class Initialized
INFO - 2024-12-22 12:19:54 --> Loader Class Initialized
INFO - 2024-12-22 12:19:54 --> Helper loaded: url_helper
INFO - 2024-12-22 12:19:54 --> Helper loaded: html_helper
INFO - 2024-12-22 12:19:54 --> Helper loaded: file_helper
INFO - 2024-12-22 12:19:54 --> Helper loaded: string_helper
INFO - 2024-12-22 12:19:54 --> Helper loaded: form_helper
INFO - 2024-12-22 12:19:54 --> Helper loaded: my_helper
INFO - 2024-12-22 12:19:54 --> Database Driver Class Initialized
INFO - 2024-12-22 12:19:56 --> Upload Class Initialized
INFO - 2024-12-22 12:19:56 --> Email Class Initialized
INFO - 2024-12-22 12:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 12:19:56 --> Form Validation Class Initialized
INFO - 2024-12-22 12:19:56 --> Controller Class Initialized
INFO - 2024-12-22 17:49:56 --> Model "MainModel" initialized
INFO - 2024-12-22 17:49:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 17:49:56 --> Final output sent to browser
DEBUG - 2024-12-22 17:49:56 --> Total execution time: 2.1363
INFO - 2024-12-22 12:19:56 --> Config Class Initialized
INFO - 2024-12-22 12:19:56 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:56 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:56 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:56 --> URI Class Initialized
INFO - 2024-12-22 12:19:56 --> Router Class Initialized
INFO - 2024-12-22 12:19:56 --> Output Class Initialized
INFO - 2024-12-22 12:19:56 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:56 --> Input Class Initialized
INFO - 2024-12-22 12:19:56 --> Language Class Initialized
ERROR - 2024-12-22 12:19:56 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-22 12:19:56 --> Config Class Initialized
INFO - 2024-12-22 12:19:56 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:56 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:56 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:56 --> URI Class Initialized
INFO - 2024-12-22 12:19:56 --> Router Class Initialized
INFO - 2024-12-22 12:19:56 --> Output Class Initialized
INFO - 2024-12-22 12:19:56 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:56 --> Input Class Initialized
INFO - 2024-12-22 12:19:56 --> Language Class Initialized
ERROR - 2024-12-22 12:19:56 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-22 12:19:57 --> Config Class Initialized
INFO - 2024-12-22 12:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:57 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:57 --> URI Class Initialized
INFO - 2024-12-22 12:19:57 --> Router Class Initialized
INFO - 2024-12-22 12:19:57 --> Output Class Initialized
INFO - 2024-12-22 12:19:57 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:57 --> Input Class Initialized
INFO - 2024-12-22 12:19:57 --> Language Class Initialized
ERROR - 2024-12-22 12:19:57 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-22 12:19:57 --> Config Class Initialized
INFO - 2024-12-22 12:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:57 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:57 --> URI Class Initialized
INFO - 2024-12-22 12:19:57 --> Router Class Initialized
INFO - 2024-12-22 12:19:57 --> Output Class Initialized
INFO - 2024-12-22 12:19:57 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:57 --> Input Class Initialized
INFO - 2024-12-22 12:19:57 --> Language Class Initialized
ERROR - 2024-12-22 12:19:57 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-22 12:19:57 --> Config Class Initialized
INFO - 2024-12-22 12:19:57 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:57 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:57 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:57 --> URI Class Initialized
INFO - 2024-12-22 12:19:57 --> Router Class Initialized
INFO - 2024-12-22 12:19:57 --> Output Class Initialized
INFO - 2024-12-22 12:19:57 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:57 --> Input Class Initialized
INFO - 2024-12-22 12:19:57 --> Language Class Initialized
ERROR - 2024-12-22 12:19:57 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-22 12:19:58 --> Config Class Initialized
INFO - 2024-12-22 12:19:58 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:58 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:58 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:58 --> URI Class Initialized
INFO - 2024-12-22 12:19:58 --> Router Class Initialized
INFO - 2024-12-22 12:19:58 --> Output Class Initialized
INFO - 2024-12-22 12:19:58 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:58 --> Input Class Initialized
INFO - 2024-12-22 12:19:58 --> Language Class Initialized
ERROR - 2024-12-22 12:19:58 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-22 12:19:58 --> Config Class Initialized
INFO - 2024-12-22 12:19:58 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:58 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:58 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:58 --> URI Class Initialized
INFO - 2024-12-22 12:19:58 --> Router Class Initialized
INFO - 2024-12-22 12:19:58 --> Output Class Initialized
INFO - 2024-12-22 12:19:58 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:58 --> Input Class Initialized
INFO - 2024-12-22 12:19:58 --> Language Class Initialized
ERROR - 2024-12-22 12:19:58 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-22 12:19:59 --> Config Class Initialized
INFO - 2024-12-22 12:19:59 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:59 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:59 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:59 --> URI Class Initialized
INFO - 2024-12-22 12:19:59 --> Router Class Initialized
INFO - 2024-12-22 12:19:59 --> Output Class Initialized
INFO - 2024-12-22 12:19:59 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:59 --> Input Class Initialized
INFO - 2024-12-22 12:19:59 --> Language Class Initialized
ERROR - 2024-12-22 12:19:59 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-22 12:19:59 --> Config Class Initialized
INFO - 2024-12-22 12:19:59 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:19:59 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:19:59 --> Utf8 Class Initialized
INFO - 2024-12-22 12:19:59 --> URI Class Initialized
INFO - 2024-12-22 12:19:59 --> Router Class Initialized
INFO - 2024-12-22 12:19:59 --> Output Class Initialized
INFO - 2024-12-22 12:19:59 --> Security Class Initialized
DEBUG - 2024-12-22 12:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:19:59 --> Input Class Initialized
INFO - 2024-12-22 12:19:59 --> Language Class Initialized
ERROR - 2024-12-22 12:19:59 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-22 12:20:00 --> Config Class Initialized
INFO - 2024-12-22 12:20:00 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:20:00 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:20:00 --> Utf8 Class Initialized
INFO - 2024-12-22 12:20:00 --> URI Class Initialized
INFO - 2024-12-22 12:20:00 --> Router Class Initialized
INFO - 2024-12-22 12:20:00 --> Output Class Initialized
INFO - 2024-12-22 12:20:00 --> Security Class Initialized
DEBUG - 2024-12-22 12:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:20:00 --> Input Class Initialized
INFO - 2024-12-22 12:20:00 --> Language Class Initialized
ERROR - 2024-12-22 12:20:00 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-22 12:20:00 --> Config Class Initialized
INFO - 2024-12-22 12:20:00 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:20:00 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:20:00 --> Utf8 Class Initialized
INFO - 2024-12-22 12:20:00 --> URI Class Initialized
INFO - 2024-12-22 12:20:00 --> Router Class Initialized
INFO - 2024-12-22 12:20:00 --> Output Class Initialized
INFO - 2024-12-22 12:20:00 --> Security Class Initialized
DEBUG - 2024-12-22 12:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:20:00 --> Input Class Initialized
INFO - 2024-12-22 12:20:00 --> Language Class Initialized
ERROR - 2024-12-22 12:20:00 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-22 12:20:00 --> Config Class Initialized
INFO - 2024-12-22 12:20:00 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:20:00 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:20:00 --> Utf8 Class Initialized
INFO - 2024-12-22 12:20:00 --> URI Class Initialized
INFO - 2024-12-22 12:20:00 --> Router Class Initialized
INFO - 2024-12-22 12:20:00 --> Output Class Initialized
INFO - 2024-12-22 12:20:00 --> Security Class Initialized
DEBUG - 2024-12-22 12:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:20:00 --> Input Class Initialized
INFO - 2024-12-22 12:20:00 --> Language Class Initialized
ERROR - 2024-12-22 12:20:00 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-22 12:20:01 --> Config Class Initialized
INFO - 2024-12-22 12:20:01 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:20:01 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:20:01 --> Utf8 Class Initialized
INFO - 2024-12-22 12:20:01 --> URI Class Initialized
INFO - 2024-12-22 12:20:01 --> Router Class Initialized
INFO - 2024-12-22 12:20:01 --> Output Class Initialized
INFO - 2024-12-22 12:20:01 --> Security Class Initialized
DEBUG - 2024-12-22 12:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:20:01 --> Input Class Initialized
INFO - 2024-12-22 12:20:01 --> Language Class Initialized
ERROR - 2024-12-22 12:20:01 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-22 12:20:01 --> Config Class Initialized
INFO - 2024-12-22 12:20:01 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:20:01 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:20:01 --> Utf8 Class Initialized
INFO - 2024-12-22 12:20:01 --> URI Class Initialized
INFO - 2024-12-22 12:20:01 --> Router Class Initialized
INFO - 2024-12-22 12:20:01 --> Output Class Initialized
INFO - 2024-12-22 12:20:01 --> Security Class Initialized
DEBUG - 2024-12-22 12:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:20:01 --> Input Class Initialized
INFO - 2024-12-22 12:20:01 --> Language Class Initialized
ERROR - 2024-12-22 12:20:01 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-22 12:20:01 --> Config Class Initialized
INFO - 2024-12-22 12:20:01 --> Hooks Class Initialized
DEBUG - 2024-12-22 12:20:01 --> UTF-8 Support Enabled
INFO - 2024-12-22 12:20:01 --> Utf8 Class Initialized
INFO - 2024-12-22 12:20:01 --> URI Class Initialized
INFO - 2024-12-22 12:20:01 --> Router Class Initialized
INFO - 2024-12-22 12:20:02 --> Output Class Initialized
INFO - 2024-12-22 12:20:02 --> Security Class Initialized
DEBUG - 2024-12-22 12:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 12:20:02 --> Input Class Initialized
INFO - 2024-12-22 12:20:02 --> Language Class Initialized
ERROR - 2024-12-22 12:20:02 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-12-22 14:23:21 --> Config Class Initialized
INFO - 2024-12-22 14:23:21 --> Hooks Class Initialized
DEBUG - 2024-12-22 14:23:21 --> UTF-8 Support Enabled
INFO - 2024-12-22 14:23:21 --> Utf8 Class Initialized
INFO - 2024-12-22 14:23:21 --> URI Class Initialized
DEBUG - 2024-12-22 14:23:21 --> No URI present. Default controller set.
INFO - 2024-12-22 14:23:21 --> Router Class Initialized
INFO - 2024-12-22 14:23:21 --> Output Class Initialized
INFO - 2024-12-22 14:23:21 --> Security Class Initialized
DEBUG - 2024-12-22 14:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 14:23:21 --> Input Class Initialized
INFO - 2024-12-22 14:23:21 --> Language Class Initialized
INFO - 2024-12-22 14:23:21 --> Loader Class Initialized
INFO - 2024-12-22 14:23:21 --> Helper loaded: url_helper
INFO - 2024-12-22 14:23:21 --> Helper loaded: html_helper
INFO - 2024-12-22 14:23:21 --> Helper loaded: file_helper
INFO - 2024-12-22 14:23:21 --> Helper loaded: string_helper
INFO - 2024-12-22 14:23:21 --> Helper loaded: form_helper
INFO - 2024-12-22 14:23:21 --> Helper loaded: my_helper
INFO - 2024-12-22 14:23:21 --> Database Driver Class Initialized
INFO - 2024-12-22 14:23:23 --> Upload Class Initialized
INFO - 2024-12-22 14:23:23 --> Email Class Initialized
INFO - 2024-12-22 14:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 14:23:23 --> Form Validation Class Initialized
INFO - 2024-12-22 14:23:23 --> Controller Class Initialized
INFO - 2024-12-22 19:53:23 --> Model "MainModel" initialized
INFO - 2024-12-22 19:53:23 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 19:53:23 --> Final output sent to browser
DEBUG - 2024-12-22 19:53:23 --> Total execution time: 2.3170
INFO - 2024-12-22 16:48:59 --> Config Class Initialized
INFO - 2024-12-22 16:48:59 --> Hooks Class Initialized
DEBUG - 2024-12-22 16:48:59 --> UTF-8 Support Enabled
INFO - 2024-12-22 16:48:59 --> Utf8 Class Initialized
INFO - 2024-12-22 16:48:59 --> URI Class Initialized
INFO - 2024-12-22 16:48:59 --> Router Class Initialized
INFO - 2024-12-22 16:48:59 --> Output Class Initialized
INFO - 2024-12-22 16:48:59 --> Security Class Initialized
DEBUG - 2024-12-22 16:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 16:48:59 --> Input Class Initialized
INFO - 2024-12-22 16:48:59 --> Language Class Initialized
ERROR - 2024-12-22 16:48:59 --> 404 Page Not Found: Wp-admin/setup-config.php
INFO - 2024-12-22 16:48:59 --> Config Class Initialized
INFO - 2024-12-22 16:48:59 --> Hooks Class Initialized
DEBUG - 2024-12-22 16:48:59 --> UTF-8 Support Enabled
INFO - 2024-12-22 16:48:59 --> Utf8 Class Initialized
INFO - 2024-12-22 16:48:59 --> URI Class Initialized
INFO - 2024-12-22 16:48:59 --> Router Class Initialized
INFO - 2024-12-22 16:48:59 --> Output Class Initialized
INFO - 2024-12-22 16:48:59 --> Security Class Initialized
DEBUG - 2024-12-22 16:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 16:48:59 --> Input Class Initialized
INFO - 2024-12-22 16:48:59 --> Language Class Initialized
ERROR - 2024-12-22 16:48:59 --> 404 Page Not Found: Wordpress/wp-admin
INFO - 2024-12-22 17:34:37 --> Config Class Initialized
INFO - 2024-12-22 17:34:37 --> Hooks Class Initialized
DEBUG - 2024-12-22 17:34:37 --> UTF-8 Support Enabled
INFO - 2024-12-22 17:34:37 --> Utf8 Class Initialized
INFO - 2024-12-22 17:34:37 --> URI Class Initialized
DEBUG - 2024-12-22 17:34:37 --> No URI present. Default controller set.
INFO - 2024-12-22 17:34:37 --> Router Class Initialized
INFO - 2024-12-22 17:34:37 --> Output Class Initialized
INFO - 2024-12-22 17:34:37 --> Security Class Initialized
DEBUG - 2024-12-22 17:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-22 17:34:37 --> Input Class Initialized
INFO - 2024-12-22 17:34:37 --> Language Class Initialized
INFO - 2024-12-22 17:34:37 --> Loader Class Initialized
INFO - 2024-12-22 17:34:37 --> Helper loaded: url_helper
INFO - 2024-12-22 17:34:37 --> Helper loaded: html_helper
INFO - 2024-12-22 17:34:37 --> Helper loaded: file_helper
INFO - 2024-12-22 17:34:37 --> Helper loaded: string_helper
INFO - 2024-12-22 17:34:37 --> Helper loaded: form_helper
INFO - 2024-12-22 17:34:37 --> Helper loaded: my_helper
INFO - 2024-12-22 17:34:37 --> Database Driver Class Initialized
INFO - 2024-12-22 17:34:40 --> Upload Class Initialized
INFO - 2024-12-22 17:34:40 --> Email Class Initialized
INFO - 2024-12-22 17:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-22 17:34:40 --> Form Validation Class Initialized
INFO - 2024-12-22 17:34:40 --> Controller Class Initialized
INFO - 2024-12-22 23:04:40 --> Model "MainModel" initialized
INFO - 2024-12-22 23:04:40 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-22 23:04:40 --> Final output sent to browser
DEBUG - 2024-12-22 23:04:40 --> Total execution time: 2.2132
