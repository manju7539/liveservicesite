<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-14 01:27:48 --> Model "MainModel" initialized
INFO - 2024-12-14 01:27:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-14 01:27:48 --> Final output sent to browser
DEBUG - 2024-12-14 01:27:48 --> Total execution time: 2.3516
INFO - 2024-12-14 01:27:51 --> Model "MainModel" initialized
INFO - 2024-12-14 01:27:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-14 01:27:51 --> Final output sent to browser
DEBUG - 2024-12-14 01:27:51 --> Total execution time: 2.1855
