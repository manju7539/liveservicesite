<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-01 09:02:57 --> Config Class Initialized
INFO - 2024-12-01 09:02:57 --> Hooks Class Initialized
DEBUG - 2024-12-01 09:02:57 --> UTF-8 Support Enabled
INFO - 2024-12-01 09:02:57 --> Utf8 Class Initialized
INFO - 2024-12-01 09:02:57 --> URI Class Initialized
DEBUG - 2024-12-01 09:02:57 --> No URI present. Default controller set.
INFO - 2024-12-01 09:02:57 --> Router Class Initialized
INFO - 2024-12-01 09:02:57 --> Output Class Initialized
INFO - 2024-12-01 09:02:57 --> Security Class Initialized
DEBUG - 2024-12-01 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 09:02:57 --> Input Class Initialized
INFO - 2024-12-01 09:02:57 --> Language Class Initialized
INFO - 2024-12-01 09:02:58 --> Loader Class Initialized
INFO - 2024-12-01 09:02:58 --> Helper loaded: url_helper
INFO - 2024-12-01 09:02:58 --> Helper loaded: html_helper
INFO - 2024-12-01 09:02:58 --> Helper loaded: file_helper
INFO - 2024-12-01 09:02:58 --> Helper loaded: string_helper
INFO - 2024-12-01 09:02:58 --> Helper loaded: form_helper
INFO - 2024-12-01 09:02:58 --> Helper loaded: my_helper
INFO - 2024-12-01 09:02:58 --> Database Driver Class Initialized
INFO - 2024-12-01 09:03:00 --> Upload Class Initialized
INFO - 2024-12-01 09:03:00 --> Email Class Initialized
INFO - 2024-12-01 09:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 09:03:00 --> Form Validation Class Initialized
INFO - 2024-12-01 09:03:00 --> Controller Class Initialized
INFO - 2024-12-01 14:33:00 --> Model "MainModel" initialized
INFO - 2024-12-01 14:33:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-01 14:33:00 --> Final output sent to browser
DEBUG - 2024-12-01 14:33:00 --> Total execution time: 2.6299
INFO - 2024-12-01 12:23:11 --> Config Class Initialized
INFO - 2024-12-01 12:23:11 --> Hooks Class Initialized
DEBUG - 2024-12-01 12:23:11 --> UTF-8 Support Enabled
INFO - 2024-12-01 12:23:11 --> Utf8 Class Initialized
INFO - 2024-12-01 12:23:11 --> URI Class Initialized
INFO - 2024-12-01 12:23:11 --> Router Class Initialized
INFO - 2024-12-01 12:23:11 --> Output Class Initialized
INFO - 2024-12-01 12:23:11 --> Security Class Initialized
DEBUG - 2024-12-01 12:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 12:23:11 --> Input Class Initialized
INFO - 2024-12-01 12:23:11 --> Language Class Initialized
ERROR - 2024-12-01 12:23:11 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-01 12:23:12 --> Config Class Initialized
INFO - 2024-12-01 12:23:12 --> Hooks Class Initialized
DEBUG - 2024-12-01 12:23:12 --> UTF-8 Support Enabled
INFO - 2024-12-01 12:23:12 --> Utf8 Class Initialized
INFO - 2024-12-01 12:23:12 --> URI Class Initialized
DEBUG - 2024-12-01 12:23:12 --> No URI present. Default controller set.
INFO - 2024-12-01 12:23:12 --> Router Class Initialized
INFO - 2024-12-01 12:23:12 --> Output Class Initialized
INFO - 2024-12-01 12:23:12 --> Security Class Initialized
DEBUG - 2024-12-01 12:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 12:23:12 --> Input Class Initialized
INFO - 2024-12-01 12:23:12 --> Language Class Initialized
INFO - 2024-12-01 12:23:12 --> Loader Class Initialized
INFO - 2024-12-01 12:23:12 --> Helper loaded: url_helper
INFO - 2024-12-01 12:23:12 --> Helper loaded: html_helper
INFO - 2024-12-01 12:23:12 --> Helper loaded: file_helper
INFO - 2024-12-01 12:23:12 --> Helper loaded: string_helper
INFO - 2024-12-01 12:23:12 --> Helper loaded: form_helper
INFO - 2024-12-01 12:23:12 --> Helper loaded: my_helper
INFO - 2024-12-01 12:23:12 --> Database Driver Class Initialized
INFO - 2024-12-01 12:23:14 --> Upload Class Initialized
INFO - 2024-12-01 12:23:14 --> Email Class Initialized
INFO - 2024-12-01 12:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 12:23:14 --> Form Validation Class Initialized
INFO - 2024-12-01 12:23:14 --> Controller Class Initialized
INFO - 2024-12-01 17:53:14 --> Model "MainModel" initialized
INFO - 2024-12-01 17:53:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-01 17:53:14 --> Final output sent to browser
DEBUG - 2024-12-01 17:53:14 --> Total execution time: 2.2393
