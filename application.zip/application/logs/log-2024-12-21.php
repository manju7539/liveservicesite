<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-21 10:36:50 --> Config Class Initialized
INFO - 2024-12-21 10:36:50 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:36:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:36:51 --> Utf8 Class Initialized
INFO - 2024-12-21 10:36:51 --> URI Class Initialized
DEBUG - 2024-12-21 10:36:51 --> No URI present. Default controller set.
INFO - 2024-12-21 10:36:51 --> Router Class Initialized
INFO - 2024-12-21 10:36:51 --> Output Class Initialized
INFO - 2024-12-21 10:36:51 --> Security Class Initialized
DEBUG - 2024-12-21 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:36:51 --> Input Class Initialized
INFO - 2024-12-21 10:36:51 --> Language Class Initialized
INFO - 2024-12-21 10:36:51 --> Loader Class Initialized
INFO - 2024-12-21 10:36:51 --> Helper loaded: url_helper
INFO - 2024-12-21 10:36:51 --> Helper loaded: html_helper
INFO - 2024-12-21 10:36:51 --> Helper loaded: file_helper
INFO - 2024-12-21 10:36:51 --> Helper loaded: string_helper
INFO - 2024-12-21 10:36:51 --> Helper loaded: form_helper
INFO - 2024-12-21 10:36:51 --> Helper loaded: my_helper
INFO - 2024-12-21 10:36:51 --> Database Driver Class Initialized
INFO - 2024-12-21 10:36:53 --> Upload Class Initialized
INFO - 2024-12-21 10:36:54 --> Email Class Initialized
INFO - 2024-12-21 10:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:36:54 --> Form Validation Class Initialized
INFO - 2024-12-21 10:36:54 --> Controller Class Initialized
INFO - 2024-12-21 16:06:54 --> Model "MainModel" initialized
INFO - 2024-12-21 16:06:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:06:54 --> Final output sent to browser
DEBUG - 2024-12-21 16:06:54 --> Total execution time: 3.5615
INFO - 2024-12-21 10:36:55 --> Config Class Initialized
INFO - 2024-12-21 10:36:55 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:36:55 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:36:55 --> Utf8 Class Initialized
INFO - 2024-12-21 10:36:55 --> URI Class Initialized
INFO - 2024-12-21 10:36:55 --> Router Class Initialized
INFO - 2024-12-21 10:36:55 --> Output Class Initialized
INFO - 2024-12-21 10:36:55 --> Security Class Initialized
DEBUG - 2024-12-21 10:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:36:55 --> Input Class Initialized
INFO - 2024-12-21 10:36:55 --> Language Class Initialized
ERROR - 2024-12-21 10:36:55 --> 404 Page Not Found: Actuator/env
INFO - 2024-12-21 10:36:56 --> Config Class Initialized
INFO - 2024-12-21 10:36:56 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:36:56 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:36:56 --> Utf8 Class Initialized
INFO - 2024-12-21 10:36:56 --> URI Class Initialized
INFO - 2024-12-21 10:36:56 --> Router Class Initialized
INFO - 2024-12-21 10:36:56 --> Output Class Initialized
INFO - 2024-12-21 10:36:56 --> Security Class Initialized
DEBUG - 2024-12-21 10:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:36:56 --> Input Class Initialized
INFO - 2024-12-21 10:36:56 --> Language Class Initialized
ERROR - 2024-12-21 10:36:56 --> 404 Page Not Found: Server/index
INFO - 2024-12-21 10:36:57 --> Config Class Initialized
INFO - 2024-12-21 10:36:57 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:36:57 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:36:57 --> Utf8 Class Initialized
INFO - 2024-12-21 10:36:57 --> URI Class Initialized
INFO - 2024-12-21 10:36:57 --> Router Class Initialized
INFO - 2024-12-21 10:36:57 --> Output Class Initialized
INFO - 2024-12-21 10:36:57 --> Security Class Initialized
DEBUG - 2024-12-21 10:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:36:57 --> Input Class Initialized
INFO - 2024-12-21 10:36:57 --> Language Class Initialized
ERROR - 2024-12-21 10:36:57 --> 404 Page Not Found: AHT/AHT_UI
INFO - 2024-12-21 10:36:58 --> Config Class Initialized
INFO - 2024-12-21 10:36:58 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:36:58 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:36:58 --> Utf8 Class Initialized
INFO - 2024-12-21 10:36:58 --> URI Class Initialized
INFO - 2024-12-21 10:36:58 --> Router Class Initialized
INFO - 2024-12-21 10:36:58 --> Output Class Initialized
INFO - 2024-12-21 10:36:58 --> Security Class Initialized
DEBUG - 2024-12-21 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:36:58 --> Input Class Initialized
INFO - 2024-12-21 10:36:58 --> Language Class Initialized
ERROR - 2024-12-21 10:36:58 --> 404 Page Not Found: Vscode/sftp.json
INFO - 2024-12-21 10:36:58 --> Config Class Initialized
INFO - 2024-12-21 10:36:58 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:36:58 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:36:58 --> Utf8 Class Initialized
INFO - 2024-12-21 10:36:58 --> URI Class Initialized
INFO - 2024-12-21 10:36:58 --> Router Class Initialized
INFO - 2024-12-21 10:36:58 --> Output Class Initialized
INFO - 2024-12-21 10:36:58 --> Security Class Initialized
DEBUG - 2024-12-21 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:36:58 --> Input Class Initialized
INFO - 2024-12-21 10:36:58 --> Language Class Initialized
ERROR - 2024-12-21 10:36:59 --> 404 Page Not Found: About/index
INFO - 2024-12-21 10:36:59 --> Config Class Initialized
INFO - 2024-12-21 10:36:59 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:36:59 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:36:59 --> Utf8 Class Initialized
INFO - 2024-12-21 10:36:59 --> URI Class Initialized
INFO - 2024-12-21 10:36:59 --> Router Class Initialized
INFO - 2024-12-21 10:36:59 --> Output Class Initialized
INFO - 2024-12-21 10:36:59 --> Security Class Initialized
DEBUG - 2024-12-21 10:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:36:59 --> Input Class Initialized
INFO - 2024-12-21 10:36:59 --> Language Class Initialized
ERROR - 2024-12-21 10:36:59 --> 404 Page Not Found: Debug/default
INFO - 2024-12-21 10:37:00 --> Config Class Initialized
INFO - 2024-12-21 10:37:00 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:00 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:00 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:00 --> URI Class Initialized
INFO - 2024-12-21 10:37:00 --> Router Class Initialized
INFO - 2024-12-21 10:37:00 --> Output Class Initialized
INFO - 2024-12-21 10:37:00 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:00 --> Input Class Initialized
INFO - 2024-12-21 10:37:00 --> Language Class Initialized
ERROR - 2024-12-21 10:37:00 --> 404 Page Not Found: V2/_catalog
INFO - 2024-12-21 10:37:01 --> Config Class Initialized
INFO - 2024-12-21 10:37:01 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:01 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:01 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:01 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:01 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:01 --> Router Class Initialized
INFO - 2024-12-21 10:37:01 --> Output Class Initialized
INFO - 2024-12-21 10:37:01 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:01 --> Input Class Initialized
INFO - 2024-12-21 10:37:01 --> Language Class Initialized
INFO - 2024-12-21 10:37:01 --> Loader Class Initialized
INFO - 2024-12-21 10:37:01 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:01 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:01 --> Config Class Initialized
INFO - 2024-12-21 10:37:01 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:01 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:01 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:01 --> Config Class Initialized
INFO - 2024-12-21 10:37:01 --> Hooks Class Initialized
INFO - 2024-12-21 10:37:01 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:01 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:01 --> Utf8 Class Initialized
DEBUG - 2024-12-21 10:37:01 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:01 --> URI Class Initialized
INFO - 2024-12-21 10:37:01 --> Router Class Initialized
INFO - 2024-12-21 10:37:01 --> Output Class Initialized
INFO - 2024-12-21 10:37:01 --> Security Class Initialized
INFO - 2024-12-21 10:37:01 --> Router Class Initialized
DEBUG - 2024-12-21 10:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:01 --> Output Class Initialized
INFO - 2024-12-21 10:37:01 --> Input Class Initialized
INFO - 2024-12-21 10:37:01 --> Security Class Initialized
INFO - 2024-12-21 10:37:01 --> Language Class Initialized
DEBUG - 2024-12-21 10:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:01 --> Input Class Initialized
INFO - 2024-12-21 10:37:01 --> Loader Class Initialized
INFO - 2024-12-21 10:37:01 --> Language Class Initialized
ERROR - 2024-12-21 10:37:01 --> 404 Page Not Found: Ecp/Current
INFO - 2024-12-21 10:37:01 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:01 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:01 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:02 --> Config Class Initialized
INFO - 2024-12-21 10:37:02 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:02 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:02 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:02 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:02 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:02 --> Router Class Initialized
INFO - 2024-12-21 10:37:02 --> Output Class Initialized
INFO - 2024-12-21 10:37:02 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:02 --> Input Class Initialized
INFO - 2024-12-21 10:37:02 --> Language Class Initialized
INFO - 2024-12-21 10:37:02 --> Loader Class Initialized
INFO - 2024-12-21 10:37:02 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:02 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:02 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:02 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:02 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:02 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:02 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:02 --> Config Class Initialized
INFO - 2024-12-21 10:37:02 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:02 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:02 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:02 --> URI Class Initialized
INFO - 2024-12-21 10:37:02 --> Router Class Initialized
INFO - 2024-12-21 10:37:02 --> Output Class Initialized
INFO - 2024-12-21 10:37:02 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:02 --> Input Class Initialized
INFO - 2024-12-21 10:37:02 --> Language Class Initialized
ERROR - 2024-12-21 10:37:02 --> 404 Page Not Found: Server-status/index
INFO - 2024-12-21 10:37:03 --> Config Class Initialized
INFO - 2024-12-21 10:37:03 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:03 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:03 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:03 --> URI Class Initialized
INFO - 2024-12-21 10:37:03 --> Router Class Initialized
INFO - 2024-12-21 10:37:03 --> Output Class Initialized
INFO - 2024-12-21 10:37:03 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:03 --> Input Class Initialized
INFO - 2024-12-21 10:37:03 --> Language Class Initialized
ERROR - 2024-12-21 10:37:03 --> 404 Page Not Found: Loginaction/index
INFO - 2024-12-21 10:37:03 --> Config Class Initialized
INFO - 2024-12-21 10:37:03 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:03 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:03 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:03 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:03 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:03 --> Router Class Initialized
INFO - 2024-12-21 10:37:03 --> Output Class Initialized
INFO - 2024-12-21 10:37:03 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:03 --> Input Class Initialized
INFO - 2024-12-21 10:37:03 --> Language Class Initialized
INFO - 2024-12-21 10:37:03 --> Loader Class Initialized
INFO - 2024-12-21 10:37:03 --> Upload Class Initialized
INFO - 2024-12-21 10:37:03 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:03 --> Email Class Initialized
INFO - 2024-12-21 10:37:03 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:03 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:03 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:03 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:03 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:03 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:03 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:03 --> Controller Class Initialized
INFO - 2024-12-21 16:07:03 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:03 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:03 --> Total execution time: 2.2879
INFO - 2024-12-21 10:37:03 --> Upload Class Initialized
INFO - 2024-12-21 10:37:03 --> Email Class Initialized
INFO - 2024-12-21 10:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:03 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:03 --> Controller Class Initialized
INFO - 2024-12-21 16:07:03 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:03 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:03 --> Total execution time: 2.2905
INFO - 2024-12-21 10:37:03 --> Config Class Initialized
INFO - 2024-12-21 10:37:03 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:03 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:03 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:03 --> URI Class Initialized
INFO - 2024-12-21 10:37:03 --> Router Class Initialized
INFO - 2024-12-21 10:37:03 --> Output Class Initialized
INFO - 2024-12-21 10:37:03 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:03 --> Input Class Initialized
INFO - 2024-12-21 10:37:03 --> Language Class Initialized
ERROR - 2024-12-21 10:37:03 --> 404 Page Not Found: _all_dbs/index
INFO - 2024-12-21 10:37:04 --> Upload Class Initialized
INFO - 2024-12-21 10:37:04 --> Email Class Initialized
INFO - 2024-12-21 10:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:04 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:04 --> Controller Class Initialized
INFO - 2024-12-21 16:07:04 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:04 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:04 --> Total execution time: 2.2283
INFO - 2024-12-21 10:37:04 --> Config Class Initialized
INFO - 2024-12-21 10:37:04 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:04 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:04 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:04 --> URI Class Initialized
INFO - 2024-12-21 10:37:04 --> Config Class Initialized
INFO - 2024-12-21 10:37:04 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:04 --> No URI present. Default controller set.
DEBUG - 2024-12-21 10:37:04 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:04 --> Router Class Initialized
INFO - 2024-12-21 10:37:04 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:04 --> Output Class Initialized
INFO - 2024-12-21 10:37:04 --> URI Class Initialized
INFO - 2024-12-21 10:37:04 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:04 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:04 --> Router Class Initialized
DEBUG - 2024-12-21 10:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:04 --> Input Class Initialized
INFO - 2024-12-21 10:37:04 --> Output Class Initialized
INFO - 2024-12-21 10:37:04 --> Language Class Initialized
INFO - 2024-12-21 10:37:04 --> Security Class Initialized
INFO - 2024-12-21 10:37:04 --> Loader Class Initialized
DEBUG - 2024-12-21 10:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:04 --> Input Class Initialized
INFO - 2024-12-21 10:37:04 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:04 --> Language Class Initialized
INFO - 2024-12-21 10:37:04 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:04 --> Loader Class Initialized
INFO - 2024-12-21 10:37:04 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:04 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:04 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:04 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:05 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:05 --> Upload Class Initialized
INFO - 2024-12-21 10:37:05 --> Email Class Initialized
INFO - 2024-12-21 10:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:05 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:05 --> Controller Class Initialized
INFO - 2024-12-21 16:07:05 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:05 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:05 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:05 --> Total execution time: 2.2974
INFO - 2024-12-21 10:37:07 --> Upload Class Initialized
INFO - 2024-12-21 10:37:07 --> Upload Class Initialized
INFO - 2024-12-21 10:37:07 --> Email Class Initialized
INFO - 2024-12-21 10:37:07 --> Email Class Initialized
INFO - 2024-12-21 10:37:07 --> Config Class Initialized
INFO - 2024-12-21 10:37:07 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:07 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:07 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:07 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:07 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:07 --> Controller Class Initialized
INFO - 2024-12-21 10:37:07 --> Controller Class Initialized
INFO - 2024-12-21 16:07:07 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:07 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:07 --> Final output sent to browser
INFO - 2024-12-21 16:07:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:07 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:07 --> Total execution time: 2.2927
DEBUG - 2024-12-21 16:07:07 --> Total execution time: 2.3220
INFO - 2024-12-21 10:37:07 --> Config Class Initialized
INFO - 2024-12-21 10:37:07 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:07 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:07 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:07 --> URI Class Initialized
INFO - 2024-12-21 10:37:07 --> Router Class Initialized
INFO - 2024-12-21 10:37:07 --> Output Class Initialized
INFO - 2024-12-21 10:37:07 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:07 --> Input Class Initialized
INFO - 2024-12-21 10:37:07 --> Language Class Initialized
ERROR - 2024-12-21 10:37:07 --> 404 Page Not Found: Configjson/index
INFO - 2024-12-21 10:37:08 --> Config Class Initialized
INFO - 2024-12-21 10:37:08 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:08 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:08 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:08 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:08 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:08 --> Router Class Initialized
INFO - 2024-12-21 10:37:08 --> Output Class Initialized
INFO - 2024-12-21 10:37:08 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:08 --> Input Class Initialized
INFO - 2024-12-21 10:37:08 --> Language Class Initialized
INFO - 2024-12-21 10:37:08 --> Loader Class Initialized
INFO - 2024-12-21 10:37:08 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:08 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:08 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:08 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:08 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:08 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:08 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:08 --> Config Class Initialized
INFO - 2024-12-21 10:37:08 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:08 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:08 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:08 --> URI Class Initialized
INFO - 2024-12-21 10:37:08 --> Router Class Initialized
INFO - 2024-12-21 10:37:08 --> Output Class Initialized
INFO - 2024-12-21 10:37:08 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:08 --> Input Class Initialized
INFO - 2024-12-21 10:37:08 --> Language Class Initialized
ERROR - 2024-12-21 10:37:08 --> 404 Page Not Found: Telescope/requests
INFO - 2024-12-21 10:37:10 --> Upload Class Initialized
INFO - 2024-12-21 10:37:10 --> Email Class Initialized
INFO - 2024-12-21 10:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:10 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:10 --> Controller Class Initialized
INFO - 2024-12-21 16:07:10 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:10 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:10 --> Total execution time: 2.1743
INFO - 2024-12-21 10:37:10 --> Config Class Initialized
INFO - 2024-12-21 10:37:10 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:10 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:10 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:10 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:10 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:10 --> Router Class Initialized
INFO - 2024-12-21 10:37:10 --> Output Class Initialized
INFO - 2024-12-21 10:37:10 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:10 --> Input Class Initialized
INFO - 2024-12-21 10:37:10 --> Language Class Initialized
INFO - 2024-12-21 10:37:10 --> Loader Class Initialized
INFO - 2024-12-21 10:37:10 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:10 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:10 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:10 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:10 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:10 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:10 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:11 --> Config Class Initialized
INFO - 2024-12-21 10:37:11 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:11 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:11 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:11 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:11 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:11 --> Router Class Initialized
INFO - 2024-12-21 10:37:11 --> Output Class Initialized
INFO - 2024-12-21 10:37:11 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:11 --> Input Class Initialized
INFO - 2024-12-21 10:37:11 --> Language Class Initialized
INFO - 2024-12-21 10:37:11 --> Loader Class Initialized
INFO - 2024-12-21 10:37:11 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:11 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:11 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:11 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:11 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:11 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:11 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:12 --> Upload Class Initialized
INFO - 2024-12-21 10:37:12 --> Email Class Initialized
INFO - 2024-12-21 10:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:12 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:12 --> Controller Class Initialized
INFO - 2024-12-21 16:07:12 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:12 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:12 --> Total execution time: 2.2153
INFO - 2024-12-21 10:37:13 --> Upload Class Initialized
INFO - 2024-12-21 10:37:13 --> Email Class Initialized
INFO - 2024-12-21 10:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:13 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:13 --> Controller Class Initialized
INFO - 2024-12-21 16:07:13 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:13 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:13 --> Total execution time: 2.2255
INFO - 2024-12-21 10:37:14 --> Config Class Initialized
INFO - 2024-12-21 10:37:14 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:14 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:14 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:14 --> URI Class Initialized
INFO - 2024-12-21 10:37:14 --> Router Class Initialized
INFO - 2024-12-21 10:37:14 --> Output Class Initialized
INFO - 2024-12-21 10:37:14 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:14 --> Input Class Initialized
INFO - 2024-12-21 10:37:14 --> Language Class Initialized
INFO - 2024-12-21 10:37:14 --> Loader Class Initialized
INFO - 2024-12-21 10:37:14 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:14 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:14 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:14 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:14 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:14 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:14 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:16 --> Upload Class Initialized
INFO - 2024-12-21 10:37:16 --> Email Class Initialized
INFO - 2024-12-21 10:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:16 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:16 --> Controller Class Initialized
INFO - 2024-12-21 16:07:16 --> Model "MainModel" initialized
DEBUG - 2024-12-21 16:07:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-21 16:07:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-12-21 16:07:16 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:16 --> Total execution time: 2.1847
INFO - 2024-12-21 10:37:18 --> Config Class Initialized
INFO - 2024-12-21 10:37:18 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:18 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:18 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:18 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:18 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:18 --> Router Class Initialized
INFO - 2024-12-21 10:37:18 --> Output Class Initialized
INFO - 2024-12-21 10:37:18 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:18 --> Input Class Initialized
INFO - 2024-12-21 10:37:18 --> Language Class Initialized
INFO - 2024-12-21 10:37:18 --> Loader Class Initialized
INFO - 2024-12-21 10:37:18 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:18 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:18 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:18 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:18 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:18 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:18 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:20 --> Upload Class Initialized
INFO - 2024-12-21 10:37:20 --> Email Class Initialized
INFO - 2024-12-21 10:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:20 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:20 --> Controller Class Initialized
INFO - 2024-12-21 16:07:20 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:20 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:20 --> Total execution time: 2.2014
INFO - 2024-12-21 10:37:25 --> Config Class Initialized
INFO - 2024-12-21 10:37:25 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:37:25 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:37:25 --> Utf8 Class Initialized
INFO - 2024-12-21 10:37:25 --> URI Class Initialized
DEBUG - 2024-12-21 10:37:25 --> No URI present. Default controller set.
INFO - 2024-12-21 10:37:25 --> Router Class Initialized
INFO - 2024-12-21 10:37:25 --> Output Class Initialized
INFO - 2024-12-21 10:37:25 --> Security Class Initialized
DEBUG - 2024-12-21 10:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:37:25 --> Input Class Initialized
INFO - 2024-12-21 10:37:25 --> Language Class Initialized
INFO - 2024-12-21 10:37:25 --> Loader Class Initialized
INFO - 2024-12-21 10:37:25 --> Helper loaded: url_helper
INFO - 2024-12-21 10:37:25 --> Helper loaded: html_helper
INFO - 2024-12-21 10:37:25 --> Helper loaded: file_helper
INFO - 2024-12-21 10:37:25 --> Helper loaded: string_helper
INFO - 2024-12-21 10:37:25 --> Helper loaded: form_helper
INFO - 2024-12-21 10:37:25 --> Helper loaded: my_helper
INFO - 2024-12-21 10:37:25 --> Database Driver Class Initialized
INFO - 2024-12-21 10:37:27 --> Upload Class Initialized
INFO - 2024-12-21 10:37:27 --> Email Class Initialized
INFO - 2024-12-21 10:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:37:27 --> Form Validation Class Initialized
INFO - 2024-12-21 10:37:27 --> Controller Class Initialized
INFO - 2024-12-21 16:07:27 --> Model "MainModel" initialized
INFO - 2024-12-21 16:07:27 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:07:27 --> Final output sent to browser
DEBUG - 2024-12-21 16:07:27 --> Total execution time: 2.1762
INFO - 2024-12-21 10:38:40 --> Config Class Initialized
INFO - 2024-12-21 10:38:40 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:38:40 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:38:40 --> Utf8 Class Initialized
INFO - 2024-12-21 10:38:40 --> URI Class Initialized
DEBUG - 2024-12-21 10:38:40 --> No URI present. Default controller set.
INFO - 2024-12-21 10:38:40 --> Router Class Initialized
INFO - 2024-12-21 10:38:40 --> Output Class Initialized
INFO - 2024-12-21 10:38:40 --> Security Class Initialized
DEBUG - 2024-12-21 10:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:38:40 --> Input Class Initialized
INFO - 2024-12-21 10:38:40 --> Language Class Initialized
INFO - 2024-12-21 10:38:40 --> Loader Class Initialized
INFO - 2024-12-21 10:38:40 --> Helper loaded: url_helper
INFO - 2024-12-21 10:38:40 --> Helper loaded: html_helper
INFO - 2024-12-21 10:38:40 --> Helper loaded: file_helper
INFO - 2024-12-21 10:38:40 --> Helper loaded: string_helper
INFO - 2024-12-21 10:38:40 --> Helper loaded: form_helper
INFO - 2024-12-21 10:38:40 --> Helper loaded: my_helper
INFO - 2024-12-21 10:38:40 --> Database Driver Class Initialized
INFO - 2024-12-21 10:38:42 --> Upload Class Initialized
INFO - 2024-12-21 10:38:42 --> Email Class Initialized
INFO - 2024-12-21 10:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:38:42 --> Form Validation Class Initialized
INFO - 2024-12-21 10:38:42 --> Controller Class Initialized
INFO - 2024-12-21 16:08:42 --> Model "MainModel" initialized
INFO - 2024-12-21 16:08:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:08:42 --> Final output sent to browser
DEBUG - 2024-12-21 16:08:42 --> Total execution time: 2.1783
INFO - 2024-12-21 10:38:42 --> Config Class Initialized
INFO - 2024-12-21 10:38:42 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:38:42 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:38:42 --> Utf8 Class Initialized
INFO - 2024-12-21 10:38:42 --> URI Class Initialized
INFO - 2024-12-21 10:38:42 --> Router Class Initialized
INFO - 2024-12-21 10:38:42 --> Output Class Initialized
INFO - 2024-12-21 10:38:42 --> Security Class Initialized
DEBUG - 2024-12-21 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:38:42 --> Input Class Initialized
INFO - 2024-12-21 10:38:42 --> Language Class Initialized
ERROR - 2024-12-21 10:38:42 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-21 10:45:14 --> Config Class Initialized
INFO - 2024-12-21 10:45:14 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:45:14 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:45:14 --> Utf8 Class Initialized
INFO - 2024-12-21 10:45:14 --> URI Class Initialized
DEBUG - 2024-12-21 10:45:14 --> No URI present. Default controller set.
INFO - 2024-12-21 10:45:14 --> Router Class Initialized
INFO - 2024-12-21 10:45:14 --> Output Class Initialized
INFO - 2024-12-21 10:45:14 --> Security Class Initialized
DEBUG - 2024-12-21 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:45:14 --> Input Class Initialized
INFO - 2024-12-21 10:45:14 --> Language Class Initialized
INFO - 2024-12-21 10:45:14 --> Loader Class Initialized
INFO - 2024-12-21 10:45:14 --> Helper loaded: url_helper
INFO - 2024-12-21 10:45:14 --> Helper loaded: html_helper
INFO - 2024-12-21 10:45:14 --> Helper loaded: file_helper
INFO - 2024-12-21 10:45:14 --> Helper loaded: string_helper
INFO - 2024-12-21 10:45:14 --> Helper loaded: form_helper
INFO - 2024-12-21 10:45:14 --> Helper loaded: my_helper
INFO - 2024-12-21 10:45:14 --> Database Driver Class Initialized
INFO - 2024-12-21 10:45:16 --> Upload Class Initialized
INFO - 2024-12-21 10:45:16 --> Email Class Initialized
INFO - 2024-12-21 10:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:45:16 --> Form Validation Class Initialized
INFO - 2024-12-21 10:45:16 --> Controller Class Initialized
INFO - 2024-12-21 16:15:16 --> Model "MainModel" initialized
INFO - 2024-12-21 16:15:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:15:16 --> Final output sent to browser
DEBUG - 2024-12-21 16:15:16 --> Total execution time: 2.4598
INFO - 2024-12-21 10:45:43 --> Config Class Initialized
INFO - 2024-12-21 10:45:43 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:45:43 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:45:43 --> Utf8 Class Initialized
INFO - 2024-12-21 10:45:43 --> URI Class Initialized
DEBUG - 2024-12-21 10:45:43 --> No URI present. Default controller set.
INFO - 2024-12-21 10:45:43 --> Router Class Initialized
INFO - 2024-12-21 10:45:43 --> Output Class Initialized
INFO - 2024-12-21 10:45:43 --> Security Class Initialized
DEBUG - 2024-12-21 10:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:45:43 --> Input Class Initialized
INFO - 2024-12-21 10:45:43 --> Language Class Initialized
INFO - 2024-12-21 10:45:43 --> Loader Class Initialized
INFO - 2024-12-21 10:45:43 --> Helper loaded: url_helper
INFO - 2024-12-21 10:45:43 --> Helper loaded: html_helper
INFO - 2024-12-21 10:45:43 --> Helper loaded: file_helper
INFO - 2024-12-21 10:45:43 --> Helper loaded: string_helper
INFO - 2024-12-21 10:45:43 --> Helper loaded: form_helper
INFO - 2024-12-21 10:45:43 --> Helper loaded: my_helper
INFO - 2024-12-21 10:45:43 --> Database Driver Class Initialized
INFO - 2024-12-21 10:45:45 --> Upload Class Initialized
INFO - 2024-12-21 10:45:45 --> Email Class Initialized
INFO - 2024-12-21 10:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:45:45 --> Form Validation Class Initialized
INFO - 2024-12-21 10:45:45 --> Controller Class Initialized
INFO - 2024-12-21 16:15:45 --> Model "MainModel" initialized
INFO - 2024-12-21 16:15:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:15:45 --> Final output sent to browser
DEBUG - 2024-12-21 16:15:45 --> Total execution time: 2.2516
INFO - 2024-12-21 10:45:45 --> Config Class Initialized
INFO - 2024-12-21 10:45:45 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:45:45 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:45:45 --> Utf8 Class Initialized
INFO - 2024-12-21 10:45:45 --> URI Class Initialized
DEBUG - 2024-12-21 10:45:45 --> No URI present. Default controller set.
INFO - 2024-12-21 10:45:45 --> Router Class Initialized
INFO - 2024-12-21 10:45:45 --> Output Class Initialized
INFO - 2024-12-21 10:45:46 --> Security Class Initialized
DEBUG - 2024-12-21 10:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:45:46 --> Input Class Initialized
INFO - 2024-12-21 10:45:46 --> Language Class Initialized
INFO - 2024-12-21 10:45:46 --> Loader Class Initialized
INFO - 2024-12-21 10:45:46 --> Helper loaded: url_helper
INFO - 2024-12-21 10:45:46 --> Helper loaded: html_helper
INFO - 2024-12-21 10:45:46 --> Helper loaded: file_helper
INFO - 2024-12-21 10:45:46 --> Helper loaded: string_helper
INFO - 2024-12-21 10:45:46 --> Helper loaded: form_helper
INFO - 2024-12-21 10:45:46 --> Helper loaded: my_helper
INFO - 2024-12-21 10:45:46 --> Database Driver Class Initialized
INFO - 2024-12-21 10:45:48 --> Upload Class Initialized
INFO - 2024-12-21 10:45:48 --> Email Class Initialized
INFO - 2024-12-21 10:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:45:48 --> Form Validation Class Initialized
INFO - 2024-12-21 10:45:48 --> Controller Class Initialized
INFO - 2024-12-21 16:15:48 --> Model "MainModel" initialized
INFO - 2024-12-21 16:15:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:15:48 --> Final output sent to browser
DEBUG - 2024-12-21 16:15:48 --> Total execution time: 2.2826
INFO - 2024-12-21 10:46:27 --> Config Class Initialized
INFO - 2024-12-21 10:46:27 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:46:27 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:46:27 --> Utf8 Class Initialized
INFO - 2024-12-21 10:46:27 --> URI Class Initialized
DEBUG - 2024-12-21 10:46:28 --> No URI present. Default controller set.
INFO - 2024-12-21 10:46:28 --> Router Class Initialized
INFO - 2024-12-21 10:46:28 --> Output Class Initialized
INFO - 2024-12-21 10:46:28 --> Security Class Initialized
DEBUG - 2024-12-21 10:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:46:28 --> Input Class Initialized
INFO - 2024-12-21 10:46:28 --> Language Class Initialized
INFO - 2024-12-21 10:46:28 --> Loader Class Initialized
INFO - 2024-12-21 10:46:28 --> Helper loaded: url_helper
INFO - 2024-12-21 10:46:28 --> Helper loaded: html_helper
INFO - 2024-12-21 10:46:28 --> Helper loaded: file_helper
INFO - 2024-12-21 10:46:28 --> Helper loaded: string_helper
INFO - 2024-12-21 10:46:28 --> Helper loaded: form_helper
INFO - 2024-12-21 10:46:28 --> Helper loaded: my_helper
INFO - 2024-12-21 10:46:28 --> Database Driver Class Initialized
INFO - 2024-12-21 10:46:30 --> Upload Class Initialized
INFO - 2024-12-21 10:46:30 --> Email Class Initialized
INFO - 2024-12-21 10:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 10:46:30 --> Form Validation Class Initialized
INFO - 2024-12-21 10:46:30 --> Controller Class Initialized
INFO - 2024-12-21 16:16:30 --> Model "MainModel" initialized
INFO - 2024-12-21 16:16:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-21 16:16:30 --> Final output sent to browser
DEBUG - 2024-12-21 16:16:30 --> Total execution time: 2.3343
INFO - 2024-12-21 10:49:12 --> Config Class Initialized
INFO - 2024-12-21 10:49:12 --> Hooks Class Initialized
DEBUG - 2024-12-21 10:49:12 --> UTF-8 Support Enabled
INFO - 2024-12-21 10:49:12 --> Utf8 Class Initialized
INFO - 2024-12-21 10:49:12 --> URI Class Initialized
DEBUG - 2024-12-21 10:49:12 --> No URI present. Default controller set.
INFO - 2024-12-21 10:49:12 --> Router Class Initialized
INFO - 2024-12-21 10:49:12 --> Output Class Initialized
INFO - 2024-12-21 10:49:12 --> Security Class Initialized
DEBUG - 2024-12-21 10:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 10:49:12 --> Input Class Initialized
INFO - 2024-12-21 10:49:13 --> Language Class Initialized
INFO - 2024-12-21 10:49:13 --> Loader Class Initialized
INFO - 2024-12-21 10:49:13 --> Helper loaded: url_helper
INFO - 2024-12-21 10:49:13 --> Helper loaded: html_helper
INFO - 2024-12-21 10:49:13 --> Helper loaded: file_helper
INFO - 2024-12-21 10:49:13 --> Helper loaded: string_helper
INFO - 2024-12-21 10:49:13 --> Helper loaded: form_helper
INFO - 2024-12-21 10:49:13 --> Helper loaded: my_helper
INFO - 2024-12-21 10:49:13 --> Database Driver Class Initialized
ERROR - 2024-12-21 10:49:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions C:\inetpub\vhosts\livservice.in\httpdocs\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-12-21 10:49:15 --> Unable to connect to the database
INFO - 2024-12-21 10:49:15 --> Language file loaded: language/english/db_lang.php
INFO - 2024-12-21 15:41:16 --> Config Class Initialized
INFO - 2024-12-21 15:41:16 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:16 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:16 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:16 --> URI Class Initialized
INFO - 2024-12-21 15:41:16 --> Router Class Initialized
INFO - 2024-12-21 15:41:16 --> Output Class Initialized
INFO - 2024-12-21 15:41:16 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:16 --> Input Class Initialized
INFO - 2024-12-21 15:41:16 --> Language Class Initialized
ERROR - 2024-12-21 15:41:16 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:41:17 --> Config Class Initialized
INFO - 2024-12-21 15:41:17 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:17 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:17 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:17 --> URI Class Initialized
INFO - 2024-12-21 15:41:17 --> Router Class Initialized
INFO - 2024-12-21 15:41:17 --> Output Class Initialized
INFO - 2024-12-21 15:41:17 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:17 --> Input Class Initialized
INFO - 2024-12-21 15:41:17 --> Language Class Initialized
ERROR - 2024-12-21 15:41:17 --> 404 Page Not Found: 403php/index
INFO - 2024-12-21 15:41:17 --> Config Class Initialized
INFO - 2024-12-21 15:41:18 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:18 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:18 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:18 --> URI Class Initialized
INFO - 2024-12-21 15:41:18 --> Router Class Initialized
INFO - 2024-12-21 15:41:18 --> Output Class Initialized
INFO - 2024-12-21 15:41:18 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:18 --> Input Class Initialized
INFO - 2024-12-21 15:41:18 --> Language Class Initialized
ERROR - 2024-12-21 15:41:18 --> 404 Page Not Found: Contentphp/index
INFO - 2024-12-21 15:41:18 --> Config Class Initialized
INFO - 2024-12-21 15:41:18 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:18 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:18 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:18 --> URI Class Initialized
INFO - 2024-12-21 15:41:18 --> Router Class Initialized
INFO - 2024-12-21 15:41:18 --> Output Class Initialized
INFO - 2024-12-21 15:41:18 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:18 --> Input Class Initialized
INFO - 2024-12-21 15:41:18 --> Language Class Initialized
ERROR - 2024-12-21 15:41:18 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:41:19 --> Config Class Initialized
INFO - 2024-12-21 15:41:19 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:19 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:19 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:19 --> URI Class Initialized
INFO - 2024-12-21 15:41:19 --> Router Class Initialized
INFO - 2024-12-21 15:41:19 --> Output Class Initialized
INFO - 2024-12-21 15:41:19 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:19 --> Input Class Initialized
INFO - 2024-12-21 15:41:19 --> Language Class Initialized
ERROR - 2024-12-21 15:41:19 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:41:20 --> Config Class Initialized
INFO - 2024-12-21 15:41:20 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:20 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:20 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:20 --> URI Class Initialized
INFO - 2024-12-21 15:41:20 --> Router Class Initialized
INFO - 2024-12-21 15:41:20 --> Output Class Initialized
INFO - 2024-12-21 15:41:20 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:20 --> Input Class Initialized
INFO - 2024-12-21 15:41:20 --> Language Class Initialized
ERROR - 2024-12-21 15:41:20 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:41:20 --> Config Class Initialized
INFO - 2024-12-21 15:41:20 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:20 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:20 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:20 --> URI Class Initialized
INFO - 2024-12-21 15:41:20 --> Router Class Initialized
INFO - 2024-12-21 15:41:20 --> Output Class Initialized
INFO - 2024-12-21 15:41:20 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:20 --> Input Class Initialized
INFO - 2024-12-21 15:41:20 --> Language Class Initialized
ERROR - 2024-12-21 15:41:20 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:41:21 --> Config Class Initialized
INFO - 2024-12-21 15:41:21 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:21 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:21 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:21 --> URI Class Initialized
INFO - 2024-12-21 15:41:21 --> Router Class Initialized
INFO - 2024-12-21 15:41:21 --> Output Class Initialized
INFO - 2024-12-21 15:41:21 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:21 --> Input Class Initialized
INFO - 2024-12-21 15:41:21 --> Language Class Initialized
ERROR - 2024-12-21 15:41:21 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-21 15:41:21 --> Config Class Initialized
INFO - 2024-12-21 15:41:21 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:21 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:21 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:21 --> URI Class Initialized
INFO - 2024-12-21 15:41:21 --> Router Class Initialized
INFO - 2024-12-21 15:41:21 --> Output Class Initialized
INFO - 2024-12-21 15:41:21 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:21 --> Input Class Initialized
INFO - 2024-12-21 15:41:21 --> Language Class Initialized
ERROR - 2024-12-21 15:41:21 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:41:22 --> Config Class Initialized
INFO - 2024-12-21 15:41:22 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:22 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:22 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:22 --> URI Class Initialized
INFO - 2024-12-21 15:41:22 --> Router Class Initialized
INFO - 2024-12-21 15:41:22 --> Output Class Initialized
INFO - 2024-12-21 15:41:22 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:22 --> Input Class Initialized
INFO - 2024-12-21 15:41:22 --> Language Class Initialized
ERROR - 2024-12-21 15:41:22 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:41:23 --> Config Class Initialized
INFO - 2024-12-21 15:41:23 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:23 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:23 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:23 --> URI Class Initialized
INFO - 2024-12-21 15:41:23 --> Router Class Initialized
INFO - 2024-12-21 15:41:23 --> Output Class Initialized
INFO - 2024-12-21 15:41:23 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:23 --> Input Class Initialized
INFO - 2024-12-21 15:41:23 --> Language Class Initialized
ERROR - 2024-12-21 15:41:23 --> 404 Page Not Found: Berlinphp/index
INFO - 2024-12-21 15:41:23 --> Config Class Initialized
INFO - 2024-12-21 15:41:23 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:23 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:23 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:23 --> URI Class Initialized
INFO - 2024-12-21 15:41:23 --> Router Class Initialized
INFO - 2024-12-21 15:41:23 --> Output Class Initialized
INFO - 2024-12-21 15:41:23 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:23 --> Input Class Initialized
INFO - 2024-12-21 15:41:23 --> Language Class Initialized
ERROR - 2024-12-21 15:41:23 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-21 15:41:24 --> Config Class Initialized
INFO - 2024-12-21 15:41:24 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:24 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:24 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:24 --> URI Class Initialized
INFO - 2024-12-21 15:41:24 --> Router Class Initialized
INFO - 2024-12-21 15:41:24 --> Output Class Initialized
INFO - 2024-12-21 15:41:24 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:24 --> Input Class Initialized
INFO - 2024-12-21 15:41:24 --> Language Class Initialized
ERROR - 2024-12-21 15:41:24 --> 404 Page Not Found: Wp-includes/style-engine
INFO - 2024-12-21 15:41:25 --> Config Class Initialized
INFO - 2024-12-21 15:41:25 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:25 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:25 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:25 --> URI Class Initialized
INFO - 2024-12-21 15:41:25 --> Router Class Initialized
INFO - 2024-12-21 15:41:25 --> Output Class Initialized
INFO - 2024-12-21 15:41:25 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:25 --> Input Class Initialized
INFO - 2024-12-21 15:41:25 --> Language Class Initialized
ERROR - 2024-12-21 15:41:25 --> 404 Page Not Found: Wp-includes/rest-api
INFO - 2024-12-21 15:41:25 --> Config Class Initialized
INFO - 2024-12-21 15:41:25 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:25 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:25 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:25 --> URI Class Initialized
INFO - 2024-12-21 15:41:25 --> Router Class Initialized
INFO - 2024-12-21 15:41:25 --> Output Class Initialized
INFO - 2024-12-21 15:41:25 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:25 --> Input Class Initialized
INFO - 2024-12-21 15:41:25 --> Language Class Initialized
ERROR - 2024-12-21 15:41:25 --> 404 Page Not Found: Wp-includes/SimplePie
INFO - 2024-12-21 15:41:26 --> Config Class Initialized
INFO - 2024-12-21 15:41:26 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:26 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:26 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:26 --> URI Class Initialized
INFO - 2024-12-21 15:41:26 --> Router Class Initialized
INFO - 2024-12-21 15:41:26 --> Output Class Initialized
INFO - 2024-12-21 15:41:26 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:26 --> Input Class Initialized
INFO - 2024-12-21 15:41:26 --> Language Class Initialized
ERROR - 2024-12-21 15:41:26 --> 404 Page Not Found: Wp-content/banners
INFO - 2024-12-21 15:41:26 --> Config Class Initialized
INFO - 2024-12-21 15:41:26 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:26 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:26 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:26 --> URI Class Initialized
INFO - 2024-12-21 15:41:26 --> Router Class Initialized
INFO - 2024-12-21 15:41:26 --> Output Class Initialized
INFO - 2024-12-21 15:41:26 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:26 --> Input Class Initialized
INFO - 2024-12-21 15:41:26 --> Language Class Initialized
ERROR - 2024-12-21 15:41:26 --> 404 Page Not Found: Wp-content/about.php
INFO - 2024-12-21 15:41:27 --> Config Class Initialized
INFO - 2024-12-21 15:41:27 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:27 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:27 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:27 --> URI Class Initialized
INFO - 2024-12-21 15:41:27 --> Router Class Initialized
INFO - 2024-12-21 15:41:27 --> Output Class Initialized
INFO - 2024-12-21 15:41:27 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:27 --> Input Class Initialized
INFO - 2024-12-21 15:41:27 --> Language Class Initialized
ERROR - 2024-12-21 15:41:27 --> 404 Page Not Found: Well-known/about.php
INFO - 2024-12-21 15:41:28 --> Config Class Initialized
INFO - 2024-12-21 15:41:28 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:28 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:28 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:28 --> URI Class Initialized
INFO - 2024-12-21 15:41:28 --> Router Class Initialized
INFO - 2024-12-21 15:41:28 --> Output Class Initialized
INFO - 2024-12-21 15:41:28 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:28 --> Input Class Initialized
INFO - 2024-12-21 15:41:28 --> Language Class Initialized
ERROR - 2024-12-21 15:41:28 --> 404 Page Not Found: Wp-includes/Text
INFO - 2024-12-21 15:41:28 --> Config Class Initialized
INFO - 2024-12-21 15:41:28 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:28 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:28 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:28 --> URI Class Initialized
INFO - 2024-12-21 15:41:28 --> Router Class Initialized
INFO - 2024-12-21 15:41:28 --> Output Class Initialized
INFO - 2024-12-21 15:41:28 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:28 --> Input Class Initialized
INFO - 2024-12-21 15:41:28 --> Language Class Initialized
ERROR - 2024-12-21 15:41:28 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2024-12-21 15:41:29 --> Config Class Initialized
INFO - 2024-12-21 15:41:29 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:29 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:29 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:29 --> URI Class Initialized
INFO - 2024-12-21 15:41:29 --> Router Class Initialized
INFO - 2024-12-21 15:41:29 --> Output Class Initialized
INFO - 2024-12-21 15:41:29 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:29 --> Input Class Initialized
INFO - 2024-12-21 15:41:29 --> Language Class Initialized
ERROR - 2024-12-21 15:41:29 --> 404 Page Not Found: Img/about.php
INFO - 2024-12-21 15:41:30 --> Config Class Initialized
INFO - 2024-12-21 15:41:30 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:30 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:30 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:30 --> URI Class Initialized
INFO - 2024-12-21 15:41:30 --> Router Class Initialized
INFO - 2024-12-21 15:41:30 --> Output Class Initialized
INFO - 2024-12-21 15:41:30 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:30 --> Input Class Initialized
INFO - 2024-12-21 15:41:30 --> Language Class Initialized
ERROR - 2024-12-21 15:41:30 --> 404 Page Not Found: Wp-content/languages
INFO - 2024-12-21 15:41:30 --> Config Class Initialized
INFO - 2024-12-21 15:41:30 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:30 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:30 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:30 --> URI Class Initialized
INFO - 2024-12-21 15:41:30 --> Router Class Initialized
INFO - 2024-12-21 15:41:30 --> Output Class Initialized
INFO - 2024-12-21 15:41:30 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:30 --> Input Class Initialized
INFO - 2024-12-21 15:41:30 --> Language Class Initialized
ERROR - 2024-12-21 15:41:30 --> 404 Page Not Found: Wp-includes/customize
INFO - 2024-12-21 15:41:31 --> Config Class Initialized
INFO - 2024-12-21 15:41:31 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:31 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:31 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:31 --> URI Class Initialized
INFO - 2024-12-21 15:41:31 --> Router Class Initialized
INFO - 2024-12-21 15:41:31 --> Output Class Initialized
INFO - 2024-12-21 15:41:31 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:31 --> Input Class Initialized
INFO - 2024-12-21 15:41:31 --> Language Class Initialized
ERROR - 2024-12-21 15:41:31 --> 404 Page Not Found: Wp-includesbak/html-api
INFO - 2024-12-21 15:41:32 --> Config Class Initialized
INFO - 2024-12-21 15:41:32 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:32 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:32 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:32 --> URI Class Initialized
INFO - 2024-12-21 15:41:32 --> Router Class Initialized
INFO - 2024-12-21 15:41:32 --> Output Class Initialized
INFO - 2024-12-21 15:41:32 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:32 --> Input Class Initialized
INFO - 2024-12-21 15:41:32 --> Language Class Initialized
ERROR - 2024-12-21 15:41:32 --> 404 Page Not Found: Wp-includes/widgets
INFO - 2024-12-21 15:41:32 --> Config Class Initialized
INFO - 2024-12-21 15:41:32 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:32 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:32 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:32 --> URI Class Initialized
INFO - 2024-12-21 15:41:32 --> Router Class Initialized
INFO - 2024-12-21 15:41:32 --> Output Class Initialized
INFO - 2024-12-21 15:41:32 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:32 --> Input Class Initialized
INFO - 2024-12-21 15:41:32 --> Language Class Initialized
ERROR - 2024-12-21 15:41:32 --> 404 Page Not Found: Wp-includes/IXR
INFO - 2024-12-21 15:41:33 --> Config Class Initialized
INFO - 2024-12-21 15:41:33 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:33 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:33 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:33 --> URI Class Initialized
INFO - 2024-12-21 15:41:33 --> Router Class Initialized
INFO - 2024-12-21 15:41:33 --> Output Class Initialized
INFO - 2024-12-21 15:41:33 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:33 --> Input Class Initialized
INFO - 2024-12-21 15:41:33 --> Language Class Initialized
ERROR - 2024-12-21 15:41:33 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:41:34 --> Config Class Initialized
INFO - 2024-12-21 15:41:34 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:34 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:34 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:34 --> URI Class Initialized
INFO - 2024-12-21 15:41:34 --> Router Class Initialized
INFO - 2024-12-21 15:41:34 --> Output Class Initialized
INFO - 2024-12-21 15:41:34 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:34 --> Input Class Initialized
INFO - 2024-12-21 15:41:34 --> Language Class Initialized
ERROR - 2024-12-21 15:41:34 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-21 15:41:34 --> Config Class Initialized
INFO - 2024-12-21 15:41:34 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:34 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:34 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:34 --> URI Class Initialized
INFO - 2024-12-21 15:41:34 --> Router Class Initialized
INFO - 2024-12-21 15:41:34 --> Output Class Initialized
INFO - 2024-12-21 15:41:34 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:34 --> Input Class Initialized
INFO - 2024-12-21 15:41:34 --> Language Class Initialized
ERROR - 2024-12-21 15:41:34 --> 404 Page Not Found: Wp-includes/pomo
INFO - 2024-12-21 15:41:35 --> Config Class Initialized
INFO - 2024-12-21 15:41:35 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:35 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:35 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:35 --> URI Class Initialized
INFO - 2024-12-21 15:41:35 --> Router Class Initialized
INFO - 2024-12-21 15:41:35 --> Output Class Initialized
INFO - 2024-12-21 15:41:35 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:35 --> Input Class Initialized
INFO - 2024-12-21 15:41:35 --> Language Class Initialized
ERROR - 2024-12-21 15:41:35 --> 404 Page Not Found: Wp-includes/block-patterns
INFO - 2024-12-21 15:41:36 --> Config Class Initialized
INFO - 2024-12-21 15:41:36 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:36 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:36 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:36 --> URI Class Initialized
INFO - 2024-12-21 15:41:36 --> Router Class Initialized
INFO - 2024-12-21 15:41:36 --> Output Class Initialized
INFO - 2024-12-21 15:41:36 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:36 --> Input Class Initialized
INFO - 2024-12-21 15:41:36 --> Language Class Initialized
ERROR - 2024-12-21 15:41:36 --> 404 Page Not Found: Wp-content/updraft
INFO - 2024-12-21 15:41:36 --> Config Class Initialized
INFO - 2024-12-21 15:41:36 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:36 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:36 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:36 --> URI Class Initialized
INFO - 2024-12-21 15:41:36 --> Router Class Initialized
INFO - 2024-12-21 15:41:36 --> Output Class Initialized
INFO - 2024-12-21 15:41:36 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:36 --> Input Class Initialized
INFO - 2024-12-21 15:41:37 --> Language Class Initialized
ERROR - 2024-12-21 15:41:37 --> 404 Page Not Found: Wp-content/upgrade-temp-backup
INFO - 2024-12-21 15:41:37 --> Config Class Initialized
INFO - 2024-12-21 15:41:37 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:37 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:37 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:37 --> URI Class Initialized
INFO - 2024-12-21 15:41:37 --> Router Class Initialized
INFO - 2024-12-21 15:41:37 --> Output Class Initialized
INFO - 2024-12-21 15:41:37 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:37 --> Input Class Initialized
INFO - 2024-12-21 15:41:37 --> Language Class Initialized
ERROR - 2024-12-21 15:41:37 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:41:38 --> Config Class Initialized
INFO - 2024-12-21 15:41:38 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:38 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:38 --> URI Class Initialized
INFO - 2024-12-21 15:41:38 --> Router Class Initialized
INFO - 2024-12-21 15:41:38 --> Output Class Initialized
INFO - 2024-12-21 15:41:38 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:38 --> Input Class Initialized
INFO - 2024-12-21 15:41:38 --> Language Class Initialized
ERROR - 2024-12-21 15:41:38 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-21 15:41:38 --> Config Class Initialized
INFO - 2024-12-21 15:41:38 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:38 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:38 --> URI Class Initialized
INFO - 2024-12-21 15:41:38 --> Router Class Initialized
INFO - 2024-12-21 15:41:38 --> Output Class Initialized
INFO - 2024-12-21 15:41:38 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:38 --> Input Class Initialized
INFO - 2024-12-21 15:41:38 --> Language Class Initialized
ERROR - 2024-12-21 15:41:38 --> 404 Page Not Found: Images/about.php
INFO - 2024-12-21 15:41:39 --> Config Class Initialized
INFO - 2024-12-21 15:41:39 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:39 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:39 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:39 --> URI Class Initialized
INFO - 2024-12-21 15:41:39 --> Router Class Initialized
INFO - 2024-12-21 15:41:39 --> Output Class Initialized
INFO - 2024-12-21 15:41:39 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:39 --> Input Class Initialized
INFO - 2024-12-21 15:41:39 --> Language Class Initialized
ERROR - 2024-12-21 15:41:39 --> 404 Page Not Found: Wp-content/blogs.dir
INFO - 2024-12-21 15:41:40 --> Config Class Initialized
INFO - 2024-12-21 15:41:40 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:40 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:40 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:40 --> URI Class Initialized
INFO - 2024-12-21 15:41:40 --> Router Class Initialized
INFO - 2024-12-21 15:41:40 --> Output Class Initialized
INFO - 2024-12-21 15:41:40 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:40 --> Input Class Initialized
INFO - 2024-12-21 15:41:40 --> Language Class Initialized
ERROR - 2024-12-21 15:41:40 --> 404 Page Not Found: Wp-includes/images
INFO - 2024-12-21 15:41:41 --> Config Class Initialized
INFO - 2024-12-21 15:41:41 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:41 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:41 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:41 --> URI Class Initialized
INFO - 2024-12-21 15:41:41 --> Router Class Initialized
INFO - 2024-12-21 15:41:41 --> Output Class Initialized
INFO - 2024-12-21 15:41:41 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:41 --> Input Class Initialized
INFO - 2024-12-21 15:41:41 --> Language Class Initialized
ERROR - 2024-12-21 15:41:41 --> 404 Page Not Found: Wp-includes/about.php
INFO - 2024-12-21 15:41:41 --> Config Class Initialized
INFO - 2024-12-21 15:41:41 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:41 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:41 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:41 --> URI Class Initialized
INFO - 2024-12-21 15:41:41 --> Router Class Initialized
INFO - 2024-12-21 15:41:41 --> Output Class Initialized
INFO - 2024-12-21 15:41:41 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:41 --> Input Class Initialized
INFO - 2024-12-21 15:41:41 --> Language Class Initialized
ERROR - 2024-12-21 15:41:41 --> 404 Page Not Found: Cgi-bin/about.php
INFO - 2024-12-21 15:41:42 --> Config Class Initialized
INFO - 2024-12-21 15:41:42 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:42 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:42 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:42 --> URI Class Initialized
INFO - 2024-12-21 15:41:42 --> Router Class Initialized
INFO - 2024-12-21 15:41:42 --> Output Class Initialized
INFO - 2024-12-21 15:41:42 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:42 --> Input Class Initialized
INFO - 2024-12-21 15:41:42 --> Language Class Initialized
ERROR - 2024-12-21 15:41:42 --> 404 Page Not Found: Wp-content/gallery
INFO - 2024-12-21 15:41:43 --> Config Class Initialized
INFO - 2024-12-21 15:41:43 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:43 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:43 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:43 --> URI Class Initialized
INFO - 2024-12-21 15:41:43 --> Router Class Initialized
INFO - 2024-12-21 15:41:43 --> Output Class Initialized
INFO - 2024-12-21 15:41:43 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:43 --> Input Class Initialized
INFO - 2024-12-21 15:41:43 --> Language Class Initialized
ERROR - 2024-12-21 15:41:43 --> 404 Page Not Found: Wp-includes/blocks
INFO - 2024-12-21 15:41:43 --> Config Class Initialized
INFO - 2024-12-21 15:41:43 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:43 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:43 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:43 --> URI Class Initialized
INFO - 2024-12-21 15:41:43 --> Router Class Initialized
INFO - 2024-12-21 15:41:43 --> Output Class Initialized
INFO - 2024-12-21 15:41:43 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:43 --> Input Class Initialized
INFO - 2024-12-21 15:41:43 --> Language Class Initialized
ERROR - 2024-12-21 15:41:43 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:41:44 --> Config Class Initialized
INFO - 2024-12-21 15:41:44 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:44 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:44 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:44 --> URI Class Initialized
INFO - 2024-12-21 15:41:44 --> Router Class Initialized
INFO - 2024-12-21 15:41:44 --> Output Class Initialized
INFO - 2024-12-21 15:41:44 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:44 --> Input Class Initialized
INFO - 2024-12-21 15:41:44 --> Language Class Initialized
ERROR - 2024-12-21 15:41:44 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:41:45 --> Config Class Initialized
INFO - 2024-12-21 15:41:45 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:45 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:45 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:45 --> URI Class Initialized
INFO - 2024-12-21 15:41:45 --> Router Class Initialized
INFO - 2024-12-21 15:41:45 --> Output Class Initialized
INFO - 2024-12-21 15:41:45 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:45 --> Input Class Initialized
INFO - 2024-12-21 15:41:45 --> Language Class Initialized
ERROR - 2024-12-21 15:41:45 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-21 15:41:46 --> Config Class Initialized
INFO - 2024-12-21 15:41:46 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:46 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:46 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:46 --> URI Class Initialized
INFO - 2024-12-21 15:41:46 --> Router Class Initialized
INFO - 2024-12-21 15:41:46 --> Output Class Initialized
INFO - 2024-12-21 15:41:46 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:46 --> Input Class Initialized
INFO - 2024-12-21 15:41:46 --> Language Class Initialized
ERROR - 2024-12-21 15:41:46 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-21 15:41:46 --> Config Class Initialized
INFO - 2024-12-21 15:41:46 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:46 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:46 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:46 --> URI Class Initialized
INFO - 2024-12-21 15:41:46 --> Router Class Initialized
INFO - 2024-12-21 15:41:46 --> Output Class Initialized
INFO - 2024-12-21 15:41:46 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:46 --> Input Class Initialized
INFO - 2024-12-21 15:41:46 --> Language Class Initialized
ERROR - 2024-12-21 15:41:46 --> 404 Page Not Found: Cloudphp/index
INFO - 2024-12-21 15:41:47 --> Config Class Initialized
INFO - 2024-12-21 15:41:47 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:47 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:47 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:47 --> URI Class Initialized
INFO - 2024-12-21 15:41:47 --> Router Class Initialized
INFO - 2024-12-21 15:41:47 --> Output Class Initialized
INFO - 2024-12-21 15:41:47 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:47 --> Input Class Initialized
INFO - 2024-12-21 15:41:47 --> Language Class Initialized
ERROR - 2024-12-21 15:41:47 --> 404 Page Not Found: Cgi-bin/cloud.php
INFO - 2024-12-21 15:41:47 --> Config Class Initialized
INFO - 2024-12-21 15:41:47 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:47 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:47 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:47 --> URI Class Initialized
INFO - 2024-12-21 15:41:47 --> Router Class Initialized
INFO - 2024-12-21 15:41:47 --> Output Class Initialized
INFO - 2024-12-21 15:41:47 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:47 --> Input Class Initialized
INFO - 2024-12-21 15:41:47 --> Language Class Initialized
ERROR - 2024-12-21 15:41:47 --> 404 Page Not Found: Wp-content/updates.php
INFO - 2024-12-21 15:41:48 --> Config Class Initialized
INFO - 2024-12-21 15:41:48 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:48 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:48 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:48 --> URI Class Initialized
INFO - 2024-12-21 15:41:48 --> Router Class Initialized
INFO - 2024-12-21 15:41:48 --> Output Class Initialized
INFO - 2024-12-21 15:41:48 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:48 --> Input Class Initialized
INFO - 2024-12-21 15:41:48 --> Language Class Initialized
ERROR - 2024-12-21 15:41:48 --> 404 Page Not Found: Css/cloud.php
INFO - 2024-12-21 15:41:48 --> Config Class Initialized
INFO - 2024-12-21 15:41:48 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:48 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:48 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:48 --> URI Class Initialized
INFO - 2024-12-21 15:41:48 --> Router Class Initialized
INFO - 2024-12-21 15:41:48 --> Output Class Initialized
INFO - 2024-12-21 15:41:48 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:48 --> Input Class Initialized
INFO - 2024-12-21 15:41:48 --> Language Class Initialized
ERROR - 2024-12-21 15:41:48 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-21 15:41:49 --> Config Class Initialized
INFO - 2024-12-21 15:41:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:49 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:49 --> URI Class Initialized
INFO - 2024-12-21 15:41:49 --> Router Class Initialized
INFO - 2024-12-21 15:41:49 --> Output Class Initialized
INFO - 2024-12-21 15:41:49 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:49 --> Input Class Initialized
INFO - 2024-12-21 15:41:49 --> Language Class Initialized
ERROR - 2024-12-21 15:41:49 --> 404 Page Not Found: Img/cloud.php
INFO - 2024-12-21 15:41:49 --> Config Class Initialized
INFO - 2024-12-21 15:41:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:49 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:49 --> URI Class Initialized
INFO - 2024-12-21 15:41:49 --> Router Class Initialized
INFO - 2024-12-21 15:41:49 --> Output Class Initialized
INFO - 2024-12-21 15:41:49 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:49 --> Input Class Initialized
INFO - 2024-12-21 15:41:49 --> Language Class Initialized
ERROR - 2024-12-21 15:41:49 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:41:50 --> Config Class Initialized
INFO - 2024-12-21 15:41:50 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:50 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:50 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:50 --> URI Class Initialized
INFO - 2024-12-21 15:41:50 --> Router Class Initialized
INFO - 2024-12-21 15:41:50 --> Output Class Initialized
INFO - 2024-12-21 15:41:50 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:50 --> Input Class Initialized
INFO - 2024-12-21 15:41:50 --> Language Class Initialized
ERROR - 2024-12-21 15:41:50 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:41:51 --> Config Class Initialized
INFO - 2024-12-21 15:41:51 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:51 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:51 --> URI Class Initialized
INFO - 2024-12-21 15:41:51 --> Router Class Initialized
INFO - 2024-12-21 15:41:51 --> Output Class Initialized
INFO - 2024-12-21 15:41:51 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:51 --> Input Class Initialized
INFO - 2024-12-21 15:41:51 --> Language Class Initialized
ERROR - 2024-12-21 15:41:51 --> 404 Page Not Found: Avaaphp/index
INFO - 2024-12-21 15:41:51 --> Config Class Initialized
INFO - 2024-12-21 15:41:51 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:51 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:51 --> URI Class Initialized
INFO - 2024-12-21 15:41:51 --> Router Class Initialized
INFO - 2024-12-21 15:41:51 --> Output Class Initialized
INFO - 2024-12-21 15:41:51 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:51 --> Input Class Initialized
INFO - 2024-12-21 15:41:51 --> Language Class Initialized
ERROR - 2024-12-21 15:41:51 --> 404 Page Not Found: Images/cloud.php
INFO - 2024-12-21 15:41:52 --> Config Class Initialized
INFO - 2024-12-21 15:41:52 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:52 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:52 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:52 --> URI Class Initialized
INFO - 2024-12-21 15:41:52 --> Router Class Initialized
INFO - 2024-12-21 15:41:52 --> Output Class Initialized
INFO - 2024-12-21 15:41:52 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:52 --> Input Class Initialized
INFO - 2024-12-21 15:41:52 --> Language Class Initialized
ERROR - 2024-12-21 15:41:52 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:41:53 --> Config Class Initialized
INFO - 2024-12-21 15:41:53 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:53 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:53 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:53 --> URI Class Initialized
INFO - 2024-12-21 15:41:53 --> Router Class Initialized
INFO - 2024-12-21 15:41:53 --> Output Class Initialized
INFO - 2024-12-21 15:41:53 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:53 --> Input Class Initialized
INFO - 2024-12-21 15:41:53 --> Language Class Initialized
ERROR - 2024-12-21 15:41:53 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-21 15:41:54 --> Config Class Initialized
INFO - 2024-12-21 15:41:54 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:54 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:54 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:54 --> URI Class Initialized
INFO - 2024-12-21 15:41:54 --> Router Class Initialized
INFO - 2024-12-21 15:41:54 --> Output Class Initialized
INFO - 2024-12-21 15:41:54 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:54 --> Input Class Initialized
INFO - 2024-12-21 15:41:54 --> Language Class Initialized
ERROR - 2024-12-21 15:41:54 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:41:55 --> Config Class Initialized
INFO - 2024-12-21 15:41:55 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:55 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:55 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:55 --> URI Class Initialized
INFO - 2024-12-21 15:41:55 --> Router Class Initialized
INFO - 2024-12-21 15:41:55 --> Output Class Initialized
INFO - 2024-12-21 15:41:55 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:55 --> Input Class Initialized
INFO - 2024-12-21 15:41:55 --> Language Class Initialized
ERROR - 2024-12-21 15:41:55 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-21 15:41:56 --> Config Class Initialized
INFO - 2024-12-21 15:41:56 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:56 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:56 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:56 --> URI Class Initialized
INFO - 2024-12-21 15:41:56 --> Router Class Initialized
INFO - 2024-12-21 15:41:56 --> Output Class Initialized
INFO - 2024-12-21 15:41:56 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:56 --> Input Class Initialized
INFO - 2024-12-21 15:41:56 --> Language Class Initialized
ERROR - 2024-12-21 15:41:56 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:41:57 --> Config Class Initialized
INFO - 2024-12-21 15:41:57 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:57 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:57 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:57 --> URI Class Initialized
INFO - 2024-12-21 15:41:57 --> Router Class Initialized
INFO - 2024-12-21 15:41:57 --> Output Class Initialized
INFO - 2024-12-21 15:41:57 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:57 --> Input Class Initialized
INFO - 2024-12-21 15:41:57 --> Language Class Initialized
ERROR - 2024-12-21 15:41:57 --> 404 Page Not Found: Wp-admin/cloud.php
INFO - 2024-12-21 15:41:57 --> Config Class Initialized
INFO - 2024-12-21 15:41:57 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:57 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:57 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:58 --> URI Class Initialized
INFO - 2024-12-21 15:41:58 --> Router Class Initialized
INFO - 2024-12-21 15:41:58 --> Output Class Initialized
INFO - 2024-12-21 15:41:58 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:58 --> Input Class Initialized
INFO - 2024-12-21 15:41:58 --> Language Class Initialized
ERROR - 2024-12-21 15:41:58 --> 404 Page Not Found: Updatesphp/index
INFO - 2024-12-21 15:41:58 --> Config Class Initialized
INFO - 2024-12-21 15:41:58 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:58 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:58 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:58 --> URI Class Initialized
INFO - 2024-12-21 15:41:58 --> Router Class Initialized
INFO - 2024-12-21 15:41:58 --> Output Class Initialized
INFO - 2024-12-21 15:41:58 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:58 --> Input Class Initialized
INFO - 2024-12-21 15:41:58 --> Language Class Initialized
ERROR - 2024-12-21 15:41:58 --> 404 Page Not Found: Libraries/legacy
INFO - 2024-12-21 15:41:59 --> Config Class Initialized
INFO - 2024-12-21 15:41:59 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:41:59 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:41:59 --> Utf8 Class Initialized
INFO - 2024-12-21 15:41:59 --> URI Class Initialized
INFO - 2024-12-21 15:41:59 --> Router Class Initialized
INFO - 2024-12-21 15:41:59 --> Output Class Initialized
INFO - 2024-12-21 15:41:59 --> Security Class Initialized
DEBUG - 2024-12-21 15:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:41:59 --> Input Class Initialized
INFO - 2024-12-21 15:41:59 --> Language Class Initialized
ERROR - 2024-12-21 15:41:59 --> 404 Page Not Found: Libraries/phpmailer
INFO - 2024-12-21 15:42:00 --> Config Class Initialized
INFO - 2024-12-21 15:42:00 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:00 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:00 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:00 --> URI Class Initialized
INFO - 2024-12-21 15:42:00 --> Router Class Initialized
INFO - 2024-12-21 15:42:00 --> Output Class Initialized
INFO - 2024-12-21 15:42:00 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:00 --> Input Class Initialized
INFO - 2024-12-21 15:42:00 --> Language Class Initialized
ERROR - 2024-12-21 15:42:00 --> 404 Page Not Found: Libraries/vendor
INFO - 2024-12-21 15:42:00 --> Config Class Initialized
INFO - 2024-12-21 15:42:00 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:00 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:00 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:00 --> URI Class Initialized
INFO - 2024-12-21 15:42:00 --> Router Class Initialized
INFO - 2024-12-21 15:42:00 --> Output Class Initialized
INFO - 2024-12-21 15:42:00 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:00 --> Input Class Initialized
INFO - 2024-12-21 15:42:00 --> Language Class Initialized
ERROR - 2024-12-21 15:42:00 --> 404 Page Not Found: Alfa-rexphp7/index
INFO - 2024-12-21 15:42:01 --> Config Class Initialized
INFO - 2024-12-21 15:42:01 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:01 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:01 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:01 --> URI Class Initialized
INFO - 2024-12-21 15:42:01 --> Router Class Initialized
INFO - 2024-12-21 15:42:01 --> Output Class Initialized
INFO - 2024-12-21 15:42:01 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:01 --> Input Class Initialized
INFO - 2024-12-21 15:42:01 --> Language Class Initialized
ERROR - 2024-12-21 15:42:01 --> 404 Page Not Found: Alfanewphp/index
INFO - 2024-12-21 15:42:02 --> Config Class Initialized
INFO - 2024-12-21 15:42:02 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:02 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:02 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:02 --> URI Class Initialized
INFO - 2024-12-21 15:42:02 --> Router Class Initialized
INFO - 2024-12-21 15:42:02 --> Output Class Initialized
INFO - 2024-12-21 15:42:02 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:02 --> Input Class Initialized
INFO - 2024-12-21 15:42:02 --> Language Class Initialized
ERROR - 2024-12-21 15:42:02 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:02 --> Config Class Initialized
INFO - 2024-12-21 15:42:02 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:02 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:02 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:02 --> URI Class Initialized
INFO - 2024-12-21 15:42:02 --> Router Class Initialized
INFO - 2024-12-21 15:42:02 --> Output Class Initialized
INFO - 2024-12-21 15:42:02 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:02 --> Input Class Initialized
INFO - 2024-12-21 15:42:02 --> Language Class Initialized
ERROR - 2024-12-21 15:42:02 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:42:03 --> Config Class Initialized
INFO - 2024-12-21 15:42:03 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:03 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:03 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:03 --> URI Class Initialized
INFO - 2024-12-21 15:42:03 --> Router Class Initialized
INFO - 2024-12-21 15:42:03 --> Output Class Initialized
INFO - 2024-12-21 15:42:03 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:03 --> Input Class Initialized
INFO - 2024-12-21 15:42:03 --> Language Class Initialized
ERROR - 2024-12-21 15:42:03 --> 404 Page Not Found: Wp-pphp7/index
INFO - 2024-12-21 15:42:03 --> Config Class Initialized
INFO - 2024-12-21 15:42:03 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:03 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:03 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:03 --> URI Class Initialized
INFO - 2024-12-21 15:42:03 --> Router Class Initialized
INFO - 2024-12-21 15:42:03 --> Output Class Initialized
INFO - 2024-12-21 15:42:03 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:03 --> Input Class Initialized
INFO - 2024-12-21 15:42:03 --> Language Class Initialized
ERROR - 2024-12-21 15:42:03 --> 404 Page Not Found: Wp-admin/repeater.php
INFO - 2024-12-21 15:42:04 --> Config Class Initialized
INFO - 2024-12-21 15:42:04 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:04 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:04 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:04 --> URI Class Initialized
INFO - 2024-12-21 15:42:04 --> Router Class Initialized
INFO - 2024-12-21 15:42:04 --> Output Class Initialized
INFO - 2024-12-21 15:42:04 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:04 --> Input Class Initialized
INFO - 2024-12-21 15:42:04 --> Language Class Initialized
ERROR - 2024-12-21 15:42:04 --> 404 Page Not Found: Wp-includes/repeater.php
INFO - 2024-12-21 15:42:05 --> Config Class Initialized
INFO - 2024-12-21 15:42:05 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:05 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:05 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:05 --> URI Class Initialized
INFO - 2024-12-21 15:42:05 --> Router Class Initialized
INFO - 2024-12-21 15:42:05 --> Output Class Initialized
INFO - 2024-12-21 15:42:05 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:05 --> Input Class Initialized
INFO - 2024-12-21 15:42:05 --> Language Class Initialized
ERROR - 2024-12-21 15:42:05 --> 404 Page Not Found: Wp-content/repeater.php
INFO - 2024-12-21 15:42:05 --> Config Class Initialized
INFO - 2024-12-21 15:42:05 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:05 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:05 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:05 --> URI Class Initialized
INFO - 2024-12-21 15:42:06 --> Router Class Initialized
INFO - 2024-12-21 15:42:06 --> Output Class Initialized
INFO - 2024-12-21 15:42:06 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:06 --> Input Class Initialized
INFO - 2024-12-21 15:42:06 --> Language Class Initialized
ERROR - 2024-12-21 15:42:06 --> 404 Page Not Found: Wsoyanzphp/index
INFO - 2024-12-21 15:42:06 --> Config Class Initialized
INFO - 2024-12-21 15:42:06 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:06 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:06 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:06 --> URI Class Initialized
INFO - 2024-12-21 15:42:06 --> Router Class Initialized
INFO - 2024-12-21 15:42:06 --> Output Class Initialized
INFO - 2024-12-21 15:42:06 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:06 --> Input Class Initialized
INFO - 2024-12-21 15:42:06 --> Language Class Initialized
ERROR - 2024-12-21 15:42:06 --> 404 Page Not Found: Yanzphp/index
INFO - 2024-12-21 15:42:07 --> Config Class Initialized
INFO - 2024-12-21 15:42:07 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:07 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:07 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:07 --> URI Class Initialized
INFO - 2024-12-21 15:42:07 --> Router Class Initialized
INFO - 2024-12-21 15:42:07 --> Output Class Initialized
INFO - 2024-12-21 15:42:07 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:07 --> Input Class Initialized
INFO - 2024-12-21 15:42:07 --> Language Class Initialized
ERROR - 2024-12-21 15:42:07 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:42:08 --> Config Class Initialized
INFO - 2024-12-21 15:42:08 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:08 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:08 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:08 --> URI Class Initialized
INFO - 2024-12-21 15:42:08 --> Router Class Initialized
INFO - 2024-12-21 15:42:08 --> Output Class Initialized
INFO - 2024-12-21 15:42:08 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:08 --> Input Class Initialized
INFO - 2024-12-21 15:42:08 --> Language Class Initialized
ERROR - 2024-12-21 15:42:08 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:09 --> Config Class Initialized
INFO - 2024-12-21 15:42:09 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:09 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:09 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:09 --> URI Class Initialized
INFO - 2024-12-21 15:42:09 --> Router Class Initialized
INFO - 2024-12-21 15:42:09 --> Output Class Initialized
INFO - 2024-12-21 15:42:09 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:09 --> Input Class Initialized
INFO - 2024-12-21 15:42:09 --> Language Class Initialized
ERROR - 2024-12-21 15:42:09 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:10 --> Config Class Initialized
INFO - 2024-12-21 15:42:10 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:10 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:10 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:10 --> URI Class Initialized
INFO - 2024-12-21 15:42:10 --> Router Class Initialized
INFO - 2024-12-21 15:42:10 --> Output Class Initialized
INFO - 2024-12-21 15:42:10 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:10 --> Input Class Initialized
INFO - 2024-12-21 15:42:10 --> Language Class Initialized
ERROR - 2024-12-21 15:42:10 --> 404 Page Not Found: Cache-compatphp/index
INFO - 2024-12-21 15:42:11 --> Config Class Initialized
INFO - 2024-12-21 15:42:11 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:11 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:11 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:11 --> URI Class Initialized
INFO - 2024-12-21 15:42:11 --> Router Class Initialized
INFO - 2024-12-21 15:42:11 --> Output Class Initialized
INFO - 2024-12-21 15:42:11 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:11 --> Input Class Initialized
INFO - 2024-12-21 15:42:11 --> Language Class Initialized
ERROR - 2024-12-21 15:42:11 --> 404 Page Not Found: Ajax-actionsphp/index
INFO - 2024-12-21 15:42:11 --> Config Class Initialized
INFO - 2024-12-21 15:42:11 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:11 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:11 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:11 --> URI Class Initialized
INFO - 2024-12-21 15:42:11 --> Router Class Initialized
INFO - 2024-12-21 15:42:11 --> Output Class Initialized
INFO - 2024-12-21 15:42:11 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:11 --> Input Class Initialized
INFO - 2024-12-21 15:42:11 --> Language Class Initialized
ERROR - 2024-12-21 15:42:11 --> 404 Page Not Found: Wp-admin/ajax-actions.php
INFO - 2024-12-21 15:42:12 --> Config Class Initialized
INFO - 2024-12-21 15:42:12 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:12 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:12 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:12 --> URI Class Initialized
INFO - 2024-12-21 15:42:12 --> Router Class Initialized
INFO - 2024-12-21 15:42:12 --> Output Class Initialized
INFO - 2024-12-21 15:42:12 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:12 --> Input Class Initialized
INFO - 2024-12-21 15:42:12 --> Language Class Initialized
ERROR - 2024-12-21 15:42:12 --> 404 Page Not Found: Wp-consarphp/index
INFO - 2024-12-21 15:42:13 --> Config Class Initialized
INFO - 2024-12-21 15:42:13 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:13 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:13 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:13 --> URI Class Initialized
INFO - 2024-12-21 15:42:13 --> Router Class Initialized
INFO - 2024-12-21 15:42:13 --> Output Class Initialized
INFO - 2024-12-21 15:42:13 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:13 --> Input Class Initialized
INFO - 2024-12-21 15:42:13 --> Language Class Initialized
ERROR - 2024-12-21 15:42:13 --> 404 Page Not Found: Repeaterphp/index
INFO - 2024-12-21 15:42:14 --> Config Class Initialized
INFO - 2024-12-21 15:42:14 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:14 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:14 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:14 --> URI Class Initialized
INFO - 2024-12-21 15:42:14 --> Router Class Initialized
INFO - 2024-12-21 15:42:14 --> Output Class Initialized
INFO - 2024-12-21 15:42:14 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:14 --> Input Class Initialized
INFO - 2024-12-21 15:42:14 --> Language Class Initialized
ERROR - 2024-12-21 15:42:14 --> 404 Page Not Found: Admin-postphp/index
INFO - 2024-12-21 15:42:15 --> Config Class Initialized
INFO - 2024-12-21 15:42:15 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:15 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:15 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:15 --> URI Class Initialized
INFO - 2024-12-21 15:42:15 --> Router Class Initialized
INFO - 2024-12-21 15:42:15 --> Output Class Initialized
INFO - 2024-12-21 15:42:15 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:15 --> Input Class Initialized
INFO - 2024-12-21 15:42:15 --> Language Class Initialized
ERROR - 2024-12-21 15:42:15 --> 404 Page Not Found: Wp-admin/maint
INFO - 2024-12-21 15:42:16 --> Config Class Initialized
INFO - 2024-12-21 15:42:16 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:16 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:16 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:16 --> URI Class Initialized
INFO - 2024-12-21 15:42:16 --> Router Class Initialized
INFO - 2024-12-21 15:42:16 --> Output Class Initialized
INFO - 2024-12-21 15:42:16 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:16 --> Input Class Initialized
INFO - 2024-12-21 15:42:16 --> Language Class Initialized
ERROR - 2024-12-21 15:42:16 --> 404 Page Not Found: Wp-admin/dropdown.php
INFO - 2024-12-21 15:42:17 --> Config Class Initialized
INFO - 2024-12-21 15:42:17 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:17 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:17 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:17 --> URI Class Initialized
INFO - 2024-12-21 15:42:17 --> Router Class Initialized
INFO - 2024-12-21 15:42:17 --> Output Class Initialized
INFO - 2024-12-21 15:42:17 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:17 --> Input Class Initialized
INFO - 2024-12-21 15:42:17 --> Language Class Initialized
ERROR - 2024-12-21 15:42:17 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:42:18 --> Config Class Initialized
INFO - 2024-12-21 15:42:18 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:18 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:18 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:18 --> URI Class Initialized
INFO - 2024-12-21 15:42:18 --> Router Class Initialized
INFO - 2024-12-21 15:42:18 --> Output Class Initialized
INFO - 2024-12-21 15:42:18 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:18 --> Input Class Initialized
INFO - 2024-12-21 15:42:18 --> Language Class Initialized
ERROR - 2024-12-21 15:42:18 --> 404 Page Not Found: Dropdownphp/index
INFO - 2024-12-21 15:42:18 --> Config Class Initialized
INFO - 2024-12-21 15:42:18 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:18 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:18 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:18 --> URI Class Initialized
INFO - 2024-12-21 15:42:18 --> Router Class Initialized
INFO - 2024-12-21 15:42:18 --> Output Class Initialized
INFO - 2024-12-21 15:42:18 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:19 --> Input Class Initialized
INFO - 2024-12-21 15:42:19 --> Language Class Initialized
ERROR - 2024-12-21 15:42:19 --> 404 Page Not Found: Aboutphp/index
INFO - 2024-12-21 15:42:19 --> Config Class Initialized
INFO - 2024-12-21 15:42:19 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:19 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:19 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:19 --> URI Class Initialized
INFO - 2024-12-21 15:42:19 --> Router Class Initialized
INFO - 2024-12-21 15:42:19 --> Output Class Initialized
INFO - 2024-12-21 15:42:19 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:19 --> Input Class Initialized
INFO - 2024-12-21 15:42:20 --> Language Class Initialized
ERROR - 2024-12-21 15:42:20 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-21 15:42:20 --> Config Class Initialized
INFO - 2024-12-21 15:42:20 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:20 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:20 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:20 --> URI Class Initialized
INFO - 2024-12-21 15:42:20 --> Router Class Initialized
INFO - 2024-12-21 15:42:20 --> Output Class Initialized
INFO - 2024-12-21 15:42:20 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:20 --> Input Class Initialized
INFO - 2024-12-21 15:42:21 --> Language Class Initialized
ERROR - 2024-12-21 15:42:21 --> 404 Page Not Found: Aboutphp7/index
INFO - 2024-12-21 15:42:22 --> Config Class Initialized
INFO - 2024-12-21 15:42:22 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:22 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:22 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:22 --> URI Class Initialized
INFO - 2024-12-21 15:42:22 --> Router Class Initialized
INFO - 2024-12-21 15:42:22 --> Output Class Initialized
INFO - 2024-12-21 15:42:22 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:22 --> Input Class Initialized
INFO - 2024-12-21 15:42:22 --> Language Class Initialized
ERROR - 2024-12-21 15:42:22 --> 404 Page Not Found: Alfanewphp7/index
INFO - 2024-12-21 15:42:22 --> Config Class Initialized
INFO - 2024-12-21 15:42:22 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:22 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:22 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:22 --> URI Class Initialized
INFO - 2024-12-21 15:42:22 --> Router Class Initialized
INFO - 2024-12-21 15:42:22 --> Output Class Initialized
INFO - 2024-12-21 15:42:22 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:23 --> Input Class Initialized
INFO - 2024-12-21 15:42:23 --> Language Class Initialized
ERROR - 2024-12-21 15:42:23 --> 404 Page Not Found: Adminfunsphp7/index
INFO - 2024-12-21 15:42:24 --> Config Class Initialized
INFO - 2024-12-21 15:42:24 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:24 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:24 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:24 --> URI Class Initialized
INFO - 2024-12-21 15:42:24 --> Router Class Initialized
INFO - 2024-12-21 15:42:24 --> Output Class Initialized
INFO - 2024-12-21 15:42:24 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:24 --> Input Class Initialized
INFO - 2024-12-21 15:42:24 --> Language Class Initialized
ERROR - 2024-12-21 15:42:24 --> 404 Page Not Found: Ebsphp7/index
INFO - 2024-12-21 15:42:25 --> Config Class Initialized
INFO - 2024-12-21 15:42:25 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:25 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:25 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:25 --> URI Class Initialized
INFO - 2024-12-21 15:42:25 --> Router Class Initialized
INFO - 2024-12-21 15:42:25 --> Output Class Initialized
INFO - 2024-12-21 15:42:25 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:25 --> Input Class Initialized
INFO - 2024-12-21 15:42:25 --> Language Class Initialized
ERROR - 2024-12-21 15:42:25 --> 404 Page Not Found: Wsphp7/index
INFO - 2024-12-21 15:42:26 --> Config Class Initialized
INFO - 2024-12-21 15:42:26 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:26 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:26 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:26 --> URI Class Initialized
INFO - 2024-12-21 15:42:26 --> Router Class Initialized
INFO - 2024-12-21 15:42:26 --> Output Class Initialized
INFO - 2024-12-21 15:42:26 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:26 --> Input Class Initialized
INFO - 2024-12-21 15:42:26 --> Language Class Initialized
ERROR - 2024-12-21 15:42:26 --> 404 Page Not Found: Alfanew2php7/index
INFO - 2024-12-21 15:42:27 --> Config Class Initialized
INFO - 2024-12-21 15:42:27 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:27 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:27 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:27 --> URI Class Initialized
INFO - 2024-12-21 15:42:27 --> Router Class Initialized
INFO - 2024-12-21 15:42:27 --> Output Class Initialized
INFO - 2024-12-21 15:42:27 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:27 --> Input Class Initialized
INFO - 2024-12-21 15:42:27 --> Language Class Initialized
ERROR - 2024-12-21 15:42:27 --> 404 Page Not Found: Alfa-rex2php7/index
INFO - 2024-12-21 15:42:27 --> Config Class Initialized
INFO - 2024-12-21 15:42:27 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:27 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:27 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:27 --> URI Class Initialized
INFO - 2024-12-21 15:42:27 --> Router Class Initialized
INFO - 2024-12-21 15:42:27 --> Output Class Initialized
INFO - 2024-12-21 15:42:27 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:28 --> Input Class Initialized
INFO - 2024-12-21 15:42:28 --> Language Class Initialized
ERROR - 2024-12-21 15:42:28 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:42:28 --> Config Class Initialized
INFO - 2024-12-21 15:42:28 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:28 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:28 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:28 --> URI Class Initialized
INFO - 2024-12-21 15:42:28 --> Router Class Initialized
INFO - 2024-12-21 15:42:28 --> Output Class Initialized
INFO - 2024-12-21 15:42:28 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:28 --> Input Class Initialized
INFO - 2024-12-21 15:42:28 --> Language Class Initialized
ERROR - 2024-12-21 15:42:28 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:42:29 --> Config Class Initialized
INFO - 2024-12-21 15:42:29 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:29 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:29 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:29 --> URI Class Initialized
INFO - 2024-12-21 15:42:29 --> Router Class Initialized
INFO - 2024-12-21 15:42:29 --> Output Class Initialized
INFO - 2024-12-21 15:42:29 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:29 --> Input Class Initialized
INFO - 2024-12-21 15:42:29 --> Language Class Initialized
ERROR - 2024-12-21 15:42:29 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:42:30 --> Config Class Initialized
INFO - 2024-12-21 15:42:30 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:30 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:30 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:30 --> URI Class Initialized
INFO - 2024-12-21 15:42:30 --> Router Class Initialized
INFO - 2024-12-21 15:42:30 --> Output Class Initialized
INFO - 2024-12-21 15:42:30 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:30 --> Input Class Initialized
INFO - 2024-12-21 15:42:30 --> Language Class Initialized
ERROR - 2024-12-21 15:42:30 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:42:31 --> Config Class Initialized
INFO - 2024-12-21 15:42:31 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:31 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:31 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:31 --> URI Class Initialized
INFO - 2024-12-21 15:42:31 --> Router Class Initialized
INFO - 2024-12-21 15:42:31 --> Output Class Initialized
INFO - 2024-12-21 15:42:31 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:31 --> Input Class Initialized
INFO - 2024-12-21 15:42:31 --> Language Class Initialized
ERROR - 2024-12-21 15:42:31 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:32 --> Config Class Initialized
INFO - 2024-12-21 15:42:32 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:32 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:32 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:32 --> URI Class Initialized
INFO - 2024-12-21 15:42:32 --> Router Class Initialized
INFO - 2024-12-21 15:42:32 --> Output Class Initialized
INFO - 2024-12-21 15:42:32 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:32 --> Input Class Initialized
INFO - 2024-12-21 15:42:32 --> Language Class Initialized
ERROR - 2024-12-21 15:42:32 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:42:33 --> Config Class Initialized
INFO - 2024-12-21 15:42:33 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:33 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:33 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:33 --> URI Class Initialized
INFO - 2024-12-21 15:42:33 --> Router Class Initialized
INFO - 2024-12-21 15:42:33 --> Output Class Initialized
INFO - 2024-12-21 15:42:33 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:33 --> Input Class Initialized
INFO - 2024-12-21 15:42:33 --> Language Class Initialized
ERROR - 2024-12-21 15:42:33 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:33 --> Config Class Initialized
INFO - 2024-12-21 15:42:33 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:33 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:33 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:33 --> URI Class Initialized
INFO - 2024-12-21 15:42:33 --> Router Class Initialized
INFO - 2024-12-21 15:42:33 --> Output Class Initialized
INFO - 2024-12-21 15:42:33 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:33 --> Input Class Initialized
INFO - 2024-12-21 15:42:33 --> Language Class Initialized
ERROR - 2024-12-21 15:42:33 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:34 --> Config Class Initialized
INFO - 2024-12-21 15:42:34 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:34 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:34 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:34 --> URI Class Initialized
INFO - 2024-12-21 15:42:34 --> Router Class Initialized
INFO - 2024-12-21 15:42:34 --> Output Class Initialized
INFO - 2024-12-21 15:42:34 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:34 --> Input Class Initialized
INFO - 2024-12-21 15:42:34 --> Language Class Initialized
ERROR - 2024-12-21 15:42:34 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-21 15:42:35 --> Config Class Initialized
INFO - 2024-12-21 15:42:35 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:35 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:35 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:35 --> URI Class Initialized
INFO - 2024-12-21 15:42:35 --> Router Class Initialized
INFO - 2024-12-21 15:42:35 --> Output Class Initialized
INFO - 2024-12-21 15:42:35 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:35 --> Input Class Initialized
INFO - 2024-12-21 15:42:35 --> Language Class Initialized
ERROR - 2024-12-21 15:42:35 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-21 15:42:36 --> Config Class Initialized
INFO - 2024-12-21 15:42:36 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:36 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:36 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:36 --> URI Class Initialized
INFO - 2024-12-21 15:42:36 --> Router Class Initialized
INFO - 2024-12-21 15:42:36 --> Output Class Initialized
INFO - 2024-12-21 15:42:36 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:36 --> Input Class Initialized
INFO - 2024-12-21 15:42:36 --> Language Class Initialized
ERROR - 2024-12-21 15:42:36 --> 404 Page Not Found: Xmrlpcphp/index
INFO - 2024-12-21 15:42:36 --> Config Class Initialized
INFO - 2024-12-21 15:42:36 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:36 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:36 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:37 --> URI Class Initialized
INFO - 2024-12-21 15:42:37 --> Router Class Initialized
INFO - 2024-12-21 15:42:37 --> Output Class Initialized
INFO - 2024-12-21 15:42:37 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:37 --> Input Class Initialized
INFO - 2024-12-21 15:42:37 --> Language Class Initialized
ERROR - 2024-12-21 15:42:37 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
INFO - 2024-12-21 15:42:37 --> Config Class Initialized
INFO - 2024-12-21 15:42:37 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:37 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:37 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:37 --> URI Class Initialized
INFO - 2024-12-21 15:42:37 --> Router Class Initialized
INFO - 2024-12-21 15:42:37 --> Output Class Initialized
INFO - 2024-12-21 15:42:37 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:37 --> Input Class Initialized
INFO - 2024-12-21 15:42:38 --> Language Class Initialized
ERROR - 2024-12-21 15:42:38 --> 404 Page Not Found: Css/xmrlpc.php
INFO - 2024-12-21 15:42:38 --> Config Class Initialized
INFO - 2024-12-21 15:42:38 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:38 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:38 --> URI Class Initialized
INFO - 2024-12-21 15:42:38 --> Router Class Initialized
INFO - 2024-12-21 15:42:38 --> Output Class Initialized
INFO - 2024-12-21 15:42:38 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:38 --> Input Class Initialized
INFO - 2024-12-21 15:42:38 --> Language Class Initialized
ERROR - 2024-12-21 15:42:38 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-21 15:42:40 --> Config Class Initialized
INFO - 2024-12-21 15:42:40 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:40 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:40 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:40 --> URI Class Initialized
INFO - 2024-12-21 15:42:40 --> Router Class Initialized
INFO - 2024-12-21 15:42:40 --> Output Class Initialized
INFO - 2024-12-21 15:42:40 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:40 --> Input Class Initialized
INFO - 2024-12-21 15:42:40 --> Language Class Initialized
ERROR - 2024-12-21 15:42:40 --> 404 Page Not Found: Img/xmrlpc.php
INFO - 2024-12-21 15:42:41 --> Config Class Initialized
INFO - 2024-12-21 15:42:41 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:41 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:41 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:41 --> URI Class Initialized
INFO - 2024-12-21 15:42:41 --> Router Class Initialized
INFO - 2024-12-21 15:42:41 --> Output Class Initialized
INFO - 2024-12-21 15:42:41 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:41 --> Input Class Initialized
INFO - 2024-12-21 15:42:41 --> Language Class Initialized
ERROR - 2024-12-21 15:42:41 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:42:42 --> Config Class Initialized
INFO - 2024-12-21 15:42:42 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:42 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:42 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:42 --> URI Class Initialized
INFO - 2024-12-21 15:42:42 --> Router Class Initialized
INFO - 2024-12-21 15:42:42 --> Output Class Initialized
INFO - 2024-12-21 15:42:42 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:42 --> Input Class Initialized
INFO - 2024-12-21 15:42:42 --> Language Class Initialized
ERROR - 2024-12-21 15:42:42 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:42:43 --> Config Class Initialized
INFO - 2024-12-21 15:42:43 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:43 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:43 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:43 --> URI Class Initialized
INFO - 2024-12-21 15:42:43 --> Router Class Initialized
INFO - 2024-12-21 15:42:43 --> Output Class Initialized
INFO - 2024-12-21 15:42:43 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:43 --> Input Class Initialized
INFO - 2024-12-21 15:42:43 --> Language Class Initialized
ERROR - 2024-12-21 15:42:43 --> 404 Page Not Found: Images/xmrlpc.php
INFO - 2024-12-21 15:42:44 --> Config Class Initialized
INFO - 2024-12-21 15:42:44 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:44 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:44 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:44 --> URI Class Initialized
INFO - 2024-12-21 15:42:44 --> Router Class Initialized
INFO - 2024-12-21 15:42:44 --> Output Class Initialized
INFO - 2024-12-21 15:42:44 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:44 --> Input Class Initialized
INFO - 2024-12-21 15:42:44 --> Language Class Initialized
ERROR - 2024-12-21 15:42:44 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:42:44 --> Config Class Initialized
INFO - 2024-12-21 15:42:44 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:44 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:44 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:44 --> URI Class Initialized
INFO - 2024-12-21 15:42:44 --> Router Class Initialized
INFO - 2024-12-21 15:42:44 --> Output Class Initialized
INFO - 2024-12-21 15:42:45 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:45 --> Input Class Initialized
INFO - 2024-12-21 15:42:45 --> Language Class Initialized
ERROR - 2024-12-21 15:42:45 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:42:45 --> Config Class Initialized
INFO - 2024-12-21 15:42:45 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:45 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:45 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:45 --> URI Class Initialized
INFO - 2024-12-21 15:42:45 --> Router Class Initialized
INFO - 2024-12-21 15:42:45 --> Output Class Initialized
INFO - 2024-12-21 15:42:45 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:45 --> Input Class Initialized
INFO - 2024-12-21 15:42:45 --> Language Class Initialized
ERROR - 2024-12-21 15:42:45 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-21 15:42:46 --> Config Class Initialized
INFO - 2024-12-21 15:42:46 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:46 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:46 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:46 --> URI Class Initialized
INFO - 2024-12-21 15:42:46 --> Router Class Initialized
INFO - 2024-12-21 15:42:46 --> Output Class Initialized
INFO - 2024-12-21 15:42:46 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:46 --> Input Class Initialized
INFO - 2024-12-21 15:42:46 --> Language Class Initialized
ERROR - 2024-12-21 15:42:46 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:42:47 --> Config Class Initialized
INFO - 2024-12-21 15:42:47 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:47 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:47 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:47 --> URI Class Initialized
INFO - 2024-12-21 15:42:47 --> Router Class Initialized
INFO - 2024-12-21 15:42:47 --> Output Class Initialized
INFO - 2024-12-21 15:42:47 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:47 --> Input Class Initialized
INFO - 2024-12-21 15:42:47 --> Language Class Initialized
ERROR - 2024-12-21 15:42:47 --> 404 Page Not Found: Wp-admin/xmrlpc.php
INFO - 2024-12-21 15:42:48 --> Config Class Initialized
INFO - 2024-12-21 15:42:48 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:48 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:48 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:48 --> URI Class Initialized
INFO - 2024-12-21 15:42:48 --> Router Class Initialized
INFO - 2024-12-21 15:42:48 --> Output Class Initialized
INFO - 2024-12-21 15:42:48 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:48 --> Input Class Initialized
INFO - 2024-12-21 15:42:48 --> Language Class Initialized
ERROR - 2024-12-21 15:42:48 --> 404 Page Not Found: 403php/index
INFO - 2024-12-21 15:42:49 --> Config Class Initialized
INFO - 2024-12-21 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:49 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:49 --> URI Class Initialized
INFO - 2024-12-21 15:42:49 --> Router Class Initialized
INFO - 2024-12-21 15:42:49 --> Output Class Initialized
INFO - 2024-12-21 15:42:49 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:49 --> Input Class Initialized
INFO - 2024-12-21 15:42:49 --> Language Class Initialized
ERROR - 2024-12-21 15:42:49 --> 404 Page Not Found: Contentphp/index
INFO - 2024-12-21 15:42:49 --> Config Class Initialized
INFO - 2024-12-21 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:49 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:49 --> URI Class Initialized
INFO - 2024-12-21 15:42:49 --> Router Class Initialized
INFO - 2024-12-21 15:42:49 --> Output Class Initialized
INFO - 2024-12-21 15:42:49 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:49 --> Input Class Initialized
INFO - 2024-12-21 15:42:49 --> Language Class Initialized
ERROR - 2024-12-21 15:42:49 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:50 --> Config Class Initialized
INFO - 2024-12-21 15:42:50 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:50 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:50 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:50 --> URI Class Initialized
INFO - 2024-12-21 15:42:50 --> Router Class Initialized
INFO - 2024-12-21 15:42:50 --> Output Class Initialized
INFO - 2024-12-21 15:42:50 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:50 --> Input Class Initialized
INFO - 2024-12-21 15:42:50 --> Language Class Initialized
ERROR - 2024-12-21 15:42:50 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:51 --> Config Class Initialized
INFO - 2024-12-21 15:42:51 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:51 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:51 --> URI Class Initialized
INFO - 2024-12-21 15:42:51 --> Router Class Initialized
INFO - 2024-12-21 15:42:51 --> Output Class Initialized
INFO - 2024-12-21 15:42:51 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:51 --> Input Class Initialized
INFO - 2024-12-21 15:42:51 --> Language Class Initialized
ERROR - 2024-12-21 15:42:51 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:51 --> Config Class Initialized
INFO - 2024-12-21 15:42:51 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:52 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:52 --> URI Class Initialized
INFO - 2024-12-21 15:42:52 --> Router Class Initialized
INFO - 2024-12-21 15:42:52 --> Output Class Initialized
INFO - 2024-12-21 15:42:52 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:52 --> Input Class Initialized
INFO - 2024-12-21 15:42:52 --> Language Class Initialized
ERROR - 2024-12-21 15:42:52 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:42:52 --> Config Class Initialized
INFO - 2024-12-21 15:42:52 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:52 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:52 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:52 --> URI Class Initialized
INFO - 2024-12-21 15:42:52 --> Router Class Initialized
INFO - 2024-12-21 15:42:52 --> Output Class Initialized
INFO - 2024-12-21 15:42:52 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:52 --> Input Class Initialized
INFO - 2024-12-21 15:42:52 --> Language Class Initialized
ERROR - 2024-12-21 15:42:52 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-21 15:42:53 --> Config Class Initialized
INFO - 2024-12-21 15:42:53 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:53 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:53 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:54 --> URI Class Initialized
INFO - 2024-12-21 15:42:54 --> Router Class Initialized
INFO - 2024-12-21 15:42:54 --> Output Class Initialized
INFO - 2024-12-21 15:42:54 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:54 --> Input Class Initialized
INFO - 2024-12-21 15:42:54 --> Language Class Initialized
ERROR - 2024-12-21 15:42:54 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:54 --> Config Class Initialized
INFO - 2024-12-21 15:42:54 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:54 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:54 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:54 --> URI Class Initialized
INFO - 2024-12-21 15:42:54 --> Router Class Initialized
INFO - 2024-12-21 15:42:54 --> Output Class Initialized
INFO - 2024-12-21 15:42:54 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:54 --> Input Class Initialized
INFO - 2024-12-21 15:42:54 --> Language Class Initialized
ERROR - 2024-12-21 15:42:54 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:42:55 --> Config Class Initialized
INFO - 2024-12-21 15:42:55 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:55 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:55 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:55 --> URI Class Initialized
INFO - 2024-12-21 15:42:55 --> Router Class Initialized
INFO - 2024-12-21 15:42:55 --> Output Class Initialized
INFO - 2024-12-21 15:42:55 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:55 --> Input Class Initialized
INFO - 2024-12-21 15:42:55 --> Language Class Initialized
ERROR - 2024-12-21 15:42:56 --> 404 Page Not Found: Berlinphp/index
INFO - 2024-12-21 15:42:57 --> Config Class Initialized
INFO - 2024-12-21 15:42:57 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:57 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:57 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:57 --> URI Class Initialized
INFO - 2024-12-21 15:42:57 --> Router Class Initialized
INFO - 2024-12-21 15:42:57 --> Output Class Initialized
INFO - 2024-12-21 15:42:57 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:57 --> Input Class Initialized
INFO - 2024-12-21 15:42:57 --> Language Class Initialized
ERROR - 2024-12-21 15:42:57 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-21 15:42:58 --> Config Class Initialized
INFO - 2024-12-21 15:42:58 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:42:58 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:42:58 --> Utf8 Class Initialized
INFO - 2024-12-21 15:42:58 --> URI Class Initialized
INFO - 2024-12-21 15:42:58 --> Router Class Initialized
INFO - 2024-12-21 15:42:58 --> Output Class Initialized
INFO - 2024-12-21 15:42:58 --> Security Class Initialized
DEBUG - 2024-12-21 15:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:42:58 --> Input Class Initialized
INFO - 2024-12-21 15:42:59 --> Language Class Initialized
ERROR - 2024-12-21 15:42:59 --> 404 Page Not Found: Wp-includes/style-engine
INFO - 2024-12-21 15:43:00 --> Config Class Initialized
INFO - 2024-12-21 15:43:00 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:00 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:00 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:00 --> URI Class Initialized
INFO - 2024-12-21 15:43:00 --> Router Class Initialized
INFO - 2024-12-21 15:43:00 --> Output Class Initialized
INFO - 2024-12-21 15:43:00 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:00 --> Input Class Initialized
INFO - 2024-12-21 15:43:00 --> Language Class Initialized
ERROR - 2024-12-21 15:43:00 --> 404 Page Not Found: Wp-includes/rest-api
INFO - 2024-12-21 15:43:01 --> Config Class Initialized
INFO - 2024-12-21 15:43:01 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:01 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:01 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:01 --> URI Class Initialized
INFO - 2024-12-21 15:43:01 --> Router Class Initialized
INFO - 2024-12-21 15:43:01 --> Output Class Initialized
INFO - 2024-12-21 15:43:01 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:01 --> Input Class Initialized
INFO - 2024-12-21 15:43:01 --> Language Class Initialized
ERROR - 2024-12-21 15:43:01 --> 404 Page Not Found: Wp-includes/SimplePie
INFO - 2024-12-21 15:43:02 --> Config Class Initialized
INFO - 2024-12-21 15:43:02 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:02 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:02 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:02 --> URI Class Initialized
INFO - 2024-12-21 15:43:02 --> Router Class Initialized
INFO - 2024-12-21 15:43:02 --> Output Class Initialized
INFO - 2024-12-21 15:43:02 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:02 --> Input Class Initialized
INFO - 2024-12-21 15:43:02 --> Language Class Initialized
ERROR - 2024-12-21 15:43:02 --> 404 Page Not Found: Wp-content/banners
INFO - 2024-12-21 15:43:03 --> Config Class Initialized
INFO - 2024-12-21 15:43:03 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:03 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:03 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:03 --> URI Class Initialized
INFO - 2024-12-21 15:43:03 --> Router Class Initialized
INFO - 2024-12-21 15:43:03 --> Output Class Initialized
INFO - 2024-12-21 15:43:03 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:03 --> Input Class Initialized
INFO - 2024-12-21 15:43:03 --> Language Class Initialized
ERROR - 2024-12-21 15:43:03 --> 404 Page Not Found: Wp-content/about.php
INFO - 2024-12-21 15:43:03 --> Config Class Initialized
INFO - 2024-12-21 15:43:03 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:03 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:03 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:03 --> URI Class Initialized
INFO - 2024-12-21 15:43:03 --> Router Class Initialized
INFO - 2024-12-21 15:43:03 --> Output Class Initialized
INFO - 2024-12-21 15:43:03 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:03 --> Input Class Initialized
INFO - 2024-12-21 15:43:03 --> Language Class Initialized
ERROR - 2024-12-21 15:43:03 --> 404 Page Not Found: Well-known/about.php
INFO - 2024-12-21 15:43:04 --> Config Class Initialized
INFO - 2024-12-21 15:43:04 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:04 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:04 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:04 --> URI Class Initialized
INFO - 2024-12-21 15:43:04 --> Router Class Initialized
INFO - 2024-12-21 15:43:04 --> Output Class Initialized
INFO - 2024-12-21 15:43:04 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:04 --> Input Class Initialized
INFO - 2024-12-21 15:43:04 --> Language Class Initialized
ERROR - 2024-12-21 15:43:04 --> 404 Page Not Found: Wp-includes/Text
INFO - 2024-12-21 15:43:05 --> Config Class Initialized
INFO - 2024-12-21 15:43:05 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:05 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:05 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:05 --> URI Class Initialized
INFO - 2024-12-21 15:43:05 --> Router Class Initialized
INFO - 2024-12-21 15:43:05 --> Output Class Initialized
INFO - 2024-12-21 15:43:05 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:05 --> Input Class Initialized
INFO - 2024-12-21 15:43:05 --> Language Class Initialized
ERROR - 2024-12-21 15:43:05 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2024-12-21 15:43:06 --> Config Class Initialized
INFO - 2024-12-21 15:43:06 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:06 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:06 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:06 --> URI Class Initialized
INFO - 2024-12-21 15:43:06 --> Router Class Initialized
INFO - 2024-12-21 15:43:06 --> Output Class Initialized
INFO - 2024-12-21 15:43:06 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:06 --> Input Class Initialized
INFO - 2024-12-21 15:43:06 --> Language Class Initialized
ERROR - 2024-12-21 15:43:06 --> 404 Page Not Found: Img/about.php
INFO - 2024-12-21 15:43:07 --> Config Class Initialized
INFO - 2024-12-21 15:43:07 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:07 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:07 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:07 --> URI Class Initialized
INFO - 2024-12-21 15:43:07 --> Router Class Initialized
INFO - 2024-12-21 15:43:07 --> Output Class Initialized
INFO - 2024-12-21 15:43:07 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:07 --> Input Class Initialized
INFO - 2024-12-21 15:43:07 --> Language Class Initialized
ERROR - 2024-12-21 15:43:07 --> 404 Page Not Found: Wp-content/languages
INFO - 2024-12-21 15:43:08 --> Config Class Initialized
INFO - 2024-12-21 15:43:08 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:08 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:08 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:08 --> URI Class Initialized
INFO - 2024-12-21 15:43:08 --> Router Class Initialized
INFO - 2024-12-21 15:43:08 --> Output Class Initialized
INFO - 2024-12-21 15:43:08 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:08 --> Input Class Initialized
INFO - 2024-12-21 15:43:08 --> Language Class Initialized
ERROR - 2024-12-21 15:43:08 --> 404 Page Not Found: Wp-includes/customize
INFO - 2024-12-21 15:43:09 --> Config Class Initialized
INFO - 2024-12-21 15:43:09 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:09 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:09 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:09 --> URI Class Initialized
INFO - 2024-12-21 15:43:09 --> Router Class Initialized
INFO - 2024-12-21 15:43:09 --> Output Class Initialized
INFO - 2024-12-21 15:43:09 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:09 --> Input Class Initialized
INFO - 2024-12-21 15:43:09 --> Language Class Initialized
ERROR - 2024-12-21 15:43:09 --> 404 Page Not Found: Wp-includesbak/html-api
INFO - 2024-12-21 15:43:11 --> Config Class Initialized
INFO - 2024-12-21 15:43:11 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:11 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:11 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:11 --> URI Class Initialized
INFO - 2024-12-21 15:43:11 --> Router Class Initialized
INFO - 2024-12-21 15:43:11 --> Output Class Initialized
INFO - 2024-12-21 15:43:11 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:11 --> Input Class Initialized
INFO - 2024-12-21 15:43:11 --> Language Class Initialized
ERROR - 2024-12-21 15:43:11 --> 404 Page Not Found: Wp-includes/widgets
INFO - 2024-12-21 15:43:12 --> Config Class Initialized
INFO - 2024-12-21 15:43:12 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:12 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:12 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:12 --> URI Class Initialized
INFO - 2024-12-21 15:43:12 --> Router Class Initialized
INFO - 2024-12-21 15:43:12 --> Output Class Initialized
INFO - 2024-12-21 15:43:12 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:12 --> Input Class Initialized
INFO - 2024-12-21 15:43:12 --> Language Class Initialized
ERROR - 2024-12-21 15:43:12 --> 404 Page Not Found: Wp-includes/IXR
INFO - 2024-12-21 15:43:14 --> Config Class Initialized
INFO - 2024-12-21 15:43:14 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:14 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:14 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:14 --> URI Class Initialized
INFO - 2024-12-21 15:43:14 --> Router Class Initialized
INFO - 2024-12-21 15:43:14 --> Output Class Initialized
INFO - 2024-12-21 15:43:14 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:14 --> Input Class Initialized
INFO - 2024-12-21 15:43:14 --> Language Class Initialized
ERROR - 2024-12-21 15:43:14 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:43:15 --> Config Class Initialized
INFO - 2024-12-21 15:43:15 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:15 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:15 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:15 --> URI Class Initialized
INFO - 2024-12-21 15:43:15 --> Router Class Initialized
INFO - 2024-12-21 15:43:15 --> Output Class Initialized
INFO - 2024-12-21 15:43:15 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:15 --> Input Class Initialized
INFO - 2024-12-21 15:43:15 --> Language Class Initialized
ERROR - 2024-12-21 15:43:15 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-21 15:43:17 --> Config Class Initialized
INFO - 2024-12-21 15:43:17 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:17 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:17 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:17 --> URI Class Initialized
INFO - 2024-12-21 15:43:17 --> Router Class Initialized
INFO - 2024-12-21 15:43:17 --> Output Class Initialized
INFO - 2024-12-21 15:43:17 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:17 --> Input Class Initialized
INFO - 2024-12-21 15:43:17 --> Language Class Initialized
ERROR - 2024-12-21 15:43:17 --> 404 Page Not Found: Wp-includes/pomo
INFO - 2024-12-21 15:43:18 --> Config Class Initialized
INFO - 2024-12-21 15:43:18 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:18 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:18 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:18 --> URI Class Initialized
INFO - 2024-12-21 15:43:18 --> Router Class Initialized
INFO - 2024-12-21 15:43:18 --> Output Class Initialized
INFO - 2024-12-21 15:43:18 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:18 --> Input Class Initialized
INFO - 2024-12-21 15:43:18 --> Language Class Initialized
ERROR - 2024-12-21 15:43:18 --> 404 Page Not Found: Wp-includes/block-patterns
INFO - 2024-12-21 15:43:20 --> Config Class Initialized
INFO - 2024-12-21 15:43:20 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:20 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:20 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:20 --> URI Class Initialized
INFO - 2024-12-21 15:43:20 --> Router Class Initialized
INFO - 2024-12-21 15:43:20 --> Output Class Initialized
INFO - 2024-12-21 15:43:20 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:20 --> Input Class Initialized
INFO - 2024-12-21 15:43:20 --> Language Class Initialized
ERROR - 2024-12-21 15:43:20 --> 404 Page Not Found: Wp-content/updraft
INFO - 2024-12-21 15:43:21 --> Config Class Initialized
INFO - 2024-12-21 15:43:21 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:21 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:21 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:21 --> URI Class Initialized
INFO - 2024-12-21 15:43:21 --> Router Class Initialized
INFO - 2024-12-21 15:43:21 --> Output Class Initialized
INFO - 2024-12-21 15:43:21 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:21 --> Input Class Initialized
INFO - 2024-12-21 15:43:21 --> Language Class Initialized
ERROR - 2024-12-21 15:43:21 --> 404 Page Not Found: Wp-content/upgrade-temp-backup
INFO - 2024-12-21 15:43:22 --> Config Class Initialized
INFO - 2024-12-21 15:43:22 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:22 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:22 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:22 --> URI Class Initialized
INFO - 2024-12-21 15:43:22 --> Router Class Initialized
INFO - 2024-12-21 15:43:22 --> Output Class Initialized
INFO - 2024-12-21 15:43:22 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:22 --> Input Class Initialized
INFO - 2024-12-21 15:43:22 --> Language Class Initialized
ERROR - 2024-12-21 15:43:22 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:43:23 --> Config Class Initialized
INFO - 2024-12-21 15:43:23 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:23 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:23 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:23 --> URI Class Initialized
INFO - 2024-12-21 15:43:23 --> Router Class Initialized
INFO - 2024-12-21 15:43:23 --> Output Class Initialized
INFO - 2024-12-21 15:43:23 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:23 --> Input Class Initialized
INFO - 2024-12-21 15:43:23 --> Language Class Initialized
ERROR - 2024-12-21 15:43:23 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-21 15:43:24 --> Config Class Initialized
INFO - 2024-12-21 15:43:24 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:24 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:24 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:24 --> URI Class Initialized
INFO - 2024-12-21 15:43:24 --> Router Class Initialized
INFO - 2024-12-21 15:43:24 --> Output Class Initialized
INFO - 2024-12-21 15:43:24 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:24 --> Input Class Initialized
INFO - 2024-12-21 15:43:24 --> Language Class Initialized
ERROR - 2024-12-21 15:43:24 --> 404 Page Not Found: Images/about.php
INFO - 2024-12-21 15:43:25 --> Config Class Initialized
INFO - 2024-12-21 15:43:25 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:25 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:25 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:25 --> URI Class Initialized
INFO - 2024-12-21 15:43:25 --> Router Class Initialized
INFO - 2024-12-21 15:43:25 --> Output Class Initialized
INFO - 2024-12-21 15:43:25 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:25 --> Input Class Initialized
INFO - 2024-12-21 15:43:25 --> Language Class Initialized
ERROR - 2024-12-21 15:43:25 --> 404 Page Not Found: Wp-content/blogs.dir
INFO - 2024-12-21 15:43:26 --> Config Class Initialized
INFO - 2024-12-21 15:43:26 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:26 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:26 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:26 --> URI Class Initialized
INFO - 2024-12-21 15:43:26 --> Router Class Initialized
INFO - 2024-12-21 15:43:26 --> Output Class Initialized
INFO - 2024-12-21 15:43:26 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:26 --> Input Class Initialized
INFO - 2024-12-21 15:43:26 --> Language Class Initialized
ERROR - 2024-12-21 15:43:26 --> 404 Page Not Found: Wp-includes/images
INFO - 2024-12-21 15:43:27 --> Config Class Initialized
INFO - 2024-12-21 15:43:27 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:27 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:27 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:27 --> URI Class Initialized
INFO - 2024-12-21 15:43:27 --> Router Class Initialized
INFO - 2024-12-21 15:43:27 --> Output Class Initialized
INFO - 2024-12-21 15:43:27 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:27 --> Input Class Initialized
INFO - 2024-12-21 15:43:27 --> Language Class Initialized
ERROR - 2024-12-21 15:43:27 --> 404 Page Not Found: Wp-includes/about.php
INFO - 2024-12-21 15:43:28 --> Config Class Initialized
INFO - 2024-12-21 15:43:28 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:28 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:28 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:28 --> URI Class Initialized
INFO - 2024-12-21 15:43:28 --> Router Class Initialized
INFO - 2024-12-21 15:43:28 --> Output Class Initialized
INFO - 2024-12-21 15:43:28 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:28 --> Input Class Initialized
INFO - 2024-12-21 15:43:28 --> Language Class Initialized
ERROR - 2024-12-21 15:43:28 --> 404 Page Not Found: Cgi-bin/about.php
INFO - 2024-12-21 15:43:28 --> Config Class Initialized
INFO - 2024-12-21 15:43:28 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:28 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:28 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:28 --> URI Class Initialized
INFO - 2024-12-21 15:43:28 --> Router Class Initialized
INFO - 2024-12-21 15:43:28 --> Output Class Initialized
INFO - 2024-12-21 15:43:28 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:28 --> Input Class Initialized
INFO - 2024-12-21 15:43:28 --> Language Class Initialized
ERROR - 2024-12-21 15:43:28 --> 404 Page Not Found: Wp-content/gallery
INFO - 2024-12-21 15:43:30 --> Config Class Initialized
INFO - 2024-12-21 15:43:30 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:30 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:30 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:30 --> URI Class Initialized
INFO - 2024-12-21 15:43:30 --> Router Class Initialized
INFO - 2024-12-21 15:43:30 --> Output Class Initialized
INFO - 2024-12-21 15:43:30 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:30 --> Input Class Initialized
INFO - 2024-12-21 15:43:30 --> Language Class Initialized
ERROR - 2024-12-21 15:43:30 --> 404 Page Not Found: Wp-includes/blocks
INFO - 2024-12-21 15:43:31 --> Config Class Initialized
INFO - 2024-12-21 15:43:31 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:31 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:31 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:31 --> URI Class Initialized
INFO - 2024-12-21 15:43:31 --> Router Class Initialized
INFO - 2024-12-21 15:43:31 --> Output Class Initialized
INFO - 2024-12-21 15:43:31 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:31 --> Input Class Initialized
INFO - 2024-12-21 15:43:31 --> Language Class Initialized
ERROR - 2024-12-21 15:43:31 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:43:32 --> Config Class Initialized
INFO - 2024-12-21 15:43:32 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:32 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:32 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:32 --> URI Class Initialized
INFO - 2024-12-21 15:43:32 --> Router Class Initialized
INFO - 2024-12-21 15:43:32 --> Output Class Initialized
INFO - 2024-12-21 15:43:32 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:32 --> Input Class Initialized
INFO - 2024-12-21 15:43:32 --> Language Class Initialized
ERROR - 2024-12-21 15:43:32 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:43:33 --> Config Class Initialized
INFO - 2024-12-21 15:43:33 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:33 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:33 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:33 --> URI Class Initialized
INFO - 2024-12-21 15:43:33 --> Router Class Initialized
INFO - 2024-12-21 15:43:33 --> Output Class Initialized
INFO - 2024-12-21 15:43:33 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:33 --> Input Class Initialized
INFO - 2024-12-21 15:43:33 --> Language Class Initialized
ERROR - 2024-12-21 15:43:33 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-21 15:43:35 --> Config Class Initialized
INFO - 2024-12-21 15:43:35 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:35 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:35 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:35 --> URI Class Initialized
INFO - 2024-12-21 15:43:35 --> Router Class Initialized
INFO - 2024-12-21 15:43:35 --> Output Class Initialized
INFO - 2024-12-21 15:43:35 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:35 --> Input Class Initialized
INFO - 2024-12-21 15:43:35 --> Language Class Initialized
ERROR - 2024-12-21 15:43:35 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-21 15:43:35 --> Config Class Initialized
INFO - 2024-12-21 15:43:35 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:35 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:35 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:35 --> URI Class Initialized
INFO - 2024-12-21 15:43:35 --> Router Class Initialized
INFO - 2024-12-21 15:43:35 --> Output Class Initialized
INFO - 2024-12-21 15:43:35 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:35 --> Input Class Initialized
INFO - 2024-12-21 15:43:35 --> Language Class Initialized
ERROR - 2024-12-21 15:43:35 --> 404 Page Not Found: Cloudphp/index
INFO - 2024-12-21 15:43:36 --> Config Class Initialized
INFO - 2024-12-21 15:43:36 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:36 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:36 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:36 --> URI Class Initialized
INFO - 2024-12-21 15:43:36 --> Router Class Initialized
INFO - 2024-12-21 15:43:36 --> Output Class Initialized
INFO - 2024-12-21 15:43:36 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:36 --> Input Class Initialized
INFO - 2024-12-21 15:43:36 --> Language Class Initialized
ERROR - 2024-12-21 15:43:36 --> 404 Page Not Found: Cgi-bin/cloud.php
INFO - 2024-12-21 15:43:37 --> Config Class Initialized
INFO - 2024-12-21 15:43:37 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:37 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:37 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:37 --> URI Class Initialized
INFO - 2024-12-21 15:43:37 --> Router Class Initialized
INFO - 2024-12-21 15:43:37 --> Output Class Initialized
INFO - 2024-12-21 15:43:37 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:37 --> Input Class Initialized
INFO - 2024-12-21 15:43:37 --> Language Class Initialized
ERROR - 2024-12-21 15:43:37 --> 404 Page Not Found: Wp-content/updates.php
INFO - 2024-12-21 15:43:38 --> Config Class Initialized
INFO - 2024-12-21 15:43:38 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:38 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:38 --> URI Class Initialized
INFO - 2024-12-21 15:43:38 --> Router Class Initialized
INFO - 2024-12-21 15:43:38 --> Output Class Initialized
INFO - 2024-12-21 15:43:38 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:38 --> Input Class Initialized
INFO - 2024-12-21 15:43:38 --> Language Class Initialized
ERROR - 2024-12-21 15:43:38 --> 404 Page Not Found: Css/cloud.php
INFO - 2024-12-21 15:43:39 --> Config Class Initialized
INFO - 2024-12-21 15:43:39 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:39 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:39 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:39 --> URI Class Initialized
INFO - 2024-12-21 15:43:39 --> Router Class Initialized
INFO - 2024-12-21 15:43:39 --> Output Class Initialized
INFO - 2024-12-21 15:43:39 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:39 --> Input Class Initialized
INFO - 2024-12-21 15:43:39 --> Language Class Initialized
ERROR - 2024-12-21 15:43:39 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-21 15:43:40 --> Config Class Initialized
INFO - 2024-12-21 15:43:40 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:40 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:40 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:40 --> URI Class Initialized
INFO - 2024-12-21 15:43:40 --> Router Class Initialized
INFO - 2024-12-21 15:43:40 --> Output Class Initialized
INFO - 2024-12-21 15:43:40 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:40 --> Input Class Initialized
INFO - 2024-12-21 15:43:40 --> Language Class Initialized
ERROR - 2024-12-21 15:43:40 --> 404 Page Not Found: Img/cloud.php
INFO - 2024-12-21 15:43:41 --> Config Class Initialized
INFO - 2024-12-21 15:43:41 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:41 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:41 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:41 --> URI Class Initialized
INFO - 2024-12-21 15:43:41 --> Router Class Initialized
INFO - 2024-12-21 15:43:41 --> Output Class Initialized
INFO - 2024-12-21 15:43:41 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:41 --> Input Class Initialized
INFO - 2024-12-21 15:43:41 --> Language Class Initialized
ERROR - 2024-12-21 15:43:41 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:43:42 --> Config Class Initialized
INFO - 2024-12-21 15:43:42 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:42 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:43 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:43 --> URI Class Initialized
INFO - 2024-12-21 15:43:43 --> Router Class Initialized
INFO - 2024-12-21 15:43:43 --> Output Class Initialized
INFO - 2024-12-21 15:43:43 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:43 --> Input Class Initialized
INFO - 2024-12-21 15:43:43 --> Language Class Initialized
ERROR - 2024-12-21 15:43:43 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:43:44 --> Config Class Initialized
INFO - 2024-12-21 15:43:44 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:44 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:44 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:44 --> URI Class Initialized
INFO - 2024-12-21 15:43:44 --> Router Class Initialized
INFO - 2024-12-21 15:43:44 --> Output Class Initialized
INFO - 2024-12-21 15:43:44 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:44 --> Input Class Initialized
INFO - 2024-12-21 15:43:44 --> Language Class Initialized
ERROR - 2024-12-21 15:43:44 --> 404 Page Not Found: Avaaphp/index
INFO - 2024-12-21 15:43:45 --> Config Class Initialized
INFO - 2024-12-21 15:43:45 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:45 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:45 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:45 --> URI Class Initialized
INFO - 2024-12-21 15:43:45 --> Router Class Initialized
INFO - 2024-12-21 15:43:45 --> Output Class Initialized
INFO - 2024-12-21 15:43:45 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:45 --> Input Class Initialized
INFO - 2024-12-21 15:43:45 --> Language Class Initialized
ERROR - 2024-12-21 15:43:45 --> 404 Page Not Found: Images/cloud.php
INFO - 2024-12-21 15:43:46 --> Config Class Initialized
INFO - 2024-12-21 15:43:46 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:46 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:46 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:46 --> URI Class Initialized
INFO - 2024-12-21 15:43:46 --> Router Class Initialized
INFO - 2024-12-21 15:43:46 --> Output Class Initialized
INFO - 2024-12-21 15:43:46 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:46 --> Input Class Initialized
INFO - 2024-12-21 15:43:46 --> Language Class Initialized
ERROR - 2024-12-21 15:43:46 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:43:48 --> Config Class Initialized
INFO - 2024-12-21 15:43:48 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:48 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:48 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:48 --> URI Class Initialized
INFO - 2024-12-21 15:43:48 --> Router Class Initialized
INFO - 2024-12-21 15:43:48 --> Output Class Initialized
INFO - 2024-12-21 15:43:48 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:48 --> Input Class Initialized
INFO - 2024-12-21 15:43:48 --> Language Class Initialized
ERROR - 2024-12-21 15:43:48 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-21 15:43:49 --> Config Class Initialized
INFO - 2024-12-21 15:43:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:49 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:49 --> URI Class Initialized
INFO - 2024-12-21 15:43:49 --> Router Class Initialized
INFO - 2024-12-21 15:43:49 --> Output Class Initialized
INFO - 2024-12-21 15:43:49 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:49 --> Input Class Initialized
INFO - 2024-12-21 15:43:49 --> Language Class Initialized
ERROR - 2024-12-21 15:43:49 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:43:50 --> Config Class Initialized
INFO - 2024-12-21 15:43:50 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:50 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:50 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:50 --> URI Class Initialized
INFO - 2024-12-21 15:43:50 --> Router Class Initialized
INFO - 2024-12-21 15:43:50 --> Output Class Initialized
INFO - 2024-12-21 15:43:50 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:50 --> Input Class Initialized
INFO - 2024-12-21 15:43:50 --> Language Class Initialized
ERROR - 2024-12-21 15:43:50 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-21 15:43:51 --> Config Class Initialized
INFO - 2024-12-21 15:43:51 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:51 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:51 --> URI Class Initialized
INFO - 2024-12-21 15:43:51 --> Router Class Initialized
INFO - 2024-12-21 15:43:51 --> Output Class Initialized
INFO - 2024-12-21 15:43:51 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:51 --> Input Class Initialized
INFO - 2024-12-21 15:43:51 --> Language Class Initialized
ERROR - 2024-12-21 15:43:51 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:43:52 --> Config Class Initialized
INFO - 2024-12-21 15:43:52 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:52 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:52 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:52 --> URI Class Initialized
INFO - 2024-12-21 15:43:52 --> Router Class Initialized
INFO - 2024-12-21 15:43:52 --> Output Class Initialized
INFO - 2024-12-21 15:43:52 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:52 --> Input Class Initialized
INFO - 2024-12-21 15:43:52 --> Language Class Initialized
ERROR - 2024-12-21 15:43:52 --> 404 Page Not Found: Wp-admin/cloud.php
INFO - 2024-12-21 15:43:52 --> Config Class Initialized
INFO - 2024-12-21 15:43:52 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:52 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:52 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:52 --> URI Class Initialized
INFO - 2024-12-21 15:43:52 --> Router Class Initialized
INFO - 2024-12-21 15:43:52 --> Output Class Initialized
INFO - 2024-12-21 15:43:52 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:52 --> Input Class Initialized
INFO - 2024-12-21 15:43:52 --> Language Class Initialized
ERROR - 2024-12-21 15:43:52 --> 404 Page Not Found: Updatesphp/index
INFO - 2024-12-21 15:43:54 --> Config Class Initialized
INFO - 2024-12-21 15:43:54 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:54 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:54 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:54 --> URI Class Initialized
INFO - 2024-12-21 15:43:54 --> Router Class Initialized
INFO - 2024-12-21 15:43:54 --> Output Class Initialized
INFO - 2024-12-21 15:43:54 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:54 --> Input Class Initialized
INFO - 2024-12-21 15:43:54 --> Language Class Initialized
ERROR - 2024-12-21 15:43:54 --> 404 Page Not Found: Libraries/legacy
INFO - 2024-12-21 15:43:55 --> Config Class Initialized
INFO - 2024-12-21 15:43:55 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:55 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:55 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:55 --> URI Class Initialized
INFO - 2024-12-21 15:43:55 --> Router Class Initialized
INFO - 2024-12-21 15:43:55 --> Output Class Initialized
INFO - 2024-12-21 15:43:55 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:55 --> Input Class Initialized
INFO - 2024-12-21 15:43:55 --> Language Class Initialized
ERROR - 2024-12-21 15:43:55 --> 404 Page Not Found: Libraries/phpmailer
INFO - 2024-12-21 15:43:56 --> Config Class Initialized
INFO - 2024-12-21 15:43:56 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:56 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:56 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:56 --> URI Class Initialized
INFO - 2024-12-21 15:43:56 --> Router Class Initialized
INFO - 2024-12-21 15:43:56 --> Output Class Initialized
INFO - 2024-12-21 15:43:56 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:56 --> Input Class Initialized
INFO - 2024-12-21 15:43:56 --> Language Class Initialized
ERROR - 2024-12-21 15:43:56 --> 404 Page Not Found: Libraries/vendor
INFO - 2024-12-21 15:43:57 --> Config Class Initialized
INFO - 2024-12-21 15:43:57 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:57 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:57 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:57 --> URI Class Initialized
INFO - 2024-12-21 15:43:57 --> Router Class Initialized
INFO - 2024-12-21 15:43:57 --> Output Class Initialized
INFO - 2024-12-21 15:43:57 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:57 --> Input Class Initialized
INFO - 2024-12-21 15:43:57 --> Language Class Initialized
ERROR - 2024-12-21 15:43:57 --> 404 Page Not Found: Alfa-rexphp7/index
INFO - 2024-12-21 15:43:58 --> Config Class Initialized
INFO - 2024-12-21 15:43:58 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:58 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:58 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:58 --> URI Class Initialized
INFO - 2024-12-21 15:43:58 --> Router Class Initialized
INFO - 2024-12-21 15:43:58 --> Output Class Initialized
INFO - 2024-12-21 15:43:58 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:58 --> Input Class Initialized
INFO - 2024-12-21 15:43:58 --> Language Class Initialized
ERROR - 2024-12-21 15:43:58 --> 404 Page Not Found: Alfanewphp/index
INFO - 2024-12-21 15:43:59 --> Config Class Initialized
INFO - 2024-12-21 15:43:59 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:43:59 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:43:59 --> Utf8 Class Initialized
INFO - 2024-12-21 15:43:59 --> URI Class Initialized
INFO - 2024-12-21 15:43:59 --> Router Class Initialized
INFO - 2024-12-21 15:43:59 --> Output Class Initialized
INFO - 2024-12-21 15:43:59 --> Security Class Initialized
DEBUG - 2024-12-21 15:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:43:59 --> Input Class Initialized
INFO - 2024-12-21 15:43:59 --> Language Class Initialized
ERROR - 2024-12-21 15:43:59 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:44:00 --> Config Class Initialized
INFO - 2024-12-21 15:44:00 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:00 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:00 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:00 --> URI Class Initialized
INFO - 2024-12-21 15:44:00 --> Router Class Initialized
INFO - 2024-12-21 15:44:00 --> Output Class Initialized
INFO - 2024-12-21 15:44:00 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:00 --> Input Class Initialized
INFO - 2024-12-21 15:44:00 --> Language Class Initialized
ERROR - 2024-12-21 15:44:00 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:44:01 --> Config Class Initialized
INFO - 2024-12-21 15:44:01 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:01 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:01 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:01 --> URI Class Initialized
INFO - 2024-12-21 15:44:01 --> Router Class Initialized
INFO - 2024-12-21 15:44:01 --> Output Class Initialized
INFO - 2024-12-21 15:44:01 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:01 --> Input Class Initialized
INFO - 2024-12-21 15:44:01 --> Language Class Initialized
ERROR - 2024-12-21 15:44:01 --> 404 Page Not Found: Wp-pphp7/index
INFO - 2024-12-21 15:44:02 --> Config Class Initialized
INFO - 2024-12-21 15:44:02 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:02 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:02 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:02 --> URI Class Initialized
INFO - 2024-12-21 15:44:02 --> Router Class Initialized
INFO - 2024-12-21 15:44:02 --> Output Class Initialized
INFO - 2024-12-21 15:44:02 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:02 --> Input Class Initialized
INFO - 2024-12-21 15:44:02 --> Language Class Initialized
ERROR - 2024-12-21 15:44:02 --> 404 Page Not Found: Wp-admin/repeater.php
INFO - 2024-12-21 15:44:04 --> Config Class Initialized
INFO - 2024-12-21 15:44:04 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:04 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:04 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:04 --> URI Class Initialized
INFO - 2024-12-21 15:44:04 --> Router Class Initialized
INFO - 2024-12-21 15:44:04 --> Output Class Initialized
INFO - 2024-12-21 15:44:04 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:04 --> Input Class Initialized
INFO - 2024-12-21 15:44:04 --> Language Class Initialized
ERROR - 2024-12-21 15:44:04 --> 404 Page Not Found: Wp-includes/repeater.php
INFO - 2024-12-21 15:44:05 --> Config Class Initialized
INFO - 2024-12-21 15:44:05 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:05 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:05 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:05 --> URI Class Initialized
INFO - 2024-12-21 15:44:05 --> Router Class Initialized
INFO - 2024-12-21 15:44:05 --> Output Class Initialized
INFO - 2024-12-21 15:44:05 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:05 --> Input Class Initialized
INFO - 2024-12-21 15:44:05 --> Language Class Initialized
ERROR - 2024-12-21 15:44:05 --> 404 Page Not Found: Wp-content/repeater.php
INFO - 2024-12-21 15:44:06 --> Config Class Initialized
INFO - 2024-12-21 15:44:06 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:06 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:06 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:06 --> URI Class Initialized
INFO - 2024-12-21 15:44:06 --> Router Class Initialized
INFO - 2024-12-21 15:44:06 --> Output Class Initialized
INFO - 2024-12-21 15:44:06 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:06 --> Input Class Initialized
INFO - 2024-12-21 15:44:06 --> Language Class Initialized
ERROR - 2024-12-21 15:44:06 --> 404 Page Not Found: Wsoyanzphp/index
INFO - 2024-12-21 15:44:07 --> Config Class Initialized
INFO - 2024-12-21 15:44:07 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:07 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:07 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:07 --> URI Class Initialized
INFO - 2024-12-21 15:44:07 --> Router Class Initialized
INFO - 2024-12-21 15:44:07 --> Output Class Initialized
INFO - 2024-12-21 15:44:07 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:07 --> Input Class Initialized
INFO - 2024-12-21 15:44:07 --> Language Class Initialized
ERROR - 2024-12-21 15:44:07 --> 404 Page Not Found: Yanzphp/index
INFO - 2024-12-21 15:44:07 --> Config Class Initialized
INFO - 2024-12-21 15:44:08 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:08 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:08 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:08 --> URI Class Initialized
INFO - 2024-12-21 15:44:08 --> Router Class Initialized
INFO - 2024-12-21 15:44:08 --> Output Class Initialized
INFO - 2024-12-21 15:44:08 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:08 --> Input Class Initialized
INFO - 2024-12-21 15:44:08 --> Language Class Initialized
ERROR - 2024-12-21 15:44:08 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:44:09 --> Config Class Initialized
INFO - 2024-12-21 15:44:09 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:09 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:09 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:09 --> URI Class Initialized
INFO - 2024-12-21 15:44:09 --> Router Class Initialized
INFO - 2024-12-21 15:44:09 --> Output Class Initialized
INFO - 2024-12-21 15:44:09 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:09 --> Input Class Initialized
INFO - 2024-12-21 15:44:09 --> Language Class Initialized
ERROR - 2024-12-21 15:44:09 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:44:10 --> Config Class Initialized
INFO - 2024-12-21 15:44:10 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:10 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:10 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:10 --> URI Class Initialized
INFO - 2024-12-21 15:44:10 --> Router Class Initialized
INFO - 2024-12-21 15:44:10 --> Output Class Initialized
INFO - 2024-12-21 15:44:10 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:10 --> Input Class Initialized
INFO - 2024-12-21 15:44:10 --> Language Class Initialized
ERROR - 2024-12-21 15:44:10 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:44:11 --> Config Class Initialized
INFO - 2024-12-21 15:44:11 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:11 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:11 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:11 --> URI Class Initialized
INFO - 2024-12-21 15:44:11 --> Router Class Initialized
INFO - 2024-12-21 15:44:11 --> Output Class Initialized
INFO - 2024-12-21 15:44:11 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:11 --> Input Class Initialized
INFO - 2024-12-21 15:44:11 --> Language Class Initialized
ERROR - 2024-12-21 15:44:11 --> 404 Page Not Found: Cache-compatphp/index
INFO - 2024-12-21 15:44:12 --> Config Class Initialized
INFO - 2024-12-21 15:44:12 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:12 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:12 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:12 --> URI Class Initialized
INFO - 2024-12-21 15:44:12 --> Router Class Initialized
INFO - 2024-12-21 15:44:12 --> Output Class Initialized
INFO - 2024-12-21 15:44:12 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:12 --> Input Class Initialized
INFO - 2024-12-21 15:44:12 --> Language Class Initialized
ERROR - 2024-12-21 15:44:12 --> 404 Page Not Found: Ajax-actionsphp/index
INFO - 2024-12-21 15:44:13 --> Config Class Initialized
INFO - 2024-12-21 15:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:13 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:13 --> URI Class Initialized
INFO - 2024-12-21 15:44:13 --> Router Class Initialized
INFO - 2024-12-21 15:44:13 --> Output Class Initialized
INFO - 2024-12-21 15:44:13 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:13 --> Input Class Initialized
INFO - 2024-12-21 15:44:13 --> Language Class Initialized
ERROR - 2024-12-21 15:44:13 --> 404 Page Not Found: Wp-admin/ajax-actions.php
INFO - 2024-12-21 15:44:14 --> Config Class Initialized
INFO - 2024-12-21 15:44:14 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:14 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:14 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:14 --> URI Class Initialized
INFO - 2024-12-21 15:44:14 --> Router Class Initialized
INFO - 2024-12-21 15:44:14 --> Output Class Initialized
INFO - 2024-12-21 15:44:14 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:14 --> Input Class Initialized
INFO - 2024-12-21 15:44:14 --> Language Class Initialized
ERROR - 2024-12-21 15:44:14 --> 404 Page Not Found: Wp-consarphp/index
INFO - 2024-12-21 15:44:16 --> Config Class Initialized
INFO - 2024-12-21 15:44:16 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:16 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:16 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:16 --> URI Class Initialized
INFO - 2024-12-21 15:44:16 --> Router Class Initialized
INFO - 2024-12-21 15:44:16 --> Output Class Initialized
INFO - 2024-12-21 15:44:16 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:16 --> Input Class Initialized
INFO - 2024-12-21 15:44:16 --> Language Class Initialized
ERROR - 2024-12-21 15:44:16 --> 404 Page Not Found: Repeaterphp/index
INFO - 2024-12-21 15:44:17 --> Config Class Initialized
INFO - 2024-12-21 15:44:17 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:17 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:17 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:17 --> URI Class Initialized
INFO - 2024-12-21 15:44:17 --> Router Class Initialized
INFO - 2024-12-21 15:44:17 --> Output Class Initialized
INFO - 2024-12-21 15:44:17 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:17 --> Input Class Initialized
INFO - 2024-12-21 15:44:17 --> Language Class Initialized
ERROR - 2024-12-21 15:44:17 --> 404 Page Not Found: Admin-postphp/index
INFO - 2024-12-21 15:44:18 --> Config Class Initialized
INFO - 2024-12-21 15:44:18 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:18 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:18 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:18 --> URI Class Initialized
INFO - 2024-12-21 15:44:18 --> Router Class Initialized
INFO - 2024-12-21 15:44:18 --> Output Class Initialized
INFO - 2024-12-21 15:44:18 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:18 --> Input Class Initialized
INFO - 2024-12-21 15:44:18 --> Language Class Initialized
ERROR - 2024-12-21 15:44:18 --> 404 Page Not Found: Wp-admin/maint
INFO - 2024-12-21 15:44:20 --> Config Class Initialized
INFO - 2024-12-21 15:44:20 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:20 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:20 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:20 --> URI Class Initialized
INFO - 2024-12-21 15:44:20 --> Router Class Initialized
INFO - 2024-12-21 15:44:20 --> Output Class Initialized
INFO - 2024-12-21 15:44:20 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:20 --> Input Class Initialized
INFO - 2024-12-21 15:44:20 --> Language Class Initialized
ERROR - 2024-12-21 15:44:20 --> 404 Page Not Found: Wp-admin/dropdown.php
INFO - 2024-12-21 15:44:21 --> Config Class Initialized
INFO - 2024-12-21 15:44:21 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:21 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:21 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:21 --> URI Class Initialized
INFO - 2024-12-21 15:44:21 --> Router Class Initialized
INFO - 2024-12-21 15:44:21 --> Output Class Initialized
INFO - 2024-12-21 15:44:21 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:21 --> Input Class Initialized
INFO - 2024-12-21 15:44:21 --> Language Class Initialized
ERROR - 2024-12-21 15:44:21 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:44:22 --> Config Class Initialized
INFO - 2024-12-21 15:44:22 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:22 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:22 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:22 --> URI Class Initialized
INFO - 2024-12-21 15:44:22 --> Router Class Initialized
INFO - 2024-12-21 15:44:22 --> Output Class Initialized
INFO - 2024-12-21 15:44:22 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:22 --> Input Class Initialized
INFO - 2024-12-21 15:44:22 --> Language Class Initialized
ERROR - 2024-12-21 15:44:22 --> 404 Page Not Found: Dropdownphp/index
INFO - 2024-12-21 15:44:23 --> Config Class Initialized
INFO - 2024-12-21 15:44:23 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:23 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:23 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:23 --> URI Class Initialized
INFO - 2024-12-21 15:44:23 --> Router Class Initialized
INFO - 2024-12-21 15:44:23 --> Output Class Initialized
INFO - 2024-12-21 15:44:23 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:23 --> Input Class Initialized
INFO - 2024-12-21 15:44:23 --> Language Class Initialized
ERROR - 2024-12-21 15:44:23 --> 404 Page Not Found: Aboutphp/index
INFO - 2024-12-21 15:44:24 --> Config Class Initialized
INFO - 2024-12-21 15:44:24 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:24 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:24 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:24 --> URI Class Initialized
INFO - 2024-12-21 15:44:24 --> Router Class Initialized
INFO - 2024-12-21 15:44:24 --> Output Class Initialized
INFO - 2024-12-21 15:44:24 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:24 --> Input Class Initialized
INFO - 2024-12-21 15:44:24 --> Language Class Initialized
ERROR - 2024-12-21 15:44:24 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-21 15:44:25 --> Config Class Initialized
INFO - 2024-12-21 15:44:25 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:25 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:25 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:25 --> URI Class Initialized
INFO - 2024-12-21 15:44:25 --> Router Class Initialized
INFO - 2024-12-21 15:44:25 --> Output Class Initialized
INFO - 2024-12-21 15:44:25 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:25 --> Input Class Initialized
INFO - 2024-12-21 15:44:25 --> Language Class Initialized
ERROR - 2024-12-21 15:44:25 --> 404 Page Not Found: Aboutphp7/index
INFO - 2024-12-21 15:44:26 --> Config Class Initialized
INFO - 2024-12-21 15:44:26 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:26 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:26 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:26 --> URI Class Initialized
INFO - 2024-12-21 15:44:26 --> Router Class Initialized
INFO - 2024-12-21 15:44:26 --> Output Class Initialized
INFO - 2024-12-21 15:44:26 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:26 --> Input Class Initialized
INFO - 2024-12-21 15:44:26 --> Language Class Initialized
ERROR - 2024-12-21 15:44:26 --> 404 Page Not Found: Alfanewphp7/index
INFO - 2024-12-21 15:44:26 --> Config Class Initialized
INFO - 2024-12-21 15:44:26 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:26 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:26 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:26 --> URI Class Initialized
INFO - 2024-12-21 15:44:26 --> Router Class Initialized
INFO - 2024-12-21 15:44:26 --> Output Class Initialized
INFO - 2024-12-21 15:44:26 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:26 --> Input Class Initialized
INFO - 2024-12-21 15:44:26 --> Language Class Initialized
ERROR - 2024-12-21 15:44:26 --> 404 Page Not Found: Adminfunsphp7/index
INFO - 2024-12-21 15:44:27 --> Config Class Initialized
INFO - 2024-12-21 15:44:27 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:27 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:27 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:27 --> URI Class Initialized
INFO - 2024-12-21 15:44:27 --> Router Class Initialized
INFO - 2024-12-21 15:44:27 --> Output Class Initialized
INFO - 2024-12-21 15:44:27 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:27 --> Input Class Initialized
INFO - 2024-12-21 15:44:27 --> Language Class Initialized
ERROR - 2024-12-21 15:44:27 --> 404 Page Not Found: Ebsphp7/index
INFO - 2024-12-21 15:44:28 --> Config Class Initialized
INFO - 2024-12-21 15:44:28 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:28 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:28 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:28 --> URI Class Initialized
INFO - 2024-12-21 15:44:28 --> Router Class Initialized
INFO - 2024-12-21 15:44:28 --> Output Class Initialized
INFO - 2024-12-21 15:44:28 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:28 --> Input Class Initialized
INFO - 2024-12-21 15:44:28 --> Language Class Initialized
ERROR - 2024-12-21 15:44:28 --> 404 Page Not Found: Wsphp7/index
INFO - 2024-12-21 15:44:28 --> Config Class Initialized
INFO - 2024-12-21 15:44:28 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:28 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:28 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:28 --> URI Class Initialized
INFO - 2024-12-21 15:44:28 --> Router Class Initialized
INFO - 2024-12-21 15:44:28 --> Output Class Initialized
INFO - 2024-12-21 15:44:28 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:28 --> Input Class Initialized
INFO - 2024-12-21 15:44:28 --> Language Class Initialized
ERROR - 2024-12-21 15:44:28 --> 404 Page Not Found: Alfanew2php7/index
INFO - 2024-12-21 15:44:29 --> Config Class Initialized
INFO - 2024-12-21 15:44:29 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:29 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:29 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:29 --> URI Class Initialized
INFO - 2024-12-21 15:44:29 --> Router Class Initialized
INFO - 2024-12-21 15:44:29 --> Output Class Initialized
INFO - 2024-12-21 15:44:29 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:29 --> Input Class Initialized
INFO - 2024-12-21 15:44:29 --> Language Class Initialized
ERROR - 2024-12-21 15:44:29 --> 404 Page Not Found: Alfa-rex2php7/index
INFO - 2024-12-21 15:44:31 --> Config Class Initialized
INFO - 2024-12-21 15:44:31 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:31 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:31 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:31 --> URI Class Initialized
INFO - 2024-12-21 15:44:31 --> Router Class Initialized
INFO - 2024-12-21 15:44:31 --> Output Class Initialized
INFO - 2024-12-21 15:44:31 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:31 --> Input Class Initialized
INFO - 2024-12-21 15:44:31 --> Language Class Initialized
ERROR - 2024-12-21 15:44:31 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:44:31 --> Config Class Initialized
INFO - 2024-12-21 15:44:31 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:31 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:31 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:31 --> URI Class Initialized
INFO - 2024-12-21 15:44:31 --> Router Class Initialized
INFO - 2024-12-21 15:44:31 --> Output Class Initialized
INFO - 2024-12-21 15:44:31 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:31 --> Input Class Initialized
INFO - 2024-12-21 15:44:32 --> Language Class Initialized
ERROR - 2024-12-21 15:44:32 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:44:33 --> Config Class Initialized
INFO - 2024-12-21 15:44:33 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:33 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:33 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:33 --> URI Class Initialized
INFO - 2024-12-21 15:44:33 --> Router Class Initialized
INFO - 2024-12-21 15:44:33 --> Output Class Initialized
INFO - 2024-12-21 15:44:33 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:33 --> Input Class Initialized
INFO - 2024-12-21 15:44:33 --> Language Class Initialized
ERROR - 2024-12-21 15:44:33 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:44:33 --> Config Class Initialized
INFO - 2024-12-21 15:44:33 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:33 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:33 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:33 --> URI Class Initialized
INFO - 2024-12-21 15:44:33 --> Router Class Initialized
INFO - 2024-12-21 15:44:33 --> Output Class Initialized
INFO - 2024-12-21 15:44:33 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:33 --> Input Class Initialized
INFO - 2024-12-21 15:44:33 --> Language Class Initialized
ERROR - 2024-12-21 15:44:34 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:44:34 --> Config Class Initialized
INFO - 2024-12-21 15:44:34 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:34 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:34 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:34 --> URI Class Initialized
INFO - 2024-12-21 15:44:34 --> Router Class Initialized
INFO - 2024-12-21 15:44:34 --> Output Class Initialized
INFO - 2024-12-21 15:44:34 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:34 --> Input Class Initialized
INFO - 2024-12-21 15:44:34 --> Language Class Initialized
ERROR - 2024-12-21 15:44:34 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:44:35 --> Config Class Initialized
INFO - 2024-12-21 15:44:35 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:35 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:35 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:35 --> URI Class Initialized
INFO - 2024-12-21 15:44:35 --> Router Class Initialized
INFO - 2024-12-21 15:44:35 --> Output Class Initialized
INFO - 2024-12-21 15:44:35 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:35 --> Input Class Initialized
INFO - 2024-12-21 15:44:35 --> Language Class Initialized
ERROR - 2024-12-21 15:44:35 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-21 15:44:36 --> Config Class Initialized
INFO - 2024-12-21 15:44:36 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:36 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:36 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:36 --> URI Class Initialized
INFO - 2024-12-21 15:44:36 --> Router Class Initialized
INFO - 2024-12-21 15:44:36 --> Output Class Initialized
INFO - 2024-12-21 15:44:36 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:36 --> Input Class Initialized
INFO - 2024-12-21 15:44:36 --> Language Class Initialized
ERROR - 2024-12-21 15:44:36 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:44:37 --> Config Class Initialized
INFO - 2024-12-21 15:44:37 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:37 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:37 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:37 --> URI Class Initialized
INFO - 2024-12-21 15:44:37 --> Router Class Initialized
INFO - 2024-12-21 15:44:37 --> Output Class Initialized
INFO - 2024-12-21 15:44:37 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:37 --> Input Class Initialized
INFO - 2024-12-21 15:44:37 --> Language Class Initialized
ERROR - 2024-12-21 15:44:37 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-21 15:44:38 --> Config Class Initialized
INFO - 2024-12-21 15:44:38 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:38 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:38 --> URI Class Initialized
INFO - 2024-12-21 15:44:38 --> Router Class Initialized
INFO - 2024-12-21 15:44:38 --> Output Class Initialized
INFO - 2024-12-21 15:44:38 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:38 --> Input Class Initialized
INFO - 2024-12-21 15:44:38 --> Language Class Initialized
ERROR - 2024-12-21 15:44:38 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-21 15:44:39 --> Config Class Initialized
INFO - 2024-12-21 15:44:39 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:39 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:39 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:39 --> URI Class Initialized
INFO - 2024-12-21 15:44:39 --> Router Class Initialized
INFO - 2024-12-21 15:44:39 --> Output Class Initialized
INFO - 2024-12-21 15:44:39 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:39 --> Input Class Initialized
INFO - 2024-12-21 15:44:39 --> Language Class Initialized
ERROR - 2024-12-21 15:44:39 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-21 15:44:40 --> Config Class Initialized
INFO - 2024-12-21 15:44:40 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:40 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:40 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:40 --> URI Class Initialized
INFO - 2024-12-21 15:44:40 --> Router Class Initialized
INFO - 2024-12-21 15:44:40 --> Output Class Initialized
INFO - 2024-12-21 15:44:40 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:40 --> Input Class Initialized
INFO - 2024-12-21 15:44:40 --> Language Class Initialized
ERROR - 2024-12-21 15:44:40 --> 404 Page Not Found: Xmrlpcphp/index
INFO - 2024-12-21 15:44:41 --> Config Class Initialized
INFO - 2024-12-21 15:44:41 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:41 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:41 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:41 --> URI Class Initialized
INFO - 2024-12-21 15:44:41 --> Router Class Initialized
INFO - 2024-12-21 15:44:41 --> Output Class Initialized
INFO - 2024-12-21 15:44:41 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:41 --> Input Class Initialized
INFO - 2024-12-21 15:44:41 --> Language Class Initialized
ERROR - 2024-12-21 15:44:41 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
INFO - 2024-12-21 15:44:41 --> Config Class Initialized
INFO - 2024-12-21 15:44:41 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:41 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:41 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:41 --> URI Class Initialized
INFO - 2024-12-21 15:44:41 --> Router Class Initialized
INFO - 2024-12-21 15:44:41 --> Output Class Initialized
INFO - 2024-12-21 15:44:41 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:41 --> Input Class Initialized
INFO - 2024-12-21 15:44:41 --> Language Class Initialized
ERROR - 2024-12-21 15:44:41 --> 404 Page Not Found: Css/xmrlpc.php
INFO - 2024-12-21 15:44:42 --> Config Class Initialized
INFO - 2024-12-21 15:44:42 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:42 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:42 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:42 --> URI Class Initialized
INFO - 2024-12-21 15:44:42 --> Router Class Initialized
INFO - 2024-12-21 15:44:42 --> Output Class Initialized
INFO - 2024-12-21 15:44:42 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:42 --> Input Class Initialized
INFO - 2024-12-21 15:44:42 --> Language Class Initialized
ERROR - 2024-12-21 15:44:42 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-21 15:44:43 --> Config Class Initialized
INFO - 2024-12-21 15:44:43 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:43 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:43 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:43 --> URI Class Initialized
INFO - 2024-12-21 15:44:43 --> Router Class Initialized
INFO - 2024-12-21 15:44:43 --> Output Class Initialized
INFO - 2024-12-21 15:44:43 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:43 --> Input Class Initialized
INFO - 2024-12-21 15:44:43 --> Language Class Initialized
ERROR - 2024-12-21 15:44:43 --> 404 Page Not Found: Img/xmrlpc.php
INFO - 2024-12-21 15:44:44 --> Config Class Initialized
INFO - 2024-12-21 15:44:44 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:44 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:44 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:44 --> URI Class Initialized
INFO - 2024-12-21 15:44:44 --> Router Class Initialized
INFO - 2024-12-21 15:44:44 --> Output Class Initialized
INFO - 2024-12-21 15:44:44 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:44 --> Input Class Initialized
INFO - 2024-12-21 15:44:44 --> Language Class Initialized
ERROR - 2024-12-21 15:44:44 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:44:45 --> Config Class Initialized
INFO - 2024-12-21 15:44:45 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:45 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:45 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:45 --> URI Class Initialized
INFO - 2024-12-21 15:44:45 --> Router Class Initialized
INFO - 2024-12-21 15:44:45 --> Output Class Initialized
INFO - 2024-12-21 15:44:45 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:45 --> Input Class Initialized
INFO - 2024-12-21 15:44:45 --> Language Class Initialized
ERROR - 2024-12-21 15:44:45 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-21 15:44:46 --> Config Class Initialized
INFO - 2024-12-21 15:44:46 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:46 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:46 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:46 --> URI Class Initialized
INFO - 2024-12-21 15:44:46 --> Router Class Initialized
INFO - 2024-12-21 15:44:46 --> Output Class Initialized
INFO - 2024-12-21 15:44:46 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:46 --> Input Class Initialized
INFO - 2024-12-21 15:44:46 --> Language Class Initialized
ERROR - 2024-12-21 15:44:46 --> 404 Page Not Found: Images/xmrlpc.php
INFO - 2024-12-21 15:44:46 --> Config Class Initialized
INFO - 2024-12-21 15:44:46 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:46 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:46 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:46 --> URI Class Initialized
INFO - 2024-12-21 15:44:46 --> Router Class Initialized
INFO - 2024-12-21 15:44:46 --> Output Class Initialized
INFO - 2024-12-21 15:44:46 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:46 --> Input Class Initialized
INFO - 2024-12-21 15:44:46 --> Language Class Initialized
ERROR - 2024-12-21 15:44:46 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-21 15:44:47 --> Config Class Initialized
INFO - 2024-12-21 15:44:47 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:47 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:47 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:47 --> URI Class Initialized
INFO - 2024-12-21 15:44:47 --> Router Class Initialized
INFO - 2024-12-21 15:44:47 --> Output Class Initialized
INFO - 2024-12-21 15:44:47 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:47 --> Input Class Initialized
INFO - 2024-12-21 15:44:47 --> Language Class Initialized
ERROR - 2024-12-21 15:44:47 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:44:47 --> Config Class Initialized
INFO - 2024-12-21 15:44:47 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:47 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:47 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:47 --> URI Class Initialized
INFO - 2024-12-21 15:44:47 --> Router Class Initialized
INFO - 2024-12-21 15:44:47 --> Output Class Initialized
INFO - 2024-12-21 15:44:47 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:48 --> Input Class Initialized
INFO - 2024-12-21 15:44:48 --> Language Class Initialized
ERROR - 2024-12-21 15:44:48 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-21 15:44:48 --> Config Class Initialized
INFO - 2024-12-21 15:44:48 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:48 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:48 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:48 --> URI Class Initialized
INFO - 2024-12-21 15:44:48 --> Router Class Initialized
INFO - 2024-12-21 15:44:48 --> Output Class Initialized
INFO - 2024-12-21 15:44:48 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:48 --> Input Class Initialized
INFO - 2024-12-21 15:44:48 --> Language Class Initialized
ERROR - 2024-12-21 15:44:48 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-21 15:44:49 --> Config Class Initialized
INFO - 2024-12-21 15:44:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 15:44:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 15:44:49 --> Utf8 Class Initialized
INFO - 2024-12-21 15:44:49 --> URI Class Initialized
INFO - 2024-12-21 15:44:49 --> Router Class Initialized
INFO - 2024-12-21 15:44:49 --> Output Class Initialized
INFO - 2024-12-21 15:44:49 --> Security Class Initialized
DEBUG - 2024-12-21 15:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 15:44:49 --> Input Class Initialized
INFO - 2024-12-21 15:44:49 --> Language Class Initialized
ERROR - 2024-12-21 15:44:49 --> 404 Page Not Found: Wp-admin/xmrlpc.php
INFO - 2024-12-21 18:53:21 --> Config Class Initialized
INFO - 2024-12-21 18:53:21 --> Hooks Class Initialized
DEBUG - 2024-12-21 18:53:21 --> UTF-8 Support Enabled
INFO - 2024-12-21 18:53:21 --> Utf8 Class Initialized
INFO - 2024-12-21 18:53:21 --> URI Class Initialized
DEBUG - 2024-12-21 18:53:21 --> No URI present. Default controller set.
INFO - 2024-12-21 18:53:21 --> Router Class Initialized
INFO - 2024-12-21 18:53:21 --> Output Class Initialized
INFO - 2024-12-21 18:53:21 --> Security Class Initialized
DEBUG - 2024-12-21 18:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 18:53:21 --> Input Class Initialized
INFO - 2024-12-21 18:53:21 --> Language Class Initialized
INFO - 2024-12-21 18:53:21 --> Loader Class Initialized
INFO - 2024-12-21 18:53:21 --> Helper loaded: url_helper
INFO - 2024-12-21 18:53:21 --> Helper loaded: html_helper
INFO - 2024-12-21 18:53:21 --> Helper loaded: file_helper
INFO - 2024-12-21 18:53:21 --> Helper loaded: string_helper
INFO - 2024-12-21 18:53:21 --> Helper loaded: form_helper
INFO - 2024-12-21 18:53:21 --> Helper loaded: my_helper
INFO - 2024-12-21 18:53:21 --> Database Driver Class Initialized
INFO - 2024-12-21 18:53:23 --> Upload Class Initialized
INFO - 2024-12-21 18:53:23 --> Email Class Initialized
INFO - 2024-12-21 18:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 18:53:23 --> Form Validation Class Initialized
INFO - 2024-12-21 18:53:23 --> Controller Class Initialized
INFO - 2024-12-21 18:59:37 --> Config Class Initialized
INFO - 2024-12-21 18:59:37 --> Hooks Class Initialized
DEBUG - 2024-12-21 18:59:37 --> UTF-8 Support Enabled
INFO - 2024-12-21 18:59:37 --> Utf8 Class Initialized
INFO - 2024-12-21 18:59:37 --> URI Class Initialized
INFO - 2024-12-21 18:59:37 --> Router Class Initialized
INFO - 2024-12-21 18:59:37 --> Output Class Initialized
INFO - 2024-12-21 18:59:37 --> Security Class Initialized
DEBUG - 2024-12-21 18:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 18:59:37 --> Input Class Initialized
INFO - 2024-12-21 18:59:37 --> Language Class Initialized
ERROR - 2024-12-21 18:59:37 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-21 18:59:38 --> Config Class Initialized
INFO - 2024-12-21 18:59:38 --> Hooks Class Initialized
DEBUG - 2024-12-21 18:59:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 18:59:38 --> Utf8 Class Initialized
INFO - 2024-12-21 18:59:38 --> URI Class Initialized
DEBUG - 2024-12-21 18:59:38 --> No URI present. Default controller set.
INFO - 2024-12-21 18:59:38 --> Router Class Initialized
INFO - 2024-12-21 18:59:38 --> Output Class Initialized
INFO - 2024-12-21 18:59:38 --> Security Class Initialized
DEBUG - 2024-12-21 18:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 18:59:38 --> Input Class Initialized
INFO - 2024-12-21 18:59:38 --> Language Class Initialized
INFO - 2024-12-21 18:59:38 --> Loader Class Initialized
INFO - 2024-12-21 18:59:38 --> Helper loaded: url_helper
INFO - 2024-12-21 18:59:38 --> Helper loaded: html_helper
INFO - 2024-12-21 18:59:38 --> Helper loaded: file_helper
INFO - 2024-12-21 18:59:38 --> Helper loaded: string_helper
INFO - 2024-12-21 18:59:38 --> Helper loaded: form_helper
INFO - 2024-12-21 18:59:38 --> Helper loaded: my_helper
INFO - 2024-12-21 18:59:38 --> Database Driver Class Initialized
INFO - 2024-12-21 18:59:40 --> Upload Class Initialized
INFO - 2024-12-21 18:59:40 --> Email Class Initialized
INFO - 2024-12-21 18:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 18:59:40 --> Form Validation Class Initialized
INFO - 2024-12-21 18:59:40 --> Controller Class Initialized
INFO - 2024-12-21 21:56:23 --> Config Class Initialized
INFO - 2024-12-21 21:56:23 --> Hooks Class Initialized
DEBUG - 2024-12-21 21:56:23 --> UTF-8 Support Enabled
INFO - 2024-12-21 21:56:23 --> Utf8 Class Initialized
INFO - 2024-12-21 21:56:23 --> URI Class Initialized
INFO - 2024-12-21 21:56:23 --> Router Class Initialized
INFO - 2024-12-21 21:56:23 --> Output Class Initialized
INFO - 2024-12-21 21:56:23 --> Security Class Initialized
DEBUG - 2024-12-21 21:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 21:56:23 --> Input Class Initialized
INFO - 2024-12-21 21:56:23 --> Language Class Initialized
ERROR - 2024-12-21 21:56:23 --> 404 Page Not Found: Wp-loginphp/index
INFO - 2024-12-21 23:09:19 --> Config Class Initialized
INFO - 2024-12-21 23:09:19 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:19 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:19 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:19 --> URI Class Initialized
INFO - 2024-12-21 23:09:19 --> Router Class Initialized
INFO - 2024-12-21 23:09:19 --> Output Class Initialized
INFO - 2024-12-21 23:09:19 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:19 --> Input Class Initialized
INFO - 2024-12-21 23:09:19 --> Language Class Initialized
ERROR - 2024-12-21 23:09:19 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2024-12-21 23:09:19 --> Config Class Initialized
INFO - 2024-12-21 23:09:19 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:19 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:19 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:19 --> URI Class Initialized
INFO - 2024-12-21 23:09:19 --> Router Class Initialized
INFO - 2024-12-21 23:09:19 --> Output Class Initialized
INFO - 2024-12-21 23:09:19 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:19 --> Input Class Initialized
INFO - 2024-12-21 23:09:19 --> Language Class Initialized
ERROR - 2024-12-21 23:09:19 --> 404 Page Not Found: Feed/index
INFO - 2024-12-21 23:09:20 --> Config Class Initialized
INFO - 2024-12-21 23:09:20 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:20 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:20 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:20 --> URI Class Initialized
INFO - 2024-12-21 23:09:20 --> Router Class Initialized
INFO - 2024-12-21 23:09:20 --> Output Class Initialized
INFO - 2024-12-21 23:09:20 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:20 --> Input Class Initialized
INFO - 2024-12-21 23:09:20 --> Language Class Initialized
ERROR - 2024-12-21 23:09:20 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-21 23:09:26 --> Config Class Initialized
INFO - 2024-12-21 23:09:26 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:26 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:26 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:26 --> URI Class Initialized
INFO - 2024-12-21 23:09:26 --> Router Class Initialized
INFO - 2024-12-21 23:09:26 --> Output Class Initialized
INFO - 2024-12-21 23:09:26 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:26 --> Input Class Initialized
INFO - 2024-12-21 23:09:26 --> Language Class Initialized
ERROR - 2024-12-21 23:09:26 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-21 23:09:31 --> Config Class Initialized
INFO - 2024-12-21 23:09:31 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:31 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:31 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:31 --> URI Class Initialized
INFO - 2024-12-21 23:09:31 --> Router Class Initialized
INFO - 2024-12-21 23:09:31 --> Output Class Initialized
INFO - 2024-12-21 23:09:31 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:31 --> Input Class Initialized
INFO - 2024-12-21 23:09:31 --> Language Class Initialized
ERROR - 2024-12-21 23:09:31 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-21 23:09:38 --> Config Class Initialized
INFO - 2024-12-21 23:09:38 --> Config Class Initialized
INFO - 2024-12-21 23:09:38 --> Hooks Class Initialized
INFO - 2024-12-21 23:09:38 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:38 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:38 --> URI Class Initialized
DEBUG - 2024-12-21 23:09:38 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:38 --> Utf8 Class Initialized
DEBUG - 2024-12-21 23:09:38 --> No URI present. Default controller set.
INFO - 2024-12-21 23:09:38 --> URI Class Initialized
INFO - 2024-12-21 23:09:38 --> Router Class Initialized
INFO - 2024-12-21 23:09:38 --> Output Class Initialized
INFO - 2024-12-21 23:09:38 --> Router Class Initialized
INFO - 2024-12-21 23:09:38 --> Security Class Initialized
INFO - 2024-12-21 23:09:38 --> Output Class Initialized
DEBUG - 2024-12-21 23:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:38 --> Security Class Initialized
INFO - 2024-12-21 23:09:38 --> Input Class Initialized
DEBUG - 2024-12-21 23:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:38 --> Language Class Initialized
INFO - 2024-12-21 23:09:38 --> Input Class Initialized
INFO - 2024-12-21 23:09:38 --> Loader Class Initialized
INFO - 2024-12-21 23:09:38 --> Language Class Initialized
ERROR - 2024-12-21 23:09:38 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-21 23:09:38 --> Helper loaded: url_helper
INFO - 2024-12-21 23:09:38 --> Helper loaded: html_helper
INFO - 2024-12-21 23:09:38 --> Helper loaded: file_helper
INFO - 2024-12-21 23:09:38 --> Helper loaded: string_helper
INFO - 2024-12-21 23:09:38 --> Helper loaded: form_helper
INFO - 2024-12-21 23:09:38 --> Helper loaded: my_helper
INFO - 2024-12-21 23:09:38 --> Database Driver Class Initialized
INFO - 2024-12-21 23:09:41 --> Config Class Initialized
INFO - 2024-12-21 23:09:41 --> Hooks Class Initialized
INFO - 2024-12-21 23:09:41 --> Upload Class Initialized
DEBUG - 2024-12-21 23:09:41 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:41 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:48 --> Email Class Initialized
INFO - 2024-12-21 23:09:48 --> URI Class Initialized
INFO - 2024-12-21 23:09:48 --> Router Class Initialized
INFO - 2024-12-21 23:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 23:09:48 --> Output Class Initialized
INFO - 2024-12-21 23:09:48 --> Form Validation Class Initialized
INFO - 2024-12-21 23:09:48 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:48 --> Controller Class Initialized
INFO - 2024-12-21 23:09:48 --> Input Class Initialized
INFO - 2024-12-21 23:09:48 --> Language Class Initialized
ERROR - 2024-12-21 23:09:48 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-21 23:09:49 --> Config Class Initialized
INFO - 2024-12-21 23:09:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:49 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:49 --> URI Class Initialized
INFO - 2024-12-21 23:09:49 --> Router Class Initialized
INFO - 2024-12-21 23:09:49 --> Output Class Initialized
INFO - 2024-12-21 23:09:49 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:49 --> Input Class Initialized
INFO - 2024-12-21 23:09:49 --> Language Class Initialized
ERROR - 2024-12-21 23:09:49 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-21 23:09:49 --> Config Class Initialized
INFO - 2024-12-21 23:09:49 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:49 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:49 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:49 --> URI Class Initialized
INFO - 2024-12-21 23:09:49 --> Router Class Initialized
INFO - 2024-12-21 23:09:49 --> Output Class Initialized
INFO - 2024-12-21 23:09:49 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:49 --> Input Class Initialized
INFO - 2024-12-21 23:09:49 --> Language Class Initialized
ERROR - 2024-12-21 23:09:49 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-21 23:09:50 --> Config Class Initialized
INFO - 2024-12-21 23:09:50 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:50 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:50 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:50 --> URI Class Initialized
INFO - 2024-12-21 23:09:50 --> Router Class Initialized
INFO - 2024-12-21 23:09:50 --> Output Class Initialized
INFO - 2024-12-21 23:09:50 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:50 --> Input Class Initialized
INFO - 2024-12-21 23:09:50 --> Language Class Initialized
ERROR - 2024-12-21 23:09:50 --> 404 Page Not Found: 2021/wp-includes
INFO - 2024-12-21 23:09:50 --> Config Class Initialized
INFO - 2024-12-21 23:09:50 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:50 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:50 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:50 --> URI Class Initialized
INFO - 2024-12-21 23:09:50 --> Router Class Initialized
INFO - 2024-12-21 23:09:50 --> Output Class Initialized
INFO - 2024-12-21 23:09:50 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:50 --> Input Class Initialized
INFO - 2024-12-21 23:09:50 --> Language Class Initialized
ERROR - 2024-12-21 23:09:50 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-21 23:09:50 --> Config Class Initialized
INFO - 2024-12-21 23:09:50 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:50 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:50 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:51 --> URI Class Initialized
INFO - 2024-12-21 23:09:51 --> Router Class Initialized
INFO - 2024-12-21 23:09:51 --> Output Class Initialized
INFO - 2024-12-21 23:09:51 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:51 --> Input Class Initialized
INFO - 2024-12-21 23:09:51 --> Language Class Initialized
ERROR - 2024-12-21 23:09:51 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-21 23:09:51 --> Config Class Initialized
INFO - 2024-12-21 23:09:51 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:51 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:51 --> URI Class Initialized
INFO - 2024-12-21 23:09:51 --> Router Class Initialized
INFO - 2024-12-21 23:09:51 --> Output Class Initialized
INFO - 2024-12-21 23:09:51 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:51 --> Input Class Initialized
INFO - 2024-12-21 23:09:51 --> Language Class Initialized
ERROR - 2024-12-21 23:09:51 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-21 23:09:51 --> Config Class Initialized
INFO - 2024-12-21 23:09:51 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:51 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:51 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:51 --> URI Class Initialized
INFO - 2024-12-21 23:09:51 --> Router Class Initialized
INFO - 2024-12-21 23:09:51 --> Output Class Initialized
INFO - 2024-12-21 23:09:51 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:51 --> Input Class Initialized
INFO - 2024-12-21 23:09:51 --> Language Class Initialized
ERROR - 2024-12-21 23:09:51 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-21 23:09:52 --> Config Class Initialized
INFO - 2024-12-21 23:09:52 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:09:52 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:09:52 --> Utf8 Class Initialized
INFO - 2024-12-21 23:09:52 --> URI Class Initialized
INFO - 2024-12-21 23:09:52 --> Router Class Initialized
INFO - 2024-12-21 23:09:52 --> Output Class Initialized
INFO - 2024-12-21 23:09:52 --> Security Class Initialized
DEBUG - 2024-12-21 23:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:09:52 --> Input Class Initialized
INFO - 2024-12-21 23:09:52 --> Language Class Initialized
ERROR - 2024-12-21 23:09:52 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-21 23:14:39 --> Config Class Initialized
INFO - 2024-12-21 23:14:39 --> Hooks Class Initialized
DEBUG - 2024-12-21 23:14:39 --> UTF-8 Support Enabled
INFO - 2024-12-21 23:14:39 --> Utf8 Class Initialized
INFO - 2024-12-21 23:14:39 --> URI Class Initialized
DEBUG - 2024-12-21 23:14:39 --> No URI present. Default controller set.
INFO - 2024-12-21 23:14:39 --> Router Class Initialized
INFO - 2024-12-21 23:14:39 --> Output Class Initialized
INFO - 2024-12-21 23:14:40 --> Security Class Initialized
DEBUG - 2024-12-21 23:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-21 23:14:40 --> Input Class Initialized
INFO - 2024-12-21 23:14:40 --> Language Class Initialized
INFO - 2024-12-21 23:14:40 --> Loader Class Initialized
INFO - 2024-12-21 23:14:40 --> Helper loaded: url_helper
INFO - 2024-12-21 23:14:40 --> Helper loaded: html_helper
INFO - 2024-12-21 23:14:40 --> Helper loaded: file_helper
INFO - 2024-12-21 23:14:40 --> Helper loaded: string_helper
INFO - 2024-12-21 23:14:40 --> Helper loaded: form_helper
INFO - 2024-12-21 23:14:40 --> Helper loaded: my_helper
INFO - 2024-12-21 23:14:40 --> Database Driver Class Initialized
INFO - 2024-12-21 23:14:42 --> Upload Class Initialized
INFO - 2024-12-21 23:14:42 --> Email Class Initialized
INFO - 2024-12-21 23:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-21 23:14:42 --> Form Validation Class Initialized
INFO - 2024-12-21 23:14:42 --> Controller Class Initialized
