<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-15 07:19:54 --> Config Class Initialized
INFO - 2024-12-15 07:19:54 --> Hooks Class Initialized
DEBUG - 2024-12-15 07:19:54 --> UTF-8 Support Enabled
INFO - 2024-12-15 07:19:54 --> Utf8 Class Initialized
INFO - 2024-12-15 07:19:54 --> URI Class Initialized
INFO - 2024-12-15 07:19:54 --> Router Class Initialized
INFO - 2024-12-15 07:19:54 --> Output Class Initialized
INFO - 2024-12-15 07:19:54 --> Security Class Initialized
DEBUG - 2024-12-15 07:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-15 07:19:54 --> Input Class Initialized
INFO - 2024-12-15 07:19:54 --> Language Class Initialized
ERROR - 2024-12-15 07:19:54 --> 404 Page Not Found: Wp-loginphp/index
