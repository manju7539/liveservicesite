<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-19 00:09:53 --> Model "MainModel" initialized
INFO - 2024-11-19 00:09:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 00:09:53 --> Final output sent to browser
DEBUG - 2024-11-19 00:09:53 --> Total execution time: 7.7908
INFO - 2024-11-19 00:27:08 --> Model "MainModel" initialized
INFO - 2024-11-19 00:27:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 00:27:08 --> Final output sent to browser
DEBUG - 2024-11-19 00:27:08 --> Total execution time: 2.2134
INFO - 2024-11-19 00:28:39 --> Model "MainModel" initialized
INFO - 2024-11-19 00:28:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 00:28:39 --> Final output sent to browser
DEBUG - 2024-11-19 00:28:39 --> Total execution time: 2.2215
INFO - 2024-11-19 01:06:23 --> Config Class Initialized
INFO - 2024-11-19 01:06:23 --> Hooks Class Initialized
DEBUG - 2024-11-19 01:06:23 --> UTF-8 Support Enabled
INFO - 2024-11-19 01:06:23 --> Utf8 Class Initialized
INFO - 2024-11-19 01:06:23 --> URI Class Initialized
DEBUG - 2024-11-19 01:06:23 --> No URI present. Default controller set.
INFO - 2024-11-19 01:06:23 --> Router Class Initialized
INFO - 2024-11-19 01:06:23 --> Output Class Initialized
INFO - 2024-11-19 01:06:23 --> Security Class Initialized
DEBUG - 2024-11-19 01:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 01:06:23 --> Input Class Initialized
INFO - 2024-11-19 01:06:23 --> Language Class Initialized
INFO - 2024-11-19 01:06:23 --> Loader Class Initialized
INFO - 2024-11-19 01:06:23 --> Helper loaded: url_helper
INFO - 2024-11-19 01:06:23 --> Helper loaded: html_helper
INFO - 2024-11-19 01:06:23 --> Helper loaded: file_helper
INFO - 2024-11-19 01:06:23 --> Helper loaded: string_helper
INFO - 2024-11-19 01:06:23 --> Helper loaded: form_helper
INFO - 2024-11-19 01:06:23 --> Helper loaded: my_helper
INFO - 2024-11-19 01:06:23 --> Database Driver Class Initialized
INFO - 2024-11-19 01:06:26 --> Upload Class Initialized
INFO - 2024-11-19 01:06:26 --> Email Class Initialized
INFO - 2024-11-19 01:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 01:06:26 --> Form Validation Class Initialized
INFO - 2024-11-19 01:06:26 --> Controller Class Initialized
INFO - 2024-11-19 06:36:26 --> Model "MainModel" initialized
INFO - 2024-11-19 06:36:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 06:36:26 --> Final output sent to browser
DEBUG - 2024-11-19 06:36:26 --> Total execution time: 2.6107
INFO - 2024-11-19 04:24:52 --> Config Class Initialized
INFO - 2024-11-19 04:24:52 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:24:52 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:24:52 --> Utf8 Class Initialized
INFO - 2024-11-19 04:24:52 --> URI Class Initialized
INFO - 2024-11-19 04:24:52 --> Router Class Initialized
INFO - 2024-11-19 04:24:52 --> Output Class Initialized
INFO - 2024-11-19 04:24:52 --> Security Class Initialized
DEBUG - 2024-11-19 04:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:24:52 --> Input Class Initialized
INFO - 2024-11-19 04:24:52 --> Language Class Initialized
INFO - 2024-11-19 04:24:52 --> Loader Class Initialized
INFO - 2024-11-19 04:24:52 --> Helper loaded: url_helper
INFO - 2024-11-19 04:24:52 --> Helper loaded: html_helper
INFO - 2024-11-19 04:24:52 --> Helper loaded: file_helper
INFO - 2024-11-19 04:24:52 --> Helper loaded: string_helper
INFO - 2024-11-19 04:24:52 --> Helper loaded: form_helper
INFO - 2024-11-19 04:24:52 --> Helper loaded: my_helper
INFO - 2024-11-19 04:24:52 --> Database Driver Class Initialized
INFO - 2024-11-19 04:24:54 --> Upload Class Initialized
INFO - 2024-11-19 04:24:54 --> Email Class Initialized
INFO - 2024-11-19 04:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 04:24:54 --> Form Validation Class Initialized
INFO - 2024-11-19 04:24:54 --> Controller Class Initialized
INFO - 2024-11-19 09:54:55 --> Model "MainModel" initialized
INFO - 2024-11-19 04:24:55 --> Config Class Initialized
INFO - 2024-11-19 04:24:55 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:24:55 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:24:55 --> Utf8 Class Initialized
INFO - 2024-11-19 04:24:55 --> URI Class Initialized
INFO - 2024-11-19 04:24:55 --> Router Class Initialized
INFO - 2024-11-19 04:24:55 --> Output Class Initialized
INFO - 2024-11-19 04:24:55 --> Security Class Initialized
DEBUG - 2024-11-19 04:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:24:55 --> Input Class Initialized
INFO - 2024-11-19 04:24:55 --> Language Class Initialized
ERROR - 2024-11-19 04:24:55 --> 404 Page Not Found: Faviconico/index
INFO - 2024-11-19 04:24:55 --> Config Class Initialized
INFO - 2024-11-19 04:24:55 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:24:55 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:24:55 --> Utf8 Class Initialized
INFO - 2024-11-19 04:24:55 --> URI Class Initialized
DEBUG - 2024-11-19 04:24:55 --> No URI present. Default controller set.
INFO - 2024-11-19 04:24:55 --> Router Class Initialized
INFO - 2024-11-19 04:24:55 --> Output Class Initialized
INFO - 2024-11-19 04:24:55 --> Security Class Initialized
DEBUG - 2024-11-19 04:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:24:55 --> Input Class Initialized
INFO - 2024-11-19 04:24:55 --> Language Class Initialized
INFO - 2024-11-19 04:24:55 --> Loader Class Initialized
INFO - 2024-11-19 04:24:55 --> Helper loaded: url_helper
INFO - 2024-11-19 04:24:55 --> Helper loaded: html_helper
INFO - 2024-11-19 04:24:55 --> Helper loaded: file_helper
INFO - 2024-11-19 04:24:55 --> Helper loaded: string_helper
INFO - 2024-11-19 04:24:55 --> Helper loaded: form_helper
INFO - 2024-11-19 04:24:55 --> Helper loaded: my_helper
INFO - 2024-11-19 04:24:55 --> Database Driver Class Initialized
INFO - 2024-11-19 04:24:57 --> Upload Class Initialized
INFO - 2024-11-19 04:24:57 --> Email Class Initialized
INFO - 2024-11-19 04:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 04:24:57 --> Form Validation Class Initialized
INFO - 2024-11-19 04:24:57 --> Controller Class Initialized
INFO - 2024-11-19 09:54:57 --> Model "MainModel" initialized
INFO - 2024-11-19 09:54:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 09:54:57 --> Final output sent to browser
DEBUG - 2024-11-19 09:54:57 --> Total execution time: 2.1378
INFO - 2024-11-19 04:25:08 --> Config Class Initialized
INFO - 2024-11-19 04:25:08 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:25:08 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:25:08 --> Utf8 Class Initialized
INFO - 2024-11-19 04:25:08 --> URI Class Initialized
INFO - 2024-11-19 04:25:08 --> Router Class Initialized
INFO - 2024-11-19 04:25:08 --> Output Class Initialized
INFO - 2024-11-19 04:25:08 --> Security Class Initialized
DEBUG - 2024-11-19 04:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:25:08 --> Input Class Initialized
INFO - 2024-11-19 04:25:08 --> Language Class Initialized
INFO - 2024-11-19 04:25:08 --> Loader Class Initialized
INFO - 2024-11-19 04:25:08 --> Helper loaded: url_helper
INFO - 2024-11-19 04:25:08 --> Helper loaded: html_helper
INFO - 2024-11-19 04:25:08 --> Helper loaded: file_helper
INFO - 2024-11-19 04:25:08 --> Helper loaded: string_helper
INFO - 2024-11-19 04:25:08 --> Helper loaded: form_helper
INFO - 2024-11-19 04:25:08 --> Helper loaded: my_helper
INFO - 2024-11-19 04:25:08 --> Database Driver Class Initialized
INFO - 2024-11-19 04:25:10 --> Upload Class Initialized
INFO - 2024-11-19 04:25:10 --> Email Class Initialized
INFO - 2024-11-19 04:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 04:25:10 --> Form Validation Class Initialized
INFO - 2024-11-19 04:25:10 --> Controller Class Initialized
INFO - 2024-11-19 09:55:10 --> Model "MainModel" initialized
INFO - 2024-11-19 04:25:11 --> Config Class Initialized
INFO - 2024-11-19 04:25:11 --> Hooks Class Initialized
DEBUG - 2024-11-19 04:25:11 --> UTF-8 Support Enabled
INFO - 2024-11-19 04:25:11 --> Utf8 Class Initialized
INFO - 2024-11-19 04:25:11 --> URI Class Initialized
DEBUG - 2024-11-19 04:25:11 --> No URI present. Default controller set.
INFO - 2024-11-19 04:25:11 --> Router Class Initialized
INFO - 2024-11-19 04:25:11 --> Output Class Initialized
INFO - 2024-11-19 04:25:11 --> Security Class Initialized
DEBUG - 2024-11-19 04:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 04:25:11 --> Input Class Initialized
INFO - 2024-11-19 04:25:11 --> Language Class Initialized
INFO - 2024-11-19 04:25:11 --> Loader Class Initialized
INFO - 2024-11-19 04:25:11 --> Helper loaded: url_helper
INFO - 2024-11-19 04:25:11 --> Helper loaded: html_helper
INFO - 2024-11-19 04:25:11 --> Helper loaded: file_helper
INFO - 2024-11-19 04:25:11 --> Helper loaded: string_helper
INFO - 2024-11-19 04:25:11 --> Helper loaded: form_helper
INFO - 2024-11-19 04:25:11 --> Helper loaded: my_helper
INFO - 2024-11-19 04:25:11 --> Database Driver Class Initialized
INFO - 2024-11-19 04:25:13 --> Upload Class Initialized
INFO - 2024-11-19 04:25:13 --> Email Class Initialized
INFO - 2024-11-19 04:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 04:25:13 --> Form Validation Class Initialized
INFO - 2024-11-19 04:25:13 --> Controller Class Initialized
INFO - 2024-11-19 09:55:13 --> Model "MainModel" initialized
INFO - 2024-11-19 09:55:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 09:55:13 --> Final output sent to browser
DEBUG - 2024-11-19 09:55:13 --> Total execution time: 2.1353
INFO - 2024-11-19 05:33:18 --> Config Class Initialized
INFO - 2024-11-19 05:33:18 --> Hooks Class Initialized
DEBUG - 2024-11-19 05:33:19 --> UTF-8 Support Enabled
INFO - 2024-11-19 05:33:19 --> Utf8 Class Initialized
INFO - 2024-11-19 05:33:19 --> URI Class Initialized
DEBUG - 2024-11-19 05:33:19 --> No URI present. Default controller set.
INFO - 2024-11-19 05:33:19 --> Router Class Initialized
INFO - 2024-11-19 05:33:19 --> Output Class Initialized
INFO - 2024-11-19 05:33:19 --> Security Class Initialized
DEBUG - 2024-11-19 05:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 05:33:19 --> Input Class Initialized
INFO - 2024-11-19 05:33:19 --> Language Class Initialized
INFO - 2024-11-19 05:33:19 --> Loader Class Initialized
INFO - 2024-11-19 05:33:19 --> Helper loaded: url_helper
INFO - 2024-11-19 05:33:19 --> Helper loaded: html_helper
INFO - 2024-11-19 05:33:19 --> Helper loaded: file_helper
INFO - 2024-11-19 05:33:19 --> Helper loaded: string_helper
INFO - 2024-11-19 05:33:19 --> Helper loaded: form_helper
INFO - 2024-11-19 05:33:19 --> Helper loaded: my_helper
INFO - 2024-11-19 05:33:19 --> Database Driver Class Initialized
INFO - 2024-11-19 05:33:21 --> Upload Class Initialized
INFO - 2024-11-19 05:33:21 --> Email Class Initialized
INFO - 2024-11-19 05:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 05:33:21 --> Form Validation Class Initialized
INFO - 2024-11-19 05:33:21 --> Controller Class Initialized
INFO - 2024-11-19 11:03:21 --> Model "MainModel" initialized
INFO - 2024-11-19 11:03:21 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 11:03:21 --> Final output sent to browser
DEBUG - 2024-11-19 11:03:21 --> Total execution time: 2.2959
INFO - 2024-11-19 05:33:23 --> Config Class Initialized
INFO - 2024-11-19 05:33:23 --> Hooks Class Initialized
DEBUG - 2024-11-19 05:33:23 --> UTF-8 Support Enabled
INFO - 2024-11-19 05:33:23 --> Utf8 Class Initialized
INFO - 2024-11-19 05:33:23 --> URI Class Initialized
INFO - 2024-11-19 05:33:23 --> Router Class Initialized
INFO - 2024-11-19 05:33:23 --> Output Class Initialized
INFO - 2024-11-19 05:33:23 --> Security Class Initialized
DEBUG - 2024-11-19 05:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 05:33:23 --> Input Class Initialized
INFO - 2024-11-19 05:33:23 --> Language Class Initialized
ERROR - 2024-11-19 05:33:23 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-19 05:33:24 --> Config Class Initialized
INFO - 2024-11-19 05:33:24 --> Hooks Class Initialized
DEBUG - 2024-11-19 05:33:24 --> UTF-8 Support Enabled
INFO - 2024-11-19 05:33:24 --> Utf8 Class Initialized
INFO - 2024-11-19 05:33:24 --> URI Class Initialized
INFO - 2024-11-19 05:33:24 --> Router Class Initialized
INFO - 2024-11-19 05:33:24 --> Output Class Initialized
INFO - 2024-11-19 05:33:24 --> Security Class Initialized
DEBUG - 2024-11-19 05:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 05:33:24 --> Input Class Initialized
INFO - 2024-11-19 05:33:24 --> Language Class Initialized
ERROR - 2024-11-19 05:33:24 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-11-19 05:33:45 --> Config Class Initialized
INFO - 2024-11-19 05:33:45 --> Hooks Class Initialized
DEBUG - 2024-11-19 05:33:45 --> UTF-8 Support Enabled
INFO - 2024-11-19 05:33:45 --> Utf8 Class Initialized
INFO - 2024-11-19 05:33:45 --> URI Class Initialized
DEBUG - 2024-11-19 05:33:45 --> No URI present. Default controller set.
INFO - 2024-11-19 05:33:45 --> Router Class Initialized
INFO - 2024-11-19 05:33:45 --> Output Class Initialized
INFO - 2024-11-19 05:33:45 --> Security Class Initialized
DEBUG - 2024-11-19 05:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 05:33:45 --> Input Class Initialized
INFO - 2024-11-19 05:33:45 --> Language Class Initialized
INFO - 2024-11-19 05:33:45 --> Loader Class Initialized
INFO - 2024-11-19 05:33:45 --> Helper loaded: url_helper
INFO - 2024-11-19 05:33:45 --> Helper loaded: html_helper
INFO - 2024-11-19 05:33:45 --> Helper loaded: file_helper
INFO - 2024-11-19 05:33:45 --> Helper loaded: string_helper
INFO - 2024-11-19 05:33:45 --> Helper loaded: form_helper
INFO - 2024-11-19 05:33:45 --> Helper loaded: my_helper
INFO - 2024-11-19 05:33:45 --> Database Driver Class Initialized
INFO - 2024-11-19 05:33:47 --> Upload Class Initialized
INFO - 2024-11-19 05:33:47 --> Email Class Initialized
INFO - 2024-11-19 05:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 05:33:47 --> Form Validation Class Initialized
INFO - 2024-11-19 05:33:47 --> Controller Class Initialized
INFO - 2024-11-19 11:03:47 --> Model "MainModel" initialized
INFO - 2024-11-19 11:03:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-19 11:03:47 --> Final output sent to browser
DEBUG - 2024-11-19 11:03:47 --> Total execution time: 2.1413
INFO - 2024-11-19 05:34:06 --> Config Class Initialized
INFO - 2024-11-19 05:34:06 --> Hooks Class Initialized
DEBUG - 2024-11-19 05:34:06 --> UTF-8 Support Enabled
INFO - 2024-11-19 05:34:07 --> Utf8 Class Initialized
INFO - 2024-11-19 05:34:07 --> URI Class Initialized
INFO - 2024-11-19 05:34:07 --> Router Class Initialized
INFO - 2024-11-19 05:34:07 --> Output Class Initialized
INFO - 2024-11-19 05:34:07 --> Security Class Initialized
DEBUG - 2024-11-19 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 05:34:07 --> Input Class Initialized
INFO - 2024-11-19 05:34:07 --> Language Class Initialized
ERROR - 2024-11-19 05:34:07 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-19 05:34:07 --> Config Class Initialized
INFO - 2024-11-19 05:34:07 --> Hooks Class Initialized
DEBUG - 2024-11-19 05:34:07 --> UTF-8 Support Enabled
INFO - 2024-11-19 05:34:07 --> Utf8 Class Initialized
INFO - 2024-11-19 05:34:07 --> URI Class Initialized
INFO - 2024-11-19 05:34:07 --> Router Class Initialized
INFO - 2024-11-19 05:34:07 --> Output Class Initialized
INFO - 2024-11-19 05:34:07 --> Security Class Initialized
DEBUG - 2024-11-19 05:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 05:34:07 --> Input Class Initialized
INFO - 2024-11-19 05:34:07 --> Language Class Initialized
ERROR - 2024-11-19 05:34:07 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-11-19 05:34:09 --> Config Class Initialized
INFO - 2024-11-19 05:34:09 --> Hooks Class Initialized
DEBUG - 2024-11-19 05:34:09 --> UTF-8 Support Enabled
INFO - 2024-11-19 05:34:09 --> Utf8 Class Initialized
INFO - 2024-11-19 05:34:09 --> URI Class Initialized
INFO - 2024-11-19 05:34:09 --> Router Class Initialized
INFO - 2024-11-19 05:34:09 --> Output Class Initialized
INFO - 2024-11-19 05:34:09 --> Security Class Initialized
DEBUG - 2024-11-19 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 05:34:09 --> Input Class Initialized
INFO - 2024-11-19 05:34:09 --> Language Class Initialized
ERROR - 2024-11-19 05:34:09 --> 404 Page Not Found: Configjson/index
INFO - 2024-11-19 19:28:37 --> Config Class Initialized
INFO - 2024-11-19 19:28:37 --> Hooks Class Initialized
DEBUG - 2024-11-19 19:28:37 --> UTF-8 Support Enabled
INFO - 2024-11-19 19:28:37 --> Utf8 Class Initialized
INFO - 2024-11-19 19:28:37 --> URI Class Initialized
DEBUG - 2024-11-19 19:28:37 --> No URI present. Default controller set.
INFO - 2024-11-19 19:28:37 --> Router Class Initialized
INFO - 2024-11-19 19:28:37 --> Output Class Initialized
INFO - 2024-11-19 19:28:37 --> Security Class Initialized
DEBUG - 2024-11-19 19:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 19:28:37 --> Input Class Initialized
INFO - 2024-11-19 19:28:37 --> Language Class Initialized
INFO - 2024-11-19 19:28:38 --> Loader Class Initialized
INFO - 2024-11-19 19:28:38 --> Helper loaded: url_helper
INFO - 2024-11-19 19:28:38 --> Helper loaded: html_helper
INFO - 2024-11-19 19:28:38 --> Helper loaded: file_helper
INFO - 2024-11-19 19:28:38 --> Helper loaded: string_helper
INFO - 2024-11-19 19:28:38 --> Helper loaded: form_helper
INFO - 2024-11-19 19:28:38 --> Helper loaded: my_helper
INFO - 2024-11-19 19:28:38 --> Database Driver Class Initialized
INFO - 2024-11-19 19:28:41 --> Upload Class Initialized
INFO - 2024-11-19 19:28:41 --> Email Class Initialized
INFO - 2024-11-19 19:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 19:28:42 --> Form Validation Class Initialized
INFO - 2024-11-19 19:28:42 --> Controller Class Initialized
INFO - 2024-11-19 23:48:45 --> Config Class Initialized
INFO - 2024-11-19 23:48:45 --> Hooks Class Initialized
DEBUG - 2024-11-19 23:48:45 --> UTF-8 Support Enabled
INFO - 2024-11-19 23:48:45 --> Utf8 Class Initialized
INFO - 2024-11-19 23:48:45 --> URI Class Initialized
DEBUG - 2024-11-19 23:48:45 --> No URI present. Default controller set.
INFO - 2024-11-19 23:48:45 --> Router Class Initialized
INFO - 2024-11-19 23:48:45 --> Output Class Initialized
INFO - 2024-11-19 23:48:45 --> Security Class Initialized
DEBUG - 2024-11-19 23:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 23:48:45 --> Input Class Initialized
INFO - 2024-11-19 23:48:45 --> Language Class Initialized
INFO - 2024-11-19 23:48:45 --> Loader Class Initialized
INFO - 2024-11-19 23:48:45 --> Helper loaded: url_helper
INFO - 2024-11-19 23:48:45 --> Helper loaded: html_helper
INFO - 2024-11-19 23:48:45 --> Helper loaded: file_helper
INFO - 2024-11-19 23:48:45 --> Helper loaded: string_helper
INFO - 2024-11-19 23:48:45 --> Helper loaded: form_helper
INFO - 2024-11-19 23:48:45 --> Helper loaded: my_helper
INFO - 2024-11-19 23:48:45 --> Database Driver Class Initialized
INFO - 2024-11-19 23:48:47 --> Upload Class Initialized
INFO - 2024-11-19 23:48:47 --> Email Class Initialized
INFO - 2024-11-19 23:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-19 23:48:48 --> Form Validation Class Initialized
INFO - 2024-11-19 23:48:48 --> Controller Class Initialized
INFO - 2024-11-19 23:48:49 --> Config Class Initialized
INFO - 2024-11-19 23:48:49 --> Hooks Class Initialized
DEBUG - 2024-11-19 23:48:49 --> UTF-8 Support Enabled
INFO - 2024-11-19 23:48:49 --> Utf8 Class Initialized
INFO - 2024-11-19 23:48:49 --> URI Class Initialized
INFO - 2024-11-19 23:48:49 --> Router Class Initialized
INFO - 2024-11-19 23:48:49 --> Output Class Initialized
INFO - 2024-11-19 23:48:49 --> Security Class Initialized
DEBUG - 2024-11-19 23:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-19 23:48:49 --> Input Class Initialized
INFO - 2024-11-19 23:48:49 --> Language Class Initialized
ERROR - 2024-11-19 23:48:49 --> 404 Page Not Found: Faviconico/index
