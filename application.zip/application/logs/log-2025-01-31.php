<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-31 05:16:13 --> Config Class Initialized
INFO - 2025-01-31 05:16:13 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:16:13 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:16:13 --> Utf8 Class Initialized
INFO - 2025-01-31 05:16:13 --> URI Class Initialized
INFO - 2025-01-31 05:16:13 --> Router Class Initialized
INFO - 2025-01-31 05:16:13 --> Output Class Initialized
INFO - 2025-01-31 05:16:13 --> Security Class Initialized
DEBUG - 2025-01-31 05:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:16:13 --> Input Class Initialized
INFO - 2025-01-31 05:16:13 --> Language Class Initialized
INFO - 2025-01-31 05:16:13 --> Loader Class Initialized
INFO - 2025-01-31 05:16:13 --> Helper loaded: url_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: html_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: file_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: string_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: form_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: my_helper
INFO - 2025-01-31 05:16:13 --> Database Driver Class Initialized
INFO - 2025-01-31 05:16:13 --> Upload Class Initialized
INFO - 2025-01-31 05:16:13 --> Email Class Initialized
INFO - 2025-01-31 05:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:16:13 --> Form Validation Class Initialized
INFO - 2025-01-31 05:16:13 --> Controller Class Initialized
INFO - 2025-01-31 10:46:13 --> Model "MainModel" initialized
INFO - 2025-01-31 10:46:13 --> Model "FrontofficeModel" initialized
INFO - 2025-01-31 10:46:13 --> Model "HotelAdminModel" initialized
INFO - 2025-01-31 10:46:13 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-31 10:46:13 --> Model "FoodAdminModel" initialized
INFO - 2025-01-31 10:46:13 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 10:46:13 --> Helper loaded: notification_helper
INFO - 2025-01-31 10:46:13 --> Helper loaded: array_helper
INFO - 2025-01-31 05:16:13 --> Config Class Initialized
INFO - 2025-01-31 05:16:13 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:16:13 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:16:13 --> Utf8 Class Initialized
INFO - 2025-01-31 05:16:13 --> URI Class Initialized
DEBUG - 2025-01-31 05:16:13 --> No URI present. Default controller set.
INFO - 2025-01-31 05:16:13 --> Router Class Initialized
INFO - 2025-01-31 05:16:13 --> Output Class Initialized
INFO - 2025-01-31 05:16:13 --> Security Class Initialized
DEBUG - 2025-01-31 05:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:16:13 --> Input Class Initialized
INFO - 2025-01-31 05:16:13 --> Language Class Initialized
INFO - 2025-01-31 05:16:13 --> Loader Class Initialized
INFO - 2025-01-31 05:16:13 --> Helper loaded: url_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: html_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: file_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: string_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: form_helper
INFO - 2025-01-31 05:16:13 --> Helper loaded: my_helper
INFO - 2025-01-31 05:16:13 --> Database Driver Class Initialized
INFO - 2025-01-31 05:16:13 --> Upload Class Initialized
INFO - 2025-01-31 05:16:13 --> Email Class Initialized
INFO - 2025-01-31 05:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:16:13 --> Form Validation Class Initialized
INFO - 2025-01-31 05:16:13 --> Controller Class Initialized
INFO - 2025-01-31 10:46:13 --> Model "MainModel" initialized
INFO - 2025-01-31 10:46:13 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-31 10:46:13 --> Final output sent to browser
DEBUG - 2025-01-31 10:46:13 --> Total execution time: 0.0268
INFO - 2025-01-31 05:24:20 --> Config Class Initialized
INFO - 2025-01-31 05:24:20 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:20 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:20 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:20 --> URI Class Initialized
INFO - 2025-01-31 05:24:20 --> Router Class Initialized
INFO - 2025-01-31 05:24:20 --> Output Class Initialized
INFO - 2025-01-31 05:24:20 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:20 --> Input Class Initialized
INFO - 2025-01-31 05:24:20 --> Language Class Initialized
INFO - 2025-01-31 05:24:20 --> Loader Class Initialized
INFO - 2025-01-31 05:24:20 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:20 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:20 --> Upload Class Initialized
INFO - 2025-01-31 05:24:20 --> Email Class Initialized
INFO - 2025-01-31 05:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:20 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:20 --> Controller Class Initialized
INFO - 2025-01-31 10:54:20 --> Model "MainModel" initialized
INFO - 2025-01-31 05:24:20 --> Config Class Initialized
INFO - 2025-01-31 05:24:20 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:20 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:20 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:20 --> URI Class Initialized
INFO - 2025-01-31 05:24:20 --> Router Class Initialized
INFO - 2025-01-31 05:24:20 --> Output Class Initialized
INFO - 2025-01-31 05:24:20 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:20 --> Input Class Initialized
INFO - 2025-01-31 05:24:20 --> Language Class Initialized
INFO - 2025-01-31 05:24:20 --> Loader Class Initialized
INFO - 2025-01-31 05:24:20 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:20 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:20 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:20 --> Upload Class Initialized
INFO - 2025-01-31 05:24:20 --> Email Class Initialized
INFO - 2025-01-31 05:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:20 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:20 --> Controller Class Initialized
INFO - 2025-01-31 10:54:20 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:20 --> Model "FrontofficeModel" initialized
INFO - 2025-01-31 10:54:20 --> Model "HotelAdminModel" initialized
INFO - 2025-01-31 10:54:20 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-31 10:54:20 --> Model "FoodAdminModel" initialized
INFO - 2025-01-31 10:54:20 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 10:54:20 --> Helper loaded: notification_helper
INFO - 2025-01-31 10:54:20 --> Helper loaded: array_helper
INFO - 2025-01-31 10:54:20 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-31 10:54:20 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-31 10:54:20 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-31 10:54:20 --> Final output sent to browser
DEBUG - 2025-01-31 10:54:20 --> Total execution time: 0.2105
INFO - 2025-01-31 05:24:20 --> Config Class Initialized
INFO - 2025-01-31 05:24:20 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:20 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:20 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:20 --> URI Class Initialized
INFO - 2025-01-31 05:24:20 --> Router Class Initialized
INFO - 2025-01-31 05:24:20 --> Output Class Initialized
INFO - 2025-01-31 05:24:20 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:20 --> Input Class Initialized
INFO - 2025-01-31 05:24:20 --> Language Class Initialized
ERROR - 2025-01-31 05:24:20 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:20 --> Config Class Initialized
INFO - 2025-01-31 05:24:20 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:20 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:20 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:21 --> URI Class Initialized
INFO - 2025-01-31 05:24:21 --> Router Class Initialized
INFO - 2025-01-31 05:24:21 --> Output Class Initialized
INFO - 2025-01-31 05:24:21 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:21 --> Input Class Initialized
INFO - 2025-01-31 05:24:21 --> Language Class Initialized
ERROR - 2025-01-31 05:24:21 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:21 --> Config Class Initialized
INFO - 2025-01-31 05:24:21 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:21 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:21 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:21 --> URI Class Initialized
INFO - 2025-01-31 05:24:21 --> Router Class Initialized
INFO - 2025-01-31 05:24:21 --> Output Class Initialized
INFO - 2025-01-31 05:24:21 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:21 --> Input Class Initialized
INFO - 2025-01-31 05:24:21 --> Language Class Initialized
ERROR - 2025-01-31 05:24:21 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:21 --> Config Class Initialized
INFO - 2025-01-31 05:24:21 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:21 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:21 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:21 --> URI Class Initialized
INFO - 2025-01-31 05:24:21 --> Router Class Initialized
INFO - 2025-01-31 05:24:21 --> Output Class Initialized
INFO - 2025-01-31 05:24:21 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:21 --> Input Class Initialized
INFO - 2025-01-31 05:24:21 --> Language Class Initialized
INFO - 2025-01-31 05:24:21 --> Loader Class Initialized
INFO - 2025-01-31 05:24:21 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:21 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:21 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:21 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:21 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:21 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:21 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:21 --> Upload Class Initialized
INFO - 2025-01-31 05:24:21 --> Email Class Initialized
INFO - 2025-01-31 05:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:21 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:21 --> Controller Class Initialized
INFO - 2025-01-31 10:54:21 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:21 --> Model "FrontofficeModel" initialized
INFO - 2025-01-31 10:54:21 --> Model "HotelAdminModel" initialized
INFO - 2025-01-31 10:54:21 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-31 10:54:21 --> Model "FoodAdminModel" initialized
INFO - 2025-01-31 10:54:21 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 10:54:21 --> Helper loaded: notification_helper
INFO - 2025-01-31 10:54:21 --> Helper loaded: array_helper
INFO - 2025-01-31 10:54:21 --> Final output sent to browser
DEBUG - 2025-01-31 10:54:21 --> Total execution time: 0.0287
INFO - 2025-01-31 05:24:26 --> Config Class Initialized
INFO - 2025-01-31 05:24:26 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:26 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:26 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:26 --> URI Class Initialized
INFO - 2025-01-31 05:24:26 --> Router Class Initialized
INFO - 2025-01-31 05:24:26 --> Output Class Initialized
INFO - 2025-01-31 05:24:26 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:26 --> Input Class Initialized
INFO - 2025-01-31 05:24:26 --> Language Class Initialized
INFO - 2025-01-31 05:24:26 --> Loader Class Initialized
INFO - 2025-01-31 05:24:26 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:26 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:26 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:26 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:26 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:26 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:26 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:26 --> Upload Class Initialized
INFO - 2025-01-31 05:24:26 --> Email Class Initialized
INFO - 2025-01-31 05:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:26 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:26 --> Controller Class Initialized
INFO - 2025-01-31 10:54:26 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:54:26 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:54:26 --> Pagination Class Initialized
INFO - 2025-01-31 05:24:31 --> Config Class Initialized
INFO - 2025-01-31 05:24:31 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:31 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:31 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:31 --> URI Class Initialized
INFO - 2025-01-31 05:24:31 --> Router Class Initialized
INFO - 2025-01-31 05:24:31 --> Output Class Initialized
INFO - 2025-01-31 05:24:31 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:31 --> Input Class Initialized
INFO - 2025-01-31 05:24:31 --> Language Class Initialized
INFO - 2025-01-31 05:24:31 --> Loader Class Initialized
INFO - 2025-01-31 05:24:31 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:31 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:31 --> Upload Class Initialized
INFO - 2025-01-31 05:24:31 --> Email Class Initialized
INFO - 2025-01-31 05:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:31 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:31 --> Controller Class Initialized
INFO - 2025-01-31 10:54:31 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:54:31 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:54:31 --> Pagination Class Initialized
INFO - 2025-01-31 05:24:31 --> Config Class Initialized
INFO - 2025-01-31 05:24:31 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:31 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:31 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:31 --> URI Class Initialized
INFO - 2025-01-31 05:24:31 --> Router Class Initialized
INFO - 2025-01-31 05:24:31 --> Output Class Initialized
INFO - 2025-01-31 05:24:31 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:31 --> Input Class Initialized
INFO - 2025-01-31 05:24:31 --> Language Class Initialized
INFO - 2025-01-31 05:24:31 --> Loader Class Initialized
INFO - 2025-01-31 05:24:31 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:31 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:31 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:31 --> Upload Class Initialized
INFO - 2025-01-31 05:24:31 --> Email Class Initialized
INFO - 2025-01-31 05:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:31 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:31 --> Controller Class Initialized
INFO - 2025-01-31 10:54:31 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 10:54:31 --> Helper loaded: notification_helper
INFO - 2025-01-31 10:54:31 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:31 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-31 10:54:31 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
INFO - 2025-01-31 10:54:31 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/hotelLists.php
INFO - 2025-01-31 10:54:31 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-31 10:54:31 --> Final output sent to browser
DEBUG - 2025-01-31 10:54:31 --> Total execution time: 0.3132
INFO - 2025-01-31 05:24:31 --> Config Class Initialized
INFO - 2025-01-31 05:24:31 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:31 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:31 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:31 --> URI Class Initialized
INFO - 2025-01-31 05:24:31 --> Router Class Initialized
INFO - 2025-01-31 05:24:31 --> Output Class Initialized
INFO - 2025-01-31 05:24:31 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:31 --> Input Class Initialized
INFO - 2025-01-31 05:24:31 --> Language Class Initialized
ERROR - 2025-01-31 05:24:31 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:32 --> Config Class Initialized
INFO - 2025-01-31 05:24:32 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:32 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:32 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:32 --> URI Class Initialized
INFO - 2025-01-31 05:24:32 --> Router Class Initialized
INFO - 2025-01-31 05:24:32 --> Output Class Initialized
INFO - 2025-01-31 05:24:32 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:32 --> Input Class Initialized
INFO - 2025-01-31 05:24:32 --> Language Class Initialized
ERROR - 2025-01-31 05:24:32 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:32 --> Config Class Initialized
INFO - 2025-01-31 05:24:32 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:32 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:32 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:32 --> URI Class Initialized
INFO - 2025-01-31 05:24:32 --> Router Class Initialized
INFO - 2025-01-31 05:24:32 --> Output Class Initialized
INFO - 2025-01-31 05:24:32 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:32 --> Input Class Initialized
INFO - 2025-01-31 05:24:32 --> Language Class Initialized
ERROR - 2025-01-31 05:24:32 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:37 --> Config Class Initialized
INFO - 2025-01-31 05:24:37 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:37 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:37 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:37 --> URI Class Initialized
INFO - 2025-01-31 05:24:37 --> Router Class Initialized
INFO - 2025-01-31 05:24:37 --> Output Class Initialized
INFO - 2025-01-31 05:24:37 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:37 --> Input Class Initialized
INFO - 2025-01-31 05:24:37 --> Language Class Initialized
INFO - 2025-01-31 05:24:37 --> Loader Class Initialized
INFO - 2025-01-31 05:24:37 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:37 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:37 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:37 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:37 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:37 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:37 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:37 --> Upload Class Initialized
INFO - 2025-01-31 05:24:37 --> Email Class Initialized
INFO - 2025-01-31 05:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:37 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:37 --> Controller Class Initialized
INFO - 2025-01-31 10:54:37 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:54:37 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:54:37 --> Pagination Class Initialized
INFO - 2025-01-31 05:24:40 --> Config Class Initialized
INFO - 2025-01-31 05:24:40 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:40 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:40 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:40 --> URI Class Initialized
INFO - 2025-01-31 05:24:40 --> Router Class Initialized
INFO - 2025-01-31 05:24:40 --> Output Class Initialized
INFO - 2025-01-31 05:24:40 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:40 --> Input Class Initialized
INFO - 2025-01-31 05:24:40 --> Language Class Initialized
INFO - 2025-01-31 05:24:40 --> Loader Class Initialized
INFO - 2025-01-31 05:24:40 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:40 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:40 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:40 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:40 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:40 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:40 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:40 --> Upload Class Initialized
INFO - 2025-01-31 05:24:40 --> Email Class Initialized
INFO - 2025-01-31 05:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:40 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:40 --> Controller Class Initialized
INFO - 2025-01-31 10:54:40 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 10:54:40 --> Helper loaded: notification_helper
INFO - 2025-01-31 10:54:40 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:40 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-31 10:54:40 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/leadsPlan.php
INFO - 2025-01-31 10:54:40 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-31 10:54:40 --> Final output sent to browser
DEBUG - 2025-01-31 10:54:40 --> Total execution time: 0.0884
INFO - 2025-01-31 05:24:40 --> Config Class Initialized
INFO - 2025-01-31 05:24:40 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:40 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:40 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:40 --> URI Class Initialized
INFO - 2025-01-31 05:24:40 --> Router Class Initialized
INFO - 2025-01-31 05:24:40 --> Output Class Initialized
INFO - 2025-01-31 05:24:40 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:40 --> Input Class Initialized
INFO - 2025-01-31 05:24:40 --> Language Class Initialized
ERROR - 2025-01-31 05:24:40 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:40 --> Config Class Initialized
INFO - 2025-01-31 05:24:40 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:40 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:40 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:40 --> URI Class Initialized
INFO - 2025-01-31 05:24:40 --> Router Class Initialized
INFO - 2025-01-31 05:24:40 --> Output Class Initialized
INFO - 2025-01-31 05:24:40 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:40 --> Input Class Initialized
INFO - 2025-01-31 05:24:40 --> Language Class Initialized
ERROR - 2025-01-31 05:24:40 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:40 --> Config Class Initialized
INFO - 2025-01-31 05:24:40 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:40 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:40 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:40 --> URI Class Initialized
INFO - 2025-01-31 05:24:40 --> Router Class Initialized
INFO - 2025-01-31 05:24:40 --> Output Class Initialized
INFO - 2025-01-31 05:24:40 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:40 --> Input Class Initialized
INFO - 2025-01-31 05:24:40 --> Language Class Initialized
ERROR - 2025-01-31 05:24:40 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:45 --> Config Class Initialized
INFO - 2025-01-31 05:24:45 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:45 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:45 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:45 --> URI Class Initialized
INFO - 2025-01-31 05:24:45 --> Router Class Initialized
INFO - 2025-01-31 05:24:45 --> Output Class Initialized
INFO - 2025-01-31 05:24:45 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:45 --> Input Class Initialized
INFO - 2025-01-31 05:24:45 --> Language Class Initialized
INFO - 2025-01-31 05:24:45 --> Loader Class Initialized
INFO - 2025-01-31 05:24:45 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:45 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:45 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:45 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:45 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:45 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:45 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:45 --> Upload Class Initialized
INFO - 2025-01-31 05:24:45 --> Email Class Initialized
INFO - 2025-01-31 05:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:45 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:45 --> Controller Class Initialized
INFO - 2025-01-31 10:54:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:54:45 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:54:45 --> Pagination Class Initialized
INFO - 2025-01-31 05:24:47 --> Config Class Initialized
INFO - 2025-01-31 05:24:47 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:47 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:47 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:47 --> URI Class Initialized
INFO - 2025-01-31 05:24:47 --> Router Class Initialized
INFO - 2025-01-31 05:24:47 --> Output Class Initialized
INFO - 2025-01-31 05:24:47 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:47 --> Input Class Initialized
INFO - 2025-01-31 05:24:47 --> Language Class Initialized
INFO - 2025-01-31 05:24:47 --> Loader Class Initialized
INFO - 2025-01-31 05:24:47 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:47 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:47 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:47 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:47 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:47 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:47 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:47 --> Upload Class Initialized
INFO - 2025-01-31 05:24:47 --> Email Class Initialized
INFO - 2025-01-31 05:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:47 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:47 --> Controller Class Initialized
INFO - 2025-01-31 10:54:47 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 10:54:47 --> Helper loaded: notification_helper
INFO - 2025-01-31 10:54:47 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:47 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 193
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-31 10:54:47 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
INFO - 2025-01-31 10:54:47 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/leadRecharge.php
INFO - 2025-01-31 10:54:47 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-31 10:54:47 --> Final output sent to browser
DEBUG - 2025-01-31 10:54:47 --> Total execution time: 0.1408
INFO - 2025-01-31 05:24:47 --> Config Class Initialized
INFO - 2025-01-31 05:24:47 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:47 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:47 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:47 --> URI Class Initialized
INFO - 2025-01-31 05:24:47 --> Router Class Initialized
INFO - 2025-01-31 05:24:47 --> Output Class Initialized
INFO - 2025-01-31 05:24:47 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:47 --> Input Class Initialized
INFO - 2025-01-31 05:24:47 --> Language Class Initialized
ERROR - 2025-01-31 05:24:47 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:47 --> Config Class Initialized
INFO - 2025-01-31 05:24:47 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:47 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:47 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:47 --> URI Class Initialized
INFO - 2025-01-31 05:24:47 --> Router Class Initialized
INFO - 2025-01-31 05:24:47 --> Output Class Initialized
INFO - 2025-01-31 05:24:47 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:47 --> Input Class Initialized
INFO - 2025-01-31 05:24:47 --> Language Class Initialized
ERROR - 2025-01-31 05:24:47 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:47 --> Config Class Initialized
INFO - 2025-01-31 05:24:47 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:47 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:47 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:47 --> URI Class Initialized
INFO - 2025-01-31 05:24:47 --> Router Class Initialized
INFO - 2025-01-31 05:24:47 --> Output Class Initialized
INFO - 2025-01-31 05:24:47 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:47 --> Input Class Initialized
INFO - 2025-01-31 05:24:47 --> Language Class Initialized
ERROR - 2025-01-31 05:24:47 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:52 --> Config Class Initialized
INFO - 2025-01-31 05:24:52 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:52 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:52 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:52 --> URI Class Initialized
INFO - 2025-01-31 05:24:52 --> Router Class Initialized
INFO - 2025-01-31 05:24:52 --> Output Class Initialized
INFO - 2025-01-31 05:24:52 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:52 --> Input Class Initialized
INFO - 2025-01-31 05:24:52 --> Language Class Initialized
INFO - 2025-01-31 05:24:52 --> Loader Class Initialized
INFO - 2025-01-31 05:24:52 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:52 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:52 --> Upload Class Initialized
INFO - 2025-01-31 05:24:52 --> Email Class Initialized
INFO - 2025-01-31 05:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:52 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:52 --> Controller Class Initialized
INFO - 2025-01-31 10:54:52 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 10:54:52 --> Helper loaded: notification_helper
INFO - 2025-01-31 10:54:52 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:52 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-31 05:24:52 --> Config Class Initialized
INFO - 2025-01-31 05:24:52 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:52 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:52 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:52 --> URI Class Initialized
INFO - 2025-01-31 05:24:52 --> Router Class Initialized
INFO - 2025-01-31 05:24:52 --> Output Class Initialized
INFO - 2025-01-31 05:24:52 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:52 --> Input Class Initialized
INFO - 2025-01-31 05:24:52 --> Language Class Initialized
INFO - 2025-01-31 05:24:52 --> Loader Class Initialized
INFO - 2025-01-31 05:24:52 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:52 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:52 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:52 --> Upload Class Initialized
INFO - 2025-01-31 05:24:52 --> Email Class Initialized
INFO - 2025-01-31 10:54:52 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/guest_panel.php
INFO - 2025-01-31 10:54:52 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-31 10:54:52 --> Final output sent to browser
DEBUG - 2025-01-31 10:54:52 --> Total execution time: 0.2994
INFO - 2025-01-31 05:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:52 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:52 --> Controller Class Initialized
INFO - 2025-01-31 10:54:52 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:54:52 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:54:52 --> Pagination Class Initialized
INFO - 2025-01-31 05:24:52 --> Config Class Initialized
INFO - 2025-01-31 05:24:52 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:52 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:52 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:52 --> URI Class Initialized
INFO - 2025-01-31 05:24:52 --> Router Class Initialized
INFO - 2025-01-31 05:24:52 --> Output Class Initialized
INFO - 2025-01-31 05:24:52 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:52 --> Input Class Initialized
INFO - 2025-01-31 05:24:52 --> Language Class Initialized
ERROR - 2025-01-31 05:24:52 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:52 --> Config Class Initialized
INFO - 2025-01-31 05:24:52 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:52 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:52 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:52 --> URI Class Initialized
INFO - 2025-01-31 05:24:52 --> Router Class Initialized
INFO - 2025-01-31 05:24:52 --> Output Class Initialized
INFO - 2025-01-31 05:24:52 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:52 --> Input Class Initialized
INFO - 2025-01-31 05:24:52 --> Language Class Initialized
ERROR - 2025-01-31 05:24:52 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:52 --> Config Class Initialized
INFO - 2025-01-31 05:24:52 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:52 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:52 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:52 --> URI Class Initialized
INFO - 2025-01-31 05:24:52 --> Router Class Initialized
INFO - 2025-01-31 05:24:52 --> Output Class Initialized
INFO - 2025-01-31 05:24:52 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:52 --> Input Class Initialized
INFO - 2025-01-31 05:24:52 --> Language Class Initialized
ERROR - 2025-01-31 05:24:52 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-31 05:24:57 --> Config Class Initialized
INFO - 2025-01-31 05:24:57 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:24:57 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:24:57 --> Utf8 Class Initialized
INFO - 2025-01-31 05:24:57 --> URI Class Initialized
INFO - 2025-01-31 05:24:57 --> Router Class Initialized
INFO - 2025-01-31 05:24:57 --> Output Class Initialized
INFO - 2025-01-31 05:24:57 --> Security Class Initialized
DEBUG - 2025-01-31 05:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:24:57 --> Input Class Initialized
INFO - 2025-01-31 05:24:57 --> Language Class Initialized
INFO - 2025-01-31 05:24:57 --> Loader Class Initialized
INFO - 2025-01-31 05:24:57 --> Helper loaded: url_helper
INFO - 2025-01-31 05:24:57 --> Helper loaded: html_helper
INFO - 2025-01-31 05:24:57 --> Helper loaded: file_helper
INFO - 2025-01-31 05:24:57 --> Helper loaded: string_helper
INFO - 2025-01-31 05:24:57 --> Helper loaded: form_helper
INFO - 2025-01-31 05:24:57 --> Helper loaded: my_helper
INFO - 2025-01-31 05:24:57 --> Database Driver Class Initialized
INFO - 2025-01-31 05:24:57 --> Upload Class Initialized
INFO - 2025-01-31 05:24:57 --> Email Class Initialized
INFO - 2025-01-31 05:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:24:57 --> Form Validation Class Initialized
INFO - 2025-01-31 05:24:57 --> Controller Class Initialized
INFO - 2025-01-31 10:54:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:54:57 --> Model "MainModel" initialized
INFO - 2025-01-31 10:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:54:57 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:02 --> Config Class Initialized
INFO - 2025-01-31 05:25:02 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:02 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:02 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:02 --> URI Class Initialized
INFO - 2025-01-31 05:25:02 --> Router Class Initialized
INFO - 2025-01-31 05:25:02 --> Output Class Initialized
INFO - 2025-01-31 05:25:02 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:02 --> Input Class Initialized
INFO - 2025-01-31 05:25:02 --> Language Class Initialized
INFO - 2025-01-31 05:25:02 --> Loader Class Initialized
INFO - 2025-01-31 05:25:02 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:02 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:02 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:02 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:02 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:02 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:02 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:02 --> Upload Class Initialized
INFO - 2025-01-31 05:25:02 --> Email Class Initialized
INFO - 2025-01-31 05:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:02 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:02 --> Controller Class Initialized
INFO - 2025-01-31 10:55:02 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:02 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:02 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:07 --> Config Class Initialized
INFO - 2025-01-31 05:25:07 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:07 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:07 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:07 --> URI Class Initialized
INFO - 2025-01-31 05:25:07 --> Router Class Initialized
INFO - 2025-01-31 05:25:07 --> Output Class Initialized
INFO - 2025-01-31 05:25:07 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:07 --> Input Class Initialized
INFO - 2025-01-31 05:25:07 --> Language Class Initialized
INFO - 2025-01-31 05:25:07 --> Loader Class Initialized
INFO - 2025-01-31 05:25:07 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:07 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:07 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:07 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:07 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:07 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:07 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:07 --> Upload Class Initialized
INFO - 2025-01-31 05:25:07 --> Email Class Initialized
INFO - 2025-01-31 05:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:07 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:07 --> Controller Class Initialized
INFO - 2025-01-31 10:55:07 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:07 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:07 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:12 --> Config Class Initialized
INFO - 2025-01-31 05:25:12 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:12 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:12 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:12 --> URI Class Initialized
INFO - 2025-01-31 05:25:12 --> Router Class Initialized
INFO - 2025-01-31 05:25:12 --> Output Class Initialized
INFO - 2025-01-31 05:25:12 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:12 --> Input Class Initialized
INFO - 2025-01-31 05:25:12 --> Language Class Initialized
INFO - 2025-01-31 05:25:12 --> Loader Class Initialized
INFO - 2025-01-31 05:25:12 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:12 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:12 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:12 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:12 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:12 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:12 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:12 --> Upload Class Initialized
INFO - 2025-01-31 05:25:12 --> Email Class Initialized
INFO - 2025-01-31 05:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:12 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:12 --> Controller Class Initialized
INFO - 2025-01-31 10:55:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:12 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:12 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:17 --> Config Class Initialized
INFO - 2025-01-31 05:25:17 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:17 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:17 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:17 --> URI Class Initialized
INFO - 2025-01-31 05:25:17 --> Router Class Initialized
INFO - 2025-01-31 05:25:17 --> Output Class Initialized
INFO - 2025-01-31 05:25:17 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:17 --> Input Class Initialized
INFO - 2025-01-31 05:25:17 --> Language Class Initialized
INFO - 2025-01-31 05:25:17 --> Loader Class Initialized
INFO - 2025-01-31 05:25:17 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:17 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:17 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:17 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:17 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:17 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:17 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:17 --> Upload Class Initialized
INFO - 2025-01-31 05:25:17 --> Email Class Initialized
INFO - 2025-01-31 05:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:17 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:17 --> Controller Class Initialized
INFO - 2025-01-31 10:55:17 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:17 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:17 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:22 --> Config Class Initialized
INFO - 2025-01-31 05:25:22 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:22 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:22 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:22 --> URI Class Initialized
INFO - 2025-01-31 05:25:22 --> Router Class Initialized
INFO - 2025-01-31 05:25:22 --> Output Class Initialized
INFO - 2025-01-31 05:25:22 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:22 --> Input Class Initialized
INFO - 2025-01-31 05:25:22 --> Language Class Initialized
INFO - 2025-01-31 05:25:22 --> Loader Class Initialized
INFO - 2025-01-31 05:25:22 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:22 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:22 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:22 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:22 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:22 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:22 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:22 --> Upload Class Initialized
INFO - 2025-01-31 05:25:22 --> Email Class Initialized
INFO - 2025-01-31 05:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:22 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:22 --> Controller Class Initialized
INFO - 2025-01-31 10:55:22 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:22 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:22 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:27 --> Config Class Initialized
INFO - 2025-01-31 05:25:27 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:27 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:27 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:27 --> URI Class Initialized
INFO - 2025-01-31 05:25:27 --> Router Class Initialized
INFO - 2025-01-31 05:25:27 --> Output Class Initialized
INFO - 2025-01-31 05:25:27 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:27 --> Input Class Initialized
INFO - 2025-01-31 05:25:27 --> Language Class Initialized
INFO - 2025-01-31 05:25:27 --> Loader Class Initialized
INFO - 2025-01-31 05:25:27 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:27 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:27 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:27 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:27 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:27 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:27 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:27 --> Upload Class Initialized
INFO - 2025-01-31 05:25:27 --> Email Class Initialized
INFO - 2025-01-31 05:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:27 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:27 --> Controller Class Initialized
INFO - 2025-01-31 10:55:27 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:27 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:27 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:33 --> Config Class Initialized
INFO - 2025-01-31 05:25:33 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:33 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:33 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:33 --> URI Class Initialized
INFO - 2025-01-31 05:25:33 --> Router Class Initialized
INFO - 2025-01-31 05:25:33 --> Output Class Initialized
INFO - 2025-01-31 05:25:33 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:33 --> Input Class Initialized
INFO - 2025-01-31 05:25:33 --> Language Class Initialized
INFO - 2025-01-31 05:25:33 --> Loader Class Initialized
INFO - 2025-01-31 05:25:33 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:33 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:33 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:33 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:33 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:33 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:33 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:33 --> Upload Class Initialized
INFO - 2025-01-31 05:25:33 --> Email Class Initialized
INFO - 2025-01-31 05:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:33 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:33 --> Controller Class Initialized
INFO - 2025-01-31 10:55:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:33 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:33 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:38 --> Config Class Initialized
INFO - 2025-01-31 05:25:38 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:38 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:38 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:38 --> URI Class Initialized
INFO - 2025-01-31 05:25:38 --> Router Class Initialized
INFO - 2025-01-31 05:25:38 --> Output Class Initialized
INFO - 2025-01-31 05:25:38 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:38 --> Input Class Initialized
INFO - 2025-01-31 05:25:38 --> Language Class Initialized
INFO - 2025-01-31 05:25:38 --> Loader Class Initialized
INFO - 2025-01-31 05:25:38 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:38 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:38 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:38 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:38 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:38 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:38 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:38 --> Upload Class Initialized
INFO - 2025-01-31 05:25:38 --> Email Class Initialized
INFO - 2025-01-31 05:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:38 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:38 --> Controller Class Initialized
INFO - 2025-01-31 10:55:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:38 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:38 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:42 --> Config Class Initialized
INFO - 2025-01-31 05:25:42 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:42 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:42 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:42 --> URI Class Initialized
INFO - 2025-01-31 05:25:42 --> Router Class Initialized
INFO - 2025-01-31 05:25:42 --> Output Class Initialized
INFO - 2025-01-31 05:25:42 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:42 --> Input Class Initialized
INFO - 2025-01-31 05:25:42 --> Language Class Initialized
INFO - 2025-01-31 05:25:42 --> Loader Class Initialized
INFO - 2025-01-31 05:25:42 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:42 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:42 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:42 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:42 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:42 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:42 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:42 --> Upload Class Initialized
INFO - 2025-01-31 05:25:42 --> Email Class Initialized
INFO - 2025-01-31 05:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:43 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:43 --> Controller Class Initialized
INFO - 2025-01-31 10:55:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:43 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:43 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:48 --> Config Class Initialized
INFO - 2025-01-31 05:25:48 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:48 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:48 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:48 --> URI Class Initialized
INFO - 2025-01-31 05:25:48 --> Router Class Initialized
INFO - 2025-01-31 05:25:48 --> Output Class Initialized
INFO - 2025-01-31 05:25:48 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:48 --> Input Class Initialized
INFO - 2025-01-31 05:25:48 --> Language Class Initialized
INFO - 2025-01-31 05:25:48 --> Loader Class Initialized
INFO - 2025-01-31 05:25:48 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:48 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:48 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:48 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:48 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:48 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:48 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:48 --> Upload Class Initialized
INFO - 2025-01-31 05:25:48 --> Email Class Initialized
INFO - 2025-01-31 05:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:48 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:48 --> Controller Class Initialized
INFO - 2025-01-31 10:55:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:48 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:48 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:53 --> Config Class Initialized
INFO - 2025-01-31 05:25:53 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:53 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:53 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:53 --> URI Class Initialized
INFO - 2025-01-31 05:25:53 --> Router Class Initialized
INFO - 2025-01-31 05:25:53 --> Output Class Initialized
INFO - 2025-01-31 05:25:53 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:53 --> Input Class Initialized
INFO - 2025-01-31 05:25:53 --> Language Class Initialized
INFO - 2025-01-31 05:25:53 --> Loader Class Initialized
INFO - 2025-01-31 05:25:53 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:53 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:53 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:53 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:53 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:53 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:53 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:53 --> Upload Class Initialized
INFO - 2025-01-31 05:25:53 --> Email Class Initialized
INFO - 2025-01-31 05:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:53 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:53 --> Controller Class Initialized
INFO - 2025-01-31 10:55:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:53 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:53 --> Pagination Class Initialized
INFO - 2025-01-31 05:25:57 --> Config Class Initialized
INFO - 2025-01-31 05:25:57 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:25:57 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:25:57 --> Utf8 Class Initialized
INFO - 2025-01-31 05:25:57 --> URI Class Initialized
INFO - 2025-01-31 05:25:57 --> Router Class Initialized
INFO - 2025-01-31 05:25:57 --> Output Class Initialized
INFO - 2025-01-31 05:25:57 --> Security Class Initialized
DEBUG - 2025-01-31 05:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:25:57 --> Input Class Initialized
INFO - 2025-01-31 05:25:57 --> Language Class Initialized
INFO - 2025-01-31 05:25:57 --> Loader Class Initialized
INFO - 2025-01-31 05:25:57 --> Helper loaded: url_helper
INFO - 2025-01-31 05:25:57 --> Helper loaded: html_helper
INFO - 2025-01-31 05:25:57 --> Helper loaded: file_helper
INFO - 2025-01-31 05:25:57 --> Helper loaded: string_helper
INFO - 2025-01-31 05:25:57 --> Helper loaded: form_helper
INFO - 2025-01-31 05:25:57 --> Helper loaded: my_helper
INFO - 2025-01-31 05:25:57 --> Database Driver Class Initialized
INFO - 2025-01-31 05:25:57 --> Upload Class Initialized
INFO - 2025-01-31 05:25:57 --> Email Class Initialized
INFO - 2025-01-31 05:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:25:57 --> Form Validation Class Initialized
INFO - 2025-01-31 05:25:57 --> Controller Class Initialized
INFO - 2025-01-31 10:55:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:55:57 --> Model "MainModel" initialized
INFO - 2025-01-31 10:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:55:57 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:03 --> Config Class Initialized
INFO - 2025-01-31 05:26:03 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:03 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:03 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:03 --> URI Class Initialized
INFO - 2025-01-31 05:26:03 --> Router Class Initialized
INFO - 2025-01-31 05:26:03 --> Output Class Initialized
INFO - 2025-01-31 05:26:03 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:03 --> Input Class Initialized
INFO - 2025-01-31 05:26:03 --> Language Class Initialized
INFO - 2025-01-31 05:26:03 --> Loader Class Initialized
INFO - 2025-01-31 05:26:03 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:03 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:03 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:03 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:03 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:03 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:03 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:03 --> Upload Class Initialized
INFO - 2025-01-31 05:26:03 --> Email Class Initialized
INFO - 2025-01-31 05:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:03 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:03 --> Controller Class Initialized
INFO - 2025-01-31 10:56:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:03 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:03 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:08 --> Config Class Initialized
INFO - 2025-01-31 05:26:08 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:08 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:08 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:08 --> URI Class Initialized
INFO - 2025-01-31 05:26:08 --> Router Class Initialized
INFO - 2025-01-31 05:26:08 --> Output Class Initialized
INFO - 2025-01-31 05:26:08 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:08 --> Input Class Initialized
INFO - 2025-01-31 05:26:08 --> Language Class Initialized
INFO - 2025-01-31 05:26:08 --> Loader Class Initialized
INFO - 2025-01-31 05:26:08 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:08 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:08 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:08 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:08 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:08 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:08 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:08 --> Upload Class Initialized
INFO - 2025-01-31 05:26:08 --> Email Class Initialized
INFO - 2025-01-31 05:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:08 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:08 --> Controller Class Initialized
INFO - 2025-01-31 10:56:08 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:08 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:08 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:13 --> Config Class Initialized
INFO - 2025-01-31 05:26:13 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:13 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:13 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:13 --> URI Class Initialized
INFO - 2025-01-31 05:26:13 --> Router Class Initialized
INFO - 2025-01-31 05:26:13 --> Output Class Initialized
INFO - 2025-01-31 05:26:13 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:13 --> Input Class Initialized
INFO - 2025-01-31 05:26:13 --> Language Class Initialized
INFO - 2025-01-31 05:26:13 --> Loader Class Initialized
INFO - 2025-01-31 05:26:13 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:13 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:13 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:13 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:13 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:13 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:13 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:13 --> Upload Class Initialized
INFO - 2025-01-31 05:26:13 --> Email Class Initialized
INFO - 2025-01-31 05:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:13 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:13 --> Controller Class Initialized
INFO - 2025-01-31 10:56:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:13 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:13 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:18 --> Config Class Initialized
INFO - 2025-01-31 05:26:18 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:18 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:18 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:18 --> URI Class Initialized
INFO - 2025-01-31 05:26:18 --> Router Class Initialized
INFO - 2025-01-31 05:26:18 --> Output Class Initialized
INFO - 2025-01-31 05:26:18 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:18 --> Input Class Initialized
INFO - 2025-01-31 05:26:18 --> Language Class Initialized
INFO - 2025-01-31 05:26:18 --> Loader Class Initialized
INFO - 2025-01-31 05:26:18 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:18 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:18 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:18 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:18 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:18 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:18 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:18 --> Upload Class Initialized
INFO - 2025-01-31 05:26:18 --> Email Class Initialized
INFO - 2025-01-31 05:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:18 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:18 --> Controller Class Initialized
INFO - 2025-01-31 10:56:18 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:18 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:18 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:23 --> Config Class Initialized
INFO - 2025-01-31 05:26:23 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:23 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:23 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:23 --> URI Class Initialized
INFO - 2025-01-31 05:26:23 --> Router Class Initialized
INFO - 2025-01-31 05:26:23 --> Output Class Initialized
INFO - 2025-01-31 05:26:23 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:23 --> Input Class Initialized
INFO - 2025-01-31 05:26:23 --> Language Class Initialized
INFO - 2025-01-31 05:26:23 --> Loader Class Initialized
INFO - 2025-01-31 05:26:23 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:23 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:23 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:23 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:23 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:23 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:23 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:23 --> Upload Class Initialized
INFO - 2025-01-31 05:26:23 --> Email Class Initialized
INFO - 2025-01-31 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:23 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:23 --> Controller Class Initialized
INFO - 2025-01-31 10:56:23 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:23 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:23 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:28 --> Config Class Initialized
INFO - 2025-01-31 05:26:28 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:28 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:28 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:28 --> URI Class Initialized
INFO - 2025-01-31 05:26:28 --> Router Class Initialized
INFO - 2025-01-31 05:26:28 --> Output Class Initialized
INFO - 2025-01-31 05:26:28 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:28 --> Input Class Initialized
INFO - 2025-01-31 05:26:28 --> Language Class Initialized
INFO - 2025-01-31 05:26:28 --> Loader Class Initialized
INFO - 2025-01-31 05:26:28 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:28 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:28 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:28 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:28 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:28 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:28 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:28 --> Upload Class Initialized
INFO - 2025-01-31 05:26:28 --> Email Class Initialized
INFO - 2025-01-31 05:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:28 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:28 --> Controller Class Initialized
INFO - 2025-01-31 10:56:28 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:28 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:28 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:33 --> Config Class Initialized
INFO - 2025-01-31 05:26:33 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:33 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:33 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:33 --> URI Class Initialized
INFO - 2025-01-31 05:26:33 --> Router Class Initialized
INFO - 2025-01-31 05:26:33 --> Output Class Initialized
INFO - 2025-01-31 05:26:33 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:33 --> Input Class Initialized
INFO - 2025-01-31 05:26:33 --> Language Class Initialized
INFO - 2025-01-31 05:26:33 --> Loader Class Initialized
INFO - 2025-01-31 05:26:33 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:33 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:33 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:33 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:33 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:33 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:33 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:33 --> Upload Class Initialized
INFO - 2025-01-31 05:26:33 --> Email Class Initialized
INFO - 2025-01-31 05:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:33 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:33 --> Controller Class Initialized
INFO - 2025-01-31 10:56:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:33 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:33 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:38 --> Config Class Initialized
INFO - 2025-01-31 05:26:38 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:38 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:38 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:38 --> URI Class Initialized
INFO - 2025-01-31 05:26:38 --> Router Class Initialized
INFO - 2025-01-31 05:26:38 --> Output Class Initialized
INFO - 2025-01-31 05:26:38 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:38 --> Input Class Initialized
INFO - 2025-01-31 05:26:38 --> Language Class Initialized
INFO - 2025-01-31 05:26:38 --> Loader Class Initialized
INFO - 2025-01-31 05:26:38 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:38 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:38 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:38 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:38 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:38 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:38 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:38 --> Upload Class Initialized
INFO - 2025-01-31 05:26:38 --> Email Class Initialized
INFO - 2025-01-31 05:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:38 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:38 --> Controller Class Initialized
INFO - 2025-01-31 10:56:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:38 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:38 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:43 --> Config Class Initialized
INFO - 2025-01-31 05:26:43 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:43 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:43 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:43 --> URI Class Initialized
INFO - 2025-01-31 05:26:43 --> Router Class Initialized
INFO - 2025-01-31 05:26:43 --> Output Class Initialized
INFO - 2025-01-31 05:26:43 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:43 --> Input Class Initialized
INFO - 2025-01-31 05:26:43 --> Language Class Initialized
INFO - 2025-01-31 05:26:43 --> Loader Class Initialized
INFO - 2025-01-31 05:26:43 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:43 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:43 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:43 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:43 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:43 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:43 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:43 --> Upload Class Initialized
INFO - 2025-01-31 05:26:43 --> Email Class Initialized
INFO - 2025-01-31 05:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:43 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:43 --> Controller Class Initialized
INFO - 2025-01-31 10:56:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:43 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:43 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:48 --> Config Class Initialized
INFO - 2025-01-31 05:26:48 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:48 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:48 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:48 --> URI Class Initialized
INFO - 2025-01-31 05:26:48 --> Router Class Initialized
INFO - 2025-01-31 05:26:48 --> Output Class Initialized
INFO - 2025-01-31 05:26:48 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:48 --> Input Class Initialized
INFO - 2025-01-31 05:26:48 --> Language Class Initialized
INFO - 2025-01-31 05:26:48 --> Loader Class Initialized
INFO - 2025-01-31 05:26:48 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:48 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:48 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:48 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:48 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:48 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:48 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:48 --> Upload Class Initialized
INFO - 2025-01-31 05:26:48 --> Email Class Initialized
INFO - 2025-01-31 05:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:48 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:48 --> Controller Class Initialized
INFO - 2025-01-31 10:56:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:48 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:48 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:53 --> Config Class Initialized
INFO - 2025-01-31 05:26:53 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:53 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:53 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:53 --> URI Class Initialized
INFO - 2025-01-31 05:26:53 --> Router Class Initialized
INFO - 2025-01-31 05:26:53 --> Output Class Initialized
INFO - 2025-01-31 05:26:53 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:53 --> Input Class Initialized
INFO - 2025-01-31 05:26:53 --> Language Class Initialized
INFO - 2025-01-31 05:26:53 --> Loader Class Initialized
INFO - 2025-01-31 05:26:53 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:53 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:53 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:53 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:53 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:53 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:53 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:53 --> Upload Class Initialized
INFO - 2025-01-31 05:26:53 --> Email Class Initialized
INFO - 2025-01-31 05:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:53 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:53 --> Controller Class Initialized
INFO - 2025-01-31 10:56:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:53 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:53 --> Pagination Class Initialized
INFO - 2025-01-31 05:26:58 --> Config Class Initialized
INFO - 2025-01-31 05:26:58 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:26:58 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:26:58 --> Utf8 Class Initialized
INFO - 2025-01-31 05:26:58 --> URI Class Initialized
INFO - 2025-01-31 05:26:58 --> Router Class Initialized
INFO - 2025-01-31 05:26:58 --> Output Class Initialized
INFO - 2025-01-31 05:26:58 --> Security Class Initialized
DEBUG - 2025-01-31 05:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:26:58 --> Input Class Initialized
INFO - 2025-01-31 05:26:58 --> Language Class Initialized
INFO - 2025-01-31 05:26:58 --> Loader Class Initialized
INFO - 2025-01-31 05:26:58 --> Helper loaded: url_helper
INFO - 2025-01-31 05:26:58 --> Helper loaded: html_helper
INFO - 2025-01-31 05:26:58 --> Helper loaded: file_helper
INFO - 2025-01-31 05:26:58 --> Helper loaded: string_helper
INFO - 2025-01-31 05:26:58 --> Helper loaded: form_helper
INFO - 2025-01-31 05:26:58 --> Helper loaded: my_helper
INFO - 2025-01-31 05:26:58 --> Database Driver Class Initialized
INFO - 2025-01-31 05:26:58 --> Upload Class Initialized
INFO - 2025-01-31 05:26:58 --> Email Class Initialized
INFO - 2025-01-31 05:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:26:58 --> Form Validation Class Initialized
INFO - 2025-01-31 05:26:58 --> Controller Class Initialized
INFO - 2025-01-31 10:56:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:56:58 --> Model "MainModel" initialized
INFO - 2025-01-31 10:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:56:58 --> Pagination Class Initialized
INFO - 2025-01-31 05:27:24 --> Config Class Initialized
INFO - 2025-01-31 05:27:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:27:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:27:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:27:24 --> URI Class Initialized
INFO - 2025-01-31 05:27:24 --> Router Class Initialized
INFO - 2025-01-31 05:27:24 --> Output Class Initialized
INFO - 2025-01-31 05:27:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:27:24 --> Input Class Initialized
INFO - 2025-01-31 05:27:24 --> Language Class Initialized
INFO - 2025-01-31 05:27:24 --> Loader Class Initialized
INFO - 2025-01-31 05:27:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:27:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:27:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:27:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:27:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:27:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:27:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:27:24 --> Upload Class Initialized
INFO - 2025-01-31 05:27:24 --> Email Class Initialized
INFO - 2025-01-31 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:27:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:27:24 --> Controller Class Initialized
INFO - 2025-01-31 10:57:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:57:24 --> Model "MainModel" initialized
INFO - 2025-01-31 10:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:57:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:28:24 --> Config Class Initialized
INFO - 2025-01-31 05:28:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:28:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:28:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:28:24 --> URI Class Initialized
INFO - 2025-01-31 05:28:24 --> Router Class Initialized
INFO - 2025-01-31 05:28:24 --> Output Class Initialized
INFO - 2025-01-31 05:28:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:28:24 --> Input Class Initialized
INFO - 2025-01-31 05:28:24 --> Language Class Initialized
INFO - 2025-01-31 05:28:24 --> Loader Class Initialized
INFO - 2025-01-31 05:28:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:28:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:28:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:28:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:28:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:28:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:28:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:28:24 --> Upload Class Initialized
INFO - 2025-01-31 05:28:24 --> Email Class Initialized
INFO - 2025-01-31 05:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:28:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:28:24 --> Controller Class Initialized
INFO - 2025-01-31 10:58:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:58:24 --> Model "MainModel" initialized
INFO - 2025-01-31 10:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:58:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:28:39 --> Config Class Initialized
INFO - 2025-01-31 05:28:39 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:28:39 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:28:39 --> Utf8 Class Initialized
INFO - 2025-01-31 05:28:39 --> URI Class Initialized
INFO - 2025-01-31 05:28:39 --> Router Class Initialized
INFO - 2025-01-31 05:28:39 --> Output Class Initialized
INFO - 2025-01-31 05:28:39 --> Security Class Initialized
DEBUG - 2025-01-31 05:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:28:39 --> Input Class Initialized
INFO - 2025-01-31 05:28:39 --> Language Class Initialized
INFO - 2025-01-31 05:28:39 --> Loader Class Initialized
INFO - 2025-01-31 05:28:39 --> Helper loaded: url_helper
INFO - 2025-01-31 05:28:39 --> Helper loaded: html_helper
INFO - 2025-01-31 05:28:39 --> Helper loaded: file_helper
INFO - 2025-01-31 05:28:39 --> Helper loaded: string_helper
INFO - 2025-01-31 05:28:39 --> Helper loaded: form_helper
INFO - 2025-01-31 05:28:39 --> Helper loaded: my_helper
INFO - 2025-01-31 05:28:39 --> Database Driver Class Initialized
INFO - 2025-01-31 05:28:39 --> Upload Class Initialized
INFO - 2025-01-31 05:28:39 --> Email Class Initialized
INFO - 2025-01-31 05:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:28:39 --> Form Validation Class Initialized
INFO - 2025-01-31 05:28:39 --> Controller Class Initialized
INFO - 2025-01-31 10:58:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:58:39 --> Model "MainModel" initialized
INFO - 2025-01-31 10:58:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:58:39 --> Pagination Class Initialized
INFO - 2025-01-31 05:28:43 --> Config Class Initialized
INFO - 2025-01-31 05:28:43 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:28:43 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:28:43 --> Utf8 Class Initialized
INFO - 2025-01-31 05:28:43 --> URI Class Initialized
INFO - 2025-01-31 05:28:43 --> Router Class Initialized
INFO - 2025-01-31 05:28:43 --> Output Class Initialized
INFO - 2025-01-31 05:28:43 --> Security Class Initialized
DEBUG - 2025-01-31 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:28:43 --> Input Class Initialized
INFO - 2025-01-31 05:28:43 --> Language Class Initialized
INFO - 2025-01-31 05:28:43 --> Loader Class Initialized
INFO - 2025-01-31 05:28:43 --> Helper loaded: url_helper
INFO - 2025-01-31 05:28:43 --> Helper loaded: html_helper
INFO - 2025-01-31 05:28:43 --> Helper loaded: file_helper
INFO - 2025-01-31 05:28:43 --> Helper loaded: string_helper
INFO - 2025-01-31 05:28:43 --> Helper loaded: form_helper
INFO - 2025-01-31 05:28:43 --> Helper loaded: my_helper
INFO - 2025-01-31 05:28:43 --> Database Driver Class Initialized
INFO - 2025-01-31 05:28:43 --> Upload Class Initialized
INFO - 2025-01-31 05:28:43 --> Email Class Initialized
INFO - 2025-01-31 05:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:28:43 --> Form Validation Class Initialized
INFO - 2025-01-31 05:28:43 --> Controller Class Initialized
INFO - 2025-01-31 10:58:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:58:43 --> Model "MainModel" initialized
INFO - 2025-01-31 10:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:58:43 --> Pagination Class Initialized
INFO - 2025-01-31 05:28:48 --> Config Class Initialized
INFO - 2025-01-31 05:28:48 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:28:48 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:28:48 --> Utf8 Class Initialized
INFO - 2025-01-31 05:28:48 --> URI Class Initialized
INFO - 2025-01-31 05:28:48 --> Router Class Initialized
INFO - 2025-01-31 05:28:48 --> Output Class Initialized
INFO - 2025-01-31 05:28:48 --> Security Class Initialized
DEBUG - 2025-01-31 05:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:28:48 --> Input Class Initialized
INFO - 2025-01-31 05:28:48 --> Language Class Initialized
INFO - 2025-01-31 05:28:48 --> Loader Class Initialized
INFO - 2025-01-31 05:28:48 --> Helper loaded: url_helper
INFO - 2025-01-31 05:28:48 --> Helper loaded: html_helper
INFO - 2025-01-31 05:28:48 --> Helper loaded: file_helper
INFO - 2025-01-31 05:28:48 --> Helper loaded: string_helper
INFO - 2025-01-31 05:28:48 --> Helper loaded: form_helper
INFO - 2025-01-31 05:28:48 --> Helper loaded: my_helper
INFO - 2025-01-31 05:28:48 --> Database Driver Class Initialized
INFO - 2025-01-31 05:28:48 --> Upload Class Initialized
INFO - 2025-01-31 05:28:48 --> Email Class Initialized
INFO - 2025-01-31 05:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:28:48 --> Form Validation Class Initialized
INFO - 2025-01-31 05:28:48 --> Controller Class Initialized
INFO - 2025-01-31 10:58:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:58:48 --> Model "MainModel" initialized
INFO - 2025-01-31 10:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:58:48 --> Pagination Class Initialized
INFO - 2025-01-31 05:28:53 --> Config Class Initialized
INFO - 2025-01-31 05:28:53 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:28:53 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:28:53 --> Utf8 Class Initialized
INFO - 2025-01-31 05:28:53 --> URI Class Initialized
INFO - 2025-01-31 05:28:53 --> Router Class Initialized
INFO - 2025-01-31 05:28:53 --> Output Class Initialized
INFO - 2025-01-31 05:28:53 --> Security Class Initialized
DEBUG - 2025-01-31 05:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:28:53 --> Input Class Initialized
INFO - 2025-01-31 05:28:53 --> Language Class Initialized
INFO - 2025-01-31 05:28:53 --> Loader Class Initialized
INFO - 2025-01-31 05:28:53 --> Helper loaded: url_helper
INFO - 2025-01-31 05:28:53 --> Helper loaded: html_helper
INFO - 2025-01-31 05:28:53 --> Helper loaded: file_helper
INFO - 2025-01-31 05:28:53 --> Helper loaded: string_helper
INFO - 2025-01-31 05:28:53 --> Helper loaded: form_helper
INFO - 2025-01-31 05:28:53 --> Helper loaded: my_helper
INFO - 2025-01-31 05:28:53 --> Database Driver Class Initialized
INFO - 2025-01-31 05:28:53 --> Upload Class Initialized
INFO - 2025-01-31 05:28:53 --> Email Class Initialized
INFO - 2025-01-31 05:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:28:53 --> Form Validation Class Initialized
INFO - 2025-01-31 05:28:53 --> Controller Class Initialized
INFO - 2025-01-31 10:58:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:58:53 --> Model "MainModel" initialized
INFO - 2025-01-31 10:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:58:53 --> Pagination Class Initialized
INFO - 2025-01-31 05:28:58 --> Config Class Initialized
INFO - 2025-01-31 05:28:58 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:28:58 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:28:58 --> Utf8 Class Initialized
INFO - 2025-01-31 05:28:58 --> URI Class Initialized
INFO - 2025-01-31 05:28:58 --> Router Class Initialized
INFO - 2025-01-31 05:28:58 --> Output Class Initialized
INFO - 2025-01-31 05:28:58 --> Security Class Initialized
DEBUG - 2025-01-31 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:28:58 --> Input Class Initialized
INFO - 2025-01-31 05:28:58 --> Language Class Initialized
INFO - 2025-01-31 05:28:58 --> Loader Class Initialized
INFO - 2025-01-31 05:28:58 --> Helper loaded: url_helper
INFO - 2025-01-31 05:28:58 --> Helper loaded: html_helper
INFO - 2025-01-31 05:28:58 --> Helper loaded: file_helper
INFO - 2025-01-31 05:28:58 --> Helper loaded: string_helper
INFO - 2025-01-31 05:28:58 --> Helper loaded: form_helper
INFO - 2025-01-31 05:28:58 --> Helper loaded: my_helper
INFO - 2025-01-31 05:28:58 --> Database Driver Class Initialized
INFO - 2025-01-31 05:28:58 --> Upload Class Initialized
INFO - 2025-01-31 05:28:58 --> Email Class Initialized
INFO - 2025-01-31 05:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:28:58 --> Form Validation Class Initialized
INFO - 2025-01-31 05:28:58 --> Controller Class Initialized
INFO - 2025-01-31 10:58:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:58:58 --> Model "MainModel" initialized
INFO - 2025-01-31 10:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:58:58 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:03 --> Config Class Initialized
INFO - 2025-01-31 05:29:03 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:03 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:03 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:03 --> URI Class Initialized
INFO - 2025-01-31 05:29:03 --> Router Class Initialized
INFO - 2025-01-31 05:29:03 --> Output Class Initialized
INFO - 2025-01-31 05:29:03 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:03 --> Input Class Initialized
INFO - 2025-01-31 05:29:03 --> Language Class Initialized
INFO - 2025-01-31 05:29:03 --> Loader Class Initialized
INFO - 2025-01-31 05:29:03 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:03 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:03 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:03 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:03 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:03 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:03 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:03 --> Upload Class Initialized
INFO - 2025-01-31 05:29:03 --> Email Class Initialized
INFO - 2025-01-31 05:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:03 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:03 --> Controller Class Initialized
INFO - 2025-01-31 10:59:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:03 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:03 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:08 --> Config Class Initialized
INFO - 2025-01-31 05:29:08 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:08 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:08 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:08 --> URI Class Initialized
INFO - 2025-01-31 05:29:08 --> Router Class Initialized
INFO - 2025-01-31 05:29:08 --> Output Class Initialized
INFO - 2025-01-31 05:29:08 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:08 --> Input Class Initialized
INFO - 2025-01-31 05:29:08 --> Language Class Initialized
INFO - 2025-01-31 05:29:08 --> Loader Class Initialized
INFO - 2025-01-31 05:29:08 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:08 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:08 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:08 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:08 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:08 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:08 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:08 --> Upload Class Initialized
INFO - 2025-01-31 05:29:08 --> Email Class Initialized
INFO - 2025-01-31 05:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:08 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:08 --> Controller Class Initialized
INFO - 2025-01-31 10:59:08 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:08 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:08 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:13 --> Config Class Initialized
INFO - 2025-01-31 05:29:13 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:13 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:13 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:13 --> URI Class Initialized
INFO - 2025-01-31 05:29:13 --> Router Class Initialized
INFO - 2025-01-31 05:29:13 --> Output Class Initialized
INFO - 2025-01-31 05:29:13 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:13 --> Input Class Initialized
INFO - 2025-01-31 05:29:13 --> Language Class Initialized
INFO - 2025-01-31 05:29:13 --> Loader Class Initialized
INFO - 2025-01-31 05:29:13 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:13 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:13 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:13 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:13 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:13 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:13 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:13 --> Upload Class Initialized
INFO - 2025-01-31 05:29:13 --> Email Class Initialized
INFO - 2025-01-31 05:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:13 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:13 --> Controller Class Initialized
INFO - 2025-01-31 10:59:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:13 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:13 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:18 --> Config Class Initialized
INFO - 2025-01-31 05:29:18 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:18 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:18 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:18 --> URI Class Initialized
INFO - 2025-01-31 05:29:18 --> Router Class Initialized
INFO - 2025-01-31 05:29:18 --> Output Class Initialized
INFO - 2025-01-31 05:29:18 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:18 --> Input Class Initialized
INFO - 2025-01-31 05:29:18 --> Language Class Initialized
INFO - 2025-01-31 05:29:18 --> Loader Class Initialized
INFO - 2025-01-31 05:29:18 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:18 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:18 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:18 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:18 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:18 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:18 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:18 --> Upload Class Initialized
INFO - 2025-01-31 05:29:18 --> Email Class Initialized
INFO - 2025-01-31 05:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:18 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:18 --> Controller Class Initialized
INFO - 2025-01-31 10:59:18 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:18 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:18 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:23 --> Config Class Initialized
INFO - 2025-01-31 05:29:23 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:23 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:23 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:23 --> URI Class Initialized
INFO - 2025-01-31 05:29:23 --> Router Class Initialized
INFO - 2025-01-31 05:29:23 --> Output Class Initialized
INFO - 2025-01-31 05:29:23 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:23 --> Input Class Initialized
INFO - 2025-01-31 05:29:23 --> Language Class Initialized
INFO - 2025-01-31 05:29:23 --> Loader Class Initialized
INFO - 2025-01-31 05:29:23 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:23 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:23 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:23 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:23 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:23 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:23 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:23 --> Upload Class Initialized
INFO - 2025-01-31 05:29:23 --> Email Class Initialized
INFO - 2025-01-31 05:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:23 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:23 --> Controller Class Initialized
INFO - 2025-01-31 10:59:23 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:23 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:23 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:28 --> Config Class Initialized
INFO - 2025-01-31 05:29:28 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:28 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:28 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:28 --> URI Class Initialized
INFO - 2025-01-31 05:29:28 --> Router Class Initialized
INFO - 2025-01-31 05:29:28 --> Output Class Initialized
INFO - 2025-01-31 05:29:28 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:28 --> Input Class Initialized
INFO - 2025-01-31 05:29:28 --> Language Class Initialized
INFO - 2025-01-31 05:29:28 --> Loader Class Initialized
INFO - 2025-01-31 05:29:28 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:28 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:28 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:28 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:28 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:28 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:28 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:28 --> Upload Class Initialized
INFO - 2025-01-31 05:29:28 --> Email Class Initialized
INFO - 2025-01-31 05:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:28 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:28 --> Controller Class Initialized
INFO - 2025-01-31 10:59:28 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:28 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:28 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:33 --> Config Class Initialized
INFO - 2025-01-31 05:29:33 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:33 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:33 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:33 --> URI Class Initialized
INFO - 2025-01-31 05:29:33 --> Router Class Initialized
INFO - 2025-01-31 05:29:33 --> Output Class Initialized
INFO - 2025-01-31 05:29:33 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:33 --> Input Class Initialized
INFO - 2025-01-31 05:29:33 --> Language Class Initialized
INFO - 2025-01-31 05:29:33 --> Loader Class Initialized
INFO - 2025-01-31 05:29:33 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:33 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:33 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:33 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:33 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:33 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:33 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:33 --> Upload Class Initialized
INFO - 2025-01-31 05:29:33 --> Email Class Initialized
INFO - 2025-01-31 05:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:33 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:33 --> Controller Class Initialized
INFO - 2025-01-31 10:59:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:33 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:33 --> Pagination Class Initialized
INFO - 2025-01-31 05:29:38 --> Config Class Initialized
INFO - 2025-01-31 05:29:38 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:29:38 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:29:38 --> Utf8 Class Initialized
INFO - 2025-01-31 05:29:38 --> URI Class Initialized
INFO - 2025-01-31 05:29:38 --> Router Class Initialized
INFO - 2025-01-31 05:29:38 --> Output Class Initialized
INFO - 2025-01-31 05:29:38 --> Security Class Initialized
DEBUG - 2025-01-31 05:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:29:38 --> Input Class Initialized
INFO - 2025-01-31 05:29:38 --> Language Class Initialized
INFO - 2025-01-31 05:29:38 --> Loader Class Initialized
INFO - 2025-01-31 05:29:38 --> Helper loaded: url_helper
INFO - 2025-01-31 05:29:38 --> Helper loaded: html_helper
INFO - 2025-01-31 05:29:38 --> Helper loaded: file_helper
INFO - 2025-01-31 05:29:38 --> Helper loaded: string_helper
INFO - 2025-01-31 05:29:38 --> Helper loaded: form_helper
INFO - 2025-01-31 05:29:38 --> Helper loaded: my_helper
INFO - 2025-01-31 05:29:38 --> Database Driver Class Initialized
INFO - 2025-01-31 05:29:38 --> Upload Class Initialized
INFO - 2025-01-31 05:29:38 --> Email Class Initialized
INFO - 2025-01-31 05:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:29:38 --> Form Validation Class Initialized
INFO - 2025-01-31 05:29:38 --> Controller Class Initialized
INFO - 2025-01-31 10:59:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 10:59:38 --> Model "MainModel" initialized
INFO - 2025-01-31 10:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 10:59:38 --> Pagination Class Initialized
INFO - 2025-01-31 05:30:24 --> Config Class Initialized
INFO - 2025-01-31 05:30:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:30:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:30:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:30:24 --> URI Class Initialized
INFO - 2025-01-31 05:30:24 --> Router Class Initialized
INFO - 2025-01-31 05:30:24 --> Output Class Initialized
INFO - 2025-01-31 05:30:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:30:24 --> Input Class Initialized
INFO - 2025-01-31 05:30:24 --> Language Class Initialized
INFO - 2025-01-31 05:30:24 --> Loader Class Initialized
INFO - 2025-01-31 05:30:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:30:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:30:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:30:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:30:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:30:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:30:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:30:24 --> Upload Class Initialized
INFO - 2025-01-31 05:30:24 --> Email Class Initialized
INFO - 2025-01-31 05:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:30:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:30:24 --> Controller Class Initialized
INFO - 2025-01-31 11:00:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:00:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:00:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:31:24 --> Config Class Initialized
INFO - 2025-01-31 05:31:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:31:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:31:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:31:24 --> URI Class Initialized
INFO - 2025-01-31 05:31:24 --> Router Class Initialized
INFO - 2025-01-31 05:31:24 --> Output Class Initialized
INFO - 2025-01-31 05:31:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:31:24 --> Input Class Initialized
INFO - 2025-01-31 05:31:24 --> Language Class Initialized
INFO - 2025-01-31 05:31:24 --> Loader Class Initialized
INFO - 2025-01-31 05:31:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:31:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:31:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:31:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:31:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:31:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:31:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:31:24 --> Upload Class Initialized
INFO - 2025-01-31 05:31:24 --> Email Class Initialized
INFO - 2025-01-31 05:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:31:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:31:24 --> Controller Class Initialized
INFO - 2025-01-31 11:01:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:01:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:01:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:32:24 --> Config Class Initialized
INFO - 2025-01-31 05:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:32:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:32:24 --> URI Class Initialized
INFO - 2025-01-31 05:32:24 --> Router Class Initialized
INFO - 2025-01-31 05:32:24 --> Output Class Initialized
INFO - 2025-01-31 05:32:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:32:24 --> Input Class Initialized
INFO - 2025-01-31 05:32:24 --> Language Class Initialized
INFO - 2025-01-31 05:32:24 --> Loader Class Initialized
INFO - 2025-01-31 05:32:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:32:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:32:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:32:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:32:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:32:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:32:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:32:24 --> Upload Class Initialized
INFO - 2025-01-31 05:32:24 --> Email Class Initialized
INFO - 2025-01-31 05:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:32:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:32:24 --> Controller Class Initialized
INFO - 2025-01-31 11:02:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:02:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:02:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:33:24 --> Config Class Initialized
INFO - 2025-01-31 05:33:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:33:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:33:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:33:24 --> URI Class Initialized
INFO - 2025-01-31 05:33:24 --> Router Class Initialized
INFO - 2025-01-31 05:33:24 --> Output Class Initialized
INFO - 2025-01-31 05:33:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:33:24 --> Input Class Initialized
INFO - 2025-01-31 05:33:24 --> Language Class Initialized
INFO - 2025-01-31 05:33:24 --> Loader Class Initialized
INFO - 2025-01-31 05:33:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:33:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:33:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:33:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:33:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:33:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:33:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:33:24 --> Upload Class Initialized
INFO - 2025-01-31 05:33:24 --> Email Class Initialized
INFO - 2025-01-31 05:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:33:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:33:24 --> Controller Class Initialized
INFO - 2025-01-31 11:03:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:03:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:03:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:34:24 --> Config Class Initialized
INFO - 2025-01-31 05:34:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:34:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:34:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:34:24 --> URI Class Initialized
INFO - 2025-01-31 05:34:24 --> Router Class Initialized
INFO - 2025-01-31 05:34:24 --> Output Class Initialized
INFO - 2025-01-31 05:34:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:34:24 --> Input Class Initialized
INFO - 2025-01-31 05:34:24 --> Language Class Initialized
INFO - 2025-01-31 05:34:24 --> Loader Class Initialized
INFO - 2025-01-31 05:34:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:34:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:34:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:34:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:34:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:34:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:34:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:34:24 --> Upload Class Initialized
INFO - 2025-01-31 05:34:24 --> Email Class Initialized
INFO - 2025-01-31 05:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:34:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:34:24 --> Controller Class Initialized
INFO - 2025-01-31 11:04:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:04:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:04:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:35:24 --> Config Class Initialized
INFO - 2025-01-31 05:35:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:35:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:35:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:35:24 --> URI Class Initialized
INFO - 2025-01-31 05:35:24 --> Router Class Initialized
INFO - 2025-01-31 05:35:24 --> Output Class Initialized
INFO - 2025-01-31 05:35:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:35:24 --> Input Class Initialized
INFO - 2025-01-31 05:35:24 --> Language Class Initialized
INFO - 2025-01-31 05:35:24 --> Loader Class Initialized
INFO - 2025-01-31 05:35:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:35:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:35:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:35:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:35:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:35:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:35:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:35:24 --> Upload Class Initialized
INFO - 2025-01-31 05:35:24 --> Email Class Initialized
INFO - 2025-01-31 05:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:35:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:35:24 --> Controller Class Initialized
INFO - 2025-01-31 11:05:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:05:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:05:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:36:24 --> Config Class Initialized
INFO - 2025-01-31 05:36:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:36:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:36:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:36:24 --> URI Class Initialized
INFO - 2025-01-31 05:36:24 --> Router Class Initialized
INFO - 2025-01-31 05:36:24 --> Output Class Initialized
INFO - 2025-01-31 05:36:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:36:24 --> Input Class Initialized
INFO - 2025-01-31 05:36:24 --> Language Class Initialized
INFO - 2025-01-31 05:36:24 --> Loader Class Initialized
INFO - 2025-01-31 05:36:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:36:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:36:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:36:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:36:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:36:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:36:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:36:24 --> Upload Class Initialized
INFO - 2025-01-31 05:36:24 --> Email Class Initialized
INFO - 2025-01-31 05:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:36:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:36:24 --> Controller Class Initialized
INFO - 2025-01-31 11:06:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:06:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:06:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:37:24 --> Config Class Initialized
INFO - 2025-01-31 05:37:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:37:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:37:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:37:24 --> URI Class Initialized
INFO - 2025-01-31 05:37:24 --> Router Class Initialized
INFO - 2025-01-31 05:37:24 --> Output Class Initialized
INFO - 2025-01-31 05:37:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:37:24 --> Input Class Initialized
INFO - 2025-01-31 05:37:24 --> Language Class Initialized
INFO - 2025-01-31 05:37:24 --> Loader Class Initialized
INFO - 2025-01-31 05:37:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:37:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:37:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:37:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:37:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:37:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:37:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:37:24 --> Upload Class Initialized
INFO - 2025-01-31 05:37:24 --> Email Class Initialized
INFO - 2025-01-31 05:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:37:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:37:24 --> Controller Class Initialized
INFO - 2025-01-31 11:07:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:07:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:07:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:38:24 --> Config Class Initialized
INFO - 2025-01-31 05:38:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:38:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:38:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:38:24 --> URI Class Initialized
INFO - 2025-01-31 05:38:24 --> Router Class Initialized
INFO - 2025-01-31 05:38:24 --> Output Class Initialized
INFO - 2025-01-31 05:38:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:38:24 --> Input Class Initialized
INFO - 2025-01-31 05:38:24 --> Language Class Initialized
INFO - 2025-01-31 05:38:24 --> Loader Class Initialized
INFO - 2025-01-31 05:38:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:38:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:38:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:38:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:38:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:38:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:38:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:38:24 --> Upload Class Initialized
INFO - 2025-01-31 05:38:24 --> Email Class Initialized
INFO - 2025-01-31 05:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:38:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:38:24 --> Controller Class Initialized
INFO - 2025-01-31 11:08:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:08:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:08:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:39:24 --> Config Class Initialized
INFO - 2025-01-31 05:39:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:39:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:39:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:39:24 --> URI Class Initialized
INFO - 2025-01-31 05:39:24 --> Router Class Initialized
INFO - 2025-01-31 05:39:24 --> Output Class Initialized
INFO - 2025-01-31 05:39:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:39:24 --> Input Class Initialized
INFO - 2025-01-31 05:39:24 --> Language Class Initialized
INFO - 2025-01-31 05:39:24 --> Loader Class Initialized
INFO - 2025-01-31 05:39:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:39:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:39:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:39:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:39:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:39:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:39:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:39:24 --> Upload Class Initialized
INFO - 2025-01-31 05:39:24 --> Email Class Initialized
INFO - 2025-01-31 05:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:39:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:39:24 --> Controller Class Initialized
INFO - 2025-01-31 11:09:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:09:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:09:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:40:24 --> Config Class Initialized
INFO - 2025-01-31 05:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:40:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:40:24 --> URI Class Initialized
INFO - 2025-01-31 05:40:24 --> Router Class Initialized
INFO - 2025-01-31 05:40:24 --> Output Class Initialized
INFO - 2025-01-31 05:40:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:40:24 --> Input Class Initialized
INFO - 2025-01-31 05:40:24 --> Language Class Initialized
INFO - 2025-01-31 05:40:24 --> Loader Class Initialized
INFO - 2025-01-31 05:40:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:40:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:40:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:40:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:40:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:40:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:40:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:40:24 --> Upload Class Initialized
INFO - 2025-01-31 05:40:24 --> Email Class Initialized
INFO - 2025-01-31 05:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:40:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:40:24 --> Controller Class Initialized
INFO - 2025-01-31 11:10:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:10:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:10:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:41:24 --> Config Class Initialized
INFO - 2025-01-31 05:41:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:41:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:41:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:41:24 --> URI Class Initialized
INFO - 2025-01-31 05:41:24 --> Router Class Initialized
INFO - 2025-01-31 05:41:24 --> Output Class Initialized
INFO - 2025-01-31 05:41:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:41:24 --> Input Class Initialized
INFO - 2025-01-31 05:41:24 --> Language Class Initialized
INFO - 2025-01-31 05:41:24 --> Loader Class Initialized
INFO - 2025-01-31 05:41:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:41:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:41:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:41:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:41:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:41:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:41:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:41:24 --> Upload Class Initialized
INFO - 2025-01-31 05:41:24 --> Email Class Initialized
INFO - 2025-01-31 05:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:41:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:41:24 --> Controller Class Initialized
INFO - 2025-01-31 11:11:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:11:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:11:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:42:24 --> Config Class Initialized
INFO - 2025-01-31 05:42:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:42:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:42:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:42:24 --> URI Class Initialized
INFO - 2025-01-31 05:42:24 --> Router Class Initialized
INFO - 2025-01-31 05:42:24 --> Output Class Initialized
INFO - 2025-01-31 05:42:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:42:24 --> Input Class Initialized
INFO - 2025-01-31 05:42:24 --> Language Class Initialized
INFO - 2025-01-31 05:42:24 --> Loader Class Initialized
INFO - 2025-01-31 05:42:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:42:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:42:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:42:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:42:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:42:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:42:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:42:24 --> Upload Class Initialized
INFO - 2025-01-31 05:42:24 --> Email Class Initialized
INFO - 2025-01-31 05:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:42:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:42:24 --> Controller Class Initialized
INFO - 2025-01-31 11:12:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:12:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:12:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:43:24 --> Config Class Initialized
INFO - 2025-01-31 05:43:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:43:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:43:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:43:24 --> URI Class Initialized
INFO - 2025-01-31 05:43:24 --> Router Class Initialized
INFO - 2025-01-31 05:43:24 --> Output Class Initialized
INFO - 2025-01-31 05:43:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:43:24 --> Input Class Initialized
INFO - 2025-01-31 05:43:24 --> Language Class Initialized
INFO - 2025-01-31 05:43:24 --> Loader Class Initialized
INFO - 2025-01-31 05:43:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:43:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:43:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:43:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:43:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:43:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:43:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:43:24 --> Upload Class Initialized
INFO - 2025-01-31 05:43:24 --> Email Class Initialized
INFO - 2025-01-31 05:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:43:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:43:24 --> Controller Class Initialized
INFO - 2025-01-31 11:13:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:13:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:13:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:44:24 --> Config Class Initialized
INFO - 2025-01-31 05:44:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:44:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:44:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:44:24 --> URI Class Initialized
INFO - 2025-01-31 05:44:24 --> Router Class Initialized
INFO - 2025-01-31 05:44:24 --> Output Class Initialized
INFO - 2025-01-31 05:44:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:44:24 --> Input Class Initialized
INFO - 2025-01-31 05:44:24 --> Language Class Initialized
INFO - 2025-01-31 05:44:24 --> Loader Class Initialized
INFO - 2025-01-31 05:44:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:44:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:44:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:44:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:44:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:44:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:44:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:44:24 --> Upload Class Initialized
INFO - 2025-01-31 05:44:24 --> Email Class Initialized
INFO - 2025-01-31 05:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:44:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:44:24 --> Controller Class Initialized
INFO - 2025-01-31 11:14:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:14:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:14:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:45:24 --> Config Class Initialized
INFO - 2025-01-31 05:45:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:45:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:45:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:45:24 --> URI Class Initialized
INFO - 2025-01-31 05:45:24 --> Router Class Initialized
INFO - 2025-01-31 05:45:24 --> Output Class Initialized
INFO - 2025-01-31 05:45:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:45:24 --> Input Class Initialized
INFO - 2025-01-31 05:45:24 --> Language Class Initialized
INFO - 2025-01-31 05:45:24 --> Loader Class Initialized
INFO - 2025-01-31 05:45:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:45:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:45:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:45:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:45:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:45:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:45:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:45:24 --> Upload Class Initialized
INFO - 2025-01-31 05:45:24 --> Email Class Initialized
INFO - 2025-01-31 05:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:45:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:45:24 --> Controller Class Initialized
INFO - 2025-01-31 11:15:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:15:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:15:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:46:24 --> Config Class Initialized
INFO - 2025-01-31 05:46:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:46:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:46:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:46:24 --> URI Class Initialized
INFO - 2025-01-31 05:46:24 --> Router Class Initialized
INFO - 2025-01-31 05:46:24 --> Output Class Initialized
INFO - 2025-01-31 05:46:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:46:24 --> Input Class Initialized
INFO - 2025-01-31 05:46:24 --> Language Class Initialized
INFO - 2025-01-31 05:46:24 --> Loader Class Initialized
INFO - 2025-01-31 05:46:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:46:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:46:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:46:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:46:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:46:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:46:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:46:24 --> Upload Class Initialized
INFO - 2025-01-31 05:46:24 --> Email Class Initialized
INFO - 2025-01-31 05:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:46:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:46:24 --> Controller Class Initialized
INFO - 2025-01-31 11:16:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:16:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:16:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:47:24 --> Config Class Initialized
INFO - 2025-01-31 05:47:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:47:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:47:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:47:24 --> URI Class Initialized
INFO - 2025-01-31 05:47:24 --> Router Class Initialized
INFO - 2025-01-31 05:47:24 --> Output Class Initialized
INFO - 2025-01-31 05:47:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:47:24 --> Input Class Initialized
INFO - 2025-01-31 05:47:24 --> Language Class Initialized
INFO - 2025-01-31 05:47:24 --> Loader Class Initialized
INFO - 2025-01-31 05:47:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:47:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:47:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:47:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:47:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:47:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:47:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:47:24 --> Upload Class Initialized
INFO - 2025-01-31 05:47:24 --> Email Class Initialized
INFO - 2025-01-31 05:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:47:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:47:24 --> Controller Class Initialized
INFO - 2025-01-31 11:17:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:17:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:17:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:48:24 --> Config Class Initialized
INFO - 2025-01-31 05:48:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:48:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:48:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:48:24 --> URI Class Initialized
INFO - 2025-01-31 05:48:24 --> Router Class Initialized
INFO - 2025-01-31 05:48:24 --> Output Class Initialized
INFO - 2025-01-31 05:48:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:48:24 --> Input Class Initialized
INFO - 2025-01-31 05:48:24 --> Language Class Initialized
INFO - 2025-01-31 05:48:24 --> Loader Class Initialized
INFO - 2025-01-31 05:48:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:48:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:48:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:48:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:48:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:48:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:48:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:48:24 --> Upload Class Initialized
INFO - 2025-01-31 05:48:24 --> Email Class Initialized
INFO - 2025-01-31 05:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:48:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:48:24 --> Controller Class Initialized
INFO - 2025-01-31 11:18:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:18:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:18:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:49:24 --> Config Class Initialized
INFO - 2025-01-31 05:49:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:49:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:49:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:49:24 --> URI Class Initialized
INFO - 2025-01-31 05:49:24 --> Router Class Initialized
INFO - 2025-01-31 05:49:24 --> Output Class Initialized
INFO - 2025-01-31 05:49:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:49:24 --> Input Class Initialized
INFO - 2025-01-31 05:49:24 --> Language Class Initialized
INFO - 2025-01-31 05:49:24 --> Loader Class Initialized
INFO - 2025-01-31 05:49:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:49:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:49:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:49:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:49:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:49:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:49:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:49:24 --> Upload Class Initialized
INFO - 2025-01-31 05:49:24 --> Email Class Initialized
INFO - 2025-01-31 05:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:49:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:49:24 --> Controller Class Initialized
INFO - 2025-01-31 11:19:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:19:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:19:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:50:24 --> Config Class Initialized
INFO - 2025-01-31 05:50:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:50:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:50:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:50:24 --> URI Class Initialized
INFO - 2025-01-31 05:50:24 --> Router Class Initialized
INFO - 2025-01-31 05:50:24 --> Output Class Initialized
INFO - 2025-01-31 05:50:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:50:24 --> Input Class Initialized
INFO - 2025-01-31 05:50:24 --> Language Class Initialized
INFO - 2025-01-31 05:50:24 --> Loader Class Initialized
INFO - 2025-01-31 05:50:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:50:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:50:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:50:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:50:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:50:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:50:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:50:24 --> Upload Class Initialized
INFO - 2025-01-31 05:50:24 --> Email Class Initialized
INFO - 2025-01-31 05:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:50:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:50:24 --> Controller Class Initialized
INFO - 2025-01-31 11:20:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:20:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:20:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:51:24 --> Config Class Initialized
INFO - 2025-01-31 05:51:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:51:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:51:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:51:24 --> URI Class Initialized
INFO - 2025-01-31 05:51:24 --> Router Class Initialized
INFO - 2025-01-31 05:51:24 --> Output Class Initialized
INFO - 2025-01-31 05:51:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:51:24 --> Input Class Initialized
INFO - 2025-01-31 05:51:24 --> Language Class Initialized
INFO - 2025-01-31 05:51:24 --> Loader Class Initialized
INFO - 2025-01-31 05:51:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:51:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:51:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:51:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:51:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:51:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:51:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:51:24 --> Upload Class Initialized
INFO - 2025-01-31 05:51:24 --> Email Class Initialized
INFO - 2025-01-31 05:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:51:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:51:24 --> Controller Class Initialized
INFO - 2025-01-31 11:21:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:21:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:21:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:52:24 --> Config Class Initialized
INFO - 2025-01-31 05:52:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:52:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:52:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:52:24 --> URI Class Initialized
INFO - 2025-01-31 05:52:24 --> Router Class Initialized
INFO - 2025-01-31 05:52:24 --> Output Class Initialized
INFO - 2025-01-31 05:52:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:52:24 --> Input Class Initialized
INFO - 2025-01-31 05:52:24 --> Language Class Initialized
INFO - 2025-01-31 05:52:24 --> Loader Class Initialized
INFO - 2025-01-31 05:52:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:52:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:52:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:52:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:52:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:52:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:52:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:52:24 --> Upload Class Initialized
INFO - 2025-01-31 05:52:24 --> Email Class Initialized
INFO - 2025-01-31 05:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:52:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:52:24 --> Controller Class Initialized
INFO - 2025-01-31 11:22:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:22:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:22:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:53:24 --> Config Class Initialized
INFO - 2025-01-31 05:53:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:53:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:53:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:53:24 --> URI Class Initialized
INFO - 2025-01-31 05:53:24 --> Router Class Initialized
INFO - 2025-01-31 05:53:24 --> Output Class Initialized
INFO - 2025-01-31 05:53:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:53:24 --> Input Class Initialized
INFO - 2025-01-31 05:53:24 --> Language Class Initialized
INFO - 2025-01-31 05:53:24 --> Loader Class Initialized
INFO - 2025-01-31 05:53:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:53:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:53:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:53:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:53:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:53:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:53:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:53:24 --> Upload Class Initialized
INFO - 2025-01-31 05:53:24 --> Email Class Initialized
INFO - 2025-01-31 05:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:53:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:53:24 --> Controller Class Initialized
INFO - 2025-01-31 11:23:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:23:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:23:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:54:24 --> Config Class Initialized
INFO - 2025-01-31 05:54:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:54:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:54:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:54:24 --> URI Class Initialized
INFO - 2025-01-31 05:54:24 --> Router Class Initialized
INFO - 2025-01-31 05:54:24 --> Output Class Initialized
INFO - 2025-01-31 05:54:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:54:24 --> Input Class Initialized
INFO - 2025-01-31 05:54:24 --> Language Class Initialized
INFO - 2025-01-31 05:54:24 --> Loader Class Initialized
INFO - 2025-01-31 05:54:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:54:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:54:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:54:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:54:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:54:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:54:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:54:24 --> Upload Class Initialized
INFO - 2025-01-31 05:54:24 --> Email Class Initialized
INFO - 2025-01-31 05:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:54:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:54:24 --> Controller Class Initialized
INFO - 2025-01-31 11:24:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:24:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:24:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:55:24 --> Config Class Initialized
INFO - 2025-01-31 05:55:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:55:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:55:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:55:24 --> URI Class Initialized
INFO - 2025-01-31 05:55:24 --> Router Class Initialized
INFO - 2025-01-31 05:55:24 --> Output Class Initialized
INFO - 2025-01-31 05:55:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:55:24 --> Input Class Initialized
INFO - 2025-01-31 05:55:24 --> Language Class Initialized
INFO - 2025-01-31 05:55:24 --> Loader Class Initialized
INFO - 2025-01-31 05:55:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:55:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:55:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:55:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:55:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:55:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:55:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:55:24 --> Upload Class Initialized
INFO - 2025-01-31 05:55:24 --> Email Class Initialized
INFO - 2025-01-31 05:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:55:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:55:24 --> Controller Class Initialized
INFO - 2025-01-31 11:25:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:25:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:25:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:56:24 --> Config Class Initialized
INFO - 2025-01-31 05:56:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:56:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:56:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:56:24 --> URI Class Initialized
INFO - 2025-01-31 05:56:24 --> Router Class Initialized
INFO - 2025-01-31 05:56:24 --> Output Class Initialized
INFO - 2025-01-31 05:56:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:56:24 --> Input Class Initialized
INFO - 2025-01-31 05:56:24 --> Language Class Initialized
INFO - 2025-01-31 05:56:24 --> Loader Class Initialized
INFO - 2025-01-31 05:56:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:56:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:56:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:56:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:56:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:56:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:56:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:56:24 --> Upload Class Initialized
INFO - 2025-01-31 05:56:24 --> Email Class Initialized
INFO - 2025-01-31 05:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:56:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:56:24 --> Controller Class Initialized
INFO - 2025-01-31 11:26:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:26:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:26:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:57:24 --> Config Class Initialized
INFO - 2025-01-31 05:57:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:57:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:57:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:57:24 --> URI Class Initialized
INFO - 2025-01-31 05:57:24 --> Router Class Initialized
INFO - 2025-01-31 05:57:24 --> Output Class Initialized
INFO - 2025-01-31 05:57:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:57:24 --> Input Class Initialized
INFO - 2025-01-31 05:57:24 --> Language Class Initialized
INFO - 2025-01-31 05:57:24 --> Loader Class Initialized
INFO - 2025-01-31 05:57:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:57:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:57:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:57:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:57:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:57:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:57:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:57:24 --> Upload Class Initialized
INFO - 2025-01-31 05:57:24 --> Email Class Initialized
INFO - 2025-01-31 05:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:57:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:57:24 --> Controller Class Initialized
INFO - 2025-01-31 11:27:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:27:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:27:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:58:24 --> Config Class Initialized
INFO - 2025-01-31 05:58:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:58:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:58:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:58:24 --> URI Class Initialized
INFO - 2025-01-31 05:58:24 --> Router Class Initialized
INFO - 2025-01-31 05:58:24 --> Output Class Initialized
INFO - 2025-01-31 05:58:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:58:24 --> Input Class Initialized
INFO - 2025-01-31 05:58:24 --> Language Class Initialized
INFO - 2025-01-31 05:58:24 --> Loader Class Initialized
INFO - 2025-01-31 05:58:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:58:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:58:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:58:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:58:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:58:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:58:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:58:24 --> Upload Class Initialized
INFO - 2025-01-31 05:58:24 --> Email Class Initialized
INFO - 2025-01-31 05:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:58:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:58:24 --> Controller Class Initialized
INFO - 2025-01-31 11:28:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:28:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:28:24 --> Pagination Class Initialized
INFO - 2025-01-31 05:59:24 --> Config Class Initialized
INFO - 2025-01-31 05:59:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 05:59:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 05:59:24 --> Utf8 Class Initialized
INFO - 2025-01-31 05:59:24 --> URI Class Initialized
INFO - 2025-01-31 05:59:24 --> Router Class Initialized
INFO - 2025-01-31 05:59:24 --> Output Class Initialized
INFO - 2025-01-31 05:59:24 --> Security Class Initialized
DEBUG - 2025-01-31 05:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 05:59:24 --> Input Class Initialized
INFO - 2025-01-31 05:59:24 --> Language Class Initialized
INFO - 2025-01-31 05:59:24 --> Loader Class Initialized
INFO - 2025-01-31 05:59:24 --> Helper loaded: url_helper
INFO - 2025-01-31 05:59:24 --> Helper loaded: html_helper
INFO - 2025-01-31 05:59:24 --> Helper loaded: file_helper
INFO - 2025-01-31 05:59:24 --> Helper loaded: string_helper
INFO - 2025-01-31 05:59:24 --> Helper loaded: form_helper
INFO - 2025-01-31 05:59:24 --> Helper loaded: my_helper
INFO - 2025-01-31 05:59:24 --> Database Driver Class Initialized
INFO - 2025-01-31 05:59:24 --> Upload Class Initialized
INFO - 2025-01-31 05:59:24 --> Email Class Initialized
INFO - 2025-01-31 05:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 05:59:24 --> Form Validation Class Initialized
INFO - 2025-01-31 05:59:24 --> Controller Class Initialized
INFO - 2025-01-31 11:29:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:29:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:29:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:00:24 --> Config Class Initialized
INFO - 2025-01-31 06:00:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:00:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:00:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:00:24 --> URI Class Initialized
INFO - 2025-01-31 06:00:24 --> Router Class Initialized
INFO - 2025-01-31 06:00:24 --> Output Class Initialized
INFO - 2025-01-31 06:00:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:00:24 --> Input Class Initialized
INFO - 2025-01-31 06:00:24 --> Language Class Initialized
INFO - 2025-01-31 06:00:24 --> Loader Class Initialized
INFO - 2025-01-31 06:00:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:00:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:00:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:00:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:00:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:00:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:00:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:00:24 --> Upload Class Initialized
INFO - 2025-01-31 06:00:24 --> Email Class Initialized
INFO - 2025-01-31 06:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:00:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:00:24 --> Controller Class Initialized
INFO - 2025-01-31 11:30:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:30:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:30:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:01:24 --> Config Class Initialized
INFO - 2025-01-31 06:01:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:01:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:01:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:01:24 --> URI Class Initialized
INFO - 2025-01-31 06:01:24 --> Router Class Initialized
INFO - 2025-01-31 06:01:24 --> Output Class Initialized
INFO - 2025-01-31 06:01:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:01:24 --> Input Class Initialized
INFO - 2025-01-31 06:01:24 --> Language Class Initialized
INFO - 2025-01-31 06:01:24 --> Loader Class Initialized
INFO - 2025-01-31 06:01:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:01:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:01:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:01:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:01:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:01:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:01:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:01:24 --> Upload Class Initialized
INFO - 2025-01-31 06:01:24 --> Email Class Initialized
INFO - 2025-01-31 06:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:01:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:01:24 --> Controller Class Initialized
INFO - 2025-01-31 11:31:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:31:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:31:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:02:24 --> Config Class Initialized
INFO - 2025-01-31 06:02:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:02:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:02:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:02:24 --> URI Class Initialized
INFO - 2025-01-31 06:02:24 --> Router Class Initialized
INFO - 2025-01-31 06:02:24 --> Output Class Initialized
INFO - 2025-01-31 06:02:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:02:24 --> Input Class Initialized
INFO - 2025-01-31 06:02:24 --> Language Class Initialized
INFO - 2025-01-31 06:02:24 --> Loader Class Initialized
INFO - 2025-01-31 06:02:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:02:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:02:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:02:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:02:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:02:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:02:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:02:24 --> Upload Class Initialized
INFO - 2025-01-31 06:02:24 --> Email Class Initialized
INFO - 2025-01-31 06:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:02:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:02:24 --> Controller Class Initialized
INFO - 2025-01-31 11:32:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:32:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:32:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:03:24 --> Config Class Initialized
INFO - 2025-01-31 06:03:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:03:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:03:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:03:24 --> URI Class Initialized
INFO - 2025-01-31 06:03:24 --> Router Class Initialized
INFO - 2025-01-31 06:03:24 --> Output Class Initialized
INFO - 2025-01-31 06:03:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:03:24 --> Input Class Initialized
INFO - 2025-01-31 06:03:24 --> Language Class Initialized
INFO - 2025-01-31 06:03:24 --> Loader Class Initialized
INFO - 2025-01-31 06:03:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:03:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:03:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:03:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:03:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:03:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:03:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:03:24 --> Upload Class Initialized
INFO - 2025-01-31 06:03:24 --> Email Class Initialized
INFO - 2025-01-31 06:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:03:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:03:24 --> Controller Class Initialized
INFO - 2025-01-31 11:33:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:33:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:33:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:04:24 --> Config Class Initialized
INFO - 2025-01-31 06:04:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:04:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:04:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:04:24 --> URI Class Initialized
INFO - 2025-01-31 06:04:24 --> Router Class Initialized
INFO - 2025-01-31 06:04:24 --> Output Class Initialized
INFO - 2025-01-31 06:04:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:04:24 --> Input Class Initialized
INFO - 2025-01-31 06:04:24 --> Language Class Initialized
INFO - 2025-01-31 06:04:24 --> Loader Class Initialized
INFO - 2025-01-31 06:04:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:04:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:04:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:04:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:04:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:04:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:04:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:04:24 --> Upload Class Initialized
INFO - 2025-01-31 06:04:24 --> Email Class Initialized
INFO - 2025-01-31 06:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:04:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:04:24 --> Controller Class Initialized
INFO - 2025-01-31 11:34:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:34:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:34:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:05:24 --> Config Class Initialized
INFO - 2025-01-31 06:05:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:05:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:05:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:05:24 --> URI Class Initialized
INFO - 2025-01-31 06:05:24 --> Router Class Initialized
INFO - 2025-01-31 06:05:24 --> Output Class Initialized
INFO - 2025-01-31 06:05:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:05:24 --> Input Class Initialized
INFO - 2025-01-31 06:05:24 --> Language Class Initialized
INFO - 2025-01-31 06:05:24 --> Loader Class Initialized
INFO - 2025-01-31 06:05:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:05:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:05:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:05:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:05:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:05:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:05:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:05:24 --> Upload Class Initialized
INFO - 2025-01-31 06:05:24 --> Email Class Initialized
INFO - 2025-01-31 06:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:05:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:05:24 --> Controller Class Initialized
INFO - 2025-01-31 11:35:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:35:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:35:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:06:24 --> Config Class Initialized
INFO - 2025-01-31 06:06:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:06:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:06:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:06:24 --> URI Class Initialized
INFO - 2025-01-31 06:06:24 --> Router Class Initialized
INFO - 2025-01-31 06:06:24 --> Output Class Initialized
INFO - 2025-01-31 06:06:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:06:24 --> Input Class Initialized
INFO - 2025-01-31 06:06:24 --> Language Class Initialized
INFO - 2025-01-31 06:06:24 --> Loader Class Initialized
INFO - 2025-01-31 06:06:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:06:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:06:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:06:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:06:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:06:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:06:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:06:24 --> Upload Class Initialized
INFO - 2025-01-31 06:06:24 --> Email Class Initialized
INFO - 2025-01-31 06:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:06:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:06:24 --> Controller Class Initialized
INFO - 2025-01-31 11:36:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:36:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:36:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:07:24 --> Config Class Initialized
INFO - 2025-01-31 06:07:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:07:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:07:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:07:24 --> URI Class Initialized
INFO - 2025-01-31 06:07:24 --> Router Class Initialized
INFO - 2025-01-31 06:07:24 --> Output Class Initialized
INFO - 2025-01-31 06:07:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:07:24 --> Input Class Initialized
INFO - 2025-01-31 06:07:24 --> Language Class Initialized
INFO - 2025-01-31 06:07:24 --> Loader Class Initialized
INFO - 2025-01-31 06:07:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:07:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:07:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:07:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:07:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:07:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:07:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:07:24 --> Upload Class Initialized
INFO - 2025-01-31 06:07:24 --> Email Class Initialized
INFO - 2025-01-31 06:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:07:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:07:24 --> Controller Class Initialized
INFO - 2025-01-31 11:37:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:37:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:37:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:08:24 --> Config Class Initialized
INFO - 2025-01-31 06:08:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:08:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:08:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:08:24 --> URI Class Initialized
INFO - 2025-01-31 06:08:24 --> Router Class Initialized
INFO - 2025-01-31 06:08:24 --> Output Class Initialized
INFO - 2025-01-31 06:08:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:08:24 --> Input Class Initialized
INFO - 2025-01-31 06:08:24 --> Language Class Initialized
INFO - 2025-01-31 06:08:24 --> Loader Class Initialized
INFO - 2025-01-31 06:08:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:08:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:08:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:08:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:08:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:08:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:08:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:08:24 --> Upload Class Initialized
INFO - 2025-01-31 06:08:24 --> Email Class Initialized
INFO - 2025-01-31 06:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:08:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:08:24 --> Controller Class Initialized
INFO - 2025-01-31 11:38:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:38:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:38:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:09:24 --> Config Class Initialized
INFO - 2025-01-31 06:09:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:09:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:09:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:09:24 --> URI Class Initialized
INFO - 2025-01-31 06:09:24 --> Router Class Initialized
INFO - 2025-01-31 06:09:24 --> Output Class Initialized
INFO - 2025-01-31 06:09:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:09:24 --> Input Class Initialized
INFO - 2025-01-31 06:09:24 --> Language Class Initialized
INFO - 2025-01-31 06:09:24 --> Loader Class Initialized
INFO - 2025-01-31 06:09:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:09:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:09:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:09:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:09:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:09:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:09:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:09:24 --> Upload Class Initialized
INFO - 2025-01-31 06:09:24 --> Email Class Initialized
INFO - 2025-01-31 06:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:09:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:09:24 --> Controller Class Initialized
INFO - 2025-01-31 11:39:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:39:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:39:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:10:24 --> Config Class Initialized
INFO - 2025-01-31 06:10:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:10:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:10:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:10:24 --> URI Class Initialized
INFO - 2025-01-31 06:10:24 --> Router Class Initialized
INFO - 2025-01-31 06:10:24 --> Output Class Initialized
INFO - 2025-01-31 06:10:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:10:24 --> Input Class Initialized
INFO - 2025-01-31 06:10:24 --> Language Class Initialized
INFO - 2025-01-31 06:10:24 --> Loader Class Initialized
INFO - 2025-01-31 06:10:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:10:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:10:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:10:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:10:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:10:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:10:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:10:24 --> Upload Class Initialized
INFO - 2025-01-31 06:10:24 --> Email Class Initialized
INFO - 2025-01-31 06:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:10:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:10:24 --> Controller Class Initialized
INFO - 2025-01-31 11:40:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:40:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:40:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:11:24 --> Config Class Initialized
INFO - 2025-01-31 06:11:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:11:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:11:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:11:24 --> URI Class Initialized
INFO - 2025-01-31 06:11:24 --> Router Class Initialized
INFO - 2025-01-31 06:11:24 --> Output Class Initialized
INFO - 2025-01-31 06:11:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:11:24 --> Input Class Initialized
INFO - 2025-01-31 06:11:24 --> Language Class Initialized
INFO - 2025-01-31 06:11:24 --> Loader Class Initialized
INFO - 2025-01-31 06:11:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:11:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:11:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:11:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:11:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:11:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:11:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:11:24 --> Upload Class Initialized
INFO - 2025-01-31 06:11:24 --> Email Class Initialized
INFO - 2025-01-31 06:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:11:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:11:24 --> Controller Class Initialized
INFO - 2025-01-31 11:41:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:41:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:41:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:12:24 --> Config Class Initialized
INFO - 2025-01-31 06:12:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:12:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:12:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:12:24 --> URI Class Initialized
INFO - 2025-01-31 06:12:24 --> Router Class Initialized
INFO - 2025-01-31 06:12:24 --> Output Class Initialized
INFO - 2025-01-31 06:12:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:12:24 --> Input Class Initialized
INFO - 2025-01-31 06:12:24 --> Language Class Initialized
INFO - 2025-01-31 06:12:24 --> Loader Class Initialized
INFO - 2025-01-31 06:12:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:12:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:12:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:12:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:12:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:12:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:12:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:12:24 --> Upload Class Initialized
INFO - 2025-01-31 06:12:24 --> Email Class Initialized
INFO - 2025-01-31 06:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:12:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:12:24 --> Controller Class Initialized
INFO - 2025-01-31 11:42:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:42:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:42:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:13:24 --> Config Class Initialized
INFO - 2025-01-31 06:13:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:13:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:13:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:13:24 --> URI Class Initialized
INFO - 2025-01-31 06:13:24 --> Router Class Initialized
INFO - 2025-01-31 06:13:24 --> Output Class Initialized
INFO - 2025-01-31 06:13:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:13:24 --> Input Class Initialized
INFO - 2025-01-31 06:13:24 --> Language Class Initialized
INFO - 2025-01-31 06:13:24 --> Loader Class Initialized
INFO - 2025-01-31 06:13:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:13:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:13:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:13:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:13:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:13:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:13:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:13:24 --> Upload Class Initialized
INFO - 2025-01-31 06:13:24 --> Email Class Initialized
INFO - 2025-01-31 06:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:13:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:13:24 --> Controller Class Initialized
INFO - 2025-01-31 11:43:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:43:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:43:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:14:24 --> Config Class Initialized
INFO - 2025-01-31 06:14:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:14:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:14:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:14:24 --> URI Class Initialized
INFO - 2025-01-31 06:14:24 --> Router Class Initialized
INFO - 2025-01-31 06:14:24 --> Output Class Initialized
INFO - 2025-01-31 06:14:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:14:24 --> Input Class Initialized
INFO - 2025-01-31 06:14:24 --> Language Class Initialized
INFO - 2025-01-31 06:14:24 --> Loader Class Initialized
INFO - 2025-01-31 06:14:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:14:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:14:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:14:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:14:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:14:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:14:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:14:24 --> Upload Class Initialized
INFO - 2025-01-31 06:14:24 --> Email Class Initialized
INFO - 2025-01-31 06:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:14:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:14:24 --> Controller Class Initialized
INFO - 2025-01-31 11:44:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:44:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:44:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:15:24 --> Config Class Initialized
INFO - 2025-01-31 06:15:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:15:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:15:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:15:24 --> URI Class Initialized
INFO - 2025-01-31 06:15:24 --> Router Class Initialized
INFO - 2025-01-31 06:15:24 --> Output Class Initialized
INFO - 2025-01-31 06:15:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:15:24 --> Input Class Initialized
INFO - 2025-01-31 06:15:24 --> Language Class Initialized
INFO - 2025-01-31 06:15:24 --> Loader Class Initialized
INFO - 2025-01-31 06:15:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:15:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:15:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:15:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:15:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:15:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:15:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:15:24 --> Upload Class Initialized
INFO - 2025-01-31 06:15:24 --> Email Class Initialized
INFO - 2025-01-31 06:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:15:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:15:24 --> Controller Class Initialized
INFO - 2025-01-31 11:45:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:45:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:45:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:16:24 --> Config Class Initialized
INFO - 2025-01-31 06:16:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:16:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:16:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:16:24 --> URI Class Initialized
INFO - 2025-01-31 06:16:24 --> Router Class Initialized
INFO - 2025-01-31 06:16:24 --> Output Class Initialized
INFO - 2025-01-31 06:16:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:16:24 --> Input Class Initialized
INFO - 2025-01-31 06:16:24 --> Language Class Initialized
INFO - 2025-01-31 06:16:24 --> Loader Class Initialized
INFO - 2025-01-31 06:16:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:16:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:16:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:16:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:16:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:16:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:16:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:16:24 --> Upload Class Initialized
INFO - 2025-01-31 06:16:24 --> Email Class Initialized
INFO - 2025-01-31 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:16:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:16:24 --> Controller Class Initialized
INFO - 2025-01-31 11:46:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:46:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:46:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:17:24 --> Config Class Initialized
INFO - 2025-01-31 06:17:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:17:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:17:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:17:24 --> URI Class Initialized
INFO - 2025-01-31 06:17:24 --> Router Class Initialized
INFO - 2025-01-31 06:17:24 --> Output Class Initialized
INFO - 2025-01-31 06:17:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:17:24 --> Input Class Initialized
INFO - 2025-01-31 06:17:24 --> Language Class Initialized
INFO - 2025-01-31 06:17:24 --> Loader Class Initialized
INFO - 2025-01-31 06:17:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:17:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:17:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:17:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:17:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:17:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:17:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:17:24 --> Upload Class Initialized
INFO - 2025-01-31 06:17:24 --> Email Class Initialized
INFO - 2025-01-31 06:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:17:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:17:24 --> Controller Class Initialized
INFO - 2025-01-31 11:47:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 11:47:24 --> Model "MainModel" initialized
INFO - 2025-01-31 11:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 11:47:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:30:10 --> Config Class Initialized
INFO - 2025-01-31 06:30:10 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:30:10 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:30:10 --> Utf8 Class Initialized
INFO - 2025-01-31 06:30:10 --> URI Class Initialized
INFO - 2025-01-31 06:30:10 --> Router Class Initialized
INFO - 2025-01-31 06:30:10 --> Output Class Initialized
INFO - 2025-01-31 06:30:10 --> Security Class Initialized
DEBUG - 2025-01-31 06:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:30:10 --> Input Class Initialized
INFO - 2025-01-31 06:30:10 --> Language Class Initialized
INFO - 2025-01-31 06:30:10 --> Loader Class Initialized
INFO - 2025-01-31 06:30:10 --> Helper loaded: url_helper
INFO - 2025-01-31 06:30:10 --> Helper loaded: html_helper
INFO - 2025-01-31 06:30:10 --> Helper loaded: file_helper
INFO - 2025-01-31 06:30:10 --> Helper loaded: string_helper
INFO - 2025-01-31 06:30:10 --> Helper loaded: form_helper
INFO - 2025-01-31 06:30:10 --> Helper loaded: my_helper
INFO - 2025-01-31 06:30:10 --> Database Driver Class Initialized
INFO - 2025-01-31 06:30:10 --> Upload Class Initialized
INFO - 2025-01-31 06:30:10 --> Email Class Initialized
INFO - 2025-01-31 06:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:30:10 --> Form Validation Class Initialized
INFO - 2025-01-31 06:30:10 --> Controller Class Initialized
INFO - 2025-01-31 12:00:10 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:00:10 --> Model "MainModel" initialized
INFO - 2025-01-31 12:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:00:10 --> Pagination Class Initialized
INFO - 2025-01-31 06:30:24 --> Config Class Initialized
INFO - 2025-01-31 06:30:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:30:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:30:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:30:24 --> URI Class Initialized
INFO - 2025-01-31 06:30:24 --> Router Class Initialized
INFO - 2025-01-31 06:30:24 --> Output Class Initialized
INFO - 2025-01-31 06:30:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:30:24 --> Input Class Initialized
INFO - 2025-01-31 06:30:24 --> Language Class Initialized
INFO - 2025-01-31 06:30:24 --> Loader Class Initialized
INFO - 2025-01-31 06:30:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:30:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:30:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:30:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:30:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:30:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:30:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:30:24 --> Upload Class Initialized
INFO - 2025-01-31 06:30:24 --> Email Class Initialized
INFO - 2025-01-31 06:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:30:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:30:24 --> Controller Class Initialized
INFO - 2025-01-31 12:00:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:00:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:00:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:31:24 --> Config Class Initialized
INFO - 2025-01-31 06:31:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:31:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:31:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:31:24 --> URI Class Initialized
INFO - 2025-01-31 06:31:24 --> Router Class Initialized
INFO - 2025-01-31 06:31:24 --> Output Class Initialized
INFO - 2025-01-31 06:31:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:31:24 --> Input Class Initialized
INFO - 2025-01-31 06:31:24 --> Language Class Initialized
INFO - 2025-01-31 06:31:24 --> Loader Class Initialized
INFO - 2025-01-31 06:31:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:31:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:31:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:31:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:31:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:31:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:31:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:31:24 --> Upload Class Initialized
INFO - 2025-01-31 06:31:24 --> Email Class Initialized
INFO - 2025-01-31 06:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:31:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:31:24 --> Controller Class Initialized
INFO - 2025-01-31 12:01:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:01:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:01:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:32:24 --> Config Class Initialized
INFO - 2025-01-31 06:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:32:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:32:24 --> URI Class Initialized
INFO - 2025-01-31 06:32:24 --> Router Class Initialized
INFO - 2025-01-31 06:32:24 --> Output Class Initialized
INFO - 2025-01-31 06:32:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:32:24 --> Input Class Initialized
INFO - 2025-01-31 06:32:24 --> Language Class Initialized
INFO - 2025-01-31 06:32:24 --> Loader Class Initialized
INFO - 2025-01-31 06:32:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:32:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:32:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:32:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:32:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:32:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:32:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:32:24 --> Upload Class Initialized
INFO - 2025-01-31 06:32:24 --> Email Class Initialized
INFO - 2025-01-31 06:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:32:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:32:24 --> Controller Class Initialized
INFO - 2025-01-31 12:02:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:02:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:02:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:33:24 --> Config Class Initialized
INFO - 2025-01-31 06:33:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:33:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:33:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:33:24 --> URI Class Initialized
INFO - 2025-01-31 06:33:24 --> Router Class Initialized
INFO - 2025-01-31 06:33:24 --> Output Class Initialized
INFO - 2025-01-31 06:33:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:33:24 --> Input Class Initialized
INFO - 2025-01-31 06:33:24 --> Language Class Initialized
INFO - 2025-01-31 06:33:24 --> Loader Class Initialized
INFO - 2025-01-31 06:33:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:33:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:33:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:33:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:33:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:33:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:33:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:33:24 --> Upload Class Initialized
INFO - 2025-01-31 06:33:24 --> Email Class Initialized
INFO - 2025-01-31 06:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:33:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:33:24 --> Controller Class Initialized
INFO - 2025-01-31 12:03:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:03:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:03:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:34:24 --> Config Class Initialized
INFO - 2025-01-31 06:34:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:34:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:34:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:34:24 --> URI Class Initialized
INFO - 2025-01-31 06:34:24 --> Router Class Initialized
INFO - 2025-01-31 06:34:24 --> Output Class Initialized
INFO - 2025-01-31 06:34:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:34:24 --> Input Class Initialized
INFO - 2025-01-31 06:34:24 --> Language Class Initialized
INFO - 2025-01-31 06:34:24 --> Loader Class Initialized
INFO - 2025-01-31 06:34:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:34:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:34:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:34:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:34:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:34:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:34:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:34:24 --> Upload Class Initialized
INFO - 2025-01-31 06:34:24 --> Email Class Initialized
INFO - 2025-01-31 06:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:34:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:34:24 --> Controller Class Initialized
INFO - 2025-01-31 12:04:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:04:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:04:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:35:24 --> Config Class Initialized
INFO - 2025-01-31 06:35:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:35:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:35:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:35:24 --> URI Class Initialized
INFO - 2025-01-31 06:35:24 --> Router Class Initialized
INFO - 2025-01-31 06:35:24 --> Output Class Initialized
INFO - 2025-01-31 06:35:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:35:24 --> Input Class Initialized
INFO - 2025-01-31 06:35:24 --> Language Class Initialized
INFO - 2025-01-31 06:35:24 --> Loader Class Initialized
INFO - 2025-01-31 06:35:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:35:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:35:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:35:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:35:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:35:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:35:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:35:24 --> Upload Class Initialized
INFO - 2025-01-31 06:35:24 --> Email Class Initialized
INFO - 2025-01-31 06:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:35:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:35:24 --> Controller Class Initialized
INFO - 2025-01-31 12:05:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:05:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:05:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:36:24 --> Config Class Initialized
INFO - 2025-01-31 06:36:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:36:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:36:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:36:24 --> URI Class Initialized
INFO - 2025-01-31 06:36:24 --> Router Class Initialized
INFO - 2025-01-31 06:36:24 --> Output Class Initialized
INFO - 2025-01-31 06:36:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:36:24 --> Input Class Initialized
INFO - 2025-01-31 06:36:24 --> Language Class Initialized
INFO - 2025-01-31 06:36:24 --> Loader Class Initialized
INFO - 2025-01-31 06:36:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:36:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:36:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:36:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:36:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:36:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:36:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:36:24 --> Upload Class Initialized
INFO - 2025-01-31 06:36:24 --> Email Class Initialized
INFO - 2025-01-31 06:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:36:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:36:24 --> Controller Class Initialized
INFO - 2025-01-31 12:06:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:06:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:06:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:37:24 --> Config Class Initialized
INFO - 2025-01-31 06:37:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:37:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:37:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:37:24 --> URI Class Initialized
INFO - 2025-01-31 06:37:24 --> Router Class Initialized
INFO - 2025-01-31 06:37:24 --> Output Class Initialized
INFO - 2025-01-31 06:37:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:37:24 --> Input Class Initialized
INFO - 2025-01-31 06:37:24 --> Language Class Initialized
INFO - 2025-01-31 06:37:24 --> Loader Class Initialized
INFO - 2025-01-31 06:37:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:37:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:37:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:37:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:37:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:37:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:37:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:37:24 --> Upload Class Initialized
INFO - 2025-01-31 06:37:24 --> Email Class Initialized
INFO - 2025-01-31 06:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:37:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:37:24 --> Controller Class Initialized
INFO - 2025-01-31 12:07:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:07:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:07:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:38:24 --> Config Class Initialized
INFO - 2025-01-31 06:38:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:38:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:38:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:38:24 --> URI Class Initialized
INFO - 2025-01-31 06:38:24 --> Router Class Initialized
INFO - 2025-01-31 06:38:24 --> Output Class Initialized
INFO - 2025-01-31 06:38:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:38:24 --> Input Class Initialized
INFO - 2025-01-31 06:38:24 --> Language Class Initialized
INFO - 2025-01-31 06:38:24 --> Loader Class Initialized
INFO - 2025-01-31 06:38:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:38:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:38:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:38:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:38:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:38:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:38:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:38:24 --> Upload Class Initialized
INFO - 2025-01-31 06:38:24 --> Email Class Initialized
INFO - 2025-01-31 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:38:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:38:24 --> Controller Class Initialized
INFO - 2025-01-31 12:08:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:08:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:08:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:39:24 --> Config Class Initialized
INFO - 2025-01-31 06:39:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:39:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:39:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:39:24 --> URI Class Initialized
INFO - 2025-01-31 06:39:24 --> Router Class Initialized
INFO - 2025-01-31 06:39:24 --> Output Class Initialized
INFO - 2025-01-31 06:39:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:39:24 --> Input Class Initialized
INFO - 2025-01-31 06:39:24 --> Language Class Initialized
INFO - 2025-01-31 06:39:24 --> Loader Class Initialized
INFO - 2025-01-31 06:39:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:39:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:39:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:39:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:39:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:39:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:39:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:39:24 --> Upload Class Initialized
INFO - 2025-01-31 06:39:24 --> Email Class Initialized
INFO - 2025-01-31 06:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:39:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:39:24 --> Controller Class Initialized
INFO - 2025-01-31 12:09:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:09:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:09:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:40:24 --> Config Class Initialized
INFO - 2025-01-31 06:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:40:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:40:24 --> URI Class Initialized
INFO - 2025-01-31 06:40:24 --> Router Class Initialized
INFO - 2025-01-31 06:40:24 --> Output Class Initialized
INFO - 2025-01-31 06:40:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:40:24 --> Input Class Initialized
INFO - 2025-01-31 06:40:24 --> Language Class Initialized
INFO - 2025-01-31 06:40:24 --> Loader Class Initialized
INFO - 2025-01-31 06:40:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:40:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:40:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:40:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:40:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:40:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:40:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:40:24 --> Upload Class Initialized
INFO - 2025-01-31 06:40:24 --> Email Class Initialized
INFO - 2025-01-31 06:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:40:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:40:24 --> Controller Class Initialized
INFO - 2025-01-31 12:10:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:10:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:10:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:41:24 --> Config Class Initialized
INFO - 2025-01-31 06:41:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:41:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:41:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:41:24 --> URI Class Initialized
INFO - 2025-01-31 06:41:24 --> Router Class Initialized
INFO - 2025-01-31 06:41:24 --> Output Class Initialized
INFO - 2025-01-31 06:41:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:41:24 --> Input Class Initialized
INFO - 2025-01-31 06:41:24 --> Language Class Initialized
INFO - 2025-01-31 06:41:24 --> Loader Class Initialized
INFO - 2025-01-31 06:41:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:41:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:41:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:41:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:41:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:41:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:41:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:41:24 --> Upload Class Initialized
INFO - 2025-01-31 06:41:24 --> Email Class Initialized
INFO - 2025-01-31 06:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:41:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:41:24 --> Controller Class Initialized
INFO - 2025-01-31 12:11:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:11:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:11:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:42:24 --> Config Class Initialized
INFO - 2025-01-31 06:42:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:42:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:42:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:42:24 --> URI Class Initialized
INFO - 2025-01-31 06:42:24 --> Router Class Initialized
INFO - 2025-01-31 06:42:24 --> Output Class Initialized
INFO - 2025-01-31 06:42:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:42:24 --> Input Class Initialized
INFO - 2025-01-31 06:42:24 --> Language Class Initialized
INFO - 2025-01-31 06:42:24 --> Loader Class Initialized
INFO - 2025-01-31 06:42:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:42:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:42:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:42:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:42:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:42:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:42:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:42:24 --> Upload Class Initialized
INFO - 2025-01-31 06:42:24 --> Email Class Initialized
INFO - 2025-01-31 06:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:42:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:42:24 --> Controller Class Initialized
INFO - 2025-01-31 12:12:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:12:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:12:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:43:24 --> Config Class Initialized
INFO - 2025-01-31 06:43:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:43:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:43:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:43:24 --> URI Class Initialized
INFO - 2025-01-31 06:43:24 --> Router Class Initialized
INFO - 2025-01-31 06:43:24 --> Output Class Initialized
INFO - 2025-01-31 06:43:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:43:24 --> Input Class Initialized
INFO - 2025-01-31 06:43:24 --> Language Class Initialized
INFO - 2025-01-31 06:43:24 --> Loader Class Initialized
INFO - 2025-01-31 06:43:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:43:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:43:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:43:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:43:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:43:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:43:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:43:24 --> Upload Class Initialized
INFO - 2025-01-31 06:43:24 --> Email Class Initialized
INFO - 2025-01-31 06:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:43:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:43:24 --> Controller Class Initialized
INFO - 2025-01-31 12:13:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:13:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:13:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:44:24 --> Config Class Initialized
INFO - 2025-01-31 06:44:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:44:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:44:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:44:24 --> URI Class Initialized
INFO - 2025-01-31 06:44:24 --> Router Class Initialized
INFO - 2025-01-31 06:44:24 --> Output Class Initialized
INFO - 2025-01-31 06:44:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:44:24 --> Input Class Initialized
INFO - 2025-01-31 06:44:24 --> Language Class Initialized
INFO - 2025-01-31 06:44:24 --> Loader Class Initialized
INFO - 2025-01-31 06:44:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:44:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:44:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:44:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:44:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:44:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:44:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:44:24 --> Upload Class Initialized
INFO - 2025-01-31 06:44:24 --> Email Class Initialized
INFO - 2025-01-31 06:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:44:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:44:24 --> Controller Class Initialized
INFO - 2025-01-31 12:14:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:14:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:14:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:45:24 --> Config Class Initialized
INFO - 2025-01-31 06:45:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:45:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:45:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:45:24 --> URI Class Initialized
INFO - 2025-01-31 06:45:24 --> Router Class Initialized
INFO - 2025-01-31 06:45:24 --> Output Class Initialized
INFO - 2025-01-31 06:45:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:45:24 --> Input Class Initialized
INFO - 2025-01-31 06:45:24 --> Language Class Initialized
INFO - 2025-01-31 06:45:24 --> Loader Class Initialized
INFO - 2025-01-31 06:45:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:45:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:45:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:45:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:45:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:45:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:45:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:45:24 --> Upload Class Initialized
INFO - 2025-01-31 06:45:24 --> Email Class Initialized
INFO - 2025-01-31 06:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:45:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:45:24 --> Controller Class Initialized
INFO - 2025-01-31 12:15:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:15:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:15:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:46:24 --> Config Class Initialized
INFO - 2025-01-31 06:46:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:46:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:46:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:46:24 --> URI Class Initialized
INFO - 2025-01-31 06:46:24 --> Router Class Initialized
INFO - 2025-01-31 06:46:24 --> Output Class Initialized
INFO - 2025-01-31 06:46:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:46:24 --> Input Class Initialized
INFO - 2025-01-31 06:46:24 --> Language Class Initialized
INFO - 2025-01-31 06:46:24 --> Loader Class Initialized
INFO - 2025-01-31 06:46:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:46:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:46:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:46:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:46:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:46:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:46:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:46:24 --> Upload Class Initialized
INFO - 2025-01-31 06:46:24 --> Email Class Initialized
INFO - 2025-01-31 06:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:46:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:46:24 --> Controller Class Initialized
INFO - 2025-01-31 12:16:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:16:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:16:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:47:24 --> Config Class Initialized
INFO - 2025-01-31 06:47:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:47:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:47:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:47:24 --> URI Class Initialized
INFO - 2025-01-31 06:47:24 --> Router Class Initialized
INFO - 2025-01-31 06:47:24 --> Output Class Initialized
INFO - 2025-01-31 06:47:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:47:24 --> Input Class Initialized
INFO - 2025-01-31 06:47:24 --> Language Class Initialized
INFO - 2025-01-31 06:47:24 --> Loader Class Initialized
INFO - 2025-01-31 06:47:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:47:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:47:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:47:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:47:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:47:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:47:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:47:24 --> Upload Class Initialized
INFO - 2025-01-31 06:47:24 --> Email Class Initialized
INFO - 2025-01-31 06:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:47:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:47:24 --> Controller Class Initialized
INFO - 2025-01-31 12:17:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:17:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:17:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:48:24 --> Config Class Initialized
INFO - 2025-01-31 06:48:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:48:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:48:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:48:24 --> URI Class Initialized
INFO - 2025-01-31 06:48:24 --> Router Class Initialized
INFO - 2025-01-31 06:48:24 --> Output Class Initialized
INFO - 2025-01-31 06:48:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:48:24 --> Input Class Initialized
INFO - 2025-01-31 06:48:24 --> Language Class Initialized
INFO - 2025-01-31 06:48:24 --> Loader Class Initialized
INFO - 2025-01-31 06:48:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:48:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:48:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:48:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:48:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:48:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:48:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:48:24 --> Upload Class Initialized
INFO - 2025-01-31 06:48:24 --> Email Class Initialized
INFO - 2025-01-31 06:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:48:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:48:24 --> Controller Class Initialized
INFO - 2025-01-31 12:18:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:18:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:18:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:49:24 --> Config Class Initialized
INFO - 2025-01-31 06:49:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:49:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:49:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:49:24 --> URI Class Initialized
INFO - 2025-01-31 06:49:24 --> Router Class Initialized
INFO - 2025-01-31 06:49:24 --> Output Class Initialized
INFO - 2025-01-31 06:49:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:49:24 --> Input Class Initialized
INFO - 2025-01-31 06:49:24 --> Language Class Initialized
INFO - 2025-01-31 06:49:24 --> Loader Class Initialized
INFO - 2025-01-31 06:49:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:49:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:49:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:49:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:49:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:49:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:49:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:49:24 --> Upload Class Initialized
INFO - 2025-01-31 06:49:24 --> Email Class Initialized
INFO - 2025-01-31 06:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:49:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:49:24 --> Controller Class Initialized
INFO - 2025-01-31 12:19:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:19:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:19:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:50:24 --> Config Class Initialized
INFO - 2025-01-31 06:50:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:50:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:50:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:50:24 --> URI Class Initialized
INFO - 2025-01-31 06:50:24 --> Router Class Initialized
INFO - 2025-01-31 06:50:24 --> Output Class Initialized
INFO - 2025-01-31 06:50:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:50:24 --> Input Class Initialized
INFO - 2025-01-31 06:50:24 --> Language Class Initialized
INFO - 2025-01-31 06:50:24 --> Loader Class Initialized
INFO - 2025-01-31 06:50:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:50:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:50:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:50:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:50:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:50:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:50:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:50:24 --> Upload Class Initialized
INFO - 2025-01-31 06:50:24 --> Email Class Initialized
INFO - 2025-01-31 06:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:50:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:50:24 --> Controller Class Initialized
INFO - 2025-01-31 12:20:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:20:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:20:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:51:24 --> Config Class Initialized
INFO - 2025-01-31 06:51:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:51:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:51:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:51:24 --> URI Class Initialized
INFO - 2025-01-31 06:51:24 --> Router Class Initialized
INFO - 2025-01-31 06:51:24 --> Output Class Initialized
INFO - 2025-01-31 06:51:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:51:24 --> Input Class Initialized
INFO - 2025-01-31 06:51:24 --> Language Class Initialized
INFO - 2025-01-31 06:51:24 --> Loader Class Initialized
INFO - 2025-01-31 06:51:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:51:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:51:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:51:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:51:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:51:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:51:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:51:24 --> Upload Class Initialized
INFO - 2025-01-31 06:51:24 --> Email Class Initialized
INFO - 2025-01-31 06:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:51:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:51:24 --> Controller Class Initialized
INFO - 2025-01-31 12:21:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:21:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:21:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:52:24 --> Config Class Initialized
INFO - 2025-01-31 06:52:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:52:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:52:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:52:24 --> URI Class Initialized
INFO - 2025-01-31 06:52:24 --> Router Class Initialized
INFO - 2025-01-31 06:52:24 --> Output Class Initialized
INFO - 2025-01-31 06:52:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:52:24 --> Input Class Initialized
INFO - 2025-01-31 06:52:24 --> Language Class Initialized
INFO - 2025-01-31 06:52:24 --> Loader Class Initialized
INFO - 2025-01-31 06:52:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:52:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:52:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:52:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:52:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:52:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:52:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:52:24 --> Upload Class Initialized
INFO - 2025-01-31 06:52:24 --> Email Class Initialized
INFO - 2025-01-31 06:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:52:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:52:24 --> Controller Class Initialized
INFO - 2025-01-31 12:22:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:22:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:22:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:53:24 --> Config Class Initialized
INFO - 2025-01-31 06:53:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:53:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:53:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:53:24 --> URI Class Initialized
INFO - 2025-01-31 06:53:24 --> Router Class Initialized
INFO - 2025-01-31 06:53:24 --> Output Class Initialized
INFO - 2025-01-31 06:53:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:53:24 --> Input Class Initialized
INFO - 2025-01-31 06:53:24 --> Language Class Initialized
INFO - 2025-01-31 06:53:24 --> Loader Class Initialized
INFO - 2025-01-31 06:53:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:53:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:53:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:53:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:53:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:53:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:53:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:53:24 --> Upload Class Initialized
INFO - 2025-01-31 06:53:24 --> Email Class Initialized
INFO - 2025-01-31 06:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:53:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:53:24 --> Controller Class Initialized
INFO - 2025-01-31 12:23:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:23:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:23:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:54:44 --> Config Class Initialized
INFO - 2025-01-31 06:54:44 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:54:44 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:54:44 --> Utf8 Class Initialized
INFO - 2025-01-31 06:54:44 --> URI Class Initialized
INFO - 2025-01-31 06:54:44 --> Router Class Initialized
INFO - 2025-01-31 06:54:44 --> Output Class Initialized
INFO - 2025-01-31 06:54:44 --> Security Class Initialized
DEBUG - 2025-01-31 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:54:44 --> Input Class Initialized
INFO - 2025-01-31 06:54:44 --> Language Class Initialized
INFO - 2025-01-31 06:54:44 --> Loader Class Initialized
INFO - 2025-01-31 06:54:44 --> Helper loaded: url_helper
INFO - 2025-01-31 06:54:44 --> Helper loaded: html_helper
INFO - 2025-01-31 06:54:44 --> Helper loaded: file_helper
INFO - 2025-01-31 06:54:44 --> Helper loaded: string_helper
INFO - 2025-01-31 06:54:44 --> Helper loaded: form_helper
INFO - 2025-01-31 06:54:44 --> Helper loaded: my_helper
INFO - 2025-01-31 06:54:44 --> Database Driver Class Initialized
INFO - 2025-01-31 06:54:44 --> Upload Class Initialized
INFO - 2025-01-31 06:54:44 --> Email Class Initialized
INFO - 2025-01-31 06:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:54:44 --> Form Validation Class Initialized
INFO - 2025-01-31 06:54:44 --> Controller Class Initialized
INFO - 2025-01-31 12:24:44 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:24:44 --> Model "MainModel" initialized
INFO - 2025-01-31 12:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:24:44 --> Pagination Class Initialized
INFO - 2025-01-31 06:55:24 --> Config Class Initialized
INFO - 2025-01-31 06:55:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:55:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:55:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:55:24 --> URI Class Initialized
INFO - 2025-01-31 06:55:24 --> Router Class Initialized
INFO - 2025-01-31 06:55:24 --> Output Class Initialized
INFO - 2025-01-31 06:55:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:55:24 --> Input Class Initialized
INFO - 2025-01-31 06:55:24 --> Language Class Initialized
INFO - 2025-01-31 06:55:24 --> Loader Class Initialized
INFO - 2025-01-31 06:55:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:55:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:55:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:55:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:55:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:55:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:55:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:55:24 --> Upload Class Initialized
INFO - 2025-01-31 06:55:24 --> Email Class Initialized
INFO - 2025-01-31 06:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:55:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:55:24 --> Controller Class Initialized
INFO - 2025-01-31 12:25:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:25:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:25:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:56:24 --> Config Class Initialized
INFO - 2025-01-31 06:56:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:56:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:56:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:56:24 --> URI Class Initialized
INFO - 2025-01-31 06:56:24 --> Router Class Initialized
INFO - 2025-01-31 06:56:24 --> Output Class Initialized
INFO - 2025-01-31 06:56:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:56:24 --> Input Class Initialized
INFO - 2025-01-31 06:56:24 --> Language Class Initialized
INFO - 2025-01-31 06:56:24 --> Loader Class Initialized
INFO - 2025-01-31 06:56:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:56:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:56:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:56:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:56:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:56:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:56:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:56:24 --> Upload Class Initialized
INFO - 2025-01-31 06:56:24 --> Email Class Initialized
INFO - 2025-01-31 06:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:56:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:56:24 --> Controller Class Initialized
INFO - 2025-01-31 12:26:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:26:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:26:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:57:24 --> Config Class Initialized
INFO - 2025-01-31 06:57:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:57:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:57:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:57:24 --> URI Class Initialized
INFO - 2025-01-31 06:57:24 --> Router Class Initialized
INFO - 2025-01-31 06:57:24 --> Output Class Initialized
INFO - 2025-01-31 06:57:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:57:24 --> Input Class Initialized
INFO - 2025-01-31 06:57:24 --> Language Class Initialized
INFO - 2025-01-31 06:57:24 --> Loader Class Initialized
INFO - 2025-01-31 06:57:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:57:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:57:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:57:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:57:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:57:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:57:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:57:24 --> Upload Class Initialized
INFO - 2025-01-31 06:57:24 --> Email Class Initialized
INFO - 2025-01-31 06:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:57:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:57:24 --> Controller Class Initialized
INFO - 2025-01-31 12:27:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:27:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:27:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:58:24 --> Config Class Initialized
INFO - 2025-01-31 06:58:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:58:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:58:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:58:24 --> URI Class Initialized
INFO - 2025-01-31 06:58:24 --> Router Class Initialized
INFO - 2025-01-31 06:58:24 --> Output Class Initialized
INFO - 2025-01-31 06:58:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:58:24 --> Input Class Initialized
INFO - 2025-01-31 06:58:24 --> Language Class Initialized
INFO - 2025-01-31 06:58:24 --> Loader Class Initialized
INFO - 2025-01-31 06:58:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:58:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:58:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:58:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:58:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:58:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:58:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:58:24 --> Upload Class Initialized
INFO - 2025-01-31 06:58:24 --> Email Class Initialized
INFO - 2025-01-31 06:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:58:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:58:24 --> Controller Class Initialized
INFO - 2025-01-31 12:28:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:28:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:28:24 --> Pagination Class Initialized
INFO - 2025-01-31 06:59:24 --> Config Class Initialized
INFO - 2025-01-31 06:59:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 06:59:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 06:59:24 --> Utf8 Class Initialized
INFO - 2025-01-31 06:59:24 --> URI Class Initialized
INFO - 2025-01-31 06:59:24 --> Router Class Initialized
INFO - 2025-01-31 06:59:24 --> Output Class Initialized
INFO - 2025-01-31 06:59:24 --> Security Class Initialized
DEBUG - 2025-01-31 06:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 06:59:24 --> Input Class Initialized
INFO - 2025-01-31 06:59:24 --> Language Class Initialized
INFO - 2025-01-31 06:59:24 --> Loader Class Initialized
INFO - 2025-01-31 06:59:24 --> Helper loaded: url_helper
INFO - 2025-01-31 06:59:24 --> Helper loaded: html_helper
INFO - 2025-01-31 06:59:24 --> Helper loaded: file_helper
INFO - 2025-01-31 06:59:24 --> Helper loaded: string_helper
INFO - 2025-01-31 06:59:24 --> Helper loaded: form_helper
INFO - 2025-01-31 06:59:24 --> Helper loaded: my_helper
INFO - 2025-01-31 06:59:24 --> Database Driver Class Initialized
INFO - 2025-01-31 06:59:24 --> Upload Class Initialized
INFO - 2025-01-31 06:59:24 --> Email Class Initialized
INFO - 2025-01-31 06:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 06:59:24 --> Form Validation Class Initialized
INFO - 2025-01-31 06:59:24 --> Controller Class Initialized
INFO - 2025-01-31 12:29:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:29:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:29:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:00:24 --> Config Class Initialized
INFO - 2025-01-31 07:00:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:00:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:00:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:00:24 --> URI Class Initialized
INFO - 2025-01-31 07:00:24 --> Router Class Initialized
INFO - 2025-01-31 07:00:24 --> Output Class Initialized
INFO - 2025-01-31 07:00:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:00:24 --> Input Class Initialized
INFO - 2025-01-31 07:00:24 --> Language Class Initialized
INFO - 2025-01-31 07:00:24 --> Loader Class Initialized
INFO - 2025-01-31 07:00:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:00:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:00:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:00:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:00:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:00:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:00:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:00:24 --> Upload Class Initialized
INFO - 2025-01-31 07:00:24 --> Email Class Initialized
INFO - 2025-01-31 07:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:00:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:00:24 --> Controller Class Initialized
INFO - 2025-01-31 12:30:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:30:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:30:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:01:24 --> Config Class Initialized
INFO - 2025-01-31 07:01:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:01:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:01:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:01:24 --> URI Class Initialized
INFO - 2025-01-31 07:01:24 --> Router Class Initialized
INFO - 2025-01-31 07:01:24 --> Output Class Initialized
INFO - 2025-01-31 07:01:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:01:24 --> Input Class Initialized
INFO - 2025-01-31 07:01:24 --> Language Class Initialized
INFO - 2025-01-31 07:01:24 --> Loader Class Initialized
INFO - 2025-01-31 07:01:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:01:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:01:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:01:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:01:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:01:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:01:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:01:24 --> Upload Class Initialized
INFO - 2025-01-31 07:01:24 --> Email Class Initialized
INFO - 2025-01-31 07:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:01:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:01:24 --> Controller Class Initialized
INFO - 2025-01-31 12:31:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:31:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:31:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:02:24 --> Config Class Initialized
INFO - 2025-01-31 07:02:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:02:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:02:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:02:24 --> URI Class Initialized
INFO - 2025-01-31 07:02:24 --> Router Class Initialized
INFO - 2025-01-31 07:02:24 --> Output Class Initialized
INFO - 2025-01-31 07:02:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:02:24 --> Input Class Initialized
INFO - 2025-01-31 07:02:24 --> Language Class Initialized
INFO - 2025-01-31 07:02:24 --> Loader Class Initialized
INFO - 2025-01-31 07:02:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:02:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:02:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:02:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:02:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:02:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:02:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:02:24 --> Upload Class Initialized
INFO - 2025-01-31 07:02:24 --> Email Class Initialized
INFO - 2025-01-31 07:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:02:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:02:24 --> Controller Class Initialized
INFO - 2025-01-31 12:32:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:32:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:32:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:03:24 --> Config Class Initialized
INFO - 2025-01-31 07:03:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:03:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:03:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:03:24 --> URI Class Initialized
INFO - 2025-01-31 07:03:24 --> Router Class Initialized
INFO - 2025-01-31 07:03:24 --> Output Class Initialized
INFO - 2025-01-31 07:03:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:03:24 --> Input Class Initialized
INFO - 2025-01-31 07:03:24 --> Language Class Initialized
INFO - 2025-01-31 07:03:24 --> Loader Class Initialized
INFO - 2025-01-31 07:03:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:03:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:03:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:03:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:03:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:03:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:03:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:03:24 --> Upload Class Initialized
INFO - 2025-01-31 07:03:24 --> Email Class Initialized
INFO - 2025-01-31 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:03:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:03:24 --> Controller Class Initialized
INFO - 2025-01-31 12:33:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:33:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:33:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:04:24 --> Config Class Initialized
INFO - 2025-01-31 07:04:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:04:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:04:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:04:24 --> URI Class Initialized
INFO - 2025-01-31 07:04:24 --> Router Class Initialized
INFO - 2025-01-31 07:04:24 --> Output Class Initialized
INFO - 2025-01-31 07:04:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:04:24 --> Input Class Initialized
INFO - 2025-01-31 07:04:24 --> Language Class Initialized
INFO - 2025-01-31 07:04:24 --> Loader Class Initialized
INFO - 2025-01-31 07:04:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:04:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:04:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:04:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:04:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:04:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:04:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:04:24 --> Upload Class Initialized
INFO - 2025-01-31 07:04:24 --> Email Class Initialized
INFO - 2025-01-31 07:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:04:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:04:24 --> Controller Class Initialized
INFO - 2025-01-31 12:34:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:34:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:34:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:05:24 --> Config Class Initialized
INFO - 2025-01-31 07:05:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:05:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:05:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:05:24 --> URI Class Initialized
INFO - 2025-01-31 07:05:24 --> Router Class Initialized
INFO - 2025-01-31 07:05:24 --> Output Class Initialized
INFO - 2025-01-31 07:05:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:05:24 --> Input Class Initialized
INFO - 2025-01-31 07:05:24 --> Language Class Initialized
INFO - 2025-01-31 07:05:24 --> Loader Class Initialized
INFO - 2025-01-31 07:05:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:05:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:05:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:05:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:05:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:05:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:05:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:05:24 --> Upload Class Initialized
INFO - 2025-01-31 07:05:24 --> Email Class Initialized
INFO - 2025-01-31 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:05:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:05:24 --> Controller Class Initialized
INFO - 2025-01-31 12:35:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:35:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:35:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:06:24 --> Config Class Initialized
INFO - 2025-01-31 07:06:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:06:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:06:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:06:24 --> URI Class Initialized
INFO - 2025-01-31 07:06:24 --> Router Class Initialized
INFO - 2025-01-31 07:06:24 --> Output Class Initialized
INFO - 2025-01-31 07:06:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:06:24 --> Input Class Initialized
INFO - 2025-01-31 07:06:24 --> Language Class Initialized
INFO - 2025-01-31 07:06:24 --> Loader Class Initialized
INFO - 2025-01-31 07:06:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:06:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:06:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:06:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:06:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:06:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:06:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:06:24 --> Upload Class Initialized
INFO - 2025-01-31 07:06:24 --> Email Class Initialized
INFO - 2025-01-31 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:06:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:06:24 --> Controller Class Initialized
INFO - 2025-01-31 12:36:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:36:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:36:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:07:24 --> Config Class Initialized
INFO - 2025-01-31 07:07:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:07:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:07:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:07:24 --> URI Class Initialized
INFO - 2025-01-31 07:07:24 --> Router Class Initialized
INFO - 2025-01-31 07:07:24 --> Output Class Initialized
INFO - 2025-01-31 07:07:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:07:24 --> Input Class Initialized
INFO - 2025-01-31 07:07:24 --> Language Class Initialized
INFO - 2025-01-31 07:07:24 --> Loader Class Initialized
INFO - 2025-01-31 07:07:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:07:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:07:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:07:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:07:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:07:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:07:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:07:24 --> Upload Class Initialized
INFO - 2025-01-31 07:07:24 --> Email Class Initialized
INFO - 2025-01-31 07:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:07:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:07:24 --> Controller Class Initialized
INFO - 2025-01-31 12:37:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:37:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:37:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:08:24 --> Config Class Initialized
INFO - 2025-01-31 07:08:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:08:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:08:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:08:24 --> URI Class Initialized
INFO - 2025-01-31 07:08:24 --> Router Class Initialized
INFO - 2025-01-31 07:08:24 --> Output Class Initialized
INFO - 2025-01-31 07:08:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:08:24 --> Input Class Initialized
INFO - 2025-01-31 07:08:24 --> Language Class Initialized
INFO - 2025-01-31 07:08:24 --> Loader Class Initialized
INFO - 2025-01-31 07:08:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:08:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:08:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:08:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:08:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:08:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:08:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:08:24 --> Upload Class Initialized
INFO - 2025-01-31 07:08:24 --> Email Class Initialized
INFO - 2025-01-31 07:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:08:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:08:24 --> Controller Class Initialized
INFO - 2025-01-31 12:38:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:38:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:38:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:09:24 --> Config Class Initialized
INFO - 2025-01-31 07:09:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:09:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:09:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:09:24 --> URI Class Initialized
INFO - 2025-01-31 07:09:24 --> Router Class Initialized
INFO - 2025-01-31 07:09:24 --> Output Class Initialized
INFO - 2025-01-31 07:09:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:09:24 --> Input Class Initialized
INFO - 2025-01-31 07:09:24 --> Language Class Initialized
INFO - 2025-01-31 07:09:24 --> Loader Class Initialized
INFO - 2025-01-31 07:09:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:09:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:09:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:09:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:09:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:09:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:09:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:09:24 --> Upload Class Initialized
INFO - 2025-01-31 07:09:24 --> Email Class Initialized
INFO - 2025-01-31 07:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:09:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:09:24 --> Controller Class Initialized
INFO - 2025-01-31 12:39:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:39:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:39:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:10:24 --> Config Class Initialized
INFO - 2025-01-31 07:10:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:10:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:10:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:10:24 --> URI Class Initialized
INFO - 2025-01-31 07:10:24 --> Router Class Initialized
INFO - 2025-01-31 07:10:24 --> Output Class Initialized
INFO - 2025-01-31 07:10:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:10:24 --> Input Class Initialized
INFO - 2025-01-31 07:10:24 --> Language Class Initialized
INFO - 2025-01-31 07:10:24 --> Loader Class Initialized
INFO - 2025-01-31 07:10:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:10:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:10:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:10:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:10:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:10:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:10:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:10:24 --> Upload Class Initialized
INFO - 2025-01-31 07:10:24 --> Email Class Initialized
INFO - 2025-01-31 07:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:10:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:10:24 --> Controller Class Initialized
INFO - 2025-01-31 12:40:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:40:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:40:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:11:24 --> Config Class Initialized
INFO - 2025-01-31 07:11:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:11:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:11:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:11:24 --> URI Class Initialized
INFO - 2025-01-31 07:11:24 --> Router Class Initialized
INFO - 2025-01-31 07:11:24 --> Output Class Initialized
INFO - 2025-01-31 07:11:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:11:24 --> Input Class Initialized
INFO - 2025-01-31 07:11:24 --> Language Class Initialized
INFO - 2025-01-31 07:11:24 --> Loader Class Initialized
INFO - 2025-01-31 07:11:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:11:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:11:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:11:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:11:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:11:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:11:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:11:24 --> Upload Class Initialized
INFO - 2025-01-31 07:11:24 --> Email Class Initialized
INFO - 2025-01-31 07:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:11:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:11:24 --> Controller Class Initialized
INFO - 2025-01-31 12:41:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:41:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:41:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:12:24 --> Config Class Initialized
INFO - 2025-01-31 07:12:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:12:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:12:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:12:24 --> URI Class Initialized
INFO - 2025-01-31 07:12:24 --> Router Class Initialized
INFO - 2025-01-31 07:12:24 --> Output Class Initialized
INFO - 2025-01-31 07:12:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:12:24 --> Input Class Initialized
INFO - 2025-01-31 07:12:24 --> Language Class Initialized
INFO - 2025-01-31 07:12:24 --> Loader Class Initialized
INFO - 2025-01-31 07:12:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:12:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:12:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:12:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:12:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:12:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:12:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:12:24 --> Upload Class Initialized
INFO - 2025-01-31 07:12:24 --> Email Class Initialized
INFO - 2025-01-31 07:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:12:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:12:24 --> Controller Class Initialized
INFO - 2025-01-31 12:42:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:42:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:42:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:13:24 --> Config Class Initialized
INFO - 2025-01-31 07:13:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:13:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:13:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:13:24 --> URI Class Initialized
INFO - 2025-01-31 07:13:24 --> Router Class Initialized
INFO - 2025-01-31 07:13:24 --> Output Class Initialized
INFO - 2025-01-31 07:13:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:13:24 --> Input Class Initialized
INFO - 2025-01-31 07:13:24 --> Language Class Initialized
INFO - 2025-01-31 07:13:24 --> Loader Class Initialized
INFO - 2025-01-31 07:13:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:13:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:13:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:13:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:13:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:13:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:13:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:13:24 --> Upload Class Initialized
INFO - 2025-01-31 07:13:24 --> Email Class Initialized
INFO - 2025-01-31 07:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:13:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:13:24 --> Controller Class Initialized
INFO - 2025-01-31 12:43:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:43:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:43:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:14:24 --> Config Class Initialized
INFO - 2025-01-31 07:14:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:14:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:14:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:14:24 --> URI Class Initialized
INFO - 2025-01-31 07:14:24 --> Router Class Initialized
INFO - 2025-01-31 07:14:24 --> Output Class Initialized
INFO - 2025-01-31 07:14:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:14:24 --> Input Class Initialized
INFO - 2025-01-31 07:14:24 --> Language Class Initialized
INFO - 2025-01-31 07:14:24 --> Loader Class Initialized
INFO - 2025-01-31 07:14:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:14:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:14:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:14:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:14:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:14:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:14:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:14:24 --> Upload Class Initialized
INFO - 2025-01-31 07:14:24 --> Email Class Initialized
INFO - 2025-01-31 07:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:14:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:14:24 --> Controller Class Initialized
INFO - 2025-01-31 12:44:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:44:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:44:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:15:24 --> Config Class Initialized
INFO - 2025-01-31 07:15:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:15:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:15:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:15:24 --> URI Class Initialized
INFO - 2025-01-31 07:15:24 --> Router Class Initialized
INFO - 2025-01-31 07:15:24 --> Output Class Initialized
INFO - 2025-01-31 07:15:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:15:24 --> Input Class Initialized
INFO - 2025-01-31 07:15:24 --> Language Class Initialized
INFO - 2025-01-31 07:15:24 --> Loader Class Initialized
INFO - 2025-01-31 07:15:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:15:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:15:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:15:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:15:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:15:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:15:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:15:24 --> Upload Class Initialized
INFO - 2025-01-31 07:15:24 --> Email Class Initialized
INFO - 2025-01-31 07:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:15:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:15:24 --> Controller Class Initialized
INFO - 2025-01-31 12:45:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:45:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:45:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:16:24 --> Config Class Initialized
INFO - 2025-01-31 07:16:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:16:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:16:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:16:24 --> URI Class Initialized
INFO - 2025-01-31 07:16:24 --> Router Class Initialized
INFO - 2025-01-31 07:16:24 --> Output Class Initialized
INFO - 2025-01-31 07:16:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:16:24 --> Input Class Initialized
INFO - 2025-01-31 07:16:24 --> Language Class Initialized
INFO - 2025-01-31 07:16:24 --> Loader Class Initialized
INFO - 2025-01-31 07:16:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:16:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:16:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:16:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:16:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:16:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:16:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:16:24 --> Upload Class Initialized
INFO - 2025-01-31 07:16:24 --> Email Class Initialized
INFO - 2025-01-31 07:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:16:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:16:24 --> Controller Class Initialized
INFO - 2025-01-31 12:46:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:46:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:46:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:17:24 --> Config Class Initialized
INFO - 2025-01-31 07:17:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:17:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:17:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:17:24 --> URI Class Initialized
INFO - 2025-01-31 07:17:24 --> Router Class Initialized
INFO - 2025-01-31 07:17:24 --> Output Class Initialized
INFO - 2025-01-31 07:17:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:17:24 --> Input Class Initialized
INFO - 2025-01-31 07:17:24 --> Language Class Initialized
INFO - 2025-01-31 07:17:24 --> Loader Class Initialized
INFO - 2025-01-31 07:17:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:17:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:17:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:17:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:17:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:17:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:17:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:17:24 --> Upload Class Initialized
INFO - 2025-01-31 07:17:24 --> Email Class Initialized
INFO - 2025-01-31 07:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:17:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:17:24 --> Controller Class Initialized
INFO - 2025-01-31 12:47:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:47:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:47:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:18:36 --> Config Class Initialized
INFO - 2025-01-31 07:18:36 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:18:36 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:18:36 --> Utf8 Class Initialized
INFO - 2025-01-31 07:18:36 --> URI Class Initialized
INFO - 2025-01-31 07:18:36 --> Router Class Initialized
INFO - 2025-01-31 07:18:36 --> Output Class Initialized
INFO - 2025-01-31 07:18:36 --> Security Class Initialized
DEBUG - 2025-01-31 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:18:36 --> Input Class Initialized
INFO - 2025-01-31 07:18:36 --> Language Class Initialized
INFO - 2025-01-31 07:18:36 --> Loader Class Initialized
INFO - 2025-01-31 07:18:36 --> Helper loaded: url_helper
INFO - 2025-01-31 07:18:36 --> Helper loaded: html_helper
INFO - 2025-01-31 07:18:36 --> Helper loaded: file_helper
INFO - 2025-01-31 07:18:36 --> Helper loaded: string_helper
INFO - 2025-01-31 07:18:36 --> Helper loaded: form_helper
INFO - 2025-01-31 07:18:36 --> Helper loaded: my_helper
INFO - 2025-01-31 07:18:36 --> Database Driver Class Initialized
INFO - 2025-01-31 07:18:36 --> Upload Class Initialized
INFO - 2025-01-31 07:18:36 --> Email Class Initialized
INFO - 2025-01-31 07:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:18:36 --> Form Validation Class Initialized
INFO - 2025-01-31 07:18:36 --> Controller Class Initialized
INFO - 2025-01-31 12:48:36 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:48:36 --> Model "MainModel" initialized
INFO - 2025-01-31 12:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:48:36 --> Pagination Class Initialized
INFO - 2025-01-31 07:19:24 --> Config Class Initialized
INFO - 2025-01-31 07:19:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:19:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:19:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:19:24 --> URI Class Initialized
INFO - 2025-01-31 07:19:24 --> Router Class Initialized
INFO - 2025-01-31 07:19:24 --> Output Class Initialized
INFO - 2025-01-31 07:19:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:19:24 --> Input Class Initialized
INFO - 2025-01-31 07:19:24 --> Language Class Initialized
INFO - 2025-01-31 07:19:24 --> Loader Class Initialized
INFO - 2025-01-31 07:19:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:19:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:19:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:19:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:19:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:19:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:19:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:19:24 --> Upload Class Initialized
INFO - 2025-01-31 07:19:24 --> Email Class Initialized
INFO - 2025-01-31 07:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:19:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:19:24 --> Controller Class Initialized
INFO - 2025-01-31 12:49:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:49:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:49:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:20:24 --> Config Class Initialized
INFO - 2025-01-31 07:20:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:20:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:20:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:20:24 --> URI Class Initialized
INFO - 2025-01-31 07:20:24 --> Router Class Initialized
INFO - 2025-01-31 07:20:24 --> Output Class Initialized
INFO - 2025-01-31 07:20:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:20:24 --> Input Class Initialized
INFO - 2025-01-31 07:20:24 --> Language Class Initialized
INFO - 2025-01-31 07:20:24 --> Loader Class Initialized
INFO - 2025-01-31 07:20:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:20:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:20:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:20:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:20:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:20:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:20:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:20:24 --> Upload Class Initialized
INFO - 2025-01-31 07:20:24 --> Email Class Initialized
INFO - 2025-01-31 07:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:20:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:20:24 --> Controller Class Initialized
INFO - 2025-01-31 12:50:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:50:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:50:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:50:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:21:24 --> Config Class Initialized
INFO - 2025-01-31 07:21:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:21:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:21:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:21:24 --> URI Class Initialized
INFO - 2025-01-31 07:21:24 --> Router Class Initialized
INFO - 2025-01-31 07:21:24 --> Output Class Initialized
INFO - 2025-01-31 07:21:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:21:24 --> Input Class Initialized
INFO - 2025-01-31 07:21:24 --> Language Class Initialized
INFO - 2025-01-31 07:21:24 --> Loader Class Initialized
INFO - 2025-01-31 07:21:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:21:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:21:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:21:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:21:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:21:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:21:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:21:24 --> Upload Class Initialized
INFO - 2025-01-31 07:21:24 --> Email Class Initialized
INFO - 2025-01-31 07:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:21:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:21:24 --> Controller Class Initialized
INFO - 2025-01-31 12:51:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:51:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:51:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:22:24 --> Config Class Initialized
INFO - 2025-01-31 07:22:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:22:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:22:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:22:24 --> URI Class Initialized
INFO - 2025-01-31 07:22:24 --> Router Class Initialized
INFO - 2025-01-31 07:22:24 --> Output Class Initialized
INFO - 2025-01-31 07:22:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:22:24 --> Input Class Initialized
INFO - 2025-01-31 07:22:24 --> Language Class Initialized
INFO - 2025-01-31 07:22:24 --> Loader Class Initialized
INFO - 2025-01-31 07:22:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:22:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:22:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:22:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:22:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:22:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:22:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:22:24 --> Upload Class Initialized
INFO - 2025-01-31 07:22:24 --> Email Class Initialized
INFO - 2025-01-31 07:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:22:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:22:24 --> Controller Class Initialized
INFO - 2025-01-31 12:52:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:52:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:52:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:23:24 --> Config Class Initialized
INFO - 2025-01-31 07:23:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:23:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:23:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:23:24 --> URI Class Initialized
INFO - 2025-01-31 07:23:24 --> Router Class Initialized
INFO - 2025-01-31 07:23:24 --> Output Class Initialized
INFO - 2025-01-31 07:23:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:23:24 --> Input Class Initialized
INFO - 2025-01-31 07:23:24 --> Language Class Initialized
INFO - 2025-01-31 07:23:24 --> Loader Class Initialized
INFO - 2025-01-31 07:23:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:23:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:23:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:23:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:23:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:23:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:23:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:23:24 --> Upload Class Initialized
INFO - 2025-01-31 07:23:24 --> Email Class Initialized
INFO - 2025-01-31 07:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:23:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:23:24 --> Controller Class Initialized
INFO - 2025-01-31 12:53:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:53:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:53:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:24:24 --> Config Class Initialized
INFO - 2025-01-31 07:24:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:24:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:24:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:24:24 --> URI Class Initialized
INFO - 2025-01-31 07:24:24 --> Router Class Initialized
INFO - 2025-01-31 07:24:24 --> Output Class Initialized
INFO - 2025-01-31 07:24:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:24:24 --> Input Class Initialized
INFO - 2025-01-31 07:24:24 --> Language Class Initialized
INFO - 2025-01-31 07:24:24 --> Loader Class Initialized
INFO - 2025-01-31 07:24:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:24:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:24:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:24:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:24:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:24:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:24:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:24:24 --> Upload Class Initialized
INFO - 2025-01-31 07:24:24 --> Email Class Initialized
INFO - 2025-01-31 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:24:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:24:24 --> Controller Class Initialized
INFO - 2025-01-31 12:54:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:54:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:54:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:25:24 --> Config Class Initialized
INFO - 2025-01-31 07:25:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:25:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:25:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:25:24 --> URI Class Initialized
INFO - 2025-01-31 07:25:24 --> Router Class Initialized
INFO - 2025-01-31 07:25:24 --> Output Class Initialized
INFO - 2025-01-31 07:25:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:25:24 --> Input Class Initialized
INFO - 2025-01-31 07:25:24 --> Language Class Initialized
INFO - 2025-01-31 07:25:24 --> Loader Class Initialized
INFO - 2025-01-31 07:25:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:25:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:25:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:25:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:25:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:25:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:25:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:25:24 --> Upload Class Initialized
INFO - 2025-01-31 07:25:24 --> Email Class Initialized
INFO - 2025-01-31 07:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:25:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:25:24 --> Controller Class Initialized
INFO - 2025-01-31 12:55:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:55:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:55:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:26:24 --> Config Class Initialized
INFO - 2025-01-31 07:26:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:26:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:26:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:26:24 --> URI Class Initialized
INFO - 2025-01-31 07:26:24 --> Router Class Initialized
INFO - 2025-01-31 07:26:24 --> Output Class Initialized
INFO - 2025-01-31 07:26:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:26:24 --> Input Class Initialized
INFO - 2025-01-31 07:26:24 --> Language Class Initialized
INFO - 2025-01-31 07:26:24 --> Loader Class Initialized
INFO - 2025-01-31 07:26:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:26:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:26:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:26:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:26:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:26:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:26:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:26:24 --> Upload Class Initialized
INFO - 2025-01-31 07:26:24 --> Email Class Initialized
INFO - 2025-01-31 07:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:26:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:26:24 --> Controller Class Initialized
INFO - 2025-01-31 12:56:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:56:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:56:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:27:24 --> Config Class Initialized
INFO - 2025-01-31 07:27:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:27:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:27:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:27:24 --> URI Class Initialized
INFO - 2025-01-31 07:27:24 --> Router Class Initialized
INFO - 2025-01-31 07:27:24 --> Output Class Initialized
INFO - 2025-01-31 07:27:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:27:24 --> Input Class Initialized
INFO - 2025-01-31 07:27:24 --> Language Class Initialized
INFO - 2025-01-31 07:27:24 --> Loader Class Initialized
INFO - 2025-01-31 07:27:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:27:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:27:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:27:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:27:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:27:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:27:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:27:24 --> Upload Class Initialized
INFO - 2025-01-31 07:27:24 --> Email Class Initialized
INFO - 2025-01-31 07:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:27:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:27:24 --> Controller Class Initialized
INFO - 2025-01-31 12:57:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:57:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:57:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:28:24 --> Config Class Initialized
INFO - 2025-01-31 07:28:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:28:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:28:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:28:24 --> URI Class Initialized
INFO - 2025-01-31 07:28:24 --> Router Class Initialized
INFO - 2025-01-31 07:28:24 --> Output Class Initialized
INFO - 2025-01-31 07:28:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:28:24 --> Input Class Initialized
INFO - 2025-01-31 07:28:24 --> Language Class Initialized
INFO - 2025-01-31 07:28:24 --> Loader Class Initialized
INFO - 2025-01-31 07:28:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:28:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:28:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:28:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:28:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:28:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:28:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:28:24 --> Upload Class Initialized
INFO - 2025-01-31 07:28:24 --> Email Class Initialized
INFO - 2025-01-31 07:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:28:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:28:24 --> Controller Class Initialized
INFO - 2025-01-31 12:58:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:58:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:58:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:29:24 --> Config Class Initialized
INFO - 2025-01-31 07:29:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:29:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:29:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:29:24 --> URI Class Initialized
INFO - 2025-01-31 07:29:24 --> Router Class Initialized
INFO - 2025-01-31 07:29:24 --> Output Class Initialized
INFO - 2025-01-31 07:29:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:29:24 --> Input Class Initialized
INFO - 2025-01-31 07:29:24 --> Language Class Initialized
INFO - 2025-01-31 07:29:24 --> Loader Class Initialized
INFO - 2025-01-31 07:29:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:29:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:29:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:29:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:29:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:29:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:29:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:29:24 --> Upload Class Initialized
INFO - 2025-01-31 07:29:24 --> Email Class Initialized
INFO - 2025-01-31 07:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:29:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:29:24 --> Controller Class Initialized
INFO - 2025-01-31 12:59:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 12:59:24 --> Model "MainModel" initialized
INFO - 2025-01-31 12:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 12:59:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:30:24 --> Config Class Initialized
INFO - 2025-01-31 07:30:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:30:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:30:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:30:24 --> URI Class Initialized
INFO - 2025-01-31 07:30:24 --> Router Class Initialized
INFO - 2025-01-31 07:30:24 --> Output Class Initialized
INFO - 2025-01-31 07:30:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:30:24 --> Input Class Initialized
INFO - 2025-01-31 07:30:24 --> Language Class Initialized
INFO - 2025-01-31 07:30:24 --> Loader Class Initialized
INFO - 2025-01-31 07:30:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:30:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:30:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:30:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:30:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:30:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:30:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:30:24 --> Upload Class Initialized
INFO - 2025-01-31 07:30:24 --> Email Class Initialized
INFO - 2025-01-31 07:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:30:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:30:24 --> Controller Class Initialized
INFO - 2025-01-31 13:00:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:00:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:00:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:31:24 --> Config Class Initialized
INFO - 2025-01-31 07:31:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:31:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:31:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:31:24 --> URI Class Initialized
INFO - 2025-01-31 07:31:24 --> Router Class Initialized
INFO - 2025-01-31 07:31:24 --> Output Class Initialized
INFO - 2025-01-31 07:31:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:31:24 --> Input Class Initialized
INFO - 2025-01-31 07:31:24 --> Language Class Initialized
INFO - 2025-01-31 07:31:24 --> Loader Class Initialized
INFO - 2025-01-31 07:31:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:31:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:31:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:31:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:31:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:31:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:31:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:31:24 --> Upload Class Initialized
INFO - 2025-01-31 07:31:24 --> Email Class Initialized
INFO - 2025-01-31 07:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:31:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:31:24 --> Controller Class Initialized
INFO - 2025-01-31 13:01:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:01:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:01:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:32:24 --> Config Class Initialized
INFO - 2025-01-31 07:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:32:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:32:24 --> URI Class Initialized
INFO - 2025-01-31 07:32:24 --> Router Class Initialized
INFO - 2025-01-31 07:32:24 --> Output Class Initialized
INFO - 2025-01-31 07:32:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:32:24 --> Input Class Initialized
INFO - 2025-01-31 07:32:24 --> Language Class Initialized
INFO - 2025-01-31 07:32:24 --> Loader Class Initialized
INFO - 2025-01-31 07:32:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:32:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:32:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:32:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:32:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:32:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:32:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:32:24 --> Upload Class Initialized
INFO - 2025-01-31 07:32:24 --> Email Class Initialized
INFO - 2025-01-31 07:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:32:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:32:24 --> Controller Class Initialized
INFO - 2025-01-31 13:02:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:02:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:02:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:32:52 --> Config Class Initialized
INFO - 2025-01-31 07:32:52 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:32:52 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:32:52 --> Utf8 Class Initialized
INFO - 2025-01-31 07:32:52 --> URI Class Initialized
INFO - 2025-01-31 07:32:52 --> Router Class Initialized
INFO - 2025-01-31 07:32:52 --> Output Class Initialized
INFO - 2025-01-31 07:32:52 --> Security Class Initialized
DEBUG - 2025-01-31 07:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:32:52 --> Input Class Initialized
INFO - 2025-01-31 07:32:52 --> Language Class Initialized
INFO - 2025-01-31 07:32:52 --> Loader Class Initialized
INFO - 2025-01-31 07:32:52 --> Helper loaded: url_helper
INFO - 2025-01-31 07:32:52 --> Helper loaded: html_helper
INFO - 2025-01-31 07:32:52 --> Helper loaded: file_helper
INFO - 2025-01-31 07:32:52 --> Helper loaded: string_helper
INFO - 2025-01-31 07:32:52 --> Helper loaded: form_helper
INFO - 2025-01-31 07:32:52 --> Helper loaded: my_helper
INFO - 2025-01-31 07:32:52 --> Database Driver Class Initialized
INFO - 2025-01-31 07:32:52 --> Upload Class Initialized
INFO - 2025-01-31 07:32:52 --> Email Class Initialized
INFO - 2025-01-31 07:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:32:52 --> Form Validation Class Initialized
INFO - 2025-01-31 07:32:52 --> Controller Class Initialized
INFO - 2025-01-31 13:02:52 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:02:52 --> Model "MainModel" initialized
INFO - 2025-01-31 13:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:02:52 --> Pagination Class Initialized
INFO - 2025-01-31 07:32:58 --> Config Class Initialized
INFO - 2025-01-31 07:32:58 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:32:58 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:32:58 --> Utf8 Class Initialized
INFO - 2025-01-31 07:32:58 --> URI Class Initialized
INFO - 2025-01-31 07:32:58 --> Router Class Initialized
INFO - 2025-01-31 07:32:58 --> Output Class Initialized
INFO - 2025-01-31 07:32:58 --> Security Class Initialized
DEBUG - 2025-01-31 07:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:32:58 --> Input Class Initialized
INFO - 2025-01-31 07:32:58 --> Language Class Initialized
INFO - 2025-01-31 07:32:58 --> Loader Class Initialized
INFO - 2025-01-31 07:32:58 --> Helper loaded: url_helper
INFO - 2025-01-31 07:32:58 --> Helper loaded: html_helper
INFO - 2025-01-31 07:32:58 --> Helper loaded: file_helper
INFO - 2025-01-31 07:32:58 --> Helper loaded: string_helper
INFO - 2025-01-31 07:32:58 --> Helper loaded: form_helper
INFO - 2025-01-31 07:32:58 --> Helper loaded: my_helper
INFO - 2025-01-31 07:32:58 --> Database Driver Class Initialized
INFO - 2025-01-31 07:32:58 --> Upload Class Initialized
INFO - 2025-01-31 07:32:58 --> Email Class Initialized
INFO - 2025-01-31 07:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:32:58 --> Form Validation Class Initialized
INFO - 2025-01-31 07:32:58 --> Controller Class Initialized
INFO - 2025-01-31 13:02:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:02:58 --> Model "MainModel" initialized
INFO - 2025-01-31 13:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:02:58 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:03 --> Config Class Initialized
INFO - 2025-01-31 07:33:03 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:03 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:03 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:03 --> URI Class Initialized
INFO - 2025-01-31 07:33:03 --> Router Class Initialized
INFO - 2025-01-31 07:33:03 --> Output Class Initialized
INFO - 2025-01-31 07:33:03 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:03 --> Input Class Initialized
INFO - 2025-01-31 07:33:03 --> Language Class Initialized
INFO - 2025-01-31 07:33:03 --> Loader Class Initialized
INFO - 2025-01-31 07:33:03 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:03 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:03 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:03 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:03 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:03 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:03 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:03 --> Upload Class Initialized
INFO - 2025-01-31 07:33:03 --> Email Class Initialized
INFO - 2025-01-31 07:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:03 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:03 --> Controller Class Initialized
INFO - 2025-01-31 13:03:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:03 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:03 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:08 --> Config Class Initialized
INFO - 2025-01-31 07:33:08 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:08 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:08 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:08 --> URI Class Initialized
INFO - 2025-01-31 07:33:08 --> Router Class Initialized
INFO - 2025-01-31 07:33:08 --> Output Class Initialized
INFO - 2025-01-31 07:33:08 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:08 --> Input Class Initialized
INFO - 2025-01-31 07:33:08 --> Language Class Initialized
INFO - 2025-01-31 07:33:08 --> Loader Class Initialized
INFO - 2025-01-31 07:33:08 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:08 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:08 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:08 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:08 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:08 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:08 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:08 --> Upload Class Initialized
INFO - 2025-01-31 07:33:08 --> Email Class Initialized
INFO - 2025-01-31 07:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:08 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:08 --> Controller Class Initialized
INFO - 2025-01-31 13:03:08 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:08 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:08 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:13 --> Config Class Initialized
INFO - 2025-01-31 07:33:13 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:13 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:13 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:13 --> URI Class Initialized
INFO - 2025-01-31 07:33:13 --> Router Class Initialized
INFO - 2025-01-31 07:33:13 --> Output Class Initialized
INFO - 2025-01-31 07:33:13 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:13 --> Input Class Initialized
INFO - 2025-01-31 07:33:13 --> Language Class Initialized
INFO - 2025-01-31 07:33:13 --> Loader Class Initialized
INFO - 2025-01-31 07:33:13 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:13 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:13 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:13 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:13 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:13 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:13 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:13 --> Upload Class Initialized
INFO - 2025-01-31 07:33:13 --> Email Class Initialized
INFO - 2025-01-31 07:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:13 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:13 --> Controller Class Initialized
INFO - 2025-01-31 13:03:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:13 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:13 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:18 --> Config Class Initialized
INFO - 2025-01-31 07:33:18 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:18 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:18 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:18 --> URI Class Initialized
INFO - 2025-01-31 07:33:18 --> Router Class Initialized
INFO - 2025-01-31 07:33:18 --> Output Class Initialized
INFO - 2025-01-31 07:33:18 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:18 --> Input Class Initialized
INFO - 2025-01-31 07:33:18 --> Language Class Initialized
INFO - 2025-01-31 07:33:18 --> Loader Class Initialized
INFO - 2025-01-31 07:33:18 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:18 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:18 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:18 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:18 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:18 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:18 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:18 --> Upload Class Initialized
INFO - 2025-01-31 07:33:18 --> Email Class Initialized
INFO - 2025-01-31 07:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:18 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:18 --> Controller Class Initialized
INFO - 2025-01-31 13:03:18 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:18 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:18 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:23 --> Config Class Initialized
INFO - 2025-01-31 07:33:23 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:23 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:23 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:23 --> URI Class Initialized
INFO - 2025-01-31 07:33:23 --> Router Class Initialized
INFO - 2025-01-31 07:33:23 --> Output Class Initialized
INFO - 2025-01-31 07:33:23 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:23 --> Input Class Initialized
INFO - 2025-01-31 07:33:23 --> Language Class Initialized
INFO - 2025-01-31 07:33:23 --> Loader Class Initialized
INFO - 2025-01-31 07:33:23 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:23 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:23 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:23 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:23 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:23 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:23 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:23 --> Upload Class Initialized
INFO - 2025-01-31 07:33:23 --> Email Class Initialized
INFO - 2025-01-31 07:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:23 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:23 --> Controller Class Initialized
INFO - 2025-01-31 13:03:23 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:23 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:23 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:28 --> Config Class Initialized
INFO - 2025-01-31 07:33:28 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:28 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:28 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:28 --> URI Class Initialized
INFO - 2025-01-31 07:33:28 --> Router Class Initialized
INFO - 2025-01-31 07:33:28 --> Output Class Initialized
INFO - 2025-01-31 07:33:28 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:28 --> Input Class Initialized
INFO - 2025-01-31 07:33:28 --> Language Class Initialized
INFO - 2025-01-31 07:33:28 --> Loader Class Initialized
INFO - 2025-01-31 07:33:28 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:28 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:28 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:28 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:28 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:28 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:28 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:28 --> Upload Class Initialized
INFO - 2025-01-31 07:33:28 --> Email Class Initialized
INFO - 2025-01-31 07:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:28 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:28 --> Controller Class Initialized
INFO - 2025-01-31 13:03:28 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:28 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:28 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:33 --> Config Class Initialized
INFO - 2025-01-31 07:33:33 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:33 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:33 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:33 --> URI Class Initialized
INFO - 2025-01-31 07:33:33 --> Router Class Initialized
INFO - 2025-01-31 07:33:33 --> Output Class Initialized
INFO - 2025-01-31 07:33:33 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:33 --> Input Class Initialized
INFO - 2025-01-31 07:33:33 --> Language Class Initialized
INFO - 2025-01-31 07:33:33 --> Loader Class Initialized
INFO - 2025-01-31 07:33:33 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:33 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:33 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:33 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:33 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:33 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:33 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:33 --> Upload Class Initialized
INFO - 2025-01-31 07:33:33 --> Email Class Initialized
INFO - 2025-01-31 07:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:33 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:33 --> Controller Class Initialized
INFO - 2025-01-31 13:03:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:33 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:33 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:38 --> Config Class Initialized
INFO - 2025-01-31 07:33:38 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:38 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:38 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:38 --> URI Class Initialized
INFO - 2025-01-31 07:33:38 --> Router Class Initialized
INFO - 2025-01-31 07:33:38 --> Output Class Initialized
INFO - 2025-01-31 07:33:38 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:38 --> Input Class Initialized
INFO - 2025-01-31 07:33:38 --> Language Class Initialized
INFO - 2025-01-31 07:33:38 --> Loader Class Initialized
INFO - 2025-01-31 07:33:38 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:38 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:38 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:38 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:38 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:38 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:38 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:38 --> Upload Class Initialized
INFO - 2025-01-31 07:33:38 --> Email Class Initialized
INFO - 2025-01-31 07:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:38 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:38 --> Controller Class Initialized
INFO - 2025-01-31 13:03:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:38 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:38 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:43 --> Config Class Initialized
INFO - 2025-01-31 07:33:43 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:43 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:43 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:43 --> URI Class Initialized
INFO - 2025-01-31 07:33:43 --> Router Class Initialized
INFO - 2025-01-31 07:33:43 --> Output Class Initialized
INFO - 2025-01-31 07:33:43 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:43 --> Input Class Initialized
INFO - 2025-01-31 07:33:43 --> Language Class Initialized
INFO - 2025-01-31 07:33:43 --> Loader Class Initialized
INFO - 2025-01-31 07:33:43 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:43 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:43 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:43 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:43 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:43 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:43 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:43 --> Upload Class Initialized
INFO - 2025-01-31 07:33:43 --> Email Class Initialized
INFO - 2025-01-31 07:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:43 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:43 --> Controller Class Initialized
INFO - 2025-01-31 13:03:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:43 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:43 --> Pagination Class Initialized
INFO - 2025-01-31 07:33:48 --> Config Class Initialized
INFO - 2025-01-31 07:33:48 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:33:48 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:33:48 --> Utf8 Class Initialized
INFO - 2025-01-31 07:33:48 --> URI Class Initialized
INFO - 2025-01-31 07:33:48 --> Router Class Initialized
INFO - 2025-01-31 07:33:48 --> Output Class Initialized
INFO - 2025-01-31 07:33:48 --> Security Class Initialized
DEBUG - 2025-01-31 07:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:33:48 --> Input Class Initialized
INFO - 2025-01-31 07:33:48 --> Language Class Initialized
INFO - 2025-01-31 07:33:48 --> Loader Class Initialized
INFO - 2025-01-31 07:33:48 --> Helper loaded: url_helper
INFO - 2025-01-31 07:33:48 --> Helper loaded: html_helper
INFO - 2025-01-31 07:33:48 --> Helper loaded: file_helper
INFO - 2025-01-31 07:33:48 --> Helper loaded: string_helper
INFO - 2025-01-31 07:33:48 --> Helper loaded: form_helper
INFO - 2025-01-31 07:33:48 --> Helper loaded: my_helper
INFO - 2025-01-31 07:33:48 --> Database Driver Class Initialized
INFO - 2025-01-31 07:33:48 --> Upload Class Initialized
INFO - 2025-01-31 07:33:48 --> Email Class Initialized
INFO - 2025-01-31 07:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:33:48 --> Form Validation Class Initialized
INFO - 2025-01-31 07:33:48 --> Controller Class Initialized
INFO - 2025-01-31 13:03:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:03:48 --> Model "MainModel" initialized
INFO - 2025-01-31 13:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:03:48 --> Pagination Class Initialized
INFO - 2025-01-31 07:34:24 --> Config Class Initialized
INFO - 2025-01-31 07:34:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:34:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:34:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:34:24 --> URI Class Initialized
INFO - 2025-01-31 07:34:24 --> Router Class Initialized
INFO - 2025-01-31 07:34:24 --> Output Class Initialized
INFO - 2025-01-31 07:34:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:34:24 --> Input Class Initialized
INFO - 2025-01-31 07:34:24 --> Language Class Initialized
INFO - 2025-01-31 07:34:24 --> Loader Class Initialized
INFO - 2025-01-31 07:34:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:34:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:34:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:34:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:34:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:34:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:34:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:34:24 --> Upload Class Initialized
INFO - 2025-01-31 07:34:24 --> Email Class Initialized
INFO - 2025-01-31 07:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:34:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:34:24 --> Controller Class Initialized
INFO - 2025-01-31 13:04:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:04:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:04:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:35:24 --> Config Class Initialized
INFO - 2025-01-31 07:35:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:35:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:35:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:35:24 --> URI Class Initialized
INFO - 2025-01-31 07:35:24 --> Router Class Initialized
INFO - 2025-01-31 07:35:24 --> Output Class Initialized
INFO - 2025-01-31 07:35:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:35:24 --> Input Class Initialized
INFO - 2025-01-31 07:35:24 --> Language Class Initialized
INFO - 2025-01-31 07:35:24 --> Loader Class Initialized
INFO - 2025-01-31 07:35:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:35:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:35:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:35:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:35:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:35:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:35:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:35:24 --> Upload Class Initialized
INFO - 2025-01-31 07:35:24 --> Email Class Initialized
INFO - 2025-01-31 07:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:35:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:35:24 --> Controller Class Initialized
INFO - 2025-01-31 13:05:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:05:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:05:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:36:24 --> Config Class Initialized
INFO - 2025-01-31 07:36:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:36:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:36:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:36:24 --> URI Class Initialized
INFO - 2025-01-31 07:36:24 --> Router Class Initialized
INFO - 2025-01-31 07:36:24 --> Output Class Initialized
INFO - 2025-01-31 07:36:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:36:24 --> Input Class Initialized
INFO - 2025-01-31 07:36:24 --> Language Class Initialized
INFO - 2025-01-31 07:36:24 --> Loader Class Initialized
INFO - 2025-01-31 07:36:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:36:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:36:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:36:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:36:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:36:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:36:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:36:24 --> Upload Class Initialized
INFO - 2025-01-31 07:36:24 --> Email Class Initialized
INFO - 2025-01-31 07:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:36:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:36:24 --> Controller Class Initialized
INFO - 2025-01-31 13:06:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:06:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:06:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:37:24 --> Config Class Initialized
INFO - 2025-01-31 07:37:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:37:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:37:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:37:24 --> URI Class Initialized
INFO - 2025-01-31 07:37:24 --> Router Class Initialized
INFO - 2025-01-31 07:37:24 --> Output Class Initialized
INFO - 2025-01-31 07:37:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:37:24 --> Input Class Initialized
INFO - 2025-01-31 07:37:24 --> Language Class Initialized
INFO - 2025-01-31 07:37:24 --> Loader Class Initialized
INFO - 2025-01-31 07:37:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:37:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:37:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:37:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:37:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:37:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:37:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:37:24 --> Upload Class Initialized
INFO - 2025-01-31 07:37:24 --> Email Class Initialized
INFO - 2025-01-31 07:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:37:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:37:24 --> Controller Class Initialized
INFO - 2025-01-31 13:07:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:07:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:07:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:38:24 --> Config Class Initialized
INFO - 2025-01-31 07:38:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:38:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:38:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:38:24 --> URI Class Initialized
INFO - 2025-01-31 07:38:24 --> Router Class Initialized
INFO - 2025-01-31 07:38:24 --> Output Class Initialized
INFO - 2025-01-31 07:38:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:38:24 --> Input Class Initialized
INFO - 2025-01-31 07:38:24 --> Language Class Initialized
INFO - 2025-01-31 07:38:24 --> Loader Class Initialized
INFO - 2025-01-31 07:38:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:38:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:38:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:38:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:38:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:38:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:38:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:38:24 --> Upload Class Initialized
INFO - 2025-01-31 07:38:24 --> Email Class Initialized
INFO - 2025-01-31 07:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:38:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:38:24 --> Controller Class Initialized
INFO - 2025-01-31 13:08:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:08:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:08:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:39:24 --> Config Class Initialized
INFO - 2025-01-31 07:39:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:39:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:39:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:39:24 --> URI Class Initialized
INFO - 2025-01-31 07:39:24 --> Router Class Initialized
INFO - 2025-01-31 07:39:24 --> Output Class Initialized
INFO - 2025-01-31 07:39:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:39:24 --> Input Class Initialized
INFO - 2025-01-31 07:39:24 --> Language Class Initialized
INFO - 2025-01-31 07:39:24 --> Loader Class Initialized
INFO - 2025-01-31 07:39:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:39:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:39:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:39:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:39:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:39:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:39:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:39:24 --> Upload Class Initialized
INFO - 2025-01-31 07:39:24 --> Email Class Initialized
INFO - 2025-01-31 07:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:39:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:39:24 --> Controller Class Initialized
INFO - 2025-01-31 13:09:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:09:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:09:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:40:24 --> Config Class Initialized
INFO - 2025-01-31 07:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:40:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:40:24 --> URI Class Initialized
INFO - 2025-01-31 07:40:24 --> Router Class Initialized
INFO - 2025-01-31 07:40:24 --> Output Class Initialized
INFO - 2025-01-31 07:40:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:40:24 --> Input Class Initialized
INFO - 2025-01-31 07:40:24 --> Language Class Initialized
INFO - 2025-01-31 07:40:24 --> Loader Class Initialized
INFO - 2025-01-31 07:40:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:40:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:40:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:40:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:40:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:40:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:40:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:40:24 --> Upload Class Initialized
INFO - 2025-01-31 07:40:24 --> Email Class Initialized
INFO - 2025-01-31 07:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:40:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:40:24 --> Controller Class Initialized
INFO - 2025-01-31 13:10:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:10:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:10:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:41:24 --> Config Class Initialized
INFO - 2025-01-31 07:41:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:41:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:41:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:41:24 --> URI Class Initialized
INFO - 2025-01-31 07:41:24 --> Router Class Initialized
INFO - 2025-01-31 07:41:24 --> Output Class Initialized
INFO - 2025-01-31 07:41:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:41:24 --> Input Class Initialized
INFO - 2025-01-31 07:41:24 --> Language Class Initialized
INFO - 2025-01-31 07:41:24 --> Loader Class Initialized
INFO - 2025-01-31 07:41:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:41:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:41:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:41:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:41:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:41:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:41:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:41:24 --> Upload Class Initialized
INFO - 2025-01-31 07:41:24 --> Email Class Initialized
INFO - 2025-01-31 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:41:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:41:24 --> Controller Class Initialized
INFO - 2025-01-31 13:11:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:11:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:11:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:42:24 --> Config Class Initialized
INFO - 2025-01-31 07:42:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:42:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:42:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:42:24 --> URI Class Initialized
INFO - 2025-01-31 07:42:24 --> Router Class Initialized
INFO - 2025-01-31 07:42:24 --> Output Class Initialized
INFO - 2025-01-31 07:42:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:42:24 --> Input Class Initialized
INFO - 2025-01-31 07:42:24 --> Language Class Initialized
INFO - 2025-01-31 07:42:24 --> Loader Class Initialized
INFO - 2025-01-31 07:42:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:42:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:42:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:42:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:42:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:42:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:42:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:42:24 --> Upload Class Initialized
INFO - 2025-01-31 07:42:24 --> Email Class Initialized
INFO - 2025-01-31 07:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:42:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:42:24 --> Controller Class Initialized
INFO - 2025-01-31 13:12:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:12:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:12:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:43:24 --> Config Class Initialized
INFO - 2025-01-31 07:43:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:43:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:43:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:43:24 --> URI Class Initialized
INFO - 2025-01-31 07:43:24 --> Router Class Initialized
INFO - 2025-01-31 07:43:24 --> Output Class Initialized
INFO - 2025-01-31 07:43:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:43:24 --> Input Class Initialized
INFO - 2025-01-31 07:43:24 --> Language Class Initialized
INFO - 2025-01-31 07:43:24 --> Loader Class Initialized
INFO - 2025-01-31 07:43:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:43:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:43:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:43:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:43:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:43:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:43:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:43:24 --> Upload Class Initialized
INFO - 2025-01-31 07:43:24 --> Email Class Initialized
INFO - 2025-01-31 07:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:43:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:43:24 --> Controller Class Initialized
INFO - 2025-01-31 13:13:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:13:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:13:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:44:24 --> Config Class Initialized
INFO - 2025-01-31 07:44:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:44:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:44:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:44:24 --> URI Class Initialized
INFO - 2025-01-31 07:44:24 --> Router Class Initialized
INFO - 2025-01-31 07:44:24 --> Output Class Initialized
INFO - 2025-01-31 07:44:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:44:24 --> Input Class Initialized
INFO - 2025-01-31 07:44:24 --> Language Class Initialized
INFO - 2025-01-31 07:44:24 --> Loader Class Initialized
INFO - 2025-01-31 07:44:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:44:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:44:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:44:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:44:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:44:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:44:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:44:24 --> Upload Class Initialized
INFO - 2025-01-31 07:44:24 --> Email Class Initialized
INFO - 2025-01-31 07:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:44:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:44:24 --> Controller Class Initialized
INFO - 2025-01-31 13:14:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:14:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:14:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:45:24 --> Config Class Initialized
INFO - 2025-01-31 07:45:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:45:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:45:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:45:24 --> URI Class Initialized
INFO - 2025-01-31 07:45:24 --> Router Class Initialized
INFO - 2025-01-31 07:45:24 --> Output Class Initialized
INFO - 2025-01-31 07:45:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:45:24 --> Input Class Initialized
INFO - 2025-01-31 07:45:24 --> Language Class Initialized
INFO - 2025-01-31 07:45:24 --> Loader Class Initialized
INFO - 2025-01-31 07:45:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:45:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:45:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:45:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:45:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:45:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:45:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:45:24 --> Upload Class Initialized
INFO - 2025-01-31 07:45:24 --> Email Class Initialized
INFO - 2025-01-31 07:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:45:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:45:24 --> Controller Class Initialized
INFO - 2025-01-31 13:15:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:15:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:15:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:46:24 --> Config Class Initialized
INFO - 2025-01-31 07:46:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:46:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:46:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:46:24 --> URI Class Initialized
INFO - 2025-01-31 07:46:24 --> Router Class Initialized
INFO - 2025-01-31 07:46:24 --> Output Class Initialized
INFO - 2025-01-31 07:46:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:46:24 --> Input Class Initialized
INFO - 2025-01-31 07:46:24 --> Language Class Initialized
INFO - 2025-01-31 07:46:24 --> Loader Class Initialized
INFO - 2025-01-31 07:46:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:46:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:46:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:46:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:46:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:46:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:46:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:46:24 --> Upload Class Initialized
INFO - 2025-01-31 07:46:24 --> Email Class Initialized
INFO - 2025-01-31 07:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:46:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:46:24 --> Controller Class Initialized
INFO - 2025-01-31 13:16:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:16:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:16:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:47:24 --> Config Class Initialized
INFO - 2025-01-31 07:47:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:47:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:47:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:47:24 --> URI Class Initialized
INFO - 2025-01-31 07:47:24 --> Router Class Initialized
INFO - 2025-01-31 07:47:24 --> Output Class Initialized
INFO - 2025-01-31 07:47:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:47:24 --> Input Class Initialized
INFO - 2025-01-31 07:47:24 --> Language Class Initialized
INFO - 2025-01-31 07:47:24 --> Loader Class Initialized
INFO - 2025-01-31 07:47:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:47:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:47:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:47:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:47:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:47:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:47:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:47:24 --> Upload Class Initialized
INFO - 2025-01-31 07:47:24 --> Email Class Initialized
INFO - 2025-01-31 07:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:47:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:47:24 --> Controller Class Initialized
INFO - 2025-01-31 13:17:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:17:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:17:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:48:24 --> Config Class Initialized
INFO - 2025-01-31 07:48:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:48:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:48:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:48:24 --> URI Class Initialized
INFO - 2025-01-31 07:48:24 --> Router Class Initialized
INFO - 2025-01-31 07:48:24 --> Output Class Initialized
INFO - 2025-01-31 07:48:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:48:24 --> Input Class Initialized
INFO - 2025-01-31 07:48:24 --> Language Class Initialized
INFO - 2025-01-31 07:48:24 --> Loader Class Initialized
INFO - 2025-01-31 07:48:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:48:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:48:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:48:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:48:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:48:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:48:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:48:24 --> Upload Class Initialized
INFO - 2025-01-31 07:48:24 --> Email Class Initialized
INFO - 2025-01-31 07:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:48:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:48:24 --> Controller Class Initialized
INFO - 2025-01-31 13:18:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:18:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:18:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:49:24 --> Config Class Initialized
INFO - 2025-01-31 07:49:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:49:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:49:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:49:24 --> URI Class Initialized
INFO - 2025-01-31 07:49:24 --> Router Class Initialized
INFO - 2025-01-31 07:49:24 --> Output Class Initialized
INFO - 2025-01-31 07:49:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:49:24 --> Input Class Initialized
INFO - 2025-01-31 07:49:24 --> Language Class Initialized
INFO - 2025-01-31 07:49:24 --> Loader Class Initialized
INFO - 2025-01-31 07:49:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:49:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:49:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:49:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:49:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:49:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:49:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:49:24 --> Upload Class Initialized
INFO - 2025-01-31 07:49:24 --> Email Class Initialized
INFO - 2025-01-31 07:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:49:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:49:24 --> Controller Class Initialized
INFO - 2025-01-31 13:19:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:19:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:19:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:50:24 --> Config Class Initialized
INFO - 2025-01-31 07:50:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:50:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:50:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:50:24 --> URI Class Initialized
INFO - 2025-01-31 07:50:24 --> Router Class Initialized
INFO - 2025-01-31 07:50:24 --> Output Class Initialized
INFO - 2025-01-31 07:50:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:50:24 --> Input Class Initialized
INFO - 2025-01-31 07:50:24 --> Language Class Initialized
INFO - 2025-01-31 07:50:24 --> Loader Class Initialized
INFO - 2025-01-31 07:50:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:50:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:50:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:50:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:50:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:50:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:50:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:50:24 --> Upload Class Initialized
INFO - 2025-01-31 07:50:24 --> Email Class Initialized
INFO - 2025-01-31 07:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:50:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:50:24 --> Controller Class Initialized
INFO - 2025-01-31 13:20:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:20:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:20:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:51:24 --> Config Class Initialized
INFO - 2025-01-31 07:51:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:51:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:51:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:51:24 --> URI Class Initialized
INFO - 2025-01-31 07:51:24 --> Router Class Initialized
INFO - 2025-01-31 07:51:24 --> Output Class Initialized
INFO - 2025-01-31 07:51:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:51:24 --> Input Class Initialized
INFO - 2025-01-31 07:51:24 --> Language Class Initialized
INFO - 2025-01-31 07:51:24 --> Loader Class Initialized
INFO - 2025-01-31 07:51:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:51:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:51:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:51:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:51:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:51:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:51:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:51:24 --> Upload Class Initialized
INFO - 2025-01-31 07:51:24 --> Email Class Initialized
INFO - 2025-01-31 07:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:51:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:51:24 --> Controller Class Initialized
INFO - 2025-01-31 13:21:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:21:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:21:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:52:24 --> Config Class Initialized
INFO - 2025-01-31 07:52:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:52:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:52:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:52:24 --> URI Class Initialized
INFO - 2025-01-31 07:52:24 --> Router Class Initialized
INFO - 2025-01-31 07:52:24 --> Output Class Initialized
INFO - 2025-01-31 07:52:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:52:24 --> Input Class Initialized
INFO - 2025-01-31 07:52:24 --> Language Class Initialized
INFO - 2025-01-31 07:52:24 --> Loader Class Initialized
INFO - 2025-01-31 07:52:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:52:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:52:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:52:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:52:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:52:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:52:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:52:24 --> Upload Class Initialized
INFO - 2025-01-31 07:52:24 --> Email Class Initialized
INFO - 2025-01-31 07:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:52:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:52:24 --> Controller Class Initialized
INFO - 2025-01-31 13:22:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:22:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:22:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:53:24 --> Config Class Initialized
INFO - 2025-01-31 07:53:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:53:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:53:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:53:24 --> URI Class Initialized
INFO - 2025-01-31 07:53:24 --> Router Class Initialized
INFO - 2025-01-31 07:53:24 --> Output Class Initialized
INFO - 2025-01-31 07:53:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:53:24 --> Input Class Initialized
INFO - 2025-01-31 07:53:24 --> Language Class Initialized
INFO - 2025-01-31 07:53:24 --> Loader Class Initialized
INFO - 2025-01-31 07:53:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:53:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:53:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:53:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:53:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:53:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:53:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:53:24 --> Upload Class Initialized
INFO - 2025-01-31 07:53:24 --> Email Class Initialized
INFO - 2025-01-31 07:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:53:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:53:24 --> Controller Class Initialized
INFO - 2025-01-31 13:23:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:23:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:23:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:54:24 --> Config Class Initialized
INFO - 2025-01-31 07:54:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:54:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:54:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:54:24 --> URI Class Initialized
INFO - 2025-01-31 07:54:24 --> Router Class Initialized
INFO - 2025-01-31 07:54:24 --> Output Class Initialized
INFO - 2025-01-31 07:54:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:54:24 --> Input Class Initialized
INFO - 2025-01-31 07:54:24 --> Language Class Initialized
INFO - 2025-01-31 07:54:24 --> Loader Class Initialized
INFO - 2025-01-31 07:54:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:54:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:54:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:54:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:54:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:54:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:54:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:54:24 --> Upload Class Initialized
INFO - 2025-01-31 07:54:24 --> Email Class Initialized
INFO - 2025-01-31 07:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:54:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:54:24 --> Controller Class Initialized
INFO - 2025-01-31 13:24:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:24:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:24:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:55:24 --> Config Class Initialized
INFO - 2025-01-31 07:55:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:55:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:55:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:55:24 --> URI Class Initialized
INFO - 2025-01-31 07:55:24 --> Router Class Initialized
INFO - 2025-01-31 07:55:24 --> Output Class Initialized
INFO - 2025-01-31 07:55:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:55:24 --> Input Class Initialized
INFO - 2025-01-31 07:55:24 --> Language Class Initialized
INFO - 2025-01-31 07:55:24 --> Loader Class Initialized
INFO - 2025-01-31 07:55:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:55:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:55:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:55:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:55:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:55:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:55:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:55:24 --> Upload Class Initialized
INFO - 2025-01-31 07:55:24 --> Email Class Initialized
INFO - 2025-01-31 07:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:55:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:55:24 --> Controller Class Initialized
INFO - 2025-01-31 13:25:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:25:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:25:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:56:24 --> Config Class Initialized
INFO - 2025-01-31 07:56:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:56:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:56:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:56:24 --> URI Class Initialized
INFO - 2025-01-31 07:56:24 --> Router Class Initialized
INFO - 2025-01-31 07:56:24 --> Output Class Initialized
INFO - 2025-01-31 07:56:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:56:24 --> Input Class Initialized
INFO - 2025-01-31 07:56:24 --> Language Class Initialized
INFO - 2025-01-31 07:56:24 --> Loader Class Initialized
INFO - 2025-01-31 07:56:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:56:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:56:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:56:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:56:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:56:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:56:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:56:24 --> Upload Class Initialized
INFO - 2025-01-31 07:56:24 --> Email Class Initialized
INFO - 2025-01-31 07:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:56:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:56:24 --> Controller Class Initialized
INFO - 2025-01-31 13:26:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:26:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:26:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:57:24 --> Config Class Initialized
INFO - 2025-01-31 07:57:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:57:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:57:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:57:24 --> URI Class Initialized
INFO - 2025-01-31 07:57:24 --> Router Class Initialized
INFO - 2025-01-31 07:57:24 --> Output Class Initialized
INFO - 2025-01-31 07:57:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:57:24 --> Input Class Initialized
INFO - 2025-01-31 07:57:24 --> Language Class Initialized
INFO - 2025-01-31 07:57:24 --> Loader Class Initialized
INFO - 2025-01-31 07:57:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:57:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:57:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:57:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:57:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:57:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:57:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:57:24 --> Upload Class Initialized
INFO - 2025-01-31 07:57:24 --> Email Class Initialized
INFO - 2025-01-31 07:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:57:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:57:24 --> Controller Class Initialized
INFO - 2025-01-31 13:27:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:27:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:27:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:58:24 --> Config Class Initialized
INFO - 2025-01-31 07:58:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:58:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:58:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:58:24 --> URI Class Initialized
INFO - 2025-01-31 07:58:24 --> Router Class Initialized
INFO - 2025-01-31 07:58:24 --> Output Class Initialized
INFO - 2025-01-31 07:58:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:58:24 --> Input Class Initialized
INFO - 2025-01-31 07:58:24 --> Language Class Initialized
INFO - 2025-01-31 07:58:24 --> Loader Class Initialized
INFO - 2025-01-31 07:58:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:58:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:58:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:58:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:58:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:58:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:58:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:58:24 --> Upload Class Initialized
INFO - 2025-01-31 07:58:24 --> Email Class Initialized
INFO - 2025-01-31 07:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:58:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:58:24 --> Controller Class Initialized
INFO - 2025-01-31 13:28:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:28:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:28:24 --> Pagination Class Initialized
INFO - 2025-01-31 07:59:24 --> Config Class Initialized
INFO - 2025-01-31 07:59:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 07:59:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 07:59:24 --> Utf8 Class Initialized
INFO - 2025-01-31 07:59:24 --> URI Class Initialized
INFO - 2025-01-31 07:59:24 --> Router Class Initialized
INFO - 2025-01-31 07:59:24 --> Output Class Initialized
INFO - 2025-01-31 07:59:24 --> Security Class Initialized
DEBUG - 2025-01-31 07:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 07:59:24 --> Input Class Initialized
INFO - 2025-01-31 07:59:24 --> Language Class Initialized
INFO - 2025-01-31 07:59:24 --> Loader Class Initialized
INFO - 2025-01-31 07:59:24 --> Helper loaded: url_helper
INFO - 2025-01-31 07:59:24 --> Helper loaded: html_helper
INFO - 2025-01-31 07:59:24 --> Helper loaded: file_helper
INFO - 2025-01-31 07:59:24 --> Helper loaded: string_helper
INFO - 2025-01-31 07:59:24 --> Helper loaded: form_helper
INFO - 2025-01-31 07:59:24 --> Helper loaded: my_helper
INFO - 2025-01-31 07:59:24 --> Database Driver Class Initialized
INFO - 2025-01-31 07:59:24 --> Upload Class Initialized
INFO - 2025-01-31 07:59:24 --> Email Class Initialized
INFO - 2025-01-31 07:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 07:59:24 --> Form Validation Class Initialized
INFO - 2025-01-31 07:59:24 --> Controller Class Initialized
INFO - 2025-01-31 13:29:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:29:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:29:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:00:24 --> Config Class Initialized
INFO - 2025-01-31 08:00:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:00:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:00:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:00:24 --> URI Class Initialized
INFO - 2025-01-31 08:00:24 --> Router Class Initialized
INFO - 2025-01-31 08:00:24 --> Output Class Initialized
INFO - 2025-01-31 08:00:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:00:24 --> Input Class Initialized
INFO - 2025-01-31 08:00:24 --> Language Class Initialized
INFO - 2025-01-31 08:00:24 --> Loader Class Initialized
INFO - 2025-01-31 08:00:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:00:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:00:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:00:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:00:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:00:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:00:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:00:24 --> Upload Class Initialized
INFO - 2025-01-31 08:00:24 --> Email Class Initialized
INFO - 2025-01-31 08:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:00:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:00:24 --> Controller Class Initialized
INFO - 2025-01-31 13:30:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:30:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:30:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:01:24 --> Config Class Initialized
INFO - 2025-01-31 08:01:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:01:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:01:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:01:24 --> URI Class Initialized
INFO - 2025-01-31 08:01:24 --> Router Class Initialized
INFO - 2025-01-31 08:01:24 --> Output Class Initialized
INFO - 2025-01-31 08:01:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:01:24 --> Input Class Initialized
INFO - 2025-01-31 08:01:24 --> Language Class Initialized
INFO - 2025-01-31 08:01:24 --> Loader Class Initialized
INFO - 2025-01-31 08:01:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:01:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:01:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:01:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:01:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:01:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:01:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:01:24 --> Upload Class Initialized
INFO - 2025-01-31 08:01:24 --> Email Class Initialized
INFO - 2025-01-31 08:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:01:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:01:24 --> Controller Class Initialized
INFO - 2025-01-31 13:31:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:31:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:31:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:02:24 --> Config Class Initialized
INFO - 2025-01-31 08:02:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:02:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:02:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:02:24 --> URI Class Initialized
INFO - 2025-01-31 08:02:24 --> Router Class Initialized
INFO - 2025-01-31 08:02:24 --> Output Class Initialized
INFO - 2025-01-31 08:02:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:02:24 --> Input Class Initialized
INFO - 2025-01-31 08:02:24 --> Language Class Initialized
INFO - 2025-01-31 08:02:24 --> Loader Class Initialized
INFO - 2025-01-31 08:02:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:02:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:02:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:02:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:02:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:02:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:02:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:02:24 --> Upload Class Initialized
INFO - 2025-01-31 08:02:24 --> Email Class Initialized
INFO - 2025-01-31 08:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:02:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:02:24 --> Controller Class Initialized
INFO - 2025-01-31 13:32:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:32:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:32:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:03:24 --> Config Class Initialized
INFO - 2025-01-31 08:03:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:03:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:03:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:03:24 --> URI Class Initialized
INFO - 2025-01-31 08:03:24 --> Router Class Initialized
INFO - 2025-01-31 08:03:24 --> Output Class Initialized
INFO - 2025-01-31 08:03:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:03:24 --> Input Class Initialized
INFO - 2025-01-31 08:03:24 --> Language Class Initialized
INFO - 2025-01-31 08:03:24 --> Loader Class Initialized
INFO - 2025-01-31 08:03:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:03:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:03:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:03:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:03:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:03:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:03:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:03:24 --> Upload Class Initialized
INFO - 2025-01-31 08:03:24 --> Email Class Initialized
INFO - 2025-01-31 08:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:03:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:03:24 --> Controller Class Initialized
INFO - 2025-01-31 13:33:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:33:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:33:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:04:24 --> Config Class Initialized
INFO - 2025-01-31 08:04:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:04:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:04:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:04:24 --> URI Class Initialized
INFO - 2025-01-31 08:04:24 --> Router Class Initialized
INFO - 2025-01-31 08:04:24 --> Output Class Initialized
INFO - 2025-01-31 08:04:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:04:24 --> Input Class Initialized
INFO - 2025-01-31 08:04:24 --> Language Class Initialized
INFO - 2025-01-31 08:04:24 --> Loader Class Initialized
INFO - 2025-01-31 08:04:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:04:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:04:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:04:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:04:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:04:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:04:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:04:24 --> Upload Class Initialized
INFO - 2025-01-31 08:04:24 --> Email Class Initialized
INFO - 2025-01-31 08:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:04:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:04:24 --> Controller Class Initialized
INFO - 2025-01-31 13:34:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:34:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:34:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:05:24 --> Config Class Initialized
INFO - 2025-01-31 08:05:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:05:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:05:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:05:24 --> URI Class Initialized
INFO - 2025-01-31 08:05:24 --> Router Class Initialized
INFO - 2025-01-31 08:05:24 --> Output Class Initialized
INFO - 2025-01-31 08:05:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:05:24 --> Input Class Initialized
INFO - 2025-01-31 08:05:24 --> Language Class Initialized
INFO - 2025-01-31 08:05:24 --> Loader Class Initialized
INFO - 2025-01-31 08:05:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:05:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:05:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:05:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:05:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:05:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:05:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:05:24 --> Upload Class Initialized
INFO - 2025-01-31 08:05:24 --> Email Class Initialized
INFO - 2025-01-31 08:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:05:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:05:24 --> Controller Class Initialized
INFO - 2025-01-31 13:35:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:35:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:35:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:06:24 --> Config Class Initialized
INFO - 2025-01-31 08:06:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:06:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:06:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:06:24 --> URI Class Initialized
INFO - 2025-01-31 08:06:24 --> Router Class Initialized
INFO - 2025-01-31 08:06:24 --> Output Class Initialized
INFO - 2025-01-31 08:06:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:06:24 --> Input Class Initialized
INFO - 2025-01-31 08:06:24 --> Language Class Initialized
INFO - 2025-01-31 08:06:24 --> Loader Class Initialized
INFO - 2025-01-31 08:06:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:06:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:06:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:06:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:06:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:06:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:06:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:06:24 --> Upload Class Initialized
INFO - 2025-01-31 08:06:24 --> Email Class Initialized
INFO - 2025-01-31 08:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:06:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:06:24 --> Controller Class Initialized
INFO - 2025-01-31 13:36:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:36:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:36:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:07:24 --> Config Class Initialized
INFO - 2025-01-31 08:07:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:07:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:07:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:07:24 --> URI Class Initialized
INFO - 2025-01-31 08:07:24 --> Router Class Initialized
INFO - 2025-01-31 08:07:24 --> Output Class Initialized
INFO - 2025-01-31 08:07:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:07:24 --> Input Class Initialized
INFO - 2025-01-31 08:07:24 --> Language Class Initialized
INFO - 2025-01-31 08:07:24 --> Loader Class Initialized
INFO - 2025-01-31 08:07:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:07:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:07:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:07:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:07:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:07:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:07:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:07:24 --> Upload Class Initialized
INFO - 2025-01-31 08:07:24 --> Email Class Initialized
INFO - 2025-01-31 08:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:07:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:07:24 --> Controller Class Initialized
INFO - 2025-01-31 13:37:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:37:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:37:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:08:24 --> Config Class Initialized
INFO - 2025-01-31 08:08:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:08:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:08:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:08:24 --> URI Class Initialized
INFO - 2025-01-31 08:08:24 --> Router Class Initialized
INFO - 2025-01-31 08:08:24 --> Output Class Initialized
INFO - 2025-01-31 08:08:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:08:24 --> Input Class Initialized
INFO - 2025-01-31 08:08:24 --> Language Class Initialized
INFO - 2025-01-31 08:08:24 --> Loader Class Initialized
INFO - 2025-01-31 08:08:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:08:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:08:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:08:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:08:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:08:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:08:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:08:24 --> Upload Class Initialized
INFO - 2025-01-31 08:08:24 --> Email Class Initialized
INFO - 2025-01-31 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:08:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:08:24 --> Controller Class Initialized
INFO - 2025-01-31 13:38:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:38:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:38:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:09:24 --> Config Class Initialized
INFO - 2025-01-31 08:09:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:09:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:09:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:09:24 --> URI Class Initialized
INFO - 2025-01-31 08:09:24 --> Router Class Initialized
INFO - 2025-01-31 08:09:24 --> Output Class Initialized
INFO - 2025-01-31 08:09:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:09:24 --> Input Class Initialized
INFO - 2025-01-31 08:09:24 --> Language Class Initialized
INFO - 2025-01-31 08:09:24 --> Loader Class Initialized
INFO - 2025-01-31 08:09:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:09:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:09:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:09:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:09:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:09:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:09:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:09:24 --> Upload Class Initialized
INFO - 2025-01-31 08:09:24 --> Email Class Initialized
INFO - 2025-01-31 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:09:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:09:24 --> Controller Class Initialized
INFO - 2025-01-31 13:39:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:39:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:39:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:10:24 --> Config Class Initialized
INFO - 2025-01-31 08:10:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:10:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:10:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:10:24 --> URI Class Initialized
INFO - 2025-01-31 08:10:24 --> Router Class Initialized
INFO - 2025-01-31 08:10:24 --> Output Class Initialized
INFO - 2025-01-31 08:10:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:10:24 --> Input Class Initialized
INFO - 2025-01-31 08:10:24 --> Language Class Initialized
INFO - 2025-01-31 08:10:24 --> Loader Class Initialized
INFO - 2025-01-31 08:10:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:10:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:10:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:10:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:10:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:10:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:10:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:10:24 --> Upload Class Initialized
INFO - 2025-01-31 08:10:24 --> Email Class Initialized
INFO - 2025-01-31 08:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:10:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:10:24 --> Controller Class Initialized
INFO - 2025-01-31 13:40:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:40:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:40:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:11:24 --> Config Class Initialized
INFO - 2025-01-31 08:11:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:11:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:11:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:11:24 --> URI Class Initialized
INFO - 2025-01-31 08:11:24 --> Router Class Initialized
INFO - 2025-01-31 08:11:24 --> Output Class Initialized
INFO - 2025-01-31 08:11:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:11:24 --> Input Class Initialized
INFO - 2025-01-31 08:11:24 --> Language Class Initialized
INFO - 2025-01-31 08:11:24 --> Loader Class Initialized
INFO - 2025-01-31 08:11:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:11:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:11:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:11:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:11:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:11:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:11:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:11:24 --> Upload Class Initialized
INFO - 2025-01-31 08:11:24 --> Email Class Initialized
INFO - 2025-01-31 08:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:11:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:11:24 --> Controller Class Initialized
INFO - 2025-01-31 13:41:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:41:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:41:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:12:24 --> Config Class Initialized
INFO - 2025-01-31 08:12:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:12:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:12:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:12:24 --> URI Class Initialized
INFO - 2025-01-31 08:12:24 --> Router Class Initialized
INFO - 2025-01-31 08:12:24 --> Output Class Initialized
INFO - 2025-01-31 08:12:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:12:24 --> Input Class Initialized
INFO - 2025-01-31 08:12:24 --> Language Class Initialized
INFO - 2025-01-31 08:12:24 --> Loader Class Initialized
INFO - 2025-01-31 08:12:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:12:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:12:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:12:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:12:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:12:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:12:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:12:24 --> Upload Class Initialized
INFO - 2025-01-31 08:12:24 --> Email Class Initialized
INFO - 2025-01-31 08:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:12:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:12:24 --> Controller Class Initialized
INFO - 2025-01-31 13:42:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:42:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:42:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:13:24 --> Config Class Initialized
INFO - 2025-01-31 08:13:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:13:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:13:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:13:24 --> URI Class Initialized
INFO - 2025-01-31 08:13:24 --> Router Class Initialized
INFO - 2025-01-31 08:13:24 --> Output Class Initialized
INFO - 2025-01-31 08:13:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:13:24 --> Input Class Initialized
INFO - 2025-01-31 08:13:24 --> Language Class Initialized
INFO - 2025-01-31 08:13:24 --> Loader Class Initialized
INFO - 2025-01-31 08:13:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:13:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:13:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:13:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:13:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:13:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:13:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:13:24 --> Upload Class Initialized
INFO - 2025-01-31 08:13:24 --> Email Class Initialized
INFO - 2025-01-31 08:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:13:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:13:24 --> Controller Class Initialized
INFO - 2025-01-31 13:43:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:43:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:43:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:14:24 --> Config Class Initialized
INFO - 2025-01-31 08:14:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:14:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:14:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:14:24 --> URI Class Initialized
INFO - 2025-01-31 08:14:24 --> Router Class Initialized
INFO - 2025-01-31 08:14:24 --> Output Class Initialized
INFO - 2025-01-31 08:14:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:14:24 --> Input Class Initialized
INFO - 2025-01-31 08:14:24 --> Language Class Initialized
INFO - 2025-01-31 08:14:24 --> Loader Class Initialized
INFO - 2025-01-31 08:14:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:14:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:14:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:14:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:14:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:14:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:14:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:14:24 --> Upload Class Initialized
INFO - 2025-01-31 08:14:24 --> Email Class Initialized
INFO - 2025-01-31 08:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:14:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:14:24 --> Controller Class Initialized
INFO - 2025-01-31 13:44:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:44:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:44:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:15:24 --> Config Class Initialized
INFO - 2025-01-31 08:15:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:15:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:15:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:15:24 --> URI Class Initialized
INFO - 2025-01-31 08:15:24 --> Router Class Initialized
INFO - 2025-01-31 08:15:24 --> Output Class Initialized
INFO - 2025-01-31 08:15:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:15:24 --> Input Class Initialized
INFO - 2025-01-31 08:15:24 --> Language Class Initialized
INFO - 2025-01-31 08:15:24 --> Loader Class Initialized
INFO - 2025-01-31 08:15:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:15:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:15:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:15:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:15:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:15:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:15:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:15:24 --> Upload Class Initialized
INFO - 2025-01-31 08:15:24 --> Email Class Initialized
INFO - 2025-01-31 08:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:15:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:15:24 --> Controller Class Initialized
INFO - 2025-01-31 13:45:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:45:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:45:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:16:24 --> Config Class Initialized
INFO - 2025-01-31 08:16:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:16:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:16:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:16:24 --> URI Class Initialized
INFO - 2025-01-31 08:16:24 --> Router Class Initialized
INFO - 2025-01-31 08:16:24 --> Output Class Initialized
INFO - 2025-01-31 08:16:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:16:24 --> Input Class Initialized
INFO - 2025-01-31 08:16:24 --> Language Class Initialized
INFO - 2025-01-31 08:16:24 --> Loader Class Initialized
INFO - 2025-01-31 08:16:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:16:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:16:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:16:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:16:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:16:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:16:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:16:24 --> Upload Class Initialized
INFO - 2025-01-31 08:16:24 --> Email Class Initialized
INFO - 2025-01-31 08:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:16:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:16:24 --> Controller Class Initialized
INFO - 2025-01-31 13:46:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:46:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:46:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:17:24 --> Config Class Initialized
INFO - 2025-01-31 08:17:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:17:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:17:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:17:24 --> URI Class Initialized
INFO - 2025-01-31 08:17:24 --> Router Class Initialized
INFO - 2025-01-31 08:17:24 --> Output Class Initialized
INFO - 2025-01-31 08:17:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:17:24 --> Input Class Initialized
INFO - 2025-01-31 08:17:24 --> Language Class Initialized
INFO - 2025-01-31 08:17:24 --> Loader Class Initialized
INFO - 2025-01-31 08:17:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:17:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:17:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:17:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:17:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:17:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:17:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:17:24 --> Upload Class Initialized
INFO - 2025-01-31 08:17:24 --> Email Class Initialized
INFO - 2025-01-31 08:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:17:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:17:24 --> Controller Class Initialized
INFO - 2025-01-31 13:47:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:47:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:47:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:18:24 --> Config Class Initialized
INFO - 2025-01-31 08:18:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:18:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:18:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:18:24 --> URI Class Initialized
INFO - 2025-01-31 08:18:24 --> Router Class Initialized
INFO - 2025-01-31 08:18:24 --> Output Class Initialized
INFO - 2025-01-31 08:18:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:18:24 --> Input Class Initialized
INFO - 2025-01-31 08:18:24 --> Language Class Initialized
INFO - 2025-01-31 08:18:24 --> Loader Class Initialized
INFO - 2025-01-31 08:18:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:18:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:18:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:18:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:18:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:18:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:18:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:18:24 --> Upload Class Initialized
INFO - 2025-01-31 08:18:24 --> Email Class Initialized
INFO - 2025-01-31 08:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:18:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:18:24 --> Controller Class Initialized
INFO - 2025-01-31 13:48:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:48:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:48:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:19:24 --> Config Class Initialized
INFO - 2025-01-31 08:19:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:19:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:19:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:19:24 --> URI Class Initialized
INFO - 2025-01-31 08:19:24 --> Router Class Initialized
INFO - 2025-01-31 08:19:24 --> Output Class Initialized
INFO - 2025-01-31 08:19:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:19:24 --> Input Class Initialized
INFO - 2025-01-31 08:19:24 --> Language Class Initialized
INFO - 2025-01-31 08:19:24 --> Loader Class Initialized
INFO - 2025-01-31 08:19:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:19:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:19:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:19:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:19:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:19:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:19:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:19:24 --> Upload Class Initialized
INFO - 2025-01-31 08:19:24 --> Email Class Initialized
INFO - 2025-01-31 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:19:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:19:24 --> Controller Class Initialized
INFO - 2025-01-31 13:49:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:49:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:49:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:20:24 --> Config Class Initialized
INFO - 2025-01-31 08:20:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:20:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:20:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:20:24 --> URI Class Initialized
INFO - 2025-01-31 08:20:24 --> Router Class Initialized
INFO - 2025-01-31 08:20:24 --> Output Class Initialized
INFO - 2025-01-31 08:20:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:20:24 --> Input Class Initialized
INFO - 2025-01-31 08:20:24 --> Language Class Initialized
INFO - 2025-01-31 08:20:24 --> Loader Class Initialized
INFO - 2025-01-31 08:20:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:20:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:20:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:20:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:20:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:20:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:20:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:20:24 --> Upload Class Initialized
INFO - 2025-01-31 08:20:24 --> Email Class Initialized
INFO - 2025-01-31 08:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:20:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:20:24 --> Controller Class Initialized
INFO - 2025-01-31 13:50:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:50:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:50:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:50:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:21:24 --> Config Class Initialized
INFO - 2025-01-31 08:21:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:21:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:21:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:21:24 --> URI Class Initialized
INFO - 2025-01-31 08:21:24 --> Router Class Initialized
INFO - 2025-01-31 08:21:24 --> Output Class Initialized
INFO - 2025-01-31 08:21:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:21:24 --> Input Class Initialized
INFO - 2025-01-31 08:21:24 --> Language Class Initialized
INFO - 2025-01-31 08:21:24 --> Loader Class Initialized
INFO - 2025-01-31 08:21:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:21:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:21:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:21:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:21:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:21:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:21:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:21:24 --> Upload Class Initialized
INFO - 2025-01-31 08:21:24 --> Email Class Initialized
INFO - 2025-01-31 08:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:21:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:21:24 --> Controller Class Initialized
INFO - 2025-01-31 13:51:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:51:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:51:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:22:24 --> Config Class Initialized
INFO - 2025-01-31 08:22:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:22:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:22:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:22:24 --> URI Class Initialized
INFO - 2025-01-31 08:22:24 --> Router Class Initialized
INFO - 2025-01-31 08:22:24 --> Output Class Initialized
INFO - 2025-01-31 08:22:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:22:24 --> Input Class Initialized
INFO - 2025-01-31 08:22:24 --> Language Class Initialized
INFO - 2025-01-31 08:22:24 --> Loader Class Initialized
INFO - 2025-01-31 08:22:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:22:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:22:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:22:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:22:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:22:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:22:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:22:24 --> Upload Class Initialized
INFO - 2025-01-31 08:22:24 --> Email Class Initialized
INFO - 2025-01-31 08:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:22:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:22:24 --> Controller Class Initialized
INFO - 2025-01-31 13:52:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 13:52:24 --> Model "MainModel" initialized
INFO - 2025-01-31 13:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 13:52:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:32:02 --> Config Class Initialized
INFO - 2025-01-31 08:32:02 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:32:02 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:32:02 --> Utf8 Class Initialized
INFO - 2025-01-31 08:32:02 --> URI Class Initialized
INFO - 2025-01-31 08:32:02 --> Router Class Initialized
INFO - 2025-01-31 08:32:02 --> Output Class Initialized
INFO - 2025-01-31 08:32:02 --> Security Class Initialized
DEBUG - 2025-01-31 08:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:32:02 --> Input Class Initialized
INFO - 2025-01-31 08:32:02 --> Language Class Initialized
INFO - 2025-01-31 08:32:02 --> Loader Class Initialized
INFO - 2025-01-31 08:32:02 --> Helper loaded: url_helper
INFO - 2025-01-31 08:32:02 --> Helper loaded: html_helper
INFO - 2025-01-31 08:32:02 --> Helper loaded: file_helper
INFO - 2025-01-31 08:32:02 --> Helper loaded: string_helper
INFO - 2025-01-31 08:32:02 --> Helper loaded: form_helper
INFO - 2025-01-31 08:32:02 --> Helper loaded: my_helper
INFO - 2025-01-31 08:32:02 --> Database Driver Class Initialized
INFO - 2025-01-31 08:32:02 --> Upload Class Initialized
INFO - 2025-01-31 08:32:02 --> Email Class Initialized
INFO - 2025-01-31 08:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:32:02 --> Form Validation Class Initialized
INFO - 2025-01-31 08:32:02 --> Controller Class Initialized
INFO - 2025-01-31 14:02:02 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:02:02 --> Model "MainModel" initialized
INFO - 2025-01-31 14:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:02:02 --> Pagination Class Initialized
INFO - 2025-01-31 08:32:24 --> Config Class Initialized
INFO - 2025-01-31 08:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:32:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:32:24 --> URI Class Initialized
INFO - 2025-01-31 08:32:24 --> Router Class Initialized
INFO - 2025-01-31 08:32:24 --> Output Class Initialized
INFO - 2025-01-31 08:32:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:32:24 --> Input Class Initialized
INFO - 2025-01-31 08:32:24 --> Language Class Initialized
INFO - 2025-01-31 08:32:24 --> Loader Class Initialized
INFO - 2025-01-31 08:32:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:32:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:32:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:32:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:32:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:32:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:32:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:32:24 --> Upload Class Initialized
INFO - 2025-01-31 08:32:24 --> Email Class Initialized
INFO - 2025-01-31 08:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:32:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:32:24 --> Controller Class Initialized
INFO - 2025-01-31 14:02:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:02:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:02:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:33:24 --> Config Class Initialized
INFO - 2025-01-31 08:33:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:33:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:33:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:33:24 --> URI Class Initialized
INFO - 2025-01-31 08:33:24 --> Router Class Initialized
INFO - 2025-01-31 08:33:24 --> Output Class Initialized
INFO - 2025-01-31 08:33:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:33:24 --> Input Class Initialized
INFO - 2025-01-31 08:33:24 --> Language Class Initialized
INFO - 2025-01-31 08:33:24 --> Loader Class Initialized
INFO - 2025-01-31 08:33:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:33:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:33:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:33:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:33:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:33:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:33:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:33:24 --> Upload Class Initialized
INFO - 2025-01-31 08:33:24 --> Email Class Initialized
INFO - 2025-01-31 08:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:33:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:33:24 --> Controller Class Initialized
INFO - 2025-01-31 14:03:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:03:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:03:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:34:24 --> Config Class Initialized
INFO - 2025-01-31 08:34:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:34:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:34:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:34:24 --> URI Class Initialized
INFO - 2025-01-31 08:34:24 --> Router Class Initialized
INFO - 2025-01-31 08:34:24 --> Output Class Initialized
INFO - 2025-01-31 08:34:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:34:24 --> Input Class Initialized
INFO - 2025-01-31 08:34:24 --> Language Class Initialized
INFO - 2025-01-31 08:34:24 --> Loader Class Initialized
INFO - 2025-01-31 08:34:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:34:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:34:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:34:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:34:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:34:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:34:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:34:24 --> Upload Class Initialized
INFO - 2025-01-31 08:34:24 --> Email Class Initialized
INFO - 2025-01-31 08:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:34:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:34:24 --> Controller Class Initialized
INFO - 2025-01-31 14:04:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:04:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:04:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:35:24 --> Config Class Initialized
INFO - 2025-01-31 08:35:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:35:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:35:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:35:24 --> URI Class Initialized
INFO - 2025-01-31 08:35:24 --> Router Class Initialized
INFO - 2025-01-31 08:35:24 --> Output Class Initialized
INFO - 2025-01-31 08:35:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:35:24 --> Input Class Initialized
INFO - 2025-01-31 08:35:24 --> Language Class Initialized
INFO - 2025-01-31 08:35:24 --> Loader Class Initialized
INFO - 2025-01-31 08:35:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:35:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:35:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:35:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:35:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:35:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:35:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:35:24 --> Upload Class Initialized
INFO - 2025-01-31 08:35:24 --> Email Class Initialized
INFO - 2025-01-31 08:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:35:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:35:24 --> Controller Class Initialized
INFO - 2025-01-31 14:05:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:05:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:05:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:36:24 --> Config Class Initialized
INFO - 2025-01-31 08:36:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:36:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:36:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:36:24 --> URI Class Initialized
INFO - 2025-01-31 08:36:24 --> Router Class Initialized
INFO - 2025-01-31 08:36:24 --> Output Class Initialized
INFO - 2025-01-31 08:36:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:36:24 --> Input Class Initialized
INFO - 2025-01-31 08:36:24 --> Language Class Initialized
INFO - 2025-01-31 08:36:24 --> Loader Class Initialized
INFO - 2025-01-31 08:36:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:36:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:36:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:36:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:36:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:36:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:36:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:36:24 --> Upload Class Initialized
INFO - 2025-01-31 08:36:24 --> Email Class Initialized
INFO - 2025-01-31 08:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:36:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:36:24 --> Controller Class Initialized
INFO - 2025-01-31 14:06:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:06:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:06:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:37:24 --> Config Class Initialized
INFO - 2025-01-31 08:37:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:37:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:37:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:37:24 --> URI Class Initialized
INFO - 2025-01-31 08:37:24 --> Router Class Initialized
INFO - 2025-01-31 08:37:24 --> Output Class Initialized
INFO - 2025-01-31 08:37:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:37:24 --> Input Class Initialized
INFO - 2025-01-31 08:37:24 --> Language Class Initialized
INFO - 2025-01-31 08:37:24 --> Loader Class Initialized
INFO - 2025-01-31 08:37:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:37:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:37:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:37:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:37:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:37:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:37:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:37:24 --> Upload Class Initialized
INFO - 2025-01-31 08:37:24 --> Email Class Initialized
INFO - 2025-01-31 08:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:37:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:37:24 --> Controller Class Initialized
INFO - 2025-01-31 14:07:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:07:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:07:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:38:24 --> Config Class Initialized
INFO - 2025-01-31 08:38:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:38:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:38:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:38:24 --> URI Class Initialized
INFO - 2025-01-31 08:38:24 --> Router Class Initialized
INFO - 2025-01-31 08:38:24 --> Output Class Initialized
INFO - 2025-01-31 08:38:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:38:24 --> Input Class Initialized
INFO - 2025-01-31 08:38:24 --> Language Class Initialized
INFO - 2025-01-31 08:38:24 --> Loader Class Initialized
INFO - 2025-01-31 08:38:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:38:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:38:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:38:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:38:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:38:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:38:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:38:24 --> Upload Class Initialized
INFO - 2025-01-31 08:38:24 --> Email Class Initialized
INFO - 2025-01-31 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:38:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:38:24 --> Controller Class Initialized
INFO - 2025-01-31 14:08:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:08:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:08:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:39:24 --> Config Class Initialized
INFO - 2025-01-31 08:39:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:39:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:39:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:39:24 --> URI Class Initialized
INFO - 2025-01-31 08:39:24 --> Router Class Initialized
INFO - 2025-01-31 08:39:24 --> Output Class Initialized
INFO - 2025-01-31 08:39:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:39:24 --> Input Class Initialized
INFO - 2025-01-31 08:39:24 --> Language Class Initialized
INFO - 2025-01-31 08:39:24 --> Loader Class Initialized
INFO - 2025-01-31 08:39:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:39:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:39:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:39:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:39:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:39:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:39:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:39:24 --> Upload Class Initialized
INFO - 2025-01-31 08:39:24 --> Email Class Initialized
INFO - 2025-01-31 08:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:39:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:39:24 --> Controller Class Initialized
INFO - 2025-01-31 14:09:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:09:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:09:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:40:24 --> Config Class Initialized
INFO - 2025-01-31 08:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:40:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:40:24 --> URI Class Initialized
INFO - 2025-01-31 08:40:24 --> Router Class Initialized
INFO - 2025-01-31 08:40:24 --> Output Class Initialized
INFO - 2025-01-31 08:40:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:40:24 --> Input Class Initialized
INFO - 2025-01-31 08:40:24 --> Language Class Initialized
INFO - 2025-01-31 08:40:24 --> Loader Class Initialized
INFO - 2025-01-31 08:40:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:40:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:40:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:40:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:40:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:40:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:40:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:40:24 --> Upload Class Initialized
INFO - 2025-01-31 08:40:24 --> Email Class Initialized
INFO - 2025-01-31 08:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:40:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:40:24 --> Controller Class Initialized
INFO - 2025-01-31 14:10:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:10:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:10:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:41:24 --> Config Class Initialized
INFO - 2025-01-31 08:41:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:41:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:41:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:41:24 --> URI Class Initialized
INFO - 2025-01-31 08:41:24 --> Router Class Initialized
INFO - 2025-01-31 08:41:24 --> Output Class Initialized
INFO - 2025-01-31 08:41:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:41:24 --> Input Class Initialized
INFO - 2025-01-31 08:41:24 --> Language Class Initialized
INFO - 2025-01-31 08:41:24 --> Loader Class Initialized
INFO - 2025-01-31 08:41:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:41:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:41:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:41:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:41:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:41:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:41:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:41:24 --> Upload Class Initialized
INFO - 2025-01-31 08:41:24 --> Email Class Initialized
INFO - 2025-01-31 08:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:41:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:41:24 --> Controller Class Initialized
INFO - 2025-01-31 14:11:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:11:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:11:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:42:24 --> Config Class Initialized
INFO - 2025-01-31 08:42:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:42:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:42:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:42:24 --> URI Class Initialized
INFO - 2025-01-31 08:42:24 --> Router Class Initialized
INFO - 2025-01-31 08:42:24 --> Output Class Initialized
INFO - 2025-01-31 08:42:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:42:24 --> Input Class Initialized
INFO - 2025-01-31 08:42:24 --> Language Class Initialized
INFO - 2025-01-31 08:42:24 --> Loader Class Initialized
INFO - 2025-01-31 08:42:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:42:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:42:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:42:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:42:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:42:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:42:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:42:24 --> Upload Class Initialized
INFO - 2025-01-31 08:42:24 --> Email Class Initialized
INFO - 2025-01-31 08:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:42:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:42:24 --> Controller Class Initialized
INFO - 2025-01-31 14:12:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:12:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:12:24 --> Pagination Class Initialized
INFO - 2025-01-31 08:43:24 --> Config Class Initialized
INFO - 2025-01-31 08:43:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 08:43:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 08:43:24 --> Utf8 Class Initialized
INFO - 2025-01-31 08:43:24 --> URI Class Initialized
INFO - 2025-01-31 08:43:24 --> Router Class Initialized
INFO - 2025-01-31 08:43:24 --> Output Class Initialized
INFO - 2025-01-31 08:43:24 --> Security Class Initialized
DEBUG - 2025-01-31 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 08:43:24 --> Input Class Initialized
INFO - 2025-01-31 08:43:24 --> Language Class Initialized
INFO - 2025-01-31 08:43:24 --> Loader Class Initialized
INFO - 2025-01-31 08:43:24 --> Helper loaded: url_helper
INFO - 2025-01-31 08:43:24 --> Helper loaded: html_helper
INFO - 2025-01-31 08:43:24 --> Helper loaded: file_helper
INFO - 2025-01-31 08:43:24 --> Helper loaded: string_helper
INFO - 2025-01-31 08:43:24 --> Helper loaded: form_helper
INFO - 2025-01-31 08:43:24 --> Helper loaded: my_helper
INFO - 2025-01-31 08:43:24 --> Database Driver Class Initialized
INFO - 2025-01-31 08:43:24 --> Upload Class Initialized
INFO - 2025-01-31 08:43:24 --> Email Class Initialized
INFO - 2025-01-31 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 08:43:24 --> Form Validation Class Initialized
INFO - 2025-01-31 08:43:24 --> Controller Class Initialized
INFO - 2025-01-31 14:13:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:13:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:13:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:24:03 --> Config Class Initialized
INFO - 2025-01-31 09:24:03 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:24:03 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:24:03 --> Utf8 Class Initialized
INFO - 2025-01-31 09:24:03 --> URI Class Initialized
INFO - 2025-01-31 09:24:03 --> Router Class Initialized
INFO - 2025-01-31 09:24:03 --> Output Class Initialized
INFO - 2025-01-31 09:24:03 --> Security Class Initialized
DEBUG - 2025-01-31 09:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:24:03 --> Input Class Initialized
INFO - 2025-01-31 09:24:03 --> Language Class Initialized
INFO - 2025-01-31 09:24:03 --> Loader Class Initialized
INFO - 2025-01-31 09:24:03 --> Helper loaded: url_helper
INFO - 2025-01-31 09:24:03 --> Helper loaded: html_helper
INFO - 2025-01-31 09:24:03 --> Helper loaded: file_helper
INFO - 2025-01-31 09:24:03 --> Helper loaded: string_helper
INFO - 2025-01-31 09:24:03 --> Helper loaded: form_helper
INFO - 2025-01-31 09:24:03 --> Helper loaded: my_helper
INFO - 2025-01-31 09:24:03 --> Database Driver Class Initialized
INFO - 2025-01-31 09:24:03 --> Upload Class Initialized
INFO - 2025-01-31 09:24:03 --> Email Class Initialized
INFO - 2025-01-31 09:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:24:03 --> Form Validation Class Initialized
INFO - 2025-01-31 09:24:03 --> Controller Class Initialized
INFO - 2025-01-31 14:54:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:54:03 --> Model "MainModel" initialized
INFO - 2025-01-31 14:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:54:03 --> Pagination Class Initialized
INFO - 2025-01-31 09:24:24 --> Config Class Initialized
INFO - 2025-01-31 09:24:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:24:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:24:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:24:24 --> URI Class Initialized
INFO - 2025-01-31 09:24:24 --> Router Class Initialized
INFO - 2025-01-31 09:24:24 --> Output Class Initialized
INFO - 2025-01-31 09:24:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:24:24 --> Input Class Initialized
INFO - 2025-01-31 09:24:24 --> Language Class Initialized
INFO - 2025-01-31 09:24:24 --> Loader Class Initialized
INFO - 2025-01-31 09:24:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:24:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:24:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:24:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:24:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:24:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:24:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:24:24 --> Upload Class Initialized
INFO - 2025-01-31 09:24:24 --> Email Class Initialized
INFO - 2025-01-31 09:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:24:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:24:24 --> Controller Class Initialized
INFO - 2025-01-31 14:54:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:54:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:54:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:25:24 --> Config Class Initialized
INFO - 2025-01-31 09:25:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:25:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:25:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:25:24 --> URI Class Initialized
INFO - 2025-01-31 09:25:24 --> Router Class Initialized
INFO - 2025-01-31 09:25:24 --> Output Class Initialized
INFO - 2025-01-31 09:25:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:25:24 --> Input Class Initialized
INFO - 2025-01-31 09:25:24 --> Language Class Initialized
INFO - 2025-01-31 09:25:24 --> Loader Class Initialized
INFO - 2025-01-31 09:25:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:25:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:25:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:25:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:25:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:25:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:25:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:25:24 --> Upload Class Initialized
INFO - 2025-01-31 09:25:24 --> Email Class Initialized
INFO - 2025-01-31 09:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:25:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:25:24 --> Controller Class Initialized
INFO - 2025-01-31 14:55:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:55:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:55:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:26:24 --> Config Class Initialized
INFO - 2025-01-31 09:26:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:26:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:26:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:26:24 --> URI Class Initialized
INFO - 2025-01-31 09:26:24 --> Router Class Initialized
INFO - 2025-01-31 09:26:24 --> Output Class Initialized
INFO - 2025-01-31 09:26:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:26:24 --> Input Class Initialized
INFO - 2025-01-31 09:26:24 --> Language Class Initialized
INFO - 2025-01-31 09:26:24 --> Loader Class Initialized
INFO - 2025-01-31 09:26:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:26:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:26:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:26:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:26:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:26:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:26:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:26:24 --> Upload Class Initialized
INFO - 2025-01-31 09:26:24 --> Email Class Initialized
INFO - 2025-01-31 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:26:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:26:24 --> Controller Class Initialized
INFO - 2025-01-31 14:56:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:56:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:56:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:27:24 --> Config Class Initialized
INFO - 2025-01-31 09:27:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:27:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:27:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:27:24 --> URI Class Initialized
INFO - 2025-01-31 09:27:24 --> Router Class Initialized
INFO - 2025-01-31 09:27:24 --> Output Class Initialized
INFO - 2025-01-31 09:27:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:27:24 --> Input Class Initialized
INFO - 2025-01-31 09:27:24 --> Language Class Initialized
INFO - 2025-01-31 09:27:24 --> Loader Class Initialized
INFO - 2025-01-31 09:27:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:27:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:27:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:27:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:27:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:27:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:27:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:27:24 --> Upload Class Initialized
INFO - 2025-01-31 09:27:24 --> Email Class Initialized
INFO - 2025-01-31 09:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:27:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:27:24 --> Controller Class Initialized
INFO - 2025-01-31 14:57:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:57:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:57:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:28:24 --> Config Class Initialized
INFO - 2025-01-31 09:28:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:28:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:28:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:28:24 --> URI Class Initialized
INFO - 2025-01-31 09:28:24 --> Router Class Initialized
INFO - 2025-01-31 09:28:24 --> Output Class Initialized
INFO - 2025-01-31 09:28:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:28:24 --> Input Class Initialized
INFO - 2025-01-31 09:28:24 --> Language Class Initialized
INFO - 2025-01-31 09:28:24 --> Loader Class Initialized
INFO - 2025-01-31 09:28:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:28:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:28:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:28:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:28:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:28:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:28:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:28:24 --> Upload Class Initialized
INFO - 2025-01-31 09:28:24 --> Email Class Initialized
INFO - 2025-01-31 09:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:28:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:28:24 --> Controller Class Initialized
INFO - 2025-01-31 14:58:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:58:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:58:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:29:24 --> Config Class Initialized
INFO - 2025-01-31 09:29:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:29:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:29:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:29:24 --> URI Class Initialized
INFO - 2025-01-31 09:29:24 --> Router Class Initialized
INFO - 2025-01-31 09:29:24 --> Output Class Initialized
INFO - 2025-01-31 09:29:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:29:24 --> Input Class Initialized
INFO - 2025-01-31 09:29:24 --> Language Class Initialized
INFO - 2025-01-31 09:29:24 --> Loader Class Initialized
INFO - 2025-01-31 09:29:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:29:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:29:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:29:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:29:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:29:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:29:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:29:24 --> Upload Class Initialized
INFO - 2025-01-31 09:29:24 --> Email Class Initialized
INFO - 2025-01-31 09:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:29:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:29:24 --> Controller Class Initialized
INFO - 2025-01-31 14:59:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 14:59:24 --> Model "MainModel" initialized
INFO - 2025-01-31 14:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 14:59:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:30:24 --> Config Class Initialized
INFO - 2025-01-31 09:30:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:30:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:30:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:30:24 --> URI Class Initialized
INFO - 2025-01-31 09:30:24 --> Router Class Initialized
INFO - 2025-01-31 09:30:24 --> Output Class Initialized
INFO - 2025-01-31 09:30:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:30:24 --> Input Class Initialized
INFO - 2025-01-31 09:30:24 --> Language Class Initialized
INFO - 2025-01-31 09:30:24 --> Loader Class Initialized
INFO - 2025-01-31 09:30:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:30:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:30:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:30:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:30:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:30:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:30:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:30:24 --> Upload Class Initialized
INFO - 2025-01-31 09:30:24 --> Email Class Initialized
INFO - 2025-01-31 09:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:30:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:30:24 --> Controller Class Initialized
INFO - 2025-01-31 15:00:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:00:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:00:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:31:24 --> Config Class Initialized
INFO - 2025-01-31 09:31:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:31:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:31:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:31:24 --> URI Class Initialized
INFO - 2025-01-31 09:31:24 --> Router Class Initialized
INFO - 2025-01-31 09:31:24 --> Output Class Initialized
INFO - 2025-01-31 09:31:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:31:24 --> Input Class Initialized
INFO - 2025-01-31 09:31:24 --> Language Class Initialized
INFO - 2025-01-31 09:31:24 --> Loader Class Initialized
INFO - 2025-01-31 09:31:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:31:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:31:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:31:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:31:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:31:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:31:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:31:24 --> Upload Class Initialized
INFO - 2025-01-31 09:31:24 --> Email Class Initialized
INFO - 2025-01-31 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:31:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:31:24 --> Controller Class Initialized
INFO - 2025-01-31 15:01:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:01:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:01:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:32:24 --> Config Class Initialized
INFO - 2025-01-31 09:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:32:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:32:24 --> URI Class Initialized
INFO - 2025-01-31 09:32:24 --> Router Class Initialized
INFO - 2025-01-31 09:32:24 --> Output Class Initialized
INFO - 2025-01-31 09:32:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:32:24 --> Input Class Initialized
INFO - 2025-01-31 09:32:24 --> Language Class Initialized
INFO - 2025-01-31 09:32:24 --> Loader Class Initialized
INFO - 2025-01-31 09:32:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:32:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:32:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:32:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:32:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:32:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:32:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:32:24 --> Upload Class Initialized
INFO - 2025-01-31 09:32:24 --> Email Class Initialized
INFO - 2025-01-31 09:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:32:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:32:24 --> Controller Class Initialized
INFO - 2025-01-31 15:02:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:02:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:02:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:33:24 --> Config Class Initialized
INFO - 2025-01-31 09:33:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:33:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:33:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:33:24 --> URI Class Initialized
INFO - 2025-01-31 09:33:24 --> Router Class Initialized
INFO - 2025-01-31 09:33:24 --> Output Class Initialized
INFO - 2025-01-31 09:33:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:33:24 --> Input Class Initialized
INFO - 2025-01-31 09:33:24 --> Language Class Initialized
INFO - 2025-01-31 09:33:24 --> Loader Class Initialized
INFO - 2025-01-31 09:33:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:33:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:33:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:33:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:33:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:33:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:33:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:33:24 --> Upload Class Initialized
INFO - 2025-01-31 09:33:24 --> Email Class Initialized
INFO - 2025-01-31 09:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:33:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:33:24 --> Controller Class Initialized
INFO - 2025-01-31 15:03:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:03:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:03:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:34:24 --> Config Class Initialized
INFO - 2025-01-31 09:34:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:34:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:34:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:34:24 --> URI Class Initialized
INFO - 2025-01-31 09:34:24 --> Router Class Initialized
INFO - 2025-01-31 09:34:24 --> Output Class Initialized
INFO - 2025-01-31 09:34:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:34:24 --> Input Class Initialized
INFO - 2025-01-31 09:34:24 --> Language Class Initialized
INFO - 2025-01-31 09:34:24 --> Loader Class Initialized
INFO - 2025-01-31 09:34:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:34:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:34:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:34:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:34:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:34:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:34:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:34:24 --> Upload Class Initialized
INFO - 2025-01-31 09:34:24 --> Email Class Initialized
INFO - 2025-01-31 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:34:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:34:24 --> Controller Class Initialized
INFO - 2025-01-31 15:04:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:04:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:04:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:35:24 --> Config Class Initialized
INFO - 2025-01-31 09:35:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:35:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:35:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:35:24 --> URI Class Initialized
INFO - 2025-01-31 09:35:24 --> Router Class Initialized
INFO - 2025-01-31 09:35:24 --> Output Class Initialized
INFO - 2025-01-31 09:35:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:35:24 --> Input Class Initialized
INFO - 2025-01-31 09:35:24 --> Language Class Initialized
INFO - 2025-01-31 09:35:24 --> Loader Class Initialized
INFO - 2025-01-31 09:35:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:35:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:35:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:35:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:35:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:35:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:35:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:35:24 --> Upload Class Initialized
INFO - 2025-01-31 09:35:24 --> Email Class Initialized
INFO - 2025-01-31 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:35:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:35:24 --> Controller Class Initialized
INFO - 2025-01-31 15:05:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:05:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:05:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:36:24 --> Config Class Initialized
INFO - 2025-01-31 09:36:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:36:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:36:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:36:24 --> URI Class Initialized
INFO - 2025-01-31 09:36:24 --> Router Class Initialized
INFO - 2025-01-31 09:36:24 --> Output Class Initialized
INFO - 2025-01-31 09:36:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:36:24 --> Input Class Initialized
INFO - 2025-01-31 09:36:24 --> Language Class Initialized
INFO - 2025-01-31 09:36:24 --> Loader Class Initialized
INFO - 2025-01-31 09:36:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:36:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:36:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:36:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:36:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:36:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:36:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:36:24 --> Upload Class Initialized
INFO - 2025-01-31 09:36:24 --> Email Class Initialized
INFO - 2025-01-31 09:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:36:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:36:24 --> Controller Class Initialized
INFO - 2025-01-31 15:06:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:06:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:06:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:37:24 --> Config Class Initialized
INFO - 2025-01-31 09:37:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:37:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:37:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:37:24 --> URI Class Initialized
INFO - 2025-01-31 09:37:24 --> Router Class Initialized
INFO - 2025-01-31 09:37:24 --> Output Class Initialized
INFO - 2025-01-31 09:37:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:37:24 --> Input Class Initialized
INFO - 2025-01-31 09:37:24 --> Language Class Initialized
INFO - 2025-01-31 09:37:24 --> Loader Class Initialized
INFO - 2025-01-31 09:37:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:37:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:37:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:37:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:37:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:37:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:37:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:37:24 --> Upload Class Initialized
INFO - 2025-01-31 09:37:24 --> Email Class Initialized
INFO - 2025-01-31 09:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:37:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:37:24 --> Controller Class Initialized
INFO - 2025-01-31 15:07:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:07:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:07:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:38:24 --> Config Class Initialized
INFO - 2025-01-31 09:38:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:38:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:38:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:38:24 --> URI Class Initialized
INFO - 2025-01-31 09:38:24 --> Router Class Initialized
INFO - 2025-01-31 09:38:24 --> Output Class Initialized
INFO - 2025-01-31 09:38:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:38:24 --> Input Class Initialized
INFO - 2025-01-31 09:38:24 --> Language Class Initialized
INFO - 2025-01-31 09:38:24 --> Loader Class Initialized
INFO - 2025-01-31 09:38:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:38:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:38:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:38:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:38:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:38:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:38:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:38:24 --> Upload Class Initialized
INFO - 2025-01-31 09:38:24 --> Email Class Initialized
INFO - 2025-01-31 09:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:38:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:38:24 --> Controller Class Initialized
INFO - 2025-01-31 15:08:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:08:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:08:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:39:24 --> Config Class Initialized
INFO - 2025-01-31 09:39:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:39:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:39:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:39:24 --> URI Class Initialized
INFO - 2025-01-31 09:39:24 --> Router Class Initialized
INFO - 2025-01-31 09:39:24 --> Output Class Initialized
INFO - 2025-01-31 09:39:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:39:24 --> Input Class Initialized
INFO - 2025-01-31 09:39:24 --> Language Class Initialized
INFO - 2025-01-31 09:39:24 --> Loader Class Initialized
INFO - 2025-01-31 09:39:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:39:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:39:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:39:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:39:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:39:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:39:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:39:24 --> Upload Class Initialized
INFO - 2025-01-31 09:39:24 --> Email Class Initialized
INFO - 2025-01-31 09:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:39:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:39:24 --> Controller Class Initialized
INFO - 2025-01-31 15:09:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:09:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:09:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:40:24 --> Config Class Initialized
INFO - 2025-01-31 09:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:40:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:40:24 --> URI Class Initialized
INFO - 2025-01-31 09:40:24 --> Router Class Initialized
INFO - 2025-01-31 09:40:24 --> Output Class Initialized
INFO - 2025-01-31 09:40:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:40:24 --> Input Class Initialized
INFO - 2025-01-31 09:40:24 --> Language Class Initialized
INFO - 2025-01-31 09:40:24 --> Loader Class Initialized
INFO - 2025-01-31 09:40:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:40:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:40:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:40:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:40:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:40:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:40:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:40:24 --> Upload Class Initialized
INFO - 2025-01-31 09:40:24 --> Email Class Initialized
INFO - 2025-01-31 09:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:40:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:40:24 --> Controller Class Initialized
INFO - 2025-01-31 15:10:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:10:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:10:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:41:24 --> Config Class Initialized
INFO - 2025-01-31 09:41:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:41:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:41:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:41:24 --> URI Class Initialized
INFO - 2025-01-31 09:41:24 --> Router Class Initialized
INFO - 2025-01-31 09:41:24 --> Output Class Initialized
INFO - 2025-01-31 09:41:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:41:24 --> Input Class Initialized
INFO - 2025-01-31 09:41:24 --> Language Class Initialized
INFO - 2025-01-31 09:41:24 --> Loader Class Initialized
INFO - 2025-01-31 09:41:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:41:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:41:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:41:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:41:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:41:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:41:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:41:24 --> Upload Class Initialized
INFO - 2025-01-31 09:41:24 --> Email Class Initialized
INFO - 2025-01-31 09:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:41:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:41:24 --> Controller Class Initialized
INFO - 2025-01-31 15:11:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:11:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:11:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:42:24 --> Config Class Initialized
INFO - 2025-01-31 09:42:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:42:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:42:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:42:24 --> URI Class Initialized
INFO - 2025-01-31 09:42:24 --> Router Class Initialized
INFO - 2025-01-31 09:42:24 --> Output Class Initialized
INFO - 2025-01-31 09:42:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:42:24 --> Input Class Initialized
INFO - 2025-01-31 09:42:24 --> Language Class Initialized
INFO - 2025-01-31 09:42:24 --> Loader Class Initialized
INFO - 2025-01-31 09:42:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:42:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:42:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:42:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:42:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:42:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:42:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:42:24 --> Upload Class Initialized
INFO - 2025-01-31 09:42:24 --> Email Class Initialized
INFO - 2025-01-31 09:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:42:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:42:24 --> Controller Class Initialized
INFO - 2025-01-31 15:12:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:12:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:12:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:43:24 --> Config Class Initialized
INFO - 2025-01-31 09:43:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:43:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:43:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:43:24 --> URI Class Initialized
INFO - 2025-01-31 09:43:24 --> Router Class Initialized
INFO - 2025-01-31 09:43:24 --> Output Class Initialized
INFO - 2025-01-31 09:43:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:43:24 --> Input Class Initialized
INFO - 2025-01-31 09:43:24 --> Language Class Initialized
INFO - 2025-01-31 09:43:24 --> Loader Class Initialized
INFO - 2025-01-31 09:43:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:43:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:43:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:43:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:43:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:43:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:43:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:43:24 --> Upload Class Initialized
INFO - 2025-01-31 09:43:24 --> Email Class Initialized
INFO - 2025-01-31 09:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:43:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:43:24 --> Controller Class Initialized
INFO - 2025-01-31 15:13:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:13:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:13:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:44:24 --> Config Class Initialized
INFO - 2025-01-31 09:44:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:44:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:44:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:44:24 --> URI Class Initialized
INFO - 2025-01-31 09:44:24 --> Router Class Initialized
INFO - 2025-01-31 09:44:24 --> Output Class Initialized
INFO - 2025-01-31 09:44:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:44:24 --> Input Class Initialized
INFO - 2025-01-31 09:44:24 --> Language Class Initialized
INFO - 2025-01-31 09:44:24 --> Loader Class Initialized
INFO - 2025-01-31 09:44:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:44:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:44:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:44:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:44:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:44:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:44:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:44:24 --> Upload Class Initialized
INFO - 2025-01-31 09:44:24 --> Email Class Initialized
INFO - 2025-01-31 09:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:44:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:44:24 --> Controller Class Initialized
INFO - 2025-01-31 15:14:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:14:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:14:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:45:24 --> Config Class Initialized
INFO - 2025-01-31 09:45:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:45:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:45:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:45:24 --> URI Class Initialized
INFO - 2025-01-31 09:45:24 --> Router Class Initialized
INFO - 2025-01-31 09:45:24 --> Output Class Initialized
INFO - 2025-01-31 09:45:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:45:24 --> Input Class Initialized
INFO - 2025-01-31 09:45:24 --> Language Class Initialized
INFO - 2025-01-31 09:45:24 --> Loader Class Initialized
INFO - 2025-01-31 09:45:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:45:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:45:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:45:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:45:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:45:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:45:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:45:24 --> Upload Class Initialized
INFO - 2025-01-31 09:45:24 --> Email Class Initialized
INFO - 2025-01-31 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:45:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:45:24 --> Controller Class Initialized
INFO - 2025-01-31 15:15:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:15:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:15:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:46:24 --> Config Class Initialized
INFO - 2025-01-31 09:46:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:46:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:46:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:46:24 --> URI Class Initialized
INFO - 2025-01-31 09:46:24 --> Router Class Initialized
INFO - 2025-01-31 09:46:24 --> Output Class Initialized
INFO - 2025-01-31 09:46:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:46:24 --> Input Class Initialized
INFO - 2025-01-31 09:46:24 --> Language Class Initialized
INFO - 2025-01-31 09:46:24 --> Loader Class Initialized
INFO - 2025-01-31 09:46:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:46:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:46:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:46:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:46:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:46:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:46:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:46:24 --> Upload Class Initialized
INFO - 2025-01-31 09:46:24 --> Email Class Initialized
INFO - 2025-01-31 09:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:46:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:46:24 --> Controller Class Initialized
INFO - 2025-01-31 15:16:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:16:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:16:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:47:24 --> Config Class Initialized
INFO - 2025-01-31 09:47:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:47:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:47:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:47:24 --> URI Class Initialized
INFO - 2025-01-31 09:47:24 --> Router Class Initialized
INFO - 2025-01-31 09:47:24 --> Output Class Initialized
INFO - 2025-01-31 09:47:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:47:24 --> Input Class Initialized
INFO - 2025-01-31 09:47:24 --> Language Class Initialized
INFO - 2025-01-31 09:47:24 --> Loader Class Initialized
INFO - 2025-01-31 09:47:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:47:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:47:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:47:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:47:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:47:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:47:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:47:24 --> Upload Class Initialized
INFO - 2025-01-31 09:47:24 --> Email Class Initialized
INFO - 2025-01-31 09:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:47:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:47:24 --> Controller Class Initialized
INFO - 2025-01-31 15:17:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:17:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:17:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:48:24 --> Config Class Initialized
INFO - 2025-01-31 09:48:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:48:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:48:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:48:24 --> URI Class Initialized
INFO - 2025-01-31 09:48:24 --> Router Class Initialized
INFO - 2025-01-31 09:48:24 --> Output Class Initialized
INFO - 2025-01-31 09:48:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:48:24 --> Input Class Initialized
INFO - 2025-01-31 09:48:24 --> Language Class Initialized
INFO - 2025-01-31 09:48:24 --> Loader Class Initialized
INFO - 2025-01-31 09:48:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:48:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:48:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:48:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:48:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:48:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:48:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:48:24 --> Upload Class Initialized
INFO - 2025-01-31 09:48:24 --> Email Class Initialized
INFO - 2025-01-31 09:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:48:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:48:24 --> Controller Class Initialized
INFO - 2025-01-31 15:18:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:18:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:18:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:49:24 --> Config Class Initialized
INFO - 2025-01-31 09:49:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:49:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:49:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:49:24 --> URI Class Initialized
INFO - 2025-01-31 09:49:24 --> Router Class Initialized
INFO - 2025-01-31 09:49:24 --> Output Class Initialized
INFO - 2025-01-31 09:49:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:49:24 --> Input Class Initialized
INFO - 2025-01-31 09:49:24 --> Language Class Initialized
INFO - 2025-01-31 09:49:24 --> Loader Class Initialized
INFO - 2025-01-31 09:49:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:49:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:49:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:49:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:49:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:49:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:49:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:49:24 --> Upload Class Initialized
INFO - 2025-01-31 09:49:24 --> Email Class Initialized
INFO - 2025-01-31 09:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:49:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:49:24 --> Controller Class Initialized
INFO - 2025-01-31 15:19:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:19:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:19:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:50:24 --> Config Class Initialized
INFO - 2025-01-31 09:50:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:50:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:50:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:50:24 --> URI Class Initialized
INFO - 2025-01-31 09:50:24 --> Router Class Initialized
INFO - 2025-01-31 09:50:24 --> Output Class Initialized
INFO - 2025-01-31 09:50:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:50:24 --> Input Class Initialized
INFO - 2025-01-31 09:50:24 --> Language Class Initialized
INFO - 2025-01-31 09:50:24 --> Loader Class Initialized
INFO - 2025-01-31 09:50:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:50:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:50:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:50:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:50:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:50:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:50:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:50:24 --> Upload Class Initialized
INFO - 2025-01-31 09:50:24 --> Email Class Initialized
INFO - 2025-01-31 09:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:50:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:50:24 --> Controller Class Initialized
INFO - 2025-01-31 15:20:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:20:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:20:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:51:24 --> Config Class Initialized
INFO - 2025-01-31 09:51:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:51:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:51:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:51:24 --> URI Class Initialized
INFO - 2025-01-31 09:51:24 --> Router Class Initialized
INFO - 2025-01-31 09:51:24 --> Output Class Initialized
INFO - 2025-01-31 09:51:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:51:24 --> Input Class Initialized
INFO - 2025-01-31 09:51:24 --> Language Class Initialized
INFO - 2025-01-31 09:51:24 --> Loader Class Initialized
INFO - 2025-01-31 09:51:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:51:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:51:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:51:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:51:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:51:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:51:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:51:24 --> Upload Class Initialized
INFO - 2025-01-31 09:51:24 --> Email Class Initialized
INFO - 2025-01-31 09:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:51:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:51:24 --> Controller Class Initialized
INFO - 2025-01-31 15:21:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:21:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:21:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:52:24 --> Config Class Initialized
INFO - 2025-01-31 09:52:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:52:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:52:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:52:24 --> URI Class Initialized
INFO - 2025-01-31 09:52:24 --> Router Class Initialized
INFO - 2025-01-31 09:52:24 --> Output Class Initialized
INFO - 2025-01-31 09:52:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:52:24 --> Input Class Initialized
INFO - 2025-01-31 09:52:24 --> Language Class Initialized
INFO - 2025-01-31 09:52:24 --> Loader Class Initialized
INFO - 2025-01-31 09:52:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:52:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:52:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:52:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:52:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:52:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:52:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:52:24 --> Upload Class Initialized
INFO - 2025-01-31 09:52:24 --> Email Class Initialized
INFO - 2025-01-31 09:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:52:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:52:24 --> Controller Class Initialized
INFO - 2025-01-31 15:22:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:22:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:22:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:53:24 --> Config Class Initialized
INFO - 2025-01-31 09:53:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:53:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:53:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:53:24 --> URI Class Initialized
INFO - 2025-01-31 09:53:24 --> Router Class Initialized
INFO - 2025-01-31 09:53:24 --> Output Class Initialized
INFO - 2025-01-31 09:53:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:53:24 --> Input Class Initialized
INFO - 2025-01-31 09:53:24 --> Language Class Initialized
INFO - 2025-01-31 09:53:24 --> Loader Class Initialized
INFO - 2025-01-31 09:53:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:53:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:53:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:53:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:53:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:53:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:53:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:53:24 --> Upload Class Initialized
INFO - 2025-01-31 09:53:24 --> Email Class Initialized
INFO - 2025-01-31 09:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:53:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:53:24 --> Controller Class Initialized
INFO - 2025-01-31 15:23:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:23:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:23:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:54:24 --> Config Class Initialized
INFO - 2025-01-31 09:54:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:54:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:54:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:54:24 --> URI Class Initialized
INFO - 2025-01-31 09:54:24 --> Router Class Initialized
INFO - 2025-01-31 09:54:24 --> Output Class Initialized
INFO - 2025-01-31 09:54:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:54:24 --> Input Class Initialized
INFO - 2025-01-31 09:54:24 --> Language Class Initialized
INFO - 2025-01-31 09:54:24 --> Loader Class Initialized
INFO - 2025-01-31 09:54:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:54:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:54:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:54:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:54:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:54:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:54:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:54:24 --> Upload Class Initialized
INFO - 2025-01-31 09:54:24 --> Email Class Initialized
INFO - 2025-01-31 09:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:54:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:54:24 --> Controller Class Initialized
INFO - 2025-01-31 15:24:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:24:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:24:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:55:24 --> Config Class Initialized
INFO - 2025-01-31 09:55:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:55:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:55:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:55:24 --> URI Class Initialized
INFO - 2025-01-31 09:55:24 --> Router Class Initialized
INFO - 2025-01-31 09:55:24 --> Output Class Initialized
INFO - 2025-01-31 09:55:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:55:24 --> Input Class Initialized
INFO - 2025-01-31 09:55:24 --> Language Class Initialized
INFO - 2025-01-31 09:55:24 --> Loader Class Initialized
INFO - 2025-01-31 09:55:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:55:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:55:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:55:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:55:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:55:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:55:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:55:24 --> Upload Class Initialized
INFO - 2025-01-31 09:55:24 --> Email Class Initialized
INFO - 2025-01-31 09:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:55:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:55:24 --> Controller Class Initialized
INFO - 2025-01-31 15:25:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:25:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:25:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:56:24 --> Config Class Initialized
INFO - 2025-01-31 09:56:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:56:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:56:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:56:24 --> URI Class Initialized
INFO - 2025-01-31 09:56:24 --> Router Class Initialized
INFO - 2025-01-31 09:56:24 --> Output Class Initialized
INFO - 2025-01-31 09:56:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:56:24 --> Input Class Initialized
INFO - 2025-01-31 09:56:24 --> Language Class Initialized
INFO - 2025-01-31 09:56:24 --> Loader Class Initialized
INFO - 2025-01-31 09:56:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:56:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:56:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:56:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:56:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:56:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:56:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:56:24 --> Upload Class Initialized
INFO - 2025-01-31 09:56:24 --> Email Class Initialized
INFO - 2025-01-31 09:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:56:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:56:24 --> Controller Class Initialized
INFO - 2025-01-31 15:26:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:26:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:26:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:57:24 --> Config Class Initialized
INFO - 2025-01-31 09:57:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:57:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:57:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:57:24 --> URI Class Initialized
INFO - 2025-01-31 09:57:24 --> Router Class Initialized
INFO - 2025-01-31 09:57:24 --> Output Class Initialized
INFO - 2025-01-31 09:57:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:57:24 --> Input Class Initialized
INFO - 2025-01-31 09:57:24 --> Language Class Initialized
INFO - 2025-01-31 09:57:24 --> Loader Class Initialized
INFO - 2025-01-31 09:57:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:57:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:57:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:57:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:57:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:57:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:57:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:57:24 --> Upload Class Initialized
INFO - 2025-01-31 09:57:24 --> Email Class Initialized
INFO - 2025-01-31 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:57:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:57:24 --> Controller Class Initialized
INFO - 2025-01-31 15:27:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:27:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:27:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:58:24 --> Config Class Initialized
INFO - 2025-01-31 09:58:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:58:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:58:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:58:24 --> URI Class Initialized
INFO - 2025-01-31 09:58:24 --> Router Class Initialized
INFO - 2025-01-31 09:58:24 --> Output Class Initialized
INFO - 2025-01-31 09:58:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:58:24 --> Input Class Initialized
INFO - 2025-01-31 09:58:24 --> Language Class Initialized
INFO - 2025-01-31 09:58:24 --> Loader Class Initialized
INFO - 2025-01-31 09:58:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:58:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:58:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:58:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:58:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:58:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:58:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:58:24 --> Upload Class Initialized
INFO - 2025-01-31 09:58:24 --> Email Class Initialized
INFO - 2025-01-31 09:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:58:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:58:24 --> Controller Class Initialized
INFO - 2025-01-31 15:28:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:28:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:28:24 --> Pagination Class Initialized
INFO - 2025-01-31 09:59:24 --> Config Class Initialized
INFO - 2025-01-31 09:59:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 09:59:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 09:59:24 --> Utf8 Class Initialized
INFO - 2025-01-31 09:59:24 --> URI Class Initialized
INFO - 2025-01-31 09:59:24 --> Router Class Initialized
INFO - 2025-01-31 09:59:24 --> Output Class Initialized
INFO - 2025-01-31 09:59:24 --> Security Class Initialized
DEBUG - 2025-01-31 09:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 09:59:24 --> Input Class Initialized
INFO - 2025-01-31 09:59:24 --> Language Class Initialized
INFO - 2025-01-31 09:59:24 --> Loader Class Initialized
INFO - 2025-01-31 09:59:24 --> Helper loaded: url_helper
INFO - 2025-01-31 09:59:24 --> Helper loaded: html_helper
INFO - 2025-01-31 09:59:24 --> Helper loaded: file_helper
INFO - 2025-01-31 09:59:24 --> Helper loaded: string_helper
INFO - 2025-01-31 09:59:24 --> Helper loaded: form_helper
INFO - 2025-01-31 09:59:24 --> Helper loaded: my_helper
INFO - 2025-01-31 09:59:24 --> Database Driver Class Initialized
INFO - 2025-01-31 09:59:24 --> Upload Class Initialized
INFO - 2025-01-31 09:59:24 --> Email Class Initialized
INFO - 2025-01-31 09:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 09:59:24 --> Form Validation Class Initialized
INFO - 2025-01-31 09:59:24 --> Controller Class Initialized
INFO - 2025-01-31 15:29:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:29:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:29:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:00:24 --> Config Class Initialized
INFO - 2025-01-31 10:00:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:00:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:00:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:00:24 --> URI Class Initialized
INFO - 2025-01-31 10:00:24 --> Router Class Initialized
INFO - 2025-01-31 10:00:24 --> Output Class Initialized
INFO - 2025-01-31 10:00:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:00:24 --> Input Class Initialized
INFO - 2025-01-31 10:00:24 --> Language Class Initialized
INFO - 2025-01-31 10:00:24 --> Loader Class Initialized
INFO - 2025-01-31 10:00:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:00:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:00:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:00:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:00:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:00:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:00:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:00:24 --> Upload Class Initialized
INFO - 2025-01-31 10:00:24 --> Email Class Initialized
INFO - 2025-01-31 10:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:00:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:00:24 --> Controller Class Initialized
INFO - 2025-01-31 15:30:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:30:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:30:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:01:24 --> Config Class Initialized
INFO - 2025-01-31 10:01:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:01:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:01:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:01:24 --> URI Class Initialized
INFO - 2025-01-31 10:01:24 --> Router Class Initialized
INFO - 2025-01-31 10:01:24 --> Output Class Initialized
INFO - 2025-01-31 10:01:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:01:24 --> Input Class Initialized
INFO - 2025-01-31 10:01:24 --> Language Class Initialized
INFO - 2025-01-31 10:01:24 --> Loader Class Initialized
INFO - 2025-01-31 10:01:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:01:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:01:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:01:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:01:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:01:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:01:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:01:24 --> Upload Class Initialized
INFO - 2025-01-31 10:01:24 --> Email Class Initialized
INFO - 2025-01-31 10:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:01:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:01:24 --> Controller Class Initialized
INFO - 2025-01-31 15:31:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:31:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:31:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:02:24 --> Config Class Initialized
INFO - 2025-01-31 10:02:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:02:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:02:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:02:24 --> URI Class Initialized
INFO - 2025-01-31 10:02:24 --> Router Class Initialized
INFO - 2025-01-31 10:02:24 --> Output Class Initialized
INFO - 2025-01-31 10:02:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:02:24 --> Input Class Initialized
INFO - 2025-01-31 10:02:24 --> Language Class Initialized
INFO - 2025-01-31 10:02:24 --> Loader Class Initialized
INFO - 2025-01-31 10:02:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:02:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:02:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:02:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:02:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:02:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:02:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:02:24 --> Upload Class Initialized
INFO - 2025-01-31 10:02:24 --> Email Class Initialized
INFO - 2025-01-31 10:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:02:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:02:24 --> Controller Class Initialized
INFO - 2025-01-31 15:32:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:32:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:32:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:03:24 --> Config Class Initialized
INFO - 2025-01-31 10:03:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:03:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:03:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:03:24 --> URI Class Initialized
INFO - 2025-01-31 10:03:24 --> Router Class Initialized
INFO - 2025-01-31 10:03:24 --> Output Class Initialized
INFO - 2025-01-31 10:03:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:03:24 --> Input Class Initialized
INFO - 2025-01-31 10:03:24 --> Language Class Initialized
INFO - 2025-01-31 10:03:24 --> Loader Class Initialized
INFO - 2025-01-31 10:03:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:03:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:03:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:03:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:03:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:03:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:03:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:03:24 --> Upload Class Initialized
INFO - 2025-01-31 10:03:24 --> Email Class Initialized
INFO - 2025-01-31 10:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:03:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:03:24 --> Controller Class Initialized
INFO - 2025-01-31 15:33:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:33:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:33:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:04:24 --> Config Class Initialized
INFO - 2025-01-31 10:04:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:04:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:04:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:04:24 --> URI Class Initialized
INFO - 2025-01-31 10:04:24 --> Router Class Initialized
INFO - 2025-01-31 10:04:24 --> Output Class Initialized
INFO - 2025-01-31 10:04:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:04:24 --> Input Class Initialized
INFO - 2025-01-31 10:04:24 --> Language Class Initialized
INFO - 2025-01-31 10:04:24 --> Loader Class Initialized
INFO - 2025-01-31 10:04:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:04:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:04:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:04:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:04:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:04:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:04:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:04:24 --> Upload Class Initialized
INFO - 2025-01-31 10:04:24 --> Email Class Initialized
INFO - 2025-01-31 10:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:04:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:04:24 --> Controller Class Initialized
INFO - 2025-01-31 15:34:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:34:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:34:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:05:24 --> Config Class Initialized
INFO - 2025-01-31 10:05:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:05:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:05:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:05:24 --> URI Class Initialized
INFO - 2025-01-31 10:05:24 --> Router Class Initialized
INFO - 2025-01-31 10:05:24 --> Output Class Initialized
INFO - 2025-01-31 10:05:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:05:24 --> Input Class Initialized
INFO - 2025-01-31 10:05:24 --> Language Class Initialized
INFO - 2025-01-31 10:05:24 --> Loader Class Initialized
INFO - 2025-01-31 10:05:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:05:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:05:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:05:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:05:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:05:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:05:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:05:24 --> Upload Class Initialized
INFO - 2025-01-31 10:05:24 --> Email Class Initialized
INFO - 2025-01-31 10:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:05:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:05:24 --> Controller Class Initialized
INFO - 2025-01-31 15:35:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:35:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:35:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:06:24 --> Config Class Initialized
INFO - 2025-01-31 10:06:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:06:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:06:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:06:24 --> URI Class Initialized
INFO - 2025-01-31 10:06:24 --> Router Class Initialized
INFO - 2025-01-31 10:06:24 --> Output Class Initialized
INFO - 2025-01-31 10:06:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:06:24 --> Input Class Initialized
INFO - 2025-01-31 10:06:24 --> Language Class Initialized
INFO - 2025-01-31 10:06:24 --> Loader Class Initialized
INFO - 2025-01-31 10:06:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:06:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:06:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:06:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:06:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:06:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:06:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:06:24 --> Upload Class Initialized
INFO - 2025-01-31 10:06:24 --> Email Class Initialized
INFO - 2025-01-31 10:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:06:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:06:24 --> Controller Class Initialized
INFO - 2025-01-31 15:36:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:36:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:36:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:07:24 --> Config Class Initialized
INFO - 2025-01-31 10:07:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:07:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:07:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:07:24 --> URI Class Initialized
INFO - 2025-01-31 10:07:24 --> Router Class Initialized
INFO - 2025-01-31 10:07:24 --> Output Class Initialized
INFO - 2025-01-31 10:07:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:07:24 --> Input Class Initialized
INFO - 2025-01-31 10:07:24 --> Language Class Initialized
INFO - 2025-01-31 10:07:24 --> Loader Class Initialized
INFO - 2025-01-31 10:07:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:07:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:07:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:07:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:07:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:07:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:07:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:07:24 --> Upload Class Initialized
INFO - 2025-01-31 10:07:24 --> Email Class Initialized
INFO - 2025-01-31 10:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:07:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:07:24 --> Controller Class Initialized
INFO - 2025-01-31 15:37:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:37:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:37:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:08:24 --> Config Class Initialized
INFO - 2025-01-31 10:08:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:08:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:08:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:08:24 --> URI Class Initialized
INFO - 2025-01-31 10:08:24 --> Router Class Initialized
INFO - 2025-01-31 10:08:24 --> Output Class Initialized
INFO - 2025-01-31 10:08:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:08:24 --> Input Class Initialized
INFO - 2025-01-31 10:08:24 --> Language Class Initialized
INFO - 2025-01-31 10:08:24 --> Loader Class Initialized
INFO - 2025-01-31 10:08:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:08:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:08:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:08:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:08:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:08:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:08:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:08:24 --> Upload Class Initialized
INFO - 2025-01-31 10:08:24 --> Email Class Initialized
INFO - 2025-01-31 10:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:08:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:08:24 --> Controller Class Initialized
INFO - 2025-01-31 15:38:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:38:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:38:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:09:24 --> Config Class Initialized
INFO - 2025-01-31 10:09:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:09:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:09:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:09:24 --> URI Class Initialized
INFO - 2025-01-31 10:09:24 --> Router Class Initialized
INFO - 2025-01-31 10:09:24 --> Output Class Initialized
INFO - 2025-01-31 10:09:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:09:24 --> Input Class Initialized
INFO - 2025-01-31 10:09:24 --> Language Class Initialized
INFO - 2025-01-31 10:09:24 --> Loader Class Initialized
INFO - 2025-01-31 10:09:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:09:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:09:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:09:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:09:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:09:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:09:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:09:24 --> Upload Class Initialized
INFO - 2025-01-31 10:09:24 --> Email Class Initialized
INFO - 2025-01-31 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:09:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:09:24 --> Controller Class Initialized
INFO - 2025-01-31 15:39:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:39:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:39:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:10:24 --> Config Class Initialized
INFO - 2025-01-31 10:10:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:10:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:10:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:10:24 --> URI Class Initialized
INFO - 2025-01-31 10:10:24 --> Router Class Initialized
INFO - 2025-01-31 10:10:24 --> Output Class Initialized
INFO - 2025-01-31 10:10:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:10:24 --> Input Class Initialized
INFO - 2025-01-31 10:10:24 --> Language Class Initialized
INFO - 2025-01-31 10:10:24 --> Loader Class Initialized
INFO - 2025-01-31 10:10:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:10:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:10:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:10:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:10:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:10:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:10:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:10:24 --> Upload Class Initialized
INFO - 2025-01-31 10:10:24 --> Email Class Initialized
INFO - 2025-01-31 10:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:10:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:10:24 --> Controller Class Initialized
INFO - 2025-01-31 15:40:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:40:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:40:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:11:24 --> Config Class Initialized
INFO - 2025-01-31 10:11:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:11:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:11:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:11:24 --> URI Class Initialized
INFO - 2025-01-31 10:11:24 --> Router Class Initialized
INFO - 2025-01-31 10:11:24 --> Output Class Initialized
INFO - 2025-01-31 10:11:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:11:24 --> Input Class Initialized
INFO - 2025-01-31 10:11:24 --> Language Class Initialized
INFO - 2025-01-31 10:11:24 --> Loader Class Initialized
INFO - 2025-01-31 10:11:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:11:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:11:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:11:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:11:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:11:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:11:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:11:24 --> Upload Class Initialized
INFO - 2025-01-31 10:11:24 --> Email Class Initialized
INFO - 2025-01-31 10:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:11:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:11:24 --> Controller Class Initialized
INFO - 2025-01-31 15:41:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:41:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:41:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:12:24 --> Config Class Initialized
INFO - 2025-01-31 10:12:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:12:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:12:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:12:24 --> URI Class Initialized
INFO - 2025-01-31 10:12:24 --> Router Class Initialized
INFO - 2025-01-31 10:12:24 --> Output Class Initialized
INFO - 2025-01-31 10:12:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:12:24 --> Input Class Initialized
INFO - 2025-01-31 10:12:24 --> Language Class Initialized
INFO - 2025-01-31 10:12:24 --> Loader Class Initialized
INFO - 2025-01-31 10:12:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:12:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:12:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:12:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:12:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:12:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:12:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:12:24 --> Upload Class Initialized
INFO - 2025-01-31 10:12:24 --> Email Class Initialized
INFO - 2025-01-31 10:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:12:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:12:24 --> Controller Class Initialized
INFO - 2025-01-31 15:42:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:42:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:42:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:13:24 --> Config Class Initialized
INFO - 2025-01-31 10:13:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:13:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:13:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:13:24 --> URI Class Initialized
INFO - 2025-01-31 10:13:24 --> Router Class Initialized
INFO - 2025-01-31 10:13:24 --> Output Class Initialized
INFO - 2025-01-31 10:13:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:13:24 --> Input Class Initialized
INFO - 2025-01-31 10:13:24 --> Language Class Initialized
INFO - 2025-01-31 10:13:24 --> Loader Class Initialized
INFO - 2025-01-31 10:13:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:13:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:13:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:13:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:13:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:13:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:13:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:13:24 --> Upload Class Initialized
INFO - 2025-01-31 10:13:24 --> Email Class Initialized
INFO - 2025-01-31 10:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:13:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:13:24 --> Controller Class Initialized
INFO - 2025-01-31 15:43:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:43:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:43:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:14:24 --> Config Class Initialized
INFO - 2025-01-31 10:14:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:14:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:14:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:14:24 --> URI Class Initialized
INFO - 2025-01-31 10:14:24 --> Router Class Initialized
INFO - 2025-01-31 10:14:24 --> Output Class Initialized
INFO - 2025-01-31 10:14:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:14:24 --> Input Class Initialized
INFO - 2025-01-31 10:14:24 --> Language Class Initialized
INFO - 2025-01-31 10:14:24 --> Loader Class Initialized
INFO - 2025-01-31 10:14:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:14:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:14:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:14:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:14:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:14:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:14:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:14:24 --> Upload Class Initialized
INFO - 2025-01-31 10:14:24 --> Email Class Initialized
INFO - 2025-01-31 10:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:14:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:14:24 --> Controller Class Initialized
INFO - 2025-01-31 15:44:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:44:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:44:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:15:24 --> Config Class Initialized
INFO - 2025-01-31 10:15:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:15:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:15:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:15:24 --> URI Class Initialized
INFO - 2025-01-31 10:15:24 --> Router Class Initialized
INFO - 2025-01-31 10:15:24 --> Output Class Initialized
INFO - 2025-01-31 10:15:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:15:24 --> Input Class Initialized
INFO - 2025-01-31 10:15:24 --> Language Class Initialized
INFO - 2025-01-31 10:15:24 --> Loader Class Initialized
INFO - 2025-01-31 10:15:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:15:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:15:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:15:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:15:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:15:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:15:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:15:24 --> Upload Class Initialized
INFO - 2025-01-31 10:15:24 --> Email Class Initialized
INFO - 2025-01-31 10:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:15:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:15:24 --> Controller Class Initialized
INFO - 2025-01-31 15:45:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:45:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:45:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:16:24 --> Config Class Initialized
INFO - 2025-01-31 10:16:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:16:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:16:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:16:24 --> URI Class Initialized
INFO - 2025-01-31 10:16:24 --> Router Class Initialized
INFO - 2025-01-31 10:16:24 --> Output Class Initialized
INFO - 2025-01-31 10:16:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:16:24 --> Input Class Initialized
INFO - 2025-01-31 10:16:24 --> Language Class Initialized
INFO - 2025-01-31 10:16:24 --> Loader Class Initialized
INFO - 2025-01-31 10:16:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:16:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:16:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:16:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:16:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:16:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:16:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:16:24 --> Upload Class Initialized
INFO - 2025-01-31 10:16:24 --> Email Class Initialized
INFO - 2025-01-31 10:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:16:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:16:24 --> Controller Class Initialized
INFO - 2025-01-31 15:46:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:46:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:46:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:17:24 --> Config Class Initialized
INFO - 2025-01-31 10:17:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:17:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:17:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:17:24 --> URI Class Initialized
INFO - 2025-01-31 10:17:24 --> Router Class Initialized
INFO - 2025-01-31 10:17:24 --> Output Class Initialized
INFO - 2025-01-31 10:17:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:17:24 --> Input Class Initialized
INFO - 2025-01-31 10:17:24 --> Language Class Initialized
INFO - 2025-01-31 10:17:24 --> Loader Class Initialized
INFO - 2025-01-31 10:17:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:17:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:17:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:17:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:17:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:17:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:17:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:17:24 --> Upload Class Initialized
INFO - 2025-01-31 10:17:24 --> Email Class Initialized
INFO - 2025-01-31 10:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:17:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:17:24 --> Controller Class Initialized
INFO - 2025-01-31 15:47:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:47:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:47:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:18:24 --> Config Class Initialized
INFO - 2025-01-31 10:18:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:18:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:18:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:18:24 --> URI Class Initialized
INFO - 2025-01-31 10:18:24 --> Router Class Initialized
INFO - 2025-01-31 10:18:24 --> Output Class Initialized
INFO - 2025-01-31 10:18:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:18:24 --> Input Class Initialized
INFO - 2025-01-31 10:18:24 --> Language Class Initialized
INFO - 2025-01-31 10:18:24 --> Loader Class Initialized
INFO - 2025-01-31 10:18:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:18:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:18:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:18:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:18:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:18:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:18:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:18:24 --> Upload Class Initialized
INFO - 2025-01-31 10:18:24 --> Email Class Initialized
INFO - 2025-01-31 10:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:18:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:18:24 --> Controller Class Initialized
INFO - 2025-01-31 15:48:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:48:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:48:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:19:24 --> Config Class Initialized
INFO - 2025-01-31 10:19:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:19:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:19:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:19:24 --> URI Class Initialized
INFO - 2025-01-31 10:19:24 --> Router Class Initialized
INFO - 2025-01-31 10:19:24 --> Output Class Initialized
INFO - 2025-01-31 10:19:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:19:24 --> Input Class Initialized
INFO - 2025-01-31 10:19:24 --> Language Class Initialized
INFO - 2025-01-31 10:19:24 --> Loader Class Initialized
INFO - 2025-01-31 10:19:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:19:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:19:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:19:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:19:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:19:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:19:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:19:24 --> Upload Class Initialized
INFO - 2025-01-31 10:19:24 --> Email Class Initialized
INFO - 2025-01-31 10:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:19:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:19:24 --> Controller Class Initialized
INFO - 2025-01-31 15:49:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:49:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:49:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:49:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:20:24 --> Config Class Initialized
INFO - 2025-01-31 10:20:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:20:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:20:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:20:24 --> URI Class Initialized
INFO - 2025-01-31 10:20:24 --> Router Class Initialized
INFO - 2025-01-31 10:20:24 --> Output Class Initialized
INFO - 2025-01-31 10:20:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:20:24 --> Input Class Initialized
INFO - 2025-01-31 10:20:24 --> Language Class Initialized
INFO - 2025-01-31 10:20:24 --> Loader Class Initialized
INFO - 2025-01-31 10:20:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:20:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:20:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:20:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:20:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:20:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:20:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:20:24 --> Upload Class Initialized
INFO - 2025-01-31 10:20:24 --> Email Class Initialized
INFO - 2025-01-31 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:20:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:20:24 --> Controller Class Initialized
INFO - 2025-01-31 15:50:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:50:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:50:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:50:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:21:24 --> Config Class Initialized
INFO - 2025-01-31 10:21:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:21:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:21:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:21:24 --> URI Class Initialized
INFO - 2025-01-31 10:21:24 --> Router Class Initialized
INFO - 2025-01-31 10:21:24 --> Output Class Initialized
INFO - 2025-01-31 10:21:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:21:24 --> Input Class Initialized
INFO - 2025-01-31 10:21:24 --> Language Class Initialized
INFO - 2025-01-31 10:21:24 --> Loader Class Initialized
INFO - 2025-01-31 10:21:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:21:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:21:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:21:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:21:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:21:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:21:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:21:24 --> Upload Class Initialized
INFO - 2025-01-31 10:21:24 --> Email Class Initialized
INFO - 2025-01-31 10:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:21:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:21:24 --> Controller Class Initialized
INFO - 2025-01-31 15:51:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:51:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:51:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:22:24 --> Config Class Initialized
INFO - 2025-01-31 10:22:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:22:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:22:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:22:24 --> URI Class Initialized
INFO - 2025-01-31 10:22:24 --> Router Class Initialized
INFO - 2025-01-31 10:22:24 --> Output Class Initialized
INFO - 2025-01-31 10:22:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:22:24 --> Input Class Initialized
INFO - 2025-01-31 10:22:24 --> Language Class Initialized
INFO - 2025-01-31 10:22:24 --> Loader Class Initialized
INFO - 2025-01-31 10:22:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:22:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:22:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:22:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:22:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:22:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:22:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:22:24 --> Upload Class Initialized
INFO - 2025-01-31 10:22:24 --> Email Class Initialized
INFO - 2025-01-31 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:22:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:22:24 --> Controller Class Initialized
INFO - 2025-01-31 15:52:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:52:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:52:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:23:24 --> Config Class Initialized
INFO - 2025-01-31 10:23:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:23:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:23:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:23:24 --> URI Class Initialized
INFO - 2025-01-31 10:23:24 --> Router Class Initialized
INFO - 2025-01-31 10:23:24 --> Output Class Initialized
INFO - 2025-01-31 10:23:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:23:24 --> Input Class Initialized
INFO - 2025-01-31 10:23:24 --> Language Class Initialized
INFO - 2025-01-31 10:23:24 --> Loader Class Initialized
INFO - 2025-01-31 10:23:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:23:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:23:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:23:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:23:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:23:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:23:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:23:24 --> Upload Class Initialized
INFO - 2025-01-31 10:23:24 --> Email Class Initialized
INFO - 2025-01-31 10:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:23:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:23:24 --> Controller Class Initialized
INFO - 2025-01-31 15:53:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:53:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:53:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:24:24 --> Config Class Initialized
INFO - 2025-01-31 10:24:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:24:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:24:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:24:24 --> URI Class Initialized
INFO - 2025-01-31 10:24:24 --> Router Class Initialized
INFO - 2025-01-31 10:24:24 --> Output Class Initialized
INFO - 2025-01-31 10:24:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:24:24 --> Input Class Initialized
INFO - 2025-01-31 10:24:24 --> Language Class Initialized
INFO - 2025-01-31 10:24:24 --> Loader Class Initialized
INFO - 2025-01-31 10:24:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:24:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:24:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:24:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:24:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:24:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:24:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:24:24 --> Upload Class Initialized
INFO - 2025-01-31 10:24:24 --> Email Class Initialized
INFO - 2025-01-31 10:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:24:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:24:24 --> Controller Class Initialized
INFO - 2025-01-31 15:54:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:54:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:54:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:25:24 --> Config Class Initialized
INFO - 2025-01-31 10:25:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:25:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:25:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:25:24 --> URI Class Initialized
INFO - 2025-01-31 10:25:24 --> Router Class Initialized
INFO - 2025-01-31 10:25:24 --> Output Class Initialized
INFO - 2025-01-31 10:25:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:25:24 --> Input Class Initialized
INFO - 2025-01-31 10:25:24 --> Language Class Initialized
INFO - 2025-01-31 10:25:24 --> Loader Class Initialized
INFO - 2025-01-31 10:25:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:25:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:25:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:25:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:25:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:25:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:25:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:25:24 --> Upload Class Initialized
INFO - 2025-01-31 10:25:24 --> Email Class Initialized
INFO - 2025-01-31 10:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:25:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:25:24 --> Controller Class Initialized
INFO - 2025-01-31 15:55:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:55:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:55:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:26:24 --> Config Class Initialized
INFO - 2025-01-31 10:26:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:26:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:26:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:26:24 --> URI Class Initialized
INFO - 2025-01-31 10:26:24 --> Router Class Initialized
INFO - 2025-01-31 10:26:24 --> Output Class Initialized
INFO - 2025-01-31 10:26:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:26:24 --> Input Class Initialized
INFO - 2025-01-31 10:26:24 --> Language Class Initialized
INFO - 2025-01-31 10:26:24 --> Loader Class Initialized
INFO - 2025-01-31 10:26:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:26:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:26:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:26:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:26:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:26:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:26:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:26:24 --> Upload Class Initialized
INFO - 2025-01-31 10:26:24 --> Email Class Initialized
INFO - 2025-01-31 10:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:26:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:26:24 --> Controller Class Initialized
INFO - 2025-01-31 15:56:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:56:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:56:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:27:24 --> Config Class Initialized
INFO - 2025-01-31 10:27:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:27:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:27:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:27:24 --> URI Class Initialized
INFO - 2025-01-31 10:27:24 --> Router Class Initialized
INFO - 2025-01-31 10:27:24 --> Output Class Initialized
INFO - 2025-01-31 10:27:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:27:24 --> Input Class Initialized
INFO - 2025-01-31 10:27:24 --> Language Class Initialized
INFO - 2025-01-31 10:27:24 --> Loader Class Initialized
INFO - 2025-01-31 10:27:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:27:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:27:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:27:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:27:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:27:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:27:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:27:24 --> Upload Class Initialized
INFO - 2025-01-31 10:27:24 --> Email Class Initialized
INFO - 2025-01-31 10:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:27:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:27:24 --> Controller Class Initialized
INFO - 2025-01-31 15:57:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:57:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:57:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:28:24 --> Config Class Initialized
INFO - 2025-01-31 10:28:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:28:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:28:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:28:24 --> URI Class Initialized
INFO - 2025-01-31 10:28:24 --> Router Class Initialized
INFO - 2025-01-31 10:28:24 --> Output Class Initialized
INFO - 2025-01-31 10:28:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:28:24 --> Input Class Initialized
INFO - 2025-01-31 10:28:24 --> Language Class Initialized
INFO - 2025-01-31 10:28:24 --> Loader Class Initialized
INFO - 2025-01-31 10:28:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:28:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:28:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:28:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:28:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:28:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:28:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:28:24 --> Upload Class Initialized
INFO - 2025-01-31 10:28:24 --> Email Class Initialized
INFO - 2025-01-31 10:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:28:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:28:24 --> Controller Class Initialized
INFO - 2025-01-31 15:58:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:58:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:58:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:29:24 --> Config Class Initialized
INFO - 2025-01-31 10:29:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:29:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:29:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:29:24 --> URI Class Initialized
INFO - 2025-01-31 10:29:24 --> Router Class Initialized
INFO - 2025-01-31 10:29:24 --> Output Class Initialized
INFO - 2025-01-31 10:29:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:29:24 --> Input Class Initialized
INFO - 2025-01-31 10:29:24 --> Language Class Initialized
INFO - 2025-01-31 10:29:24 --> Loader Class Initialized
INFO - 2025-01-31 10:29:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:29:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:29:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:29:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:29:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:29:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:29:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:29:24 --> Upload Class Initialized
INFO - 2025-01-31 10:29:24 --> Email Class Initialized
INFO - 2025-01-31 10:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:29:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:29:24 --> Controller Class Initialized
INFO - 2025-01-31 15:59:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 15:59:24 --> Model "MainModel" initialized
INFO - 2025-01-31 15:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 15:59:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:30:24 --> Config Class Initialized
INFO - 2025-01-31 10:30:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:30:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:30:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:30:24 --> URI Class Initialized
INFO - 2025-01-31 10:30:24 --> Router Class Initialized
INFO - 2025-01-31 10:30:24 --> Output Class Initialized
INFO - 2025-01-31 10:30:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:30:24 --> Input Class Initialized
INFO - 2025-01-31 10:30:24 --> Language Class Initialized
INFO - 2025-01-31 10:30:24 --> Loader Class Initialized
INFO - 2025-01-31 10:30:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:30:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:30:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:30:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:30:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:30:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:30:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:30:24 --> Upload Class Initialized
INFO - 2025-01-31 10:30:24 --> Email Class Initialized
INFO - 2025-01-31 10:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:30:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:30:24 --> Controller Class Initialized
INFO - 2025-01-31 16:00:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:00:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:00:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:31:24 --> Config Class Initialized
INFO - 2025-01-31 10:31:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:31:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:31:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:31:24 --> URI Class Initialized
INFO - 2025-01-31 10:31:24 --> Router Class Initialized
INFO - 2025-01-31 10:31:24 --> Output Class Initialized
INFO - 2025-01-31 10:31:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:31:24 --> Input Class Initialized
INFO - 2025-01-31 10:31:24 --> Language Class Initialized
INFO - 2025-01-31 10:31:24 --> Loader Class Initialized
INFO - 2025-01-31 10:31:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:31:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:31:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:31:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:31:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:31:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:31:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:31:24 --> Upload Class Initialized
INFO - 2025-01-31 10:31:24 --> Email Class Initialized
INFO - 2025-01-31 10:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:31:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:31:24 --> Controller Class Initialized
INFO - 2025-01-31 16:01:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:01:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:01:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:32:24 --> Config Class Initialized
INFO - 2025-01-31 10:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:32:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:32:24 --> URI Class Initialized
INFO - 2025-01-31 10:32:24 --> Router Class Initialized
INFO - 2025-01-31 10:32:24 --> Output Class Initialized
INFO - 2025-01-31 10:32:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:32:24 --> Input Class Initialized
INFO - 2025-01-31 10:32:24 --> Language Class Initialized
INFO - 2025-01-31 10:32:24 --> Loader Class Initialized
INFO - 2025-01-31 10:32:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:32:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:32:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:32:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:32:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:32:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:32:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:32:24 --> Upload Class Initialized
INFO - 2025-01-31 10:32:24 --> Email Class Initialized
INFO - 2025-01-31 10:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:32:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:32:24 --> Controller Class Initialized
INFO - 2025-01-31 16:02:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:02:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:02:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:33:24 --> Config Class Initialized
INFO - 2025-01-31 10:33:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:33:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:33:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:33:24 --> URI Class Initialized
INFO - 2025-01-31 10:33:24 --> Router Class Initialized
INFO - 2025-01-31 10:33:24 --> Output Class Initialized
INFO - 2025-01-31 10:33:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:33:24 --> Input Class Initialized
INFO - 2025-01-31 10:33:24 --> Language Class Initialized
INFO - 2025-01-31 10:33:24 --> Loader Class Initialized
INFO - 2025-01-31 10:33:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:33:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:33:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:33:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:33:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:33:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:33:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:33:24 --> Upload Class Initialized
INFO - 2025-01-31 10:33:24 --> Email Class Initialized
INFO - 2025-01-31 10:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:33:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:33:24 --> Controller Class Initialized
INFO - 2025-01-31 16:03:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:03:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:03:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:34:24 --> Config Class Initialized
INFO - 2025-01-31 10:34:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:34:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:34:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:34:24 --> URI Class Initialized
INFO - 2025-01-31 10:34:24 --> Router Class Initialized
INFO - 2025-01-31 10:34:24 --> Output Class Initialized
INFO - 2025-01-31 10:34:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:34:24 --> Input Class Initialized
INFO - 2025-01-31 10:34:24 --> Language Class Initialized
INFO - 2025-01-31 10:34:24 --> Loader Class Initialized
INFO - 2025-01-31 10:34:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:34:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:34:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:34:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:34:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:34:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:34:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:34:24 --> Upload Class Initialized
INFO - 2025-01-31 10:34:24 --> Email Class Initialized
INFO - 2025-01-31 10:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:34:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:34:24 --> Controller Class Initialized
INFO - 2025-01-31 16:04:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:04:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:04:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:35:24 --> Config Class Initialized
INFO - 2025-01-31 10:35:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:35:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:35:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:35:24 --> URI Class Initialized
INFO - 2025-01-31 10:35:24 --> Router Class Initialized
INFO - 2025-01-31 10:35:24 --> Output Class Initialized
INFO - 2025-01-31 10:35:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:35:24 --> Input Class Initialized
INFO - 2025-01-31 10:35:24 --> Language Class Initialized
INFO - 2025-01-31 10:35:24 --> Loader Class Initialized
INFO - 2025-01-31 10:35:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:35:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:35:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:35:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:35:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:35:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:35:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:35:24 --> Upload Class Initialized
INFO - 2025-01-31 10:35:24 --> Email Class Initialized
INFO - 2025-01-31 10:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:35:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:35:24 --> Controller Class Initialized
INFO - 2025-01-31 16:05:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:05:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:05:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:36:24 --> Config Class Initialized
INFO - 2025-01-31 10:36:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:36:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:36:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:36:24 --> URI Class Initialized
INFO - 2025-01-31 10:36:24 --> Router Class Initialized
INFO - 2025-01-31 10:36:24 --> Output Class Initialized
INFO - 2025-01-31 10:36:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:36:24 --> Input Class Initialized
INFO - 2025-01-31 10:36:24 --> Language Class Initialized
INFO - 2025-01-31 10:36:24 --> Loader Class Initialized
INFO - 2025-01-31 10:36:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:36:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:36:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:36:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:36:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:36:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:36:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:36:24 --> Upload Class Initialized
INFO - 2025-01-31 10:36:24 --> Email Class Initialized
INFO - 2025-01-31 10:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:36:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:36:24 --> Controller Class Initialized
INFO - 2025-01-31 16:06:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:06:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:06:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:37:24 --> Config Class Initialized
INFO - 2025-01-31 10:37:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:37:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:37:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:37:24 --> URI Class Initialized
INFO - 2025-01-31 10:37:24 --> Router Class Initialized
INFO - 2025-01-31 10:37:24 --> Output Class Initialized
INFO - 2025-01-31 10:37:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:37:24 --> Input Class Initialized
INFO - 2025-01-31 10:37:24 --> Language Class Initialized
INFO - 2025-01-31 10:37:24 --> Loader Class Initialized
INFO - 2025-01-31 10:37:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:37:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:37:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:37:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:37:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:37:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:37:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:37:24 --> Upload Class Initialized
INFO - 2025-01-31 10:37:24 --> Email Class Initialized
INFO - 2025-01-31 10:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:37:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:37:24 --> Controller Class Initialized
INFO - 2025-01-31 16:07:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:07:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:07:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:38:24 --> Config Class Initialized
INFO - 2025-01-31 10:38:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:38:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:38:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:38:24 --> URI Class Initialized
INFO - 2025-01-31 10:38:24 --> Router Class Initialized
INFO - 2025-01-31 10:38:24 --> Output Class Initialized
INFO - 2025-01-31 10:38:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:38:24 --> Input Class Initialized
INFO - 2025-01-31 10:38:24 --> Language Class Initialized
INFO - 2025-01-31 10:38:24 --> Loader Class Initialized
INFO - 2025-01-31 10:38:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:38:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:38:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:38:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:38:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:38:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:38:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:38:24 --> Upload Class Initialized
INFO - 2025-01-31 10:38:24 --> Email Class Initialized
INFO - 2025-01-31 10:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:38:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:38:24 --> Controller Class Initialized
INFO - 2025-01-31 16:08:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:08:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:08:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:39:24 --> Config Class Initialized
INFO - 2025-01-31 10:39:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:39:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:39:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:39:24 --> URI Class Initialized
INFO - 2025-01-31 10:39:24 --> Router Class Initialized
INFO - 2025-01-31 10:39:24 --> Output Class Initialized
INFO - 2025-01-31 10:39:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:39:24 --> Input Class Initialized
INFO - 2025-01-31 10:39:24 --> Language Class Initialized
INFO - 2025-01-31 10:39:24 --> Loader Class Initialized
INFO - 2025-01-31 10:39:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:39:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:39:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:39:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:39:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:39:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:39:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:39:24 --> Upload Class Initialized
INFO - 2025-01-31 10:39:24 --> Email Class Initialized
INFO - 2025-01-31 10:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:39:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:39:24 --> Controller Class Initialized
INFO - 2025-01-31 16:09:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:09:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:09:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:40:24 --> Config Class Initialized
INFO - 2025-01-31 10:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:40:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:40:24 --> URI Class Initialized
INFO - 2025-01-31 10:40:24 --> Router Class Initialized
INFO - 2025-01-31 10:40:24 --> Output Class Initialized
INFO - 2025-01-31 10:40:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:40:24 --> Input Class Initialized
INFO - 2025-01-31 10:40:24 --> Language Class Initialized
INFO - 2025-01-31 10:40:24 --> Loader Class Initialized
INFO - 2025-01-31 10:40:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:40:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:40:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:40:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:40:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:40:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:40:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:40:24 --> Upload Class Initialized
INFO - 2025-01-31 10:40:24 --> Email Class Initialized
INFO - 2025-01-31 10:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:40:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:40:24 --> Controller Class Initialized
INFO - 2025-01-31 16:10:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:10:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:10:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:41:24 --> Config Class Initialized
INFO - 2025-01-31 10:41:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:41:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:41:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:41:24 --> URI Class Initialized
INFO - 2025-01-31 10:41:24 --> Router Class Initialized
INFO - 2025-01-31 10:41:24 --> Output Class Initialized
INFO - 2025-01-31 10:41:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:41:24 --> Input Class Initialized
INFO - 2025-01-31 10:41:24 --> Language Class Initialized
INFO - 2025-01-31 10:41:24 --> Loader Class Initialized
INFO - 2025-01-31 10:41:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:41:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:41:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:41:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:41:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:41:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:41:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:41:24 --> Upload Class Initialized
INFO - 2025-01-31 10:41:24 --> Email Class Initialized
INFO - 2025-01-31 10:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:41:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:41:24 --> Controller Class Initialized
INFO - 2025-01-31 16:11:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:11:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:11:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:42:24 --> Config Class Initialized
INFO - 2025-01-31 10:42:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:42:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:42:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:42:24 --> URI Class Initialized
INFO - 2025-01-31 10:42:24 --> Router Class Initialized
INFO - 2025-01-31 10:42:24 --> Output Class Initialized
INFO - 2025-01-31 10:42:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:42:24 --> Input Class Initialized
INFO - 2025-01-31 10:42:24 --> Language Class Initialized
INFO - 2025-01-31 10:42:24 --> Loader Class Initialized
INFO - 2025-01-31 10:42:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:42:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:42:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:42:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:42:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:42:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:42:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:42:24 --> Upload Class Initialized
INFO - 2025-01-31 10:42:24 --> Email Class Initialized
INFO - 2025-01-31 10:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:42:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:42:24 --> Controller Class Initialized
INFO - 2025-01-31 16:12:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:12:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:12:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:43:24 --> Config Class Initialized
INFO - 2025-01-31 10:43:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:43:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:43:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:43:24 --> URI Class Initialized
INFO - 2025-01-31 10:43:24 --> Router Class Initialized
INFO - 2025-01-31 10:43:24 --> Output Class Initialized
INFO - 2025-01-31 10:43:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:43:24 --> Input Class Initialized
INFO - 2025-01-31 10:43:24 --> Language Class Initialized
INFO - 2025-01-31 10:43:24 --> Loader Class Initialized
INFO - 2025-01-31 10:43:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:43:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:43:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:43:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:43:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:43:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:43:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:43:24 --> Upload Class Initialized
INFO - 2025-01-31 10:43:24 --> Email Class Initialized
INFO - 2025-01-31 10:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:43:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:43:24 --> Controller Class Initialized
INFO - 2025-01-31 16:13:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:13:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:13:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:44:24 --> Config Class Initialized
INFO - 2025-01-31 10:44:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:44:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:44:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:44:24 --> URI Class Initialized
INFO - 2025-01-31 10:44:24 --> Router Class Initialized
INFO - 2025-01-31 10:44:24 --> Output Class Initialized
INFO - 2025-01-31 10:44:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:44:24 --> Input Class Initialized
INFO - 2025-01-31 10:44:24 --> Language Class Initialized
INFO - 2025-01-31 10:44:24 --> Loader Class Initialized
INFO - 2025-01-31 10:44:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:44:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:44:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:44:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:44:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:44:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:44:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:44:24 --> Upload Class Initialized
INFO - 2025-01-31 10:44:24 --> Email Class Initialized
INFO - 2025-01-31 10:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:44:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:44:24 --> Controller Class Initialized
INFO - 2025-01-31 16:14:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:14:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:14:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:45:24 --> Config Class Initialized
INFO - 2025-01-31 10:45:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:45:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:45:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:45:24 --> URI Class Initialized
INFO - 2025-01-31 10:45:24 --> Router Class Initialized
INFO - 2025-01-31 10:45:24 --> Output Class Initialized
INFO - 2025-01-31 10:45:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:45:24 --> Input Class Initialized
INFO - 2025-01-31 10:45:24 --> Language Class Initialized
INFO - 2025-01-31 10:45:24 --> Loader Class Initialized
INFO - 2025-01-31 10:45:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:45:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:45:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:45:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:45:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:45:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:45:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:45:24 --> Upload Class Initialized
INFO - 2025-01-31 10:45:24 --> Email Class Initialized
INFO - 2025-01-31 10:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:45:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:45:24 --> Controller Class Initialized
INFO - 2025-01-31 16:15:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:15:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:15:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:46:24 --> Config Class Initialized
INFO - 2025-01-31 10:46:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:46:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:46:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:46:24 --> URI Class Initialized
INFO - 2025-01-31 10:46:24 --> Router Class Initialized
INFO - 2025-01-31 10:46:24 --> Output Class Initialized
INFO - 2025-01-31 10:46:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:46:24 --> Input Class Initialized
INFO - 2025-01-31 10:46:24 --> Language Class Initialized
INFO - 2025-01-31 10:46:24 --> Loader Class Initialized
INFO - 2025-01-31 10:46:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:46:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:46:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:46:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:46:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:46:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:46:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:46:24 --> Upload Class Initialized
INFO - 2025-01-31 10:46:24 --> Email Class Initialized
INFO - 2025-01-31 10:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:46:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:46:24 --> Controller Class Initialized
INFO - 2025-01-31 16:16:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:16:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:16:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:16:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:47:24 --> Config Class Initialized
INFO - 2025-01-31 10:47:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:47:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:47:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:47:24 --> URI Class Initialized
INFO - 2025-01-31 10:47:24 --> Router Class Initialized
INFO - 2025-01-31 10:47:24 --> Output Class Initialized
INFO - 2025-01-31 10:47:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:47:24 --> Input Class Initialized
INFO - 2025-01-31 10:47:24 --> Language Class Initialized
INFO - 2025-01-31 10:47:24 --> Loader Class Initialized
INFO - 2025-01-31 10:47:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:47:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:47:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:47:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:47:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:47:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:47:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:47:24 --> Upload Class Initialized
INFO - 2025-01-31 10:47:24 --> Email Class Initialized
INFO - 2025-01-31 10:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:47:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:47:24 --> Controller Class Initialized
INFO - 2025-01-31 16:17:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:17:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:17:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:48:24 --> Config Class Initialized
INFO - 2025-01-31 10:48:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:48:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:48:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:48:24 --> URI Class Initialized
INFO - 2025-01-31 10:48:24 --> Router Class Initialized
INFO - 2025-01-31 10:48:24 --> Output Class Initialized
INFO - 2025-01-31 10:48:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:48:24 --> Input Class Initialized
INFO - 2025-01-31 10:48:24 --> Language Class Initialized
INFO - 2025-01-31 10:48:24 --> Loader Class Initialized
INFO - 2025-01-31 10:48:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:48:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:48:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:48:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:48:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:48:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:48:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:48:24 --> Upload Class Initialized
INFO - 2025-01-31 10:48:24 --> Email Class Initialized
INFO - 2025-01-31 10:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:48:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:48:24 --> Controller Class Initialized
INFO - 2025-01-31 16:18:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:18:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:18:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:49:24 --> Config Class Initialized
INFO - 2025-01-31 10:49:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:49:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:49:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:49:24 --> URI Class Initialized
INFO - 2025-01-31 10:49:24 --> Router Class Initialized
INFO - 2025-01-31 10:49:24 --> Output Class Initialized
INFO - 2025-01-31 10:49:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:49:24 --> Input Class Initialized
INFO - 2025-01-31 10:49:24 --> Language Class Initialized
INFO - 2025-01-31 10:49:24 --> Loader Class Initialized
INFO - 2025-01-31 10:49:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:49:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:49:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:49:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:49:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:49:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:49:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:49:24 --> Upload Class Initialized
INFO - 2025-01-31 10:49:24 --> Email Class Initialized
INFO - 2025-01-31 10:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:49:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:49:24 --> Controller Class Initialized
INFO - 2025-01-31 16:19:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:19:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:19:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:50:24 --> Config Class Initialized
INFO - 2025-01-31 10:50:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:50:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:50:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:50:24 --> URI Class Initialized
INFO - 2025-01-31 10:50:24 --> Router Class Initialized
INFO - 2025-01-31 10:50:24 --> Output Class Initialized
INFO - 2025-01-31 10:50:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:50:24 --> Input Class Initialized
INFO - 2025-01-31 10:50:24 --> Language Class Initialized
INFO - 2025-01-31 10:50:24 --> Loader Class Initialized
INFO - 2025-01-31 10:50:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:50:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:50:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:50:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:50:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:50:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:50:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:50:24 --> Upload Class Initialized
INFO - 2025-01-31 10:50:24 --> Email Class Initialized
INFO - 2025-01-31 10:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:50:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:50:24 --> Controller Class Initialized
INFO - 2025-01-31 16:20:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:20:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:20:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:51:24 --> Config Class Initialized
INFO - 2025-01-31 10:51:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:51:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:51:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:51:24 --> URI Class Initialized
INFO - 2025-01-31 10:51:24 --> Router Class Initialized
INFO - 2025-01-31 10:51:24 --> Output Class Initialized
INFO - 2025-01-31 10:51:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:51:24 --> Input Class Initialized
INFO - 2025-01-31 10:51:24 --> Language Class Initialized
INFO - 2025-01-31 10:51:24 --> Loader Class Initialized
INFO - 2025-01-31 10:51:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:51:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:51:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:51:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:51:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:51:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:51:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:51:24 --> Upload Class Initialized
INFO - 2025-01-31 10:51:24 --> Email Class Initialized
INFO - 2025-01-31 10:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:51:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:51:24 --> Controller Class Initialized
INFO - 2025-01-31 16:21:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:21:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:21:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:52:24 --> Config Class Initialized
INFO - 2025-01-31 10:52:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:52:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:52:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:52:24 --> URI Class Initialized
INFO - 2025-01-31 10:52:24 --> Router Class Initialized
INFO - 2025-01-31 10:52:24 --> Output Class Initialized
INFO - 2025-01-31 10:52:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:52:24 --> Input Class Initialized
INFO - 2025-01-31 10:52:24 --> Language Class Initialized
INFO - 2025-01-31 10:52:24 --> Loader Class Initialized
INFO - 2025-01-31 10:52:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:52:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:52:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:52:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:52:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:52:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:52:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:52:24 --> Upload Class Initialized
INFO - 2025-01-31 10:52:24 --> Email Class Initialized
INFO - 2025-01-31 10:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:52:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:52:24 --> Controller Class Initialized
INFO - 2025-01-31 16:22:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:22:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:22:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:53:24 --> Config Class Initialized
INFO - 2025-01-31 10:53:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:53:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:53:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:53:24 --> URI Class Initialized
INFO - 2025-01-31 10:53:24 --> Router Class Initialized
INFO - 2025-01-31 10:53:24 --> Output Class Initialized
INFO - 2025-01-31 10:53:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:53:24 --> Input Class Initialized
INFO - 2025-01-31 10:53:24 --> Language Class Initialized
INFO - 2025-01-31 10:53:24 --> Loader Class Initialized
INFO - 2025-01-31 10:53:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:53:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:53:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:53:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:53:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:53:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:53:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:53:24 --> Upload Class Initialized
INFO - 2025-01-31 10:53:24 --> Email Class Initialized
INFO - 2025-01-31 10:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:53:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:53:24 --> Controller Class Initialized
INFO - 2025-01-31 16:23:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:23:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:23:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:54:24 --> Config Class Initialized
INFO - 2025-01-31 10:54:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:54:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:54:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:54:24 --> URI Class Initialized
INFO - 2025-01-31 10:54:24 --> Router Class Initialized
INFO - 2025-01-31 10:54:24 --> Output Class Initialized
INFO - 2025-01-31 10:54:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:54:24 --> Input Class Initialized
INFO - 2025-01-31 10:54:24 --> Language Class Initialized
INFO - 2025-01-31 10:54:24 --> Loader Class Initialized
INFO - 2025-01-31 10:54:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:54:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:54:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:54:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:54:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:54:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:54:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:54:24 --> Upload Class Initialized
INFO - 2025-01-31 10:54:24 --> Email Class Initialized
INFO - 2025-01-31 10:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:54:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:54:24 --> Controller Class Initialized
INFO - 2025-01-31 16:24:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:24:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:24:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:55:24 --> Config Class Initialized
INFO - 2025-01-31 10:55:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:55:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:55:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:55:24 --> URI Class Initialized
INFO - 2025-01-31 10:55:24 --> Router Class Initialized
INFO - 2025-01-31 10:55:24 --> Output Class Initialized
INFO - 2025-01-31 10:55:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:55:24 --> Input Class Initialized
INFO - 2025-01-31 10:55:24 --> Language Class Initialized
INFO - 2025-01-31 10:55:24 --> Loader Class Initialized
INFO - 2025-01-31 10:55:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:55:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:55:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:55:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:55:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:55:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:55:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:55:24 --> Upload Class Initialized
INFO - 2025-01-31 10:55:24 --> Email Class Initialized
INFO - 2025-01-31 10:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:55:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:55:24 --> Controller Class Initialized
INFO - 2025-01-31 16:25:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:25:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:25:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:56:24 --> Config Class Initialized
INFO - 2025-01-31 10:56:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:56:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:56:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:56:24 --> URI Class Initialized
INFO - 2025-01-31 10:56:24 --> Router Class Initialized
INFO - 2025-01-31 10:56:24 --> Output Class Initialized
INFO - 2025-01-31 10:56:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:56:24 --> Input Class Initialized
INFO - 2025-01-31 10:56:24 --> Language Class Initialized
INFO - 2025-01-31 10:56:24 --> Loader Class Initialized
INFO - 2025-01-31 10:56:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:56:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:56:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:56:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:56:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:56:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:56:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:56:24 --> Upload Class Initialized
INFO - 2025-01-31 10:56:24 --> Email Class Initialized
INFO - 2025-01-31 10:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:56:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:56:24 --> Controller Class Initialized
INFO - 2025-01-31 16:26:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:26:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:26:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:57:24 --> Config Class Initialized
INFO - 2025-01-31 10:57:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:57:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:57:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:57:24 --> URI Class Initialized
INFO - 2025-01-31 10:57:24 --> Router Class Initialized
INFO - 2025-01-31 10:57:24 --> Output Class Initialized
INFO - 2025-01-31 10:57:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:57:24 --> Input Class Initialized
INFO - 2025-01-31 10:57:24 --> Language Class Initialized
INFO - 2025-01-31 10:57:24 --> Loader Class Initialized
INFO - 2025-01-31 10:57:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:57:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:57:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:57:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:57:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:57:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:57:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:57:24 --> Upload Class Initialized
INFO - 2025-01-31 10:57:24 --> Email Class Initialized
INFO - 2025-01-31 10:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:57:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:57:24 --> Controller Class Initialized
INFO - 2025-01-31 16:27:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:27:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:27:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:58:24 --> Config Class Initialized
INFO - 2025-01-31 10:58:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:58:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:58:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:58:24 --> URI Class Initialized
INFO - 2025-01-31 10:58:24 --> Router Class Initialized
INFO - 2025-01-31 10:58:24 --> Output Class Initialized
INFO - 2025-01-31 10:58:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:58:24 --> Input Class Initialized
INFO - 2025-01-31 10:58:24 --> Language Class Initialized
INFO - 2025-01-31 10:58:24 --> Loader Class Initialized
INFO - 2025-01-31 10:58:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:58:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:58:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:58:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:58:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:58:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:58:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:58:24 --> Upload Class Initialized
INFO - 2025-01-31 10:58:24 --> Email Class Initialized
INFO - 2025-01-31 10:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:58:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:58:24 --> Controller Class Initialized
INFO - 2025-01-31 16:28:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:28:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:28:24 --> Pagination Class Initialized
INFO - 2025-01-31 10:59:24 --> Config Class Initialized
INFO - 2025-01-31 10:59:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 10:59:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 10:59:24 --> Utf8 Class Initialized
INFO - 2025-01-31 10:59:24 --> URI Class Initialized
INFO - 2025-01-31 10:59:24 --> Router Class Initialized
INFO - 2025-01-31 10:59:24 --> Output Class Initialized
INFO - 2025-01-31 10:59:24 --> Security Class Initialized
DEBUG - 2025-01-31 10:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 10:59:24 --> Input Class Initialized
INFO - 2025-01-31 10:59:24 --> Language Class Initialized
INFO - 2025-01-31 10:59:24 --> Loader Class Initialized
INFO - 2025-01-31 10:59:24 --> Helper loaded: url_helper
INFO - 2025-01-31 10:59:24 --> Helper loaded: html_helper
INFO - 2025-01-31 10:59:24 --> Helper loaded: file_helper
INFO - 2025-01-31 10:59:24 --> Helper loaded: string_helper
INFO - 2025-01-31 10:59:24 --> Helper loaded: form_helper
INFO - 2025-01-31 10:59:24 --> Helper loaded: my_helper
INFO - 2025-01-31 10:59:24 --> Database Driver Class Initialized
INFO - 2025-01-31 10:59:24 --> Upload Class Initialized
INFO - 2025-01-31 10:59:24 --> Email Class Initialized
INFO - 2025-01-31 10:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 10:59:24 --> Form Validation Class Initialized
INFO - 2025-01-31 10:59:24 --> Controller Class Initialized
INFO - 2025-01-31 16:29:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:29:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:29:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:00:24 --> Config Class Initialized
INFO - 2025-01-31 11:00:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:00:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:00:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:00:24 --> URI Class Initialized
INFO - 2025-01-31 11:00:24 --> Router Class Initialized
INFO - 2025-01-31 11:00:24 --> Output Class Initialized
INFO - 2025-01-31 11:00:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:00:24 --> Input Class Initialized
INFO - 2025-01-31 11:00:24 --> Language Class Initialized
INFO - 2025-01-31 11:00:24 --> Loader Class Initialized
INFO - 2025-01-31 11:00:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:00:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:00:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:00:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:00:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:00:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:00:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:00:24 --> Upload Class Initialized
INFO - 2025-01-31 11:00:24 --> Email Class Initialized
INFO - 2025-01-31 11:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:00:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:00:24 --> Controller Class Initialized
INFO - 2025-01-31 16:30:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:30:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:30:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:01:24 --> Config Class Initialized
INFO - 2025-01-31 11:01:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:01:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:01:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:01:24 --> URI Class Initialized
INFO - 2025-01-31 11:01:24 --> Router Class Initialized
INFO - 2025-01-31 11:01:24 --> Output Class Initialized
INFO - 2025-01-31 11:01:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:01:24 --> Input Class Initialized
INFO - 2025-01-31 11:01:24 --> Language Class Initialized
INFO - 2025-01-31 11:01:24 --> Loader Class Initialized
INFO - 2025-01-31 11:01:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:01:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:01:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:01:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:01:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:01:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:01:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:01:24 --> Upload Class Initialized
INFO - 2025-01-31 11:01:24 --> Email Class Initialized
INFO - 2025-01-31 11:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:01:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:01:24 --> Controller Class Initialized
INFO - 2025-01-31 16:31:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:31:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:31:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:02:24 --> Config Class Initialized
INFO - 2025-01-31 11:02:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:02:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:02:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:02:24 --> URI Class Initialized
INFO - 2025-01-31 11:02:24 --> Router Class Initialized
INFO - 2025-01-31 11:02:24 --> Output Class Initialized
INFO - 2025-01-31 11:02:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:02:24 --> Input Class Initialized
INFO - 2025-01-31 11:02:24 --> Language Class Initialized
INFO - 2025-01-31 11:02:24 --> Loader Class Initialized
INFO - 2025-01-31 11:02:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:02:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:02:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:02:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:02:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:02:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:02:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:02:24 --> Upload Class Initialized
INFO - 2025-01-31 11:02:24 --> Email Class Initialized
INFO - 2025-01-31 11:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:02:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:02:24 --> Controller Class Initialized
INFO - 2025-01-31 16:32:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:32:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:32:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:03:24 --> Config Class Initialized
INFO - 2025-01-31 11:03:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:03:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:03:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:03:24 --> URI Class Initialized
INFO - 2025-01-31 11:03:24 --> Router Class Initialized
INFO - 2025-01-31 11:03:24 --> Output Class Initialized
INFO - 2025-01-31 11:03:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:03:24 --> Input Class Initialized
INFO - 2025-01-31 11:03:24 --> Language Class Initialized
INFO - 2025-01-31 11:03:24 --> Loader Class Initialized
INFO - 2025-01-31 11:03:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:03:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:03:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:03:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:03:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:03:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:03:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:03:24 --> Upload Class Initialized
INFO - 2025-01-31 11:03:24 --> Email Class Initialized
INFO - 2025-01-31 11:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:03:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:03:24 --> Controller Class Initialized
INFO - 2025-01-31 16:33:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:33:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:33:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:04:24 --> Config Class Initialized
INFO - 2025-01-31 11:04:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:04:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:04:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:04:24 --> URI Class Initialized
INFO - 2025-01-31 11:04:24 --> Router Class Initialized
INFO - 2025-01-31 11:04:24 --> Output Class Initialized
INFO - 2025-01-31 11:04:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:04:24 --> Input Class Initialized
INFO - 2025-01-31 11:04:24 --> Language Class Initialized
INFO - 2025-01-31 11:04:24 --> Loader Class Initialized
INFO - 2025-01-31 11:04:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:04:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:04:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:04:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:04:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:04:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:04:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:04:24 --> Upload Class Initialized
INFO - 2025-01-31 11:04:24 --> Email Class Initialized
INFO - 2025-01-31 11:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:04:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:04:24 --> Controller Class Initialized
INFO - 2025-01-31 16:34:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:34:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:34:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:05:24 --> Config Class Initialized
INFO - 2025-01-31 11:05:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:05:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:05:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:05:24 --> URI Class Initialized
INFO - 2025-01-31 11:05:24 --> Router Class Initialized
INFO - 2025-01-31 11:05:24 --> Output Class Initialized
INFO - 2025-01-31 11:05:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:05:24 --> Input Class Initialized
INFO - 2025-01-31 11:05:24 --> Language Class Initialized
INFO - 2025-01-31 11:05:24 --> Loader Class Initialized
INFO - 2025-01-31 11:05:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:05:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:05:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:05:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:05:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:05:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:05:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:05:24 --> Upload Class Initialized
INFO - 2025-01-31 11:05:24 --> Email Class Initialized
INFO - 2025-01-31 11:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:05:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:05:24 --> Controller Class Initialized
INFO - 2025-01-31 16:35:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:35:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:35:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:06:24 --> Config Class Initialized
INFO - 2025-01-31 11:06:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:06:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:06:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:06:24 --> URI Class Initialized
INFO - 2025-01-31 11:06:24 --> Router Class Initialized
INFO - 2025-01-31 11:06:24 --> Output Class Initialized
INFO - 2025-01-31 11:06:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:06:24 --> Input Class Initialized
INFO - 2025-01-31 11:06:24 --> Language Class Initialized
INFO - 2025-01-31 11:06:24 --> Loader Class Initialized
INFO - 2025-01-31 11:06:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:06:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:06:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:06:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:06:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:06:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:06:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:06:24 --> Upload Class Initialized
INFO - 2025-01-31 11:06:24 --> Email Class Initialized
INFO - 2025-01-31 11:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:06:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:06:24 --> Controller Class Initialized
INFO - 2025-01-31 16:36:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:36:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:36:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:36:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:07:24 --> Config Class Initialized
INFO - 2025-01-31 11:07:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:07:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:07:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:07:24 --> URI Class Initialized
INFO - 2025-01-31 11:07:24 --> Router Class Initialized
INFO - 2025-01-31 11:07:24 --> Output Class Initialized
INFO - 2025-01-31 11:07:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:07:24 --> Input Class Initialized
INFO - 2025-01-31 11:07:24 --> Language Class Initialized
INFO - 2025-01-31 11:07:24 --> Loader Class Initialized
INFO - 2025-01-31 11:07:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:07:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:07:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:07:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:07:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:07:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:07:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:07:24 --> Upload Class Initialized
INFO - 2025-01-31 11:07:24 --> Email Class Initialized
INFO - 2025-01-31 11:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:07:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:07:24 --> Controller Class Initialized
INFO - 2025-01-31 16:37:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:37:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:37:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:08:24 --> Config Class Initialized
INFO - 2025-01-31 11:08:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:08:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:08:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:08:24 --> URI Class Initialized
INFO - 2025-01-31 11:08:24 --> Router Class Initialized
INFO - 2025-01-31 11:08:24 --> Output Class Initialized
INFO - 2025-01-31 11:08:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:08:24 --> Input Class Initialized
INFO - 2025-01-31 11:08:24 --> Language Class Initialized
INFO - 2025-01-31 11:08:24 --> Loader Class Initialized
INFO - 2025-01-31 11:08:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:08:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:08:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:08:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:08:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:08:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:08:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:08:24 --> Upload Class Initialized
INFO - 2025-01-31 11:08:24 --> Email Class Initialized
INFO - 2025-01-31 11:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:08:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:08:24 --> Controller Class Initialized
INFO - 2025-01-31 16:38:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:38:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:38:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:09:24 --> Config Class Initialized
INFO - 2025-01-31 11:09:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:09:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:09:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:09:24 --> URI Class Initialized
INFO - 2025-01-31 11:09:24 --> Router Class Initialized
INFO - 2025-01-31 11:09:24 --> Output Class Initialized
INFO - 2025-01-31 11:09:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:09:24 --> Input Class Initialized
INFO - 2025-01-31 11:09:24 --> Language Class Initialized
INFO - 2025-01-31 11:09:24 --> Loader Class Initialized
INFO - 2025-01-31 11:09:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:09:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:09:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:09:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:09:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:09:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:09:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:09:24 --> Upload Class Initialized
INFO - 2025-01-31 11:09:24 --> Email Class Initialized
INFO - 2025-01-31 11:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:09:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:09:24 --> Controller Class Initialized
INFO - 2025-01-31 16:39:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:39:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:39:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:10:24 --> Config Class Initialized
INFO - 2025-01-31 11:10:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:10:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:10:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:10:24 --> URI Class Initialized
INFO - 2025-01-31 11:10:24 --> Router Class Initialized
INFO - 2025-01-31 11:10:24 --> Output Class Initialized
INFO - 2025-01-31 11:10:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:10:24 --> Input Class Initialized
INFO - 2025-01-31 11:10:24 --> Language Class Initialized
INFO - 2025-01-31 11:10:24 --> Loader Class Initialized
INFO - 2025-01-31 11:10:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:10:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:10:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:10:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:10:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:10:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:10:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:10:24 --> Upload Class Initialized
INFO - 2025-01-31 11:10:24 --> Email Class Initialized
INFO - 2025-01-31 11:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:10:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:10:24 --> Controller Class Initialized
INFO - 2025-01-31 16:40:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:40:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:40:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:23:47 --> Config Class Initialized
INFO - 2025-01-31 11:23:47 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:23:47 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:23:47 --> Utf8 Class Initialized
INFO - 2025-01-31 11:23:47 --> URI Class Initialized
INFO - 2025-01-31 11:23:47 --> Router Class Initialized
INFO - 2025-01-31 11:23:47 --> Output Class Initialized
INFO - 2025-01-31 11:23:47 --> Security Class Initialized
DEBUG - 2025-01-31 11:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:23:47 --> Input Class Initialized
INFO - 2025-01-31 11:23:47 --> Language Class Initialized
INFO - 2025-01-31 11:23:47 --> Loader Class Initialized
INFO - 2025-01-31 11:23:47 --> Helper loaded: url_helper
INFO - 2025-01-31 11:23:47 --> Helper loaded: html_helper
INFO - 2025-01-31 11:23:47 --> Helper loaded: file_helper
INFO - 2025-01-31 11:23:47 --> Helper loaded: string_helper
INFO - 2025-01-31 11:23:47 --> Helper loaded: form_helper
INFO - 2025-01-31 11:23:47 --> Helper loaded: my_helper
INFO - 2025-01-31 11:23:47 --> Database Driver Class Initialized
INFO - 2025-01-31 11:23:47 --> Upload Class Initialized
INFO - 2025-01-31 11:23:47 --> Email Class Initialized
INFO - 2025-01-31 11:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:23:47 --> Form Validation Class Initialized
INFO - 2025-01-31 11:23:47 --> Controller Class Initialized
INFO - 2025-01-31 16:53:47 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:53:47 --> Model "MainModel" initialized
INFO - 2025-01-31 16:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:53:47 --> Pagination Class Initialized
INFO - 2025-01-31 11:24:24 --> Config Class Initialized
INFO - 2025-01-31 11:24:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:24:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:24:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:24:24 --> URI Class Initialized
INFO - 2025-01-31 11:24:24 --> Router Class Initialized
INFO - 2025-01-31 11:24:24 --> Output Class Initialized
INFO - 2025-01-31 11:24:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:24:24 --> Input Class Initialized
INFO - 2025-01-31 11:24:24 --> Language Class Initialized
INFO - 2025-01-31 11:24:24 --> Loader Class Initialized
INFO - 2025-01-31 11:24:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:24:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:24:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:24:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:24:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:24:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:24:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:24:24 --> Upload Class Initialized
INFO - 2025-01-31 11:24:24 --> Email Class Initialized
INFO - 2025-01-31 11:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:24:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:24:24 --> Controller Class Initialized
INFO - 2025-01-31 16:54:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:54:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:54:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:25:24 --> Config Class Initialized
INFO - 2025-01-31 11:25:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:25:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:25:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:25:24 --> URI Class Initialized
INFO - 2025-01-31 11:25:24 --> Router Class Initialized
INFO - 2025-01-31 11:25:24 --> Output Class Initialized
INFO - 2025-01-31 11:25:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:25:24 --> Input Class Initialized
INFO - 2025-01-31 11:25:24 --> Language Class Initialized
INFO - 2025-01-31 11:25:24 --> Loader Class Initialized
INFO - 2025-01-31 11:25:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:25:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:25:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:25:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:25:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:25:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:25:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:25:24 --> Upload Class Initialized
INFO - 2025-01-31 11:25:24 --> Email Class Initialized
INFO - 2025-01-31 11:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:25:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:25:24 --> Controller Class Initialized
INFO - 2025-01-31 16:55:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:55:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:55:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:26:24 --> Config Class Initialized
INFO - 2025-01-31 11:26:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:26:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:26:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:26:24 --> URI Class Initialized
INFO - 2025-01-31 11:26:24 --> Router Class Initialized
INFO - 2025-01-31 11:26:24 --> Output Class Initialized
INFO - 2025-01-31 11:26:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:26:24 --> Input Class Initialized
INFO - 2025-01-31 11:26:24 --> Language Class Initialized
INFO - 2025-01-31 11:26:24 --> Loader Class Initialized
INFO - 2025-01-31 11:26:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:26:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:26:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:26:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:26:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:26:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:26:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:26:24 --> Upload Class Initialized
INFO - 2025-01-31 11:26:24 --> Email Class Initialized
INFO - 2025-01-31 11:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:26:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:26:24 --> Controller Class Initialized
INFO - 2025-01-31 16:56:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:56:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:56:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:27:24 --> Config Class Initialized
INFO - 2025-01-31 11:27:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:27:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:27:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:27:24 --> URI Class Initialized
INFO - 2025-01-31 11:27:24 --> Router Class Initialized
INFO - 2025-01-31 11:27:24 --> Output Class Initialized
INFO - 2025-01-31 11:27:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:27:24 --> Input Class Initialized
INFO - 2025-01-31 11:27:24 --> Language Class Initialized
INFO - 2025-01-31 11:27:24 --> Loader Class Initialized
INFO - 2025-01-31 11:27:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:27:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:27:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:27:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:27:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:27:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:27:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:27:24 --> Upload Class Initialized
INFO - 2025-01-31 11:27:24 --> Email Class Initialized
INFO - 2025-01-31 11:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:27:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:27:24 --> Controller Class Initialized
INFO - 2025-01-31 16:57:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:57:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:57:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:28:24 --> Config Class Initialized
INFO - 2025-01-31 11:28:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:28:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:28:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:28:24 --> URI Class Initialized
INFO - 2025-01-31 11:28:24 --> Router Class Initialized
INFO - 2025-01-31 11:28:24 --> Output Class Initialized
INFO - 2025-01-31 11:28:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:28:24 --> Input Class Initialized
INFO - 2025-01-31 11:28:24 --> Language Class Initialized
INFO - 2025-01-31 11:28:24 --> Loader Class Initialized
INFO - 2025-01-31 11:28:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:28:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:28:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:28:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:28:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:28:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:28:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:28:24 --> Upload Class Initialized
INFO - 2025-01-31 11:28:24 --> Email Class Initialized
INFO - 2025-01-31 11:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:28:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:28:24 --> Controller Class Initialized
INFO - 2025-01-31 16:58:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:58:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:58:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:58:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:29:24 --> Config Class Initialized
INFO - 2025-01-31 11:29:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:29:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:29:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:29:24 --> URI Class Initialized
INFO - 2025-01-31 11:29:24 --> Router Class Initialized
INFO - 2025-01-31 11:29:24 --> Output Class Initialized
INFO - 2025-01-31 11:29:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:29:24 --> Input Class Initialized
INFO - 2025-01-31 11:29:24 --> Language Class Initialized
INFO - 2025-01-31 11:29:24 --> Loader Class Initialized
INFO - 2025-01-31 11:29:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:29:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:29:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:29:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:29:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:29:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:29:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:29:24 --> Upload Class Initialized
INFO - 2025-01-31 11:29:24 --> Email Class Initialized
INFO - 2025-01-31 11:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:29:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:29:24 --> Controller Class Initialized
INFO - 2025-01-31 16:59:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 16:59:24 --> Model "MainModel" initialized
INFO - 2025-01-31 16:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 16:59:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:30:24 --> Config Class Initialized
INFO - 2025-01-31 11:30:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:30:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:30:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:30:24 --> URI Class Initialized
INFO - 2025-01-31 11:30:24 --> Router Class Initialized
INFO - 2025-01-31 11:30:24 --> Output Class Initialized
INFO - 2025-01-31 11:30:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:30:24 --> Input Class Initialized
INFO - 2025-01-31 11:30:24 --> Language Class Initialized
INFO - 2025-01-31 11:30:24 --> Loader Class Initialized
INFO - 2025-01-31 11:30:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:30:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:30:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:30:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:30:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:30:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:30:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:30:24 --> Upload Class Initialized
INFO - 2025-01-31 11:30:24 --> Email Class Initialized
INFO - 2025-01-31 11:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:30:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:30:24 --> Controller Class Initialized
INFO - 2025-01-31 17:00:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:00:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:00:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:00:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:31:24 --> Config Class Initialized
INFO - 2025-01-31 11:31:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:31:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:31:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:31:24 --> URI Class Initialized
INFO - 2025-01-31 11:31:24 --> Router Class Initialized
INFO - 2025-01-31 11:31:24 --> Output Class Initialized
INFO - 2025-01-31 11:31:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:31:24 --> Input Class Initialized
INFO - 2025-01-31 11:31:24 --> Language Class Initialized
INFO - 2025-01-31 11:31:24 --> Loader Class Initialized
INFO - 2025-01-31 11:31:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:31:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:31:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:31:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:31:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:31:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:31:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:31:24 --> Upload Class Initialized
INFO - 2025-01-31 11:31:24 --> Email Class Initialized
INFO - 2025-01-31 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:31:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:31:24 --> Controller Class Initialized
INFO - 2025-01-31 17:01:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:01:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:01:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:32:24 --> Config Class Initialized
INFO - 2025-01-31 11:32:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:32:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:32:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:32:24 --> URI Class Initialized
INFO - 2025-01-31 11:32:24 --> Router Class Initialized
INFO - 2025-01-31 11:32:24 --> Output Class Initialized
INFO - 2025-01-31 11:32:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:32:24 --> Input Class Initialized
INFO - 2025-01-31 11:32:24 --> Language Class Initialized
INFO - 2025-01-31 11:32:24 --> Loader Class Initialized
INFO - 2025-01-31 11:32:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:32:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:32:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:32:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:32:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:32:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:32:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:32:24 --> Upload Class Initialized
INFO - 2025-01-31 11:32:24 --> Email Class Initialized
INFO - 2025-01-31 11:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:32:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:32:24 --> Controller Class Initialized
INFO - 2025-01-31 17:02:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:02:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:02:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:02:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:33:24 --> Config Class Initialized
INFO - 2025-01-31 11:33:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:33:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:33:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:33:24 --> URI Class Initialized
INFO - 2025-01-31 11:33:24 --> Router Class Initialized
INFO - 2025-01-31 11:33:24 --> Output Class Initialized
INFO - 2025-01-31 11:33:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:33:24 --> Input Class Initialized
INFO - 2025-01-31 11:33:24 --> Language Class Initialized
INFO - 2025-01-31 11:33:24 --> Loader Class Initialized
INFO - 2025-01-31 11:33:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:33:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:33:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:33:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:33:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:33:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:33:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:33:24 --> Upload Class Initialized
INFO - 2025-01-31 11:33:24 --> Email Class Initialized
INFO - 2025-01-31 11:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:33:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:33:24 --> Controller Class Initialized
INFO - 2025-01-31 17:03:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:03:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:03:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:34:24 --> Config Class Initialized
INFO - 2025-01-31 11:34:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:34:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:34:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:34:24 --> URI Class Initialized
INFO - 2025-01-31 11:34:24 --> Router Class Initialized
INFO - 2025-01-31 11:34:24 --> Output Class Initialized
INFO - 2025-01-31 11:34:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:34:24 --> Input Class Initialized
INFO - 2025-01-31 11:34:24 --> Language Class Initialized
INFO - 2025-01-31 11:34:24 --> Loader Class Initialized
INFO - 2025-01-31 11:34:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:34:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:34:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:34:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:34:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:34:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:34:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:34:24 --> Upload Class Initialized
INFO - 2025-01-31 11:34:24 --> Email Class Initialized
INFO - 2025-01-31 11:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:34:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:34:24 --> Controller Class Initialized
INFO - 2025-01-31 17:04:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:04:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:04:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:35:24 --> Config Class Initialized
INFO - 2025-01-31 11:35:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:35:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:35:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:35:24 --> URI Class Initialized
INFO - 2025-01-31 11:35:24 --> Router Class Initialized
INFO - 2025-01-31 11:35:24 --> Output Class Initialized
INFO - 2025-01-31 11:35:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:35:24 --> Input Class Initialized
INFO - 2025-01-31 11:35:24 --> Language Class Initialized
INFO - 2025-01-31 11:35:24 --> Loader Class Initialized
INFO - 2025-01-31 11:35:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:35:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:35:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:35:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:35:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:35:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:35:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:35:24 --> Upload Class Initialized
INFO - 2025-01-31 11:35:24 --> Email Class Initialized
INFO - 2025-01-31 11:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:35:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:35:24 --> Controller Class Initialized
INFO - 2025-01-31 17:05:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:05:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:05:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:05:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:36:24 --> Config Class Initialized
INFO - 2025-01-31 11:36:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:36:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:36:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:36:24 --> URI Class Initialized
INFO - 2025-01-31 11:36:24 --> Router Class Initialized
INFO - 2025-01-31 11:36:24 --> Output Class Initialized
INFO - 2025-01-31 11:36:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:36:24 --> Input Class Initialized
INFO - 2025-01-31 11:36:24 --> Language Class Initialized
INFO - 2025-01-31 11:36:24 --> Loader Class Initialized
INFO - 2025-01-31 11:36:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:36:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:36:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:36:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:36:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:36:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:36:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:36:24 --> Upload Class Initialized
INFO - 2025-01-31 11:36:24 --> Email Class Initialized
INFO - 2025-01-31 11:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:36:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:36:24 --> Controller Class Initialized
INFO - 2025-01-31 17:06:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:06:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:06:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:37:24 --> Config Class Initialized
INFO - 2025-01-31 11:37:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:37:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:37:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:37:24 --> URI Class Initialized
INFO - 2025-01-31 11:37:24 --> Router Class Initialized
INFO - 2025-01-31 11:37:24 --> Output Class Initialized
INFO - 2025-01-31 11:37:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:37:24 --> Input Class Initialized
INFO - 2025-01-31 11:37:24 --> Language Class Initialized
INFO - 2025-01-31 11:37:24 --> Loader Class Initialized
INFO - 2025-01-31 11:37:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:37:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:37:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:37:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:37:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:37:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:37:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:37:24 --> Upload Class Initialized
INFO - 2025-01-31 11:37:24 --> Email Class Initialized
INFO - 2025-01-31 11:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:37:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:37:24 --> Controller Class Initialized
INFO - 2025-01-31 17:07:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:07:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:07:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:07:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:38:24 --> Config Class Initialized
INFO - 2025-01-31 11:38:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:38:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:38:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:38:24 --> URI Class Initialized
INFO - 2025-01-31 11:38:24 --> Router Class Initialized
INFO - 2025-01-31 11:38:24 --> Output Class Initialized
INFO - 2025-01-31 11:38:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:38:24 --> Input Class Initialized
INFO - 2025-01-31 11:38:24 --> Language Class Initialized
INFO - 2025-01-31 11:38:24 --> Loader Class Initialized
INFO - 2025-01-31 11:38:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:38:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:38:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:38:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:38:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:38:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:38:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:38:24 --> Upload Class Initialized
INFO - 2025-01-31 11:38:24 --> Email Class Initialized
INFO - 2025-01-31 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:38:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:38:24 --> Controller Class Initialized
INFO - 2025-01-31 17:08:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:08:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:08:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:39:24 --> Config Class Initialized
INFO - 2025-01-31 11:39:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:39:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:39:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:39:24 --> URI Class Initialized
INFO - 2025-01-31 11:39:24 --> Router Class Initialized
INFO - 2025-01-31 11:39:24 --> Output Class Initialized
INFO - 2025-01-31 11:39:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:39:24 --> Input Class Initialized
INFO - 2025-01-31 11:39:24 --> Language Class Initialized
INFO - 2025-01-31 11:39:24 --> Loader Class Initialized
INFO - 2025-01-31 11:39:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:39:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:39:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:39:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:39:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:39:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:39:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:39:24 --> Upload Class Initialized
INFO - 2025-01-31 11:39:24 --> Email Class Initialized
INFO - 2025-01-31 11:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:39:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:39:24 --> Controller Class Initialized
INFO - 2025-01-31 17:09:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:09:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:09:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:40:24 --> Config Class Initialized
INFO - 2025-01-31 11:40:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:40:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:40:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:40:24 --> URI Class Initialized
INFO - 2025-01-31 11:40:24 --> Router Class Initialized
INFO - 2025-01-31 11:40:24 --> Output Class Initialized
INFO - 2025-01-31 11:40:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:40:24 --> Input Class Initialized
INFO - 2025-01-31 11:40:24 --> Language Class Initialized
INFO - 2025-01-31 11:40:24 --> Loader Class Initialized
INFO - 2025-01-31 11:40:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:40:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:40:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:40:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:40:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:40:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:40:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:40:24 --> Upload Class Initialized
INFO - 2025-01-31 11:40:24 --> Email Class Initialized
INFO - 2025-01-31 11:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:40:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:40:24 --> Controller Class Initialized
INFO - 2025-01-31 17:10:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:10:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:10:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:41:24 --> Config Class Initialized
INFO - 2025-01-31 11:41:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:41:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:41:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:41:24 --> URI Class Initialized
INFO - 2025-01-31 11:41:24 --> Router Class Initialized
INFO - 2025-01-31 11:41:24 --> Output Class Initialized
INFO - 2025-01-31 11:41:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:41:24 --> Input Class Initialized
INFO - 2025-01-31 11:41:24 --> Language Class Initialized
INFO - 2025-01-31 11:41:24 --> Loader Class Initialized
INFO - 2025-01-31 11:41:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:41:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:41:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:41:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:41:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:41:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:41:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:41:24 --> Upload Class Initialized
INFO - 2025-01-31 11:41:24 --> Email Class Initialized
INFO - 2025-01-31 11:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:41:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:41:24 --> Controller Class Initialized
INFO - 2025-01-31 17:11:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:11:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:11:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:42:24 --> Config Class Initialized
INFO - 2025-01-31 11:42:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:42:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:42:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:42:24 --> URI Class Initialized
INFO - 2025-01-31 11:42:24 --> Router Class Initialized
INFO - 2025-01-31 11:42:24 --> Output Class Initialized
INFO - 2025-01-31 11:42:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:42:24 --> Input Class Initialized
INFO - 2025-01-31 11:42:24 --> Language Class Initialized
INFO - 2025-01-31 11:42:24 --> Loader Class Initialized
INFO - 2025-01-31 11:42:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:42:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:42:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:42:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:42:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:42:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:42:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:42:24 --> Upload Class Initialized
INFO - 2025-01-31 11:42:24 --> Email Class Initialized
INFO - 2025-01-31 11:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:42:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:42:24 --> Controller Class Initialized
INFO - 2025-01-31 17:12:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:12:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:12:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:12:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:43:15 --> Config Class Initialized
INFO - 2025-01-31 11:43:15 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:15 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:15 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:15 --> URI Class Initialized
INFO - 2025-01-31 11:43:15 --> Router Class Initialized
INFO - 2025-01-31 11:43:15 --> Output Class Initialized
INFO - 2025-01-31 11:43:15 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:15 --> Input Class Initialized
INFO - 2025-01-31 11:43:15 --> Language Class Initialized
INFO - 2025-01-31 11:43:15 --> Loader Class Initialized
INFO - 2025-01-31 11:43:15 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:15 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:15 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:15 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:15 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:15 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:15 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:15 --> Upload Class Initialized
INFO - 2025-01-31 11:43:15 --> Email Class Initialized
INFO - 2025-01-31 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:15 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:15 --> Controller Class Initialized
INFO - 2025-01-31 17:13:15 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 17:13:15 --> Helper loaded: notification_helper
INFO - 2025-01-31 17:13:15 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:15 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-31 17:13:16 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/guest_panel.php
INFO - 2025-01-31 17:13:16 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-31 17:13:16 --> Final output sent to browser
DEBUG - 2025-01-31 17:13:16 --> Total execution time: 0.5434
INFO - 2025-01-31 11:43:24 --> Config Class Initialized
INFO - 2025-01-31 11:43:24 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:24 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:24 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:24 --> URI Class Initialized
INFO - 2025-01-31 11:43:24 --> Router Class Initialized
INFO - 2025-01-31 11:43:24 --> Output Class Initialized
INFO - 2025-01-31 11:43:24 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:24 --> Input Class Initialized
INFO - 2025-01-31 11:43:24 --> Language Class Initialized
INFO - 2025-01-31 11:43:24 --> Loader Class Initialized
INFO - 2025-01-31 11:43:24 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:24 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:24 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:24 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:24 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:24 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:24 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:24 --> Upload Class Initialized
INFO - 2025-01-31 11:43:24 --> Email Class Initialized
INFO - 2025-01-31 11:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:24 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:24 --> Controller Class Initialized
INFO - 2025-01-31 17:13:24 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:13:24 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:13:24 --> Pagination Class Initialized
INFO - 2025-01-31 11:43:29 --> Config Class Initialized
INFO - 2025-01-31 11:43:29 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:29 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:29 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:29 --> URI Class Initialized
INFO - 2025-01-31 11:43:29 --> Router Class Initialized
INFO - 2025-01-31 11:43:29 --> Output Class Initialized
INFO - 2025-01-31 11:43:29 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:29 --> Input Class Initialized
INFO - 2025-01-31 11:43:29 --> Language Class Initialized
INFO - 2025-01-31 11:43:29 --> Loader Class Initialized
INFO - 2025-01-31 11:43:29 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:29 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:29 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:29 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:29 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:29 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:29 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:29 --> Upload Class Initialized
INFO - 2025-01-31 11:43:29 --> Email Class Initialized
INFO - 2025-01-31 11:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:29 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:29 --> Controller Class Initialized
INFO - 2025-01-31 17:13:29 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:13:29 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:13:29 --> Pagination Class Initialized
INFO - 2025-01-31 11:43:33 --> Config Class Initialized
INFO - 2025-01-31 11:43:33 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:33 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:33 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:33 --> URI Class Initialized
INFO - 2025-01-31 11:43:33 --> Router Class Initialized
INFO - 2025-01-31 11:43:33 --> Output Class Initialized
INFO - 2025-01-31 11:43:33 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:33 --> Input Class Initialized
INFO - 2025-01-31 11:43:33 --> Language Class Initialized
INFO - 2025-01-31 11:43:33 --> Loader Class Initialized
INFO - 2025-01-31 11:43:33 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:33 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:33 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:33 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:33 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:33 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:33 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:33 --> Upload Class Initialized
INFO - 2025-01-31 11:43:33 --> Email Class Initialized
INFO - 2025-01-31 11:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:33 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:33 --> Controller Class Initialized
INFO - 2025-01-31 17:13:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:13:33 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:13:33 --> Pagination Class Initialized
INFO - 2025-01-31 11:43:38 --> Config Class Initialized
INFO - 2025-01-31 11:43:38 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:38 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:38 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:38 --> URI Class Initialized
INFO - 2025-01-31 11:43:38 --> Router Class Initialized
INFO - 2025-01-31 11:43:38 --> Output Class Initialized
INFO - 2025-01-31 11:43:38 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:38 --> Input Class Initialized
INFO - 2025-01-31 11:43:38 --> Language Class Initialized
INFO - 2025-01-31 11:43:38 --> Loader Class Initialized
INFO - 2025-01-31 11:43:38 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:38 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:38 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:38 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:38 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:38 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:38 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:38 --> Upload Class Initialized
INFO - 2025-01-31 11:43:38 --> Email Class Initialized
INFO - 2025-01-31 11:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:38 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:38 --> Controller Class Initialized
INFO - 2025-01-31 17:13:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:13:38 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:13:38 --> Pagination Class Initialized
INFO - 2025-01-31 11:43:43 --> Config Class Initialized
INFO - 2025-01-31 11:43:43 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:43 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:43 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:43 --> URI Class Initialized
INFO - 2025-01-31 11:43:43 --> Router Class Initialized
INFO - 2025-01-31 11:43:43 --> Output Class Initialized
INFO - 2025-01-31 11:43:43 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:43 --> Input Class Initialized
INFO - 2025-01-31 11:43:43 --> Language Class Initialized
INFO - 2025-01-31 11:43:43 --> Loader Class Initialized
INFO - 2025-01-31 11:43:43 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:43 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:43 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:43 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:43 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:43 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:43 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:43 --> Upload Class Initialized
INFO - 2025-01-31 11:43:43 --> Email Class Initialized
INFO - 2025-01-31 11:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:43 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:43 --> Controller Class Initialized
INFO - 2025-01-31 17:13:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:13:43 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:13:43 --> Pagination Class Initialized
INFO - 2025-01-31 11:43:48 --> Config Class Initialized
INFO - 2025-01-31 11:43:48 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:48 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:48 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:48 --> URI Class Initialized
INFO - 2025-01-31 11:43:48 --> Router Class Initialized
INFO - 2025-01-31 11:43:48 --> Output Class Initialized
INFO - 2025-01-31 11:43:48 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:48 --> Input Class Initialized
INFO - 2025-01-31 11:43:48 --> Language Class Initialized
INFO - 2025-01-31 11:43:48 --> Loader Class Initialized
INFO - 2025-01-31 11:43:48 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:48 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:48 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:48 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:48 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:48 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:48 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:48 --> Upload Class Initialized
INFO - 2025-01-31 11:43:48 --> Email Class Initialized
INFO - 2025-01-31 11:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:48 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:48 --> Controller Class Initialized
INFO - 2025-01-31 17:13:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:13:48 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:13:48 --> Pagination Class Initialized
INFO - 2025-01-31 11:43:53 --> Config Class Initialized
INFO - 2025-01-31 11:43:53 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:43:53 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:43:53 --> Utf8 Class Initialized
INFO - 2025-01-31 11:43:53 --> URI Class Initialized
INFO - 2025-01-31 11:43:53 --> Router Class Initialized
INFO - 2025-01-31 11:43:53 --> Output Class Initialized
INFO - 2025-01-31 11:43:53 --> Security Class Initialized
DEBUG - 2025-01-31 11:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:43:53 --> Input Class Initialized
INFO - 2025-01-31 11:43:53 --> Language Class Initialized
INFO - 2025-01-31 11:43:53 --> Loader Class Initialized
INFO - 2025-01-31 11:43:53 --> Helper loaded: url_helper
INFO - 2025-01-31 11:43:53 --> Helper loaded: html_helper
INFO - 2025-01-31 11:43:53 --> Helper loaded: file_helper
INFO - 2025-01-31 11:43:53 --> Helper loaded: string_helper
INFO - 2025-01-31 11:43:53 --> Helper loaded: form_helper
INFO - 2025-01-31 11:43:53 --> Helper loaded: my_helper
INFO - 2025-01-31 11:43:53 --> Database Driver Class Initialized
INFO - 2025-01-31 11:43:53 --> Upload Class Initialized
INFO - 2025-01-31 11:43:53 --> Email Class Initialized
INFO - 2025-01-31 11:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:43:53 --> Form Validation Class Initialized
INFO - 2025-01-31 11:43:53 --> Controller Class Initialized
INFO - 2025-01-31 17:13:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:13:53 --> Model "MainModel" initialized
INFO - 2025-01-31 17:13:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:13:53 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:05 --> Config Class Initialized
INFO - 2025-01-31 11:49:05 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:05 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:05 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:05 --> URI Class Initialized
INFO - 2025-01-31 11:49:05 --> Router Class Initialized
INFO - 2025-01-31 11:49:06 --> Output Class Initialized
INFO - 2025-01-31 11:49:06 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:06 --> Input Class Initialized
INFO - 2025-01-31 11:49:06 --> Language Class Initialized
INFO - 2025-01-31 11:49:06 --> Loader Class Initialized
INFO - 2025-01-31 11:49:06 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:06 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:06 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:06 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:06 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:06 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:06 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:06 --> Upload Class Initialized
INFO - 2025-01-31 11:49:06 --> Email Class Initialized
INFO - 2025-01-31 11:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:07 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:07 --> Controller Class Initialized
INFO - 2025-01-31 17:19:07 --> Model "SuperAdminModel" initialized
INFO - 2025-01-31 17:19:07 --> Helper loaded: notification_helper
INFO - 2025-01-31 17:19:07 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:09 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-31 17:19:10 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/guest_panel.php
INFO - 2025-01-31 17:19:10 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-31 17:19:10 --> Final output sent to browser
DEBUG - 2025-01-31 17:19:10 --> Total execution time: 4.5783
INFO - 2025-01-31 11:49:15 --> Config Class Initialized
INFO - 2025-01-31 11:49:15 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:15 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:15 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:15 --> URI Class Initialized
INFO - 2025-01-31 11:49:15 --> Router Class Initialized
INFO - 2025-01-31 11:49:15 --> Output Class Initialized
INFO - 2025-01-31 11:49:15 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:15 --> Input Class Initialized
INFO - 2025-01-31 11:49:15 --> Language Class Initialized
INFO - 2025-01-31 11:49:15 --> Loader Class Initialized
INFO - 2025-01-31 11:49:15 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:15 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:15 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:15 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:15 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:15 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:15 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:15 --> Upload Class Initialized
INFO - 2025-01-31 11:49:15 --> Email Class Initialized
INFO - 2025-01-31 11:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:15 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:15 --> Controller Class Initialized
INFO - 2025-01-31 17:19:16 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:16 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:16 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:20 --> Config Class Initialized
INFO - 2025-01-31 11:49:20 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:20 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:20 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:20 --> URI Class Initialized
INFO - 2025-01-31 11:49:20 --> Router Class Initialized
INFO - 2025-01-31 11:49:20 --> Output Class Initialized
INFO - 2025-01-31 11:49:20 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:20 --> Input Class Initialized
INFO - 2025-01-31 11:49:20 --> Language Class Initialized
INFO - 2025-01-31 11:49:20 --> Loader Class Initialized
INFO - 2025-01-31 11:49:20 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:20 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:20 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:20 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:20 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:20 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:20 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:20 --> Upload Class Initialized
INFO - 2025-01-31 11:49:20 --> Email Class Initialized
INFO - 2025-01-31 11:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:20 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:20 --> Controller Class Initialized
INFO - 2025-01-31 17:19:20 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:20 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:20 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:25 --> Config Class Initialized
INFO - 2025-01-31 11:49:25 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:25 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:25 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:25 --> URI Class Initialized
INFO - 2025-01-31 11:49:25 --> Router Class Initialized
INFO - 2025-01-31 11:49:25 --> Output Class Initialized
INFO - 2025-01-31 11:49:25 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:25 --> Input Class Initialized
INFO - 2025-01-31 11:49:25 --> Language Class Initialized
INFO - 2025-01-31 11:49:25 --> Loader Class Initialized
INFO - 2025-01-31 11:49:25 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:25 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:25 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:25 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:25 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:25 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:25 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:25 --> Upload Class Initialized
INFO - 2025-01-31 11:49:25 --> Email Class Initialized
INFO - 2025-01-31 11:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:25 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:25 --> Controller Class Initialized
INFO - 2025-01-31 17:19:25 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:25 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:25 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:30 --> Config Class Initialized
INFO - 2025-01-31 11:49:30 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:30 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:30 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:30 --> URI Class Initialized
INFO - 2025-01-31 11:49:30 --> Router Class Initialized
INFO - 2025-01-31 11:49:30 --> Output Class Initialized
INFO - 2025-01-31 11:49:30 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:30 --> Input Class Initialized
INFO - 2025-01-31 11:49:30 --> Language Class Initialized
INFO - 2025-01-31 11:49:30 --> Loader Class Initialized
INFO - 2025-01-31 11:49:30 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:30 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:30 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:30 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:30 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:30 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:30 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:30 --> Upload Class Initialized
INFO - 2025-01-31 11:49:30 --> Email Class Initialized
INFO - 2025-01-31 11:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:30 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:30 --> Controller Class Initialized
INFO - 2025-01-31 17:19:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:30 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:30 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:35 --> Config Class Initialized
INFO - 2025-01-31 11:49:35 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:35 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:35 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:35 --> URI Class Initialized
INFO - 2025-01-31 11:49:35 --> Router Class Initialized
INFO - 2025-01-31 11:49:35 --> Output Class Initialized
INFO - 2025-01-31 11:49:35 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:35 --> Input Class Initialized
INFO - 2025-01-31 11:49:35 --> Language Class Initialized
INFO - 2025-01-31 11:49:35 --> Loader Class Initialized
INFO - 2025-01-31 11:49:35 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:35 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:35 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:35 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:35 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:35 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:35 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:35 --> Upload Class Initialized
INFO - 2025-01-31 11:49:35 --> Email Class Initialized
INFO - 2025-01-31 11:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:35 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:35 --> Controller Class Initialized
INFO - 2025-01-31 17:19:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:35 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:35 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:40 --> Config Class Initialized
INFO - 2025-01-31 11:49:40 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:40 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:40 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:40 --> URI Class Initialized
INFO - 2025-01-31 11:49:40 --> Router Class Initialized
INFO - 2025-01-31 11:49:40 --> Output Class Initialized
INFO - 2025-01-31 11:49:40 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:40 --> Input Class Initialized
INFO - 2025-01-31 11:49:40 --> Language Class Initialized
INFO - 2025-01-31 11:49:40 --> Loader Class Initialized
INFO - 2025-01-31 11:49:40 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:40 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:40 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:40 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:40 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:40 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:40 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:40 --> Upload Class Initialized
INFO - 2025-01-31 11:49:40 --> Email Class Initialized
INFO - 2025-01-31 11:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:40 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:40 --> Controller Class Initialized
INFO - 2025-01-31 17:19:40 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:40 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:40 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:45 --> Config Class Initialized
INFO - 2025-01-31 11:49:45 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:45 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:45 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:45 --> URI Class Initialized
INFO - 2025-01-31 11:49:45 --> Router Class Initialized
INFO - 2025-01-31 11:49:45 --> Output Class Initialized
INFO - 2025-01-31 11:49:45 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:45 --> Input Class Initialized
INFO - 2025-01-31 11:49:45 --> Language Class Initialized
INFO - 2025-01-31 11:49:45 --> Loader Class Initialized
INFO - 2025-01-31 11:49:45 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:45 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:45 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:45 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:45 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:45 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:45 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:45 --> Upload Class Initialized
INFO - 2025-01-31 11:49:45 --> Email Class Initialized
INFO - 2025-01-31 11:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:45 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:45 --> Controller Class Initialized
INFO - 2025-01-31 17:19:45 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:45 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:45 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:50 --> Config Class Initialized
INFO - 2025-01-31 11:49:50 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:50 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:50 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:50 --> URI Class Initialized
INFO - 2025-01-31 11:49:50 --> Router Class Initialized
INFO - 2025-01-31 11:49:50 --> Output Class Initialized
INFO - 2025-01-31 11:49:50 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:50 --> Input Class Initialized
INFO - 2025-01-31 11:49:50 --> Language Class Initialized
INFO - 2025-01-31 11:49:50 --> Loader Class Initialized
INFO - 2025-01-31 11:49:50 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:50 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:50 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:50 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:50 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:50 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:50 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:50 --> Upload Class Initialized
INFO - 2025-01-31 11:49:50 --> Email Class Initialized
INFO - 2025-01-31 11:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:50 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:50 --> Controller Class Initialized
INFO - 2025-01-31 17:19:50 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:50 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:50 --> Pagination Class Initialized
INFO - 2025-01-31 11:49:55 --> Config Class Initialized
INFO - 2025-01-31 11:49:55 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:49:55 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:49:55 --> Utf8 Class Initialized
INFO - 2025-01-31 11:49:55 --> URI Class Initialized
INFO - 2025-01-31 11:49:55 --> Router Class Initialized
INFO - 2025-01-31 11:49:55 --> Output Class Initialized
INFO - 2025-01-31 11:49:55 --> Security Class Initialized
DEBUG - 2025-01-31 11:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:49:55 --> Input Class Initialized
INFO - 2025-01-31 11:49:55 --> Language Class Initialized
INFO - 2025-01-31 11:49:55 --> Loader Class Initialized
INFO - 2025-01-31 11:49:55 --> Helper loaded: url_helper
INFO - 2025-01-31 11:49:55 --> Helper loaded: html_helper
INFO - 2025-01-31 11:49:55 --> Helper loaded: file_helper
INFO - 2025-01-31 11:49:55 --> Helper loaded: string_helper
INFO - 2025-01-31 11:49:55 --> Helper loaded: form_helper
INFO - 2025-01-31 11:49:55 --> Helper loaded: my_helper
INFO - 2025-01-31 11:49:55 --> Database Driver Class Initialized
INFO - 2025-01-31 11:49:55 --> Upload Class Initialized
INFO - 2025-01-31 11:49:55 --> Email Class Initialized
INFO - 2025-01-31 11:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:49:55 --> Form Validation Class Initialized
INFO - 2025-01-31 11:49:55 --> Controller Class Initialized
INFO - 2025-01-31 17:19:55 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:19:55 --> Model "MainModel" initialized
INFO - 2025-01-31 17:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:19:55 --> Pagination Class Initialized
INFO - 2025-01-31 11:50:00 --> Config Class Initialized
INFO - 2025-01-31 11:50:00 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:50:00 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:50:00 --> Utf8 Class Initialized
INFO - 2025-01-31 11:50:00 --> URI Class Initialized
INFO - 2025-01-31 11:50:00 --> Router Class Initialized
INFO - 2025-01-31 11:50:00 --> Output Class Initialized
INFO - 2025-01-31 11:50:00 --> Security Class Initialized
DEBUG - 2025-01-31 11:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:50:00 --> Input Class Initialized
INFO - 2025-01-31 11:50:00 --> Language Class Initialized
INFO - 2025-01-31 11:50:00 --> Loader Class Initialized
INFO - 2025-01-31 11:50:00 --> Helper loaded: url_helper
INFO - 2025-01-31 11:50:00 --> Helper loaded: html_helper
INFO - 2025-01-31 11:50:00 --> Helper loaded: file_helper
INFO - 2025-01-31 11:50:00 --> Helper loaded: string_helper
INFO - 2025-01-31 11:50:00 --> Helper loaded: form_helper
INFO - 2025-01-31 11:50:00 --> Helper loaded: my_helper
INFO - 2025-01-31 11:50:00 --> Database Driver Class Initialized
INFO - 2025-01-31 11:50:00 --> Upload Class Initialized
INFO - 2025-01-31 11:50:00 --> Email Class Initialized
INFO - 2025-01-31 11:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:50:00 --> Form Validation Class Initialized
INFO - 2025-01-31 11:50:00 --> Controller Class Initialized
INFO - 2025-01-31 17:20:00 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:20:00 --> Model "MainModel" initialized
INFO - 2025-01-31 17:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:20:00 --> Pagination Class Initialized
INFO - 2025-01-31 11:50:51 --> Config Class Initialized
INFO - 2025-01-31 11:50:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:50:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:50:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:50:51 --> URI Class Initialized
INFO - 2025-01-31 11:50:51 --> Router Class Initialized
INFO - 2025-01-31 11:50:51 --> Output Class Initialized
INFO - 2025-01-31 11:50:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:50:51 --> Input Class Initialized
INFO - 2025-01-31 11:50:51 --> Language Class Initialized
INFO - 2025-01-31 11:50:51 --> Loader Class Initialized
INFO - 2025-01-31 11:50:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:50:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:50:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:50:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:50:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:50:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:50:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:50:51 --> Upload Class Initialized
INFO - 2025-01-31 11:50:51 --> Email Class Initialized
INFO - 2025-01-31 11:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:50:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:50:51 --> Controller Class Initialized
INFO - 2025-01-31 17:20:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:20:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:20:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:51:51 --> Config Class Initialized
INFO - 2025-01-31 11:51:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:51:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:51:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:51:51 --> URI Class Initialized
INFO - 2025-01-31 11:51:51 --> Router Class Initialized
INFO - 2025-01-31 11:51:51 --> Output Class Initialized
INFO - 2025-01-31 11:51:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:51:51 --> Input Class Initialized
INFO - 2025-01-31 11:51:51 --> Language Class Initialized
INFO - 2025-01-31 11:51:51 --> Loader Class Initialized
INFO - 2025-01-31 11:51:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:51:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:51:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:51:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:51:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:51:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:51:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:51:51 --> Upload Class Initialized
INFO - 2025-01-31 11:51:51 --> Email Class Initialized
INFO - 2025-01-31 11:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:51:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:51:51 --> Controller Class Initialized
INFO - 2025-01-31 17:21:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:21:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:21:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:52:51 --> Config Class Initialized
INFO - 2025-01-31 11:52:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:52:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:52:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:52:51 --> URI Class Initialized
INFO - 2025-01-31 11:52:51 --> Router Class Initialized
INFO - 2025-01-31 11:52:51 --> Output Class Initialized
INFO - 2025-01-31 11:52:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:52:51 --> Input Class Initialized
INFO - 2025-01-31 11:52:51 --> Language Class Initialized
INFO - 2025-01-31 11:52:51 --> Loader Class Initialized
INFO - 2025-01-31 11:52:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:52:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:52:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:52:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:52:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:52:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:52:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:52:51 --> Upload Class Initialized
INFO - 2025-01-31 11:52:51 --> Email Class Initialized
INFO - 2025-01-31 11:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:52:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:52:51 --> Controller Class Initialized
INFO - 2025-01-31 17:22:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:22:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:22:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:53:51 --> Config Class Initialized
INFO - 2025-01-31 11:53:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:53:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:53:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:53:51 --> URI Class Initialized
INFO - 2025-01-31 11:53:51 --> Router Class Initialized
INFO - 2025-01-31 11:53:51 --> Output Class Initialized
INFO - 2025-01-31 11:53:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:53:51 --> Input Class Initialized
INFO - 2025-01-31 11:53:51 --> Language Class Initialized
INFO - 2025-01-31 11:53:51 --> Loader Class Initialized
INFO - 2025-01-31 11:53:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:53:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:53:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:53:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:53:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:53:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:53:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:53:51 --> Upload Class Initialized
INFO - 2025-01-31 11:53:51 --> Email Class Initialized
INFO - 2025-01-31 11:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:53:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:53:51 --> Controller Class Initialized
INFO - 2025-01-31 17:23:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:23:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:23:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:54:51 --> Config Class Initialized
INFO - 2025-01-31 11:54:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:54:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:54:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:54:51 --> URI Class Initialized
INFO - 2025-01-31 11:54:51 --> Router Class Initialized
INFO - 2025-01-31 11:54:51 --> Output Class Initialized
INFO - 2025-01-31 11:54:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:54:51 --> Input Class Initialized
INFO - 2025-01-31 11:54:51 --> Language Class Initialized
INFO - 2025-01-31 11:54:51 --> Loader Class Initialized
INFO - 2025-01-31 11:54:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:54:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:54:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:54:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:54:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:54:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:54:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:54:51 --> Upload Class Initialized
INFO - 2025-01-31 11:54:51 --> Email Class Initialized
INFO - 2025-01-31 11:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:54:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:54:51 --> Controller Class Initialized
INFO - 2025-01-31 17:24:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:24:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:24:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:55:51 --> Config Class Initialized
INFO - 2025-01-31 11:55:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:55:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:55:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:55:51 --> URI Class Initialized
INFO - 2025-01-31 11:55:51 --> Router Class Initialized
INFO - 2025-01-31 11:55:51 --> Output Class Initialized
INFO - 2025-01-31 11:55:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:55:51 --> Input Class Initialized
INFO - 2025-01-31 11:55:51 --> Language Class Initialized
INFO - 2025-01-31 11:55:51 --> Loader Class Initialized
INFO - 2025-01-31 11:55:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:55:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:55:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:55:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:55:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:55:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:55:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:55:51 --> Upload Class Initialized
INFO - 2025-01-31 11:55:51 --> Email Class Initialized
INFO - 2025-01-31 11:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:55:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:55:51 --> Controller Class Initialized
INFO - 2025-01-31 17:25:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:25:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:25:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:56:51 --> Config Class Initialized
INFO - 2025-01-31 11:56:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:56:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:56:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:56:51 --> URI Class Initialized
INFO - 2025-01-31 11:56:51 --> Router Class Initialized
INFO - 2025-01-31 11:56:51 --> Output Class Initialized
INFO - 2025-01-31 11:56:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:56:51 --> Input Class Initialized
INFO - 2025-01-31 11:56:51 --> Language Class Initialized
INFO - 2025-01-31 11:56:51 --> Loader Class Initialized
INFO - 2025-01-31 11:56:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:56:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:56:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:56:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:56:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:56:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:56:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:56:51 --> Upload Class Initialized
INFO - 2025-01-31 11:56:51 --> Email Class Initialized
INFO - 2025-01-31 11:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:56:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:56:51 --> Controller Class Initialized
INFO - 2025-01-31 17:26:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:26:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:26:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:57:51 --> Config Class Initialized
INFO - 2025-01-31 11:57:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:57:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:57:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:57:51 --> URI Class Initialized
INFO - 2025-01-31 11:57:51 --> Router Class Initialized
INFO - 2025-01-31 11:57:51 --> Output Class Initialized
INFO - 2025-01-31 11:57:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:57:51 --> Input Class Initialized
INFO - 2025-01-31 11:57:51 --> Language Class Initialized
INFO - 2025-01-31 11:57:51 --> Loader Class Initialized
INFO - 2025-01-31 11:57:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:57:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:57:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:57:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:57:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:57:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:57:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:57:51 --> Upload Class Initialized
INFO - 2025-01-31 11:57:51 --> Email Class Initialized
INFO - 2025-01-31 11:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:57:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:57:51 --> Controller Class Initialized
INFO - 2025-01-31 17:27:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:27:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:27:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:58:51 --> Config Class Initialized
INFO - 2025-01-31 11:58:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:58:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:58:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:58:51 --> URI Class Initialized
INFO - 2025-01-31 11:58:51 --> Router Class Initialized
INFO - 2025-01-31 11:58:51 --> Output Class Initialized
INFO - 2025-01-31 11:58:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:58:51 --> Input Class Initialized
INFO - 2025-01-31 11:58:51 --> Language Class Initialized
INFO - 2025-01-31 11:58:51 --> Loader Class Initialized
INFO - 2025-01-31 11:58:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:58:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:58:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:58:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:58:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:58:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:58:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:58:51 --> Upload Class Initialized
INFO - 2025-01-31 11:58:51 --> Email Class Initialized
INFO - 2025-01-31 11:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:58:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:58:51 --> Controller Class Initialized
INFO - 2025-01-31 17:28:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:28:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:28:51 --> Pagination Class Initialized
INFO - 2025-01-31 11:59:51 --> Config Class Initialized
INFO - 2025-01-31 11:59:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 11:59:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 11:59:51 --> Utf8 Class Initialized
INFO - 2025-01-31 11:59:51 --> URI Class Initialized
INFO - 2025-01-31 11:59:51 --> Router Class Initialized
INFO - 2025-01-31 11:59:51 --> Output Class Initialized
INFO - 2025-01-31 11:59:51 --> Security Class Initialized
DEBUG - 2025-01-31 11:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 11:59:51 --> Input Class Initialized
INFO - 2025-01-31 11:59:51 --> Language Class Initialized
INFO - 2025-01-31 11:59:51 --> Loader Class Initialized
INFO - 2025-01-31 11:59:51 --> Helper loaded: url_helper
INFO - 2025-01-31 11:59:51 --> Helper loaded: html_helper
INFO - 2025-01-31 11:59:51 --> Helper loaded: file_helper
INFO - 2025-01-31 11:59:51 --> Helper loaded: string_helper
INFO - 2025-01-31 11:59:51 --> Helper loaded: form_helper
INFO - 2025-01-31 11:59:51 --> Helper loaded: my_helper
INFO - 2025-01-31 11:59:51 --> Database Driver Class Initialized
INFO - 2025-01-31 11:59:51 --> Upload Class Initialized
INFO - 2025-01-31 11:59:51 --> Email Class Initialized
INFO - 2025-01-31 11:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 11:59:51 --> Form Validation Class Initialized
INFO - 2025-01-31 11:59:51 --> Controller Class Initialized
INFO - 2025-01-31 17:29:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:29:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:29:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:00:51 --> Config Class Initialized
INFO - 2025-01-31 12:00:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:00:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:00:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:00:51 --> URI Class Initialized
INFO - 2025-01-31 12:00:51 --> Router Class Initialized
INFO - 2025-01-31 12:00:51 --> Output Class Initialized
INFO - 2025-01-31 12:00:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:00:51 --> Input Class Initialized
INFO - 2025-01-31 12:00:51 --> Language Class Initialized
INFO - 2025-01-31 12:00:51 --> Loader Class Initialized
INFO - 2025-01-31 12:00:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:00:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:00:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:00:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:00:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:00:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:00:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:00:51 --> Upload Class Initialized
INFO - 2025-01-31 12:00:51 --> Email Class Initialized
INFO - 2025-01-31 12:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:00:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:00:51 --> Controller Class Initialized
INFO - 2025-01-31 17:30:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:30:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:30:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:01:51 --> Config Class Initialized
INFO - 2025-01-31 12:01:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:01:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:01:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:01:51 --> URI Class Initialized
INFO - 2025-01-31 12:01:51 --> Router Class Initialized
INFO - 2025-01-31 12:01:51 --> Output Class Initialized
INFO - 2025-01-31 12:01:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:01:51 --> Input Class Initialized
INFO - 2025-01-31 12:01:51 --> Language Class Initialized
INFO - 2025-01-31 12:01:51 --> Loader Class Initialized
INFO - 2025-01-31 12:01:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:01:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:01:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:01:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:01:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:01:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:01:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:01:51 --> Upload Class Initialized
INFO - 2025-01-31 12:01:51 --> Email Class Initialized
INFO - 2025-01-31 12:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:01:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:01:51 --> Controller Class Initialized
INFO - 2025-01-31 17:31:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:31:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:31:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:02:51 --> Config Class Initialized
INFO - 2025-01-31 12:02:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:02:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:02:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:02:51 --> URI Class Initialized
INFO - 2025-01-31 12:02:51 --> Router Class Initialized
INFO - 2025-01-31 12:02:51 --> Output Class Initialized
INFO - 2025-01-31 12:02:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:02:51 --> Input Class Initialized
INFO - 2025-01-31 12:02:51 --> Language Class Initialized
INFO - 2025-01-31 12:02:51 --> Loader Class Initialized
INFO - 2025-01-31 12:02:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:02:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:02:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:02:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:02:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:02:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:02:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:02:51 --> Upload Class Initialized
INFO - 2025-01-31 12:02:51 --> Email Class Initialized
INFO - 2025-01-31 12:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:02:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:02:51 --> Controller Class Initialized
INFO - 2025-01-31 17:32:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:32:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:32:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:03:51 --> Config Class Initialized
INFO - 2025-01-31 12:03:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:03:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:03:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:03:51 --> URI Class Initialized
INFO - 2025-01-31 12:03:51 --> Router Class Initialized
INFO - 2025-01-31 12:03:51 --> Output Class Initialized
INFO - 2025-01-31 12:03:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:03:51 --> Input Class Initialized
INFO - 2025-01-31 12:03:51 --> Language Class Initialized
INFO - 2025-01-31 12:03:51 --> Loader Class Initialized
INFO - 2025-01-31 12:03:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:03:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:03:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:03:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:03:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:03:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:03:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:03:51 --> Upload Class Initialized
INFO - 2025-01-31 12:03:51 --> Email Class Initialized
INFO - 2025-01-31 12:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:03:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:03:51 --> Controller Class Initialized
INFO - 2025-01-31 17:33:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:33:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:33:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:33:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:04:51 --> Config Class Initialized
INFO - 2025-01-31 12:04:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:04:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:04:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:04:51 --> URI Class Initialized
INFO - 2025-01-31 12:04:51 --> Router Class Initialized
INFO - 2025-01-31 12:04:51 --> Output Class Initialized
INFO - 2025-01-31 12:04:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:04:51 --> Input Class Initialized
INFO - 2025-01-31 12:04:51 --> Language Class Initialized
INFO - 2025-01-31 12:04:51 --> Loader Class Initialized
INFO - 2025-01-31 12:04:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:04:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:04:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:04:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:04:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:04:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:04:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:04:51 --> Upload Class Initialized
INFO - 2025-01-31 12:04:51 --> Email Class Initialized
INFO - 2025-01-31 12:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:04:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:04:51 --> Controller Class Initialized
INFO - 2025-01-31 17:34:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:34:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:34:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:05:51 --> Config Class Initialized
INFO - 2025-01-31 12:05:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:05:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:05:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:05:51 --> URI Class Initialized
INFO - 2025-01-31 12:05:51 --> Router Class Initialized
INFO - 2025-01-31 12:05:51 --> Output Class Initialized
INFO - 2025-01-31 12:05:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:05:51 --> Input Class Initialized
INFO - 2025-01-31 12:05:51 --> Language Class Initialized
INFO - 2025-01-31 12:05:51 --> Loader Class Initialized
INFO - 2025-01-31 12:05:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:05:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:05:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:05:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:05:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:05:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:05:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:05:51 --> Upload Class Initialized
INFO - 2025-01-31 12:05:51 --> Email Class Initialized
INFO - 2025-01-31 12:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:05:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:05:51 --> Controller Class Initialized
INFO - 2025-01-31 17:35:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:35:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:35:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:06:51 --> Config Class Initialized
INFO - 2025-01-31 12:06:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:06:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:06:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:06:51 --> URI Class Initialized
INFO - 2025-01-31 12:06:51 --> Router Class Initialized
INFO - 2025-01-31 12:06:51 --> Output Class Initialized
INFO - 2025-01-31 12:06:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:06:51 --> Input Class Initialized
INFO - 2025-01-31 12:06:51 --> Language Class Initialized
INFO - 2025-01-31 12:06:51 --> Loader Class Initialized
INFO - 2025-01-31 12:06:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:06:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:06:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:06:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:06:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:06:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:06:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:06:51 --> Upload Class Initialized
INFO - 2025-01-31 12:06:51 --> Email Class Initialized
INFO - 2025-01-31 12:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:06:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:06:51 --> Controller Class Initialized
INFO - 2025-01-31 17:36:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:36:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:36:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:07:51 --> Config Class Initialized
INFO - 2025-01-31 12:07:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:07:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:07:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:07:51 --> URI Class Initialized
INFO - 2025-01-31 12:07:51 --> Router Class Initialized
INFO - 2025-01-31 12:07:51 --> Output Class Initialized
INFO - 2025-01-31 12:07:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:07:51 --> Input Class Initialized
INFO - 2025-01-31 12:07:51 --> Language Class Initialized
INFO - 2025-01-31 12:07:51 --> Loader Class Initialized
INFO - 2025-01-31 12:07:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:07:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:07:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:07:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:07:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:07:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:07:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:07:51 --> Upload Class Initialized
INFO - 2025-01-31 12:07:51 --> Email Class Initialized
INFO - 2025-01-31 12:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:07:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:07:51 --> Controller Class Initialized
INFO - 2025-01-31 17:37:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:37:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:37:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:12:30 --> Config Class Initialized
INFO - 2025-01-31 12:12:30 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:12:30 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:12:30 --> Utf8 Class Initialized
INFO - 2025-01-31 12:12:30 --> URI Class Initialized
INFO - 2025-01-31 12:12:30 --> Router Class Initialized
INFO - 2025-01-31 12:12:30 --> Output Class Initialized
INFO - 2025-01-31 12:12:30 --> Security Class Initialized
DEBUG - 2025-01-31 12:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:12:30 --> Input Class Initialized
INFO - 2025-01-31 12:12:30 --> Language Class Initialized
INFO - 2025-01-31 12:12:30 --> Loader Class Initialized
INFO - 2025-01-31 12:12:30 --> Helper loaded: url_helper
INFO - 2025-01-31 12:12:30 --> Helper loaded: html_helper
INFO - 2025-01-31 12:12:30 --> Helper loaded: file_helper
INFO - 2025-01-31 12:12:30 --> Helper loaded: string_helper
INFO - 2025-01-31 12:12:30 --> Helper loaded: form_helper
INFO - 2025-01-31 12:12:30 --> Helper loaded: my_helper
INFO - 2025-01-31 12:12:30 --> Database Driver Class Initialized
INFO - 2025-01-31 12:12:30 --> Upload Class Initialized
INFO - 2025-01-31 12:12:30 --> Email Class Initialized
INFO - 2025-01-31 12:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:12:30 --> Form Validation Class Initialized
INFO - 2025-01-31 12:12:30 --> Controller Class Initialized
INFO - 2025-01-31 17:42:30 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:42:30 --> Model "MainModel" initialized
INFO - 2025-01-31 17:42:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:42:30 --> Pagination Class Initialized
INFO - 2025-01-31 12:12:51 --> Config Class Initialized
INFO - 2025-01-31 12:12:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:12:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:12:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:12:51 --> URI Class Initialized
INFO - 2025-01-31 12:12:51 --> Router Class Initialized
INFO - 2025-01-31 12:12:51 --> Output Class Initialized
INFO - 2025-01-31 12:12:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:12:51 --> Input Class Initialized
INFO - 2025-01-31 12:12:51 --> Language Class Initialized
INFO - 2025-01-31 12:12:51 --> Loader Class Initialized
INFO - 2025-01-31 12:12:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:12:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:12:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:12:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:12:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:12:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:12:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:12:51 --> Upload Class Initialized
INFO - 2025-01-31 12:12:51 --> Email Class Initialized
INFO - 2025-01-31 12:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:12:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:12:51 --> Controller Class Initialized
INFO - 2025-01-31 17:42:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:42:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:42:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:13:51 --> Config Class Initialized
INFO - 2025-01-31 12:13:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:13:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:13:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:13:51 --> URI Class Initialized
INFO - 2025-01-31 12:13:51 --> Router Class Initialized
INFO - 2025-01-31 12:13:51 --> Output Class Initialized
INFO - 2025-01-31 12:13:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:13:51 --> Input Class Initialized
INFO - 2025-01-31 12:13:51 --> Language Class Initialized
INFO - 2025-01-31 12:13:51 --> Loader Class Initialized
INFO - 2025-01-31 12:13:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:13:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:13:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:13:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:13:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:13:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:13:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:13:51 --> Upload Class Initialized
INFO - 2025-01-31 12:13:51 --> Email Class Initialized
INFO - 2025-01-31 12:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:13:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:13:51 --> Controller Class Initialized
INFO - 2025-01-31 17:43:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:43:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:43:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:14:51 --> Config Class Initialized
INFO - 2025-01-31 12:14:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:14:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:14:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:14:51 --> URI Class Initialized
INFO - 2025-01-31 12:14:51 --> Router Class Initialized
INFO - 2025-01-31 12:14:51 --> Output Class Initialized
INFO - 2025-01-31 12:14:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:14:51 --> Input Class Initialized
INFO - 2025-01-31 12:14:51 --> Language Class Initialized
INFO - 2025-01-31 12:14:51 --> Loader Class Initialized
INFO - 2025-01-31 12:14:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:14:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:14:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:14:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:14:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:14:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:14:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:14:51 --> Upload Class Initialized
INFO - 2025-01-31 12:14:51 --> Email Class Initialized
INFO - 2025-01-31 12:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:14:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:14:51 --> Controller Class Initialized
INFO - 2025-01-31 17:44:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:44:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:44:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:15:51 --> Config Class Initialized
INFO - 2025-01-31 12:15:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:15:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:15:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:15:51 --> URI Class Initialized
INFO - 2025-01-31 12:15:51 --> Router Class Initialized
INFO - 2025-01-31 12:15:51 --> Output Class Initialized
INFO - 2025-01-31 12:15:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:15:51 --> Input Class Initialized
INFO - 2025-01-31 12:15:51 --> Language Class Initialized
INFO - 2025-01-31 12:15:51 --> Loader Class Initialized
INFO - 2025-01-31 12:15:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:15:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:15:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:15:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:15:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:15:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:15:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:15:51 --> Upload Class Initialized
INFO - 2025-01-31 12:15:51 --> Email Class Initialized
INFO - 2025-01-31 12:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:15:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:15:51 --> Controller Class Initialized
INFO - 2025-01-31 17:45:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:45:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:45:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:16:51 --> Config Class Initialized
INFO - 2025-01-31 12:16:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:16:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:16:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:16:51 --> URI Class Initialized
INFO - 2025-01-31 12:16:51 --> Router Class Initialized
INFO - 2025-01-31 12:16:51 --> Output Class Initialized
INFO - 2025-01-31 12:16:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:16:51 --> Input Class Initialized
INFO - 2025-01-31 12:16:51 --> Language Class Initialized
INFO - 2025-01-31 12:16:51 --> Loader Class Initialized
INFO - 2025-01-31 12:16:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:16:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:16:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:16:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:16:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:16:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:16:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:16:51 --> Upload Class Initialized
INFO - 2025-01-31 12:16:51 --> Email Class Initialized
INFO - 2025-01-31 12:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:16:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:16:51 --> Controller Class Initialized
INFO - 2025-01-31 17:46:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:46:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:46:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:17:51 --> Config Class Initialized
INFO - 2025-01-31 12:17:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:17:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:17:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:17:51 --> URI Class Initialized
INFO - 2025-01-31 12:17:51 --> Router Class Initialized
INFO - 2025-01-31 12:17:51 --> Output Class Initialized
INFO - 2025-01-31 12:17:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:17:51 --> Input Class Initialized
INFO - 2025-01-31 12:17:51 --> Language Class Initialized
INFO - 2025-01-31 12:17:51 --> Loader Class Initialized
INFO - 2025-01-31 12:17:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:17:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:17:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:17:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:17:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:17:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:17:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:17:51 --> Upload Class Initialized
INFO - 2025-01-31 12:17:51 --> Email Class Initialized
INFO - 2025-01-31 12:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:17:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:17:51 --> Controller Class Initialized
INFO - 2025-01-31 17:47:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:47:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:47:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:18:51 --> Config Class Initialized
INFO - 2025-01-31 12:18:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:18:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:18:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:18:51 --> URI Class Initialized
INFO - 2025-01-31 12:18:51 --> Router Class Initialized
INFO - 2025-01-31 12:18:51 --> Output Class Initialized
INFO - 2025-01-31 12:18:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:18:51 --> Input Class Initialized
INFO - 2025-01-31 12:18:51 --> Language Class Initialized
INFO - 2025-01-31 12:18:51 --> Loader Class Initialized
INFO - 2025-01-31 12:18:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:18:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:18:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:18:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:18:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:18:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:18:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:18:51 --> Upload Class Initialized
INFO - 2025-01-31 12:18:51 --> Email Class Initialized
INFO - 2025-01-31 12:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:18:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:18:51 --> Controller Class Initialized
INFO - 2025-01-31 17:48:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:48:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:48:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:48:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:19:51 --> Config Class Initialized
INFO - 2025-01-31 12:19:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:19:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:19:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:19:51 --> URI Class Initialized
INFO - 2025-01-31 12:19:51 --> Router Class Initialized
INFO - 2025-01-31 12:19:51 --> Output Class Initialized
INFO - 2025-01-31 12:19:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:19:51 --> Input Class Initialized
INFO - 2025-01-31 12:19:51 --> Language Class Initialized
INFO - 2025-01-31 12:19:51 --> Loader Class Initialized
INFO - 2025-01-31 12:19:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:19:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:19:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:19:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:19:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:19:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:19:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:19:51 --> Upload Class Initialized
INFO - 2025-01-31 12:19:51 --> Email Class Initialized
INFO - 2025-01-31 12:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:19:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:19:51 --> Controller Class Initialized
INFO - 2025-01-31 17:49:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:49:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:49:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:49:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:20:51 --> Config Class Initialized
INFO - 2025-01-31 12:20:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:20:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:20:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:20:51 --> URI Class Initialized
INFO - 2025-01-31 12:20:51 --> Router Class Initialized
INFO - 2025-01-31 12:20:51 --> Output Class Initialized
INFO - 2025-01-31 12:20:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:20:51 --> Input Class Initialized
INFO - 2025-01-31 12:20:51 --> Language Class Initialized
INFO - 2025-01-31 12:20:51 --> Loader Class Initialized
INFO - 2025-01-31 12:20:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:20:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:20:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:20:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:20:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:20:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:20:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:20:51 --> Upload Class Initialized
INFO - 2025-01-31 12:20:51 --> Email Class Initialized
INFO - 2025-01-31 12:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:20:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:20:51 --> Controller Class Initialized
INFO - 2025-01-31 17:50:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:50:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:50:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:21:51 --> Config Class Initialized
INFO - 2025-01-31 12:21:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:21:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:21:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:21:51 --> URI Class Initialized
INFO - 2025-01-31 12:21:51 --> Router Class Initialized
INFO - 2025-01-31 12:21:51 --> Output Class Initialized
INFO - 2025-01-31 12:21:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:21:51 --> Input Class Initialized
INFO - 2025-01-31 12:21:51 --> Language Class Initialized
INFO - 2025-01-31 12:21:51 --> Loader Class Initialized
INFO - 2025-01-31 12:21:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:21:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:21:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:21:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:21:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:21:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:21:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:21:51 --> Upload Class Initialized
INFO - 2025-01-31 12:21:51 --> Email Class Initialized
INFO - 2025-01-31 12:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:21:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:21:51 --> Controller Class Initialized
INFO - 2025-01-31 17:51:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:51:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:51:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:51:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:22:51 --> Config Class Initialized
INFO - 2025-01-31 12:22:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:22:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:22:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:22:51 --> URI Class Initialized
INFO - 2025-01-31 12:22:51 --> Router Class Initialized
INFO - 2025-01-31 12:22:51 --> Output Class Initialized
INFO - 2025-01-31 12:22:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:22:51 --> Input Class Initialized
INFO - 2025-01-31 12:22:51 --> Language Class Initialized
INFO - 2025-01-31 12:22:51 --> Loader Class Initialized
INFO - 2025-01-31 12:22:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:22:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:22:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:22:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:22:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:22:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:22:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:22:51 --> Upload Class Initialized
INFO - 2025-01-31 12:22:51 --> Email Class Initialized
INFO - 2025-01-31 12:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:22:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:22:51 --> Controller Class Initialized
INFO - 2025-01-31 17:52:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:52:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:52:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:23:51 --> Config Class Initialized
INFO - 2025-01-31 12:23:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:23:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:23:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:23:51 --> URI Class Initialized
INFO - 2025-01-31 12:23:51 --> Router Class Initialized
INFO - 2025-01-31 12:23:51 --> Output Class Initialized
INFO - 2025-01-31 12:23:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:23:51 --> Input Class Initialized
INFO - 2025-01-31 12:23:51 --> Language Class Initialized
INFO - 2025-01-31 12:23:51 --> Loader Class Initialized
INFO - 2025-01-31 12:23:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:23:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:23:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:23:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:23:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:23:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:23:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:23:51 --> Upload Class Initialized
INFO - 2025-01-31 12:23:51 --> Email Class Initialized
INFO - 2025-01-31 12:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:23:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:23:51 --> Controller Class Initialized
INFO - 2025-01-31 17:53:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:53:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:53:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:24:51 --> Config Class Initialized
INFO - 2025-01-31 12:24:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:24:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:24:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:24:51 --> URI Class Initialized
INFO - 2025-01-31 12:24:51 --> Router Class Initialized
INFO - 2025-01-31 12:24:51 --> Output Class Initialized
INFO - 2025-01-31 12:24:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:24:51 --> Input Class Initialized
INFO - 2025-01-31 12:24:51 --> Language Class Initialized
INFO - 2025-01-31 12:24:51 --> Loader Class Initialized
INFO - 2025-01-31 12:24:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:24:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:24:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:24:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:24:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:24:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:24:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:24:51 --> Upload Class Initialized
INFO - 2025-01-31 12:24:51 --> Email Class Initialized
INFO - 2025-01-31 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:24:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:24:51 --> Controller Class Initialized
INFO - 2025-01-31 17:54:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:54:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:54:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:25:51 --> Config Class Initialized
INFO - 2025-01-31 12:25:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:25:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:25:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:25:51 --> URI Class Initialized
INFO - 2025-01-31 12:25:51 --> Router Class Initialized
INFO - 2025-01-31 12:25:51 --> Output Class Initialized
INFO - 2025-01-31 12:25:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:25:51 --> Input Class Initialized
INFO - 2025-01-31 12:25:51 --> Language Class Initialized
INFO - 2025-01-31 12:25:51 --> Loader Class Initialized
INFO - 2025-01-31 12:25:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:25:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:25:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:25:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:25:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:25:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:25:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:25:51 --> Upload Class Initialized
INFO - 2025-01-31 12:25:51 --> Email Class Initialized
INFO - 2025-01-31 12:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:25:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:25:51 --> Controller Class Initialized
INFO - 2025-01-31 17:55:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:55:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:55:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:26:51 --> Config Class Initialized
INFO - 2025-01-31 12:26:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:26:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:26:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:26:51 --> URI Class Initialized
INFO - 2025-01-31 12:26:51 --> Router Class Initialized
INFO - 2025-01-31 12:26:51 --> Output Class Initialized
INFO - 2025-01-31 12:26:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:26:51 --> Input Class Initialized
INFO - 2025-01-31 12:26:51 --> Language Class Initialized
INFO - 2025-01-31 12:26:51 --> Loader Class Initialized
INFO - 2025-01-31 12:26:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:26:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:26:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:26:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:26:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:26:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:26:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:26:51 --> Upload Class Initialized
INFO - 2025-01-31 12:26:51 --> Email Class Initialized
INFO - 2025-01-31 12:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:26:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:26:51 --> Controller Class Initialized
INFO - 2025-01-31 17:56:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:56:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:56:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:27:51 --> Config Class Initialized
INFO - 2025-01-31 12:27:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:27:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:27:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:27:51 --> URI Class Initialized
INFO - 2025-01-31 12:27:51 --> Router Class Initialized
INFO - 2025-01-31 12:27:51 --> Output Class Initialized
INFO - 2025-01-31 12:27:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:27:51 --> Input Class Initialized
INFO - 2025-01-31 12:27:51 --> Language Class Initialized
INFO - 2025-01-31 12:27:51 --> Loader Class Initialized
INFO - 2025-01-31 12:27:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:27:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:27:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:27:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:27:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:27:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:27:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:27:51 --> Upload Class Initialized
INFO - 2025-01-31 12:27:51 --> Email Class Initialized
INFO - 2025-01-31 12:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:27:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:27:51 --> Controller Class Initialized
INFO - 2025-01-31 17:57:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:57:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:57:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:28:51 --> Config Class Initialized
INFO - 2025-01-31 12:28:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:28:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:28:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:28:51 --> URI Class Initialized
INFO - 2025-01-31 12:28:51 --> Router Class Initialized
INFO - 2025-01-31 12:28:51 --> Output Class Initialized
INFO - 2025-01-31 12:28:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:28:51 --> Input Class Initialized
INFO - 2025-01-31 12:28:51 --> Language Class Initialized
INFO - 2025-01-31 12:28:51 --> Loader Class Initialized
INFO - 2025-01-31 12:28:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:28:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:28:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:28:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:28:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:28:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:28:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:28:51 --> Upload Class Initialized
INFO - 2025-01-31 12:28:51 --> Email Class Initialized
INFO - 2025-01-31 12:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:28:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:28:51 --> Controller Class Initialized
INFO - 2025-01-31 17:58:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:58:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:58:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:29:51 --> Config Class Initialized
INFO - 2025-01-31 12:29:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:29:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:29:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:29:51 --> URI Class Initialized
INFO - 2025-01-31 12:29:51 --> Router Class Initialized
INFO - 2025-01-31 12:29:51 --> Output Class Initialized
INFO - 2025-01-31 12:29:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:29:51 --> Input Class Initialized
INFO - 2025-01-31 12:29:51 --> Language Class Initialized
INFO - 2025-01-31 12:29:51 --> Loader Class Initialized
INFO - 2025-01-31 12:29:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:29:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:29:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:29:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:29:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:29:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:29:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:29:51 --> Upload Class Initialized
INFO - 2025-01-31 12:29:51 --> Email Class Initialized
INFO - 2025-01-31 12:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:29:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:29:51 --> Controller Class Initialized
INFO - 2025-01-31 17:59:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 17:59:51 --> Model "MainModel" initialized
INFO - 2025-01-31 17:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 17:59:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:30:51 --> Config Class Initialized
INFO - 2025-01-31 12:30:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:30:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:30:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:30:51 --> URI Class Initialized
INFO - 2025-01-31 12:30:51 --> Router Class Initialized
INFO - 2025-01-31 12:30:51 --> Output Class Initialized
INFO - 2025-01-31 12:30:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:30:51 --> Input Class Initialized
INFO - 2025-01-31 12:30:51 --> Language Class Initialized
INFO - 2025-01-31 12:30:51 --> Loader Class Initialized
INFO - 2025-01-31 12:30:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:30:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:30:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:30:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:30:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:30:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:30:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:30:51 --> Upload Class Initialized
INFO - 2025-01-31 12:30:51 --> Email Class Initialized
INFO - 2025-01-31 12:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:30:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:30:51 --> Controller Class Initialized
INFO - 2025-01-31 18:00:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:00:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:00:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:31:51 --> Config Class Initialized
INFO - 2025-01-31 12:31:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:31:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:31:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:31:51 --> URI Class Initialized
INFO - 2025-01-31 12:31:51 --> Router Class Initialized
INFO - 2025-01-31 12:31:51 --> Output Class Initialized
INFO - 2025-01-31 12:31:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:31:51 --> Input Class Initialized
INFO - 2025-01-31 12:31:51 --> Language Class Initialized
INFO - 2025-01-31 12:31:51 --> Loader Class Initialized
INFO - 2025-01-31 12:31:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:31:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:31:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:31:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:31:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:31:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:31:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:31:51 --> Upload Class Initialized
INFO - 2025-01-31 12:31:51 --> Email Class Initialized
INFO - 2025-01-31 12:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:31:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:31:51 --> Controller Class Initialized
INFO - 2025-01-31 18:01:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:01:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:01:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:32:51 --> Config Class Initialized
INFO - 2025-01-31 12:32:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:32:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:32:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:32:51 --> URI Class Initialized
INFO - 2025-01-31 12:32:51 --> Router Class Initialized
INFO - 2025-01-31 12:32:51 --> Output Class Initialized
INFO - 2025-01-31 12:32:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:32:51 --> Input Class Initialized
INFO - 2025-01-31 12:32:51 --> Language Class Initialized
INFO - 2025-01-31 12:32:51 --> Loader Class Initialized
INFO - 2025-01-31 12:32:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:32:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:32:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:32:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:32:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:32:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:32:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:32:51 --> Upload Class Initialized
INFO - 2025-01-31 12:32:51 --> Email Class Initialized
INFO - 2025-01-31 12:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:32:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:32:51 --> Controller Class Initialized
INFO - 2025-01-31 18:02:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:02:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:02:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:33:51 --> Config Class Initialized
INFO - 2025-01-31 12:33:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:33:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:33:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:33:51 --> URI Class Initialized
INFO - 2025-01-31 12:33:51 --> Router Class Initialized
INFO - 2025-01-31 12:33:51 --> Output Class Initialized
INFO - 2025-01-31 12:33:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:33:51 --> Input Class Initialized
INFO - 2025-01-31 12:33:51 --> Language Class Initialized
INFO - 2025-01-31 12:33:51 --> Loader Class Initialized
INFO - 2025-01-31 12:33:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:33:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:33:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:33:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:33:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:33:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:33:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:33:51 --> Upload Class Initialized
INFO - 2025-01-31 12:33:51 --> Email Class Initialized
INFO - 2025-01-31 12:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:33:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:33:51 --> Controller Class Initialized
INFO - 2025-01-31 18:03:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:03:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:03:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:34:51 --> Config Class Initialized
INFO - 2025-01-31 12:34:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:34:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:34:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:34:51 --> URI Class Initialized
INFO - 2025-01-31 12:34:51 --> Router Class Initialized
INFO - 2025-01-31 12:34:51 --> Output Class Initialized
INFO - 2025-01-31 12:34:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:34:51 --> Input Class Initialized
INFO - 2025-01-31 12:34:51 --> Language Class Initialized
INFO - 2025-01-31 12:34:51 --> Loader Class Initialized
INFO - 2025-01-31 12:34:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:34:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:34:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:34:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:34:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:34:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:34:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:34:51 --> Upload Class Initialized
INFO - 2025-01-31 12:34:51 --> Email Class Initialized
INFO - 2025-01-31 12:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:34:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:34:51 --> Controller Class Initialized
INFO - 2025-01-31 18:04:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:04:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:04:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:04:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:35:51 --> Config Class Initialized
INFO - 2025-01-31 12:35:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:35:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:35:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:35:51 --> URI Class Initialized
INFO - 2025-01-31 12:35:51 --> Router Class Initialized
INFO - 2025-01-31 12:35:51 --> Output Class Initialized
INFO - 2025-01-31 12:35:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:35:51 --> Input Class Initialized
INFO - 2025-01-31 12:35:51 --> Language Class Initialized
INFO - 2025-01-31 12:35:51 --> Loader Class Initialized
INFO - 2025-01-31 12:35:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:35:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:35:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:35:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:35:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:35:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:35:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:35:51 --> Upload Class Initialized
INFO - 2025-01-31 12:35:51 --> Email Class Initialized
INFO - 2025-01-31 12:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:35:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:35:51 --> Controller Class Initialized
INFO - 2025-01-31 18:05:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:05:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:05:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:05:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:36:51 --> Config Class Initialized
INFO - 2025-01-31 12:36:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:36:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:36:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:36:51 --> URI Class Initialized
INFO - 2025-01-31 12:36:51 --> Router Class Initialized
INFO - 2025-01-31 12:36:51 --> Output Class Initialized
INFO - 2025-01-31 12:36:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:36:51 --> Input Class Initialized
INFO - 2025-01-31 12:36:51 --> Language Class Initialized
INFO - 2025-01-31 12:36:51 --> Loader Class Initialized
INFO - 2025-01-31 12:36:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:36:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:36:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:36:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:36:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:36:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:36:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:36:51 --> Upload Class Initialized
INFO - 2025-01-31 12:36:51 --> Email Class Initialized
INFO - 2025-01-31 12:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:36:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:36:51 --> Controller Class Initialized
INFO - 2025-01-31 18:06:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:06:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:06:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:37:51 --> Config Class Initialized
INFO - 2025-01-31 12:37:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:37:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:37:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:37:51 --> URI Class Initialized
INFO - 2025-01-31 12:37:51 --> Router Class Initialized
INFO - 2025-01-31 12:37:51 --> Output Class Initialized
INFO - 2025-01-31 12:37:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:37:51 --> Input Class Initialized
INFO - 2025-01-31 12:37:51 --> Language Class Initialized
INFO - 2025-01-31 12:37:51 --> Loader Class Initialized
INFO - 2025-01-31 12:37:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:37:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:37:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:37:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:37:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:37:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:37:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:37:51 --> Upload Class Initialized
INFO - 2025-01-31 12:37:51 --> Email Class Initialized
INFO - 2025-01-31 12:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:37:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:37:51 --> Controller Class Initialized
INFO - 2025-01-31 18:07:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:07:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:07:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:38:51 --> Config Class Initialized
INFO - 2025-01-31 12:38:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:38:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:38:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:38:51 --> URI Class Initialized
INFO - 2025-01-31 12:38:51 --> Router Class Initialized
INFO - 2025-01-31 12:38:51 --> Output Class Initialized
INFO - 2025-01-31 12:38:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:38:51 --> Input Class Initialized
INFO - 2025-01-31 12:38:51 --> Language Class Initialized
INFO - 2025-01-31 12:38:51 --> Loader Class Initialized
INFO - 2025-01-31 12:38:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:38:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:38:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:38:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:38:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:38:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:38:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:38:51 --> Upload Class Initialized
INFO - 2025-01-31 12:38:51 --> Email Class Initialized
INFO - 2025-01-31 12:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:38:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:38:51 --> Controller Class Initialized
INFO - 2025-01-31 18:08:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:08:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:08:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:39:51 --> Config Class Initialized
INFO - 2025-01-31 12:39:51 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:39:51 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:39:51 --> Utf8 Class Initialized
INFO - 2025-01-31 12:39:51 --> URI Class Initialized
INFO - 2025-01-31 12:39:51 --> Router Class Initialized
INFO - 2025-01-31 12:39:51 --> Output Class Initialized
INFO - 2025-01-31 12:39:51 --> Security Class Initialized
DEBUG - 2025-01-31 12:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:39:51 --> Input Class Initialized
INFO - 2025-01-31 12:39:51 --> Language Class Initialized
INFO - 2025-01-31 12:39:51 --> Loader Class Initialized
INFO - 2025-01-31 12:39:51 --> Helper loaded: url_helper
INFO - 2025-01-31 12:39:51 --> Helper loaded: html_helper
INFO - 2025-01-31 12:39:51 --> Helper loaded: file_helper
INFO - 2025-01-31 12:39:51 --> Helper loaded: string_helper
INFO - 2025-01-31 12:39:51 --> Helper loaded: form_helper
INFO - 2025-01-31 12:39:51 --> Helper loaded: my_helper
INFO - 2025-01-31 12:39:51 --> Database Driver Class Initialized
INFO - 2025-01-31 12:39:51 --> Upload Class Initialized
INFO - 2025-01-31 12:39:51 --> Email Class Initialized
INFO - 2025-01-31 12:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:39:51 --> Form Validation Class Initialized
INFO - 2025-01-31 12:39:51 --> Controller Class Initialized
INFO - 2025-01-31 18:09:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:09:51 --> Model "MainModel" initialized
INFO - 2025-01-31 18:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:09:51 --> Pagination Class Initialized
INFO - 2025-01-31 12:39:58 --> Config Class Initialized
INFO - 2025-01-31 12:39:58 --> Hooks Class Initialized
DEBUG - 2025-01-31 12:39:58 --> UTF-8 Support Enabled
INFO - 2025-01-31 12:39:58 --> Utf8 Class Initialized
INFO - 2025-01-31 12:39:58 --> URI Class Initialized
INFO - 2025-01-31 12:39:58 --> Router Class Initialized
INFO - 2025-01-31 12:39:58 --> Output Class Initialized
INFO - 2025-01-31 12:39:58 --> Security Class Initialized
DEBUG - 2025-01-31 12:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-31 12:39:58 --> Input Class Initialized
INFO - 2025-01-31 12:39:58 --> Language Class Initialized
INFO - 2025-01-31 12:39:58 --> Loader Class Initialized
INFO - 2025-01-31 12:39:58 --> Helper loaded: url_helper
INFO - 2025-01-31 12:39:58 --> Helper loaded: html_helper
INFO - 2025-01-31 12:39:58 --> Helper loaded: file_helper
INFO - 2025-01-31 12:39:58 --> Helper loaded: string_helper
INFO - 2025-01-31 12:39:58 --> Helper loaded: form_helper
INFO - 2025-01-31 12:39:58 --> Helper loaded: my_helper
INFO - 2025-01-31 12:39:58 --> Database Driver Class Initialized
INFO - 2025-01-31 12:39:58 --> Upload Class Initialized
INFO - 2025-01-31 12:39:58 --> Email Class Initialized
INFO - 2025-01-31 12:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-31 12:39:58 --> Form Validation Class Initialized
INFO - 2025-01-31 12:39:58 --> Controller Class Initialized
INFO - 2025-01-31 18:09:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-31 18:09:58 --> Model "MainModel" initialized
INFO - 2025-01-31 18:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-31 18:09:58 --> Pagination Class Initialized
