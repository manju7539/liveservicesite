<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-11 05:06:24 --> Config Class Initialized
INFO - 2024-11-11 05:06:24 --> Hooks Class Initialized
DEBUG - 2024-11-11 05:06:24 --> UTF-8 Support Enabled
INFO - 2024-11-11 05:06:24 --> Utf8 Class Initialized
INFO - 2024-11-11 05:06:24 --> URI Class Initialized
DEBUG - 2024-11-11 05:06:24 --> No URI present. Default controller set.
INFO - 2024-11-11 05:06:24 --> Router Class Initialized
INFO - 2024-11-11 05:06:24 --> Output Class Initialized
INFO - 2024-11-11 05:06:24 --> Security Class Initialized
DEBUG - 2024-11-11 05:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 05:06:24 --> Input Class Initialized
INFO - 2024-11-11 05:06:24 --> Language Class Initialized
INFO - 2024-11-11 05:06:24 --> Loader Class Initialized
INFO - 2024-11-11 05:06:24 --> Helper loaded: url_helper
INFO - 2024-11-11 05:06:24 --> Helper loaded: html_helper
INFO - 2024-11-11 05:06:24 --> Helper loaded: file_helper
INFO - 2024-11-11 05:06:24 --> Helper loaded: string_helper
INFO - 2024-11-11 05:06:24 --> Helper loaded: form_helper
INFO - 2024-11-11 05:06:24 --> Helper loaded: my_helper
INFO - 2024-11-11 05:06:24 --> Database Driver Class Initialized
INFO - 2024-11-11 05:06:26 --> Upload Class Initialized
INFO - 2024-11-11 05:06:26 --> Email Class Initialized
INFO - 2024-11-11 05:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 05:06:26 --> Form Validation Class Initialized
INFO - 2024-11-11 05:06:26 --> Controller Class Initialized
INFO - 2024-11-11 10:36:26 --> Model "MainModel" initialized
INFO - 2024-11-11 10:36:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-11 10:36:26 --> Final output sent to browser
DEBUG - 2024-11-11 10:36:26 --> Total execution time: 2.7087
INFO - 2024-11-11 12:58:07 --> Config Class Initialized
INFO - 2024-11-11 12:58:07 --> Hooks Class Initialized
DEBUG - 2024-11-11 12:58:07 --> UTF-8 Support Enabled
INFO - 2024-11-11 12:58:07 --> Utf8 Class Initialized
INFO - 2024-11-11 12:58:07 --> URI Class Initialized
DEBUG - 2024-11-11 12:58:07 --> No URI present. Default controller set.
INFO - 2024-11-11 12:58:07 --> Router Class Initialized
INFO - 2024-11-11 12:58:08 --> Output Class Initialized
INFO - 2024-11-11 12:58:08 --> Security Class Initialized
DEBUG - 2024-11-11 12:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 12:58:08 --> Input Class Initialized
INFO - 2024-11-11 12:58:08 --> Language Class Initialized
INFO - 2024-11-11 12:58:08 --> Loader Class Initialized
INFO - 2024-11-11 12:58:09 --> Helper loaded: url_helper
INFO - 2024-11-11 12:58:09 --> Helper loaded: html_helper
INFO - 2024-11-11 12:58:09 --> Helper loaded: file_helper
INFO - 2024-11-11 12:58:09 --> Helper loaded: string_helper
INFO - 2024-11-11 12:58:09 --> Helper loaded: form_helper
INFO - 2024-11-11 12:58:09 --> Helper loaded: my_helper
INFO - 2024-11-11 12:58:09 --> Database Driver Class Initialized
INFO - 2024-11-11 12:58:11 --> Upload Class Initialized
INFO - 2024-11-11 12:58:11 --> Email Class Initialized
INFO - 2024-11-11 12:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 12:58:12 --> Form Validation Class Initialized
INFO - 2024-11-11 12:58:12 --> Controller Class Initialized
INFO - 2024-11-11 18:28:12 --> Model "MainModel" initialized
INFO - 2024-11-11 18:28:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-11 18:28:12 --> Final output sent to browser
DEBUG - 2024-11-11 18:28:12 --> Total execution time: 5.0123
INFO - 2024-11-11 12:58:23 --> Config Class Initialized
INFO - 2024-11-11 12:58:23 --> Hooks Class Initialized
DEBUG - 2024-11-11 12:58:23 --> UTF-8 Support Enabled
INFO - 2024-11-11 12:58:23 --> Utf8 Class Initialized
INFO - 2024-11-11 12:58:23 --> URI Class Initialized
DEBUG - 2024-11-11 12:58:23 --> No URI present. Default controller set.
INFO - 2024-11-11 12:58:23 --> Router Class Initialized
INFO - 2024-11-11 12:58:23 --> Output Class Initialized
INFO - 2024-11-11 12:58:23 --> Security Class Initialized
DEBUG - 2024-11-11 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 12:58:23 --> Input Class Initialized
INFO - 2024-11-11 12:58:23 --> Language Class Initialized
INFO - 2024-11-11 12:58:23 --> Loader Class Initialized
INFO - 2024-11-11 12:58:23 --> Helper loaded: url_helper
INFO - 2024-11-11 12:58:23 --> Helper loaded: html_helper
INFO - 2024-11-11 12:58:23 --> Helper loaded: file_helper
INFO - 2024-11-11 12:58:23 --> Helper loaded: string_helper
INFO - 2024-11-11 12:58:23 --> Helper loaded: form_helper
INFO - 2024-11-11 12:58:23 --> Helper loaded: my_helper
INFO - 2024-11-11 12:58:23 --> Database Driver Class Initialized
INFO - 2024-11-11 12:58:25 --> Upload Class Initialized
INFO - 2024-11-11 12:58:25 --> Email Class Initialized
INFO - 2024-11-11 12:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 12:58:25 --> Form Validation Class Initialized
INFO - 2024-11-11 12:58:25 --> Controller Class Initialized
INFO - 2024-11-11 18:28:25 --> Model "MainModel" initialized
INFO - 2024-11-11 18:28:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-11 18:28:25 --> Final output sent to browser
DEBUG - 2024-11-11 18:28:25 --> Total execution time: 2.1415
INFO - 2024-11-11 13:04:37 --> Config Class Initialized
INFO - 2024-11-11 13:04:37 --> Hooks Class Initialized
DEBUG - 2024-11-11 13:04:37 --> UTF-8 Support Enabled
INFO - 2024-11-11 13:04:37 --> Utf8 Class Initialized
INFO - 2024-11-11 13:04:37 --> URI Class Initialized
DEBUG - 2024-11-11 13:04:37 --> No URI present. Default controller set.
INFO - 2024-11-11 13:04:37 --> Router Class Initialized
INFO - 2024-11-11 13:04:37 --> Output Class Initialized
INFO - 2024-11-11 13:04:37 --> Security Class Initialized
DEBUG - 2024-11-11 13:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 13:04:37 --> Input Class Initialized
INFO - 2024-11-11 13:04:37 --> Language Class Initialized
INFO - 2024-11-11 13:04:37 --> Loader Class Initialized
INFO - 2024-11-11 13:04:37 --> Helper loaded: url_helper
INFO - 2024-11-11 13:04:37 --> Helper loaded: html_helper
INFO - 2024-11-11 13:04:37 --> Helper loaded: file_helper
INFO - 2024-11-11 13:04:37 --> Helper loaded: string_helper
INFO - 2024-11-11 13:04:37 --> Helper loaded: form_helper
INFO - 2024-11-11 13:04:37 --> Helper loaded: my_helper
INFO - 2024-11-11 13:04:37 --> Database Driver Class Initialized
INFO - 2024-11-11 13:04:39 --> Upload Class Initialized
INFO - 2024-11-11 13:04:39 --> Email Class Initialized
INFO - 2024-11-11 13:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 13:04:39 --> Form Validation Class Initialized
INFO - 2024-11-11 13:04:39 --> Controller Class Initialized
INFO - 2024-11-11 18:34:39 --> Model "MainModel" initialized
INFO - 2024-11-11 18:34:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-11 18:34:39 --> Final output sent to browser
DEBUG - 2024-11-11 18:34:39 --> Total execution time: 2.2033
INFO - 2024-11-11 20:32:10 --> Config Class Initialized
INFO - 2024-11-11 20:32:10 --> Hooks Class Initialized
DEBUG - 2024-11-11 20:32:10 --> UTF-8 Support Enabled
INFO - 2024-11-11 20:32:10 --> Utf8 Class Initialized
INFO - 2024-11-11 20:32:10 --> URI Class Initialized
DEBUG - 2024-11-11 20:32:10 --> No URI present. Default controller set.
INFO - 2024-11-11 20:32:10 --> Router Class Initialized
INFO - 2024-11-11 20:32:10 --> Output Class Initialized
INFO - 2024-11-11 20:32:10 --> Security Class Initialized
DEBUG - 2024-11-11 20:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 20:32:10 --> Input Class Initialized
INFO - 2024-11-11 20:32:10 --> Language Class Initialized
INFO - 2024-11-11 20:32:10 --> Loader Class Initialized
INFO - 2024-11-11 20:32:10 --> Helper loaded: url_helper
INFO - 2024-11-11 20:32:10 --> Helper loaded: html_helper
INFO - 2024-11-11 20:32:10 --> Helper loaded: file_helper
INFO - 2024-11-11 20:32:10 --> Helper loaded: string_helper
INFO - 2024-11-11 20:32:10 --> Helper loaded: form_helper
INFO - 2024-11-11 20:32:10 --> Helper loaded: my_helper
INFO - 2024-11-11 20:32:10 --> Database Driver Class Initialized
INFO - 2024-11-11 20:32:12 --> Upload Class Initialized
INFO - 2024-11-11 20:32:12 --> Email Class Initialized
INFO - 2024-11-11 20:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 20:32:12 --> Form Validation Class Initialized
INFO - 2024-11-11 20:32:12 --> Controller Class Initialized
INFO - 2024-11-11 22:31:46 --> Config Class Initialized
INFO - 2024-11-11 22:31:46 --> Hooks Class Initialized
DEBUG - 2024-11-11 22:31:46 --> UTF-8 Support Enabled
INFO - 2024-11-11 22:31:46 --> Utf8 Class Initialized
INFO - 2024-11-11 22:31:46 --> URI Class Initialized
DEBUG - 2024-11-11 22:31:46 --> No URI present. Default controller set.
INFO - 2024-11-11 22:31:46 --> Router Class Initialized
INFO - 2024-11-11 22:31:46 --> Output Class Initialized
INFO - 2024-11-11 22:31:46 --> Security Class Initialized
DEBUG - 2024-11-11 22:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-11 22:31:46 --> Input Class Initialized
INFO - 2024-11-11 22:31:46 --> Language Class Initialized
INFO - 2024-11-11 22:31:46 --> Loader Class Initialized
INFO - 2024-11-11 22:31:46 --> Helper loaded: url_helper
INFO - 2024-11-11 22:31:46 --> Helper loaded: html_helper
INFO - 2024-11-11 22:31:46 --> Helper loaded: file_helper
INFO - 2024-11-11 22:31:46 --> Helper loaded: string_helper
INFO - 2024-11-11 22:31:46 --> Helper loaded: form_helper
INFO - 2024-11-11 22:31:46 --> Helper loaded: my_helper
INFO - 2024-11-11 22:31:46 --> Database Driver Class Initialized
INFO - 2024-11-11 22:31:48 --> Upload Class Initialized
INFO - 2024-11-11 22:31:48 --> Email Class Initialized
INFO - 2024-11-11 22:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-11 22:31:48 --> Form Validation Class Initialized
INFO - 2024-11-11 22:31:48 --> Controller Class Initialized
