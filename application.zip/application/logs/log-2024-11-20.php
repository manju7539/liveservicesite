<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-20 00:58:42 --> Model "MainModel" initialized
INFO - 2024-11-20 00:58:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 00:58:42 --> Final output sent to browser
DEBUG - 2024-11-20 00:58:42 --> Total execution time: 5.6833
INFO - 2024-11-20 05:18:48 --> Model "MainModel" initialized
INFO - 2024-11-20 05:18:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 05:18:48 --> Final output sent to browser
DEBUG - 2024-11-20 05:18:48 --> Total execution time: 2.6486
INFO - 2024-11-20 00:48:14 --> Config Class Initialized
INFO - 2024-11-20 00:48:14 --> Hooks Class Initialized
DEBUG - 2024-11-20 00:48:14 --> UTF-8 Support Enabled
INFO - 2024-11-20 00:48:14 --> Utf8 Class Initialized
INFO - 2024-11-20 00:48:14 --> URI Class Initialized
DEBUG - 2024-11-20 00:48:14 --> No URI present. Default controller set.
INFO - 2024-11-20 00:48:14 --> Router Class Initialized
INFO - 2024-11-20 00:48:14 --> Output Class Initialized
INFO - 2024-11-20 00:48:14 --> Security Class Initialized
DEBUG - 2024-11-20 00:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 00:48:14 --> Input Class Initialized
INFO - 2024-11-20 00:48:14 --> Language Class Initialized
INFO - 2024-11-20 00:48:14 --> Loader Class Initialized
INFO - 2024-11-20 00:48:14 --> Helper loaded: url_helper
INFO - 2024-11-20 00:48:14 --> Helper loaded: html_helper
INFO - 2024-11-20 00:48:14 --> Helper loaded: file_helper
INFO - 2024-11-20 00:48:14 --> Helper loaded: string_helper
INFO - 2024-11-20 00:48:14 --> Helper loaded: form_helper
INFO - 2024-11-20 00:48:14 --> Helper loaded: my_helper
INFO - 2024-11-20 00:48:14 --> Database Driver Class Initialized
INFO - 2024-11-20 00:48:16 --> Upload Class Initialized
INFO - 2024-11-20 00:48:16 --> Email Class Initialized
INFO - 2024-11-20 00:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 00:48:16 --> Form Validation Class Initialized
INFO - 2024-11-20 00:48:16 --> Controller Class Initialized
INFO - 2024-11-20 06:18:16 --> Model "MainModel" initialized
INFO - 2024-11-20 06:18:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 06:18:16 --> Final output sent to browser
DEBUG - 2024-11-20 06:18:16 --> Total execution time: 2.2422
INFO - 2024-11-20 00:48:17 --> Config Class Initialized
INFO - 2024-11-20 00:48:17 --> Hooks Class Initialized
DEBUG - 2024-11-20 00:48:17 --> UTF-8 Support Enabled
INFO - 2024-11-20 00:48:17 --> Utf8 Class Initialized
INFO - 2024-11-20 00:48:17 --> URI Class Initialized
DEBUG - 2024-11-20 00:48:17 --> No URI present. Default controller set.
INFO - 2024-11-20 00:48:17 --> Router Class Initialized
INFO - 2024-11-20 00:48:17 --> Output Class Initialized
INFO - 2024-11-20 00:48:17 --> Security Class Initialized
DEBUG - 2024-11-20 00:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 00:48:17 --> Input Class Initialized
INFO - 2024-11-20 00:48:17 --> Language Class Initialized
INFO - 2024-11-20 00:48:17 --> Loader Class Initialized
INFO - 2024-11-20 00:48:17 --> Helper loaded: url_helper
INFO - 2024-11-20 00:48:17 --> Helper loaded: html_helper
INFO - 2024-11-20 00:48:17 --> Helper loaded: file_helper
INFO - 2024-11-20 00:48:17 --> Helper loaded: string_helper
INFO - 2024-11-20 00:48:17 --> Helper loaded: form_helper
INFO - 2024-11-20 00:48:17 --> Helper loaded: my_helper
INFO - 2024-11-20 00:48:17 --> Database Driver Class Initialized
INFO - 2024-11-20 00:48:19 --> Upload Class Initialized
INFO - 2024-11-20 00:48:19 --> Email Class Initialized
INFO - 2024-11-20 00:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 00:48:19 --> Form Validation Class Initialized
INFO - 2024-11-20 00:48:19 --> Controller Class Initialized
INFO - 2024-11-20 06:18:19 --> Model "MainModel" initialized
INFO - 2024-11-20 06:18:19 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 06:18:19 --> Final output sent to browser
DEBUG - 2024-11-20 06:18:19 --> Total execution time: 2.1259
INFO - 2024-11-20 00:48:20 --> Config Class Initialized
INFO - 2024-11-20 00:48:20 --> Hooks Class Initialized
DEBUG - 2024-11-20 00:48:20 --> UTF-8 Support Enabled
INFO - 2024-11-20 00:48:20 --> Utf8 Class Initialized
INFO - 2024-11-20 00:48:20 --> URI Class Initialized
DEBUG - 2024-11-20 00:48:20 --> No URI present. Default controller set.
INFO - 2024-11-20 00:48:20 --> Router Class Initialized
INFO - 2024-11-20 00:48:20 --> Output Class Initialized
INFO - 2024-11-20 00:48:20 --> Security Class Initialized
DEBUG - 2024-11-20 00:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 00:48:20 --> Input Class Initialized
INFO - 2024-11-20 00:48:20 --> Language Class Initialized
INFO - 2024-11-20 00:48:20 --> Loader Class Initialized
INFO - 2024-11-20 00:48:20 --> Helper loaded: url_helper
INFO - 2024-11-20 00:48:20 --> Helper loaded: html_helper
INFO - 2024-11-20 00:48:20 --> Helper loaded: file_helper
INFO - 2024-11-20 00:48:20 --> Helper loaded: string_helper
INFO - 2024-11-20 00:48:20 --> Helper loaded: form_helper
INFO - 2024-11-20 00:48:20 --> Helper loaded: my_helper
INFO - 2024-11-20 00:48:20 --> Database Driver Class Initialized
INFO - 2024-11-20 00:48:22 --> Upload Class Initialized
INFO - 2024-11-20 00:48:22 --> Email Class Initialized
INFO - 2024-11-20 00:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 00:48:22 --> Form Validation Class Initialized
INFO - 2024-11-20 00:48:22 --> Controller Class Initialized
INFO - 2024-11-20 06:18:22 --> Model "MainModel" initialized
INFO - 2024-11-20 06:18:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 06:18:22 --> Final output sent to browser
DEBUG - 2024-11-20 06:18:22 --> Total execution time: 2.1565
INFO - 2024-11-20 00:48:23 --> Config Class Initialized
INFO - 2024-11-20 00:48:23 --> Hooks Class Initialized
DEBUG - 2024-11-20 00:48:23 --> UTF-8 Support Enabled
INFO - 2024-11-20 00:48:23 --> Utf8 Class Initialized
INFO - 2024-11-20 00:48:23 --> URI Class Initialized
DEBUG - 2024-11-20 00:48:23 --> No URI present. Default controller set.
INFO - 2024-11-20 00:48:23 --> Router Class Initialized
INFO - 2024-11-20 00:48:23 --> Output Class Initialized
INFO - 2024-11-20 00:48:23 --> Security Class Initialized
DEBUG - 2024-11-20 00:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 00:48:23 --> Input Class Initialized
INFO - 2024-11-20 00:48:23 --> Language Class Initialized
INFO - 2024-11-20 00:48:23 --> Loader Class Initialized
INFO - 2024-11-20 00:48:23 --> Helper loaded: url_helper
INFO - 2024-11-20 00:48:23 --> Helper loaded: html_helper
INFO - 2024-11-20 00:48:23 --> Helper loaded: file_helper
INFO - 2024-11-20 00:48:23 --> Helper loaded: string_helper
INFO - 2024-11-20 00:48:23 --> Helper loaded: form_helper
INFO - 2024-11-20 00:48:23 --> Helper loaded: my_helper
INFO - 2024-11-20 00:48:23 --> Database Driver Class Initialized
INFO - 2024-11-20 00:48:25 --> Upload Class Initialized
INFO - 2024-11-20 00:48:25 --> Email Class Initialized
INFO - 2024-11-20 00:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 00:48:25 --> Form Validation Class Initialized
INFO - 2024-11-20 00:48:25 --> Controller Class Initialized
INFO - 2024-11-20 06:18:25 --> Model "MainModel" initialized
INFO - 2024-11-20 06:18:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 06:18:25 --> Final output sent to browser
DEBUG - 2024-11-20 06:18:25 --> Total execution time: 2.1464
INFO - 2024-11-20 01:27:40 --> Config Class Initialized
INFO - 2024-11-20 01:27:40 --> Hooks Class Initialized
DEBUG - 2024-11-20 01:27:40 --> UTF-8 Support Enabled
INFO - 2024-11-20 01:27:40 --> Utf8 Class Initialized
INFO - 2024-11-20 01:27:40 --> URI Class Initialized
DEBUG - 2024-11-20 01:27:40 --> No URI present. Default controller set.
INFO - 2024-11-20 01:27:40 --> Router Class Initialized
INFO - 2024-11-20 01:27:40 --> Output Class Initialized
INFO - 2024-11-20 01:27:40 --> Security Class Initialized
DEBUG - 2024-11-20 01:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 01:27:40 --> Input Class Initialized
INFO - 2024-11-20 01:27:40 --> Language Class Initialized
INFO - 2024-11-20 01:27:40 --> Loader Class Initialized
INFO - 2024-11-20 01:27:40 --> Helper loaded: url_helper
INFO - 2024-11-20 01:27:40 --> Helper loaded: html_helper
INFO - 2024-11-20 01:27:40 --> Helper loaded: file_helper
INFO - 2024-11-20 01:27:40 --> Helper loaded: string_helper
INFO - 2024-11-20 01:27:40 --> Helper loaded: form_helper
INFO - 2024-11-20 01:27:40 --> Helper loaded: my_helper
INFO - 2024-11-20 01:27:40 --> Database Driver Class Initialized
INFO - 2024-11-20 01:27:43 --> Upload Class Initialized
INFO - 2024-11-20 01:27:43 --> Email Class Initialized
INFO - 2024-11-20 01:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 01:27:43 --> Form Validation Class Initialized
INFO - 2024-11-20 01:27:43 --> Controller Class Initialized
INFO - 2024-11-20 06:57:43 --> Model "MainModel" initialized
INFO - 2024-11-20 06:57:43 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 06:57:43 --> Final output sent to browser
DEBUG - 2024-11-20 06:57:43 --> Total execution time: 3.4858
INFO - 2024-11-20 01:27:47 --> Config Class Initialized
INFO - 2024-11-20 01:27:47 --> Hooks Class Initialized
DEBUG - 2024-11-20 01:27:47 --> UTF-8 Support Enabled
INFO - 2024-11-20 01:27:47 --> Utf8 Class Initialized
INFO - 2024-11-20 01:27:47 --> URI Class Initialized
INFO - 2024-11-20 01:27:47 --> Router Class Initialized
INFO - 2024-11-20 01:27:47 --> Output Class Initialized
INFO - 2024-11-20 01:27:47 --> Security Class Initialized
DEBUG - 2024-11-20 01:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 01:27:47 --> Input Class Initialized
INFO - 2024-11-20 01:27:47 --> Language Class Initialized
ERROR - 2024-11-20 01:27:47 --> 404 Page Not Found: Faviconico/index
INFO - 2024-11-20 01:33:59 --> Config Class Initialized
INFO - 2024-11-20 01:33:59 --> Hooks Class Initialized
DEBUG - 2024-11-20 01:33:59 --> UTF-8 Support Enabled
INFO - 2024-11-20 01:33:59 --> Utf8 Class Initialized
INFO - 2024-11-20 01:33:59 --> URI Class Initialized
DEBUG - 2024-11-20 01:33:59 --> No URI present. Default controller set.
INFO - 2024-11-20 01:33:59 --> Router Class Initialized
INFO - 2024-11-20 01:33:59 --> Output Class Initialized
INFO - 2024-11-20 01:33:59 --> Security Class Initialized
DEBUG - 2024-11-20 01:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 01:33:59 --> Input Class Initialized
INFO - 2024-11-20 01:33:59 --> Language Class Initialized
INFO - 2024-11-20 01:33:59 --> Loader Class Initialized
INFO - 2024-11-20 01:33:59 --> Helper loaded: url_helper
INFO - 2024-11-20 01:33:59 --> Helper loaded: html_helper
INFO - 2024-11-20 01:33:59 --> Helper loaded: file_helper
INFO - 2024-11-20 01:33:59 --> Helper loaded: string_helper
INFO - 2024-11-20 01:33:59 --> Helper loaded: form_helper
INFO - 2024-11-20 01:33:59 --> Helper loaded: my_helper
INFO - 2024-11-20 01:33:59 --> Database Driver Class Initialized
INFO - 2024-11-20 01:34:02 --> Config Class Initialized
INFO - 2024-11-20 01:34:02 --> Hooks Class Initialized
DEBUG - 2024-11-20 01:34:02 --> UTF-8 Support Enabled
INFO - 2024-11-20 01:34:02 --> Utf8 Class Initialized
INFO - 2024-11-20 01:34:02 --> URI Class Initialized
DEBUG - 2024-11-20 01:34:02 --> No URI present. Default controller set.
INFO - 2024-11-20 01:34:02 --> Router Class Initialized
INFO - 2024-11-20 01:34:02 --> Output Class Initialized
INFO - 2024-11-20 01:34:02 --> Security Class Initialized
DEBUG - 2024-11-20 01:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 01:34:02 --> Input Class Initialized
INFO - 2024-11-20 01:34:02 --> Language Class Initialized
INFO - 2024-11-20 01:34:02 --> Loader Class Initialized
INFO - 2024-11-20 01:34:02 --> Helper loaded: url_helper
INFO - 2024-11-20 01:34:02 --> Helper loaded: html_helper
INFO - 2024-11-20 01:34:02 --> Helper loaded: file_helper
INFO - 2024-11-20 01:34:02 --> Helper loaded: string_helper
INFO - 2024-11-20 01:34:02 --> Helper loaded: form_helper
INFO - 2024-11-20 01:34:02 --> Helper loaded: my_helper
INFO - 2024-11-20 01:34:02 --> Database Driver Class Initialized
INFO - 2024-11-20 01:34:02 --> Upload Class Initialized
INFO - 2024-11-20 01:34:02 --> Email Class Initialized
INFO - 2024-11-20 01:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 01:34:02 --> Form Validation Class Initialized
INFO - 2024-11-20 01:34:02 --> Controller Class Initialized
INFO - 2024-11-20 07:04:02 --> Model "MainModel" initialized
INFO - 2024-11-20 07:04:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 07:04:02 --> Final output sent to browser
DEBUG - 2024-11-20 07:04:02 --> Total execution time: 2.8290
INFO - 2024-11-20 01:34:04 --> Upload Class Initialized
INFO - 2024-11-20 01:34:04 --> Email Class Initialized
INFO - 2024-11-20 01:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 01:34:04 --> Form Validation Class Initialized
INFO - 2024-11-20 01:34:04 --> Controller Class Initialized
INFO - 2024-11-20 07:04:04 --> Model "MainModel" initialized
INFO - 2024-11-20 07:04:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 07:04:04 --> Final output sent to browser
DEBUG - 2024-11-20 07:04:04 --> Total execution time: 2.3842
INFO - 2024-11-20 06:03:27 --> Config Class Initialized
INFO - 2024-11-20 06:03:27 --> Hooks Class Initialized
INFO - 2024-11-20 06:03:27 --> Config Class Initialized
DEBUG - 2024-11-20 06:03:27 --> UTF-8 Support Enabled
INFO - 2024-11-20 06:03:27 --> Hooks Class Initialized
INFO - 2024-11-20 06:03:27 --> Utf8 Class Initialized
DEBUG - 2024-11-20 06:03:27 --> UTF-8 Support Enabled
INFO - 2024-11-20 06:03:27 --> URI Class Initialized
INFO - 2024-11-20 06:03:27 --> Utf8 Class Initialized
INFO - 2024-11-20 06:03:27 --> URI Class Initialized
DEBUG - 2024-11-20 06:03:27 --> No URI present. Default controller set.
DEBUG - 2024-11-20 06:03:27 --> No URI present. Default controller set.
INFO - 2024-11-20 06:03:27 --> Router Class Initialized
INFO - 2024-11-20 06:03:27 --> Router Class Initialized
INFO - 2024-11-20 06:03:27 --> Output Class Initialized
INFO - 2024-11-20 06:03:27 --> Output Class Initialized
INFO - 2024-11-20 06:03:27 --> Security Class Initialized
INFO - 2024-11-20 06:03:27 --> Security Class Initialized
DEBUG - 2024-11-20 06:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-11-20 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 06:03:27 --> Input Class Initialized
INFO - 2024-11-20 06:03:27 --> Input Class Initialized
INFO - 2024-11-20 06:03:27 --> Language Class Initialized
INFO - 2024-11-20 06:03:27 --> Language Class Initialized
INFO - 2024-11-20 06:03:27 --> Loader Class Initialized
INFO - 2024-11-20 06:03:27 --> Loader Class Initialized
INFO - 2024-11-20 06:03:27 --> Helper loaded: url_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: url_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: html_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: html_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: file_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: file_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: string_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: form_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: my_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: string_helper
INFO - 2024-11-20 06:03:27 --> Database Driver Class Initialized
INFO - 2024-11-20 06:03:27 --> Helper loaded: form_helper
INFO - 2024-11-20 06:03:27 --> Helper loaded: my_helper
INFO - 2024-11-20 06:03:27 --> Database Driver Class Initialized
INFO - 2024-11-20 06:03:29 --> Upload Class Initialized
INFO - 2024-11-20 06:03:29 --> Email Class Initialized
INFO - 2024-11-20 06:03:30 --> Upload Class Initialized
INFO - 2024-11-20 06:03:30 --> Email Class Initialized
INFO - 2024-11-20 06:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 06:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 06:03:30 --> Form Validation Class Initialized
INFO - 2024-11-20 06:03:30 --> Form Validation Class Initialized
INFO - 2024-11-20 06:03:30 --> Controller Class Initialized
INFO - 2024-11-20 06:03:30 --> Controller Class Initialized
INFO - 2024-11-20 11:33:30 --> Model "MainModel" initialized
INFO - 2024-11-20 11:33:30 --> Model "MainModel" initialized
INFO - 2024-11-20 11:33:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 11:33:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 11:33:30 --> Final output sent to browser
INFO - 2024-11-20 11:33:30 --> Final output sent to browser
DEBUG - 2024-11-20 11:33:30 --> Total execution time: 2.5621
DEBUG - 2024-11-20 11:33:30 --> Total execution time: 2.5586
INFO - 2024-11-20 14:28:47 --> Config Class Initialized
INFO - 2024-11-20 14:28:47 --> Hooks Class Initialized
DEBUG - 2024-11-20 14:28:47 --> UTF-8 Support Enabled
INFO - 2024-11-20 14:28:47 --> Utf8 Class Initialized
INFO - 2024-11-20 14:28:47 --> URI Class Initialized
DEBUG - 2024-11-20 14:28:47 --> No URI present. Default controller set.
INFO - 2024-11-20 14:28:47 --> Router Class Initialized
INFO - 2024-11-20 14:28:47 --> Output Class Initialized
INFO - 2024-11-20 14:28:47 --> Security Class Initialized
DEBUG - 2024-11-20 14:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 14:28:47 --> Input Class Initialized
INFO - 2024-11-20 14:28:47 --> Language Class Initialized
INFO - 2024-11-20 14:28:47 --> Loader Class Initialized
INFO - 2024-11-20 14:28:47 --> Helper loaded: url_helper
INFO - 2024-11-20 14:28:47 --> Helper loaded: html_helper
INFO - 2024-11-20 14:28:47 --> Helper loaded: file_helper
INFO - 2024-11-20 14:28:47 --> Helper loaded: string_helper
INFO - 2024-11-20 14:28:47 --> Helper loaded: form_helper
INFO - 2024-11-20 14:28:47 --> Helper loaded: my_helper
INFO - 2024-11-20 14:28:47 --> Database Driver Class Initialized
INFO - 2024-11-20 14:28:49 --> Upload Class Initialized
INFO - 2024-11-20 14:28:49 --> Email Class Initialized
INFO - 2024-11-20 14:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 14:28:49 --> Form Validation Class Initialized
INFO - 2024-11-20 14:28:49 --> Controller Class Initialized
INFO - 2024-11-20 19:58:49 --> Model "MainModel" initialized
INFO - 2024-11-20 19:58:50 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 19:58:50 --> Final output sent to browser
DEBUG - 2024-11-20 19:58:50 --> Total execution time: 2.8601
INFO - 2024-11-20 14:29:12 --> Config Class Initialized
INFO - 2024-11-20 14:29:12 --> Hooks Class Initialized
DEBUG - 2024-11-20 14:29:12 --> UTF-8 Support Enabled
INFO - 2024-11-20 14:29:12 --> Utf8 Class Initialized
INFO - 2024-11-20 14:29:12 --> URI Class Initialized
INFO - 2024-11-20 14:29:12 --> Router Class Initialized
INFO - 2024-11-20 14:29:12 --> Output Class Initialized
INFO - 2024-11-20 14:29:12 --> Security Class Initialized
DEBUG - 2024-11-20 14:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 14:29:12 --> Input Class Initialized
INFO - 2024-11-20 14:29:12 --> Language Class Initialized
ERROR - 2024-11-20 14:29:12 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-20 14:29:13 --> Config Class Initialized
INFO - 2024-11-20 14:29:13 --> Hooks Class Initialized
DEBUG - 2024-11-20 14:29:13 --> UTF-8 Support Enabled
INFO - 2024-11-20 14:29:13 --> Utf8 Class Initialized
INFO - 2024-11-20 14:29:13 --> URI Class Initialized
INFO - 2024-11-20 14:29:13 --> Router Class Initialized
INFO - 2024-11-20 14:29:13 --> Output Class Initialized
INFO - 2024-11-20 14:29:13 --> Security Class Initialized
DEBUG - 2024-11-20 14:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 14:29:13 --> Input Class Initialized
INFO - 2024-11-20 14:29:13 --> Language Class Initialized
ERROR - 2024-11-20 14:29:13 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-11-20 14:29:20 --> Config Class Initialized
INFO - 2024-11-20 14:29:20 --> Hooks Class Initialized
DEBUG - 2024-11-20 14:29:20 --> UTF-8 Support Enabled
INFO - 2024-11-20 14:29:20 --> Utf8 Class Initialized
INFO - 2024-11-20 14:29:20 --> URI Class Initialized
INFO - 2024-11-20 14:29:20 --> Router Class Initialized
INFO - 2024-11-20 14:29:20 --> Output Class Initialized
INFO - 2024-11-20 14:29:20 --> Security Class Initialized
DEBUG - 2024-11-20 14:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 14:29:20 --> Input Class Initialized
INFO - 2024-11-20 14:29:20 --> Language Class Initialized
ERROR - 2024-11-20 14:29:20 --> 404 Page Not Found: Configjson/index
INFO - 2024-11-20 14:33:06 --> Config Class Initialized
INFO - 2024-11-20 14:33:06 --> Hooks Class Initialized
DEBUG - 2024-11-20 14:33:06 --> UTF-8 Support Enabled
INFO - 2024-11-20 14:33:06 --> Utf8 Class Initialized
INFO - 2024-11-20 14:33:06 --> URI Class Initialized
DEBUG - 2024-11-20 14:33:06 --> No URI present. Default controller set.
INFO - 2024-11-20 14:33:06 --> Router Class Initialized
INFO - 2024-11-20 14:33:06 --> Output Class Initialized
INFO - 2024-11-20 14:33:06 --> Security Class Initialized
DEBUG - 2024-11-20 14:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 14:33:06 --> Input Class Initialized
INFO - 2024-11-20 14:33:06 --> Language Class Initialized
INFO - 2024-11-20 14:33:06 --> Loader Class Initialized
INFO - 2024-11-20 14:33:06 --> Helper loaded: url_helper
INFO - 2024-11-20 14:33:06 --> Helper loaded: html_helper
INFO - 2024-11-20 14:33:06 --> Helper loaded: file_helper
INFO - 2024-11-20 14:33:06 --> Helper loaded: string_helper
INFO - 2024-11-20 14:33:06 --> Helper loaded: form_helper
INFO - 2024-11-20 14:33:06 --> Helper loaded: my_helper
INFO - 2024-11-20 14:33:06 --> Database Driver Class Initialized
INFO - 2024-11-20 14:33:08 --> Upload Class Initialized
INFO - 2024-11-20 14:33:08 --> Email Class Initialized
INFO - 2024-11-20 14:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-20 14:33:08 --> Form Validation Class Initialized
INFO - 2024-11-20 14:33:08 --> Controller Class Initialized
INFO - 2024-11-20 20:03:08 --> Model "MainModel" initialized
INFO - 2024-11-20 20:03:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-20 20:03:08 --> Final output sent to browser
DEBUG - 2024-11-20 20:03:08 --> Total execution time: 2.1517
INFO - 2024-11-20 14:33:11 --> Config Class Initialized
INFO - 2024-11-20 14:33:11 --> Hooks Class Initialized
DEBUG - 2024-11-20 14:33:11 --> UTF-8 Support Enabled
INFO - 2024-11-20 14:33:11 --> Utf8 Class Initialized
INFO - 2024-11-20 14:33:11 --> URI Class Initialized
INFO - 2024-11-20 14:33:11 --> Router Class Initialized
INFO - 2024-11-20 14:33:11 --> Output Class Initialized
INFO - 2024-11-20 14:33:11 --> Security Class Initialized
DEBUG - 2024-11-20 14:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 14:33:11 --> Input Class Initialized
INFO - 2024-11-20 14:33:11 --> Language Class Initialized
ERROR - 2024-11-20 14:33:11 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-20 14:33:12 --> Config Class Initialized
INFO - 2024-11-20 14:33:12 --> Hooks Class Initialized
DEBUG - 2024-11-20 14:33:12 --> UTF-8 Support Enabled
INFO - 2024-11-20 14:33:12 --> Utf8 Class Initialized
INFO - 2024-11-20 14:33:12 --> URI Class Initialized
INFO - 2024-11-20 14:33:12 --> Router Class Initialized
INFO - 2024-11-20 14:33:12 --> Output Class Initialized
INFO - 2024-11-20 14:33:12 --> Security Class Initialized
DEBUG - 2024-11-20 14:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-20 14:33:12 --> Input Class Initialized
INFO - 2024-11-20 14:33:12 --> Language Class Initialized
ERROR - 2024-11-20 14:33:12 --> 404 Page Not Found: Sitemapxml/index
