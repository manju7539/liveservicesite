<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-24 00:12:39 --> Model "MainModel" initialized
INFO - 2024-12-24 00:12:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-24 00:12:39 --> Final output sent to browser
DEBUG - 2024-12-24 00:12:39 --> Total execution time: 2.3771
INFO - 2024-12-24 00:12:45 --> Model "MainModel" initialized
DEBUG - 2024-12-24 00:12:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-12-24 00:12:46 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-12-24 00:12:46 --> Final output sent to browser
DEBUG - 2024-12-24 00:12:46 --> Total execution time: 2.5348
INFO - 2024-12-24 01:24:54 --> Config Class Initialized
INFO - 2024-12-24 01:24:54 --> Hooks Class Initialized
DEBUG - 2024-12-24 01:24:54 --> UTF-8 Support Enabled
INFO - 2024-12-24 01:24:54 --> Utf8 Class Initialized
INFO - 2024-12-24 01:24:54 --> URI Class Initialized
DEBUG - 2024-12-24 01:24:54 --> No URI present. Default controller set.
INFO - 2024-12-24 01:24:54 --> Router Class Initialized
INFO - 2024-12-24 01:24:54 --> Output Class Initialized
INFO - 2024-12-24 01:24:54 --> Security Class Initialized
DEBUG - 2024-12-24 01:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 01:24:54 --> Input Class Initialized
INFO - 2024-12-24 01:24:54 --> Language Class Initialized
INFO - 2024-12-24 01:24:54 --> Loader Class Initialized
INFO - 2024-12-24 01:24:54 --> Helper loaded: url_helper
INFO - 2024-12-24 01:24:54 --> Helper loaded: html_helper
INFO - 2024-12-24 01:24:54 --> Helper loaded: file_helper
INFO - 2024-12-24 01:24:54 --> Helper loaded: string_helper
INFO - 2024-12-24 01:24:54 --> Helper loaded: form_helper
INFO - 2024-12-24 01:24:54 --> Helper loaded: my_helper
INFO - 2024-12-24 01:24:54 --> Database Driver Class Initialized
INFO - 2024-12-24 01:24:56 --> Upload Class Initialized
INFO - 2024-12-24 01:24:56 --> Email Class Initialized
INFO - 2024-12-24 01:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 01:24:56 --> Form Validation Class Initialized
INFO - 2024-12-24 01:24:56 --> Controller Class Initialized
INFO - 2024-12-24 06:54:56 --> Model "MainModel" initialized
INFO - 2024-12-24 06:54:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-24 06:54:56 --> Final output sent to browser
DEBUG - 2024-12-24 06:54:56 --> Total execution time: 2.2567
INFO - 2024-12-24 01:25:01 --> Config Class Initialized
INFO - 2024-12-24 01:25:01 --> Hooks Class Initialized
DEBUG - 2024-12-24 01:25:01 --> UTF-8 Support Enabled
INFO - 2024-12-24 01:25:01 --> Utf8 Class Initialized
INFO - 2024-12-24 01:25:01 --> URI Class Initialized
DEBUG - 2024-12-24 01:25:01 --> No URI present. Default controller set.
INFO - 2024-12-24 01:25:01 --> Router Class Initialized
INFO - 2024-12-24 01:25:01 --> Output Class Initialized
INFO - 2024-12-24 01:25:01 --> Security Class Initialized
DEBUG - 2024-12-24 01:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 01:25:01 --> Input Class Initialized
INFO - 2024-12-24 01:25:01 --> Language Class Initialized
INFO - 2024-12-24 01:25:01 --> Loader Class Initialized
INFO - 2024-12-24 01:25:01 --> Helper loaded: url_helper
INFO - 2024-12-24 01:25:01 --> Helper loaded: html_helper
INFO - 2024-12-24 01:25:01 --> Helper loaded: file_helper
INFO - 2024-12-24 01:25:01 --> Helper loaded: string_helper
INFO - 2024-12-24 01:25:01 --> Helper loaded: form_helper
INFO - 2024-12-24 01:25:01 --> Helper loaded: my_helper
INFO - 2024-12-24 01:25:01 --> Database Driver Class Initialized
INFO - 2024-12-24 01:25:03 --> Upload Class Initialized
INFO - 2024-12-24 01:25:03 --> Email Class Initialized
INFO - 2024-12-24 01:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 01:25:03 --> Form Validation Class Initialized
INFO - 2024-12-24 01:25:03 --> Controller Class Initialized
INFO - 2024-12-24 06:55:03 --> Model "MainModel" initialized
INFO - 2024-12-24 06:55:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-24 06:55:03 --> Final output sent to browser
DEBUG - 2024-12-24 06:55:03 --> Total execution time: 2.1362
INFO - 2024-12-24 01:26:27 --> Config Class Initialized
INFO - 2024-12-24 01:26:27 --> Hooks Class Initialized
DEBUG - 2024-12-24 01:26:27 --> UTF-8 Support Enabled
INFO - 2024-12-24 01:26:27 --> Utf8 Class Initialized
INFO - 2024-12-24 01:26:27 --> URI Class Initialized
DEBUG - 2024-12-24 01:26:27 --> No URI present. Default controller set.
INFO - 2024-12-24 01:26:27 --> Router Class Initialized
INFO - 2024-12-24 01:26:27 --> Output Class Initialized
INFO - 2024-12-24 01:26:27 --> Security Class Initialized
DEBUG - 2024-12-24 01:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 01:26:27 --> Input Class Initialized
INFO - 2024-12-24 01:26:27 --> Language Class Initialized
INFO - 2024-12-24 01:26:27 --> Loader Class Initialized
INFO - 2024-12-24 01:26:27 --> Helper loaded: url_helper
INFO - 2024-12-24 01:26:27 --> Helper loaded: html_helper
INFO - 2024-12-24 01:26:27 --> Helper loaded: file_helper
INFO - 2024-12-24 01:26:27 --> Helper loaded: string_helper
INFO - 2024-12-24 01:26:27 --> Helper loaded: form_helper
INFO - 2024-12-24 01:26:27 --> Helper loaded: my_helper
INFO - 2024-12-24 01:26:27 --> Database Driver Class Initialized
INFO - 2024-12-24 01:26:29 --> Upload Class Initialized
INFO - 2024-12-24 01:26:29 --> Email Class Initialized
INFO - 2024-12-24 01:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 01:26:29 --> Form Validation Class Initialized
INFO - 2024-12-24 01:26:29 --> Controller Class Initialized
INFO - 2024-12-24 06:56:29 --> Model "MainModel" initialized
INFO - 2024-12-24 06:56:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-24 06:56:29 --> Final output sent to browser
DEBUG - 2024-12-24 06:56:29 --> Total execution time: 2.1358
INFO - 2024-12-24 05:17:37 --> Config Class Initialized
INFO - 2024-12-24 05:17:37 --> Hooks Class Initialized
DEBUG - 2024-12-24 05:17:37 --> UTF-8 Support Enabled
INFO - 2024-12-24 05:17:37 --> Utf8 Class Initialized
INFO - 2024-12-24 05:17:37 --> URI Class Initialized
DEBUG - 2024-12-24 05:17:37 --> No URI present. Default controller set.
INFO - 2024-12-24 05:17:37 --> Router Class Initialized
INFO - 2024-12-24 05:17:37 --> Output Class Initialized
INFO - 2024-12-24 05:17:37 --> Security Class Initialized
DEBUG - 2024-12-24 05:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 05:17:37 --> Input Class Initialized
INFO - 2024-12-24 05:17:37 --> Language Class Initialized
INFO - 2024-12-24 05:17:37 --> Loader Class Initialized
INFO - 2024-12-24 05:17:37 --> Helper loaded: url_helper
INFO - 2024-12-24 05:17:37 --> Helper loaded: html_helper
INFO - 2024-12-24 05:17:37 --> Helper loaded: file_helper
INFO - 2024-12-24 05:17:37 --> Helper loaded: string_helper
INFO - 2024-12-24 05:17:37 --> Helper loaded: form_helper
INFO - 2024-12-24 05:17:37 --> Helper loaded: my_helper
INFO - 2024-12-24 05:17:37 --> Database Driver Class Initialized
INFO - 2024-12-24 05:17:39 --> Upload Class Initialized
INFO - 2024-12-24 05:17:39 --> Email Class Initialized
INFO - 2024-12-24 05:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 05:17:39 --> Form Validation Class Initialized
INFO - 2024-12-24 05:17:39 --> Controller Class Initialized
INFO - 2024-12-24 10:47:39 --> Model "MainModel" initialized
INFO - 2024-12-24 10:47:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-24 10:47:39 --> Final output sent to browser
DEBUG - 2024-12-24 10:47:39 --> Total execution time: 2.3074
INFO - 2024-12-24 18:42:19 --> Config Class Initialized
INFO - 2024-12-24 18:42:19 --> Hooks Class Initialized
DEBUG - 2024-12-24 18:42:19 --> UTF-8 Support Enabled
INFO - 2024-12-24 18:42:19 --> Utf8 Class Initialized
INFO - 2024-12-24 18:42:20 --> URI Class Initialized
DEBUG - 2024-12-24 18:42:20 --> No URI present. Default controller set.
INFO - 2024-12-24 18:42:20 --> Router Class Initialized
INFO - 2024-12-24 18:42:20 --> Output Class Initialized
INFO - 2024-12-24 18:42:20 --> Security Class Initialized
DEBUG - 2024-12-24 18:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-24 18:42:20 --> Input Class Initialized
INFO - 2024-12-24 18:42:20 --> Language Class Initialized
INFO - 2024-12-24 18:42:20 --> Loader Class Initialized
INFO - 2024-12-24 18:42:20 --> Helper loaded: url_helper
INFO - 2024-12-24 18:42:20 --> Helper loaded: html_helper
INFO - 2024-12-24 18:42:20 --> Helper loaded: file_helper
INFO - 2024-12-24 18:42:20 --> Helper loaded: string_helper
INFO - 2024-12-24 18:42:20 --> Helper loaded: form_helper
INFO - 2024-12-24 18:42:20 --> Helper loaded: my_helper
INFO - 2024-12-24 18:42:20 --> Database Driver Class Initialized
INFO - 2024-12-24 18:42:22 --> Upload Class Initialized
INFO - 2024-12-24 18:42:23 --> Email Class Initialized
INFO - 2024-12-24 18:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-24 18:42:23 --> Form Validation Class Initialized
INFO - 2024-12-24 18:42:23 --> Controller Class Initialized
