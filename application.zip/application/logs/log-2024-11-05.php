<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-05 17:13:09 --> Config Class Initialized
INFO - 2024-11-05 17:13:09 --> Hooks Class Initialized
DEBUG - 2024-11-05 17:13:09 --> UTF-8 Support Enabled
INFO - 2024-11-05 17:13:09 --> Utf8 Class Initialized
INFO - 2024-11-05 17:13:09 --> URI Class Initialized
DEBUG - 2024-11-05 17:13:09 --> No URI present. Default controller set.
INFO - 2024-11-05 17:13:09 --> Router Class Initialized
INFO - 2024-11-05 17:13:09 --> Output Class Initialized
INFO - 2024-11-05 17:13:09 --> Security Class Initialized
DEBUG - 2024-11-05 17:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-05 17:13:09 --> Input Class Initialized
INFO - 2024-11-05 17:13:09 --> Language Class Initialized
INFO - 2024-11-05 17:13:09 --> Loader Class Initialized
INFO - 2024-11-05 17:13:09 --> Helper loaded: url_helper
INFO - 2024-11-05 17:13:09 --> Helper loaded: html_helper
INFO - 2024-11-05 17:13:09 --> Helper loaded: file_helper
INFO - 2024-11-05 17:13:10 --> Helper loaded: string_helper
INFO - 2024-11-05 17:13:10 --> Helper loaded: form_helper
INFO - 2024-11-05 17:13:10 --> Helper loaded: my_helper
INFO - 2024-11-05 17:13:10 --> Database Driver Class Initialized
INFO - 2024-11-05 17:13:12 --> Upload Class Initialized
INFO - 2024-11-05 17:13:12 --> Email Class Initialized
INFO - 2024-11-05 17:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-05 17:13:12 --> Form Validation Class Initialized
INFO - 2024-11-05 17:13:12 --> Controller Class Initialized
INFO - 2024-11-05 22:43:12 --> Model "MainModel" initialized
INFO - 2024-11-05 22:43:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-05 22:43:12 --> Final output sent to browser
DEBUG - 2024-11-05 22:43:12 --> Total execution time: 3.3064
INFO - 2024-11-05 17:39:05 --> Config Class Initialized
INFO - 2024-11-05 17:39:05 --> Hooks Class Initialized
DEBUG - 2024-11-05 17:39:05 --> UTF-8 Support Enabled
INFO - 2024-11-05 17:39:05 --> Utf8 Class Initialized
INFO - 2024-11-05 17:39:05 --> URI Class Initialized
DEBUG - 2024-11-05 17:39:05 --> No URI present. Default controller set.
INFO - 2024-11-05 17:39:05 --> Router Class Initialized
INFO - 2024-11-05 17:39:05 --> Output Class Initialized
INFO - 2024-11-05 17:39:05 --> Security Class Initialized
DEBUG - 2024-11-05 17:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-05 17:39:05 --> Input Class Initialized
INFO - 2024-11-05 17:39:05 --> Language Class Initialized
INFO - 2024-11-05 17:39:05 --> Loader Class Initialized
INFO - 2024-11-05 17:39:05 --> Helper loaded: url_helper
INFO - 2024-11-05 17:39:05 --> Helper loaded: html_helper
INFO - 2024-11-05 17:39:06 --> Helper loaded: file_helper
INFO - 2024-11-05 17:39:06 --> Helper loaded: string_helper
INFO - 2024-11-05 17:39:06 --> Helper loaded: form_helper
INFO - 2024-11-05 17:39:06 --> Helper loaded: my_helper
INFO - 2024-11-05 17:39:06 --> Database Driver Class Initialized
INFO - 2024-11-05 17:39:08 --> Upload Class Initialized
INFO - 2024-11-05 17:39:08 --> Email Class Initialized
INFO - 2024-11-05 17:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-05 17:39:08 --> Form Validation Class Initialized
INFO - 2024-11-05 17:39:08 --> Controller Class Initialized
INFO - 2024-11-05 23:09:08 --> Model "MainModel" initialized
INFO - 2024-11-05 23:09:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-05 23:09:08 --> Final output sent to browser
DEBUG - 2024-11-05 23:09:08 --> Total execution time: 2.3089
INFO - 2024-11-05 20:25:43 --> Config Class Initialized
INFO - 2024-11-05 20:25:43 --> Hooks Class Initialized
DEBUG - 2024-11-05 20:25:43 --> UTF-8 Support Enabled
INFO - 2024-11-05 20:25:43 --> Utf8 Class Initialized
INFO - 2024-11-05 20:25:43 --> URI Class Initialized
INFO - 2024-11-05 20:25:43 --> Router Class Initialized
INFO - 2024-11-05 20:25:43 --> Output Class Initialized
INFO - 2024-11-05 20:25:43 --> Security Class Initialized
DEBUG - 2024-11-05 20:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-05 20:25:43 --> Input Class Initialized
INFO - 2024-11-05 20:25:43 --> Language Class Initialized
ERROR - 2024-11-05 20:25:43 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-05 20:25:44 --> Config Class Initialized
INFO - 2024-11-05 20:25:44 --> Hooks Class Initialized
DEBUG - 2024-11-05 20:25:44 --> UTF-8 Support Enabled
INFO - 2024-11-05 20:25:44 --> Utf8 Class Initialized
INFO - 2024-11-05 20:25:44 --> URI Class Initialized
DEBUG - 2024-11-05 20:25:44 --> No URI present. Default controller set.
INFO - 2024-11-05 20:25:44 --> Router Class Initialized
INFO - 2024-11-05 20:25:44 --> Output Class Initialized
INFO - 2024-11-05 20:25:44 --> Security Class Initialized
DEBUG - 2024-11-05 20:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-05 20:25:44 --> Input Class Initialized
INFO - 2024-11-05 20:25:44 --> Language Class Initialized
INFO - 2024-11-05 20:25:44 --> Loader Class Initialized
INFO - 2024-11-05 20:25:44 --> Helper loaded: url_helper
INFO - 2024-11-05 20:25:44 --> Helper loaded: html_helper
INFO - 2024-11-05 20:25:44 --> Helper loaded: file_helper
INFO - 2024-11-05 20:25:44 --> Helper loaded: string_helper
INFO - 2024-11-05 20:25:44 --> Helper loaded: form_helper
INFO - 2024-11-05 20:25:44 --> Helper loaded: my_helper
INFO - 2024-11-05 20:25:44 --> Database Driver Class Initialized
INFO - 2024-11-05 20:25:46 --> Upload Class Initialized
INFO - 2024-11-05 20:25:46 --> Email Class Initialized
INFO - 2024-11-05 20:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-05 20:25:46 --> Form Validation Class Initialized
INFO - 2024-11-05 20:25:46 --> Controller Class Initialized
