<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-12 02:02:13 --> Model "MainModel" initialized
INFO - 2024-11-12 02:02:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-12 02:02:13 --> Final output sent to browser
DEBUG - 2024-11-12 02:02:13 --> Total execution time: 2.3312
INFO - 2024-11-12 04:01:48 --> Model "MainModel" initialized
INFO - 2024-11-12 04:01:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-12 04:01:48 --> Final output sent to browser
DEBUG - 2024-11-12 04:01:48 --> Total execution time: 2.3863
INFO - 2024-11-12 09:27:41 --> Config Class Initialized
INFO - 2024-11-12 09:27:41 --> Hooks Class Initialized
DEBUG - 2024-11-12 09:27:41 --> UTF-8 Support Enabled
INFO - 2024-11-12 09:27:41 --> Utf8 Class Initialized
INFO - 2024-11-12 09:27:41 --> URI Class Initialized
DEBUG - 2024-11-12 09:27:41 --> No URI present. Default controller set.
INFO - 2024-11-12 09:27:41 --> Router Class Initialized
INFO - 2024-11-12 09:27:41 --> Output Class Initialized
INFO - 2024-11-12 09:27:41 --> Security Class Initialized
DEBUG - 2024-11-12 09:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 09:27:41 --> Input Class Initialized
INFO - 2024-11-12 09:27:41 --> Language Class Initialized
INFO - 2024-11-12 09:27:41 --> Loader Class Initialized
INFO - 2024-11-12 09:27:41 --> Helper loaded: url_helper
INFO - 2024-11-12 09:27:41 --> Helper loaded: html_helper
INFO - 2024-11-12 09:27:41 --> Helper loaded: file_helper
INFO - 2024-11-12 09:27:41 --> Helper loaded: string_helper
INFO - 2024-11-12 09:27:41 --> Helper loaded: form_helper
INFO - 2024-11-12 09:27:41 --> Helper loaded: my_helper
INFO - 2024-11-12 09:27:42 --> Database Driver Class Initialized
INFO - 2024-11-12 09:27:44 --> Upload Class Initialized
INFO - 2024-11-12 09:27:44 --> Email Class Initialized
INFO - 2024-11-12 09:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 09:27:44 --> Form Validation Class Initialized
INFO - 2024-11-12 09:27:44 --> Controller Class Initialized
INFO - 2024-11-12 14:57:44 --> Model "MainModel" initialized
INFO - 2024-11-12 14:57:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-12 14:57:44 --> Final output sent to browser
DEBUG - 2024-11-12 14:57:44 --> Total execution time: 3.2539
INFO - 2024-11-12 09:28:06 --> Config Class Initialized
INFO - 2024-11-12 09:28:06 --> Hooks Class Initialized
DEBUG - 2024-11-12 09:28:06 --> UTF-8 Support Enabled
INFO - 2024-11-12 09:28:06 --> Utf8 Class Initialized
INFO - 2024-11-12 09:28:06 --> URI Class Initialized
INFO - 2024-11-12 09:28:06 --> Router Class Initialized
INFO - 2024-11-12 09:28:06 --> Output Class Initialized
INFO - 2024-11-12 09:28:06 --> Security Class Initialized
DEBUG - 2024-11-12 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 09:28:06 --> Input Class Initialized
INFO - 2024-11-12 09:28:06 --> Language Class Initialized
ERROR - 2024-11-12 09:28:06 --> 404 Page Not Found: Static/admin
INFO - 2024-11-12 21:04:14 --> Config Class Initialized
INFO - 2024-11-12 21:04:14 --> Hooks Class Initialized
DEBUG - 2024-11-12 21:04:14 --> UTF-8 Support Enabled
INFO - 2024-11-12 21:04:14 --> Utf8 Class Initialized
INFO - 2024-11-12 21:04:14 --> URI Class Initialized
INFO - 2024-11-12 21:04:14 --> Router Class Initialized
INFO - 2024-11-12 21:04:14 --> Output Class Initialized
INFO - 2024-11-12 21:04:14 --> Security Class Initialized
DEBUG - 2024-11-12 21:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 21:04:14 --> Input Class Initialized
INFO - 2024-11-12 21:04:14 --> Language Class Initialized
ERROR - 2024-11-12 21:04:14 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-12 21:04:15 --> Config Class Initialized
INFO - 2024-11-12 21:04:15 --> Hooks Class Initialized
DEBUG - 2024-11-12 21:04:15 --> UTF-8 Support Enabled
INFO - 2024-11-12 21:04:15 --> Utf8 Class Initialized
INFO - 2024-11-12 21:04:15 --> URI Class Initialized
DEBUG - 2024-11-12 21:04:15 --> No URI present. Default controller set.
INFO - 2024-11-12 21:04:15 --> Router Class Initialized
INFO - 2024-11-12 21:04:15 --> Output Class Initialized
INFO - 2024-11-12 21:04:15 --> Security Class Initialized
DEBUG - 2024-11-12 21:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-12 21:04:15 --> Input Class Initialized
INFO - 2024-11-12 21:04:15 --> Language Class Initialized
INFO - 2024-11-12 21:04:15 --> Loader Class Initialized
INFO - 2024-11-12 21:04:15 --> Helper loaded: url_helper
INFO - 2024-11-12 21:04:15 --> Helper loaded: html_helper
INFO - 2024-11-12 21:04:15 --> Helper loaded: file_helper
INFO - 2024-11-12 21:04:15 --> Helper loaded: string_helper
INFO - 2024-11-12 21:04:15 --> Helper loaded: form_helper
INFO - 2024-11-12 21:04:15 --> Helper loaded: my_helper
INFO - 2024-11-12 21:04:15 --> Database Driver Class Initialized
INFO - 2024-11-12 21:04:17 --> Upload Class Initialized
INFO - 2024-11-12 21:04:17 --> Email Class Initialized
INFO - 2024-11-12 21:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-12 21:04:17 --> Form Validation Class Initialized
INFO - 2024-11-12 21:04:17 --> Controller Class Initialized
