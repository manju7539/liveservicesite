<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-01 01:18:53 --> Config Class Initialized
INFO - 2025-01-01 01:18:53 --> Hooks Class Initialized
DEBUG - 2025-01-01 01:18:53 --> UTF-8 Support Enabled
INFO - 2025-01-01 01:18:53 --> Utf8 Class Initialized
INFO - 2025-01-01 01:18:53 --> URI Class Initialized
DEBUG - 2025-01-01 01:18:53 --> No URI present. Default controller set.
INFO - 2025-01-01 01:18:53 --> Router Class Initialized
INFO - 2025-01-01 01:18:53 --> Output Class Initialized
INFO - 2025-01-01 01:18:53 --> Security Class Initialized
DEBUG - 2025-01-01 01:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 01:18:53 --> Input Class Initialized
INFO - 2025-01-01 01:18:53 --> Language Class Initialized
INFO - 2025-01-01 01:18:53 --> Loader Class Initialized
INFO - 2025-01-01 01:18:53 --> Helper loaded: url_helper
INFO - 2025-01-01 01:18:53 --> Helper loaded: html_helper
INFO - 2025-01-01 01:18:53 --> Helper loaded: file_helper
INFO - 2025-01-01 01:18:53 --> Helper loaded: string_helper
INFO - 2025-01-01 01:18:53 --> Helper loaded: form_helper
INFO - 2025-01-01 01:18:53 --> Helper loaded: my_helper
INFO - 2025-01-01 01:18:53 --> Database Driver Class Initialized
INFO - 2025-01-01 01:18:55 --> Upload Class Initialized
INFO - 2025-01-01 01:18:55 --> Email Class Initialized
INFO - 2025-01-01 01:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-01 01:18:55 --> Form Validation Class Initialized
INFO - 2025-01-01 01:18:55 --> Controller Class Initialized
INFO - 2025-01-01 06:48:55 --> Model "MainModel" initialized
INFO - 2025-01-01 06:48:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2025-01-01 06:48:55 --> Final output sent to browser
DEBUG - 2025-01-01 06:48:55 --> Total execution time: 2.5728
INFO - 2025-01-01 02:13:54 --> Config Class Initialized
INFO - 2025-01-01 02:13:54 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:13:54 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:13:54 --> Utf8 Class Initialized
INFO - 2025-01-01 02:13:54 --> URI Class Initialized
DEBUG - 2025-01-01 02:13:54 --> No URI present. Default controller set.
INFO - 2025-01-01 02:13:54 --> Router Class Initialized
INFO - 2025-01-01 02:13:54 --> Output Class Initialized
INFO - 2025-01-01 02:13:54 --> Security Class Initialized
DEBUG - 2025-01-01 02:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:13:54 --> Input Class Initialized
INFO - 2025-01-01 02:13:54 --> Language Class Initialized
INFO - 2025-01-01 02:13:54 --> Loader Class Initialized
INFO - 2025-01-01 02:13:54 --> Helper loaded: url_helper
INFO - 2025-01-01 02:13:54 --> Helper loaded: html_helper
INFO - 2025-01-01 02:13:54 --> Helper loaded: file_helper
INFO - 2025-01-01 02:13:54 --> Helper loaded: string_helper
INFO - 2025-01-01 02:13:54 --> Helper loaded: form_helper
INFO - 2025-01-01 02:13:54 --> Helper loaded: my_helper
INFO - 2025-01-01 02:13:54 --> Database Driver Class Initialized
INFO - 2025-01-01 02:13:55 --> Config Class Initialized
INFO - 2025-01-01 02:13:55 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:13:55 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:13:55 --> Utf8 Class Initialized
INFO - 2025-01-01 02:13:55 --> URI Class Initialized
DEBUG - 2025-01-01 02:13:55 --> No URI present. Default controller set.
INFO - 2025-01-01 02:13:55 --> Router Class Initialized
INFO - 2025-01-01 02:13:55 --> Output Class Initialized
INFO - 2025-01-01 02:13:55 --> Security Class Initialized
DEBUG - 2025-01-01 02:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:13:55 --> Input Class Initialized
INFO - 2025-01-01 02:13:55 --> Language Class Initialized
INFO - 2025-01-01 02:13:55 --> Loader Class Initialized
INFO - 2025-01-01 02:13:55 --> Helper loaded: url_helper
INFO - 2025-01-01 02:13:55 --> Helper loaded: html_helper
INFO - 2025-01-01 02:13:55 --> Helper loaded: file_helper
INFO - 2025-01-01 02:13:55 --> Helper loaded: string_helper
INFO - 2025-01-01 02:13:55 --> Helper loaded: form_helper
INFO - 2025-01-01 02:13:55 --> Helper loaded: my_helper
INFO - 2025-01-01 02:13:55 --> Database Driver Class Initialized
INFO - 2025-01-01 02:13:56 --> Upload Class Initialized
INFO - 2025-01-01 02:13:57 --> Email Class Initialized
INFO - 2025-01-01 02:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-01 02:13:57 --> Form Validation Class Initialized
INFO - 2025-01-01 02:13:57 --> Controller Class Initialized
INFO - 2025-01-01 07:43:57 --> Model "MainModel" initialized
INFO - 2025-01-01 07:43:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2025-01-01 07:43:57 --> Final output sent to browser
DEBUG - 2025-01-01 07:43:57 --> Total execution time: 2.1747
INFO - 2025-01-01 02:13:57 --> Upload Class Initialized
INFO - 2025-01-01 02:13:57 --> Email Class Initialized
INFO - 2025-01-01 02:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-01 02:13:57 --> Form Validation Class Initialized
INFO - 2025-01-01 02:13:57 --> Controller Class Initialized
INFO - 2025-01-01 07:43:57 --> Model "MainModel" initialized
INFO - 2025-01-01 07:43:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2025-01-01 07:43:57 --> Final output sent to browser
DEBUG - 2025-01-01 07:43:57 --> Total execution time: 2.1395
INFO - 2025-01-01 02:13:58 --> Config Class Initialized
INFO - 2025-01-01 02:13:58 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:13:58 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:13:58 --> Utf8 Class Initialized
INFO - 2025-01-01 02:13:58 --> URI Class Initialized
INFO - 2025-01-01 02:13:58 --> Router Class Initialized
INFO - 2025-01-01 02:13:58 --> Output Class Initialized
INFO - 2025-01-01 02:13:58 --> Security Class Initialized
DEBUG - 2025-01-01 02:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:13:58 --> Input Class Initialized
INFO - 2025-01-01 02:13:58 --> Language Class Initialized
ERROR - 2025-01-01 02:13:58 --> 404 Page Not Found: Actuator/env
INFO - 2025-01-01 02:13:59 --> Config Class Initialized
INFO - 2025-01-01 02:13:59 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:13:59 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:13:59 --> Utf8 Class Initialized
INFO - 2025-01-01 02:13:59 --> URI Class Initialized
INFO - 2025-01-01 02:13:59 --> Router Class Initialized
INFO - 2025-01-01 02:13:59 --> Output Class Initialized
INFO - 2025-01-01 02:13:59 --> Security Class Initialized
DEBUG - 2025-01-01 02:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:13:59 --> Input Class Initialized
INFO - 2025-01-01 02:13:59 --> Language Class Initialized
ERROR - 2025-01-01 02:13:59 --> 404 Page Not Found: Server/index
INFO - 2025-01-01 02:13:59 --> Config Class Initialized
INFO - 2025-01-01 02:13:59 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:13:59 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:13:59 --> Utf8 Class Initialized
INFO - 2025-01-01 02:13:59 --> URI Class Initialized
INFO - 2025-01-01 02:13:59 --> Router Class Initialized
INFO - 2025-01-01 02:13:59 --> Output Class Initialized
INFO - 2025-01-01 02:13:59 --> Security Class Initialized
DEBUG - 2025-01-01 02:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:13:59 --> Input Class Initialized
INFO - 2025-01-01 02:13:59 --> Language Class Initialized
ERROR - 2025-01-01 02:13:59 --> 404 Page Not Found: AHT/AHT_UI
INFO - 2025-01-01 02:14:00 --> Config Class Initialized
INFO - 2025-01-01 02:14:00 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:00 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:00 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:00 --> URI Class Initialized
INFO - 2025-01-01 02:14:00 --> Router Class Initialized
INFO - 2025-01-01 02:14:00 --> Output Class Initialized
INFO - 2025-01-01 02:14:00 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:00 --> Input Class Initialized
INFO - 2025-01-01 02:14:00 --> Language Class Initialized
ERROR - 2025-01-01 02:14:00 --> 404 Page Not Found: Vscode/sftp.json
INFO - 2025-01-01 02:14:00 --> Config Class Initialized
INFO - 2025-01-01 02:14:00 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:00 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:00 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:00 --> URI Class Initialized
INFO - 2025-01-01 02:14:00 --> Router Class Initialized
INFO - 2025-01-01 02:14:00 --> Output Class Initialized
INFO - 2025-01-01 02:14:00 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:00 --> Input Class Initialized
INFO - 2025-01-01 02:14:00 --> Language Class Initialized
ERROR - 2025-01-01 02:14:00 --> 404 Page Not Found: About/index
INFO - 2025-01-01 02:14:01 --> Config Class Initialized
INFO - 2025-01-01 02:14:01 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:01 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:01 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:01 --> URI Class Initialized
INFO - 2025-01-01 02:14:01 --> Router Class Initialized
INFO - 2025-01-01 02:14:01 --> Output Class Initialized
INFO - 2025-01-01 02:14:01 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:01 --> Input Class Initialized
INFO - 2025-01-01 02:14:01 --> Language Class Initialized
ERROR - 2025-01-01 02:14:01 --> 404 Page Not Found: Debug/default
INFO - 2025-01-01 02:14:01 --> Config Class Initialized
INFO - 2025-01-01 02:14:01 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:01 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:01 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:01 --> URI Class Initialized
INFO - 2025-01-01 02:14:01 --> Router Class Initialized
INFO - 2025-01-01 02:14:01 --> Output Class Initialized
INFO - 2025-01-01 02:14:01 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:01 --> Input Class Initialized
INFO - 2025-01-01 02:14:01 --> Language Class Initialized
ERROR - 2025-01-01 02:14:01 --> 404 Page Not Found: V2/_catalog
INFO - 2025-01-01 02:14:02 --> Config Class Initialized
INFO - 2025-01-01 02:14:02 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:02 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:02 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:02 --> URI Class Initialized
INFO - 2025-01-01 02:14:02 --> Router Class Initialized
INFO - 2025-01-01 02:14:02 --> Output Class Initialized
INFO - 2025-01-01 02:14:02 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:02 --> Input Class Initialized
INFO - 2025-01-01 02:14:02 --> Language Class Initialized
ERROR - 2025-01-01 02:14:02 --> 404 Page Not Found: Ecp/Current
INFO - 2025-01-01 02:14:02 --> Config Class Initialized
INFO - 2025-01-01 02:14:02 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:02 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:02 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:02 --> URI Class Initialized
INFO - 2025-01-01 02:14:02 --> Router Class Initialized
INFO - 2025-01-01 02:14:02 --> Output Class Initialized
INFO - 2025-01-01 02:14:02 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:02 --> Input Class Initialized
INFO - 2025-01-01 02:14:02 --> Language Class Initialized
ERROR - 2025-01-01 02:14:02 --> 404 Page Not Found: Server-status/index
INFO - 2025-01-01 02:14:02 --> Config Class Initialized
INFO - 2025-01-01 02:14:02 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:02 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:02 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:02 --> URI Class Initialized
INFO - 2025-01-01 02:14:02 --> Router Class Initialized
INFO - 2025-01-01 02:14:02 --> Output Class Initialized
INFO - 2025-01-01 02:14:02 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:02 --> Input Class Initialized
INFO - 2025-01-01 02:14:02 --> Language Class Initialized
ERROR - 2025-01-01 02:14:02 --> 404 Page Not Found: Loginaction/index
INFO - 2025-01-01 02:14:03 --> Config Class Initialized
INFO - 2025-01-01 02:14:03 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:03 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:03 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:03 --> URI Class Initialized
INFO - 2025-01-01 02:14:03 --> Router Class Initialized
INFO - 2025-01-01 02:14:03 --> Output Class Initialized
INFO - 2025-01-01 02:14:03 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:03 --> Input Class Initialized
INFO - 2025-01-01 02:14:03 --> Language Class Initialized
ERROR - 2025-01-01 02:14:03 --> 404 Page Not Found: _all_dbs/index
INFO - 2025-01-01 02:14:05 --> Config Class Initialized
INFO - 2025-01-01 02:14:05 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:05 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:05 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:05 --> Config Class Initialized
INFO - 2025-01-01 02:14:05 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:05 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:05 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:05 --> URI Class Initialized
INFO - 2025-01-01 02:14:05 --> Router Class Initialized
INFO - 2025-01-01 02:14:05 --> Output Class Initialized
INFO - 2025-01-01 02:14:05 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:05 --> Input Class Initialized
INFO - 2025-01-01 02:14:05 --> Language Class Initialized
ERROR - 2025-01-01 02:14:05 --> 404 Page Not Found: Configjson/index
INFO - 2025-01-01 02:14:05 --> Config Class Initialized
INFO - 2025-01-01 02:14:05 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:06 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:06 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:06 --> URI Class Initialized
INFO - 2025-01-01 02:14:06 --> Router Class Initialized
INFO - 2025-01-01 02:14:06 --> Output Class Initialized
INFO - 2025-01-01 02:14:06 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:06 --> Input Class Initialized
INFO - 2025-01-01 02:14:06 --> Language Class Initialized
ERROR - 2025-01-01 02:14:06 --> 404 Page Not Found: Telescope/requests
INFO - 2025-01-01 02:14:07 --> Config Class Initialized
INFO - 2025-01-01 02:14:07 --> Hooks Class Initialized
DEBUG - 2025-01-01 02:14:07 --> UTF-8 Support Enabled
INFO - 2025-01-01 02:14:07 --> Utf8 Class Initialized
INFO - 2025-01-01 02:14:07 --> URI Class Initialized
DEBUG - 2025-01-01 02:14:07 --> No URI present. Default controller set.
INFO - 2025-01-01 02:14:07 --> Router Class Initialized
INFO - 2025-01-01 02:14:07 --> Output Class Initialized
INFO - 2025-01-01 02:14:07 --> Security Class Initialized
DEBUG - 2025-01-01 02:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-01 02:14:07 --> Input Class Initialized
INFO - 2025-01-01 02:14:07 --> Language Class Initialized
INFO - 2025-01-01 02:14:07 --> Loader Class Initialized
INFO - 2025-01-01 02:14:07 --> Helper loaded: url_helper
INFO - 2025-01-01 02:14:07 --> Helper loaded: html_helper
INFO - 2025-01-01 02:14:07 --> Helper loaded: file_helper
INFO - 2025-01-01 02:14:07 --> Helper loaded: string_helper
INFO - 2025-01-01 02:14:07 --> Helper loaded: form_helper
INFO - 2025-01-01 02:14:07 --> Helper loaded: my_helper
INFO - 2025-01-01 02:14:07 --> Database Driver Class Initialized
INFO - 2025-01-01 02:14:09 --> Upload Class Initialized
INFO - 2025-01-01 02:14:09 --> Email Class Initialized
INFO - 2025-01-01 02:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-01 02:14:09 --> Form Validation Class Initialized
INFO - 2025-01-01 02:14:09 --> Controller Class Initialized
INFO - 2025-01-01 07:44:09 --> Model "MainModel" initialized
INFO - 2025-01-01 07:44:09 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2025-01-01 07:44:09 --> Final output sent to browser
DEBUG - 2025-01-01 07:44:09 --> Total execution time: 2.1323
