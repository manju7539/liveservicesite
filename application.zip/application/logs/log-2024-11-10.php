<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-10 02:03:22 --> Config Class Initialized
INFO - 2024-11-10 02:03:22 --> Hooks Class Initialized
DEBUG - 2024-11-10 02:03:23 --> UTF-8 Support Enabled
INFO - 2024-11-10 02:03:23 --> Utf8 Class Initialized
INFO - 2024-11-10 02:03:24 --> URI Class Initialized
DEBUG - 2024-11-10 02:03:27 --> No URI present. Default controller set.
INFO - 2024-11-10 02:03:27 --> Router Class Initialized
INFO - 2024-11-10 02:03:28 --> Output Class Initialized
INFO - 2024-11-10 02:03:28 --> Security Class Initialized
DEBUG - 2024-11-10 02:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-10 02:03:28 --> Input Class Initialized
INFO - 2024-11-10 02:03:28 --> Language Class Initialized
INFO - 2024-11-10 02:03:30 --> Loader Class Initialized
INFO - 2024-11-10 02:03:32 --> Helper loaded: url_helper
INFO - 2024-11-10 02:03:33 --> Helper loaded: html_helper
INFO - 2024-11-10 02:03:34 --> Helper loaded: file_helper
INFO - 2024-11-10 02:03:34 --> Helper loaded: string_helper
INFO - 2024-11-10 02:03:34 --> Helper loaded: form_helper
INFO - 2024-11-10 02:03:34 --> Helper loaded: my_helper
