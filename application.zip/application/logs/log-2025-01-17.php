<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-17 04:54:17 --> Config Class Initialized
INFO - 2025-01-17 04:54:17 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:54:17 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:54:17 --> Utf8 Class Initialized
INFO - 2025-01-17 04:54:17 --> URI Class Initialized
INFO - 2025-01-17 04:54:17 --> Router Class Initialized
INFO - 2025-01-17 04:54:17 --> Output Class Initialized
INFO - 2025-01-17 04:54:17 --> Security Class Initialized
DEBUG - 2025-01-17 04:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:54:17 --> Input Class Initialized
INFO - 2025-01-17 04:54:17 --> Language Class Initialized
INFO - 2025-01-17 04:54:17 --> Loader Class Initialized
INFO - 2025-01-17 04:54:17 --> Helper loaded: url_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: html_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: file_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: string_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: form_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: my_helper
INFO - 2025-01-17 04:54:17 --> Database Driver Class Initialized
INFO - 2025-01-17 04:54:17 --> Upload Class Initialized
INFO - 2025-01-17 04:54:17 --> Email Class Initialized
INFO - 2025-01-17 04:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:54:17 --> Form Validation Class Initialized
INFO - 2025-01-17 04:54:17 --> Controller Class Initialized
INFO - 2025-01-17 10:24:17 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:24:17 --> Model "MainModel" initialized
INFO - 2025-01-17 10:24:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:24:17 --> Pagination Class Initialized
INFO - 2025-01-17 04:54:17 --> Config Class Initialized
INFO - 2025-01-17 04:54:17 --> Hooks Class Initialized
INFO - 2025-01-17 04:54:17 --> Config Class Initialized
DEBUG - 2025-01-17 04:54:17 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:54:17 --> Hooks Class Initialized
INFO - 2025-01-17 04:54:17 --> Utf8 Class Initialized
INFO - 2025-01-17 04:54:17 --> URI Class Initialized
DEBUG - 2025-01-17 04:54:17 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:54:17 --> Utf8 Class Initialized
INFO - 2025-01-17 04:54:17 --> URI Class Initialized
DEBUG - 2025-01-17 04:54:17 --> No URI present. Default controller set.
INFO - 2025-01-17 04:54:17 --> Router Class Initialized
INFO - 2025-01-17 04:54:17 --> Output Class Initialized
INFO - 2025-01-17 04:54:17 --> Security Class Initialized
INFO - 2025-01-17 04:54:17 --> Router Class Initialized
DEBUG - 2025-01-17 04:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:54:17 --> Input Class Initialized
INFO - 2025-01-17 04:54:17 --> Output Class Initialized
INFO - 2025-01-17 04:54:17 --> Language Class Initialized
INFO - 2025-01-17 04:54:17 --> Security Class Initialized
INFO - 2025-01-17 04:54:17 --> Loader Class Initialized
DEBUG - 2025-01-17 04:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:54:17 --> Input Class Initialized
INFO - 2025-01-17 04:54:17 --> Helper loaded: url_helper
INFO - 2025-01-17 04:54:17 --> Language Class Initialized
INFO - 2025-01-17 04:54:17 --> Helper loaded: html_helper
INFO - 2025-01-17 04:54:17 --> Loader Class Initialized
INFO - 2025-01-17 04:54:17 --> Helper loaded: file_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: url_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: string_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: html_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: form_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: file_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: my_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: string_helper
INFO - 2025-01-17 04:54:17 --> Database Driver Class Initialized
INFO - 2025-01-17 04:54:17 --> Helper loaded: form_helper
INFO - 2025-01-17 04:54:17 --> Helper loaded: my_helper
INFO - 2025-01-17 04:54:17 --> Database Driver Class Initialized
INFO - 2025-01-17 04:54:17 --> Upload Class Initialized
INFO - 2025-01-17 04:54:17 --> Upload Class Initialized
INFO - 2025-01-17 04:54:17 --> Email Class Initialized
INFO - 2025-01-17 04:54:17 --> Email Class Initialized
INFO - 2025-01-17 04:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:54:17 --> Form Validation Class Initialized
INFO - 2025-01-17 04:54:17 --> Controller Class Initialized
INFO - 2025-01-17 10:24:17 --> Model "MainModel" initialized
INFO - 2025-01-17 10:24:17 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:24:17 --> Final output sent to browser
DEBUG - 2025-01-17 10:24:17 --> Total execution time: 0.0290
INFO - 2025-01-17 04:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:54:17 --> Form Validation Class Initialized
INFO - 2025-01-17 04:54:17 --> Controller Class Initialized
INFO - 2025-01-17 10:24:17 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:24:17 --> Model "MainModel" initialized
INFO - 2025-01-17 10:24:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:24:17 --> Pagination Class Initialized
INFO - 2025-01-17 04:54:18 --> Config Class Initialized
INFO - 2025-01-17 04:54:18 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:54:18 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:54:18 --> Utf8 Class Initialized
INFO - 2025-01-17 04:54:18 --> URI Class Initialized
DEBUG - 2025-01-17 04:54:18 --> No URI present. Default controller set.
INFO - 2025-01-17 04:54:18 --> Router Class Initialized
INFO - 2025-01-17 04:54:18 --> Output Class Initialized
INFO - 2025-01-17 04:54:18 --> Security Class Initialized
DEBUG - 2025-01-17 04:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:54:18 --> Input Class Initialized
INFO - 2025-01-17 04:54:18 --> Language Class Initialized
INFO - 2025-01-17 04:54:18 --> Loader Class Initialized
INFO - 2025-01-17 04:54:18 --> Helper loaded: url_helper
INFO - 2025-01-17 04:54:18 --> Helper loaded: html_helper
INFO - 2025-01-17 04:54:18 --> Helper loaded: file_helper
INFO - 2025-01-17 04:54:18 --> Helper loaded: string_helper
INFO - 2025-01-17 04:54:18 --> Helper loaded: form_helper
INFO - 2025-01-17 04:54:18 --> Helper loaded: my_helper
INFO - 2025-01-17 04:54:18 --> Database Driver Class Initialized
INFO - 2025-01-17 04:54:18 --> Upload Class Initialized
INFO - 2025-01-17 04:54:18 --> Email Class Initialized
INFO - 2025-01-17 04:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:54:18 --> Form Validation Class Initialized
INFO - 2025-01-17 04:54:18 --> Controller Class Initialized
INFO - 2025-01-17 10:24:18 --> Model "MainModel" initialized
INFO - 2025-01-17 10:24:18 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:24:18 --> Final output sent to browser
DEBUG - 2025-01-17 10:24:18 --> Total execution time: 0.0253
INFO - 2025-01-17 04:54:35 --> Config Class Initialized
INFO - 2025-01-17 04:54:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:54:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:54:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:54:35 --> URI Class Initialized
INFO - 2025-01-17 04:54:35 --> Router Class Initialized
INFO - 2025-01-17 04:54:35 --> Output Class Initialized
INFO - 2025-01-17 04:54:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:54:35 --> Input Class Initialized
INFO - 2025-01-17 04:54:35 --> Language Class Initialized
INFO - 2025-01-17 04:54:35 --> Loader Class Initialized
INFO - 2025-01-17 04:54:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:54:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:54:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:54:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:54:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:54:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:54:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:54:35 --> Upload Class Initialized
INFO - 2025-01-17 04:54:35 --> Email Class Initialized
INFO - 2025-01-17 04:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:54:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:54:35 --> Controller Class Initialized
INFO - 2025-01-17 10:24:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:24:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:24:35 --> Pagination Class Initialized
INFO - 2025-01-17 04:54:36 --> Config Class Initialized
INFO - 2025-01-17 04:54:36 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:54:36 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:54:36 --> Utf8 Class Initialized
INFO - 2025-01-17 04:54:36 --> URI Class Initialized
DEBUG - 2025-01-17 04:54:36 --> No URI present. Default controller set.
INFO - 2025-01-17 04:54:36 --> Router Class Initialized
INFO - 2025-01-17 04:54:36 --> Output Class Initialized
INFO - 2025-01-17 04:54:36 --> Security Class Initialized
DEBUG - 2025-01-17 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:54:36 --> Input Class Initialized
INFO - 2025-01-17 04:54:36 --> Language Class Initialized
INFO - 2025-01-17 04:54:36 --> Loader Class Initialized
INFO - 2025-01-17 04:54:36 --> Helper loaded: url_helper
INFO - 2025-01-17 04:54:36 --> Helper loaded: html_helper
INFO - 2025-01-17 04:54:36 --> Helper loaded: file_helper
INFO - 2025-01-17 04:54:36 --> Helper loaded: string_helper
INFO - 2025-01-17 04:54:36 --> Helper loaded: form_helper
INFO - 2025-01-17 04:54:36 --> Helper loaded: my_helper
INFO - 2025-01-17 04:54:36 --> Database Driver Class Initialized
INFO - 2025-01-17 04:54:36 --> Upload Class Initialized
INFO - 2025-01-17 04:54:36 --> Email Class Initialized
INFO - 2025-01-17 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:54:36 --> Form Validation Class Initialized
INFO - 2025-01-17 04:54:36 --> Controller Class Initialized
INFO - 2025-01-17 10:24:36 --> Model "MainModel" initialized
INFO - 2025-01-17 10:24:36 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:24:36 --> Final output sent to browser
DEBUG - 2025-01-17 10:24:36 --> Total execution time: 0.0260
INFO - 2025-01-17 04:55:35 --> Config Class Initialized
INFO - 2025-01-17 04:55:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:55:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:55:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:55:35 --> URI Class Initialized
INFO - 2025-01-17 04:55:35 --> Router Class Initialized
INFO - 2025-01-17 04:55:35 --> Output Class Initialized
INFO - 2025-01-17 04:55:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:55:35 --> Input Class Initialized
INFO - 2025-01-17 04:55:35 --> Language Class Initialized
INFO - 2025-01-17 04:55:35 --> Loader Class Initialized
INFO - 2025-01-17 04:55:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:55:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:55:35 --> Upload Class Initialized
INFO - 2025-01-17 04:55:35 --> Email Class Initialized
INFO - 2025-01-17 04:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:55:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:55:35 --> Controller Class Initialized
INFO - 2025-01-17 10:25:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:25:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:25:35 --> Pagination Class Initialized
INFO - 2025-01-17 04:55:35 --> Config Class Initialized
INFO - 2025-01-17 04:55:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:55:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:55:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:55:35 --> URI Class Initialized
DEBUG - 2025-01-17 04:55:35 --> No URI present. Default controller set.
INFO - 2025-01-17 04:55:35 --> Router Class Initialized
INFO - 2025-01-17 04:55:35 --> Output Class Initialized
INFO - 2025-01-17 04:55:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:55:35 --> Input Class Initialized
INFO - 2025-01-17 04:55:35 --> Language Class Initialized
INFO - 2025-01-17 04:55:35 --> Loader Class Initialized
INFO - 2025-01-17 04:55:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:55:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:55:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:55:35 --> Upload Class Initialized
INFO - 2025-01-17 04:55:35 --> Email Class Initialized
INFO - 2025-01-17 04:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:55:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:55:35 --> Controller Class Initialized
INFO - 2025-01-17 10:25:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:25:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:25:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:25:35 --> Total execution time: 0.0377
INFO - 2025-01-17 04:56:35 --> Config Class Initialized
INFO - 2025-01-17 04:56:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:56:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:56:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:56:35 --> URI Class Initialized
INFO - 2025-01-17 04:56:35 --> Router Class Initialized
INFO - 2025-01-17 04:56:35 --> Output Class Initialized
INFO - 2025-01-17 04:56:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:56:35 --> Input Class Initialized
INFO - 2025-01-17 04:56:35 --> Language Class Initialized
INFO - 2025-01-17 04:56:35 --> Loader Class Initialized
INFO - 2025-01-17 04:56:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:56:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:56:35 --> Upload Class Initialized
INFO - 2025-01-17 04:56:35 --> Email Class Initialized
INFO - 2025-01-17 04:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:56:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:56:35 --> Controller Class Initialized
INFO - 2025-01-17 10:26:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:26:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:26:35 --> Pagination Class Initialized
INFO - 2025-01-17 04:56:35 --> Config Class Initialized
INFO - 2025-01-17 04:56:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:56:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:56:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:56:35 --> URI Class Initialized
DEBUG - 2025-01-17 04:56:35 --> No URI present. Default controller set.
INFO - 2025-01-17 04:56:35 --> Router Class Initialized
INFO - 2025-01-17 04:56:35 --> Output Class Initialized
INFO - 2025-01-17 04:56:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:56:35 --> Input Class Initialized
INFO - 2025-01-17 04:56:35 --> Language Class Initialized
INFO - 2025-01-17 04:56:35 --> Loader Class Initialized
INFO - 2025-01-17 04:56:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:56:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:56:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:56:35 --> Upload Class Initialized
INFO - 2025-01-17 04:56:35 --> Email Class Initialized
INFO - 2025-01-17 04:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:56:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:56:35 --> Controller Class Initialized
INFO - 2025-01-17 10:26:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:26:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:26:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:26:35 --> Total execution time: 0.0351
INFO - 2025-01-17 04:57:35 --> Config Class Initialized
INFO - 2025-01-17 04:57:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:57:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:57:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:57:35 --> URI Class Initialized
INFO - 2025-01-17 04:57:35 --> Router Class Initialized
INFO - 2025-01-17 04:57:35 --> Output Class Initialized
INFO - 2025-01-17 04:57:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:57:35 --> Input Class Initialized
INFO - 2025-01-17 04:57:35 --> Language Class Initialized
INFO - 2025-01-17 04:57:35 --> Loader Class Initialized
INFO - 2025-01-17 04:57:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:57:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:57:35 --> Upload Class Initialized
INFO - 2025-01-17 04:57:35 --> Email Class Initialized
INFO - 2025-01-17 04:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:57:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:57:35 --> Controller Class Initialized
INFO - 2025-01-17 10:27:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:27:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:27:35 --> Pagination Class Initialized
INFO - 2025-01-17 04:57:35 --> Config Class Initialized
INFO - 2025-01-17 04:57:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:57:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:57:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:57:35 --> URI Class Initialized
DEBUG - 2025-01-17 04:57:35 --> No URI present. Default controller set.
INFO - 2025-01-17 04:57:35 --> Router Class Initialized
INFO - 2025-01-17 04:57:35 --> Output Class Initialized
INFO - 2025-01-17 04:57:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:57:35 --> Input Class Initialized
INFO - 2025-01-17 04:57:35 --> Language Class Initialized
INFO - 2025-01-17 04:57:35 --> Loader Class Initialized
INFO - 2025-01-17 04:57:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:57:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:57:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:57:35 --> Upload Class Initialized
INFO - 2025-01-17 04:57:35 --> Email Class Initialized
INFO - 2025-01-17 04:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:57:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:57:35 --> Controller Class Initialized
INFO - 2025-01-17 10:27:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:27:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:27:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:27:35 --> Total execution time: 0.0378
INFO - 2025-01-17 04:58:35 --> Config Class Initialized
INFO - 2025-01-17 04:58:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:58:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:58:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:58:35 --> URI Class Initialized
INFO - 2025-01-17 04:58:35 --> Router Class Initialized
INFO - 2025-01-17 04:58:35 --> Output Class Initialized
INFO - 2025-01-17 04:58:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:58:35 --> Input Class Initialized
INFO - 2025-01-17 04:58:35 --> Language Class Initialized
INFO - 2025-01-17 04:58:35 --> Loader Class Initialized
INFO - 2025-01-17 04:58:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:58:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:58:35 --> Upload Class Initialized
INFO - 2025-01-17 04:58:35 --> Email Class Initialized
INFO - 2025-01-17 04:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:58:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:58:35 --> Controller Class Initialized
INFO - 2025-01-17 10:28:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:28:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:28:35 --> Pagination Class Initialized
INFO - 2025-01-17 04:58:35 --> Config Class Initialized
INFO - 2025-01-17 04:58:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:58:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:58:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:58:35 --> URI Class Initialized
DEBUG - 2025-01-17 04:58:35 --> No URI present. Default controller set.
INFO - 2025-01-17 04:58:35 --> Router Class Initialized
INFO - 2025-01-17 04:58:35 --> Output Class Initialized
INFO - 2025-01-17 04:58:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:58:35 --> Input Class Initialized
INFO - 2025-01-17 04:58:35 --> Language Class Initialized
INFO - 2025-01-17 04:58:35 --> Loader Class Initialized
INFO - 2025-01-17 04:58:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:58:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:58:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:58:35 --> Upload Class Initialized
INFO - 2025-01-17 04:58:35 --> Email Class Initialized
INFO - 2025-01-17 04:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:58:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:58:35 --> Controller Class Initialized
INFO - 2025-01-17 10:28:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:28:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:28:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:28:35 --> Total execution time: 0.0274
INFO - 2025-01-17 04:59:35 --> Config Class Initialized
INFO - 2025-01-17 04:59:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:59:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:59:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:59:35 --> URI Class Initialized
INFO - 2025-01-17 04:59:35 --> Router Class Initialized
INFO - 2025-01-17 04:59:35 --> Output Class Initialized
INFO - 2025-01-17 04:59:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:59:35 --> Input Class Initialized
INFO - 2025-01-17 04:59:35 --> Language Class Initialized
INFO - 2025-01-17 04:59:35 --> Loader Class Initialized
INFO - 2025-01-17 04:59:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:59:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:59:35 --> Upload Class Initialized
INFO - 2025-01-17 04:59:35 --> Email Class Initialized
INFO - 2025-01-17 04:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:59:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:59:35 --> Controller Class Initialized
INFO - 2025-01-17 10:29:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:29:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:29:35 --> Pagination Class Initialized
INFO - 2025-01-17 04:59:35 --> Config Class Initialized
INFO - 2025-01-17 04:59:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 04:59:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 04:59:35 --> Utf8 Class Initialized
INFO - 2025-01-17 04:59:35 --> URI Class Initialized
DEBUG - 2025-01-17 04:59:35 --> No URI present. Default controller set.
INFO - 2025-01-17 04:59:35 --> Router Class Initialized
INFO - 2025-01-17 04:59:35 --> Output Class Initialized
INFO - 2025-01-17 04:59:35 --> Security Class Initialized
DEBUG - 2025-01-17 04:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 04:59:35 --> Input Class Initialized
INFO - 2025-01-17 04:59:35 --> Language Class Initialized
INFO - 2025-01-17 04:59:35 --> Loader Class Initialized
INFO - 2025-01-17 04:59:35 --> Helper loaded: url_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: html_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: file_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: string_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: form_helper
INFO - 2025-01-17 04:59:35 --> Helper loaded: my_helper
INFO - 2025-01-17 04:59:35 --> Database Driver Class Initialized
INFO - 2025-01-17 04:59:35 --> Upload Class Initialized
INFO - 2025-01-17 04:59:35 --> Email Class Initialized
INFO - 2025-01-17 04:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 04:59:35 --> Form Validation Class Initialized
INFO - 2025-01-17 04:59:35 --> Controller Class Initialized
INFO - 2025-01-17 10:29:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:29:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:29:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:29:35 --> Total execution time: 0.0254
INFO - 2025-01-17 05:00:35 --> Config Class Initialized
INFO - 2025-01-17 05:00:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:00:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:00:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:00:35 --> URI Class Initialized
INFO - 2025-01-17 05:00:35 --> Router Class Initialized
INFO - 2025-01-17 05:00:35 --> Output Class Initialized
INFO - 2025-01-17 05:00:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:00:35 --> Input Class Initialized
INFO - 2025-01-17 05:00:35 --> Language Class Initialized
INFO - 2025-01-17 05:00:35 --> Loader Class Initialized
INFO - 2025-01-17 05:00:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:00:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:00:35 --> Upload Class Initialized
INFO - 2025-01-17 05:00:35 --> Email Class Initialized
INFO - 2025-01-17 05:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:00:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:00:35 --> Controller Class Initialized
INFO - 2025-01-17 10:30:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:30:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:30:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:00:35 --> Config Class Initialized
INFO - 2025-01-17 05:00:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:00:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:00:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:00:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:00:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:00:35 --> Router Class Initialized
INFO - 2025-01-17 05:00:35 --> Output Class Initialized
INFO - 2025-01-17 05:00:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:00:35 --> Input Class Initialized
INFO - 2025-01-17 05:00:35 --> Language Class Initialized
INFO - 2025-01-17 05:00:35 --> Loader Class Initialized
INFO - 2025-01-17 05:00:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:00:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:00:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:00:35 --> Upload Class Initialized
INFO - 2025-01-17 05:00:35 --> Email Class Initialized
INFO - 2025-01-17 05:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:00:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:00:35 --> Controller Class Initialized
INFO - 2025-01-17 10:30:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:30:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:30:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:30:35 --> Total execution time: 0.0323
INFO - 2025-01-17 05:01:35 --> Config Class Initialized
INFO - 2025-01-17 05:01:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:01:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:01:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:01:35 --> URI Class Initialized
INFO - 2025-01-17 05:01:35 --> Router Class Initialized
INFO - 2025-01-17 05:01:35 --> Output Class Initialized
INFO - 2025-01-17 05:01:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:01:35 --> Input Class Initialized
INFO - 2025-01-17 05:01:35 --> Language Class Initialized
INFO - 2025-01-17 05:01:35 --> Loader Class Initialized
INFO - 2025-01-17 05:01:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:01:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:01:35 --> Upload Class Initialized
INFO - 2025-01-17 05:01:35 --> Email Class Initialized
INFO - 2025-01-17 05:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:01:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:01:35 --> Controller Class Initialized
INFO - 2025-01-17 10:31:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:31:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:31:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:01:35 --> Config Class Initialized
INFO - 2025-01-17 05:01:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:01:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:01:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:01:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:01:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:01:35 --> Router Class Initialized
INFO - 2025-01-17 05:01:35 --> Output Class Initialized
INFO - 2025-01-17 05:01:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:01:35 --> Input Class Initialized
INFO - 2025-01-17 05:01:35 --> Language Class Initialized
INFO - 2025-01-17 05:01:35 --> Loader Class Initialized
INFO - 2025-01-17 05:01:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:01:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:01:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:01:35 --> Upload Class Initialized
INFO - 2025-01-17 05:01:35 --> Email Class Initialized
INFO - 2025-01-17 05:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:01:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:01:35 --> Controller Class Initialized
INFO - 2025-01-17 10:31:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:31:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:31:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:31:35 --> Total execution time: 0.0228
INFO - 2025-01-17 05:02:35 --> Config Class Initialized
INFO - 2025-01-17 05:02:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:35 --> URI Class Initialized
INFO - 2025-01-17 05:02:35 --> Router Class Initialized
INFO - 2025-01-17 05:02:35 --> Output Class Initialized
INFO - 2025-01-17 05:02:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:35 --> Input Class Initialized
INFO - 2025-01-17 05:02:35 --> Language Class Initialized
INFO - 2025-01-17 05:02:35 --> Loader Class Initialized
INFO - 2025-01-17 05:02:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:35 --> Upload Class Initialized
INFO - 2025-01-17 05:02:35 --> Email Class Initialized
INFO - 2025-01-17 05:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:35 --> Controller Class Initialized
INFO - 2025-01-17 10:32:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:32:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:32:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:02:35 --> Config Class Initialized
INFO - 2025-01-17 05:02:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:02:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:02:35 --> Router Class Initialized
INFO - 2025-01-17 05:02:35 --> Output Class Initialized
INFO - 2025-01-17 05:02:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:35 --> Input Class Initialized
INFO - 2025-01-17 05:02:35 --> Language Class Initialized
INFO - 2025-01-17 05:02:35 --> Loader Class Initialized
INFO - 2025-01-17 05:02:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:35 --> Upload Class Initialized
INFO - 2025-01-17 05:02:35 --> Email Class Initialized
INFO - 2025-01-17 05:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:35 --> Controller Class Initialized
INFO - 2025-01-17 10:32:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:32:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:32:35 --> Total execution time: 0.0237
INFO - 2025-01-17 05:02:37 --> Config Class Initialized
INFO - 2025-01-17 05:02:37 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:37 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:37 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:37 --> URI Class Initialized
INFO - 2025-01-17 05:02:37 --> Router Class Initialized
INFO - 2025-01-17 05:02:37 --> Output Class Initialized
INFO - 2025-01-17 05:02:37 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:37 --> Input Class Initialized
INFO - 2025-01-17 05:02:37 --> Language Class Initialized
INFO - 2025-01-17 05:02:37 --> Loader Class Initialized
INFO - 2025-01-17 05:02:37 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:37 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:37 --> Upload Class Initialized
INFO - 2025-01-17 05:02:37 --> Email Class Initialized
INFO - 2025-01-17 05:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:37 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:37 --> Controller Class Initialized
INFO - 2025-01-17 10:32:37 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:32:37 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:32:37 --> Pagination Class Initialized
INFO - 2025-01-17 05:02:37 --> Config Class Initialized
INFO - 2025-01-17 05:02:37 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:37 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:37 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:37 --> URI Class Initialized
DEBUG - 2025-01-17 05:02:37 --> No URI present. Default controller set.
INFO - 2025-01-17 05:02:37 --> Router Class Initialized
INFO - 2025-01-17 05:02:37 --> Output Class Initialized
INFO - 2025-01-17 05:02:37 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:37 --> Input Class Initialized
INFO - 2025-01-17 05:02:37 --> Language Class Initialized
INFO - 2025-01-17 05:02:37 --> Loader Class Initialized
INFO - 2025-01-17 05:02:37 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:37 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:37 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:37 --> Upload Class Initialized
INFO - 2025-01-17 05:02:37 --> Email Class Initialized
INFO - 2025-01-17 05:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:37 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:37 --> Controller Class Initialized
INFO - 2025-01-17 10:32:37 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:37 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:32:37 --> Final output sent to browser
DEBUG - 2025-01-17 10:32:37 --> Total execution time: 0.0534
INFO - 2025-01-17 05:02:42 --> Config Class Initialized
INFO - 2025-01-17 05:02:42 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:42 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:42 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:42 --> URI Class Initialized
INFO - 2025-01-17 05:02:42 --> Router Class Initialized
INFO - 2025-01-17 05:02:42 --> Output Class Initialized
INFO - 2025-01-17 05:02:42 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:42 --> Input Class Initialized
INFO - 2025-01-17 05:02:42 --> Language Class Initialized
INFO - 2025-01-17 05:02:42 --> Loader Class Initialized
INFO - 2025-01-17 05:02:42 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:42 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:42 --> Upload Class Initialized
INFO - 2025-01-17 05:02:42 --> Email Class Initialized
INFO - 2025-01-17 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:42 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:42 --> Controller Class Initialized
INFO - 2025-01-17 10:32:42 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:32:42 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:32:42 --> Pagination Class Initialized
INFO - 2025-01-17 05:02:42 --> Config Class Initialized
INFO - 2025-01-17 05:02:42 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:42 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:42 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:42 --> URI Class Initialized
DEBUG - 2025-01-17 05:02:42 --> No URI present. Default controller set.
INFO - 2025-01-17 05:02:42 --> Router Class Initialized
INFO - 2025-01-17 05:02:42 --> Output Class Initialized
INFO - 2025-01-17 05:02:42 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:42 --> Input Class Initialized
INFO - 2025-01-17 05:02:42 --> Language Class Initialized
INFO - 2025-01-17 05:02:42 --> Loader Class Initialized
INFO - 2025-01-17 05:02:42 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:42 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:42 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:42 --> Upload Class Initialized
INFO - 2025-01-17 05:02:42 --> Email Class Initialized
INFO - 2025-01-17 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:42 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:42 --> Controller Class Initialized
INFO - 2025-01-17 10:32:42 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:42 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:32:42 --> Final output sent to browser
DEBUG - 2025-01-17 10:32:42 --> Total execution time: 0.0189
INFO - 2025-01-17 05:02:47 --> Config Class Initialized
INFO - 2025-01-17 05:02:47 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:47 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:47 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:47 --> URI Class Initialized
INFO - 2025-01-17 05:02:47 --> Router Class Initialized
INFO - 2025-01-17 05:02:47 --> Output Class Initialized
INFO - 2025-01-17 05:02:47 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:47 --> Input Class Initialized
INFO - 2025-01-17 05:02:47 --> Language Class Initialized
INFO - 2025-01-17 05:02:47 --> Loader Class Initialized
INFO - 2025-01-17 05:02:47 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:47 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:47 --> Upload Class Initialized
INFO - 2025-01-17 05:02:47 --> Email Class Initialized
INFO - 2025-01-17 05:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:47 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:47 --> Controller Class Initialized
INFO - 2025-01-17 10:32:47 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:32:47 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:32:47 --> Pagination Class Initialized
INFO - 2025-01-17 05:02:47 --> Config Class Initialized
INFO - 2025-01-17 05:02:47 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:47 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:47 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:47 --> URI Class Initialized
DEBUG - 2025-01-17 05:02:47 --> No URI present. Default controller set.
INFO - 2025-01-17 05:02:47 --> Router Class Initialized
INFO - 2025-01-17 05:02:47 --> Output Class Initialized
INFO - 2025-01-17 05:02:47 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:47 --> Input Class Initialized
INFO - 2025-01-17 05:02:47 --> Language Class Initialized
INFO - 2025-01-17 05:02:47 --> Loader Class Initialized
INFO - 2025-01-17 05:02:47 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:47 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:47 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:47 --> Upload Class Initialized
INFO - 2025-01-17 05:02:47 --> Email Class Initialized
INFO - 2025-01-17 05:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:47 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:47 --> Controller Class Initialized
INFO - 2025-01-17 10:32:47 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:47 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:32:47 --> Final output sent to browser
DEBUG - 2025-01-17 10:32:47 --> Total execution time: 0.0411
INFO - 2025-01-17 05:02:52 --> Config Class Initialized
INFO - 2025-01-17 05:02:52 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:52 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:52 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:52 --> URI Class Initialized
INFO - 2025-01-17 05:02:52 --> Router Class Initialized
INFO - 2025-01-17 05:02:52 --> Output Class Initialized
INFO - 2025-01-17 05:02:52 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:52 --> Input Class Initialized
INFO - 2025-01-17 05:02:52 --> Language Class Initialized
INFO - 2025-01-17 05:02:52 --> Loader Class Initialized
INFO - 2025-01-17 05:02:52 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:52 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:52 --> Upload Class Initialized
INFO - 2025-01-17 05:02:52 --> Email Class Initialized
INFO - 2025-01-17 05:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:52 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:52 --> Controller Class Initialized
INFO - 2025-01-17 10:32:52 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:32:52 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:32:52 --> Pagination Class Initialized
INFO - 2025-01-17 05:02:52 --> Config Class Initialized
INFO - 2025-01-17 05:02:52 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:52 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:52 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:52 --> URI Class Initialized
DEBUG - 2025-01-17 05:02:52 --> No URI present. Default controller set.
INFO - 2025-01-17 05:02:52 --> Router Class Initialized
INFO - 2025-01-17 05:02:52 --> Output Class Initialized
INFO - 2025-01-17 05:02:52 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:52 --> Input Class Initialized
INFO - 2025-01-17 05:02:52 --> Language Class Initialized
INFO - 2025-01-17 05:02:52 --> Loader Class Initialized
INFO - 2025-01-17 05:02:52 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:52 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:52 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:52 --> Upload Class Initialized
INFO - 2025-01-17 05:02:52 --> Email Class Initialized
INFO - 2025-01-17 05:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:52 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:52 --> Controller Class Initialized
INFO - 2025-01-17 10:32:52 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:52 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:32:52 --> Final output sent to browser
DEBUG - 2025-01-17 10:32:52 --> Total execution time: 0.0485
INFO - 2025-01-17 05:02:57 --> Config Class Initialized
INFO - 2025-01-17 05:02:57 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:57 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:57 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:57 --> URI Class Initialized
INFO - 2025-01-17 05:02:57 --> Router Class Initialized
INFO - 2025-01-17 05:02:57 --> Output Class Initialized
INFO - 2025-01-17 05:02:57 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:57 --> Input Class Initialized
INFO - 2025-01-17 05:02:57 --> Language Class Initialized
INFO - 2025-01-17 05:02:57 --> Loader Class Initialized
INFO - 2025-01-17 05:02:57 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:57 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:57 --> Upload Class Initialized
INFO - 2025-01-17 05:02:57 --> Email Class Initialized
INFO - 2025-01-17 05:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:57 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:57 --> Controller Class Initialized
INFO - 2025-01-17 10:32:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:32:57 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:32:57 --> Pagination Class Initialized
INFO - 2025-01-17 05:02:57 --> Config Class Initialized
INFO - 2025-01-17 05:02:57 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:02:57 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:02:57 --> Utf8 Class Initialized
INFO - 2025-01-17 05:02:57 --> URI Class Initialized
DEBUG - 2025-01-17 05:02:57 --> No URI present. Default controller set.
INFO - 2025-01-17 05:02:57 --> Router Class Initialized
INFO - 2025-01-17 05:02:57 --> Output Class Initialized
INFO - 2025-01-17 05:02:57 --> Security Class Initialized
DEBUG - 2025-01-17 05:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:02:57 --> Input Class Initialized
INFO - 2025-01-17 05:02:57 --> Language Class Initialized
INFO - 2025-01-17 05:02:57 --> Loader Class Initialized
INFO - 2025-01-17 05:02:57 --> Helper loaded: url_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: html_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: file_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: string_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: form_helper
INFO - 2025-01-17 05:02:57 --> Helper loaded: my_helper
INFO - 2025-01-17 05:02:57 --> Database Driver Class Initialized
INFO - 2025-01-17 05:02:57 --> Upload Class Initialized
INFO - 2025-01-17 05:02:57 --> Email Class Initialized
INFO - 2025-01-17 05:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:02:57 --> Form Validation Class Initialized
INFO - 2025-01-17 05:02:57 --> Controller Class Initialized
INFO - 2025-01-17 10:32:57 --> Model "MainModel" initialized
INFO - 2025-01-17 10:32:57 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:32:57 --> Final output sent to browser
DEBUG - 2025-01-17 10:32:57 --> Total execution time: 0.0251
INFO - 2025-01-17 05:03:02 --> Config Class Initialized
INFO - 2025-01-17 05:03:02 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:02 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:02 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:02 --> URI Class Initialized
INFO - 2025-01-17 05:03:02 --> Router Class Initialized
INFO - 2025-01-17 05:03:02 --> Output Class Initialized
INFO - 2025-01-17 05:03:02 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:02 --> Input Class Initialized
INFO - 2025-01-17 05:03:02 --> Language Class Initialized
INFO - 2025-01-17 05:03:02 --> Loader Class Initialized
INFO - 2025-01-17 05:03:02 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:02 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:02 --> Upload Class Initialized
INFO - 2025-01-17 05:03:02 --> Email Class Initialized
INFO - 2025-01-17 05:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:02 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:02 --> Controller Class Initialized
INFO - 2025-01-17 10:33:02 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:33:02 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:33:02 --> Pagination Class Initialized
INFO - 2025-01-17 05:03:02 --> Config Class Initialized
INFO - 2025-01-17 05:03:02 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:02 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:02 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:02 --> URI Class Initialized
DEBUG - 2025-01-17 05:03:02 --> No URI present. Default controller set.
INFO - 2025-01-17 05:03:02 --> Router Class Initialized
INFO - 2025-01-17 05:03:02 --> Output Class Initialized
INFO - 2025-01-17 05:03:02 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:02 --> Input Class Initialized
INFO - 2025-01-17 05:03:02 --> Language Class Initialized
INFO - 2025-01-17 05:03:02 --> Loader Class Initialized
INFO - 2025-01-17 05:03:02 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:02 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:02 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:02 --> Upload Class Initialized
INFO - 2025-01-17 05:03:02 --> Email Class Initialized
INFO - 2025-01-17 05:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:02 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:02 --> Controller Class Initialized
INFO - 2025-01-17 10:33:02 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:02 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:33:02 --> Final output sent to browser
DEBUG - 2025-01-17 10:33:02 --> Total execution time: 0.0436
INFO - 2025-01-17 05:03:07 --> Config Class Initialized
INFO - 2025-01-17 05:03:07 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:07 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:07 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:07 --> URI Class Initialized
INFO - 2025-01-17 05:03:07 --> Router Class Initialized
INFO - 2025-01-17 05:03:07 --> Output Class Initialized
INFO - 2025-01-17 05:03:07 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:07 --> Input Class Initialized
INFO - 2025-01-17 05:03:07 --> Language Class Initialized
INFO - 2025-01-17 05:03:07 --> Loader Class Initialized
INFO - 2025-01-17 05:03:07 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:07 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:07 --> Upload Class Initialized
INFO - 2025-01-17 05:03:07 --> Email Class Initialized
INFO - 2025-01-17 05:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:07 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:07 --> Controller Class Initialized
INFO - 2025-01-17 10:33:07 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:33:07 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:33:07 --> Pagination Class Initialized
INFO - 2025-01-17 05:03:07 --> Config Class Initialized
INFO - 2025-01-17 05:03:07 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:07 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:07 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:07 --> URI Class Initialized
DEBUG - 2025-01-17 05:03:07 --> No URI present. Default controller set.
INFO - 2025-01-17 05:03:07 --> Router Class Initialized
INFO - 2025-01-17 05:03:07 --> Output Class Initialized
INFO - 2025-01-17 05:03:07 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:07 --> Input Class Initialized
INFO - 2025-01-17 05:03:07 --> Language Class Initialized
INFO - 2025-01-17 05:03:07 --> Loader Class Initialized
INFO - 2025-01-17 05:03:07 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:07 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:07 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:07 --> Upload Class Initialized
INFO - 2025-01-17 05:03:07 --> Email Class Initialized
INFO - 2025-01-17 05:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:07 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:07 --> Controller Class Initialized
INFO - 2025-01-17 10:33:07 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:07 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:33:07 --> Final output sent to browser
DEBUG - 2025-01-17 10:33:07 --> Total execution time: 0.0218
INFO - 2025-01-17 05:03:12 --> Config Class Initialized
INFO - 2025-01-17 05:03:12 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:12 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:12 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:12 --> URI Class Initialized
INFO - 2025-01-17 05:03:12 --> Router Class Initialized
INFO - 2025-01-17 05:03:12 --> Output Class Initialized
INFO - 2025-01-17 05:03:12 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:12 --> Input Class Initialized
INFO - 2025-01-17 05:03:12 --> Language Class Initialized
INFO - 2025-01-17 05:03:12 --> Loader Class Initialized
INFO - 2025-01-17 05:03:12 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:12 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:12 --> Upload Class Initialized
INFO - 2025-01-17 05:03:12 --> Email Class Initialized
INFO - 2025-01-17 05:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:12 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:12 --> Controller Class Initialized
INFO - 2025-01-17 10:33:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:33:12 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:33:12 --> Pagination Class Initialized
INFO - 2025-01-17 05:03:12 --> Config Class Initialized
INFO - 2025-01-17 05:03:12 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:12 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:12 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:12 --> URI Class Initialized
DEBUG - 2025-01-17 05:03:12 --> No URI present. Default controller set.
INFO - 2025-01-17 05:03:12 --> Router Class Initialized
INFO - 2025-01-17 05:03:12 --> Output Class Initialized
INFO - 2025-01-17 05:03:12 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:12 --> Input Class Initialized
INFO - 2025-01-17 05:03:12 --> Language Class Initialized
INFO - 2025-01-17 05:03:12 --> Loader Class Initialized
INFO - 2025-01-17 05:03:12 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:12 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:12 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:12 --> Upload Class Initialized
INFO - 2025-01-17 05:03:12 --> Email Class Initialized
INFO - 2025-01-17 05:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:12 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:12 --> Controller Class Initialized
INFO - 2025-01-17 10:33:12 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:12 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:33:12 --> Final output sent to browser
DEBUG - 2025-01-17 10:33:12 --> Total execution time: 0.0405
INFO - 2025-01-17 05:03:17 --> Config Class Initialized
INFO - 2025-01-17 05:03:17 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:17 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:17 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:17 --> URI Class Initialized
INFO - 2025-01-17 05:03:17 --> Router Class Initialized
INFO - 2025-01-17 05:03:17 --> Output Class Initialized
INFO - 2025-01-17 05:03:17 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:17 --> Input Class Initialized
INFO - 2025-01-17 05:03:17 --> Language Class Initialized
INFO - 2025-01-17 05:03:17 --> Loader Class Initialized
INFO - 2025-01-17 05:03:17 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:17 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:17 --> Upload Class Initialized
INFO - 2025-01-17 05:03:17 --> Email Class Initialized
INFO - 2025-01-17 05:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:17 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:17 --> Controller Class Initialized
INFO - 2025-01-17 10:33:17 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:33:17 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:33:17 --> Pagination Class Initialized
INFO - 2025-01-17 05:03:17 --> Config Class Initialized
INFO - 2025-01-17 05:03:17 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:17 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:17 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:17 --> URI Class Initialized
DEBUG - 2025-01-17 05:03:17 --> No URI present. Default controller set.
INFO - 2025-01-17 05:03:17 --> Router Class Initialized
INFO - 2025-01-17 05:03:17 --> Output Class Initialized
INFO - 2025-01-17 05:03:17 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:17 --> Input Class Initialized
INFO - 2025-01-17 05:03:17 --> Language Class Initialized
INFO - 2025-01-17 05:03:17 --> Loader Class Initialized
INFO - 2025-01-17 05:03:17 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:17 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:17 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:17 --> Upload Class Initialized
INFO - 2025-01-17 05:03:17 --> Email Class Initialized
INFO - 2025-01-17 05:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:17 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:17 --> Controller Class Initialized
INFO - 2025-01-17 10:33:17 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:17 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:33:17 --> Final output sent to browser
DEBUG - 2025-01-17 10:33:17 --> Total execution time: 0.0206
INFO - 2025-01-17 05:03:22 --> Config Class Initialized
INFO - 2025-01-17 05:03:22 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:22 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:22 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:22 --> URI Class Initialized
INFO - 2025-01-17 05:03:22 --> Router Class Initialized
INFO - 2025-01-17 05:03:22 --> Output Class Initialized
INFO - 2025-01-17 05:03:22 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:22 --> Input Class Initialized
INFO - 2025-01-17 05:03:22 --> Language Class Initialized
INFO - 2025-01-17 05:03:22 --> Loader Class Initialized
INFO - 2025-01-17 05:03:22 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:22 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:22 --> Upload Class Initialized
INFO - 2025-01-17 05:03:22 --> Email Class Initialized
INFO - 2025-01-17 05:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:22 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:22 --> Controller Class Initialized
INFO - 2025-01-17 10:33:22 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:33:22 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:33:22 --> Pagination Class Initialized
INFO - 2025-01-17 05:03:22 --> Config Class Initialized
INFO - 2025-01-17 05:03:22 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:22 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:22 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:22 --> URI Class Initialized
DEBUG - 2025-01-17 05:03:22 --> No URI present. Default controller set.
INFO - 2025-01-17 05:03:22 --> Router Class Initialized
INFO - 2025-01-17 05:03:22 --> Output Class Initialized
INFO - 2025-01-17 05:03:22 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:22 --> Input Class Initialized
INFO - 2025-01-17 05:03:22 --> Language Class Initialized
INFO - 2025-01-17 05:03:22 --> Loader Class Initialized
INFO - 2025-01-17 05:03:22 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:22 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:22 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:22 --> Upload Class Initialized
INFO - 2025-01-17 05:03:22 --> Email Class Initialized
INFO - 2025-01-17 05:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:22 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:22 --> Controller Class Initialized
INFO - 2025-01-17 10:33:22 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:22 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:33:22 --> Final output sent to browser
DEBUG - 2025-01-17 10:33:22 --> Total execution time: 0.0345
INFO - 2025-01-17 05:03:27 --> Config Class Initialized
INFO - 2025-01-17 05:03:27 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:27 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:27 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:27 --> URI Class Initialized
INFO - 2025-01-17 05:03:27 --> Router Class Initialized
INFO - 2025-01-17 05:03:27 --> Output Class Initialized
INFO - 2025-01-17 05:03:27 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:27 --> Input Class Initialized
INFO - 2025-01-17 05:03:27 --> Language Class Initialized
INFO - 2025-01-17 05:03:27 --> Loader Class Initialized
INFO - 2025-01-17 05:03:27 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:27 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:27 --> Upload Class Initialized
INFO - 2025-01-17 05:03:27 --> Email Class Initialized
INFO - 2025-01-17 05:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:27 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:27 --> Controller Class Initialized
INFO - 2025-01-17 10:33:27 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:33:27 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:33:27 --> Pagination Class Initialized
INFO - 2025-01-17 05:03:27 --> Config Class Initialized
INFO - 2025-01-17 05:03:27 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:27 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:27 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:27 --> URI Class Initialized
DEBUG - 2025-01-17 05:03:27 --> No URI present. Default controller set.
INFO - 2025-01-17 05:03:27 --> Router Class Initialized
INFO - 2025-01-17 05:03:27 --> Output Class Initialized
INFO - 2025-01-17 05:03:27 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:27 --> Input Class Initialized
INFO - 2025-01-17 05:03:27 --> Language Class Initialized
INFO - 2025-01-17 05:03:27 --> Loader Class Initialized
INFO - 2025-01-17 05:03:27 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:27 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:27 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:27 --> Upload Class Initialized
INFO - 2025-01-17 05:03:27 --> Email Class Initialized
INFO - 2025-01-17 05:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:27 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:27 --> Controller Class Initialized
INFO - 2025-01-17 10:33:27 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:27 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:33:27 --> Final output sent to browser
DEBUG - 2025-01-17 10:33:27 --> Total execution time: 0.0472
INFO - 2025-01-17 05:03:32 --> Config Class Initialized
INFO - 2025-01-17 05:03:32 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:32 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:32 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:32 --> URI Class Initialized
INFO - 2025-01-17 05:03:32 --> Router Class Initialized
INFO - 2025-01-17 05:03:32 --> Output Class Initialized
INFO - 2025-01-17 05:03:32 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:32 --> Input Class Initialized
INFO - 2025-01-17 05:03:32 --> Language Class Initialized
INFO - 2025-01-17 05:03:32 --> Loader Class Initialized
INFO - 2025-01-17 05:03:32 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:32 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:32 --> Upload Class Initialized
INFO - 2025-01-17 05:03:32 --> Email Class Initialized
INFO - 2025-01-17 05:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:32 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:32 --> Controller Class Initialized
INFO - 2025-01-17 10:33:32 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:33:32 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:33:32 --> Pagination Class Initialized
INFO - 2025-01-17 05:03:32 --> Config Class Initialized
INFO - 2025-01-17 05:03:32 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:03:32 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:03:32 --> Utf8 Class Initialized
INFO - 2025-01-17 05:03:32 --> URI Class Initialized
DEBUG - 2025-01-17 05:03:32 --> No URI present. Default controller set.
INFO - 2025-01-17 05:03:32 --> Router Class Initialized
INFO - 2025-01-17 05:03:32 --> Output Class Initialized
INFO - 2025-01-17 05:03:32 --> Security Class Initialized
DEBUG - 2025-01-17 05:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:03:32 --> Input Class Initialized
INFO - 2025-01-17 05:03:32 --> Language Class Initialized
INFO - 2025-01-17 05:03:32 --> Loader Class Initialized
INFO - 2025-01-17 05:03:32 --> Helper loaded: url_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: html_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: file_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: string_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: form_helper
INFO - 2025-01-17 05:03:32 --> Helper loaded: my_helper
INFO - 2025-01-17 05:03:32 --> Database Driver Class Initialized
INFO - 2025-01-17 05:03:32 --> Upload Class Initialized
INFO - 2025-01-17 05:03:32 --> Email Class Initialized
INFO - 2025-01-17 05:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:03:32 --> Form Validation Class Initialized
INFO - 2025-01-17 05:03:32 --> Controller Class Initialized
INFO - 2025-01-17 10:33:32 --> Model "MainModel" initialized
INFO - 2025-01-17 10:33:32 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:33:32 --> Final output sent to browser
DEBUG - 2025-01-17 10:33:32 --> Total execution time: 0.0346
INFO - 2025-01-17 05:04:33 --> Config Class Initialized
INFO - 2025-01-17 05:04:33 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:04:33 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:04:33 --> Utf8 Class Initialized
INFO - 2025-01-17 05:04:33 --> URI Class Initialized
INFO - 2025-01-17 05:04:33 --> Router Class Initialized
INFO - 2025-01-17 05:04:33 --> Output Class Initialized
INFO - 2025-01-17 05:04:33 --> Security Class Initialized
DEBUG - 2025-01-17 05:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:04:33 --> Input Class Initialized
INFO - 2025-01-17 05:04:33 --> Language Class Initialized
INFO - 2025-01-17 05:04:33 --> Loader Class Initialized
INFO - 2025-01-17 05:04:33 --> Helper loaded: url_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: html_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: file_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: string_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: form_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: my_helper
INFO - 2025-01-17 05:04:33 --> Database Driver Class Initialized
INFO - 2025-01-17 05:04:33 --> Upload Class Initialized
INFO - 2025-01-17 05:04:33 --> Email Class Initialized
INFO - 2025-01-17 05:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:04:33 --> Form Validation Class Initialized
INFO - 2025-01-17 05:04:33 --> Controller Class Initialized
INFO - 2025-01-17 10:34:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:34:33 --> Model "MainModel" initialized
INFO - 2025-01-17 10:34:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:34:33 --> Pagination Class Initialized
INFO - 2025-01-17 05:04:33 --> Config Class Initialized
INFO - 2025-01-17 05:04:33 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:04:33 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:04:33 --> Utf8 Class Initialized
INFO - 2025-01-17 05:04:33 --> URI Class Initialized
DEBUG - 2025-01-17 05:04:33 --> No URI present. Default controller set.
INFO - 2025-01-17 05:04:33 --> Router Class Initialized
INFO - 2025-01-17 05:04:33 --> Output Class Initialized
INFO - 2025-01-17 05:04:33 --> Security Class Initialized
DEBUG - 2025-01-17 05:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:04:33 --> Input Class Initialized
INFO - 2025-01-17 05:04:33 --> Language Class Initialized
INFO - 2025-01-17 05:04:33 --> Loader Class Initialized
INFO - 2025-01-17 05:04:33 --> Helper loaded: url_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: html_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: file_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: string_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: form_helper
INFO - 2025-01-17 05:04:33 --> Helper loaded: my_helper
INFO - 2025-01-17 05:04:33 --> Database Driver Class Initialized
INFO - 2025-01-17 05:04:33 --> Upload Class Initialized
INFO - 2025-01-17 05:04:33 --> Email Class Initialized
INFO - 2025-01-17 05:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:04:33 --> Form Validation Class Initialized
INFO - 2025-01-17 05:04:33 --> Controller Class Initialized
INFO - 2025-01-17 10:34:33 --> Model "MainModel" initialized
INFO - 2025-01-17 10:34:33 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:34:33 --> Final output sent to browser
DEBUG - 2025-01-17 10:34:33 --> Total execution time: 0.0409
INFO - 2025-01-17 05:05:34 --> Config Class Initialized
INFO - 2025-01-17 05:05:34 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:05:34 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:05:34 --> Utf8 Class Initialized
INFO - 2025-01-17 05:05:34 --> URI Class Initialized
INFO - 2025-01-17 05:05:34 --> Router Class Initialized
INFO - 2025-01-17 05:05:34 --> Output Class Initialized
INFO - 2025-01-17 05:05:34 --> Security Class Initialized
DEBUG - 2025-01-17 05:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:05:34 --> Input Class Initialized
INFO - 2025-01-17 05:05:34 --> Language Class Initialized
INFO - 2025-01-17 05:05:34 --> Loader Class Initialized
INFO - 2025-01-17 05:05:34 --> Helper loaded: url_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: html_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: file_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: string_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: form_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: my_helper
INFO - 2025-01-17 05:05:34 --> Database Driver Class Initialized
INFO - 2025-01-17 05:05:34 --> Upload Class Initialized
INFO - 2025-01-17 05:05:34 --> Email Class Initialized
INFO - 2025-01-17 05:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:05:34 --> Form Validation Class Initialized
INFO - 2025-01-17 05:05:34 --> Controller Class Initialized
INFO - 2025-01-17 10:35:34 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:35:34 --> Model "MainModel" initialized
INFO - 2025-01-17 10:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:35:34 --> Pagination Class Initialized
INFO - 2025-01-17 05:05:34 --> Config Class Initialized
INFO - 2025-01-17 05:05:34 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:05:34 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:05:34 --> Utf8 Class Initialized
INFO - 2025-01-17 05:05:34 --> URI Class Initialized
DEBUG - 2025-01-17 05:05:34 --> No URI present. Default controller set.
INFO - 2025-01-17 05:05:34 --> Router Class Initialized
INFO - 2025-01-17 05:05:34 --> Output Class Initialized
INFO - 2025-01-17 05:05:34 --> Security Class Initialized
DEBUG - 2025-01-17 05:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:05:34 --> Input Class Initialized
INFO - 2025-01-17 05:05:34 --> Language Class Initialized
INFO - 2025-01-17 05:05:34 --> Loader Class Initialized
INFO - 2025-01-17 05:05:34 --> Helper loaded: url_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: html_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: file_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: string_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: form_helper
INFO - 2025-01-17 05:05:34 --> Helper loaded: my_helper
INFO - 2025-01-17 05:05:34 --> Database Driver Class Initialized
INFO - 2025-01-17 05:05:34 --> Upload Class Initialized
INFO - 2025-01-17 05:05:34 --> Email Class Initialized
INFO - 2025-01-17 05:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:05:34 --> Form Validation Class Initialized
INFO - 2025-01-17 05:05:34 --> Controller Class Initialized
INFO - 2025-01-17 10:35:34 --> Model "MainModel" initialized
INFO - 2025-01-17 10:35:34 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:35:34 --> Final output sent to browser
DEBUG - 2025-01-17 10:35:34 --> Total execution time: 0.0253
INFO - 2025-01-17 05:06:35 --> Config Class Initialized
INFO - 2025-01-17 05:06:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:06:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:06:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:06:35 --> URI Class Initialized
INFO - 2025-01-17 05:06:35 --> Router Class Initialized
INFO - 2025-01-17 05:06:35 --> Output Class Initialized
INFO - 2025-01-17 05:06:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:06:35 --> Input Class Initialized
INFO - 2025-01-17 05:06:35 --> Language Class Initialized
INFO - 2025-01-17 05:06:35 --> Loader Class Initialized
INFO - 2025-01-17 05:06:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:06:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:06:35 --> Upload Class Initialized
INFO - 2025-01-17 05:06:35 --> Email Class Initialized
INFO - 2025-01-17 05:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:06:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:06:35 --> Controller Class Initialized
INFO - 2025-01-17 10:36:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:36:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:36:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:06:35 --> Config Class Initialized
INFO - 2025-01-17 05:06:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:06:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:06:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:06:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:06:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:06:35 --> Router Class Initialized
INFO - 2025-01-17 05:06:35 --> Output Class Initialized
INFO - 2025-01-17 05:06:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:06:35 --> Input Class Initialized
INFO - 2025-01-17 05:06:35 --> Language Class Initialized
INFO - 2025-01-17 05:06:35 --> Loader Class Initialized
INFO - 2025-01-17 05:06:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:06:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:06:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:06:35 --> Upload Class Initialized
INFO - 2025-01-17 05:06:35 --> Email Class Initialized
INFO - 2025-01-17 05:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:06:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:06:35 --> Controller Class Initialized
INFO - 2025-01-17 10:36:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:36:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:36:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:36:35 --> Total execution time: 0.0308
INFO - 2025-01-17 05:07:35 --> Config Class Initialized
INFO - 2025-01-17 05:07:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:07:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:07:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:07:35 --> URI Class Initialized
INFO - 2025-01-17 05:07:35 --> Router Class Initialized
INFO - 2025-01-17 05:07:35 --> Output Class Initialized
INFO - 2025-01-17 05:07:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:07:35 --> Input Class Initialized
INFO - 2025-01-17 05:07:35 --> Language Class Initialized
INFO - 2025-01-17 05:07:35 --> Loader Class Initialized
INFO - 2025-01-17 05:07:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:07:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:07:35 --> Upload Class Initialized
INFO - 2025-01-17 05:07:35 --> Email Class Initialized
INFO - 2025-01-17 05:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:07:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:07:35 --> Controller Class Initialized
INFO - 2025-01-17 10:37:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:37:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:37:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:07:35 --> Config Class Initialized
INFO - 2025-01-17 05:07:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:07:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:07:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:07:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:07:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:07:35 --> Router Class Initialized
INFO - 2025-01-17 05:07:35 --> Output Class Initialized
INFO - 2025-01-17 05:07:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:07:35 --> Input Class Initialized
INFO - 2025-01-17 05:07:35 --> Language Class Initialized
INFO - 2025-01-17 05:07:35 --> Loader Class Initialized
INFO - 2025-01-17 05:07:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:07:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:07:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:07:35 --> Upload Class Initialized
INFO - 2025-01-17 05:07:35 --> Email Class Initialized
INFO - 2025-01-17 05:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:07:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:07:35 --> Controller Class Initialized
INFO - 2025-01-17 10:37:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:37:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:37:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:37:35 --> Total execution time: 0.0230
INFO - 2025-01-17 05:08:35 --> Config Class Initialized
INFO - 2025-01-17 05:08:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:08:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:08:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:08:35 --> URI Class Initialized
INFO - 2025-01-17 05:08:35 --> Router Class Initialized
INFO - 2025-01-17 05:08:35 --> Output Class Initialized
INFO - 2025-01-17 05:08:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:08:35 --> Input Class Initialized
INFO - 2025-01-17 05:08:35 --> Language Class Initialized
INFO - 2025-01-17 05:08:35 --> Loader Class Initialized
INFO - 2025-01-17 05:08:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:08:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:08:35 --> Upload Class Initialized
INFO - 2025-01-17 05:08:35 --> Email Class Initialized
INFO - 2025-01-17 05:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:08:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:08:35 --> Controller Class Initialized
INFO - 2025-01-17 10:38:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:38:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:38:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:08:35 --> Config Class Initialized
INFO - 2025-01-17 05:08:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:08:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:08:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:08:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:08:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:08:35 --> Router Class Initialized
INFO - 2025-01-17 05:08:35 --> Output Class Initialized
INFO - 2025-01-17 05:08:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:08:35 --> Input Class Initialized
INFO - 2025-01-17 05:08:35 --> Language Class Initialized
INFO - 2025-01-17 05:08:35 --> Loader Class Initialized
INFO - 2025-01-17 05:08:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:08:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:08:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:08:35 --> Upload Class Initialized
INFO - 2025-01-17 05:08:35 --> Email Class Initialized
INFO - 2025-01-17 05:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:08:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:08:35 --> Controller Class Initialized
INFO - 2025-01-17 10:38:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:38:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:38:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:38:35 --> Total execution time: 0.0288
INFO - 2025-01-17 05:09:35 --> Config Class Initialized
INFO - 2025-01-17 05:09:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:09:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:09:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:09:35 --> URI Class Initialized
INFO - 2025-01-17 05:09:35 --> Router Class Initialized
INFO - 2025-01-17 05:09:35 --> Output Class Initialized
INFO - 2025-01-17 05:09:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:09:35 --> Input Class Initialized
INFO - 2025-01-17 05:09:35 --> Language Class Initialized
INFO - 2025-01-17 05:09:35 --> Loader Class Initialized
INFO - 2025-01-17 05:09:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:09:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:09:35 --> Upload Class Initialized
INFO - 2025-01-17 05:09:35 --> Email Class Initialized
INFO - 2025-01-17 05:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:09:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:09:35 --> Controller Class Initialized
INFO - 2025-01-17 10:39:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:39:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:39:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:09:35 --> Config Class Initialized
INFO - 2025-01-17 05:09:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:09:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:09:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:09:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:09:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:09:35 --> Router Class Initialized
INFO - 2025-01-17 05:09:35 --> Output Class Initialized
INFO - 2025-01-17 05:09:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:09:35 --> Input Class Initialized
INFO - 2025-01-17 05:09:35 --> Language Class Initialized
INFO - 2025-01-17 05:09:35 --> Loader Class Initialized
INFO - 2025-01-17 05:09:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:09:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:09:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:09:35 --> Upload Class Initialized
INFO - 2025-01-17 05:09:35 --> Email Class Initialized
INFO - 2025-01-17 05:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:09:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:09:35 --> Controller Class Initialized
INFO - 2025-01-17 10:39:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:39:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:39:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:39:35 --> Total execution time: 0.0411
INFO - 2025-01-17 05:10:35 --> Config Class Initialized
INFO - 2025-01-17 05:10:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:10:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:10:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:10:35 --> URI Class Initialized
INFO - 2025-01-17 05:10:35 --> Router Class Initialized
INFO - 2025-01-17 05:10:35 --> Output Class Initialized
INFO - 2025-01-17 05:10:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:10:35 --> Input Class Initialized
INFO - 2025-01-17 05:10:35 --> Language Class Initialized
INFO - 2025-01-17 05:10:35 --> Loader Class Initialized
INFO - 2025-01-17 05:10:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:10:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:10:35 --> Upload Class Initialized
INFO - 2025-01-17 05:10:35 --> Email Class Initialized
INFO - 2025-01-17 05:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:10:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:10:35 --> Controller Class Initialized
INFO - 2025-01-17 10:40:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:40:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:40:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:10:35 --> Config Class Initialized
INFO - 2025-01-17 05:10:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:10:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:10:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:10:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:10:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:10:35 --> Router Class Initialized
INFO - 2025-01-17 05:10:35 --> Output Class Initialized
INFO - 2025-01-17 05:10:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:10:35 --> Input Class Initialized
INFO - 2025-01-17 05:10:35 --> Language Class Initialized
INFO - 2025-01-17 05:10:35 --> Loader Class Initialized
INFO - 2025-01-17 05:10:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:10:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:10:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:10:35 --> Upload Class Initialized
INFO - 2025-01-17 05:10:35 --> Email Class Initialized
INFO - 2025-01-17 05:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:10:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:10:35 --> Controller Class Initialized
INFO - 2025-01-17 10:40:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:40:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:40:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:40:35 --> Total execution time: 0.0245
INFO - 2025-01-17 05:11:35 --> Config Class Initialized
INFO - 2025-01-17 05:11:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:11:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:11:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:11:35 --> URI Class Initialized
INFO - 2025-01-17 05:11:35 --> Router Class Initialized
INFO - 2025-01-17 05:11:35 --> Output Class Initialized
INFO - 2025-01-17 05:11:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:11:35 --> Input Class Initialized
INFO - 2025-01-17 05:11:35 --> Language Class Initialized
INFO - 2025-01-17 05:11:35 --> Loader Class Initialized
INFO - 2025-01-17 05:11:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:11:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:11:35 --> Upload Class Initialized
INFO - 2025-01-17 05:11:35 --> Email Class Initialized
INFO - 2025-01-17 05:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:11:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:11:35 --> Controller Class Initialized
INFO - 2025-01-17 10:41:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:41:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:41:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:11:35 --> Config Class Initialized
INFO - 2025-01-17 05:11:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:11:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:11:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:11:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:11:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:11:35 --> Router Class Initialized
INFO - 2025-01-17 05:11:35 --> Output Class Initialized
INFO - 2025-01-17 05:11:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:11:35 --> Input Class Initialized
INFO - 2025-01-17 05:11:35 --> Language Class Initialized
INFO - 2025-01-17 05:11:35 --> Loader Class Initialized
INFO - 2025-01-17 05:11:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:11:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:11:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:11:35 --> Upload Class Initialized
INFO - 2025-01-17 05:11:35 --> Email Class Initialized
INFO - 2025-01-17 05:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:11:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:11:35 --> Controller Class Initialized
INFO - 2025-01-17 10:41:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:41:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:41:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:41:35 --> Total execution time: 0.0239
INFO - 2025-01-17 05:12:35 --> Config Class Initialized
INFO - 2025-01-17 05:12:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:12:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:12:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:12:35 --> URI Class Initialized
INFO - 2025-01-17 05:12:35 --> Router Class Initialized
INFO - 2025-01-17 05:12:35 --> Output Class Initialized
INFO - 2025-01-17 05:12:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:12:35 --> Input Class Initialized
INFO - 2025-01-17 05:12:35 --> Language Class Initialized
INFO - 2025-01-17 05:12:35 --> Loader Class Initialized
INFO - 2025-01-17 05:12:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:12:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:12:35 --> Upload Class Initialized
INFO - 2025-01-17 05:12:35 --> Email Class Initialized
INFO - 2025-01-17 05:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:12:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:12:35 --> Controller Class Initialized
INFO - 2025-01-17 10:42:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:42:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:42:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:12:35 --> Config Class Initialized
INFO - 2025-01-17 05:12:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:12:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:12:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:12:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:12:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:12:35 --> Router Class Initialized
INFO - 2025-01-17 05:12:35 --> Output Class Initialized
INFO - 2025-01-17 05:12:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:12:35 --> Input Class Initialized
INFO - 2025-01-17 05:12:35 --> Language Class Initialized
INFO - 2025-01-17 05:12:35 --> Loader Class Initialized
INFO - 2025-01-17 05:12:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:12:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:12:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:12:35 --> Upload Class Initialized
INFO - 2025-01-17 05:12:35 --> Email Class Initialized
INFO - 2025-01-17 05:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:12:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:12:35 --> Controller Class Initialized
INFO - 2025-01-17 10:42:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:42:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:42:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:42:35 --> Total execution time: 0.0228
INFO - 2025-01-17 05:13:35 --> Config Class Initialized
INFO - 2025-01-17 05:13:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:13:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:13:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:13:35 --> URI Class Initialized
INFO - 2025-01-17 05:13:35 --> Router Class Initialized
INFO - 2025-01-17 05:13:35 --> Output Class Initialized
INFO - 2025-01-17 05:13:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:13:35 --> Input Class Initialized
INFO - 2025-01-17 05:13:35 --> Language Class Initialized
INFO - 2025-01-17 05:13:35 --> Loader Class Initialized
INFO - 2025-01-17 05:13:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:13:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:13:35 --> Upload Class Initialized
INFO - 2025-01-17 05:13:35 --> Email Class Initialized
INFO - 2025-01-17 05:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:13:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:13:35 --> Controller Class Initialized
INFO - 2025-01-17 10:43:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:43:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:43:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:13:35 --> Config Class Initialized
INFO - 2025-01-17 05:13:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:13:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:13:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:13:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:13:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:13:35 --> Router Class Initialized
INFO - 2025-01-17 05:13:35 --> Output Class Initialized
INFO - 2025-01-17 05:13:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:13:35 --> Input Class Initialized
INFO - 2025-01-17 05:13:35 --> Language Class Initialized
INFO - 2025-01-17 05:13:35 --> Loader Class Initialized
INFO - 2025-01-17 05:13:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:13:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:13:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:13:35 --> Upload Class Initialized
INFO - 2025-01-17 05:13:35 --> Email Class Initialized
INFO - 2025-01-17 05:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:13:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:13:35 --> Controller Class Initialized
INFO - 2025-01-17 10:43:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:43:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:43:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:43:35 --> Total execution time: 0.0238
INFO - 2025-01-17 05:14:35 --> Config Class Initialized
INFO - 2025-01-17 05:14:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:14:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:14:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:14:35 --> URI Class Initialized
INFO - 2025-01-17 05:14:35 --> Router Class Initialized
INFO - 2025-01-17 05:14:35 --> Output Class Initialized
INFO - 2025-01-17 05:14:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:14:35 --> Input Class Initialized
INFO - 2025-01-17 05:14:35 --> Language Class Initialized
INFO - 2025-01-17 05:14:35 --> Loader Class Initialized
INFO - 2025-01-17 05:14:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:14:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:14:35 --> Upload Class Initialized
INFO - 2025-01-17 05:14:35 --> Email Class Initialized
INFO - 2025-01-17 05:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:14:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:14:35 --> Controller Class Initialized
INFO - 2025-01-17 10:44:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:44:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:44:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:14:35 --> Config Class Initialized
INFO - 2025-01-17 05:14:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:14:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:14:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:14:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:14:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:14:35 --> Router Class Initialized
INFO - 2025-01-17 05:14:35 --> Output Class Initialized
INFO - 2025-01-17 05:14:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:14:35 --> Input Class Initialized
INFO - 2025-01-17 05:14:35 --> Language Class Initialized
INFO - 2025-01-17 05:14:35 --> Loader Class Initialized
INFO - 2025-01-17 05:14:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:14:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:14:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:14:35 --> Upload Class Initialized
INFO - 2025-01-17 05:14:35 --> Email Class Initialized
INFO - 2025-01-17 05:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:14:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:14:35 --> Controller Class Initialized
INFO - 2025-01-17 10:44:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:44:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:44:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:44:35 --> Total execution time: 0.0297
INFO - 2025-01-17 05:15:35 --> Config Class Initialized
INFO - 2025-01-17 05:15:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:15:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:15:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:15:35 --> URI Class Initialized
INFO - 2025-01-17 05:15:35 --> Router Class Initialized
INFO - 2025-01-17 05:15:35 --> Output Class Initialized
INFO - 2025-01-17 05:15:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:15:35 --> Input Class Initialized
INFO - 2025-01-17 05:15:35 --> Language Class Initialized
INFO - 2025-01-17 05:15:35 --> Loader Class Initialized
INFO - 2025-01-17 05:15:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:15:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:15:35 --> Upload Class Initialized
INFO - 2025-01-17 05:15:35 --> Email Class Initialized
INFO - 2025-01-17 05:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:15:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:15:35 --> Controller Class Initialized
INFO - 2025-01-17 10:45:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:45:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:45:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:15:35 --> Config Class Initialized
INFO - 2025-01-17 05:15:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:15:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:15:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:15:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:15:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:15:35 --> Router Class Initialized
INFO - 2025-01-17 05:15:35 --> Output Class Initialized
INFO - 2025-01-17 05:15:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:15:35 --> Input Class Initialized
INFO - 2025-01-17 05:15:35 --> Language Class Initialized
INFO - 2025-01-17 05:15:35 --> Loader Class Initialized
INFO - 2025-01-17 05:15:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:15:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:15:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:15:35 --> Upload Class Initialized
INFO - 2025-01-17 05:15:35 --> Email Class Initialized
INFO - 2025-01-17 05:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:15:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:15:35 --> Controller Class Initialized
INFO - 2025-01-17 10:45:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:45:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:45:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:45:35 --> Total execution time: 0.0230
INFO - 2025-01-17 05:16:35 --> Config Class Initialized
INFO - 2025-01-17 05:16:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:16:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:16:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:16:35 --> URI Class Initialized
INFO - 2025-01-17 05:16:35 --> Router Class Initialized
INFO - 2025-01-17 05:16:35 --> Output Class Initialized
INFO - 2025-01-17 05:16:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:16:35 --> Input Class Initialized
INFO - 2025-01-17 05:16:35 --> Language Class Initialized
INFO - 2025-01-17 05:16:35 --> Loader Class Initialized
INFO - 2025-01-17 05:16:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:16:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:16:35 --> Upload Class Initialized
INFO - 2025-01-17 05:16:35 --> Email Class Initialized
INFO - 2025-01-17 05:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:16:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:16:35 --> Controller Class Initialized
INFO - 2025-01-17 10:46:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:46:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:46:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:46:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:16:35 --> Config Class Initialized
INFO - 2025-01-17 05:16:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:16:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:16:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:16:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:16:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:16:35 --> Router Class Initialized
INFO - 2025-01-17 05:16:35 --> Output Class Initialized
INFO - 2025-01-17 05:16:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:16:35 --> Input Class Initialized
INFO - 2025-01-17 05:16:35 --> Language Class Initialized
INFO - 2025-01-17 05:16:35 --> Loader Class Initialized
INFO - 2025-01-17 05:16:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:16:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:16:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:16:35 --> Upload Class Initialized
INFO - 2025-01-17 05:16:35 --> Email Class Initialized
INFO - 2025-01-17 05:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:16:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:16:35 --> Controller Class Initialized
INFO - 2025-01-17 10:46:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:46:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:46:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:46:35 --> Total execution time: 0.0256
INFO - 2025-01-17 05:17:35 --> Config Class Initialized
INFO - 2025-01-17 05:17:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:17:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:17:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:17:35 --> URI Class Initialized
INFO - 2025-01-17 05:17:35 --> Router Class Initialized
INFO - 2025-01-17 05:17:35 --> Output Class Initialized
INFO - 2025-01-17 05:17:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:17:35 --> Input Class Initialized
INFO - 2025-01-17 05:17:35 --> Language Class Initialized
INFO - 2025-01-17 05:17:35 --> Loader Class Initialized
INFO - 2025-01-17 05:17:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:17:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:17:35 --> Upload Class Initialized
INFO - 2025-01-17 05:17:35 --> Email Class Initialized
INFO - 2025-01-17 05:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:17:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:17:35 --> Controller Class Initialized
INFO - 2025-01-17 10:47:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:47:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:47:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:47:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:17:35 --> Config Class Initialized
INFO - 2025-01-17 05:17:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:17:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:17:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:17:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:17:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:17:35 --> Router Class Initialized
INFO - 2025-01-17 05:17:35 --> Output Class Initialized
INFO - 2025-01-17 05:17:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:17:35 --> Input Class Initialized
INFO - 2025-01-17 05:17:35 --> Language Class Initialized
INFO - 2025-01-17 05:17:35 --> Loader Class Initialized
INFO - 2025-01-17 05:17:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:17:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:17:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:17:35 --> Upload Class Initialized
INFO - 2025-01-17 05:17:35 --> Email Class Initialized
INFO - 2025-01-17 05:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:17:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:17:35 --> Controller Class Initialized
INFO - 2025-01-17 10:47:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:47:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:47:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:47:35 --> Total execution time: 0.0228
INFO - 2025-01-17 05:18:35 --> Config Class Initialized
INFO - 2025-01-17 05:18:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:18:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:18:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:18:35 --> URI Class Initialized
INFO - 2025-01-17 05:18:35 --> Router Class Initialized
INFO - 2025-01-17 05:18:35 --> Output Class Initialized
INFO - 2025-01-17 05:18:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:18:35 --> Input Class Initialized
INFO - 2025-01-17 05:18:35 --> Language Class Initialized
INFO - 2025-01-17 05:18:35 --> Loader Class Initialized
INFO - 2025-01-17 05:18:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:18:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:18:35 --> Upload Class Initialized
INFO - 2025-01-17 05:18:35 --> Email Class Initialized
INFO - 2025-01-17 05:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:18:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:18:35 --> Controller Class Initialized
INFO - 2025-01-17 10:48:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:48:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:48:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:18:35 --> Config Class Initialized
INFO - 2025-01-17 05:18:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:18:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:18:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:18:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:18:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:18:35 --> Router Class Initialized
INFO - 2025-01-17 05:18:35 --> Output Class Initialized
INFO - 2025-01-17 05:18:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:18:35 --> Input Class Initialized
INFO - 2025-01-17 05:18:35 --> Language Class Initialized
INFO - 2025-01-17 05:18:35 --> Loader Class Initialized
INFO - 2025-01-17 05:18:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:18:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:18:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:18:35 --> Upload Class Initialized
INFO - 2025-01-17 05:18:35 --> Email Class Initialized
INFO - 2025-01-17 05:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:18:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:18:35 --> Controller Class Initialized
INFO - 2025-01-17 10:48:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:48:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:48:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:48:35 --> Total execution time: 0.0246
INFO - 2025-01-17 05:19:35 --> Config Class Initialized
INFO - 2025-01-17 05:19:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:19:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:19:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:19:35 --> URI Class Initialized
INFO - 2025-01-17 05:19:35 --> Router Class Initialized
INFO - 2025-01-17 05:19:35 --> Output Class Initialized
INFO - 2025-01-17 05:19:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:19:35 --> Input Class Initialized
INFO - 2025-01-17 05:19:35 --> Language Class Initialized
INFO - 2025-01-17 05:19:35 --> Loader Class Initialized
INFO - 2025-01-17 05:19:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:19:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:19:35 --> Upload Class Initialized
INFO - 2025-01-17 05:19:35 --> Email Class Initialized
INFO - 2025-01-17 05:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:19:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:19:35 --> Controller Class Initialized
INFO - 2025-01-17 10:49:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:49:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:49:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:49:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:19:35 --> Config Class Initialized
INFO - 2025-01-17 05:19:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:19:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:19:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:19:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:19:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:19:35 --> Router Class Initialized
INFO - 2025-01-17 05:19:35 --> Output Class Initialized
INFO - 2025-01-17 05:19:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:19:35 --> Input Class Initialized
INFO - 2025-01-17 05:19:35 --> Language Class Initialized
INFO - 2025-01-17 05:19:35 --> Loader Class Initialized
INFO - 2025-01-17 05:19:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:19:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:19:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:19:35 --> Upload Class Initialized
INFO - 2025-01-17 05:19:35 --> Email Class Initialized
INFO - 2025-01-17 05:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:19:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:19:35 --> Controller Class Initialized
INFO - 2025-01-17 10:49:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:49:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:49:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:49:35 --> Total execution time: 0.0266
INFO - 2025-01-17 05:20:35 --> Config Class Initialized
INFO - 2025-01-17 05:20:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:20:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:20:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:20:35 --> URI Class Initialized
INFO - 2025-01-17 05:20:35 --> Router Class Initialized
INFO - 2025-01-17 05:20:35 --> Output Class Initialized
INFO - 2025-01-17 05:20:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:20:35 --> Input Class Initialized
INFO - 2025-01-17 05:20:35 --> Language Class Initialized
INFO - 2025-01-17 05:20:35 --> Loader Class Initialized
INFO - 2025-01-17 05:20:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:20:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:20:35 --> Upload Class Initialized
INFO - 2025-01-17 05:20:35 --> Email Class Initialized
INFO - 2025-01-17 05:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:20:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:20:35 --> Controller Class Initialized
INFO - 2025-01-17 10:50:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:50:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:50:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:20:35 --> Config Class Initialized
INFO - 2025-01-17 05:20:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:20:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:20:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:20:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:20:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:20:35 --> Router Class Initialized
INFO - 2025-01-17 05:20:35 --> Output Class Initialized
INFO - 2025-01-17 05:20:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:20:35 --> Input Class Initialized
INFO - 2025-01-17 05:20:35 --> Language Class Initialized
INFO - 2025-01-17 05:20:35 --> Loader Class Initialized
INFO - 2025-01-17 05:20:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:20:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:20:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:20:35 --> Upload Class Initialized
INFO - 2025-01-17 05:20:35 --> Email Class Initialized
INFO - 2025-01-17 05:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:20:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:20:35 --> Controller Class Initialized
INFO - 2025-01-17 10:50:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:50:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:50:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:50:35 --> Total execution time: 0.0210
INFO - 2025-01-17 05:21:35 --> Config Class Initialized
INFO - 2025-01-17 05:21:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:21:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:21:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:21:35 --> URI Class Initialized
INFO - 2025-01-17 05:21:35 --> Router Class Initialized
INFO - 2025-01-17 05:21:35 --> Output Class Initialized
INFO - 2025-01-17 05:21:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:21:35 --> Input Class Initialized
INFO - 2025-01-17 05:21:35 --> Language Class Initialized
INFO - 2025-01-17 05:21:35 --> Loader Class Initialized
INFO - 2025-01-17 05:21:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:21:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:21:35 --> Upload Class Initialized
INFO - 2025-01-17 05:21:35 --> Email Class Initialized
INFO - 2025-01-17 05:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:21:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:21:35 --> Controller Class Initialized
INFO - 2025-01-17 10:51:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:51:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:51:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:21:35 --> Config Class Initialized
INFO - 2025-01-17 05:21:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:21:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:21:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:21:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:21:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:21:35 --> Router Class Initialized
INFO - 2025-01-17 05:21:35 --> Output Class Initialized
INFO - 2025-01-17 05:21:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:21:35 --> Input Class Initialized
INFO - 2025-01-17 05:21:35 --> Language Class Initialized
INFO - 2025-01-17 05:21:35 --> Loader Class Initialized
INFO - 2025-01-17 05:21:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:21:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:21:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:21:35 --> Upload Class Initialized
INFO - 2025-01-17 05:21:35 --> Email Class Initialized
INFO - 2025-01-17 05:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:21:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:21:35 --> Controller Class Initialized
INFO - 2025-01-17 10:51:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:51:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:51:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:51:35 --> Total execution time: 0.0303
INFO - 2025-01-17 05:22:35 --> Config Class Initialized
INFO - 2025-01-17 05:22:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:22:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:22:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:22:35 --> URI Class Initialized
INFO - 2025-01-17 05:22:35 --> Router Class Initialized
INFO - 2025-01-17 05:22:35 --> Output Class Initialized
INFO - 2025-01-17 05:22:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:22:35 --> Input Class Initialized
INFO - 2025-01-17 05:22:35 --> Language Class Initialized
INFO - 2025-01-17 05:22:35 --> Loader Class Initialized
INFO - 2025-01-17 05:22:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:22:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:22:35 --> Upload Class Initialized
INFO - 2025-01-17 05:22:35 --> Email Class Initialized
INFO - 2025-01-17 05:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:22:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:22:35 --> Controller Class Initialized
INFO - 2025-01-17 10:52:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:52:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:52:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:22:35 --> Config Class Initialized
INFO - 2025-01-17 05:22:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:22:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:22:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:22:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:22:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:22:35 --> Router Class Initialized
INFO - 2025-01-17 05:22:35 --> Output Class Initialized
INFO - 2025-01-17 05:22:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:22:35 --> Input Class Initialized
INFO - 2025-01-17 05:22:35 --> Language Class Initialized
INFO - 2025-01-17 05:22:35 --> Loader Class Initialized
INFO - 2025-01-17 05:22:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:22:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:22:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:22:35 --> Upload Class Initialized
INFO - 2025-01-17 05:22:35 --> Email Class Initialized
INFO - 2025-01-17 05:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:22:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:22:35 --> Controller Class Initialized
INFO - 2025-01-17 10:52:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:52:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:52:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:52:35 --> Total execution time: 0.0366
INFO - 2025-01-17 05:23:35 --> Config Class Initialized
INFO - 2025-01-17 05:23:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:23:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:23:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:23:35 --> URI Class Initialized
INFO - 2025-01-17 05:23:35 --> Router Class Initialized
INFO - 2025-01-17 05:23:35 --> Output Class Initialized
INFO - 2025-01-17 05:23:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:23:35 --> Input Class Initialized
INFO - 2025-01-17 05:23:35 --> Language Class Initialized
INFO - 2025-01-17 05:23:35 --> Loader Class Initialized
INFO - 2025-01-17 05:23:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:23:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:23:35 --> Upload Class Initialized
INFO - 2025-01-17 05:23:35 --> Email Class Initialized
INFO - 2025-01-17 05:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:23:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:23:35 --> Controller Class Initialized
INFO - 2025-01-17 10:53:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:53:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:53:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:23:35 --> Config Class Initialized
INFO - 2025-01-17 05:23:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:23:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:23:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:23:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:23:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:23:35 --> Router Class Initialized
INFO - 2025-01-17 05:23:35 --> Output Class Initialized
INFO - 2025-01-17 05:23:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:23:35 --> Input Class Initialized
INFO - 2025-01-17 05:23:35 --> Language Class Initialized
INFO - 2025-01-17 05:23:35 --> Loader Class Initialized
INFO - 2025-01-17 05:23:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:23:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:23:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:23:35 --> Upload Class Initialized
INFO - 2025-01-17 05:23:35 --> Email Class Initialized
INFO - 2025-01-17 05:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:23:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:23:35 --> Controller Class Initialized
INFO - 2025-01-17 10:53:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:53:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:53:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:53:35 --> Total execution time: 0.0343
INFO - 2025-01-17 05:24:35 --> Config Class Initialized
INFO - 2025-01-17 05:24:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:24:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:24:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:24:35 --> URI Class Initialized
INFO - 2025-01-17 05:24:35 --> Router Class Initialized
INFO - 2025-01-17 05:24:35 --> Output Class Initialized
INFO - 2025-01-17 05:24:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:24:35 --> Input Class Initialized
INFO - 2025-01-17 05:24:35 --> Language Class Initialized
INFO - 2025-01-17 05:24:35 --> Loader Class Initialized
INFO - 2025-01-17 05:24:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:24:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:24:35 --> Upload Class Initialized
INFO - 2025-01-17 05:24:35 --> Email Class Initialized
INFO - 2025-01-17 05:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:24:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:24:35 --> Controller Class Initialized
INFO - 2025-01-17 10:54:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:54:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:54:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:24:35 --> Config Class Initialized
INFO - 2025-01-17 05:24:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:24:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:24:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:24:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:24:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:24:35 --> Router Class Initialized
INFO - 2025-01-17 05:24:35 --> Output Class Initialized
INFO - 2025-01-17 05:24:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:24:35 --> Input Class Initialized
INFO - 2025-01-17 05:24:35 --> Language Class Initialized
INFO - 2025-01-17 05:24:35 --> Loader Class Initialized
INFO - 2025-01-17 05:24:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:24:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:24:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:24:35 --> Upload Class Initialized
INFO - 2025-01-17 05:24:35 --> Email Class Initialized
INFO - 2025-01-17 05:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:24:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:24:35 --> Controller Class Initialized
INFO - 2025-01-17 10:54:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:54:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:54:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:54:35 --> Total execution time: 0.0253
INFO - 2025-01-17 05:25:35 --> Config Class Initialized
INFO - 2025-01-17 05:25:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:25:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:25:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:25:35 --> URI Class Initialized
INFO - 2025-01-17 05:25:35 --> Router Class Initialized
INFO - 2025-01-17 05:25:35 --> Output Class Initialized
INFO - 2025-01-17 05:25:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:25:35 --> Input Class Initialized
INFO - 2025-01-17 05:25:35 --> Language Class Initialized
INFO - 2025-01-17 05:25:35 --> Loader Class Initialized
INFO - 2025-01-17 05:25:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:25:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:25:35 --> Upload Class Initialized
INFO - 2025-01-17 05:25:35 --> Email Class Initialized
INFO - 2025-01-17 05:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:25:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:25:35 --> Controller Class Initialized
INFO - 2025-01-17 10:55:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:55:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:55:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:25:35 --> Config Class Initialized
INFO - 2025-01-17 05:25:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:25:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:25:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:25:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:25:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:25:35 --> Router Class Initialized
INFO - 2025-01-17 05:25:35 --> Output Class Initialized
INFO - 2025-01-17 05:25:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:25:35 --> Input Class Initialized
INFO - 2025-01-17 05:25:35 --> Language Class Initialized
INFO - 2025-01-17 05:25:35 --> Loader Class Initialized
INFO - 2025-01-17 05:25:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:25:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:25:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:25:35 --> Upload Class Initialized
INFO - 2025-01-17 05:25:35 --> Email Class Initialized
INFO - 2025-01-17 05:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:25:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:25:35 --> Controller Class Initialized
INFO - 2025-01-17 10:55:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:55:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:55:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:55:35 --> Total execution time: 0.0440
INFO - 2025-01-17 05:26:35 --> Config Class Initialized
INFO - 2025-01-17 05:26:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:26:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:26:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:26:35 --> URI Class Initialized
INFO - 2025-01-17 05:26:35 --> Router Class Initialized
INFO - 2025-01-17 05:26:35 --> Output Class Initialized
INFO - 2025-01-17 05:26:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:26:35 --> Input Class Initialized
INFO - 2025-01-17 05:26:35 --> Language Class Initialized
INFO - 2025-01-17 05:26:35 --> Loader Class Initialized
INFO - 2025-01-17 05:26:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:26:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:26:35 --> Upload Class Initialized
INFO - 2025-01-17 05:26:35 --> Email Class Initialized
INFO - 2025-01-17 05:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:26:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:26:35 --> Controller Class Initialized
INFO - 2025-01-17 10:56:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:56:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:56:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:26:35 --> Config Class Initialized
INFO - 2025-01-17 05:26:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:26:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:26:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:26:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:26:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:26:35 --> Router Class Initialized
INFO - 2025-01-17 05:26:35 --> Output Class Initialized
INFO - 2025-01-17 05:26:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:26:35 --> Input Class Initialized
INFO - 2025-01-17 05:26:35 --> Language Class Initialized
INFO - 2025-01-17 05:26:35 --> Loader Class Initialized
INFO - 2025-01-17 05:26:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:26:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:26:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:26:35 --> Upload Class Initialized
INFO - 2025-01-17 05:26:35 --> Email Class Initialized
INFO - 2025-01-17 05:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:26:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:26:35 --> Controller Class Initialized
INFO - 2025-01-17 10:56:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:56:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:56:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:56:35 --> Total execution time: 0.0464
INFO - 2025-01-17 05:27:35 --> Config Class Initialized
INFO - 2025-01-17 05:27:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:27:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:27:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:27:35 --> URI Class Initialized
INFO - 2025-01-17 05:27:35 --> Router Class Initialized
INFO - 2025-01-17 05:27:35 --> Output Class Initialized
INFO - 2025-01-17 05:27:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:27:35 --> Input Class Initialized
INFO - 2025-01-17 05:27:35 --> Language Class Initialized
INFO - 2025-01-17 05:27:35 --> Loader Class Initialized
INFO - 2025-01-17 05:27:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:27:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:27:35 --> Upload Class Initialized
INFO - 2025-01-17 05:27:35 --> Email Class Initialized
INFO - 2025-01-17 05:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:27:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:27:35 --> Controller Class Initialized
INFO - 2025-01-17 10:57:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:57:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:57:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:27:35 --> Config Class Initialized
INFO - 2025-01-17 05:27:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:27:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:27:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:27:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:27:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:27:35 --> Router Class Initialized
INFO - 2025-01-17 05:27:35 --> Output Class Initialized
INFO - 2025-01-17 05:27:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:27:35 --> Input Class Initialized
INFO - 2025-01-17 05:27:35 --> Language Class Initialized
INFO - 2025-01-17 05:27:35 --> Loader Class Initialized
INFO - 2025-01-17 05:27:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:27:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:27:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:27:35 --> Upload Class Initialized
INFO - 2025-01-17 05:27:35 --> Email Class Initialized
INFO - 2025-01-17 05:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:27:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:27:35 --> Controller Class Initialized
INFO - 2025-01-17 10:57:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:57:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:57:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:57:35 --> Total execution time: 0.0220
INFO - 2025-01-17 05:28:35 --> Config Class Initialized
INFO - 2025-01-17 05:28:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:28:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:28:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:28:35 --> URI Class Initialized
INFO - 2025-01-17 05:28:35 --> Router Class Initialized
INFO - 2025-01-17 05:28:35 --> Output Class Initialized
INFO - 2025-01-17 05:28:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:28:35 --> Input Class Initialized
INFO - 2025-01-17 05:28:35 --> Language Class Initialized
INFO - 2025-01-17 05:28:35 --> Loader Class Initialized
INFO - 2025-01-17 05:28:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:28:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:28:35 --> Upload Class Initialized
INFO - 2025-01-17 05:28:35 --> Email Class Initialized
INFO - 2025-01-17 05:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:28:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:28:35 --> Controller Class Initialized
INFO - 2025-01-17 10:58:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:58:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:58:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:28:35 --> Config Class Initialized
INFO - 2025-01-17 05:28:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:28:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:28:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:28:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:28:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:28:35 --> Router Class Initialized
INFO - 2025-01-17 05:28:35 --> Output Class Initialized
INFO - 2025-01-17 05:28:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:28:35 --> Input Class Initialized
INFO - 2025-01-17 05:28:35 --> Language Class Initialized
INFO - 2025-01-17 05:28:35 --> Loader Class Initialized
INFO - 2025-01-17 05:28:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:28:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:28:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:28:35 --> Upload Class Initialized
INFO - 2025-01-17 05:28:35 --> Email Class Initialized
INFO - 2025-01-17 05:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:28:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:28:35 --> Controller Class Initialized
INFO - 2025-01-17 10:58:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:58:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:58:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:58:35 --> Total execution time: 0.0336
INFO - 2025-01-17 05:29:35 --> Config Class Initialized
INFO - 2025-01-17 05:29:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:29:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:29:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:29:35 --> URI Class Initialized
INFO - 2025-01-17 05:29:35 --> Router Class Initialized
INFO - 2025-01-17 05:29:35 --> Output Class Initialized
INFO - 2025-01-17 05:29:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:29:35 --> Input Class Initialized
INFO - 2025-01-17 05:29:35 --> Language Class Initialized
INFO - 2025-01-17 05:29:35 --> Loader Class Initialized
INFO - 2025-01-17 05:29:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:29:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:29:35 --> Upload Class Initialized
INFO - 2025-01-17 05:29:35 --> Email Class Initialized
INFO - 2025-01-17 05:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:29:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:29:35 --> Controller Class Initialized
INFO - 2025-01-17 10:59:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 10:59:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 10:59:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:29:35 --> Config Class Initialized
INFO - 2025-01-17 05:29:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:29:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:29:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:29:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:29:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:29:35 --> Router Class Initialized
INFO - 2025-01-17 05:29:35 --> Output Class Initialized
INFO - 2025-01-17 05:29:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:29:35 --> Input Class Initialized
INFO - 2025-01-17 05:29:35 --> Language Class Initialized
INFO - 2025-01-17 05:29:35 --> Loader Class Initialized
INFO - 2025-01-17 05:29:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:29:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:29:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:29:35 --> Upload Class Initialized
INFO - 2025-01-17 05:29:35 --> Email Class Initialized
INFO - 2025-01-17 05:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:29:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:29:35 --> Controller Class Initialized
INFO - 2025-01-17 10:59:35 --> Model "MainModel" initialized
INFO - 2025-01-17 10:59:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 10:59:35 --> Final output sent to browser
DEBUG - 2025-01-17 10:59:35 --> Total execution time: 0.0369
INFO - 2025-01-17 05:30:35 --> Config Class Initialized
INFO - 2025-01-17 05:30:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:30:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:30:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:30:35 --> URI Class Initialized
INFO - 2025-01-17 05:30:35 --> Router Class Initialized
INFO - 2025-01-17 05:30:35 --> Output Class Initialized
INFO - 2025-01-17 05:30:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:30:35 --> Input Class Initialized
INFO - 2025-01-17 05:30:35 --> Language Class Initialized
INFO - 2025-01-17 05:30:35 --> Loader Class Initialized
INFO - 2025-01-17 05:30:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:30:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:30:35 --> Upload Class Initialized
INFO - 2025-01-17 05:30:35 --> Email Class Initialized
INFO - 2025-01-17 05:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:30:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:30:35 --> Controller Class Initialized
INFO - 2025-01-17 11:00:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:00:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:00:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:30:35 --> Config Class Initialized
INFO - 2025-01-17 05:30:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:30:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:30:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:30:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:30:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:30:35 --> Router Class Initialized
INFO - 2025-01-17 05:30:35 --> Output Class Initialized
INFO - 2025-01-17 05:30:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:30:35 --> Input Class Initialized
INFO - 2025-01-17 05:30:35 --> Language Class Initialized
INFO - 2025-01-17 05:30:35 --> Loader Class Initialized
INFO - 2025-01-17 05:30:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:30:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:30:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:30:35 --> Upload Class Initialized
INFO - 2025-01-17 05:30:35 --> Email Class Initialized
INFO - 2025-01-17 05:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:30:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:30:35 --> Controller Class Initialized
INFO - 2025-01-17 11:00:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:00:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:00:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:00:35 --> Total execution time: 0.0252
INFO - 2025-01-17 05:31:35 --> Config Class Initialized
INFO - 2025-01-17 05:31:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:31:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:31:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:31:35 --> URI Class Initialized
INFO - 2025-01-17 05:31:35 --> Router Class Initialized
INFO - 2025-01-17 05:31:35 --> Output Class Initialized
INFO - 2025-01-17 05:31:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:31:35 --> Input Class Initialized
INFO - 2025-01-17 05:31:35 --> Language Class Initialized
INFO - 2025-01-17 05:31:35 --> Loader Class Initialized
INFO - 2025-01-17 05:31:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:31:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:31:35 --> Upload Class Initialized
INFO - 2025-01-17 05:31:35 --> Email Class Initialized
INFO - 2025-01-17 05:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:31:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:31:35 --> Controller Class Initialized
INFO - 2025-01-17 11:01:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:01:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:01:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:31:35 --> Config Class Initialized
INFO - 2025-01-17 05:31:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:31:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:31:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:31:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:31:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:31:35 --> Router Class Initialized
INFO - 2025-01-17 05:31:35 --> Output Class Initialized
INFO - 2025-01-17 05:31:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:31:35 --> Input Class Initialized
INFO - 2025-01-17 05:31:35 --> Language Class Initialized
INFO - 2025-01-17 05:31:35 --> Loader Class Initialized
INFO - 2025-01-17 05:31:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:31:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:31:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:31:35 --> Upload Class Initialized
INFO - 2025-01-17 05:31:35 --> Email Class Initialized
INFO - 2025-01-17 05:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:31:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:31:35 --> Controller Class Initialized
INFO - 2025-01-17 11:01:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:01:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:01:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:01:35 --> Total execution time: 0.0273
INFO - 2025-01-17 05:32:35 --> Config Class Initialized
INFO - 2025-01-17 05:32:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:32:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:32:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:32:35 --> URI Class Initialized
INFO - 2025-01-17 05:32:35 --> Router Class Initialized
INFO - 2025-01-17 05:32:35 --> Output Class Initialized
INFO - 2025-01-17 05:32:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:32:35 --> Input Class Initialized
INFO - 2025-01-17 05:32:35 --> Language Class Initialized
INFO - 2025-01-17 05:32:35 --> Loader Class Initialized
INFO - 2025-01-17 05:32:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:32:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:32:35 --> Upload Class Initialized
INFO - 2025-01-17 05:32:35 --> Email Class Initialized
INFO - 2025-01-17 05:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:32:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:32:35 --> Controller Class Initialized
INFO - 2025-01-17 11:02:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:02:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:02:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:32:35 --> Config Class Initialized
INFO - 2025-01-17 05:32:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:32:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:32:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:32:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:32:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:32:35 --> Router Class Initialized
INFO - 2025-01-17 05:32:35 --> Output Class Initialized
INFO - 2025-01-17 05:32:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:32:35 --> Input Class Initialized
INFO - 2025-01-17 05:32:35 --> Language Class Initialized
INFO - 2025-01-17 05:32:35 --> Loader Class Initialized
INFO - 2025-01-17 05:32:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:32:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:32:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:32:35 --> Upload Class Initialized
INFO - 2025-01-17 05:32:35 --> Email Class Initialized
INFO - 2025-01-17 05:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:32:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:32:35 --> Controller Class Initialized
INFO - 2025-01-17 11:02:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:02:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:02:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:02:35 --> Total execution time: 0.0283
INFO - 2025-01-17 05:33:35 --> Config Class Initialized
INFO - 2025-01-17 05:33:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:33:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:33:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:33:35 --> URI Class Initialized
INFO - 2025-01-17 05:33:35 --> Router Class Initialized
INFO - 2025-01-17 05:33:35 --> Output Class Initialized
INFO - 2025-01-17 05:33:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:33:35 --> Input Class Initialized
INFO - 2025-01-17 05:33:35 --> Language Class Initialized
INFO - 2025-01-17 05:33:35 --> Loader Class Initialized
INFO - 2025-01-17 05:33:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:33:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:33:35 --> Upload Class Initialized
INFO - 2025-01-17 05:33:35 --> Email Class Initialized
INFO - 2025-01-17 05:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:33:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:33:35 --> Controller Class Initialized
INFO - 2025-01-17 11:03:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:03:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:03:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:03:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:33:35 --> Config Class Initialized
INFO - 2025-01-17 05:33:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:33:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:33:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:33:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:33:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:33:35 --> Router Class Initialized
INFO - 2025-01-17 05:33:35 --> Output Class Initialized
INFO - 2025-01-17 05:33:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:33:35 --> Input Class Initialized
INFO - 2025-01-17 05:33:35 --> Language Class Initialized
INFO - 2025-01-17 05:33:35 --> Loader Class Initialized
INFO - 2025-01-17 05:33:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:33:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:33:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:33:35 --> Upload Class Initialized
INFO - 2025-01-17 05:33:35 --> Email Class Initialized
INFO - 2025-01-17 05:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:33:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:33:35 --> Controller Class Initialized
INFO - 2025-01-17 11:03:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:03:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:03:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:03:35 --> Total execution time: 0.0227
INFO - 2025-01-17 05:34:35 --> Config Class Initialized
INFO - 2025-01-17 05:34:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:34:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:34:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:34:35 --> URI Class Initialized
INFO - 2025-01-17 05:34:35 --> Router Class Initialized
INFO - 2025-01-17 05:34:35 --> Output Class Initialized
INFO - 2025-01-17 05:34:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:34:35 --> Input Class Initialized
INFO - 2025-01-17 05:34:35 --> Language Class Initialized
INFO - 2025-01-17 05:34:35 --> Loader Class Initialized
INFO - 2025-01-17 05:34:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:34:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:34:35 --> Upload Class Initialized
INFO - 2025-01-17 05:34:35 --> Email Class Initialized
INFO - 2025-01-17 05:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:34:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:34:35 --> Controller Class Initialized
INFO - 2025-01-17 11:04:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:04:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:04:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:34:35 --> Config Class Initialized
INFO - 2025-01-17 05:34:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:34:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:34:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:34:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:34:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:34:35 --> Router Class Initialized
INFO - 2025-01-17 05:34:35 --> Output Class Initialized
INFO - 2025-01-17 05:34:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:34:35 --> Input Class Initialized
INFO - 2025-01-17 05:34:35 --> Language Class Initialized
INFO - 2025-01-17 05:34:35 --> Loader Class Initialized
INFO - 2025-01-17 05:34:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:34:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:34:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:34:35 --> Upload Class Initialized
INFO - 2025-01-17 05:34:35 --> Email Class Initialized
INFO - 2025-01-17 05:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:34:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:34:35 --> Controller Class Initialized
INFO - 2025-01-17 11:04:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:04:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:04:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:04:35 --> Total execution time: 0.0277
INFO - 2025-01-17 05:35:35 --> Config Class Initialized
INFO - 2025-01-17 05:35:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:35:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:35:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:35:35 --> URI Class Initialized
INFO - 2025-01-17 05:35:35 --> Router Class Initialized
INFO - 2025-01-17 05:35:35 --> Output Class Initialized
INFO - 2025-01-17 05:35:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:35:35 --> Input Class Initialized
INFO - 2025-01-17 05:35:35 --> Language Class Initialized
INFO - 2025-01-17 05:35:35 --> Loader Class Initialized
INFO - 2025-01-17 05:35:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:35:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:35:35 --> Upload Class Initialized
INFO - 2025-01-17 05:35:35 --> Email Class Initialized
INFO - 2025-01-17 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:35:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:35:35 --> Controller Class Initialized
INFO - 2025-01-17 11:05:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:05:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:05:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:35:35 --> Config Class Initialized
INFO - 2025-01-17 05:35:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:35:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:35:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:35:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:35:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:35:35 --> Router Class Initialized
INFO - 2025-01-17 05:35:35 --> Output Class Initialized
INFO - 2025-01-17 05:35:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:35:35 --> Input Class Initialized
INFO - 2025-01-17 05:35:35 --> Language Class Initialized
INFO - 2025-01-17 05:35:35 --> Loader Class Initialized
INFO - 2025-01-17 05:35:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:35:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:35:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:35:35 --> Upload Class Initialized
INFO - 2025-01-17 05:35:35 --> Email Class Initialized
INFO - 2025-01-17 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:35:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:35:35 --> Controller Class Initialized
INFO - 2025-01-17 11:05:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:05:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:05:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:05:35 --> Total execution time: 0.0319
INFO - 2025-01-17 05:36:35 --> Config Class Initialized
INFO - 2025-01-17 05:36:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:36:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:36:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:36:35 --> URI Class Initialized
INFO - 2025-01-17 05:36:35 --> Router Class Initialized
INFO - 2025-01-17 05:36:35 --> Output Class Initialized
INFO - 2025-01-17 05:36:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:36:35 --> Input Class Initialized
INFO - 2025-01-17 05:36:35 --> Language Class Initialized
INFO - 2025-01-17 05:36:35 --> Loader Class Initialized
INFO - 2025-01-17 05:36:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:36:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:36:35 --> Upload Class Initialized
INFO - 2025-01-17 05:36:35 --> Email Class Initialized
INFO - 2025-01-17 05:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:36:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:36:35 --> Controller Class Initialized
INFO - 2025-01-17 11:06:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:06:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:06:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:36:35 --> Config Class Initialized
INFO - 2025-01-17 05:36:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:36:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:36:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:36:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:36:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:36:35 --> Router Class Initialized
INFO - 2025-01-17 05:36:35 --> Output Class Initialized
INFO - 2025-01-17 05:36:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:36:35 --> Input Class Initialized
INFO - 2025-01-17 05:36:35 --> Language Class Initialized
INFO - 2025-01-17 05:36:35 --> Loader Class Initialized
INFO - 2025-01-17 05:36:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:36:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:36:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:36:35 --> Upload Class Initialized
INFO - 2025-01-17 05:36:35 --> Email Class Initialized
INFO - 2025-01-17 05:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:36:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:36:35 --> Controller Class Initialized
INFO - 2025-01-17 11:06:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:06:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:06:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:06:35 --> Total execution time: 0.0242
INFO - 2025-01-17 05:37:35 --> Config Class Initialized
INFO - 2025-01-17 05:37:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:37:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:37:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:37:35 --> URI Class Initialized
INFO - 2025-01-17 05:37:35 --> Router Class Initialized
INFO - 2025-01-17 05:37:35 --> Output Class Initialized
INFO - 2025-01-17 05:37:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:37:35 --> Input Class Initialized
INFO - 2025-01-17 05:37:35 --> Language Class Initialized
INFO - 2025-01-17 05:37:35 --> Loader Class Initialized
INFO - 2025-01-17 05:37:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:37:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:37:35 --> Upload Class Initialized
INFO - 2025-01-17 05:37:35 --> Email Class Initialized
INFO - 2025-01-17 05:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:37:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:37:35 --> Controller Class Initialized
INFO - 2025-01-17 11:07:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:07:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:07:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:37:35 --> Config Class Initialized
INFO - 2025-01-17 05:37:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:37:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:37:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:37:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:37:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:37:35 --> Router Class Initialized
INFO - 2025-01-17 05:37:35 --> Output Class Initialized
INFO - 2025-01-17 05:37:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:37:35 --> Input Class Initialized
INFO - 2025-01-17 05:37:35 --> Language Class Initialized
INFO - 2025-01-17 05:37:35 --> Loader Class Initialized
INFO - 2025-01-17 05:37:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:37:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:37:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:37:35 --> Upload Class Initialized
INFO - 2025-01-17 05:37:35 --> Email Class Initialized
INFO - 2025-01-17 05:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:37:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:37:35 --> Controller Class Initialized
INFO - 2025-01-17 11:07:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:07:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:07:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:07:35 --> Total execution time: 0.0453
INFO - 2025-01-17 05:38:35 --> Config Class Initialized
INFO - 2025-01-17 05:38:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:38:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:38:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:38:35 --> URI Class Initialized
INFO - 2025-01-17 05:38:35 --> Router Class Initialized
INFO - 2025-01-17 05:38:35 --> Output Class Initialized
INFO - 2025-01-17 05:38:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:38:35 --> Input Class Initialized
INFO - 2025-01-17 05:38:35 --> Language Class Initialized
INFO - 2025-01-17 05:38:35 --> Loader Class Initialized
INFO - 2025-01-17 05:38:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:38:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:38:35 --> Upload Class Initialized
INFO - 2025-01-17 05:38:35 --> Email Class Initialized
INFO - 2025-01-17 05:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:38:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:38:35 --> Controller Class Initialized
INFO - 2025-01-17 11:08:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:08:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:08:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:38:35 --> Config Class Initialized
INFO - 2025-01-17 05:38:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:38:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:38:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:38:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:38:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:38:35 --> Router Class Initialized
INFO - 2025-01-17 05:38:35 --> Output Class Initialized
INFO - 2025-01-17 05:38:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:38:35 --> Input Class Initialized
INFO - 2025-01-17 05:38:35 --> Language Class Initialized
INFO - 2025-01-17 05:38:35 --> Loader Class Initialized
INFO - 2025-01-17 05:38:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:38:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:38:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:38:35 --> Upload Class Initialized
INFO - 2025-01-17 05:38:35 --> Email Class Initialized
INFO - 2025-01-17 05:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:38:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:38:35 --> Controller Class Initialized
INFO - 2025-01-17 11:08:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:08:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:08:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:08:35 --> Total execution time: 0.0232
INFO - 2025-01-17 05:39:35 --> Config Class Initialized
INFO - 2025-01-17 05:39:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:39:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:39:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:39:35 --> URI Class Initialized
INFO - 2025-01-17 05:39:35 --> Router Class Initialized
INFO - 2025-01-17 05:39:35 --> Output Class Initialized
INFO - 2025-01-17 05:39:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:39:35 --> Input Class Initialized
INFO - 2025-01-17 05:39:35 --> Language Class Initialized
INFO - 2025-01-17 05:39:35 --> Loader Class Initialized
INFO - 2025-01-17 05:39:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:39:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:39:35 --> Upload Class Initialized
INFO - 2025-01-17 05:39:35 --> Email Class Initialized
INFO - 2025-01-17 05:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:39:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:39:35 --> Controller Class Initialized
INFO - 2025-01-17 11:09:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:09:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:09:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:39:35 --> Config Class Initialized
INFO - 2025-01-17 05:39:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:39:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:39:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:39:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:39:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:39:35 --> Router Class Initialized
INFO - 2025-01-17 05:39:35 --> Output Class Initialized
INFO - 2025-01-17 05:39:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:39:35 --> Input Class Initialized
INFO - 2025-01-17 05:39:35 --> Language Class Initialized
INFO - 2025-01-17 05:39:35 --> Loader Class Initialized
INFO - 2025-01-17 05:39:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:39:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:39:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:39:35 --> Upload Class Initialized
INFO - 2025-01-17 05:39:35 --> Email Class Initialized
INFO - 2025-01-17 05:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:39:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:39:35 --> Controller Class Initialized
INFO - 2025-01-17 11:09:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:09:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:09:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:09:35 --> Total execution time: 0.0223
INFO - 2025-01-17 05:40:35 --> Config Class Initialized
INFO - 2025-01-17 05:40:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:40:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:40:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:40:35 --> URI Class Initialized
INFO - 2025-01-17 05:40:35 --> Router Class Initialized
INFO - 2025-01-17 05:40:35 --> Output Class Initialized
INFO - 2025-01-17 05:40:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:40:35 --> Input Class Initialized
INFO - 2025-01-17 05:40:35 --> Language Class Initialized
INFO - 2025-01-17 05:40:35 --> Loader Class Initialized
INFO - 2025-01-17 05:40:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:40:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:40:35 --> Upload Class Initialized
INFO - 2025-01-17 05:40:35 --> Email Class Initialized
INFO - 2025-01-17 05:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:40:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:40:35 --> Controller Class Initialized
INFO - 2025-01-17 11:10:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:10:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:10:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:40:35 --> Config Class Initialized
INFO - 2025-01-17 05:40:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:40:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:40:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:40:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:40:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:40:35 --> Router Class Initialized
INFO - 2025-01-17 05:40:35 --> Output Class Initialized
INFO - 2025-01-17 05:40:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:40:35 --> Input Class Initialized
INFO - 2025-01-17 05:40:35 --> Language Class Initialized
INFO - 2025-01-17 05:40:35 --> Loader Class Initialized
INFO - 2025-01-17 05:40:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:40:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:40:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:40:35 --> Upload Class Initialized
INFO - 2025-01-17 05:40:35 --> Email Class Initialized
INFO - 2025-01-17 05:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:40:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:40:35 --> Controller Class Initialized
INFO - 2025-01-17 11:10:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:10:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:10:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:10:35 --> Total execution time: 0.0281
INFO - 2025-01-17 05:41:35 --> Config Class Initialized
INFO - 2025-01-17 05:41:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:41:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:41:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:41:35 --> URI Class Initialized
INFO - 2025-01-17 05:41:35 --> Router Class Initialized
INFO - 2025-01-17 05:41:35 --> Output Class Initialized
INFO - 2025-01-17 05:41:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:41:35 --> Input Class Initialized
INFO - 2025-01-17 05:41:35 --> Language Class Initialized
INFO - 2025-01-17 05:41:35 --> Loader Class Initialized
INFO - 2025-01-17 05:41:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:41:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:41:35 --> Upload Class Initialized
INFO - 2025-01-17 05:41:35 --> Email Class Initialized
INFO - 2025-01-17 05:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:41:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:41:35 --> Controller Class Initialized
INFO - 2025-01-17 11:11:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:11:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:11:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:41:35 --> Config Class Initialized
INFO - 2025-01-17 05:41:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:41:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:41:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:41:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:41:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:41:35 --> Router Class Initialized
INFO - 2025-01-17 05:41:35 --> Output Class Initialized
INFO - 2025-01-17 05:41:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:41:35 --> Input Class Initialized
INFO - 2025-01-17 05:41:35 --> Language Class Initialized
INFO - 2025-01-17 05:41:35 --> Loader Class Initialized
INFO - 2025-01-17 05:41:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:41:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:41:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:41:35 --> Upload Class Initialized
INFO - 2025-01-17 05:41:35 --> Email Class Initialized
INFO - 2025-01-17 05:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:41:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:41:35 --> Controller Class Initialized
INFO - 2025-01-17 11:11:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:11:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:11:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:11:35 --> Total execution time: 0.0245
INFO - 2025-01-17 05:42:35 --> Config Class Initialized
INFO - 2025-01-17 05:42:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:42:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:42:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:42:35 --> URI Class Initialized
INFO - 2025-01-17 05:42:35 --> Router Class Initialized
INFO - 2025-01-17 05:42:35 --> Output Class Initialized
INFO - 2025-01-17 05:42:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:42:35 --> Input Class Initialized
INFO - 2025-01-17 05:42:35 --> Language Class Initialized
INFO - 2025-01-17 05:42:35 --> Loader Class Initialized
INFO - 2025-01-17 05:42:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:42:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:42:35 --> Upload Class Initialized
INFO - 2025-01-17 05:42:35 --> Email Class Initialized
INFO - 2025-01-17 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:42:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:42:35 --> Controller Class Initialized
INFO - 2025-01-17 11:12:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:12:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:12:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:42:35 --> Config Class Initialized
INFO - 2025-01-17 05:42:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:42:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:42:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:42:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:42:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:42:35 --> Router Class Initialized
INFO - 2025-01-17 05:42:35 --> Output Class Initialized
INFO - 2025-01-17 05:42:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:42:35 --> Input Class Initialized
INFO - 2025-01-17 05:42:35 --> Language Class Initialized
INFO - 2025-01-17 05:42:35 --> Loader Class Initialized
INFO - 2025-01-17 05:42:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:42:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:42:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:42:35 --> Upload Class Initialized
INFO - 2025-01-17 05:42:35 --> Email Class Initialized
INFO - 2025-01-17 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:42:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:42:35 --> Controller Class Initialized
INFO - 2025-01-17 11:12:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:12:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:12:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:12:35 --> Total execution time: 0.0240
INFO - 2025-01-17 05:43:35 --> Config Class Initialized
INFO - 2025-01-17 05:43:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:43:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:43:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:43:35 --> URI Class Initialized
INFO - 2025-01-17 05:43:35 --> Router Class Initialized
INFO - 2025-01-17 05:43:35 --> Output Class Initialized
INFO - 2025-01-17 05:43:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:43:35 --> Input Class Initialized
INFO - 2025-01-17 05:43:35 --> Language Class Initialized
INFO - 2025-01-17 05:43:35 --> Loader Class Initialized
INFO - 2025-01-17 05:43:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:43:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:43:35 --> Upload Class Initialized
INFO - 2025-01-17 05:43:35 --> Email Class Initialized
INFO - 2025-01-17 05:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:43:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:43:35 --> Controller Class Initialized
INFO - 2025-01-17 11:13:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:13:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:13:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:43:35 --> Config Class Initialized
INFO - 2025-01-17 05:43:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:43:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:43:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:43:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:43:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:43:35 --> Router Class Initialized
INFO - 2025-01-17 05:43:35 --> Output Class Initialized
INFO - 2025-01-17 05:43:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:43:35 --> Input Class Initialized
INFO - 2025-01-17 05:43:35 --> Language Class Initialized
INFO - 2025-01-17 05:43:35 --> Loader Class Initialized
INFO - 2025-01-17 05:43:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:43:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:43:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:43:35 --> Upload Class Initialized
INFO - 2025-01-17 05:43:35 --> Email Class Initialized
INFO - 2025-01-17 05:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:43:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:43:35 --> Controller Class Initialized
INFO - 2025-01-17 11:13:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:13:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:13:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:13:35 --> Total execution time: 0.0239
INFO - 2025-01-17 05:44:36 --> Config Class Initialized
INFO - 2025-01-17 05:44:36 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:44:36 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:44:36 --> Utf8 Class Initialized
INFO - 2025-01-17 05:44:36 --> URI Class Initialized
INFO - 2025-01-17 05:44:36 --> Router Class Initialized
INFO - 2025-01-17 05:44:36 --> Output Class Initialized
INFO - 2025-01-17 05:44:36 --> Security Class Initialized
DEBUG - 2025-01-17 05:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:44:36 --> Input Class Initialized
INFO - 2025-01-17 05:44:36 --> Language Class Initialized
INFO - 2025-01-17 05:44:36 --> Loader Class Initialized
INFO - 2025-01-17 05:44:36 --> Helper loaded: url_helper
INFO - 2025-01-17 05:44:36 --> Helper loaded: html_helper
INFO - 2025-01-17 05:44:36 --> Helper loaded: file_helper
INFO - 2025-01-17 05:44:36 --> Helper loaded: string_helper
INFO - 2025-01-17 05:44:36 --> Helper loaded: form_helper
INFO - 2025-01-17 05:44:36 --> Helper loaded: my_helper
INFO - 2025-01-17 05:44:36 --> Database Driver Class Initialized
INFO - 2025-01-17 05:44:36 --> Upload Class Initialized
INFO - 2025-01-17 05:44:36 --> Email Class Initialized
INFO - 2025-01-17 05:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:44:36 --> Form Validation Class Initialized
INFO - 2025-01-17 05:44:36 --> Controller Class Initialized
INFO - 2025-01-17 11:14:36 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:14:36 --> Model "MainModel" initialized
INFO - 2025-01-17 11:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:14:36 --> Pagination Class Initialized
INFO - 2025-01-17 05:44:43 --> Config Class Initialized
INFO - 2025-01-17 05:44:43 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:44:43 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:44:43 --> Utf8 Class Initialized
INFO - 2025-01-17 05:44:43 --> URI Class Initialized
DEBUG - 2025-01-17 05:44:43 --> No URI present. Default controller set.
INFO - 2025-01-17 05:44:43 --> Router Class Initialized
INFO - 2025-01-17 05:44:43 --> Output Class Initialized
INFO - 2025-01-17 05:44:43 --> Security Class Initialized
DEBUG - 2025-01-17 05:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:44:43 --> Input Class Initialized
INFO - 2025-01-17 05:44:43 --> Language Class Initialized
INFO - 2025-01-17 05:44:43 --> Loader Class Initialized
INFO - 2025-01-17 05:44:43 --> Helper loaded: url_helper
INFO - 2025-01-17 05:44:43 --> Helper loaded: html_helper
INFO - 2025-01-17 05:44:43 --> Helper loaded: file_helper
INFO - 2025-01-17 05:44:43 --> Helper loaded: string_helper
INFO - 2025-01-17 05:44:43 --> Helper loaded: form_helper
INFO - 2025-01-17 05:44:43 --> Helper loaded: my_helper
INFO - 2025-01-17 05:44:43 --> Database Driver Class Initialized
INFO - 2025-01-17 05:44:43 --> Upload Class Initialized
INFO - 2025-01-17 05:44:43 --> Email Class Initialized
INFO - 2025-01-17 05:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:44:43 --> Form Validation Class Initialized
INFO - 2025-01-17 05:44:43 --> Controller Class Initialized
INFO - 2025-01-17 11:14:43 --> Model "MainModel" initialized
INFO - 2025-01-17 11:14:43 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:14:43 --> Final output sent to browser
DEBUG - 2025-01-17 11:14:43 --> Total execution time: 0.0592
INFO - 2025-01-17 05:45:35 --> Config Class Initialized
INFO - 2025-01-17 05:45:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:45:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:45:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:45:35 --> URI Class Initialized
INFO - 2025-01-17 05:45:35 --> Router Class Initialized
INFO - 2025-01-17 05:45:35 --> Output Class Initialized
INFO - 2025-01-17 05:45:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:45:35 --> Input Class Initialized
INFO - 2025-01-17 05:45:35 --> Language Class Initialized
INFO - 2025-01-17 05:45:35 --> Loader Class Initialized
INFO - 2025-01-17 05:45:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:45:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:45:35 --> Upload Class Initialized
INFO - 2025-01-17 05:45:35 --> Email Class Initialized
INFO - 2025-01-17 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:45:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:45:35 --> Controller Class Initialized
INFO - 2025-01-17 11:15:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:15:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:15:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:45:35 --> Config Class Initialized
INFO - 2025-01-17 05:45:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:45:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:45:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:45:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:45:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:45:35 --> Router Class Initialized
INFO - 2025-01-17 05:45:35 --> Output Class Initialized
INFO - 2025-01-17 05:45:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:45:35 --> Input Class Initialized
INFO - 2025-01-17 05:45:35 --> Language Class Initialized
INFO - 2025-01-17 05:45:35 --> Loader Class Initialized
INFO - 2025-01-17 05:45:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:45:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:45:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:45:35 --> Upload Class Initialized
INFO - 2025-01-17 05:45:35 --> Email Class Initialized
INFO - 2025-01-17 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:45:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:45:35 --> Controller Class Initialized
INFO - 2025-01-17 11:15:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:15:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:15:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:15:35 --> Total execution time: 0.0344
INFO - 2025-01-17 05:46:35 --> Config Class Initialized
INFO - 2025-01-17 05:46:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:46:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:46:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:46:35 --> URI Class Initialized
INFO - 2025-01-17 05:46:35 --> Router Class Initialized
INFO - 2025-01-17 05:46:35 --> Output Class Initialized
INFO - 2025-01-17 05:46:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:46:35 --> Input Class Initialized
INFO - 2025-01-17 05:46:35 --> Language Class Initialized
INFO - 2025-01-17 05:46:35 --> Loader Class Initialized
INFO - 2025-01-17 05:46:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:46:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:46:35 --> Upload Class Initialized
INFO - 2025-01-17 05:46:35 --> Email Class Initialized
INFO - 2025-01-17 05:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:46:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:46:35 --> Controller Class Initialized
INFO - 2025-01-17 11:16:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:16:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:16:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:46:35 --> Config Class Initialized
INFO - 2025-01-17 05:46:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:46:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:46:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:46:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:46:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:46:35 --> Router Class Initialized
INFO - 2025-01-17 05:46:35 --> Output Class Initialized
INFO - 2025-01-17 05:46:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:46:35 --> Input Class Initialized
INFO - 2025-01-17 05:46:35 --> Language Class Initialized
INFO - 2025-01-17 05:46:35 --> Loader Class Initialized
INFO - 2025-01-17 05:46:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:46:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:46:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:46:35 --> Upload Class Initialized
INFO - 2025-01-17 05:46:35 --> Email Class Initialized
INFO - 2025-01-17 05:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:46:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:46:35 --> Controller Class Initialized
INFO - 2025-01-17 11:16:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:16:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:16:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:16:35 --> Total execution time: 0.0265
INFO - 2025-01-17 05:47:13 --> Config Class Initialized
INFO - 2025-01-17 05:47:13 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:13 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:13 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:13 --> URI Class Initialized
INFO - 2025-01-17 05:47:13 --> Router Class Initialized
INFO - 2025-01-17 05:47:13 --> Output Class Initialized
INFO - 2025-01-17 05:47:13 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:13 --> Input Class Initialized
INFO - 2025-01-17 05:47:13 --> Language Class Initialized
INFO - 2025-01-17 05:47:13 --> Loader Class Initialized
INFO - 2025-01-17 05:47:13 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:13 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:13 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:13 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:13 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:13 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:13 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:13 --> Upload Class Initialized
INFO - 2025-01-17 05:47:13 --> Email Class Initialized
INFO - 2025-01-17 05:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:13 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:14 --> Controller Class Initialized
INFO - 2025-01-17 11:17:14 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:14 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:14 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:14 --> Config Class Initialized
INFO - 2025-01-17 05:47:14 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:14 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:14 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:14 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:14 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:14 --> Router Class Initialized
INFO - 2025-01-17 05:47:14 --> Output Class Initialized
INFO - 2025-01-17 05:47:14 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:14 --> Input Class Initialized
INFO - 2025-01-17 05:47:14 --> Language Class Initialized
INFO - 2025-01-17 05:47:14 --> Loader Class Initialized
INFO - 2025-01-17 05:47:14 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:14 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:14 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:14 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:14 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:14 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:14 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:14 --> Upload Class Initialized
INFO - 2025-01-17 05:47:14 --> Email Class Initialized
INFO - 2025-01-17 05:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:14 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:14 --> Controller Class Initialized
INFO - 2025-01-17 11:17:14 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:14 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:14 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:14 --> Total execution time: 0.0388
INFO - 2025-01-17 05:47:17 --> Config Class Initialized
INFO - 2025-01-17 05:47:17 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:17 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:17 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:17 --> URI Class Initialized
INFO - 2025-01-17 05:47:17 --> Router Class Initialized
INFO - 2025-01-17 05:47:17 --> Output Class Initialized
INFO - 2025-01-17 05:47:17 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:17 --> Input Class Initialized
INFO - 2025-01-17 05:47:17 --> Language Class Initialized
INFO - 2025-01-17 05:47:17 --> Loader Class Initialized
INFO - 2025-01-17 05:47:17 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:17 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:17 --> Upload Class Initialized
INFO - 2025-01-17 05:47:17 --> Email Class Initialized
INFO - 2025-01-17 05:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:17 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:17 --> Controller Class Initialized
INFO - 2025-01-17 11:17:17 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:17 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:17 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:17 --> Config Class Initialized
INFO - 2025-01-17 05:47:17 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:17 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:17 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:17 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:17 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:17 --> Router Class Initialized
INFO - 2025-01-17 05:47:17 --> Output Class Initialized
INFO - 2025-01-17 05:47:17 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:17 --> Input Class Initialized
INFO - 2025-01-17 05:47:17 --> Language Class Initialized
INFO - 2025-01-17 05:47:17 --> Loader Class Initialized
INFO - 2025-01-17 05:47:17 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:17 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:17 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:17 --> Upload Class Initialized
INFO - 2025-01-17 05:47:17 --> Email Class Initialized
INFO - 2025-01-17 05:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:17 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:17 --> Controller Class Initialized
INFO - 2025-01-17 11:17:17 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:17 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:17 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:17 --> Total execution time: 0.0349
INFO - 2025-01-17 05:47:22 --> Config Class Initialized
INFO - 2025-01-17 05:47:22 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:22 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:22 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:22 --> URI Class Initialized
INFO - 2025-01-17 05:47:22 --> Router Class Initialized
INFO - 2025-01-17 05:47:22 --> Output Class Initialized
INFO - 2025-01-17 05:47:22 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:22 --> Input Class Initialized
INFO - 2025-01-17 05:47:22 --> Language Class Initialized
INFO - 2025-01-17 05:47:22 --> Loader Class Initialized
INFO - 2025-01-17 05:47:22 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:22 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:22 --> Upload Class Initialized
INFO - 2025-01-17 05:47:22 --> Email Class Initialized
INFO - 2025-01-17 05:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:22 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:22 --> Controller Class Initialized
INFO - 2025-01-17 11:17:22 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:22 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:22 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:22 --> Config Class Initialized
INFO - 2025-01-17 05:47:22 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:22 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:22 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:22 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:22 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:22 --> Router Class Initialized
INFO - 2025-01-17 05:47:22 --> Output Class Initialized
INFO - 2025-01-17 05:47:22 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:22 --> Input Class Initialized
INFO - 2025-01-17 05:47:22 --> Language Class Initialized
INFO - 2025-01-17 05:47:22 --> Loader Class Initialized
INFO - 2025-01-17 05:47:22 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:22 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:22 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:22 --> Upload Class Initialized
INFO - 2025-01-17 05:47:22 --> Email Class Initialized
INFO - 2025-01-17 05:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:22 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:22 --> Controller Class Initialized
INFO - 2025-01-17 11:17:22 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:22 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:22 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:22 --> Total execution time: 0.0422
INFO - 2025-01-17 05:47:27 --> Config Class Initialized
INFO - 2025-01-17 05:47:27 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:27 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:27 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:27 --> URI Class Initialized
INFO - 2025-01-17 05:47:27 --> Router Class Initialized
INFO - 2025-01-17 05:47:27 --> Output Class Initialized
INFO - 2025-01-17 05:47:27 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:27 --> Input Class Initialized
INFO - 2025-01-17 05:47:27 --> Language Class Initialized
INFO - 2025-01-17 05:47:27 --> Loader Class Initialized
INFO - 2025-01-17 05:47:27 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:27 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:27 --> Upload Class Initialized
INFO - 2025-01-17 05:47:27 --> Email Class Initialized
INFO - 2025-01-17 05:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:27 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:27 --> Controller Class Initialized
INFO - 2025-01-17 11:17:27 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:27 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:27 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:27 --> Config Class Initialized
INFO - 2025-01-17 05:47:27 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:27 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:27 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:27 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:27 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:27 --> Router Class Initialized
INFO - 2025-01-17 05:47:27 --> Output Class Initialized
INFO - 2025-01-17 05:47:27 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:27 --> Input Class Initialized
INFO - 2025-01-17 05:47:27 --> Language Class Initialized
INFO - 2025-01-17 05:47:27 --> Loader Class Initialized
INFO - 2025-01-17 05:47:27 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:27 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:27 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:27 --> Upload Class Initialized
INFO - 2025-01-17 05:47:27 --> Email Class Initialized
INFO - 2025-01-17 05:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:27 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:27 --> Controller Class Initialized
INFO - 2025-01-17 11:17:27 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:27 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:27 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:27 --> Total execution time: 0.0228
INFO - 2025-01-17 05:47:32 --> Config Class Initialized
INFO - 2025-01-17 05:47:32 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:32 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:32 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:32 --> URI Class Initialized
INFO - 2025-01-17 05:47:32 --> Router Class Initialized
INFO - 2025-01-17 05:47:32 --> Output Class Initialized
INFO - 2025-01-17 05:47:32 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:32 --> Input Class Initialized
INFO - 2025-01-17 05:47:32 --> Language Class Initialized
INFO - 2025-01-17 05:47:32 --> Loader Class Initialized
INFO - 2025-01-17 05:47:32 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:32 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:32 --> Upload Class Initialized
INFO - 2025-01-17 05:47:32 --> Email Class Initialized
INFO - 2025-01-17 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:32 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:32 --> Controller Class Initialized
INFO - 2025-01-17 11:17:32 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:32 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:32 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:32 --> Config Class Initialized
INFO - 2025-01-17 05:47:32 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:32 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:32 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:32 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:32 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:32 --> Router Class Initialized
INFO - 2025-01-17 05:47:32 --> Output Class Initialized
INFO - 2025-01-17 05:47:32 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:32 --> Input Class Initialized
INFO - 2025-01-17 05:47:32 --> Language Class Initialized
INFO - 2025-01-17 05:47:32 --> Loader Class Initialized
INFO - 2025-01-17 05:47:32 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:32 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:32 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:32 --> Upload Class Initialized
INFO - 2025-01-17 05:47:32 --> Email Class Initialized
INFO - 2025-01-17 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:32 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:32 --> Controller Class Initialized
INFO - 2025-01-17 11:17:32 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:32 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:32 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:32 --> Total execution time: 0.0235
INFO - 2025-01-17 05:47:37 --> Config Class Initialized
INFO - 2025-01-17 05:47:37 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:37 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:37 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:37 --> URI Class Initialized
INFO - 2025-01-17 05:47:37 --> Router Class Initialized
INFO - 2025-01-17 05:47:37 --> Output Class Initialized
INFO - 2025-01-17 05:47:37 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:37 --> Input Class Initialized
INFO - 2025-01-17 05:47:37 --> Language Class Initialized
INFO - 2025-01-17 05:47:37 --> Loader Class Initialized
INFO - 2025-01-17 05:47:37 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:37 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:37 --> Upload Class Initialized
INFO - 2025-01-17 05:47:37 --> Email Class Initialized
INFO - 2025-01-17 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:37 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:37 --> Controller Class Initialized
INFO - 2025-01-17 11:17:37 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:37 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:37 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:37 --> Config Class Initialized
INFO - 2025-01-17 05:47:37 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:37 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:37 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:37 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:37 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:37 --> Router Class Initialized
INFO - 2025-01-17 05:47:37 --> Output Class Initialized
INFO - 2025-01-17 05:47:37 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:37 --> Input Class Initialized
INFO - 2025-01-17 05:47:37 --> Language Class Initialized
INFO - 2025-01-17 05:47:37 --> Loader Class Initialized
INFO - 2025-01-17 05:47:37 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:37 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:37 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:37 --> Upload Class Initialized
INFO - 2025-01-17 05:47:37 --> Email Class Initialized
INFO - 2025-01-17 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:37 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:37 --> Controller Class Initialized
INFO - 2025-01-17 11:17:37 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:37 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:37 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:37 --> Total execution time: 0.0460
INFO - 2025-01-17 05:47:42 --> Config Class Initialized
INFO - 2025-01-17 05:47:42 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:42 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:42 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:42 --> URI Class Initialized
INFO - 2025-01-17 05:47:42 --> Router Class Initialized
INFO - 2025-01-17 05:47:42 --> Output Class Initialized
INFO - 2025-01-17 05:47:42 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:42 --> Input Class Initialized
INFO - 2025-01-17 05:47:42 --> Language Class Initialized
INFO - 2025-01-17 05:47:42 --> Loader Class Initialized
INFO - 2025-01-17 05:47:42 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:42 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:42 --> Upload Class Initialized
INFO - 2025-01-17 05:47:42 --> Email Class Initialized
INFO - 2025-01-17 05:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:42 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:42 --> Controller Class Initialized
INFO - 2025-01-17 11:17:42 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:42 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:42 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:42 --> Config Class Initialized
INFO - 2025-01-17 05:47:42 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:42 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:42 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:42 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:42 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:42 --> Router Class Initialized
INFO - 2025-01-17 05:47:42 --> Output Class Initialized
INFO - 2025-01-17 05:47:42 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:42 --> Input Class Initialized
INFO - 2025-01-17 05:47:42 --> Language Class Initialized
INFO - 2025-01-17 05:47:42 --> Loader Class Initialized
INFO - 2025-01-17 05:47:42 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:42 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:42 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:42 --> Upload Class Initialized
INFO - 2025-01-17 05:47:42 --> Email Class Initialized
INFO - 2025-01-17 05:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:42 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:42 --> Controller Class Initialized
INFO - 2025-01-17 11:17:42 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:42 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:42 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:42 --> Total execution time: 0.0314
INFO - 2025-01-17 05:47:47 --> Config Class Initialized
INFO - 2025-01-17 05:47:47 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:47 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:47 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:47 --> URI Class Initialized
INFO - 2025-01-17 05:47:47 --> Router Class Initialized
INFO - 2025-01-17 05:47:47 --> Output Class Initialized
INFO - 2025-01-17 05:47:47 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:47 --> Input Class Initialized
INFO - 2025-01-17 05:47:47 --> Language Class Initialized
INFO - 2025-01-17 05:47:47 --> Loader Class Initialized
INFO - 2025-01-17 05:47:47 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:47 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:47 --> Upload Class Initialized
INFO - 2025-01-17 05:47:47 --> Email Class Initialized
INFO - 2025-01-17 05:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:47 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:47 --> Controller Class Initialized
INFO - 2025-01-17 11:17:47 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:47 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:47 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:47 --> Config Class Initialized
INFO - 2025-01-17 05:47:47 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:47 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:47 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:47 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:47 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:47 --> Router Class Initialized
INFO - 2025-01-17 05:47:47 --> Output Class Initialized
INFO - 2025-01-17 05:47:47 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:47 --> Input Class Initialized
INFO - 2025-01-17 05:47:47 --> Language Class Initialized
INFO - 2025-01-17 05:47:47 --> Loader Class Initialized
INFO - 2025-01-17 05:47:47 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:47 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:47 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:47 --> Upload Class Initialized
INFO - 2025-01-17 05:47:47 --> Email Class Initialized
INFO - 2025-01-17 05:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:47 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:47 --> Controller Class Initialized
INFO - 2025-01-17 11:17:47 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:47 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:47 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:47 --> Total execution time: 0.0591
INFO - 2025-01-17 05:47:52 --> Config Class Initialized
INFO - 2025-01-17 05:47:52 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:52 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:52 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:52 --> URI Class Initialized
INFO - 2025-01-17 05:47:52 --> Router Class Initialized
INFO - 2025-01-17 05:47:52 --> Output Class Initialized
INFO - 2025-01-17 05:47:52 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:52 --> Input Class Initialized
INFO - 2025-01-17 05:47:52 --> Language Class Initialized
INFO - 2025-01-17 05:47:52 --> Loader Class Initialized
INFO - 2025-01-17 05:47:52 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:52 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:52 --> Upload Class Initialized
INFO - 2025-01-17 05:47:52 --> Email Class Initialized
INFO - 2025-01-17 05:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:52 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:52 --> Controller Class Initialized
INFO - 2025-01-17 11:17:52 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:52 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:52 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:52 --> Config Class Initialized
INFO - 2025-01-17 05:47:52 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:52 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:52 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:52 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:52 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:52 --> Router Class Initialized
INFO - 2025-01-17 05:47:52 --> Output Class Initialized
INFO - 2025-01-17 05:47:52 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:52 --> Input Class Initialized
INFO - 2025-01-17 05:47:52 --> Language Class Initialized
INFO - 2025-01-17 05:47:52 --> Loader Class Initialized
INFO - 2025-01-17 05:47:52 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:52 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:52 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:52 --> Upload Class Initialized
INFO - 2025-01-17 05:47:52 --> Email Class Initialized
INFO - 2025-01-17 05:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:52 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:52 --> Controller Class Initialized
INFO - 2025-01-17 11:17:52 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:52 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:52 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:52 --> Total execution time: 0.0290
INFO - 2025-01-17 05:47:57 --> Config Class Initialized
INFO - 2025-01-17 05:47:57 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:57 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:57 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:57 --> URI Class Initialized
INFO - 2025-01-17 05:47:57 --> Router Class Initialized
INFO - 2025-01-17 05:47:57 --> Output Class Initialized
INFO - 2025-01-17 05:47:57 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:57 --> Input Class Initialized
INFO - 2025-01-17 05:47:57 --> Language Class Initialized
INFO - 2025-01-17 05:47:57 --> Loader Class Initialized
INFO - 2025-01-17 05:47:57 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:57 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:57 --> Upload Class Initialized
INFO - 2025-01-17 05:47:57 --> Email Class Initialized
INFO - 2025-01-17 05:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:57 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:57 --> Controller Class Initialized
INFO - 2025-01-17 11:17:57 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:17:57 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:17:57 --> Pagination Class Initialized
INFO - 2025-01-17 05:47:57 --> Config Class Initialized
INFO - 2025-01-17 05:47:57 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:47:57 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:47:57 --> Utf8 Class Initialized
INFO - 2025-01-17 05:47:57 --> URI Class Initialized
DEBUG - 2025-01-17 05:47:57 --> No URI present. Default controller set.
INFO - 2025-01-17 05:47:57 --> Router Class Initialized
INFO - 2025-01-17 05:47:57 --> Output Class Initialized
INFO - 2025-01-17 05:47:57 --> Security Class Initialized
DEBUG - 2025-01-17 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:47:57 --> Input Class Initialized
INFO - 2025-01-17 05:47:57 --> Language Class Initialized
INFO - 2025-01-17 05:47:57 --> Loader Class Initialized
INFO - 2025-01-17 05:47:57 --> Helper loaded: url_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: html_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: file_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: string_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: form_helper
INFO - 2025-01-17 05:47:57 --> Helper loaded: my_helper
INFO - 2025-01-17 05:47:57 --> Database Driver Class Initialized
INFO - 2025-01-17 05:47:57 --> Upload Class Initialized
INFO - 2025-01-17 05:47:57 --> Email Class Initialized
INFO - 2025-01-17 05:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:47:57 --> Form Validation Class Initialized
INFO - 2025-01-17 05:47:57 --> Controller Class Initialized
INFO - 2025-01-17 11:17:57 --> Model "MainModel" initialized
INFO - 2025-01-17 11:17:57 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:17:57 --> Final output sent to browser
DEBUG - 2025-01-17 11:17:57 --> Total execution time: 0.0393
INFO - 2025-01-17 05:48:02 --> Config Class Initialized
INFO - 2025-01-17 05:48:02 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:02 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:02 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:02 --> URI Class Initialized
INFO - 2025-01-17 05:48:02 --> Router Class Initialized
INFO - 2025-01-17 05:48:02 --> Output Class Initialized
INFO - 2025-01-17 05:48:02 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:02 --> Input Class Initialized
INFO - 2025-01-17 05:48:02 --> Language Class Initialized
INFO - 2025-01-17 05:48:02 --> Loader Class Initialized
INFO - 2025-01-17 05:48:02 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:02 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:02 --> Upload Class Initialized
INFO - 2025-01-17 05:48:02 --> Email Class Initialized
INFO - 2025-01-17 05:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:02 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:02 --> Controller Class Initialized
INFO - 2025-01-17 11:18:02 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:18:02 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:18:02 --> Pagination Class Initialized
INFO - 2025-01-17 05:48:02 --> Config Class Initialized
INFO - 2025-01-17 05:48:02 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:02 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:02 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:02 --> URI Class Initialized
DEBUG - 2025-01-17 05:48:02 --> No URI present. Default controller set.
INFO - 2025-01-17 05:48:02 --> Router Class Initialized
INFO - 2025-01-17 05:48:02 --> Output Class Initialized
INFO - 2025-01-17 05:48:02 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:02 --> Input Class Initialized
INFO - 2025-01-17 05:48:02 --> Language Class Initialized
INFO - 2025-01-17 05:48:02 --> Loader Class Initialized
INFO - 2025-01-17 05:48:02 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:02 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:02 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:02 --> Upload Class Initialized
INFO - 2025-01-17 05:48:02 --> Email Class Initialized
INFO - 2025-01-17 05:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:02 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:02 --> Controller Class Initialized
INFO - 2025-01-17 11:18:02 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:02 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:18:02 --> Final output sent to browser
DEBUG - 2025-01-17 11:18:02 --> Total execution time: 0.0417
INFO - 2025-01-17 05:48:07 --> Config Class Initialized
INFO - 2025-01-17 05:48:07 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:07 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:07 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:07 --> URI Class Initialized
INFO - 2025-01-17 05:48:07 --> Router Class Initialized
INFO - 2025-01-17 05:48:07 --> Output Class Initialized
INFO - 2025-01-17 05:48:07 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:07 --> Input Class Initialized
INFO - 2025-01-17 05:48:07 --> Language Class Initialized
INFO - 2025-01-17 05:48:07 --> Loader Class Initialized
INFO - 2025-01-17 05:48:07 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:07 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:07 --> Upload Class Initialized
INFO - 2025-01-17 05:48:07 --> Email Class Initialized
INFO - 2025-01-17 05:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:07 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:07 --> Controller Class Initialized
INFO - 2025-01-17 11:18:07 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:18:07 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:18:07 --> Pagination Class Initialized
INFO - 2025-01-17 05:48:07 --> Config Class Initialized
INFO - 2025-01-17 05:48:07 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:07 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:07 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:07 --> URI Class Initialized
DEBUG - 2025-01-17 05:48:07 --> No URI present. Default controller set.
INFO - 2025-01-17 05:48:07 --> Router Class Initialized
INFO - 2025-01-17 05:48:07 --> Output Class Initialized
INFO - 2025-01-17 05:48:07 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:07 --> Input Class Initialized
INFO - 2025-01-17 05:48:07 --> Language Class Initialized
INFO - 2025-01-17 05:48:07 --> Loader Class Initialized
INFO - 2025-01-17 05:48:07 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:07 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:07 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:07 --> Upload Class Initialized
INFO - 2025-01-17 05:48:07 --> Email Class Initialized
INFO - 2025-01-17 05:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:07 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:07 --> Controller Class Initialized
INFO - 2025-01-17 11:18:07 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:07 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:18:07 --> Final output sent to browser
DEBUG - 2025-01-17 11:18:07 --> Total execution time: 0.0258
INFO - 2025-01-17 05:48:12 --> Config Class Initialized
INFO - 2025-01-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:12 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:12 --> URI Class Initialized
INFO - 2025-01-17 05:48:12 --> Router Class Initialized
INFO - 2025-01-17 05:48:12 --> Output Class Initialized
INFO - 2025-01-17 05:48:12 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:12 --> Input Class Initialized
INFO - 2025-01-17 05:48:12 --> Language Class Initialized
INFO - 2025-01-17 05:48:12 --> Loader Class Initialized
INFO - 2025-01-17 05:48:12 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:12 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:12 --> Upload Class Initialized
INFO - 2025-01-17 05:48:12 --> Email Class Initialized
INFO - 2025-01-17 05:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:12 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:12 --> Controller Class Initialized
INFO - 2025-01-17 11:18:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:18:12 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:18:12 --> Pagination Class Initialized
INFO - 2025-01-17 05:48:12 --> Config Class Initialized
INFO - 2025-01-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:12 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:12 --> URI Class Initialized
DEBUG - 2025-01-17 05:48:12 --> No URI present. Default controller set.
INFO - 2025-01-17 05:48:12 --> Router Class Initialized
INFO - 2025-01-17 05:48:12 --> Output Class Initialized
INFO - 2025-01-17 05:48:12 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:12 --> Input Class Initialized
INFO - 2025-01-17 05:48:12 --> Language Class Initialized
INFO - 2025-01-17 05:48:12 --> Loader Class Initialized
INFO - 2025-01-17 05:48:12 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:12 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:12 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:12 --> Upload Class Initialized
INFO - 2025-01-17 05:48:12 --> Email Class Initialized
INFO - 2025-01-17 05:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:12 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:12 --> Controller Class Initialized
INFO - 2025-01-17 11:18:12 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:12 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:18:12 --> Final output sent to browser
DEBUG - 2025-01-17 11:18:12 --> Total execution time: 0.0429
INFO - 2025-01-17 05:48:35 --> Config Class Initialized
INFO - 2025-01-17 05:48:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:35 --> URI Class Initialized
INFO - 2025-01-17 05:48:35 --> Router Class Initialized
INFO - 2025-01-17 05:48:35 --> Output Class Initialized
INFO - 2025-01-17 05:48:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:35 --> Input Class Initialized
INFO - 2025-01-17 05:48:35 --> Language Class Initialized
INFO - 2025-01-17 05:48:35 --> Loader Class Initialized
INFO - 2025-01-17 05:48:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:35 --> Upload Class Initialized
INFO - 2025-01-17 05:48:35 --> Email Class Initialized
INFO - 2025-01-17 05:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:35 --> Controller Class Initialized
INFO - 2025-01-17 11:18:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:18:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:18:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:48:35 --> Config Class Initialized
INFO - 2025-01-17 05:48:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:48:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:48:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:48:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:48:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:48:35 --> Router Class Initialized
INFO - 2025-01-17 05:48:35 --> Output Class Initialized
INFO - 2025-01-17 05:48:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:48:35 --> Input Class Initialized
INFO - 2025-01-17 05:48:35 --> Language Class Initialized
INFO - 2025-01-17 05:48:35 --> Loader Class Initialized
INFO - 2025-01-17 05:48:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:48:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:48:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:48:35 --> Upload Class Initialized
INFO - 2025-01-17 05:48:35 --> Email Class Initialized
INFO - 2025-01-17 05:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:48:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:48:35 --> Controller Class Initialized
INFO - 2025-01-17 11:18:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:18:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:18:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:18:35 --> Total execution time: 0.0224
INFO - 2025-01-17 05:49:35 --> Config Class Initialized
INFO - 2025-01-17 05:49:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:49:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:49:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:49:35 --> URI Class Initialized
INFO - 2025-01-17 05:49:35 --> Router Class Initialized
INFO - 2025-01-17 05:49:35 --> Output Class Initialized
INFO - 2025-01-17 05:49:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:49:35 --> Input Class Initialized
INFO - 2025-01-17 05:49:35 --> Language Class Initialized
INFO - 2025-01-17 05:49:35 --> Loader Class Initialized
INFO - 2025-01-17 05:49:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:49:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:49:35 --> Upload Class Initialized
INFO - 2025-01-17 05:49:35 --> Email Class Initialized
INFO - 2025-01-17 05:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:49:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:49:35 --> Controller Class Initialized
INFO - 2025-01-17 11:19:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:19:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:19:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:49:35 --> Config Class Initialized
INFO - 2025-01-17 05:49:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:49:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:49:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:49:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:49:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:49:35 --> Router Class Initialized
INFO - 2025-01-17 05:49:35 --> Output Class Initialized
INFO - 2025-01-17 05:49:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:49:35 --> Input Class Initialized
INFO - 2025-01-17 05:49:35 --> Language Class Initialized
INFO - 2025-01-17 05:49:35 --> Loader Class Initialized
INFO - 2025-01-17 05:49:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:49:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:49:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:49:35 --> Upload Class Initialized
INFO - 2025-01-17 05:49:35 --> Email Class Initialized
INFO - 2025-01-17 05:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:49:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:49:35 --> Controller Class Initialized
INFO - 2025-01-17 11:19:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:19:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:19:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:19:35 --> Total execution time: 0.0240
INFO - 2025-01-17 05:50:35 --> Config Class Initialized
INFO - 2025-01-17 05:50:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:50:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:50:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:50:35 --> URI Class Initialized
INFO - 2025-01-17 05:50:35 --> Router Class Initialized
INFO - 2025-01-17 05:50:35 --> Output Class Initialized
INFO - 2025-01-17 05:50:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:50:35 --> Input Class Initialized
INFO - 2025-01-17 05:50:35 --> Language Class Initialized
INFO - 2025-01-17 05:50:35 --> Loader Class Initialized
INFO - 2025-01-17 05:50:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:50:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:50:35 --> Upload Class Initialized
INFO - 2025-01-17 05:50:35 --> Email Class Initialized
INFO - 2025-01-17 05:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:50:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:50:35 --> Controller Class Initialized
INFO - 2025-01-17 11:20:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:20:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:20:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:50:35 --> Config Class Initialized
INFO - 2025-01-17 05:50:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:50:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:50:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:50:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:50:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:50:35 --> Router Class Initialized
INFO - 2025-01-17 05:50:35 --> Output Class Initialized
INFO - 2025-01-17 05:50:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:50:35 --> Input Class Initialized
INFO - 2025-01-17 05:50:35 --> Language Class Initialized
INFO - 2025-01-17 05:50:35 --> Loader Class Initialized
INFO - 2025-01-17 05:50:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:50:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:50:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:50:35 --> Upload Class Initialized
INFO - 2025-01-17 05:50:35 --> Email Class Initialized
INFO - 2025-01-17 05:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:50:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:50:35 --> Controller Class Initialized
INFO - 2025-01-17 11:20:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:20:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:20:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:20:35 --> Total execution time: 0.0437
INFO - 2025-01-17 05:51:35 --> Config Class Initialized
INFO - 2025-01-17 05:51:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:51:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:51:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:51:35 --> URI Class Initialized
INFO - 2025-01-17 05:51:35 --> Router Class Initialized
INFO - 2025-01-17 05:51:35 --> Output Class Initialized
INFO - 2025-01-17 05:51:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:51:35 --> Input Class Initialized
INFO - 2025-01-17 05:51:35 --> Language Class Initialized
INFO - 2025-01-17 05:51:35 --> Loader Class Initialized
INFO - 2025-01-17 05:51:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:51:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:51:35 --> Upload Class Initialized
INFO - 2025-01-17 05:51:35 --> Email Class Initialized
INFO - 2025-01-17 05:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:51:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:51:35 --> Controller Class Initialized
INFO - 2025-01-17 11:21:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:21:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:21:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:51:35 --> Config Class Initialized
INFO - 2025-01-17 05:51:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:51:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:51:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:51:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:51:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:51:35 --> Router Class Initialized
INFO - 2025-01-17 05:51:35 --> Output Class Initialized
INFO - 2025-01-17 05:51:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:51:35 --> Input Class Initialized
INFO - 2025-01-17 05:51:35 --> Language Class Initialized
INFO - 2025-01-17 05:51:35 --> Loader Class Initialized
INFO - 2025-01-17 05:51:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:51:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:51:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:51:35 --> Upload Class Initialized
INFO - 2025-01-17 05:51:35 --> Email Class Initialized
INFO - 2025-01-17 05:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:51:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:51:35 --> Controller Class Initialized
INFO - 2025-01-17 11:21:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:21:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:21:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:21:35 --> Total execution time: 0.0312
INFO - 2025-01-17 05:52:35 --> Config Class Initialized
INFO - 2025-01-17 05:52:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:52:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:52:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:52:35 --> URI Class Initialized
INFO - 2025-01-17 05:52:35 --> Router Class Initialized
INFO - 2025-01-17 05:52:35 --> Output Class Initialized
INFO - 2025-01-17 05:52:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:52:35 --> Input Class Initialized
INFO - 2025-01-17 05:52:35 --> Language Class Initialized
INFO - 2025-01-17 05:52:35 --> Loader Class Initialized
INFO - 2025-01-17 05:52:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:52:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:52:35 --> Upload Class Initialized
INFO - 2025-01-17 05:52:35 --> Email Class Initialized
INFO - 2025-01-17 05:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:52:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:52:35 --> Controller Class Initialized
INFO - 2025-01-17 11:22:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:22:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:22:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:52:35 --> Config Class Initialized
INFO - 2025-01-17 05:52:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:52:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:52:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:52:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:52:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:52:35 --> Router Class Initialized
INFO - 2025-01-17 05:52:35 --> Output Class Initialized
INFO - 2025-01-17 05:52:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:52:35 --> Input Class Initialized
INFO - 2025-01-17 05:52:35 --> Language Class Initialized
INFO - 2025-01-17 05:52:35 --> Loader Class Initialized
INFO - 2025-01-17 05:52:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:52:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:52:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:52:35 --> Upload Class Initialized
INFO - 2025-01-17 05:52:35 --> Email Class Initialized
INFO - 2025-01-17 05:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:52:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:52:35 --> Controller Class Initialized
INFO - 2025-01-17 11:22:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:22:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:22:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:22:35 --> Total execution time: 0.0289
INFO - 2025-01-17 05:53:35 --> Config Class Initialized
INFO - 2025-01-17 05:53:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:53:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:53:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:53:35 --> URI Class Initialized
INFO - 2025-01-17 05:53:35 --> Router Class Initialized
INFO - 2025-01-17 05:53:35 --> Output Class Initialized
INFO - 2025-01-17 05:53:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:53:35 --> Input Class Initialized
INFO - 2025-01-17 05:53:35 --> Language Class Initialized
INFO - 2025-01-17 05:53:35 --> Loader Class Initialized
INFO - 2025-01-17 05:53:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:53:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:53:35 --> Upload Class Initialized
INFO - 2025-01-17 05:53:35 --> Email Class Initialized
INFO - 2025-01-17 05:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:53:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:53:35 --> Controller Class Initialized
INFO - 2025-01-17 11:23:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:23:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:23:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:53:35 --> Config Class Initialized
INFO - 2025-01-17 05:53:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:53:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:53:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:53:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:53:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:53:35 --> Router Class Initialized
INFO - 2025-01-17 05:53:35 --> Output Class Initialized
INFO - 2025-01-17 05:53:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:53:35 --> Input Class Initialized
INFO - 2025-01-17 05:53:35 --> Language Class Initialized
INFO - 2025-01-17 05:53:35 --> Loader Class Initialized
INFO - 2025-01-17 05:53:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:53:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:53:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:53:35 --> Upload Class Initialized
INFO - 2025-01-17 05:53:35 --> Email Class Initialized
INFO - 2025-01-17 05:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:53:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:53:35 --> Controller Class Initialized
INFO - 2025-01-17 11:23:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:23:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:23:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:23:35 --> Total execution time: 0.0224
INFO - 2025-01-17 05:54:35 --> Config Class Initialized
INFO - 2025-01-17 05:54:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:54:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:54:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:54:35 --> URI Class Initialized
INFO - 2025-01-17 05:54:35 --> Router Class Initialized
INFO - 2025-01-17 05:54:35 --> Output Class Initialized
INFO - 2025-01-17 05:54:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:54:35 --> Input Class Initialized
INFO - 2025-01-17 05:54:35 --> Language Class Initialized
INFO - 2025-01-17 05:54:35 --> Loader Class Initialized
INFO - 2025-01-17 05:54:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:54:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:54:35 --> Upload Class Initialized
INFO - 2025-01-17 05:54:35 --> Email Class Initialized
INFO - 2025-01-17 05:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:54:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:54:35 --> Controller Class Initialized
INFO - 2025-01-17 11:24:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:24:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:24:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:54:35 --> Config Class Initialized
INFO - 2025-01-17 05:54:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:54:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:54:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:54:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:54:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:54:35 --> Router Class Initialized
INFO - 2025-01-17 05:54:35 --> Output Class Initialized
INFO - 2025-01-17 05:54:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:54:35 --> Input Class Initialized
INFO - 2025-01-17 05:54:35 --> Language Class Initialized
INFO - 2025-01-17 05:54:35 --> Loader Class Initialized
INFO - 2025-01-17 05:54:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:54:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:54:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:54:35 --> Upload Class Initialized
INFO - 2025-01-17 05:54:35 --> Email Class Initialized
INFO - 2025-01-17 05:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:54:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:54:35 --> Controller Class Initialized
INFO - 2025-01-17 11:24:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:24:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:24:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:24:35 --> Total execution time: 0.0244
INFO - 2025-01-17 05:55:35 --> Config Class Initialized
INFO - 2025-01-17 05:55:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:55:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:55:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:55:35 --> URI Class Initialized
INFO - 2025-01-17 05:55:35 --> Router Class Initialized
INFO - 2025-01-17 05:55:35 --> Output Class Initialized
INFO - 2025-01-17 05:55:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:55:35 --> Input Class Initialized
INFO - 2025-01-17 05:55:35 --> Language Class Initialized
INFO - 2025-01-17 05:55:35 --> Loader Class Initialized
INFO - 2025-01-17 05:55:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:55:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:55:35 --> Upload Class Initialized
INFO - 2025-01-17 05:55:35 --> Email Class Initialized
INFO - 2025-01-17 05:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:55:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:55:35 --> Controller Class Initialized
INFO - 2025-01-17 11:25:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:25:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:25:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:55:35 --> Config Class Initialized
INFO - 2025-01-17 05:55:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:55:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:55:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:55:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:55:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:55:35 --> Router Class Initialized
INFO - 2025-01-17 05:55:35 --> Output Class Initialized
INFO - 2025-01-17 05:55:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:55:35 --> Input Class Initialized
INFO - 2025-01-17 05:55:35 --> Language Class Initialized
INFO - 2025-01-17 05:55:35 --> Loader Class Initialized
INFO - 2025-01-17 05:55:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:55:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:55:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:55:35 --> Upload Class Initialized
INFO - 2025-01-17 05:55:35 --> Email Class Initialized
INFO - 2025-01-17 05:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:55:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:55:35 --> Controller Class Initialized
INFO - 2025-01-17 11:25:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:25:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:25:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:25:35 --> Total execution time: 0.0324
INFO - 2025-01-17 05:56:35 --> Config Class Initialized
INFO - 2025-01-17 05:56:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:56:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:56:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:56:35 --> URI Class Initialized
INFO - 2025-01-17 05:56:35 --> Router Class Initialized
INFO - 2025-01-17 05:56:35 --> Output Class Initialized
INFO - 2025-01-17 05:56:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:56:35 --> Input Class Initialized
INFO - 2025-01-17 05:56:35 --> Language Class Initialized
INFO - 2025-01-17 05:56:35 --> Loader Class Initialized
INFO - 2025-01-17 05:56:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:56:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:56:35 --> Upload Class Initialized
INFO - 2025-01-17 05:56:35 --> Email Class Initialized
INFO - 2025-01-17 05:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:56:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:56:35 --> Controller Class Initialized
INFO - 2025-01-17 11:26:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:26:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:26:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:56:35 --> Config Class Initialized
INFO - 2025-01-17 05:56:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:56:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:56:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:56:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:56:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:56:35 --> Router Class Initialized
INFO - 2025-01-17 05:56:35 --> Output Class Initialized
INFO - 2025-01-17 05:56:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:56:35 --> Input Class Initialized
INFO - 2025-01-17 05:56:35 --> Language Class Initialized
INFO - 2025-01-17 05:56:35 --> Loader Class Initialized
INFO - 2025-01-17 05:56:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:56:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:56:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:56:35 --> Upload Class Initialized
INFO - 2025-01-17 05:56:35 --> Email Class Initialized
INFO - 2025-01-17 05:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:56:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:56:35 --> Controller Class Initialized
INFO - 2025-01-17 11:26:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:26:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:26:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:26:35 --> Total execution time: 0.0384
INFO - 2025-01-17 05:57:35 --> Config Class Initialized
INFO - 2025-01-17 05:57:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:57:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:57:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:57:35 --> URI Class Initialized
INFO - 2025-01-17 05:57:35 --> Router Class Initialized
INFO - 2025-01-17 05:57:35 --> Output Class Initialized
INFO - 2025-01-17 05:57:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:57:35 --> Input Class Initialized
INFO - 2025-01-17 05:57:35 --> Language Class Initialized
INFO - 2025-01-17 05:57:35 --> Loader Class Initialized
INFO - 2025-01-17 05:57:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:57:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:57:35 --> Upload Class Initialized
INFO - 2025-01-17 05:57:35 --> Email Class Initialized
INFO - 2025-01-17 05:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:57:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:57:35 --> Controller Class Initialized
INFO - 2025-01-17 11:27:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:27:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:27:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:57:35 --> Config Class Initialized
INFO - 2025-01-17 05:57:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:57:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:57:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:57:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:57:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:57:35 --> Router Class Initialized
INFO - 2025-01-17 05:57:35 --> Output Class Initialized
INFO - 2025-01-17 05:57:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:57:35 --> Input Class Initialized
INFO - 2025-01-17 05:57:35 --> Language Class Initialized
INFO - 2025-01-17 05:57:35 --> Loader Class Initialized
INFO - 2025-01-17 05:57:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:57:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:57:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:57:35 --> Upload Class Initialized
INFO - 2025-01-17 05:57:35 --> Email Class Initialized
INFO - 2025-01-17 05:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:57:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:57:35 --> Controller Class Initialized
INFO - 2025-01-17 11:27:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:27:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:27:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:27:35 --> Total execution time: 0.0288
INFO - 2025-01-17 05:58:35 --> Config Class Initialized
INFO - 2025-01-17 05:58:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:58:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:58:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:58:35 --> URI Class Initialized
INFO - 2025-01-17 05:58:35 --> Router Class Initialized
INFO - 2025-01-17 05:58:35 --> Output Class Initialized
INFO - 2025-01-17 05:58:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:58:35 --> Input Class Initialized
INFO - 2025-01-17 05:58:35 --> Language Class Initialized
INFO - 2025-01-17 05:58:35 --> Loader Class Initialized
INFO - 2025-01-17 05:58:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:58:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:58:35 --> Upload Class Initialized
INFO - 2025-01-17 05:58:35 --> Email Class Initialized
INFO - 2025-01-17 05:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:58:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:58:35 --> Controller Class Initialized
INFO - 2025-01-17 11:28:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:28:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:28:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:58:35 --> Config Class Initialized
INFO - 2025-01-17 05:58:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:58:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:58:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:58:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:58:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:58:35 --> Router Class Initialized
INFO - 2025-01-17 05:58:35 --> Output Class Initialized
INFO - 2025-01-17 05:58:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:58:35 --> Input Class Initialized
INFO - 2025-01-17 05:58:35 --> Language Class Initialized
INFO - 2025-01-17 05:58:35 --> Loader Class Initialized
INFO - 2025-01-17 05:58:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:58:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:58:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:58:35 --> Upload Class Initialized
INFO - 2025-01-17 05:58:35 --> Email Class Initialized
INFO - 2025-01-17 05:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:58:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:58:35 --> Controller Class Initialized
INFO - 2025-01-17 11:28:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:28:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:28:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:28:35 --> Total execution time: 0.0537
INFO - 2025-01-17 05:59:35 --> Config Class Initialized
INFO - 2025-01-17 05:59:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:59:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:59:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:59:35 --> URI Class Initialized
INFO - 2025-01-17 05:59:35 --> Router Class Initialized
INFO - 2025-01-17 05:59:35 --> Output Class Initialized
INFO - 2025-01-17 05:59:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:59:35 --> Input Class Initialized
INFO - 2025-01-17 05:59:35 --> Language Class Initialized
INFO - 2025-01-17 05:59:35 --> Loader Class Initialized
INFO - 2025-01-17 05:59:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:59:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:59:35 --> Upload Class Initialized
INFO - 2025-01-17 05:59:35 --> Email Class Initialized
INFO - 2025-01-17 05:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:59:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:59:35 --> Controller Class Initialized
INFO - 2025-01-17 11:29:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:29:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:29:35 --> Pagination Class Initialized
INFO - 2025-01-17 05:59:35 --> Config Class Initialized
INFO - 2025-01-17 05:59:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 05:59:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 05:59:35 --> Utf8 Class Initialized
INFO - 2025-01-17 05:59:35 --> URI Class Initialized
DEBUG - 2025-01-17 05:59:35 --> No URI present. Default controller set.
INFO - 2025-01-17 05:59:35 --> Router Class Initialized
INFO - 2025-01-17 05:59:35 --> Output Class Initialized
INFO - 2025-01-17 05:59:35 --> Security Class Initialized
DEBUG - 2025-01-17 05:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 05:59:35 --> Input Class Initialized
INFO - 2025-01-17 05:59:35 --> Language Class Initialized
INFO - 2025-01-17 05:59:35 --> Loader Class Initialized
INFO - 2025-01-17 05:59:35 --> Helper loaded: url_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: html_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: file_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: string_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: form_helper
INFO - 2025-01-17 05:59:35 --> Helper loaded: my_helper
INFO - 2025-01-17 05:59:35 --> Database Driver Class Initialized
INFO - 2025-01-17 05:59:35 --> Upload Class Initialized
INFO - 2025-01-17 05:59:35 --> Email Class Initialized
INFO - 2025-01-17 05:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 05:59:35 --> Form Validation Class Initialized
INFO - 2025-01-17 05:59:35 --> Controller Class Initialized
INFO - 2025-01-17 11:29:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:29:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:29:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:29:35 --> Total execution time: 0.0351
INFO - 2025-01-17 06:00:35 --> Config Class Initialized
INFO - 2025-01-17 06:00:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:00:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:00:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:00:35 --> URI Class Initialized
INFO - 2025-01-17 06:00:35 --> Router Class Initialized
INFO - 2025-01-17 06:00:35 --> Output Class Initialized
INFO - 2025-01-17 06:00:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:00:35 --> Input Class Initialized
INFO - 2025-01-17 06:00:35 --> Language Class Initialized
INFO - 2025-01-17 06:00:35 --> Loader Class Initialized
INFO - 2025-01-17 06:00:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:00:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:00:35 --> Upload Class Initialized
INFO - 2025-01-17 06:00:35 --> Email Class Initialized
INFO - 2025-01-17 06:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:00:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:00:35 --> Controller Class Initialized
INFO - 2025-01-17 11:30:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:30:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:30:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:00:35 --> Config Class Initialized
INFO - 2025-01-17 06:00:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:00:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:00:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:00:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:00:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:00:35 --> Router Class Initialized
INFO - 2025-01-17 06:00:35 --> Output Class Initialized
INFO - 2025-01-17 06:00:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:00:35 --> Input Class Initialized
INFO - 2025-01-17 06:00:35 --> Language Class Initialized
INFO - 2025-01-17 06:00:35 --> Loader Class Initialized
INFO - 2025-01-17 06:00:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:00:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:00:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:00:35 --> Upload Class Initialized
INFO - 2025-01-17 06:00:35 --> Email Class Initialized
INFO - 2025-01-17 06:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:00:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:00:35 --> Controller Class Initialized
INFO - 2025-01-17 11:30:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:30:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:30:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:30:35 --> Total execution time: 0.0355
INFO - 2025-01-17 06:01:35 --> Config Class Initialized
INFO - 2025-01-17 06:01:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:01:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:01:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:01:35 --> URI Class Initialized
INFO - 2025-01-17 06:01:35 --> Router Class Initialized
INFO - 2025-01-17 06:01:35 --> Output Class Initialized
INFO - 2025-01-17 06:01:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:01:35 --> Input Class Initialized
INFO - 2025-01-17 06:01:35 --> Language Class Initialized
INFO - 2025-01-17 06:01:35 --> Loader Class Initialized
INFO - 2025-01-17 06:01:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:01:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:01:35 --> Upload Class Initialized
INFO - 2025-01-17 06:01:35 --> Email Class Initialized
INFO - 2025-01-17 06:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:01:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:01:35 --> Controller Class Initialized
INFO - 2025-01-17 11:31:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:31:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:31:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:01:35 --> Config Class Initialized
INFO - 2025-01-17 06:01:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:01:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:01:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:01:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:01:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:01:35 --> Router Class Initialized
INFO - 2025-01-17 06:01:35 --> Output Class Initialized
INFO - 2025-01-17 06:01:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:01:35 --> Input Class Initialized
INFO - 2025-01-17 06:01:35 --> Language Class Initialized
INFO - 2025-01-17 06:01:35 --> Loader Class Initialized
INFO - 2025-01-17 06:01:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:01:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:01:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:01:35 --> Upload Class Initialized
INFO - 2025-01-17 06:01:35 --> Email Class Initialized
INFO - 2025-01-17 06:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:01:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:01:35 --> Controller Class Initialized
INFO - 2025-01-17 11:31:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:31:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:31:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:31:35 --> Total execution time: 0.0374
INFO - 2025-01-17 06:02:35 --> Config Class Initialized
INFO - 2025-01-17 06:02:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:02:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:02:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:02:35 --> URI Class Initialized
INFO - 2025-01-17 06:02:35 --> Router Class Initialized
INFO - 2025-01-17 06:02:35 --> Output Class Initialized
INFO - 2025-01-17 06:02:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:02:35 --> Input Class Initialized
INFO - 2025-01-17 06:02:35 --> Language Class Initialized
INFO - 2025-01-17 06:02:35 --> Loader Class Initialized
INFO - 2025-01-17 06:02:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:02:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:02:35 --> Upload Class Initialized
INFO - 2025-01-17 06:02:35 --> Email Class Initialized
INFO - 2025-01-17 06:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:02:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:02:35 --> Controller Class Initialized
INFO - 2025-01-17 11:32:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:32:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:32:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:02:35 --> Config Class Initialized
INFO - 2025-01-17 06:02:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:02:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:02:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:02:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:02:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:02:35 --> Router Class Initialized
INFO - 2025-01-17 06:02:35 --> Output Class Initialized
INFO - 2025-01-17 06:02:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:02:35 --> Input Class Initialized
INFO - 2025-01-17 06:02:35 --> Language Class Initialized
INFO - 2025-01-17 06:02:35 --> Loader Class Initialized
INFO - 2025-01-17 06:02:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:02:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:02:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:02:35 --> Upload Class Initialized
INFO - 2025-01-17 06:02:35 --> Email Class Initialized
INFO - 2025-01-17 06:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:02:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:02:35 --> Controller Class Initialized
INFO - 2025-01-17 11:32:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:32:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:32:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:32:35 --> Total execution time: 0.0229
INFO - 2025-01-17 06:09:52 --> Config Class Initialized
INFO - 2025-01-17 06:09:52 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:09:52 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:09:52 --> Utf8 Class Initialized
INFO - 2025-01-17 06:09:52 --> URI Class Initialized
INFO - 2025-01-17 06:09:52 --> Router Class Initialized
INFO - 2025-01-17 06:09:52 --> Output Class Initialized
INFO - 2025-01-17 06:09:52 --> Security Class Initialized
DEBUG - 2025-01-17 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:09:52 --> Input Class Initialized
INFO - 2025-01-17 06:09:52 --> Language Class Initialized
INFO - 2025-01-17 06:09:52 --> Loader Class Initialized
INFO - 2025-01-17 06:09:52 --> Helper loaded: url_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: html_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: file_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: string_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: form_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: my_helper
INFO - 2025-01-17 06:09:52 --> Database Driver Class Initialized
INFO - 2025-01-17 06:09:52 --> Upload Class Initialized
INFO - 2025-01-17 06:09:52 --> Email Class Initialized
INFO - 2025-01-17 06:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:09:52 --> Form Validation Class Initialized
INFO - 2025-01-17 06:09:52 --> Controller Class Initialized
INFO - 2025-01-17 11:39:52 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:39:52 --> Model "MainModel" initialized
INFO - 2025-01-17 11:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:39:52 --> Pagination Class Initialized
INFO - 2025-01-17 06:09:52 --> Config Class Initialized
INFO - 2025-01-17 06:09:52 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:09:52 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:09:52 --> Utf8 Class Initialized
INFO - 2025-01-17 06:09:52 --> URI Class Initialized
DEBUG - 2025-01-17 06:09:52 --> No URI present. Default controller set.
INFO - 2025-01-17 06:09:52 --> Router Class Initialized
INFO - 2025-01-17 06:09:52 --> Output Class Initialized
INFO - 2025-01-17 06:09:52 --> Security Class Initialized
DEBUG - 2025-01-17 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:09:52 --> Input Class Initialized
INFO - 2025-01-17 06:09:52 --> Language Class Initialized
INFO - 2025-01-17 06:09:52 --> Loader Class Initialized
INFO - 2025-01-17 06:09:52 --> Helper loaded: url_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: html_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: file_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: string_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: form_helper
INFO - 2025-01-17 06:09:52 --> Helper loaded: my_helper
INFO - 2025-01-17 06:09:52 --> Database Driver Class Initialized
INFO - 2025-01-17 06:09:52 --> Upload Class Initialized
INFO - 2025-01-17 06:09:52 --> Email Class Initialized
INFO - 2025-01-17 06:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:09:52 --> Form Validation Class Initialized
INFO - 2025-01-17 06:09:52 --> Controller Class Initialized
INFO - 2025-01-17 11:39:52 --> Model "MainModel" initialized
INFO - 2025-01-17 11:39:52 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:39:52 --> Final output sent to browser
DEBUG - 2025-01-17 11:39:52 --> Total execution time: 0.0264
INFO - 2025-01-17 06:10:35 --> Config Class Initialized
INFO - 2025-01-17 06:10:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:10:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:10:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:10:35 --> URI Class Initialized
INFO - 2025-01-17 06:10:35 --> Router Class Initialized
INFO - 2025-01-17 06:10:35 --> Output Class Initialized
INFO - 2025-01-17 06:10:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:10:35 --> Input Class Initialized
INFO - 2025-01-17 06:10:35 --> Language Class Initialized
INFO - 2025-01-17 06:10:35 --> Loader Class Initialized
INFO - 2025-01-17 06:10:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:10:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:10:35 --> Upload Class Initialized
INFO - 2025-01-17 06:10:35 --> Email Class Initialized
INFO - 2025-01-17 06:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:10:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:10:35 --> Controller Class Initialized
INFO - 2025-01-17 11:40:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:40:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:40:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:10:35 --> Config Class Initialized
INFO - 2025-01-17 06:10:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:10:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:10:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:10:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:10:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:10:35 --> Router Class Initialized
INFO - 2025-01-17 06:10:35 --> Output Class Initialized
INFO - 2025-01-17 06:10:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:10:35 --> Input Class Initialized
INFO - 2025-01-17 06:10:35 --> Language Class Initialized
INFO - 2025-01-17 06:10:35 --> Loader Class Initialized
INFO - 2025-01-17 06:10:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:10:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:10:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:10:35 --> Upload Class Initialized
INFO - 2025-01-17 06:10:35 --> Email Class Initialized
INFO - 2025-01-17 06:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:10:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:10:35 --> Controller Class Initialized
INFO - 2025-01-17 11:40:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:40:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:40:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:40:35 --> Total execution time: 0.0262
INFO - 2025-01-17 06:11:35 --> Config Class Initialized
INFO - 2025-01-17 06:11:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:11:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:11:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:11:35 --> URI Class Initialized
INFO - 2025-01-17 06:11:35 --> Router Class Initialized
INFO - 2025-01-17 06:11:35 --> Output Class Initialized
INFO - 2025-01-17 06:11:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:11:35 --> Input Class Initialized
INFO - 2025-01-17 06:11:35 --> Language Class Initialized
INFO - 2025-01-17 06:11:35 --> Loader Class Initialized
INFO - 2025-01-17 06:11:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:11:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:11:35 --> Upload Class Initialized
INFO - 2025-01-17 06:11:35 --> Email Class Initialized
INFO - 2025-01-17 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:11:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:11:35 --> Controller Class Initialized
INFO - 2025-01-17 11:41:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:41:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:41:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:11:35 --> Config Class Initialized
INFO - 2025-01-17 06:11:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:11:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:11:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:11:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:11:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:11:35 --> Router Class Initialized
INFO - 2025-01-17 06:11:35 --> Output Class Initialized
INFO - 2025-01-17 06:11:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:11:35 --> Input Class Initialized
INFO - 2025-01-17 06:11:35 --> Language Class Initialized
INFO - 2025-01-17 06:11:35 --> Loader Class Initialized
INFO - 2025-01-17 06:11:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:11:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:11:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:11:35 --> Upload Class Initialized
INFO - 2025-01-17 06:11:35 --> Email Class Initialized
INFO - 2025-01-17 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:11:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:11:35 --> Controller Class Initialized
INFO - 2025-01-17 11:41:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:41:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:41:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:41:35 --> Total execution time: 0.0449
INFO - 2025-01-17 06:12:35 --> Config Class Initialized
INFO - 2025-01-17 06:12:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:12:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:12:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:12:35 --> URI Class Initialized
INFO - 2025-01-17 06:12:35 --> Router Class Initialized
INFO - 2025-01-17 06:12:35 --> Output Class Initialized
INFO - 2025-01-17 06:12:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:12:35 --> Input Class Initialized
INFO - 2025-01-17 06:12:35 --> Language Class Initialized
INFO - 2025-01-17 06:12:35 --> Loader Class Initialized
INFO - 2025-01-17 06:12:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:12:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:12:35 --> Upload Class Initialized
INFO - 2025-01-17 06:12:35 --> Email Class Initialized
INFO - 2025-01-17 06:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:12:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:12:35 --> Controller Class Initialized
INFO - 2025-01-17 11:42:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:42:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:42:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:12:35 --> Config Class Initialized
INFO - 2025-01-17 06:12:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:12:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:12:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:12:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:12:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:12:35 --> Router Class Initialized
INFO - 2025-01-17 06:12:35 --> Output Class Initialized
INFO - 2025-01-17 06:12:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:12:35 --> Input Class Initialized
INFO - 2025-01-17 06:12:35 --> Language Class Initialized
INFO - 2025-01-17 06:12:35 --> Loader Class Initialized
INFO - 2025-01-17 06:12:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:12:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:12:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:12:35 --> Upload Class Initialized
INFO - 2025-01-17 06:12:35 --> Email Class Initialized
INFO - 2025-01-17 06:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:12:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:12:35 --> Controller Class Initialized
INFO - 2025-01-17 11:42:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:42:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:42:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:42:35 --> Total execution time: 0.0240
INFO - 2025-01-17 06:26:35 --> Config Class Initialized
INFO - 2025-01-17 06:26:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:26:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:26:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:26:35 --> URI Class Initialized
INFO - 2025-01-17 06:26:35 --> Router Class Initialized
INFO - 2025-01-17 06:26:35 --> Output Class Initialized
INFO - 2025-01-17 06:26:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:26:35 --> Input Class Initialized
INFO - 2025-01-17 06:26:35 --> Language Class Initialized
INFO - 2025-01-17 06:26:35 --> Loader Class Initialized
INFO - 2025-01-17 06:26:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:26:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:26:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:26:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:26:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:26:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:26:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:26:35 --> Upload Class Initialized
INFO - 2025-01-17 06:26:35 --> Email Class Initialized
INFO - 2025-01-17 06:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:26:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:26:35 --> Controller Class Initialized
INFO - 2025-01-17 11:56:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:56:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:56:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:26:36 --> Config Class Initialized
INFO - 2025-01-17 06:26:36 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:26:36 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:26:36 --> Utf8 Class Initialized
INFO - 2025-01-17 06:26:36 --> URI Class Initialized
DEBUG - 2025-01-17 06:26:36 --> No URI present. Default controller set.
INFO - 2025-01-17 06:26:36 --> Router Class Initialized
INFO - 2025-01-17 06:26:36 --> Output Class Initialized
INFO - 2025-01-17 06:26:36 --> Security Class Initialized
DEBUG - 2025-01-17 06:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:26:36 --> Input Class Initialized
INFO - 2025-01-17 06:26:36 --> Language Class Initialized
INFO - 2025-01-17 06:26:36 --> Loader Class Initialized
INFO - 2025-01-17 06:26:36 --> Helper loaded: url_helper
INFO - 2025-01-17 06:26:36 --> Helper loaded: html_helper
INFO - 2025-01-17 06:26:36 --> Helper loaded: file_helper
INFO - 2025-01-17 06:26:36 --> Helper loaded: string_helper
INFO - 2025-01-17 06:26:36 --> Helper loaded: form_helper
INFO - 2025-01-17 06:26:36 --> Helper loaded: my_helper
INFO - 2025-01-17 06:26:36 --> Database Driver Class Initialized
INFO - 2025-01-17 06:26:36 --> Upload Class Initialized
INFO - 2025-01-17 06:26:36 --> Email Class Initialized
INFO - 2025-01-17 06:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:26:36 --> Form Validation Class Initialized
INFO - 2025-01-17 06:26:36 --> Controller Class Initialized
INFO - 2025-01-17 11:56:36 --> Model "MainModel" initialized
INFO - 2025-01-17 11:56:36 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:56:36 --> Final output sent to browser
DEBUG - 2025-01-17 11:56:36 --> Total execution time: 0.0261
INFO - 2025-01-17 06:27:35 --> Config Class Initialized
INFO - 2025-01-17 06:27:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:27:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:27:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:27:35 --> URI Class Initialized
INFO - 2025-01-17 06:27:35 --> Router Class Initialized
INFO - 2025-01-17 06:27:35 --> Output Class Initialized
INFO - 2025-01-17 06:27:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:27:35 --> Input Class Initialized
INFO - 2025-01-17 06:27:35 --> Language Class Initialized
INFO - 2025-01-17 06:27:35 --> Loader Class Initialized
INFO - 2025-01-17 06:27:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:27:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:27:35 --> Upload Class Initialized
INFO - 2025-01-17 06:27:35 --> Email Class Initialized
INFO - 2025-01-17 06:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:27:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:27:35 --> Controller Class Initialized
INFO - 2025-01-17 11:57:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:57:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:57:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:27:35 --> Config Class Initialized
INFO - 2025-01-17 06:27:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:27:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:27:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:27:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:27:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:27:35 --> Router Class Initialized
INFO - 2025-01-17 06:27:35 --> Output Class Initialized
INFO - 2025-01-17 06:27:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:27:35 --> Input Class Initialized
INFO - 2025-01-17 06:27:35 --> Language Class Initialized
INFO - 2025-01-17 06:27:35 --> Loader Class Initialized
INFO - 2025-01-17 06:27:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:27:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:27:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:27:35 --> Upload Class Initialized
INFO - 2025-01-17 06:27:35 --> Email Class Initialized
INFO - 2025-01-17 06:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:27:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:27:35 --> Controller Class Initialized
INFO - 2025-01-17 11:57:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:57:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:57:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:57:35 --> Total execution time: 0.0272
INFO - 2025-01-17 06:28:35 --> Config Class Initialized
INFO - 2025-01-17 06:28:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:28:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:28:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:28:35 --> URI Class Initialized
INFO - 2025-01-17 06:28:35 --> Router Class Initialized
INFO - 2025-01-17 06:28:35 --> Output Class Initialized
INFO - 2025-01-17 06:28:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:28:35 --> Input Class Initialized
INFO - 2025-01-17 06:28:35 --> Language Class Initialized
INFO - 2025-01-17 06:28:35 --> Loader Class Initialized
INFO - 2025-01-17 06:28:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:28:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:28:35 --> Upload Class Initialized
INFO - 2025-01-17 06:28:35 --> Email Class Initialized
INFO - 2025-01-17 06:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:28:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:28:35 --> Controller Class Initialized
INFO - 2025-01-17 11:58:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:58:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:58:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:28:35 --> Config Class Initialized
INFO - 2025-01-17 06:28:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:28:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:28:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:28:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:28:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:28:35 --> Router Class Initialized
INFO - 2025-01-17 06:28:35 --> Output Class Initialized
INFO - 2025-01-17 06:28:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:28:35 --> Input Class Initialized
INFO - 2025-01-17 06:28:35 --> Language Class Initialized
INFO - 2025-01-17 06:28:35 --> Loader Class Initialized
INFO - 2025-01-17 06:28:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:28:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:28:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:28:35 --> Upload Class Initialized
INFO - 2025-01-17 06:28:35 --> Email Class Initialized
INFO - 2025-01-17 06:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:28:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:28:35 --> Controller Class Initialized
INFO - 2025-01-17 11:58:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:58:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:58:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:58:35 --> Total execution time: 0.0342
INFO - 2025-01-17 06:29:35 --> Config Class Initialized
INFO - 2025-01-17 06:29:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:29:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:29:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:29:35 --> URI Class Initialized
INFO - 2025-01-17 06:29:35 --> Router Class Initialized
INFO - 2025-01-17 06:29:35 --> Output Class Initialized
INFO - 2025-01-17 06:29:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:29:35 --> Input Class Initialized
INFO - 2025-01-17 06:29:35 --> Language Class Initialized
INFO - 2025-01-17 06:29:35 --> Loader Class Initialized
INFO - 2025-01-17 06:29:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:29:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:29:35 --> Upload Class Initialized
INFO - 2025-01-17 06:29:35 --> Email Class Initialized
INFO - 2025-01-17 06:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:29:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:29:35 --> Controller Class Initialized
INFO - 2025-01-17 11:59:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 11:59:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:59:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 11:59:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:29:35 --> Config Class Initialized
INFO - 2025-01-17 06:29:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:29:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:29:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:29:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:29:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:29:35 --> Router Class Initialized
INFO - 2025-01-17 06:29:35 --> Output Class Initialized
INFO - 2025-01-17 06:29:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:29:35 --> Input Class Initialized
INFO - 2025-01-17 06:29:35 --> Language Class Initialized
INFO - 2025-01-17 06:29:35 --> Loader Class Initialized
INFO - 2025-01-17 06:29:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:29:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:29:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:29:35 --> Upload Class Initialized
INFO - 2025-01-17 06:29:35 --> Email Class Initialized
INFO - 2025-01-17 06:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:29:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:29:35 --> Controller Class Initialized
INFO - 2025-01-17 11:59:35 --> Model "MainModel" initialized
INFO - 2025-01-17 11:59:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 11:59:35 --> Final output sent to browser
DEBUG - 2025-01-17 11:59:35 --> Total execution time: 0.0250
INFO - 2025-01-17 06:30:35 --> Config Class Initialized
INFO - 2025-01-17 06:30:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:30:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:30:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:30:35 --> URI Class Initialized
INFO - 2025-01-17 06:30:35 --> Router Class Initialized
INFO - 2025-01-17 06:30:35 --> Output Class Initialized
INFO - 2025-01-17 06:30:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:30:35 --> Input Class Initialized
INFO - 2025-01-17 06:30:35 --> Language Class Initialized
INFO - 2025-01-17 06:30:35 --> Loader Class Initialized
INFO - 2025-01-17 06:30:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:30:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:30:35 --> Upload Class Initialized
INFO - 2025-01-17 06:30:35 --> Email Class Initialized
INFO - 2025-01-17 06:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:30:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:30:35 --> Controller Class Initialized
INFO - 2025-01-17 12:00:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 12:00:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 12:00:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:30:35 --> Config Class Initialized
INFO - 2025-01-17 06:30:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:30:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:30:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:30:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:30:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:30:35 --> Router Class Initialized
INFO - 2025-01-17 06:30:35 --> Output Class Initialized
INFO - 2025-01-17 06:30:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:30:35 --> Input Class Initialized
INFO - 2025-01-17 06:30:35 --> Language Class Initialized
INFO - 2025-01-17 06:30:35 --> Loader Class Initialized
INFO - 2025-01-17 06:30:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:30:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:30:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:30:35 --> Upload Class Initialized
INFO - 2025-01-17 06:30:35 --> Email Class Initialized
INFO - 2025-01-17 06:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:30:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:30:35 --> Controller Class Initialized
INFO - 2025-01-17 12:00:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:00:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 12:00:35 --> Final output sent to browser
DEBUG - 2025-01-17 12:00:35 --> Total execution time: 0.0472
INFO - 2025-01-17 06:31:35 --> Config Class Initialized
INFO - 2025-01-17 06:31:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:31:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:31:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:31:35 --> URI Class Initialized
INFO - 2025-01-17 06:31:35 --> Router Class Initialized
INFO - 2025-01-17 06:31:35 --> Output Class Initialized
INFO - 2025-01-17 06:31:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:31:35 --> Input Class Initialized
INFO - 2025-01-17 06:31:35 --> Language Class Initialized
INFO - 2025-01-17 06:31:35 --> Loader Class Initialized
INFO - 2025-01-17 06:31:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:31:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:31:35 --> Upload Class Initialized
INFO - 2025-01-17 06:31:35 --> Email Class Initialized
INFO - 2025-01-17 06:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:31:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:31:35 --> Controller Class Initialized
INFO - 2025-01-17 12:01:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 12:01:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 12:01:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:31:35 --> Config Class Initialized
INFO - 2025-01-17 06:31:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:31:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:31:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:31:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:31:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:31:35 --> Router Class Initialized
INFO - 2025-01-17 06:31:35 --> Output Class Initialized
INFO - 2025-01-17 06:31:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:31:35 --> Input Class Initialized
INFO - 2025-01-17 06:31:35 --> Language Class Initialized
INFO - 2025-01-17 06:31:35 --> Loader Class Initialized
INFO - 2025-01-17 06:31:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:31:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:31:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:31:35 --> Upload Class Initialized
INFO - 2025-01-17 06:31:35 --> Email Class Initialized
INFO - 2025-01-17 06:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:31:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:31:35 --> Controller Class Initialized
INFO - 2025-01-17 12:01:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:01:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 12:01:35 --> Final output sent to browser
DEBUG - 2025-01-17 12:01:35 --> Total execution time: 0.0248
INFO - 2025-01-17 06:32:35 --> Config Class Initialized
INFO - 2025-01-17 06:32:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:32:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:32:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:32:35 --> URI Class Initialized
INFO - 2025-01-17 06:32:35 --> Router Class Initialized
INFO - 2025-01-17 06:32:35 --> Output Class Initialized
INFO - 2025-01-17 06:32:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:32:35 --> Input Class Initialized
INFO - 2025-01-17 06:32:35 --> Language Class Initialized
INFO - 2025-01-17 06:32:35 --> Loader Class Initialized
INFO - 2025-01-17 06:32:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:32:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:32:35 --> Upload Class Initialized
INFO - 2025-01-17 06:32:35 --> Email Class Initialized
INFO - 2025-01-17 06:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:32:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:32:35 --> Controller Class Initialized
INFO - 2025-01-17 12:02:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 12:02:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 12:02:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:32:35 --> Config Class Initialized
INFO - 2025-01-17 06:32:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:32:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:32:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:32:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:32:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:32:35 --> Router Class Initialized
INFO - 2025-01-17 06:32:35 --> Output Class Initialized
INFO - 2025-01-17 06:32:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:32:35 --> Input Class Initialized
INFO - 2025-01-17 06:32:35 --> Language Class Initialized
INFO - 2025-01-17 06:32:35 --> Loader Class Initialized
INFO - 2025-01-17 06:32:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:32:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:32:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:32:35 --> Upload Class Initialized
INFO - 2025-01-17 06:32:35 --> Email Class Initialized
INFO - 2025-01-17 06:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:32:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:32:35 --> Controller Class Initialized
INFO - 2025-01-17 12:02:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:02:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 12:02:35 --> Final output sent to browser
DEBUG - 2025-01-17 12:02:35 --> Total execution time: 0.0233
INFO - 2025-01-17 06:33:35 --> Config Class Initialized
INFO - 2025-01-17 06:33:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:33:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:33:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:33:35 --> URI Class Initialized
INFO - 2025-01-17 06:33:35 --> Router Class Initialized
INFO - 2025-01-17 06:33:35 --> Output Class Initialized
INFO - 2025-01-17 06:33:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:33:35 --> Input Class Initialized
INFO - 2025-01-17 06:33:35 --> Language Class Initialized
INFO - 2025-01-17 06:33:35 --> Loader Class Initialized
INFO - 2025-01-17 06:33:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:33:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:33:35 --> Upload Class Initialized
INFO - 2025-01-17 06:33:35 --> Email Class Initialized
INFO - 2025-01-17 06:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:33:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:33:35 --> Controller Class Initialized
INFO - 2025-01-17 12:03:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 12:03:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:03:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 12:03:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:33:35 --> Config Class Initialized
INFO - 2025-01-17 06:33:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:33:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:33:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:33:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:33:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:33:35 --> Router Class Initialized
INFO - 2025-01-17 06:33:35 --> Output Class Initialized
INFO - 2025-01-17 06:33:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:33:35 --> Input Class Initialized
INFO - 2025-01-17 06:33:35 --> Language Class Initialized
INFO - 2025-01-17 06:33:35 --> Loader Class Initialized
INFO - 2025-01-17 06:33:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:33:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:33:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:33:35 --> Upload Class Initialized
INFO - 2025-01-17 06:33:35 --> Email Class Initialized
INFO - 2025-01-17 06:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:33:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:33:35 --> Controller Class Initialized
INFO - 2025-01-17 12:03:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:03:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 12:03:35 --> Final output sent to browser
DEBUG - 2025-01-17 12:03:35 --> Total execution time: 0.0380
INFO - 2025-01-17 06:34:35 --> Config Class Initialized
INFO - 2025-01-17 06:34:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:34:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:34:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:34:35 --> URI Class Initialized
INFO - 2025-01-17 06:34:35 --> Router Class Initialized
INFO - 2025-01-17 06:34:35 --> Output Class Initialized
INFO - 2025-01-17 06:34:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:34:35 --> Input Class Initialized
INFO - 2025-01-17 06:34:35 --> Language Class Initialized
INFO - 2025-01-17 06:34:35 --> Loader Class Initialized
INFO - 2025-01-17 06:34:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:34:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:34:35 --> Upload Class Initialized
INFO - 2025-01-17 06:34:35 --> Email Class Initialized
INFO - 2025-01-17 06:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:34:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:34:35 --> Controller Class Initialized
INFO - 2025-01-17 12:04:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 12:04:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 12:04:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:34:35 --> Config Class Initialized
INFO - 2025-01-17 06:34:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:34:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:34:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:34:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:34:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:34:35 --> Router Class Initialized
INFO - 2025-01-17 06:34:35 --> Output Class Initialized
INFO - 2025-01-17 06:34:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:34:35 --> Input Class Initialized
INFO - 2025-01-17 06:34:35 --> Language Class Initialized
INFO - 2025-01-17 06:34:35 --> Loader Class Initialized
INFO - 2025-01-17 06:34:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:34:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:34:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:34:35 --> Upload Class Initialized
INFO - 2025-01-17 06:34:35 --> Email Class Initialized
INFO - 2025-01-17 06:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:34:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:34:35 --> Controller Class Initialized
INFO - 2025-01-17 12:04:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:04:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 12:04:35 --> Final output sent to browser
DEBUG - 2025-01-17 12:04:35 --> Total execution time: 0.0372
INFO - 2025-01-17 06:35:35 --> Config Class Initialized
INFO - 2025-01-17 06:35:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:35:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:35:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:35:35 --> URI Class Initialized
INFO - 2025-01-17 06:35:35 --> Router Class Initialized
INFO - 2025-01-17 06:35:35 --> Output Class Initialized
INFO - 2025-01-17 06:35:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:35:35 --> Input Class Initialized
INFO - 2025-01-17 06:35:35 --> Language Class Initialized
INFO - 2025-01-17 06:35:35 --> Loader Class Initialized
INFO - 2025-01-17 06:35:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:35:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:35:35 --> Upload Class Initialized
INFO - 2025-01-17 06:35:35 --> Email Class Initialized
INFO - 2025-01-17 06:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:35:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:35:35 --> Controller Class Initialized
INFO - 2025-01-17 12:05:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 12:05:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 12:05:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:35:35 --> Config Class Initialized
INFO - 2025-01-17 06:35:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:35:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:35:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:35:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:35:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:35:35 --> Router Class Initialized
INFO - 2025-01-17 06:35:35 --> Output Class Initialized
INFO - 2025-01-17 06:35:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:35:35 --> Input Class Initialized
INFO - 2025-01-17 06:35:35 --> Language Class Initialized
INFO - 2025-01-17 06:35:35 --> Loader Class Initialized
INFO - 2025-01-17 06:35:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:35:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:35:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:35:35 --> Upload Class Initialized
INFO - 2025-01-17 06:35:35 --> Email Class Initialized
INFO - 2025-01-17 06:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:35:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:35:35 --> Controller Class Initialized
INFO - 2025-01-17 12:05:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:05:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 12:05:35 --> Final output sent to browser
DEBUG - 2025-01-17 12:05:35 --> Total execution time: 0.0247
INFO - 2025-01-17 06:36:35 --> Config Class Initialized
INFO - 2025-01-17 06:36:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:36:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:36:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:36:35 --> URI Class Initialized
INFO - 2025-01-17 06:36:35 --> Router Class Initialized
INFO - 2025-01-17 06:36:35 --> Output Class Initialized
INFO - 2025-01-17 06:36:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:36:35 --> Input Class Initialized
INFO - 2025-01-17 06:36:35 --> Language Class Initialized
INFO - 2025-01-17 06:36:35 --> Loader Class Initialized
INFO - 2025-01-17 06:36:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:36:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:36:35 --> Upload Class Initialized
INFO - 2025-01-17 06:36:35 --> Email Class Initialized
INFO - 2025-01-17 06:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:36:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:36:35 --> Controller Class Initialized
INFO - 2025-01-17 12:06:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-17 12:06:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-17 12:06:35 --> Pagination Class Initialized
INFO - 2025-01-17 06:36:35 --> Config Class Initialized
INFO - 2025-01-17 06:36:35 --> Hooks Class Initialized
DEBUG - 2025-01-17 06:36:35 --> UTF-8 Support Enabled
INFO - 2025-01-17 06:36:35 --> Utf8 Class Initialized
INFO - 2025-01-17 06:36:35 --> URI Class Initialized
DEBUG - 2025-01-17 06:36:35 --> No URI present. Default controller set.
INFO - 2025-01-17 06:36:35 --> Router Class Initialized
INFO - 2025-01-17 06:36:35 --> Output Class Initialized
INFO - 2025-01-17 06:36:35 --> Security Class Initialized
DEBUG - 2025-01-17 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-17 06:36:35 --> Input Class Initialized
INFO - 2025-01-17 06:36:35 --> Language Class Initialized
INFO - 2025-01-17 06:36:35 --> Loader Class Initialized
INFO - 2025-01-17 06:36:35 --> Helper loaded: url_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: html_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: file_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: string_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: form_helper
INFO - 2025-01-17 06:36:35 --> Helper loaded: my_helper
INFO - 2025-01-17 06:36:35 --> Database Driver Class Initialized
INFO - 2025-01-17 06:36:35 --> Upload Class Initialized
INFO - 2025-01-17 06:36:35 --> Email Class Initialized
INFO - 2025-01-17 06:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-17 06:36:35 --> Form Validation Class Initialized
INFO - 2025-01-17 06:36:35 --> Controller Class Initialized
INFO - 2025-01-17 12:06:35 --> Model "MainModel" initialized
INFO - 2025-01-17 12:06:35 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-17 12:06:35 --> Final output sent to browser
DEBUG - 2025-01-17 12:06:35 --> Total execution time: 0.0268
