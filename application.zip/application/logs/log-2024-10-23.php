<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-23 01:20:43 --> Model "MainModel" initialized
INFO - 2024-10-23 01:20:43 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 01:20:43 --> Final output sent to browser
DEBUG - 2024-10-23 01:20:43 --> Total execution time: 4.1365
INFO - 2024-10-23 01:20:48 --> Model "MainModel" initialized
INFO - 2024-10-23 01:20:48 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 01:20:48 --> Final output sent to browser
DEBUG - 2024-10-23 01:20:48 --> Total execution time: 4.0551
INFO - 2024-10-23 02:25:36 --> Model "MainModel" initialized
INFO - 2024-10-23 02:25:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:25:36 --> Final output sent to browser
DEBUG - 2024-10-23 02:25:36 --> Total execution time: 3.9592
INFO - 2024-10-23 02:26:03 --> Model "MainModel" initialized
INFO - 2024-10-23 02:26:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:26:03 --> Final output sent to browser
DEBUG - 2024-10-23 02:26:03 --> Total execution time: 3.9727
INFO - 2024-10-23 02:26:49 --> Model "MainModel" initialized
INFO - 2024-10-23 02:26:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:26:49 --> Final output sent to browser
DEBUG - 2024-10-23 02:26:49 --> Total execution time: 6.7368
INFO - 2024-10-23 02:26:49 --> Model "MainModel" initialized
INFO - 2024-10-23 02:26:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:26:49 --> Final output sent to browser
DEBUG - 2024-10-23 02:26:49 --> Total execution time: 7.1462
INFO - 2024-10-23 02:26:51 --> Model "MainModel" initialized
INFO - 2024-10-23 02:26:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:26:51 --> Final output sent to browser
DEBUG - 2024-10-23 02:26:51 --> Total execution time: 6.9436
INFO - 2024-10-23 02:26:52 --> Model "MainModel" initialized
INFO - 2024-10-23 02:26:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:26:52 --> Final output sent to browser
DEBUG - 2024-10-23 02:26:52 --> Total execution time: 7.1124
INFO - 2024-10-23 02:32:29 --> Model "MainModel" initialized
INFO - 2024-10-23 02:32:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:32:29 --> Final output sent to browser
DEBUG - 2024-10-23 02:32:29 --> Total execution time: 5.6213
INFO - 2024-10-23 02:32:29 --> Model "MainModel" initialized
INFO - 2024-10-23 02:32:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:32:29 --> Final output sent to browser
DEBUG - 2024-10-23 02:32:29 --> Total execution time: 5.8645
INFO - 2024-10-23 02:43:49 --> Model "MainModel" initialized
INFO - 2024-10-23 02:43:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:43:49 --> Final output sent to browser
DEBUG - 2024-10-23 02:43:49 --> Total execution time: 4.2120
INFO - 2024-10-23 02:43:57 --> Model "MainModel" initialized
INFO - 2024-10-23 02:43:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 02:43:57 --> Final output sent to browser
DEBUG - 2024-10-23 02:43:57 --> Total execution time: 4.0094
INFO - 2024-10-23 04:57:01 --> Model "MainModel" initialized
INFO - 2024-10-23 04:57:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 04:57:01 --> Final output sent to browser
DEBUG - 2024-10-23 04:57:01 --> Total execution time: 4.0250
INFO - 2024-10-23 05:18:27 --> Model "MainModel" initialized
INFO - 2024-10-23 05:18:27 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 05:18:27 --> Final output sent to browser
DEBUG - 2024-10-23 05:18:27 --> Total execution time: 3.9291
INFO - 2024-10-23 05:18:53 --> Model "MainModel" initialized
INFO - 2024-10-23 05:18:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 05:18:53 --> Final output sent to browser
DEBUG - 2024-10-23 05:18:53 --> Total execution time: 3.9058
INFO - 2024-10-23 01:03:13 --> Config Class Initialized
INFO - 2024-10-23 01:03:13 --> Hooks Class Initialized
DEBUG - 2024-10-23 01:03:13 --> UTF-8 Support Enabled
INFO - 2024-10-23 01:03:13 --> Utf8 Class Initialized
INFO - 2024-10-23 01:03:13 --> URI Class Initialized
DEBUG - 2024-10-23 01:03:13 --> No URI present. Default controller set.
INFO - 2024-10-23 01:03:13 --> Router Class Initialized
INFO - 2024-10-23 01:03:13 --> Output Class Initialized
INFO - 2024-10-23 01:03:13 --> Security Class Initialized
DEBUG - 2024-10-23 01:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 01:03:13 --> Input Class Initialized
INFO - 2024-10-23 01:03:13 --> Config Class Initialized
INFO - 2024-10-23 01:03:13 --> Hooks Class Initialized
INFO - 2024-10-23 01:03:13 --> Language Class Initialized
DEBUG - 2024-10-23 01:03:13 --> UTF-8 Support Enabled
INFO - 2024-10-23 01:03:13 --> Utf8 Class Initialized
INFO - 2024-10-23 01:03:13 --> URI Class Initialized
DEBUG - 2024-10-23 01:03:13 --> No URI present. Default controller set.
INFO - 2024-10-23 01:03:13 --> Router Class Initialized
INFO - 2024-10-23 01:03:13 --> Loader Class Initialized
INFO - 2024-10-23 01:03:13 --> Output Class Initialized
INFO - 2024-10-23 01:03:13 --> Security Class Initialized
DEBUG - 2024-10-23 01:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 01:03:13 --> Input Class Initialized
INFO - 2024-10-23 01:03:13 --> Helper loaded: url_helper
INFO - 2024-10-23 01:03:13 --> Language Class Initialized
INFO - 2024-10-23 01:03:13 --> Helper loaded: html_helper
INFO - 2024-10-23 01:03:13 --> Loader Class Initialized
INFO - 2024-10-23 01:03:13 --> Helper loaded: url_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: file_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: html_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: file_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: string_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: string_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: form_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: form_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: my_helper
INFO - 2024-10-23 01:03:13 --> Helper loaded: my_helper
INFO - 2024-10-23 01:03:13 --> Database Driver Class Initialized
INFO - 2024-10-23 01:03:13 --> Database Driver Class Initialized
INFO - 2024-10-23 01:03:15 --> Upload Class Initialized
INFO - 2024-10-23 01:03:15 --> Upload Class Initialized
INFO - 2024-10-23 01:03:15 --> Email Class Initialized
INFO - 2024-10-23 01:03:15 --> Email Class Initialized
INFO - 2024-10-23 01:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 01:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 01:03:15 --> Form Validation Class Initialized
INFO - 2024-10-23 01:03:15 --> Form Validation Class Initialized
INFO - 2024-10-23 01:03:15 --> Controller Class Initialized
INFO - 2024-10-23 01:03:15 --> Controller Class Initialized
INFO - 2024-10-23 06:33:15 --> Model "MainModel" initialized
INFO - 2024-10-23 06:33:15 --> Model "MainModel" initialized
INFO - 2024-10-23 06:33:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 06:33:15 --> Final output sent to browser
INFO - 2024-10-23 06:33:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 06:33:15 --> Final output sent to browser
DEBUG - 2024-10-23 06:33:15 --> Total execution time: 2.2097
DEBUG - 2024-10-23 06:33:15 --> Total execution time: 2.2800
INFO - 2024-10-23 01:03:16 --> Config Class Initialized
INFO - 2024-10-23 01:03:16 --> Hooks Class Initialized
DEBUG - 2024-10-23 01:03:16 --> UTF-8 Support Enabled
INFO - 2024-10-23 01:03:16 --> Utf8 Class Initialized
INFO - 2024-10-23 01:03:16 --> URI Class Initialized
DEBUG - 2024-10-23 01:03:16 --> No URI present. Default controller set.
INFO - 2024-10-23 01:03:16 --> Router Class Initialized
INFO - 2024-10-23 01:03:16 --> Output Class Initialized
INFO - 2024-10-23 01:03:16 --> Security Class Initialized
DEBUG - 2024-10-23 01:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 01:03:16 --> Input Class Initialized
INFO - 2024-10-23 01:03:16 --> Language Class Initialized
INFO - 2024-10-23 01:03:16 --> Loader Class Initialized
INFO - 2024-10-23 01:03:16 --> Helper loaded: url_helper
INFO - 2024-10-23 01:03:16 --> Helper loaded: html_helper
INFO - 2024-10-23 01:03:16 --> Helper loaded: file_helper
INFO - 2024-10-23 01:03:16 --> Helper loaded: string_helper
INFO - 2024-10-23 01:03:16 --> Helper loaded: form_helper
INFO - 2024-10-23 01:03:16 --> Helper loaded: my_helper
INFO - 2024-10-23 01:03:16 --> Database Driver Class Initialized
INFO - 2024-10-23 01:03:18 --> Upload Class Initialized
INFO - 2024-10-23 01:03:18 --> Email Class Initialized
INFO - 2024-10-23 01:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 01:03:18 --> Form Validation Class Initialized
INFO - 2024-10-23 01:03:18 --> Controller Class Initialized
INFO - 2024-10-23 06:33:18 --> Model "MainModel" initialized
INFO - 2024-10-23 06:33:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 06:33:18 --> Final output sent to browser
DEBUG - 2024-10-23 06:33:18 --> Total execution time: 2.1434
INFO - 2024-10-23 02:05:05 --> Config Class Initialized
INFO - 2024-10-23 02:05:05 --> Hooks Class Initialized
DEBUG - 2024-10-23 02:05:05 --> UTF-8 Support Enabled
INFO - 2024-10-23 02:05:05 --> Utf8 Class Initialized
INFO - 2024-10-23 02:05:05 --> URI Class Initialized
DEBUG - 2024-10-23 02:05:05 --> No URI present. Default controller set.
INFO - 2024-10-23 02:05:05 --> Router Class Initialized
INFO - 2024-10-23 02:05:05 --> Output Class Initialized
INFO - 2024-10-23 02:05:05 --> Security Class Initialized
DEBUG - 2024-10-23 02:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 02:05:05 --> Input Class Initialized
INFO - 2024-10-23 02:05:05 --> Language Class Initialized
INFO - 2024-10-23 02:05:06 --> Loader Class Initialized
INFO - 2024-10-23 02:05:06 --> Helper loaded: url_helper
INFO - 2024-10-23 02:05:06 --> Helper loaded: html_helper
INFO - 2024-10-23 02:05:06 --> Helper loaded: file_helper
INFO - 2024-10-23 02:05:06 --> Helper loaded: string_helper
INFO - 2024-10-23 02:05:06 --> Helper loaded: form_helper
INFO - 2024-10-23 02:05:06 --> Helper loaded: my_helper
INFO - 2024-10-23 02:05:06 --> Database Driver Class Initialized
INFO - 2024-10-23 02:05:08 --> Upload Class Initialized
INFO - 2024-10-23 02:05:08 --> Email Class Initialized
INFO - 2024-10-23 02:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 02:05:08 --> Form Validation Class Initialized
INFO - 2024-10-23 02:05:08 --> Controller Class Initialized
INFO - 2024-10-23 07:35:08 --> Model "MainModel" initialized
INFO - 2024-10-23 07:35:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 07:35:08 --> Final output sent to browser
DEBUG - 2024-10-23 07:35:08 --> Total execution time: 2.2282
INFO - 2024-10-23 03:18:21 --> Config Class Initialized
INFO - 2024-10-23 03:18:21 --> Hooks Class Initialized
DEBUG - 2024-10-23 03:18:21 --> UTF-8 Support Enabled
INFO - 2024-10-23 03:18:21 --> Utf8 Class Initialized
INFO - 2024-10-23 03:18:21 --> URI Class Initialized
INFO - 2024-10-23 03:18:21 --> Router Class Initialized
INFO - 2024-10-23 03:18:21 --> Output Class Initialized
INFO - 2024-10-23 03:18:21 --> Security Class Initialized
DEBUG - 2024-10-23 03:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 03:18:21 --> Input Class Initialized
INFO - 2024-10-23 03:18:21 --> Language Class Initialized
ERROR - 2024-10-23 03:18:21 --> 404 Page Not Found: Wp-admin/setup-config.php
INFO - 2024-10-23 03:18:21 --> Config Class Initialized
INFO - 2024-10-23 03:18:21 --> Hooks Class Initialized
DEBUG - 2024-10-23 03:18:21 --> UTF-8 Support Enabled
INFO - 2024-10-23 03:18:21 --> Utf8 Class Initialized
INFO - 2024-10-23 03:18:21 --> URI Class Initialized
INFO - 2024-10-23 03:18:21 --> Router Class Initialized
INFO - 2024-10-23 03:18:21 --> Output Class Initialized
INFO - 2024-10-23 03:18:21 --> Security Class Initialized
DEBUG - 2024-10-23 03:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 03:18:21 --> Input Class Initialized
INFO - 2024-10-23 03:18:21 --> Language Class Initialized
ERROR - 2024-10-23 03:18:21 --> 404 Page Not Found: Wordpress/wp-admin
INFO - 2024-10-23 04:38:39 --> Config Class Initialized
INFO - 2024-10-23 04:38:39 --> Hooks Class Initialized
DEBUG - 2024-10-23 04:38:39 --> UTF-8 Support Enabled
INFO - 2024-10-23 04:38:39 --> Utf8 Class Initialized
INFO - 2024-10-23 04:38:39 --> URI Class Initialized
DEBUG - 2024-10-23 04:38:39 --> No URI present. Default controller set.
INFO - 2024-10-23 04:38:39 --> Router Class Initialized
INFO - 2024-10-23 04:38:39 --> Output Class Initialized
INFO - 2024-10-23 04:38:39 --> Security Class Initialized
DEBUG - 2024-10-23 04:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 04:38:39 --> Input Class Initialized
INFO - 2024-10-23 04:38:39 --> Language Class Initialized
INFO - 2024-10-23 04:38:39 --> Loader Class Initialized
INFO - 2024-10-23 04:38:39 --> Helper loaded: url_helper
INFO - 2024-10-23 04:38:39 --> Helper loaded: html_helper
INFO - 2024-10-23 04:38:39 --> Helper loaded: file_helper
INFO - 2024-10-23 04:38:39 --> Helper loaded: string_helper
INFO - 2024-10-23 04:38:39 --> Helper loaded: form_helper
INFO - 2024-10-23 04:38:39 --> Helper loaded: my_helper
INFO - 2024-10-23 04:38:39 --> Database Driver Class Initialized
INFO - 2024-10-23 04:38:41 --> Upload Class Initialized
INFO - 2024-10-23 04:38:41 --> Email Class Initialized
INFO - 2024-10-23 04:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 04:38:41 --> Form Validation Class Initialized
INFO - 2024-10-23 04:38:41 --> Controller Class Initialized
INFO - 2024-10-23 10:08:41 --> Model "MainModel" initialized
INFO - 2024-10-23 10:08:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 10:08:41 --> Final output sent to browser
DEBUG - 2024-10-23 10:08:41 --> Total execution time: 2.2443
INFO - 2024-10-23 04:38:42 --> Config Class Initialized
INFO - 2024-10-23 04:38:42 --> Hooks Class Initialized
DEBUG - 2024-10-23 04:38:42 --> UTF-8 Support Enabled
INFO - 2024-10-23 04:38:42 --> Utf8 Class Initialized
INFO - 2024-10-23 04:38:42 --> URI Class Initialized
DEBUG - 2024-10-23 04:38:42 --> No URI present. Default controller set.
INFO - 2024-10-23 04:38:42 --> Router Class Initialized
INFO - 2024-10-23 04:38:42 --> Output Class Initialized
INFO - 2024-10-23 04:38:42 --> Security Class Initialized
DEBUG - 2024-10-23 04:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 04:38:42 --> Input Class Initialized
INFO - 2024-10-23 04:38:42 --> Language Class Initialized
INFO - 2024-10-23 04:38:42 --> Loader Class Initialized
INFO - 2024-10-23 04:38:42 --> Helper loaded: url_helper
INFO - 2024-10-23 04:38:42 --> Helper loaded: html_helper
INFO - 2024-10-23 04:38:42 --> Helper loaded: file_helper
INFO - 2024-10-23 04:38:42 --> Helper loaded: string_helper
INFO - 2024-10-23 04:38:42 --> Helper loaded: form_helper
INFO - 2024-10-23 04:38:42 --> Helper loaded: my_helper
INFO - 2024-10-23 04:38:42 --> Database Driver Class Initialized
INFO - 2024-10-23 04:38:44 --> Upload Class Initialized
INFO - 2024-10-23 04:38:44 --> Email Class Initialized
INFO - 2024-10-23 04:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 04:38:44 --> Form Validation Class Initialized
INFO - 2024-10-23 04:38:44 --> Controller Class Initialized
INFO - 2024-10-23 10:08:44 --> Model "MainModel" initialized
INFO - 2024-10-23 10:08:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 10:08:44 --> Final output sent to browser
DEBUG - 2024-10-23 10:08:44 --> Total execution time: 2.1211
INFO - 2024-10-23 06:16:12 --> Config Class Initialized
INFO - 2024-10-23 06:16:12 --> Hooks Class Initialized
DEBUG - 2024-10-23 06:16:12 --> UTF-8 Support Enabled
INFO - 2024-10-23 06:16:12 --> Utf8 Class Initialized
INFO - 2024-10-23 06:16:12 --> URI Class Initialized
DEBUG - 2024-10-23 06:16:12 --> No URI present. Default controller set.
INFO - 2024-10-23 06:16:12 --> Router Class Initialized
INFO - 2024-10-23 06:16:12 --> Output Class Initialized
INFO - 2024-10-23 06:16:12 --> Security Class Initialized
DEBUG - 2024-10-23 06:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 06:16:12 --> Input Class Initialized
INFO - 2024-10-23 06:16:12 --> Language Class Initialized
INFO - 2024-10-23 06:16:12 --> Loader Class Initialized
INFO - 2024-10-23 06:16:12 --> Helper loaded: url_helper
INFO - 2024-10-23 06:16:12 --> Helper loaded: html_helper
INFO - 2024-10-23 06:16:12 --> Helper loaded: file_helper
INFO - 2024-10-23 06:16:12 --> Helper loaded: string_helper
INFO - 2024-10-23 06:16:12 --> Helper loaded: form_helper
INFO - 2024-10-23 06:16:12 --> Helper loaded: my_helper
INFO - 2024-10-23 06:16:12 --> Database Driver Class Initialized
INFO - 2024-10-23 06:16:14 --> Upload Class Initialized
INFO - 2024-10-23 06:16:14 --> Email Class Initialized
INFO - 2024-10-23 06:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 06:16:14 --> Form Validation Class Initialized
INFO - 2024-10-23 06:16:14 --> Controller Class Initialized
INFO - 2024-10-23 11:46:14 --> Model "MainModel" initialized
INFO - 2024-10-23 11:46:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 11:46:14 --> Final output sent to browser
DEBUG - 2024-10-23 11:46:14 --> Total execution time: 2.2707
INFO - 2024-10-23 07:43:29 --> Config Class Initialized
INFO - 2024-10-23 07:43:29 --> Hooks Class Initialized
DEBUG - 2024-10-23 07:43:29 --> UTF-8 Support Enabled
INFO - 2024-10-23 07:43:29 --> Utf8 Class Initialized
INFO - 2024-10-23 07:43:29 --> URI Class Initialized
DEBUG - 2024-10-23 07:43:29 --> No URI present. Default controller set.
INFO - 2024-10-23 07:43:29 --> Router Class Initialized
INFO - 2024-10-23 07:43:29 --> Output Class Initialized
INFO - 2024-10-23 07:43:29 --> Security Class Initialized
DEBUG - 2024-10-23 07:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 07:43:29 --> Input Class Initialized
INFO - 2024-10-23 07:43:29 --> Language Class Initialized
INFO - 2024-10-23 07:43:29 --> Loader Class Initialized
INFO - 2024-10-23 07:43:29 --> Helper loaded: url_helper
INFO - 2024-10-23 07:43:29 --> Helper loaded: html_helper
INFO - 2024-10-23 07:43:29 --> Helper loaded: file_helper
INFO - 2024-10-23 07:43:29 --> Helper loaded: string_helper
INFO - 2024-10-23 07:43:29 --> Helper loaded: form_helper
INFO - 2024-10-23 07:43:29 --> Helper loaded: my_helper
INFO - 2024-10-23 07:43:29 --> Database Driver Class Initialized
INFO - 2024-10-23 07:43:31 --> Upload Class Initialized
INFO - 2024-10-23 07:43:31 --> Email Class Initialized
INFO - 2024-10-23 07:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 07:43:31 --> Form Validation Class Initialized
INFO - 2024-10-23 07:43:31 --> Controller Class Initialized
INFO - 2024-10-23 13:13:31 --> Model "MainModel" initialized
INFO - 2024-10-23 13:13:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 13:13:31 --> Final output sent to browser
DEBUG - 2024-10-23 13:13:31 --> Total execution time: 2.5116
INFO - 2024-10-23 07:43:38 --> Config Class Initialized
INFO - 2024-10-23 07:43:38 --> Hooks Class Initialized
DEBUG - 2024-10-23 07:43:38 --> UTF-8 Support Enabled
INFO - 2024-10-23 07:43:38 --> Utf8 Class Initialized
INFO - 2024-10-23 07:43:38 --> URI Class Initialized
INFO - 2024-10-23 07:43:38 --> Router Class Initialized
INFO - 2024-10-23 07:43:38 --> Output Class Initialized
INFO - 2024-10-23 07:43:38 --> Security Class Initialized
DEBUG - 2024-10-23 07:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 07:43:38 --> Input Class Initialized
INFO - 2024-10-23 07:43:38 --> Language Class Initialized
ERROR - 2024-10-23 07:43:38 --> 404 Page Not Found: Adstxt/index
INFO - 2024-10-23 07:43:39 --> Config Class Initialized
INFO - 2024-10-23 07:43:39 --> Hooks Class Initialized
DEBUG - 2024-10-23 07:43:39 --> UTF-8 Support Enabled
INFO - 2024-10-23 07:43:39 --> Utf8 Class Initialized
INFO - 2024-10-23 07:43:39 --> URI Class Initialized
INFO - 2024-10-23 07:43:39 --> Router Class Initialized
INFO - 2024-10-23 07:43:39 --> Output Class Initialized
INFO - 2024-10-23 07:43:39 --> Security Class Initialized
DEBUG - 2024-10-23 07:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 07:43:39 --> Input Class Initialized
INFO - 2024-10-23 07:43:39 --> Language Class Initialized
ERROR - 2024-10-23 07:43:39 --> 404 Page Not Found: App-adstxt/index
INFO - 2024-10-23 07:43:39 --> Config Class Initialized
INFO - 2024-10-23 07:43:39 --> Hooks Class Initialized
DEBUG - 2024-10-23 07:43:39 --> UTF-8 Support Enabled
INFO - 2024-10-23 07:43:39 --> Utf8 Class Initialized
INFO - 2024-10-23 07:43:39 --> URI Class Initialized
INFO - 2024-10-23 07:43:39 --> Router Class Initialized
INFO - 2024-10-23 07:43:39 --> Output Class Initialized
INFO - 2024-10-23 07:43:39 --> Security Class Initialized
DEBUG - 2024-10-23 07:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 07:43:39 --> Input Class Initialized
INFO - 2024-10-23 07:43:39 --> Language Class Initialized
ERROR - 2024-10-23 07:43:39 --> 404 Page Not Found: Sellersjson/index
INFO - 2024-10-23 13:24:59 --> Config Class Initialized
INFO - 2024-10-23 13:24:59 --> Hooks Class Initialized
DEBUG - 2024-10-23 13:24:59 --> UTF-8 Support Enabled
INFO - 2024-10-23 13:24:59 --> Utf8 Class Initialized
INFO - 2024-10-23 13:24:59 --> URI Class Initialized
DEBUG - 2024-10-23 13:24:59 --> No URI present. Default controller set.
INFO - 2024-10-23 13:24:59 --> Router Class Initialized
INFO - 2024-10-23 13:24:59 --> Output Class Initialized
INFO - 2024-10-23 13:24:59 --> Security Class Initialized
DEBUG - 2024-10-23 13:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 13:24:59 --> Input Class Initialized
INFO - 2024-10-23 13:24:59 --> Language Class Initialized
INFO - 2024-10-23 13:24:59 --> Loader Class Initialized
INFO - 2024-10-23 13:25:00 --> Helper loaded: url_helper
INFO - 2024-10-23 13:25:00 --> Helper loaded: html_helper
INFO - 2024-10-23 13:25:00 --> Helper loaded: file_helper
INFO - 2024-10-23 13:25:00 --> Helper loaded: string_helper
INFO - 2024-10-23 13:25:00 --> Helper loaded: form_helper
INFO - 2024-10-23 13:25:00 --> Helper loaded: my_helper
INFO - 2024-10-23 13:25:00 --> Database Driver Class Initialized
INFO - 2024-10-23 13:25:02 --> Upload Class Initialized
INFO - 2024-10-23 13:25:02 --> Email Class Initialized
INFO - 2024-10-23 13:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 13:25:02 --> Form Validation Class Initialized
INFO - 2024-10-23 13:25:02 --> Controller Class Initialized
INFO - 2024-10-23 18:55:02 --> Model "MainModel" initialized
INFO - 2024-10-23 18:55:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 18:55:02 --> Final output sent to browser
DEBUG - 2024-10-23 18:55:02 --> Total execution time: 2.4001
INFO - 2024-10-23 13:59:06 --> Config Class Initialized
INFO - 2024-10-23 13:59:06 --> Hooks Class Initialized
DEBUG - 2024-10-23 13:59:06 --> UTF-8 Support Enabled
INFO - 2024-10-23 13:59:06 --> Utf8 Class Initialized
INFO - 2024-10-23 13:59:06 --> URI Class Initialized
DEBUG - 2024-10-23 13:59:06 --> No URI present. Default controller set.
INFO - 2024-10-23 13:59:06 --> Router Class Initialized
INFO - 2024-10-23 13:59:06 --> Output Class Initialized
INFO - 2024-10-23 13:59:06 --> Security Class Initialized
DEBUG - 2024-10-23 13:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 13:59:06 --> Input Class Initialized
INFO - 2024-10-23 13:59:06 --> Language Class Initialized
INFO - 2024-10-23 13:59:06 --> Loader Class Initialized
INFO - 2024-10-23 13:59:06 --> Helper loaded: url_helper
INFO - 2024-10-23 13:59:06 --> Helper loaded: html_helper
INFO - 2024-10-23 13:59:06 --> Helper loaded: file_helper
INFO - 2024-10-23 13:59:06 --> Helper loaded: string_helper
INFO - 2024-10-23 13:59:06 --> Helper loaded: form_helper
INFO - 2024-10-23 13:59:06 --> Helper loaded: my_helper
INFO - 2024-10-23 13:59:06 --> Database Driver Class Initialized
INFO - 2024-10-23 13:59:08 --> Upload Class Initialized
INFO - 2024-10-23 13:59:08 --> Email Class Initialized
INFO - 2024-10-23 13:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 13:59:08 --> Form Validation Class Initialized
INFO - 2024-10-23 13:59:08 --> Controller Class Initialized
INFO - 2024-10-23 19:29:08 --> Model "MainModel" initialized
INFO - 2024-10-23 19:29:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 19:29:08 --> Final output sent to browser
DEBUG - 2024-10-23 19:29:08 --> Total execution time: 2.2034
INFO - 2024-10-23 13:59:10 --> Config Class Initialized
INFO - 2024-10-23 13:59:10 --> Hooks Class Initialized
DEBUG - 2024-10-23 13:59:10 --> UTF-8 Support Enabled
INFO - 2024-10-23 13:59:10 --> Utf8 Class Initialized
INFO - 2024-10-23 13:59:10 --> URI Class Initialized
INFO - 2024-10-23 13:59:10 --> Router Class Initialized
INFO - 2024-10-23 13:59:10 --> Output Class Initialized
INFO - 2024-10-23 13:59:10 --> Security Class Initialized
DEBUG - 2024-10-23 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 13:59:10 --> Input Class Initialized
INFO - 2024-10-23 13:59:10 --> Language Class Initialized
ERROR - 2024-10-23 13:59:10 --> 404 Page Not Found: Adstxt/index
INFO - 2024-10-23 13:59:11 --> Config Class Initialized
INFO - 2024-10-23 13:59:11 --> Hooks Class Initialized
DEBUG - 2024-10-23 13:59:11 --> UTF-8 Support Enabled
INFO - 2024-10-23 13:59:11 --> Utf8 Class Initialized
INFO - 2024-10-23 13:59:11 --> URI Class Initialized
INFO - 2024-10-23 13:59:11 --> Router Class Initialized
INFO - 2024-10-23 13:59:11 --> Output Class Initialized
INFO - 2024-10-23 13:59:11 --> Security Class Initialized
DEBUG - 2024-10-23 13:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 13:59:11 --> Input Class Initialized
INFO - 2024-10-23 13:59:11 --> Language Class Initialized
ERROR - 2024-10-23 13:59:11 --> 404 Page Not Found: App-adstxt/index
INFO - 2024-10-23 13:59:11 --> Config Class Initialized
INFO - 2024-10-23 13:59:11 --> Hooks Class Initialized
DEBUG - 2024-10-23 13:59:11 --> UTF-8 Support Enabled
INFO - 2024-10-23 13:59:11 --> Utf8 Class Initialized
INFO - 2024-10-23 13:59:11 --> URI Class Initialized
INFO - 2024-10-23 13:59:11 --> Router Class Initialized
INFO - 2024-10-23 13:59:11 --> Output Class Initialized
INFO - 2024-10-23 13:59:11 --> Security Class Initialized
DEBUG - 2024-10-23 13:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 13:59:11 --> Input Class Initialized
INFO - 2024-10-23 13:59:11 --> Language Class Initialized
ERROR - 2024-10-23 13:59:11 --> 404 Page Not Found: Sellersjson/index
INFO - 2024-10-23 14:52:49 --> Config Class Initialized
INFO - 2024-10-23 14:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-23 14:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-23 14:52:49 --> Utf8 Class Initialized
INFO - 2024-10-23 14:52:49 --> URI Class Initialized
DEBUG - 2024-10-23 14:52:49 --> No URI present. Default controller set.
INFO - 2024-10-23 14:52:49 --> Router Class Initialized
INFO - 2024-10-23 14:52:49 --> Output Class Initialized
INFO - 2024-10-23 14:52:49 --> Security Class Initialized
DEBUG - 2024-10-23 14:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 14:52:49 --> Input Class Initialized
INFO - 2024-10-23 14:52:49 --> Language Class Initialized
INFO - 2024-10-23 14:52:49 --> Loader Class Initialized
INFO - 2024-10-23 14:52:49 --> Helper loaded: url_helper
INFO - 2024-10-23 14:52:49 --> Helper loaded: html_helper
INFO - 2024-10-23 14:52:49 --> Helper loaded: file_helper
INFO - 2024-10-23 14:52:49 --> Helper loaded: string_helper
INFO - 2024-10-23 14:52:49 --> Helper loaded: form_helper
INFO - 2024-10-23 14:52:49 --> Helper loaded: my_helper
INFO - 2024-10-23 14:52:49 --> Database Driver Class Initialized
INFO - 2024-10-23 14:52:51 --> Upload Class Initialized
INFO - 2024-10-23 14:52:51 --> Email Class Initialized
INFO - 2024-10-23 14:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 14:52:51 --> Form Validation Class Initialized
INFO - 2024-10-23 14:52:51 --> Controller Class Initialized
INFO - 2024-10-23 20:22:51 --> Model "MainModel" initialized
INFO - 2024-10-23 20:22:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 20:22:51 --> Final output sent to browser
DEBUG - 2024-10-23 20:22:51 --> Total execution time: 2.2597
INFO - 2024-10-23 14:52:51 --> Config Class Initialized
INFO - 2024-10-23 14:52:51 --> Hooks Class Initialized
DEBUG - 2024-10-23 14:52:51 --> UTF-8 Support Enabled
INFO - 2024-10-23 14:52:51 --> Utf8 Class Initialized
INFO - 2024-10-23 14:52:51 --> URI Class Initialized
DEBUG - 2024-10-23 14:52:51 --> No URI present. Default controller set.
INFO - 2024-10-23 14:52:51 --> Router Class Initialized
INFO - 2024-10-23 14:52:51 --> Output Class Initialized
INFO - 2024-10-23 14:52:51 --> Security Class Initialized
DEBUG - 2024-10-23 14:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 14:52:51 --> Input Class Initialized
INFO - 2024-10-23 14:52:51 --> Language Class Initialized
INFO - 2024-10-23 14:52:51 --> Loader Class Initialized
INFO - 2024-10-23 14:52:51 --> Helper loaded: url_helper
INFO - 2024-10-23 14:52:51 --> Helper loaded: html_helper
INFO - 2024-10-23 14:52:51 --> Helper loaded: file_helper
INFO - 2024-10-23 14:52:51 --> Helper loaded: string_helper
INFO - 2024-10-23 14:52:51 --> Helper loaded: form_helper
INFO - 2024-10-23 14:52:51 --> Helper loaded: my_helper
INFO - 2024-10-23 14:52:51 --> Database Driver Class Initialized
INFO - 2024-10-23 14:52:53 --> Upload Class Initialized
INFO - 2024-10-23 14:52:53 --> Email Class Initialized
INFO - 2024-10-23 14:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 14:52:54 --> Form Validation Class Initialized
INFO - 2024-10-23 14:52:54 --> Controller Class Initialized
INFO - 2024-10-23 20:22:54 --> Model "MainModel" initialized
INFO - 2024-10-23 20:22:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 20:22:54 --> Final output sent to browser
DEBUG - 2024-10-23 20:22:54 --> Total execution time: 2.1196
INFO - 2024-10-23 16:11:21 --> Config Class Initialized
INFO - 2024-10-23 16:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-23 16:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-23 16:11:21 --> Utf8 Class Initialized
INFO - 2024-10-23 16:11:21 --> URI Class Initialized
DEBUG - 2024-10-23 16:11:21 --> No URI present. Default controller set.
INFO - 2024-10-23 16:11:21 --> Router Class Initialized
INFO - 2024-10-23 16:11:21 --> Output Class Initialized
INFO - 2024-10-23 16:11:21 --> Security Class Initialized
DEBUG - 2024-10-23 16:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 16:11:21 --> Input Class Initialized
INFO - 2024-10-23 16:11:21 --> Language Class Initialized
INFO - 2024-10-23 16:11:21 --> Loader Class Initialized
INFO - 2024-10-23 16:11:21 --> Helper loaded: url_helper
INFO - 2024-10-23 16:11:21 --> Helper loaded: html_helper
INFO - 2024-10-23 16:11:21 --> Helper loaded: file_helper
INFO - 2024-10-23 16:11:21 --> Helper loaded: string_helper
INFO - 2024-10-23 16:11:21 --> Helper loaded: form_helper
INFO - 2024-10-23 16:11:21 --> Helper loaded: my_helper
INFO - 2024-10-23 16:11:21 --> Database Driver Class Initialized
INFO - 2024-10-23 16:11:23 --> Upload Class Initialized
INFO - 2024-10-23 16:11:23 --> Email Class Initialized
INFO - 2024-10-23 16:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 16:11:23 --> Form Validation Class Initialized
INFO - 2024-10-23 16:11:23 --> Controller Class Initialized
INFO - 2024-10-23 21:41:23 --> Model "MainModel" initialized
INFO - 2024-10-23 21:41:23 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 21:41:23 --> Final output sent to browser
DEBUG - 2024-10-23 21:41:23 --> Total execution time: 2.2201
INFO - 2024-10-23 16:45:23 --> Config Class Initialized
INFO - 2024-10-23 16:45:23 --> Hooks Class Initialized
DEBUG - 2024-10-23 16:45:23 --> UTF-8 Support Enabled
INFO - 2024-10-23 16:45:23 --> Utf8 Class Initialized
INFO - 2024-10-23 16:45:23 --> URI Class Initialized
DEBUG - 2024-10-23 16:45:23 --> No URI present. Default controller set.
INFO - 2024-10-23 16:45:23 --> Router Class Initialized
INFO - 2024-10-23 16:45:23 --> Output Class Initialized
INFO - 2024-10-23 16:45:23 --> Security Class Initialized
DEBUG - 2024-10-23 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 16:45:23 --> Input Class Initialized
INFO - 2024-10-23 16:45:23 --> Language Class Initialized
INFO - 2024-10-23 16:45:23 --> Loader Class Initialized
INFO - 2024-10-23 16:45:23 --> Helper loaded: url_helper
INFO - 2024-10-23 16:45:23 --> Helper loaded: html_helper
INFO - 2024-10-23 16:45:23 --> Helper loaded: file_helper
INFO - 2024-10-23 16:45:23 --> Helper loaded: string_helper
INFO - 2024-10-23 16:45:23 --> Helper loaded: form_helper
INFO - 2024-10-23 16:45:23 --> Helper loaded: my_helper
INFO - 2024-10-23 16:45:23 --> Database Driver Class Initialized
INFO - 2024-10-23 16:45:25 --> Upload Class Initialized
INFO - 2024-10-23 16:45:26 --> Email Class Initialized
INFO - 2024-10-23 16:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 16:45:26 --> Form Validation Class Initialized
INFO - 2024-10-23 16:45:26 --> Controller Class Initialized
INFO - 2024-10-23 22:15:26 --> Model "MainModel" initialized
INFO - 2024-10-23 22:15:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-23 22:15:26 --> Final output sent to browser
DEBUG - 2024-10-23 22:15:26 --> Total execution time: 2.2764
INFO - 2024-10-23 21:08:16 --> Config Class Initialized
INFO - 2024-10-23 21:08:16 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:08:17 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:08:17 --> Utf8 Class Initialized
INFO - 2024-10-23 21:08:17 --> URI Class Initialized
DEBUG - 2024-10-23 21:08:17 --> No URI present. Default controller set.
INFO - 2024-10-23 21:08:17 --> Router Class Initialized
INFO - 2024-10-23 21:08:17 --> Output Class Initialized
INFO - 2024-10-23 21:08:17 --> Security Class Initialized
DEBUG - 2024-10-23 21:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:08:17 --> Input Class Initialized
INFO - 2024-10-23 21:08:17 --> Language Class Initialized
INFO - 2024-10-23 21:08:17 --> Loader Class Initialized
INFO - 2024-10-23 21:08:17 --> Helper loaded: url_helper
INFO - 2024-10-23 21:08:17 --> Helper loaded: html_helper
INFO - 2024-10-23 21:08:17 --> Helper loaded: file_helper
INFO - 2024-10-23 21:08:17 --> Helper loaded: string_helper
INFO - 2024-10-23 21:08:17 --> Helper loaded: form_helper
INFO - 2024-10-23 21:08:17 --> Helper loaded: my_helper
INFO - 2024-10-23 21:08:17 --> Database Driver Class Initialized
INFO - 2024-10-23 21:08:19 --> Upload Class Initialized
INFO - 2024-10-23 21:08:19 --> Email Class Initialized
INFO - 2024-10-23 21:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:08:19 --> Form Validation Class Initialized
INFO - 2024-10-23 21:08:19 --> Controller Class Initialized
INFO - 2024-10-23 21:08:22 --> Config Class Initialized
INFO - 2024-10-23 21:08:22 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:08:22 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:08:22 --> Utf8 Class Initialized
INFO - 2024-10-23 21:08:22 --> URI Class Initialized
DEBUG - 2024-10-23 21:08:22 --> No URI present. Default controller set.
INFO - 2024-10-23 21:08:22 --> Router Class Initialized
INFO - 2024-10-23 21:08:22 --> Output Class Initialized
INFO - 2024-10-23 21:08:22 --> Security Class Initialized
DEBUG - 2024-10-23 21:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:08:22 --> Input Class Initialized
INFO - 2024-10-23 21:08:22 --> Language Class Initialized
INFO - 2024-10-23 21:08:22 --> Loader Class Initialized
INFO - 2024-10-23 21:08:22 --> Helper loaded: url_helper
INFO - 2024-10-23 21:08:22 --> Helper loaded: html_helper
INFO - 2024-10-23 21:08:22 --> Helper loaded: file_helper
INFO - 2024-10-23 21:08:22 --> Helper loaded: string_helper
INFO - 2024-10-23 21:08:22 --> Helper loaded: form_helper
INFO - 2024-10-23 21:08:22 --> Helper loaded: my_helper
INFO - 2024-10-23 21:08:22 --> Database Driver Class Initialized
INFO - 2024-10-23 21:08:24 --> Upload Class Initialized
INFO - 2024-10-23 21:08:24 --> Email Class Initialized
INFO - 2024-10-23 21:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:08:24 --> Form Validation Class Initialized
INFO - 2024-10-23 21:08:24 --> Controller Class Initialized
INFO - 2024-10-23 21:08:49 --> Config Class Initialized
INFO - 2024-10-23 21:08:49 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:08:49 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:08:49 --> Utf8 Class Initialized
INFO - 2024-10-23 21:08:49 --> URI Class Initialized
DEBUG - 2024-10-23 21:08:49 --> No URI present. Default controller set.
INFO - 2024-10-23 21:08:49 --> Router Class Initialized
INFO - 2024-10-23 21:08:49 --> Output Class Initialized
INFO - 2024-10-23 21:08:49 --> Security Class Initialized
DEBUG - 2024-10-23 21:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:08:49 --> Input Class Initialized
INFO - 2024-10-23 21:08:49 --> Language Class Initialized
INFO - 2024-10-23 21:08:49 --> Loader Class Initialized
INFO - 2024-10-23 21:08:49 --> Helper loaded: url_helper
INFO - 2024-10-23 21:08:49 --> Helper loaded: html_helper
INFO - 2024-10-23 21:08:49 --> Helper loaded: file_helper
INFO - 2024-10-23 21:08:49 --> Helper loaded: string_helper
INFO - 2024-10-23 21:08:49 --> Helper loaded: form_helper
INFO - 2024-10-23 21:08:49 --> Helper loaded: my_helper
INFO - 2024-10-23 21:08:49 --> Database Driver Class Initialized
INFO - 2024-10-23 21:08:50 --> Config Class Initialized
INFO - 2024-10-23 21:08:50 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:08:50 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:08:50 --> Utf8 Class Initialized
INFO - 2024-10-23 21:08:50 --> URI Class Initialized
DEBUG - 2024-10-23 21:08:50 --> No URI present. Default controller set.
INFO - 2024-10-23 21:08:50 --> Router Class Initialized
INFO - 2024-10-23 21:08:50 --> Output Class Initialized
INFO - 2024-10-23 21:08:50 --> Security Class Initialized
DEBUG - 2024-10-23 21:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:08:50 --> Input Class Initialized
INFO - 2024-10-23 21:08:50 --> Language Class Initialized
INFO - 2024-10-23 21:08:50 --> Loader Class Initialized
INFO - 2024-10-23 21:08:50 --> Helper loaded: url_helper
INFO - 2024-10-23 21:08:50 --> Helper loaded: html_helper
INFO - 2024-10-23 21:08:50 --> Helper loaded: file_helper
INFO - 2024-10-23 21:08:50 --> Helper loaded: string_helper
INFO - 2024-10-23 21:08:50 --> Helper loaded: form_helper
INFO - 2024-10-23 21:08:50 --> Helper loaded: my_helper
INFO - 2024-10-23 21:08:50 --> Database Driver Class Initialized
INFO - 2024-10-23 21:08:51 --> Upload Class Initialized
INFO - 2024-10-23 21:08:51 --> Email Class Initialized
INFO - 2024-10-23 21:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:08:51 --> Form Validation Class Initialized
INFO - 2024-10-23 21:08:51 --> Controller Class Initialized
INFO - 2024-10-23 21:08:51 --> Config Class Initialized
INFO - 2024-10-23 21:08:51 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:08:51 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:08:52 --> Config Class Initialized
INFO - 2024-10-23 21:08:52 --> Utf8 Class Initialized
INFO - 2024-10-23 21:08:52 --> Hooks Class Initialized
INFO - 2024-10-23 21:08:52 --> URI Class Initialized
DEBUG - 2024-10-23 21:08:52 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:08:52 --> Utf8 Class Initialized
INFO - 2024-10-23 21:08:52 --> URI Class Initialized
INFO - 2024-10-23 21:08:52 --> Router Class Initialized
INFO - 2024-10-23 21:08:52 --> Router Class Initialized
INFO - 2024-10-23 21:08:52 --> Output Class Initialized
INFO - 2024-10-23 21:08:52 --> Output Class Initialized
INFO - 2024-10-23 21:08:52 --> Security Class Initialized
INFO - 2024-10-23 21:08:52 --> Security Class Initialized
DEBUG - 2024-10-23 21:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 21:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:08:52 --> Input Class Initialized
INFO - 2024-10-23 21:08:52 --> Language Class Initialized
INFO - 2024-10-23 21:08:52 --> Input Class Initialized
INFO - 2024-10-23 21:08:52 --> Language Class Initialized
INFO - 2024-10-23 21:08:52 --> Loader Class Initialized
INFO - 2024-10-23 21:08:52 --> Loader Class Initialized
INFO - 2024-10-23 21:08:52 --> Helper loaded: url_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: url_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: html_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: html_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: file_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: file_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: string_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: string_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: form_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: form_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: my_helper
INFO - 2024-10-23 21:08:52 --> Helper loaded: my_helper
INFO - 2024-10-23 21:08:52 --> Database Driver Class Initialized
INFO - 2024-10-23 21:08:52 --> Database Driver Class Initialized
INFO - 2024-10-23 21:08:53 --> Upload Class Initialized
INFO - 2024-10-23 21:08:53 --> Email Class Initialized
INFO - 2024-10-23 21:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:08:53 --> Form Validation Class Initialized
INFO - 2024-10-23 21:08:53 --> Controller Class Initialized
INFO - 2024-10-23 21:08:54 --> Upload Class Initialized
INFO - 2024-10-23 21:08:54 --> Email Class Initialized
INFO - 2024-10-23 21:08:54 --> Upload Class Initialized
INFO - 2024-10-23 21:08:54 --> Email Class Initialized
INFO - 2024-10-23 21:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:08:54 --> Form Validation Class Initialized
INFO - 2024-10-23 21:08:54 --> Controller Class Initialized
INFO - 2024-10-23 21:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:08:54 --> Form Validation Class Initialized
INFO - 2024-10-23 21:08:54 --> Controller Class Initialized
INFO - 2024-10-23 21:08:54 --> Config Class Initialized
INFO - 2024-10-23 21:08:54 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:08:54 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:08:54 --> Utf8 Class Initialized
INFO - 2024-10-23 21:08:54 --> URI Class Initialized
INFO - 2024-10-23 21:08:54 --> Router Class Initialized
INFO - 2024-10-23 21:08:54 --> Output Class Initialized
INFO - 2024-10-23 21:08:54 --> Security Class Initialized
DEBUG - 2024-10-23 21:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:08:54 --> Input Class Initialized
INFO - 2024-10-23 21:08:54 --> Language Class Initialized
INFO - 2024-10-23 21:08:54 --> Loader Class Initialized
INFO - 2024-10-23 21:08:54 --> Helper loaded: url_helper
INFO - 2024-10-23 21:08:54 --> Helper loaded: html_helper
INFO - 2024-10-23 21:08:54 --> Helper loaded: file_helper
INFO - 2024-10-23 21:08:54 --> Helper loaded: string_helper
INFO - 2024-10-23 21:08:54 --> Helper loaded: form_helper
INFO - 2024-10-23 21:08:54 --> Helper loaded: my_helper
INFO - 2024-10-23 21:08:54 --> Database Driver Class Initialized
INFO - 2024-10-23 21:08:56 --> Upload Class Initialized
INFO - 2024-10-23 21:08:56 --> Email Class Initialized
INFO - 2024-10-23 21:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:08:56 --> Form Validation Class Initialized
INFO - 2024-10-23 21:08:56 --> Controller Class Initialized
INFO - 2024-10-23 21:09:33 --> Config Class Initialized
INFO - 2024-10-23 21:09:33 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:09:33 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:09:33 --> Utf8 Class Initialized
INFO - 2024-10-23 21:09:33 --> URI Class Initialized
DEBUG - 2024-10-23 21:09:33 --> No URI present. Default controller set.
INFO - 2024-10-23 21:09:33 --> Router Class Initialized
INFO - 2024-10-23 21:09:33 --> Output Class Initialized
INFO - 2024-10-23 21:09:33 --> Security Class Initialized
DEBUG - 2024-10-23 21:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:09:33 --> Config Class Initialized
INFO - 2024-10-23 21:09:33 --> Input Class Initialized
INFO - 2024-10-23 21:09:33 --> Hooks Class Initialized
INFO - 2024-10-23 21:09:33 --> Language Class Initialized
DEBUG - 2024-10-23 21:09:33 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:09:33 --> Loader Class Initialized
INFO - 2024-10-23 21:09:33 --> Utf8 Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: url_helper
INFO - 2024-10-23 21:09:34 --> URI Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: html_helper
DEBUG - 2024-10-23 21:09:34 --> No URI present. Default controller set.
INFO - 2024-10-23 21:09:34 --> Helper loaded: file_helper
INFO - 2024-10-23 21:09:34 --> Router Class Initialized
INFO - 2024-10-23 21:09:34 --> Output Class Initialized
INFO - 2024-10-23 21:09:34 --> Config Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: string_helper
INFO - 2024-10-23 21:09:34 --> Security Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: form_helper
INFO - 2024-10-23 21:09:34 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-23 21:09:34 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:09:34 --> Helper loaded: my_helper
INFO - 2024-10-23 21:09:34 --> Database Driver Class Initialized
INFO - 2024-10-23 21:09:34 --> Input Class Initialized
INFO - 2024-10-23 21:09:34 --> Utf8 Class Initialized
INFO - 2024-10-23 21:09:34 --> URI Class Initialized
INFO - 2024-10-23 21:09:34 --> Language Class Initialized
DEBUG - 2024-10-23 21:09:34 --> No URI present. Default controller set.
INFO - 2024-10-23 21:09:34 --> Loader Class Initialized
INFO - 2024-10-23 21:09:34 --> Router Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: url_helper
INFO - 2024-10-23 21:09:34 --> Output Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: html_helper
INFO - 2024-10-23 21:09:34 --> Security Class Initialized
DEBUG - 2024-10-23 21:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:09:34 --> Helper loaded: file_helper
INFO - 2024-10-23 21:09:34 --> Input Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: string_helper
INFO - 2024-10-23 21:09:34 --> Language Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: form_helper
INFO - 2024-10-23 21:09:34 --> Helper loaded: my_helper
INFO - 2024-10-23 21:09:34 --> Loader Class Initialized
INFO - 2024-10-23 21:09:34 --> Database Driver Class Initialized
INFO - 2024-10-23 21:09:34 --> Helper loaded: url_helper
INFO - 2024-10-23 21:09:34 --> Helper loaded: html_helper
INFO - 2024-10-23 21:09:34 --> Helper loaded: file_helper
INFO - 2024-10-23 21:09:34 --> Helper loaded: string_helper
INFO - 2024-10-23 21:09:34 --> Helper loaded: form_helper
INFO - 2024-10-23 21:09:34 --> Helper loaded: my_helper
INFO - 2024-10-23 21:09:34 --> Database Driver Class Initialized
INFO - 2024-10-23 21:09:36 --> Upload Class Initialized
INFO - 2024-10-23 21:09:36 --> Email Class Initialized
INFO - 2024-10-23 21:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:09:36 --> Form Validation Class Initialized
INFO - 2024-10-23 21:09:36 --> Controller Class Initialized
INFO - 2024-10-23 21:09:36 --> Upload Class Initialized
INFO - 2024-10-23 21:09:36 --> Email Class Initialized
INFO - 2024-10-23 21:09:36 --> Upload Class Initialized
INFO - 2024-10-23 21:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:09:36 --> Email Class Initialized
INFO - 2024-10-23 21:09:36 --> Form Validation Class Initialized
INFO - 2024-10-23 21:09:36 --> Controller Class Initialized
INFO - 2024-10-23 21:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:09:36 --> Form Validation Class Initialized
INFO - 2024-10-23 21:09:36 --> Controller Class Initialized
INFO - 2024-10-23 21:09:37 --> Config Class Initialized
INFO - 2024-10-23 21:09:37 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:09:37 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:09:37 --> Utf8 Class Initialized
INFO - 2024-10-23 21:09:37 --> URI Class Initialized
INFO - 2024-10-23 21:09:37 --> Router Class Initialized
INFO - 2024-10-23 21:09:37 --> Output Class Initialized
INFO - 2024-10-23 21:09:37 --> Security Class Initialized
DEBUG - 2024-10-23 21:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:09:37 --> Input Class Initialized
INFO - 2024-10-23 21:09:37 --> Language Class Initialized
ERROR - 2024-10-23 21:09:37 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-23 21:09:48 --> Config Class Initialized
INFO - 2024-10-23 21:09:48 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:09:48 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:09:48 --> Utf8 Class Initialized
INFO - 2024-10-23 21:09:48 --> URI Class Initialized
DEBUG - 2024-10-23 21:09:48 --> No URI present. Default controller set.
INFO - 2024-10-23 21:09:48 --> Router Class Initialized
INFO - 2024-10-23 21:09:48 --> Output Class Initialized
INFO - 2024-10-23 21:09:48 --> Security Class Initialized
DEBUG - 2024-10-23 21:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:09:48 --> Input Class Initialized
INFO - 2024-10-23 21:09:48 --> Language Class Initialized
INFO - 2024-10-23 21:09:48 --> Loader Class Initialized
INFO - 2024-10-23 21:09:48 --> Helper loaded: url_helper
INFO - 2024-10-23 21:09:48 --> Helper loaded: html_helper
INFO - 2024-10-23 21:09:48 --> Helper loaded: file_helper
INFO - 2024-10-23 21:09:48 --> Helper loaded: string_helper
INFO - 2024-10-23 21:09:48 --> Helper loaded: form_helper
INFO - 2024-10-23 21:09:48 --> Helper loaded: my_helper
INFO - 2024-10-23 21:09:48 --> Database Driver Class Initialized
INFO - 2024-10-23 21:09:50 --> Upload Class Initialized
INFO - 2024-10-23 21:09:50 --> Email Class Initialized
INFO - 2024-10-23 21:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:09:50 --> Form Validation Class Initialized
INFO - 2024-10-23 21:09:50 --> Controller Class Initialized
INFO - 2024-10-23 21:09:56 --> Config Class Initialized
INFO - 2024-10-23 21:09:56 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:09:56 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:09:56 --> Utf8 Class Initialized
INFO - 2024-10-23 21:09:56 --> URI Class Initialized
DEBUG - 2024-10-23 21:09:56 --> No URI present. Default controller set.
INFO - 2024-10-23 21:09:56 --> Router Class Initialized
INFO - 2024-10-23 21:09:56 --> Output Class Initialized
INFO - 2024-10-23 21:09:56 --> Security Class Initialized
DEBUG - 2024-10-23 21:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:09:56 --> Input Class Initialized
INFO - 2024-10-23 21:09:56 --> Language Class Initialized
INFO - 2024-10-23 21:09:56 --> Loader Class Initialized
INFO - 2024-10-23 21:09:57 --> Helper loaded: url_helper
INFO - 2024-10-23 21:09:57 --> Helper loaded: html_helper
INFO - 2024-10-23 21:09:57 --> Helper loaded: file_helper
INFO - 2024-10-23 21:09:57 --> Helper loaded: string_helper
INFO - 2024-10-23 21:09:57 --> Helper loaded: form_helper
INFO - 2024-10-23 21:09:57 --> Helper loaded: my_helper
INFO - 2024-10-23 21:09:57 --> Database Driver Class Initialized
INFO - 2024-10-23 21:09:59 --> Upload Class Initialized
INFO - 2024-10-23 21:09:59 --> Email Class Initialized
INFO - 2024-10-23 21:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:09:59 --> Form Validation Class Initialized
INFO - 2024-10-23 21:09:59 --> Controller Class Initialized
INFO - 2024-10-23 21:09:59 --> Config Class Initialized
INFO - 2024-10-23 21:09:59 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:09:59 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:09:59 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:00 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:00 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:00 --> Router Class Initialized
INFO - 2024-10-23 21:10:00 --> Output Class Initialized
INFO - 2024-10-23 21:10:00 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:00 --> Input Class Initialized
INFO - 2024-10-23 21:10:00 --> Language Class Initialized
INFO - 2024-10-23 21:10:00 --> Loader Class Initialized
INFO - 2024-10-23 21:10:00 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:00 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:00 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:00 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:00 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:00 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:00 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:02 --> Config Class Initialized
INFO - 2024-10-23 21:10:02 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:02 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:02 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:02 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:02 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:02 --> Router Class Initialized
INFO - 2024-10-23 21:10:02 --> Output Class Initialized
INFO - 2024-10-23 21:10:02 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:02 --> Input Class Initialized
INFO - 2024-10-23 21:10:02 --> Language Class Initialized
INFO - 2024-10-23 21:10:02 --> Loader Class Initialized
INFO - 2024-10-23 21:10:02 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:02 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:02 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:02 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:02 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:02 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:02 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:02 --> Upload Class Initialized
INFO - 2024-10-23 21:10:02 --> Email Class Initialized
INFO - 2024-10-23 21:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:02 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:02 --> Controller Class Initialized
INFO - 2024-10-23 21:10:04 --> Upload Class Initialized
INFO - 2024-10-23 21:10:04 --> Email Class Initialized
INFO - 2024-10-23 21:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:04 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:04 --> Controller Class Initialized
INFO - 2024-10-23 21:10:17 --> Config Class Initialized
INFO - 2024-10-23 21:10:17 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:17 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:17 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:17 --> URI Class Initialized
INFO - 2024-10-23 21:10:17 --> Router Class Initialized
INFO - 2024-10-23 21:10:17 --> Output Class Initialized
INFO - 2024-10-23 21:10:17 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:17 --> Input Class Initialized
INFO - 2024-10-23 21:10:17 --> Language Class Initialized
INFO - 2024-10-23 21:10:17 --> Loader Class Initialized
INFO - 2024-10-23 21:10:17 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:17 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:17 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:17 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:17 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:17 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:17 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:19 --> Upload Class Initialized
INFO - 2024-10-23 21:10:19 --> Email Class Initialized
INFO - 2024-10-23 21:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:19 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:19 --> Controller Class Initialized
INFO - 2024-10-23 21:10:19 --> Config Class Initialized
INFO - 2024-10-23 21:10:20 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:20 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:20 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:20 --> URI Class Initialized
INFO - 2024-10-23 21:10:20 --> Router Class Initialized
INFO - 2024-10-23 21:10:20 --> Output Class Initialized
INFO - 2024-10-23 21:10:20 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:20 --> Input Class Initialized
INFO - 2024-10-23 21:10:20 --> Language Class Initialized
ERROR - 2024-10-23 21:10:20 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-23 21:10:20 --> Config Class Initialized
INFO - 2024-10-23 21:10:20 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:20 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:20 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:20 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:20 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:20 --> Router Class Initialized
INFO - 2024-10-23 21:10:20 --> Output Class Initialized
INFO - 2024-10-23 21:10:20 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:20 --> Input Class Initialized
INFO - 2024-10-23 21:10:20 --> Language Class Initialized
INFO - 2024-10-23 21:10:20 --> Loader Class Initialized
INFO - 2024-10-23 21:10:20 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:20 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:20 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:20 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:20 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:20 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:20 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:22 --> Upload Class Initialized
INFO - 2024-10-23 21:10:22 --> Email Class Initialized
INFO - 2024-10-23 21:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:22 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:22 --> Controller Class Initialized
INFO - 2024-10-23 21:10:25 --> Config Class Initialized
INFO - 2024-10-23 21:10:25 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:25 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:25 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:25 --> URI Class Initialized
INFO - 2024-10-23 21:10:25 --> Router Class Initialized
INFO - 2024-10-23 21:10:25 --> Output Class Initialized
INFO - 2024-10-23 21:10:25 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:25 --> Input Class Initialized
INFO - 2024-10-23 21:10:25 --> Language Class Initialized
INFO - 2024-10-23 21:10:25 --> Loader Class Initialized
INFO - 2024-10-23 21:10:25 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:25 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:25 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:25 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:25 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:25 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:25 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:26 --> Config Class Initialized
INFO - 2024-10-23 21:10:26 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:26 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:26 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:26 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:26 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:26 --> Router Class Initialized
INFO - 2024-10-23 21:10:26 --> Output Class Initialized
INFO - 2024-10-23 21:10:26 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:26 --> Input Class Initialized
INFO - 2024-10-23 21:10:26 --> Language Class Initialized
INFO - 2024-10-23 21:10:26 --> Loader Class Initialized
INFO - 2024-10-23 21:10:26 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:26 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:26 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:26 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:26 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:26 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:26 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:27 --> Upload Class Initialized
INFO - 2024-10-23 21:10:27 --> Email Class Initialized
INFO - 2024-10-23 21:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:27 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:27 --> Controller Class Initialized
INFO - 2024-10-23 21:10:27 --> Config Class Initialized
INFO - 2024-10-23 21:10:27 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:27 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:27 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:27 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:27 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:27 --> Router Class Initialized
INFO - 2024-10-23 21:10:27 --> Output Class Initialized
INFO - 2024-10-23 21:10:27 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:27 --> Input Class Initialized
INFO - 2024-10-23 21:10:27 --> Language Class Initialized
INFO - 2024-10-23 21:10:27 --> Loader Class Initialized
INFO - 2024-10-23 21:10:27 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:27 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:27 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:27 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:27 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:27 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:27 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:28 --> Upload Class Initialized
INFO - 2024-10-23 21:10:28 --> Email Class Initialized
INFO - 2024-10-23 21:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:28 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:28 --> Controller Class Initialized
INFO - 2024-10-23 21:10:29 --> Upload Class Initialized
INFO - 2024-10-23 21:10:29 --> Email Class Initialized
INFO - 2024-10-23 21:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:30 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:30 --> Controller Class Initialized
INFO - 2024-10-23 21:10:31 --> Config Class Initialized
INFO - 2024-10-23 21:10:31 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:31 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:31 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:31 --> URI Class Initialized
INFO - 2024-10-23 21:10:31 --> Router Class Initialized
INFO - 2024-10-23 21:10:31 --> Output Class Initialized
INFO - 2024-10-23 21:10:31 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:31 --> Input Class Initialized
INFO - 2024-10-23 21:10:31 --> Language Class Initialized
INFO - 2024-10-23 21:10:31 --> Loader Class Initialized
INFO - 2024-10-23 21:10:31 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:31 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:31 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:31 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:31 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:31 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:31 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:33 --> Upload Class Initialized
INFO - 2024-10-23 21:10:33 --> Email Class Initialized
INFO - 2024-10-23 21:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:33 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:34 --> Controller Class Initialized
INFO - 2024-10-23 21:10:34 --> Config Class Initialized
INFO - 2024-10-23 21:10:34 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:34 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:34 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:34 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:34 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:35 --> Router Class Initialized
INFO - 2024-10-23 21:10:35 --> Output Class Initialized
INFO - 2024-10-23 21:10:35 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:35 --> Input Class Initialized
INFO - 2024-10-23 21:10:35 --> Language Class Initialized
INFO - 2024-10-23 21:10:35 --> Loader Class Initialized
INFO - 2024-10-23 21:10:35 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:35 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:35 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:35 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:35 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:35 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:35 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:37 --> Upload Class Initialized
INFO - 2024-10-23 21:10:37 --> Email Class Initialized
INFO - 2024-10-23 21:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:37 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:37 --> Controller Class Initialized
INFO - 2024-10-23 21:10:38 --> Config Class Initialized
INFO - 2024-10-23 21:10:39 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:39 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:39 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:39 --> URI Class Initialized
INFO - 2024-10-23 21:10:39 --> Router Class Initialized
INFO - 2024-10-23 21:10:39 --> Output Class Initialized
INFO - 2024-10-23 21:10:39 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:39 --> Input Class Initialized
INFO - 2024-10-23 21:10:39 --> Language Class Initialized
INFO - 2024-10-23 21:10:39 --> Loader Class Initialized
INFO - 2024-10-23 21:10:39 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:39 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:39 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:39 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:39 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:39 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:39 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:41 --> Upload Class Initialized
INFO - 2024-10-23 21:10:41 --> Email Class Initialized
INFO - 2024-10-23 21:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:41 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:41 --> Controller Class Initialized
INFO - 2024-10-23 21:10:41 --> Config Class Initialized
INFO - 2024-10-23 21:10:41 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:41 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:41 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:41 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:41 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:41 --> Router Class Initialized
INFO - 2024-10-23 21:10:41 --> Output Class Initialized
INFO - 2024-10-23 21:10:41 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:42 --> Input Class Initialized
INFO - 2024-10-23 21:10:42 --> Language Class Initialized
INFO - 2024-10-23 21:10:42 --> Loader Class Initialized
INFO - 2024-10-23 21:10:42 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:42 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:42 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:42 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:42 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:42 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:42 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:44 --> Config Class Initialized
INFO - 2024-10-23 21:10:44 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:44 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:44 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:44 --> URI Class Initialized
INFO - 2024-10-23 21:10:44 --> Router Class Initialized
INFO - 2024-10-23 21:10:44 --> Output Class Initialized
INFO - 2024-10-23 21:10:44 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:44 --> Input Class Initialized
INFO - 2024-10-23 21:10:44 --> Language Class Initialized
ERROR - 2024-10-23 21:10:44 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-23 21:10:44 --> Upload Class Initialized
INFO - 2024-10-23 21:10:44 --> Email Class Initialized
INFO - 2024-10-23 21:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:44 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:44 --> Controller Class Initialized
INFO - 2024-10-23 21:10:46 --> Config Class Initialized
INFO - 2024-10-23 21:10:46 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:46 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:46 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:46 --> URI Class Initialized
INFO - 2024-10-23 21:10:46 --> Router Class Initialized
INFO - 2024-10-23 21:10:46 --> Output Class Initialized
INFO - 2024-10-23 21:10:46 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:46 --> Input Class Initialized
INFO - 2024-10-23 21:10:46 --> Language Class Initialized
INFO - 2024-10-23 21:10:46 --> Loader Class Initialized
INFO - 2024-10-23 21:10:46 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:46 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:46 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:46 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:46 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:46 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:46 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:48 --> Upload Class Initialized
INFO - 2024-10-23 21:10:48 --> Email Class Initialized
INFO - 2024-10-23 21:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:48 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:48 --> Controller Class Initialized
INFO - 2024-10-23 21:10:48 --> Config Class Initialized
INFO - 2024-10-23 21:10:48 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:48 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:48 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:48 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:48 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:48 --> Router Class Initialized
INFO - 2024-10-23 21:10:48 --> Output Class Initialized
INFO - 2024-10-23 21:10:48 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:48 --> Input Class Initialized
INFO - 2024-10-23 21:10:48 --> Language Class Initialized
INFO - 2024-10-23 21:10:48 --> Loader Class Initialized
INFO - 2024-10-23 21:10:48 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:49 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:49 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:49 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:49 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:49 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:49 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:51 --> Upload Class Initialized
INFO - 2024-10-23 21:10:51 --> Email Class Initialized
INFO - 2024-10-23 21:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:51 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:51 --> Controller Class Initialized
INFO - 2024-10-23 21:10:52 --> Config Class Initialized
INFO - 2024-10-23 21:10:52 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:52 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:52 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:52 --> URI Class Initialized
INFO - 2024-10-23 21:10:52 --> Router Class Initialized
INFO - 2024-10-23 21:10:52 --> Output Class Initialized
INFO - 2024-10-23 21:10:52 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:52 --> Input Class Initialized
INFO - 2024-10-23 21:10:52 --> Language Class Initialized
INFO - 2024-10-23 21:10:52 --> Loader Class Initialized
INFO - 2024-10-23 21:10:53 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:53 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:53 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:53 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:53 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:53 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:53 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:55 --> Upload Class Initialized
INFO - 2024-10-23 21:10:55 --> Email Class Initialized
INFO - 2024-10-23 21:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:55 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:55 --> Controller Class Initialized
INFO - 2024-10-23 21:10:55 --> Config Class Initialized
INFO - 2024-10-23 21:10:55 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:10:55 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:10:55 --> Utf8 Class Initialized
INFO - 2024-10-23 21:10:55 --> URI Class Initialized
DEBUG - 2024-10-23 21:10:55 --> No URI present. Default controller set.
INFO - 2024-10-23 21:10:55 --> Router Class Initialized
INFO - 2024-10-23 21:10:55 --> Output Class Initialized
INFO - 2024-10-23 21:10:55 --> Security Class Initialized
DEBUG - 2024-10-23 21:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:10:55 --> Input Class Initialized
INFO - 2024-10-23 21:10:55 --> Language Class Initialized
INFO - 2024-10-23 21:10:55 --> Loader Class Initialized
INFO - 2024-10-23 21:10:55 --> Helper loaded: url_helper
INFO - 2024-10-23 21:10:55 --> Helper loaded: html_helper
INFO - 2024-10-23 21:10:55 --> Helper loaded: file_helper
INFO - 2024-10-23 21:10:55 --> Helper loaded: string_helper
INFO - 2024-10-23 21:10:55 --> Helper loaded: form_helper
INFO - 2024-10-23 21:10:55 --> Helper loaded: my_helper
INFO - 2024-10-23 21:10:55 --> Database Driver Class Initialized
INFO - 2024-10-23 21:10:57 --> Upload Class Initialized
INFO - 2024-10-23 21:10:57 --> Email Class Initialized
INFO - 2024-10-23 21:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:10:57 --> Form Validation Class Initialized
INFO - 2024-10-23 21:10:57 --> Controller Class Initialized
INFO - 2024-10-23 21:11:00 --> Config Class Initialized
INFO - 2024-10-23 21:11:00 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:11:00 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:11:00 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:00 --> URI Class Initialized
INFO - 2024-10-23 21:11:00 --> Router Class Initialized
INFO - 2024-10-23 21:11:00 --> Output Class Initialized
INFO - 2024-10-23 21:11:00 --> Security Class Initialized
DEBUG - 2024-10-23 21:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:00 --> Input Class Initialized
INFO - 2024-10-23 21:11:00 --> Language Class Initialized
INFO - 2024-10-23 21:11:00 --> Loader Class Initialized
INFO - 2024-10-23 21:11:00 --> Helper loaded: url_helper
INFO - 2024-10-23 21:11:00 --> Helper loaded: html_helper
INFO - 2024-10-23 21:11:00 --> Helper loaded: file_helper
INFO - 2024-10-23 21:11:00 --> Helper loaded: string_helper
INFO - 2024-10-23 21:11:00 --> Helper loaded: form_helper
INFO - 2024-10-23 21:11:00 --> Helper loaded: my_helper
INFO - 2024-10-23 21:11:00 --> Database Driver Class Initialized
INFO - 2024-10-23 21:11:02 --> Upload Class Initialized
INFO - 2024-10-23 21:11:02 --> Email Class Initialized
INFO - 2024-10-23 21:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:11:02 --> Form Validation Class Initialized
INFO - 2024-10-23 21:11:02 --> Controller Class Initialized
INFO - 2024-10-23 21:11:03 --> Config Class Initialized
INFO - 2024-10-23 21:11:03 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:11:03 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:11:03 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:03 --> URI Class Initialized
DEBUG - 2024-10-23 21:11:03 --> No URI present. Default controller set.
INFO - 2024-10-23 21:11:03 --> Router Class Initialized
INFO - 2024-10-23 21:11:03 --> Output Class Initialized
INFO - 2024-10-23 21:11:03 --> Security Class Initialized
DEBUG - 2024-10-23 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:03 --> Input Class Initialized
INFO - 2024-10-23 21:11:03 --> Language Class Initialized
INFO - 2024-10-23 21:11:03 --> Loader Class Initialized
INFO - 2024-10-23 21:11:03 --> Helper loaded: url_helper
INFO - 2024-10-23 21:11:03 --> Helper loaded: html_helper
INFO - 2024-10-23 21:11:03 --> Helper loaded: file_helper
INFO - 2024-10-23 21:11:03 --> Helper loaded: string_helper
INFO - 2024-10-23 21:11:03 --> Helper loaded: form_helper
INFO - 2024-10-23 21:11:03 --> Helper loaded: my_helper
INFO - 2024-10-23 21:11:03 --> Database Driver Class Initialized
INFO - 2024-10-23 21:11:05 --> Upload Class Initialized
INFO - 2024-10-23 21:11:05 --> Email Class Initialized
INFO - 2024-10-23 21:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:11:05 --> Form Validation Class Initialized
INFO - 2024-10-23 21:11:05 --> Controller Class Initialized
INFO - 2024-10-23 21:11:06 --> Config Class Initialized
INFO - 2024-10-23 21:11:06 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:11:06 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:11:06 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:06 --> URI Class Initialized
INFO - 2024-10-23 21:11:06 --> Router Class Initialized
INFO - 2024-10-23 21:11:06 --> Output Class Initialized
INFO - 2024-10-23 21:11:06 --> Security Class Initialized
DEBUG - 2024-10-23 21:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:06 --> Input Class Initialized
INFO - 2024-10-23 21:11:06 --> Language Class Initialized
INFO - 2024-10-23 21:11:06 --> Loader Class Initialized
INFO - 2024-10-23 21:11:06 --> Helper loaded: url_helper
INFO - 2024-10-23 21:11:06 --> Helper loaded: html_helper
INFO - 2024-10-23 21:11:06 --> Helper loaded: file_helper
INFO - 2024-10-23 21:11:06 --> Helper loaded: string_helper
INFO - 2024-10-23 21:11:06 --> Helper loaded: form_helper
INFO - 2024-10-23 21:11:06 --> Helper loaded: my_helper
INFO - 2024-10-23 21:11:06 --> Database Driver Class Initialized
INFO - 2024-10-23 21:11:08 --> Upload Class Initialized
INFO - 2024-10-23 21:11:08 --> Email Class Initialized
INFO - 2024-10-23 21:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:11:08 --> Form Validation Class Initialized
INFO - 2024-10-23 21:11:08 --> Controller Class Initialized
INFO - 2024-10-23 21:11:08 --> Config Class Initialized
INFO - 2024-10-23 21:11:08 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:11:08 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:11:08 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:08 --> URI Class Initialized
DEBUG - 2024-10-23 21:11:08 --> No URI present. Default controller set.
INFO - 2024-10-23 21:11:08 --> Router Class Initialized
INFO - 2024-10-23 21:11:08 --> Output Class Initialized
INFO - 2024-10-23 21:11:08 --> Security Class Initialized
DEBUG - 2024-10-23 21:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:08 --> Input Class Initialized
INFO - 2024-10-23 21:11:08 --> Language Class Initialized
INFO - 2024-10-23 21:11:08 --> Loader Class Initialized
INFO - 2024-10-23 21:11:08 --> Helper loaded: url_helper
INFO - 2024-10-23 21:11:08 --> Helper loaded: html_helper
INFO - 2024-10-23 21:11:08 --> Helper loaded: file_helper
INFO - 2024-10-23 21:11:08 --> Helper loaded: string_helper
INFO - 2024-10-23 21:11:08 --> Helper loaded: form_helper
INFO - 2024-10-23 21:11:08 --> Helper loaded: my_helper
INFO - 2024-10-23 21:11:08 --> Database Driver Class Initialized
INFO - 2024-10-23 21:11:10 --> Upload Class Initialized
INFO - 2024-10-23 21:11:10 --> Email Class Initialized
INFO - 2024-10-23 21:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:11:10 --> Form Validation Class Initialized
INFO - 2024-10-23 21:11:10 --> Controller Class Initialized
INFO - 2024-10-23 21:11:54 --> Config Class Initialized
INFO - 2024-10-23 21:11:54 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:11:54 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:11:54 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:54 --> URI Class Initialized
DEBUG - 2024-10-23 21:11:54 --> No URI present. Default controller set.
INFO - 2024-10-23 21:11:54 --> Router Class Initialized
INFO - 2024-10-23 21:11:54 --> Output Class Initialized
INFO - 2024-10-23 21:11:54 --> Config Class Initialized
INFO - 2024-10-23 21:11:54 --> Hooks Class Initialized
INFO - 2024-10-23 21:11:54 --> Security Class Initialized
DEBUG - 2024-10-23 21:11:54 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 21:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:54 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:54 --> URI Class Initialized
INFO - 2024-10-23 21:11:54 --> Input Class Initialized
INFO - 2024-10-23 21:11:54 --> Router Class Initialized
INFO - 2024-10-23 21:11:54 --> Language Class Initialized
INFO - 2024-10-23 21:11:54 --> Output Class Initialized
INFO - 2024-10-23 21:11:54 --> Security Class Initialized
INFO - 2024-10-23 21:11:54 --> Loader Class Initialized
INFO - 2024-10-23 21:11:54 --> Helper loaded: url_helper
DEBUG - 2024-10-23 21:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:54 --> Helper loaded: html_helper
INFO - 2024-10-23 21:11:54 --> Input Class Initialized
INFO - 2024-10-23 21:11:54 --> Helper loaded: file_helper
INFO - 2024-10-23 21:11:54 --> Helper loaded: string_helper
INFO - 2024-10-23 21:11:54 --> Language Class Initialized
INFO - 2024-10-23 21:11:54 --> Helper loaded: form_helper
ERROR - 2024-10-23 21:11:54 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:11:54 --> Helper loaded: my_helper
INFO - 2024-10-23 21:11:54 --> Database Driver Class Initialized
INFO - 2024-10-23 21:11:56 --> Config Class Initialized
INFO - 2024-10-23 21:11:56 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:11:56 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:11:56 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:56 --> URI Class Initialized
INFO - 2024-10-23 21:11:56 --> Router Class Initialized
INFO - 2024-10-23 21:11:56 --> Output Class Initialized
INFO - 2024-10-23 21:11:56 --> Security Class Initialized
DEBUG - 2024-10-23 21:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:56 --> Input Class Initialized
INFO - 2024-10-23 21:11:56 --> Language Class Initialized
ERROR - 2024-10-23 21:11:56 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:11:56 --> Config Class Initialized
INFO - 2024-10-23 21:11:56 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:11:56 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:11:56 --> Utf8 Class Initialized
INFO - 2024-10-23 21:11:56 --> URI Class Initialized
INFO - 2024-10-23 21:11:57 --> Upload Class Initialized
DEBUG - 2024-10-23 21:11:57 --> No URI present. Default controller set.
INFO - 2024-10-23 21:11:57 --> Router Class Initialized
INFO - 2024-10-23 21:11:57 --> Email Class Initialized
INFO - 2024-10-23 21:11:57 --> Output Class Initialized
INFO - 2024-10-23 21:11:57 --> Security Class Initialized
DEBUG - 2024-10-23 21:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:11:57 --> Input Class Initialized
INFO - 2024-10-23 21:11:57 --> Form Validation Class Initialized
INFO - 2024-10-23 21:11:57 --> Language Class Initialized
INFO - 2024-10-23 21:11:57 --> Controller Class Initialized
INFO - 2024-10-23 21:11:57 --> Loader Class Initialized
INFO - 2024-10-23 21:11:57 --> Helper loaded: url_helper
INFO - 2024-10-23 21:11:57 --> Helper loaded: html_helper
INFO - 2024-10-23 21:11:57 --> Helper loaded: file_helper
INFO - 2024-10-23 21:11:57 --> Helper loaded: string_helper
INFO - 2024-10-23 21:11:57 --> Helper loaded: form_helper
INFO - 2024-10-23 21:11:57 --> Helper loaded: my_helper
INFO - 2024-10-23 21:11:57 --> Database Driver Class Initialized
INFO - 2024-10-23 21:11:59 --> Config Class Initialized
INFO - 2024-10-23 21:12:00 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:00 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:00 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:00 --> URI Class Initialized
DEBUG - 2024-10-23 21:12:00 --> No URI present. Default controller set.
INFO - 2024-10-23 21:12:00 --> Router Class Initialized
INFO - 2024-10-23 21:12:00 --> Upload Class Initialized
INFO - 2024-10-23 21:12:00 --> Output Class Initialized
INFO - 2024-10-23 21:12:00 --> Email Class Initialized
INFO - 2024-10-23 21:12:00 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:00 --> Input Class Initialized
INFO - 2024-10-23 21:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:12:00 --> Language Class Initialized
INFO - 2024-10-23 21:12:00 --> Form Validation Class Initialized
INFO - 2024-10-23 21:12:00 --> Loader Class Initialized
INFO - 2024-10-23 21:12:00 --> Controller Class Initialized
INFO - 2024-10-23 21:12:00 --> Helper loaded: url_helper
INFO - 2024-10-23 21:12:00 --> Helper loaded: html_helper
INFO - 2024-10-23 21:12:00 --> Helper loaded: file_helper
INFO - 2024-10-23 21:12:00 --> Helper loaded: string_helper
INFO - 2024-10-23 21:12:00 --> Helper loaded: form_helper
INFO - 2024-10-23 21:12:00 --> Helper loaded: my_helper
INFO - 2024-10-23 21:12:00 --> Database Driver Class Initialized
INFO - 2024-10-23 21:12:00 --> Config Class Initialized
INFO - 2024-10-23 21:12:00 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:00 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:00 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:00 --> URI Class Initialized
INFO - 2024-10-23 21:12:00 --> Router Class Initialized
INFO - 2024-10-23 21:12:01 --> Output Class Initialized
INFO - 2024-10-23 21:12:01 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:01 --> Input Class Initialized
INFO - 2024-10-23 21:12:01 --> Language Class Initialized
ERROR - 2024-10-23 21:12:01 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:12:01 --> Config Class Initialized
INFO - 2024-10-23 21:12:01 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:01 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:01 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:01 --> URI Class Initialized
DEBUG - 2024-10-23 21:12:01 --> No URI present. Default controller set.
INFO - 2024-10-23 21:12:01 --> Router Class Initialized
INFO - 2024-10-23 21:12:01 --> Output Class Initialized
INFO - 2024-10-23 21:12:01 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:01 --> Input Class Initialized
INFO - 2024-10-23 21:12:01 --> Language Class Initialized
INFO - 2024-10-23 21:12:01 --> Loader Class Initialized
INFO - 2024-10-23 21:12:01 --> Helper loaded: url_helper
INFO - 2024-10-23 21:12:01 --> Helper loaded: html_helper
INFO - 2024-10-23 21:12:01 --> Helper loaded: file_helper
INFO - 2024-10-23 21:12:01 --> Helper loaded: string_helper
INFO - 2024-10-23 21:12:01 --> Helper loaded: form_helper
INFO - 2024-10-23 21:12:01 --> Helper loaded: my_helper
INFO - 2024-10-23 21:12:01 --> Database Driver Class Initialized
INFO - 2024-10-23 21:12:02 --> Config Class Initialized
INFO - 2024-10-23 21:12:02 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:02 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:02 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:02 --> URI Class Initialized
INFO - 2024-10-23 21:12:02 --> Router Class Initialized
INFO - 2024-10-23 21:12:02 --> Output Class Initialized
INFO - 2024-10-23 21:12:02 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:02 --> Input Class Initialized
INFO - 2024-10-23 21:12:02 --> Language Class Initialized
ERROR - 2024-10-23 21:12:02 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:12:02 --> Upload Class Initialized
INFO - 2024-10-23 21:12:02 --> Email Class Initialized
INFO - 2024-10-23 21:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:12:02 --> Form Validation Class Initialized
INFO - 2024-10-23 21:12:02 --> Controller Class Initialized
INFO - 2024-10-23 21:12:03 --> Upload Class Initialized
INFO - 2024-10-23 21:12:03 --> Email Class Initialized
INFO - 2024-10-23 21:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:12:04 --> Form Validation Class Initialized
INFO - 2024-10-23 21:12:04 --> Controller Class Initialized
INFO - 2024-10-23 21:12:12 --> Config Class Initialized
INFO - 2024-10-23 21:12:12 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:12 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:12 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:12 --> URI Class Initialized
INFO - 2024-10-23 21:12:12 --> Router Class Initialized
INFO - 2024-10-23 21:12:12 --> Output Class Initialized
INFO - 2024-10-23 21:12:12 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:12 --> Input Class Initialized
INFO - 2024-10-23 21:12:12 --> Language Class Initialized
ERROR - 2024-10-23 21:12:12 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-23 21:12:15 --> Config Class Initialized
INFO - 2024-10-23 21:12:15 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:15 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:15 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:15 --> URI Class Initialized
DEBUG - 2024-10-23 21:12:15 --> No URI present. Default controller set.
INFO - 2024-10-23 21:12:15 --> Router Class Initialized
INFO - 2024-10-23 21:12:15 --> Output Class Initialized
INFO - 2024-10-23 21:12:15 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:15 --> Input Class Initialized
INFO - 2024-10-23 21:12:15 --> Language Class Initialized
INFO - 2024-10-23 21:12:15 --> Loader Class Initialized
INFO - 2024-10-23 21:12:15 --> Helper loaded: url_helper
INFO - 2024-10-23 21:12:15 --> Helper loaded: html_helper
INFO - 2024-10-23 21:12:15 --> Helper loaded: file_helper
INFO - 2024-10-23 21:12:15 --> Helper loaded: string_helper
INFO - 2024-10-23 21:12:15 --> Helper loaded: form_helper
INFO - 2024-10-23 21:12:15 --> Helper loaded: my_helper
INFO - 2024-10-23 21:12:15 --> Database Driver Class Initialized
INFO - 2024-10-23 21:12:15 --> Config Class Initialized
INFO - 2024-10-23 21:12:15 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:15 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:15 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:15 --> URI Class Initialized
INFO - 2024-10-23 21:12:15 --> Router Class Initialized
INFO - 2024-10-23 21:12:15 --> Output Class Initialized
INFO - 2024-10-23 21:12:15 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:15 --> Input Class Initialized
INFO - 2024-10-23 21:12:15 --> Language Class Initialized
ERROR - 2024-10-23 21:12:15 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:12:17 --> Upload Class Initialized
INFO - 2024-10-23 21:12:17 --> Email Class Initialized
INFO - 2024-10-23 21:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:12:17 --> Form Validation Class Initialized
INFO - 2024-10-23 21:12:17 --> Controller Class Initialized
INFO - 2024-10-23 21:12:25 --> Config Class Initialized
INFO - 2024-10-23 21:12:25 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:25 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:25 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:25 --> URI Class Initialized
DEBUG - 2024-10-23 21:12:25 --> No URI present. Default controller set.
INFO - 2024-10-23 21:12:25 --> Router Class Initialized
INFO - 2024-10-23 21:12:25 --> Output Class Initialized
INFO - 2024-10-23 21:12:25 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:25 --> Input Class Initialized
INFO - 2024-10-23 21:12:25 --> Language Class Initialized
INFO - 2024-10-23 21:12:25 --> Loader Class Initialized
INFO - 2024-10-23 21:12:25 --> Helper loaded: url_helper
INFO - 2024-10-23 21:12:25 --> Helper loaded: html_helper
INFO - 2024-10-23 21:12:25 --> Helper loaded: file_helper
INFO - 2024-10-23 21:12:25 --> Helper loaded: string_helper
INFO - 2024-10-23 21:12:25 --> Helper loaded: form_helper
INFO - 2024-10-23 21:12:25 --> Helper loaded: my_helper
INFO - 2024-10-23 21:12:26 --> Database Driver Class Initialized
INFO - 2024-10-23 21:12:26 --> Config Class Initialized
INFO - 2024-10-23 21:12:27 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:27 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:27 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:27 --> URI Class Initialized
INFO - 2024-10-23 21:12:27 --> Router Class Initialized
INFO - 2024-10-23 21:12:27 --> Output Class Initialized
INFO - 2024-10-23 21:12:27 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:27 --> Input Class Initialized
INFO - 2024-10-23 21:12:27 --> Language Class Initialized
ERROR - 2024-10-23 21:12:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:12:28 --> Upload Class Initialized
INFO - 2024-10-23 21:12:28 --> Email Class Initialized
INFO - 2024-10-23 21:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:12:29 --> Form Validation Class Initialized
INFO - 2024-10-23 21:12:29 --> Controller Class Initialized
INFO - 2024-10-23 21:12:30 --> Config Class Initialized
INFO - 2024-10-23 21:12:30 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:30 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:30 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:30 --> URI Class Initialized
DEBUG - 2024-10-23 21:12:30 --> No URI present. Default controller set.
INFO - 2024-10-23 21:12:30 --> Router Class Initialized
INFO - 2024-10-23 21:12:30 --> Output Class Initialized
INFO - 2024-10-23 21:12:30 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:30 --> Input Class Initialized
INFO - 2024-10-23 21:12:30 --> Language Class Initialized
INFO - 2024-10-23 21:12:30 --> Loader Class Initialized
INFO - 2024-10-23 21:12:30 --> Helper loaded: url_helper
INFO - 2024-10-23 21:12:30 --> Helper loaded: html_helper
INFO - 2024-10-23 21:12:30 --> Helper loaded: file_helper
INFO - 2024-10-23 21:12:30 --> Helper loaded: string_helper
INFO - 2024-10-23 21:12:30 --> Helper loaded: form_helper
INFO - 2024-10-23 21:12:30 --> Helper loaded: my_helper
INFO - 2024-10-23 21:12:30 --> Database Driver Class Initialized
INFO - 2024-10-23 21:12:31 --> Config Class Initialized
INFO - 2024-10-23 21:12:31 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:31 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:31 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:31 --> URI Class Initialized
DEBUG - 2024-10-23 21:12:31 --> No URI present. Default controller set.
INFO - 2024-10-23 21:12:31 --> Router Class Initialized
INFO - 2024-10-23 21:12:31 --> Output Class Initialized
INFO - 2024-10-23 21:12:31 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:31 --> Input Class Initialized
INFO - 2024-10-23 21:12:31 --> Language Class Initialized
INFO - 2024-10-23 21:12:31 --> Loader Class Initialized
INFO - 2024-10-23 21:12:31 --> Helper loaded: url_helper
INFO - 2024-10-23 21:12:31 --> Helper loaded: html_helper
INFO - 2024-10-23 21:12:31 --> Helper loaded: file_helper
INFO - 2024-10-23 21:12:31 --> Helper loaded: string_helper
INFO - 2024-10-23 21:12:31 --> Helper loaded: form_helper
INFO - 2024-10-23 21:12:31 --> Helper loaded: my_helper
INFO - 2024-10-23 21:12:31 --> Database Driver Class Initialized
INFO - 2024-10-23 21:12:32 --> Config Class Initialized
INFO - 2024-10-23 21:12:32 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:32 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:32 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:32 --> URI Class Initialized
INFO - 2024-10-23 21:12:32 --> Router Class Initialized
INFO - 2024-10-23 21:12:32 --> Output Class Initialized
INFO - 2024-10-23 21:12:32 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:32 --> Input Class Initialized
INFO - 2024-10-23 21:12:32 --> Language Class Initialized
ERROR - 2024-10-23 21:12:32 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:12:33 --> Upload Class Initialized
INFO - 2024-10-23 21:12:33 --> Email Class Initialized
INFO - 2024-10-23 21:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:12:33 --> Form Validation Class Initialized
INFO - 2024-10-23 21:12:33 --> Controller Class Initialized
INFO - 2024-10-23 21:12:33 --> Config Class Initialized
INFO - 2024-10-23 21:12:33 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:12:33 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:12:33 --> Utf8 Class Initialized
INFO - 2024-10-23 21:12:33 --> URI Class Initialized
INFO - 2024-10-23 21:12:33 --> Router Class Initialized
INFO - 2024-10-23 21:12:33 --> Output Class Initialized
INFO - 2024-10-23 21:12:33 --> Security Class Initialized
DEBUG - 2024-10-23 21:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:12:33 --> Input Class Initialized
INFO - 2024-10-23 21:12:33 --> Language Class Initialized
ERROR - 2024-10-23 21:12:33 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-23 21:12:34 --> Upload Class Initialized
INFO - 2024-10-23 21:12:34 --> Email Class Initialized
INFO - 2024-10-23 21:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:12:34 --> Form Validation Class Initialized
INFO - 2024-10-23 21:12:34 --> Controller Class Initialized
INFO - 2024-10-23 21:14:15 --> Config Class Initialized
INFO - 2024-10-23 21:14:15 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:14:15 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:14:15 --> Utf8 Class Initialized
INFO - 2024-10-23 21:14:15 --> URI Class Initialized
DEBUG - 2024-10-23 21:14:15 --> No URI present. Default controller set.
INFO - 2024-10-23 21:14:15 --> Router Class Initialized
INFO - 2024-10-23 21:14:15 --> Output Class Initialized
INFO - 2024-10-23 21:14:15 --> Security Class Initialized
DEBUG - 2024-10-23 21:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:14:15 --> Input Class Initialized
INFO - 2024-10-23 21:14:15 --> Language Class Initialized
INFO - 2024-10-23 21:14:15 --> Loader Class Initialized
INFO - 2024-10-23 21:14:15 --> Helper loaded: url_helper
INFO - 2024-10-23 21:14:15 --> Helper loaded: html_helper
INFO - 2024-10-23 21:14:15 --> Helper loaded: file_helper
INFO - 2024-10-23 21:14:15 --> Helper loaded: string_helper
INFO - 2024-10-23 21:14:15 --> Helper loaded: form_helper
INFO - 2024-10-23 21:14:15 --> Helper loaded: my_helper
INFO - 2024-10-23 21:14:15 --> Database Driver Class Initialized
INFO - 2024-10-23 21:14:17 --> Upload Class Initialized
INFO - 2024-10-23 21:14:17 --> Email Class Initialized
INFO - 2024-10-23 21:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:14:17 --> Form Validation Class Initialized
INFO - 2024-10-23 21:14:17 --> Controller Class Initialized
INFO - 2024-10-23 21:22:32 --> Config Class Initialized
INFO - 2024-10-23 21:22:32 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:22:32 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:22:32 --> Utf8 Class Initialized
INFO - 2024-10-23 21:22:32 --> URI Class Initialized
DEBUG - 2024-10-23 21:22:32 --> No URI present. Default controller set.
INFO - 2024-10-23 21:22:32 --> Router Class Initialized
INFO - 2024-10-23 21:22:32 --> Output Class Initialized
INFO - 2024-10-23 21:22:32 --> Security Class Initialized
DEBUG - 2024-10-23 21:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:22:32 --> Input Class Initialized
INFO - 2024-10-23 21:22:32 --> Language Class Initialized
INFO - 2024-10-23 21:22:32 --> Loader Class Initialized
INFO - 2024-10-23 21:22:32 --> Helper loaded: url_helper
INFO - 2024-10-23 21:22:32 --> Helper loaded: html_helper
INFO - 2024-10-23 21:22:32 --> Helper loaded: file_helper
INFO - 2024-10-23 21:22:32 --> Helper loaded: string_helper
INFO - 2024-10-23 21:22:32 --> Helper loaded: form_helper
INFO - 2024-10-23 21:22:32 --> Helper loaded: my_helper
INFO - 2024-10-23 21:22:32 --> Database Driver Class Initialized
INFO - 2024-10-23 21:22:34 --> Upload Class Initialized
INFO - 2024-10-23 21:22:34 --> Email Class Initialized
INFO - 2024-10-23 21:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:22:34 --> Form Validation Class Initialized
INFO - 2024-10-23 21:22:34 --> Controller Class Initialized
INFO - 2024-10-23 21:22:48 --> Config Class Initialized
INFO - 2024-10-23 21:22:48 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:22:48 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:22:48 --> Utf8 Class Initialized
INFO - 2024-10-23 21:22:48 --> URI Class Initialized
INFO - 2024-10-23 21:22:48 --> Router Class Initialized
INFO - 2024-10-23 21:22:48 --> Output Class Initialized
INFO - 2024-10-23 21:22:48 --> Security Class Initialized
DEBUG - 2024-10-23 21:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:22:48 --> Input Class Initialized
INFO - 2024-10-23 21:22:48 --> Language Class Initialized
INFO - 2024-10-23 21:22:48 --> Loader Class Initialized
INFO - 2024-10-23 21:22:48 --> Helper loaded: url_helper
INFO - 2024-10-23 21:22:48 --> Helper loaded: html_helper
INFO - 2024-10-23 21:22:48 --> Helper loaded: file_helper
INFO - 2024-10-23 21:22:48 --> Helper loaded: string_helper
INFO - 2024-10-23 21:22:48 --> Helper loaded: form_helper
INFO - 2024-10-23 21:22:48 --> Helper loaded: my_helper
INFO - 2024-10-23 21:22:48 --> Database Driver Class Initialized
INFO - 2024-10-23 21:22:51 --> Upload Class Initialized
INFO - 2024-10-23 21:22:51 --> Email Class Initialized
INFO - 2024-10-23 21:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:22:51 --> Form Validation Class Initialized
INFO - 2024-10-23 21:22:51 --> Controller Class Initialized
INFO - 2024-10-23 21:22:52 --> Config Class Initialized
INFO - 2024-10-23 21:22:52 --> Config Class Initialized
INFO - 2024-10-23 21:22:52 --> Hooks Class Initialized
INFO - 2024-10-23 21:22:52 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:22:52 --> UTF-8 Support Enabled
DEBUG - 2024-10-23 21:22:52 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:22:52 --> Utf8 Class Initialized
INFO - 2024-10-23 21:22:52 --> URI Class Initialized
INFO - 2024-10-23 21:22:52 --> Utf8 Class Initialized
DEBUG - 2024-10-23 21:22:52 --> No URI present. Default controller set.
INFO - 2024-10-23 21:22:52 --> URI Class Initialized
INFO - 2024-10-23 21:22:52 --> Router Class Initialized
INFO - 2024-10-23 21:22:52 --> Output Class Initialized
INFO - 2024-10-23 21:22:52 --> Router Class Initialized
INFO - 2024-10-23 21:22:52 --> Security Class Initialized
INFO - 2024-10-23 21:22:52 --> Output Class Initialized
DEBUG - 2024-10-23 21:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:22:52 --> Security Class Initialized
INFO - 2024-10-23 21:22:52 --> Input Class Initialized
INFO - 2024-10-23 21:22:52 --> Language Class Initialized
DEBUG - 2024-10-23 21:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:22:52 --> Input Class Initialized
INFO - 2024-10-23 21:22:52 --> Loader Class Initialized
INFO - 2024-10-23 21:22:52 --> Language Class Initialized
INFO - 2024-10-23 21:22:52 --> Helper loaded: url_helper
ERROR - 2024-10-23 21:22:52 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-23 21:22:52 --> Helper loaded: html_helper
INFO - 2024-10-23 21:22:52 --> Helper loaded: file_helper
INFO - 2024-10-23 21:22:52 --> Helper loaded: string_helper
INFO - 2024-10-23 21:22:52 --> Helper loaded: form_helper
INFO - 2024-10-23 21:22:52 --> Helper loaded: my_helper
INFO - 2024-10-23 21:22:52 --> Database Driver Class Initialized
INFO - 2024-10-23 21:22:54 --> Upload Class Initialized
INFO - 2024-10-23 21:22:54 --> Email Class Initialized
INFO - 2024-10-23 21:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:22:55 --> Form Validation Class Initialized
INFO - 2024-10-23 21:22:55 --> Controller Class Initialized
INFO - 2024-10-23 21:22:59 --> Config Class Initialized
INFO - 2024-10-23 21:22:59 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:22:59 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:22:59 --> Utf8 Class Initialized
INFO - 2024-10-23 21:22:59 --> URI Class Initialized
INFO - 2024-10-23 21:22:59 --> Router Class Initialized
INFO - 2024-10-23 21:22:59 --> Output Class Initialized
INFO - 2024-10-23 21:22:59 --> Security Class Initialized
DEBUG - 2024-10-23 21:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:22:59 --> Input Class Initialized
INFO - 2024-10-23 21:22:59 --> Language Class Initialized
INFO - 2024-10-23 21:22:59 --> Loader Class Initialized
INFO - 2024-10-23 21:22:59 --> Helper loaded: url_helper
INFO - 2024-10-23 21:22:59 --> Helper loaded: html_helper
INFO - 2024-10-23 21:22:59 --> Helper loaded: file_helper
INFO - 2024-10-23 21:22:59 --> Helper loaded: string_helper
INFO - 2024-10-23 21:22:59 --> Helper loaded: form_helper
INFO - 2024-10-23 21:22:59 --> Helper loaded: my_helper
INFO - 2024-10-23 21:22:59 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:02 --> Upload Class Initialized
INFO - 2024-10-23 21:23:02 --> Email Class Initialized
INFO - 2024-10-23 21:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:02 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:02 --> Controller Class Initialized
INFO - 2024-10-23 21:23:03 --> Config Class Initialized
INFO - 2024-10-23 21:23:03 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:03 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:03 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:03 --> URI Class Initialized
DEBUG - 2024-10-23 21:23:03 --> No URI present. Default controller set.
INFO - 2024-10-23 21:23:03 --> Router Class Initialized
INFO - 2024-10-23 21:23:03 --> Output Class Initialized
INFO - 2024-10-23 21:23:03 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:03 --> Input Class Initialized
INFO - 2024-10-23 21:23:03 --> Language Class Initialized
INFO - 2024-10-23 21:23:03 --> Loader Class Initialized
INFO - 2024-10-23 21:23:03 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:03 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:03 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:03 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:03 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:03 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:03 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:05 --> Upload Class Initialized
INFO - 2024-10-23 21:23:05 --> Email Class Initialized
INFO - 2024-10-23 21:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:05 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:05 --> Controller Class Initialized
INFO - 2024-10-23 21:23:07 --> Config Class Initialized
INFO - 2024-10-23 21:23:07 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:07 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:07 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:07 --> URI Class Initialized
INFO - 2024-10-23 21:23:07 --> Router Class Initialized
INFO - 2024-10-23 21:23:07 --> Output Class Initialized
INFO - 2024-10-23 21:23:07 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:07 --> Input Class Initialized
INFO - 2024-10-23 21:23:07 --> Language Class Initialized
INFO - 2024-10-23 21:23:07 --> Loader Class Initialized
INFO - 2024-10-23 21:23:07 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:07 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:07 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:07 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:07 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:07 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:07 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:09 --> Upload Class Initialized
INFO - 2024-10-23 21:23:09 --> Email Class Initialized
INFO - 2024-10-23 21:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:09 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:09 --> Controller Class Initialized
INFO - 2024-10-23 21:23:10 --> Config Class Initialized
INFO - 2024-10-23 21:23:10 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:10 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:10 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:10 --> URI Class Initialized
DEBUG - 2024-10-23 21:23:10 --> No URI present. Default controller set.
INFO - 2024-10-23 21:23:10 --> Router Class Initialized
INFO - 2024-10-23 21:23:10 --> Output Class Initialized
INFO - 2024-10-23 21:23:10 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:10 --> Input Class Initialized
INFO - 2024-10-23 21:23:10 --> Language Class Initialized
INFO - 2024-10-23 21:23:10 --> Loader Class Initialized
INFO - 2024-10-23 21:23:10 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:10 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:10 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:10 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:10 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:10 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:10 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:13 --> Upload Class Initialized
INFO - 2024-10-23 21:23:13 --> Email Class Initialized
INFO - 2024-10-23 21:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:13 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:13 --> Controller Class Initialized
INFO - 2024-10-23 21:23:15 --> Config Class Initialized
INFO - 2024-10-23 21:23:15 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:15 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:15 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:15 --> URI Class Initialized
INFO - 2024-10-23 21:23:15 --> Router Class Initialized
INFO - 2024-10-23 21:23:15 --> Output Class Initialized
INFO - 2024-10-23 21:23:15 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:15 --> Input Class Initialized
INFO - 2024-10-23 21:23:15 --> Language Class Initialized
INFO - 2024-10-23 21:23:15 --> Loader Class Initialized
INFO - 2024-10-23 21:23:15 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:15 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:15 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:15 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:15 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:15 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:15 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:17 --> Upload Class Initialized
INFO - 2024-10-23 21:23:17 --> Email Class Initialized
INFO - 2024-10-23 21:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:17 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:17 --> Controller Class Initialized
INFO - 2024-10-23 21:23:17 --> Config Class Initialized
INFO - 2024-10-23 21:23:17 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:17 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:17 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:17 --> URI Class Initialized
DEBUG - 2024-10-23 21:23:17 --> No URI present. Default controller set.
INFO - 2024-10-23 21:23:18 --> Router Class Initialized
INFO - 2024-10-23 21:23:18 --> Output Class Initialized
INFO - 2024-10-23 21:23:18 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:18 --> Input Class Initialized
INFO - 2024-10-23 21:23:18 --> Language Class Initialized
INFO - 2024-10-23 21:23:18 --> Loader Class Initialized
INFO - 2024-10-23 21:23:18 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:18 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:18 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:18 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:18 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:18 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:18 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:20 --> Upload Class Initialized
INFO - 2024-10-23 21:23:20 --> Email Class Initialized
INFO - 2024-10-23 21:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:20 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:20 --> Controller Class Initialized
INFO - 2024-10-23 21:23:22 --> Config Class Initialized
INFO - 2024-10-23 21:23:22 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:22 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:22 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:22 --> URI Class Initialized
INFO - 2024-10-23 21:23:22 --> Router Class Initialized
INFO - 2024-10-23 21:23:22 --> Output Class Initialized
INFO - 2024-10-23 21:23:22 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:22 --> Input Class Initialized
INFO - 2024-10-23 21:23:22 --> Language Class Initialized
INFO - 2024-10-23 21:23:22 --> Loader Class Initialized
INFO - 2024-10-23 21:23:22 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:22 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:22 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:22 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:22 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:22 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:22 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:24 --> Upload Class Initialized
INFO - 2024-10-23 21:23:24 --> Email Class Initialized
INFO - 2024-10-23 21:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:24 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:24 --> Controller Class Initialized
INFO - 2024-10-23 21:23:25 --> Config Class Initialized
INFO - 2024-10-23 21:23:25 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:25 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:25 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:25 --> URI Class Initialized
DEBUG - 2024-10-23 21:23:25 --> No URI present. Default controller set.
INFO - 2024-10-23 21:23:25 --> Router Class Initialized
INFO - 2024-10-23 21:23:25 --> Output Class Initialized
INFO - 2024-10-23 21:23:25 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:25 --> Input Class Initialized
INFO - 2024-10-23 21:23:25 --> Language Class Initialized
INFO - 2024-10-23 21:23:25 --> Loader Class Initialized
INFO - 2024-10-23 21:23:25 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:25 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:25 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:25 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:25 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:25 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:25 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:27 --> Upload Class Initialized
INFO - 2024-10-23 21:23:27 --> Email Class Initialized
INFO - 2024-10-23 21:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:27 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:28 --> Controller Class Initialized
INFO - 2024-10-23 21:23:30 --> Config Class Initialized
INFO - 2024-10-23 21:23:30 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:30 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:30 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:30 --> URI Class Initialized
INFO - 2024-10-23 21:23:30 --> Router Class Initialized
INFO - 2024-10-23 21:23:30 --> Output Class Initialized
INFO - 2024-10-23 21:23:30 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:30 --> Input Class Initialized
INFO - 2024-10-23 21:23:30 --> Language Class Initialized
INFO - 2024-10-23 21:23:30 --> Loader Class Initialized
INFO - 2024-10-23 21:23:30 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:30 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:30 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:30 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:30 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:30 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:30 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:32 --> Upload Class Initialized
INFO - 2024-10-23 21:23:32 --> Email Class Initialized
INFO - 2024-10-23 21:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:32 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:32 --> Controller Class Initialized
INFO - 2024-10-23 21:23:32 --> Config Class Initialized
INFO - 2024-10-23 21:23:32 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:32 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:32 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:32 --> URI Class Initialized
DEBUG - 2024-10-23 21:23:32 --> No URI present. Default controller set.
INFO - 2024-10-23 21:23:32 --> Router Class Initialized
INFO - 2024-10-23 21:23:32 --> Output Class Initialized
INFO - 2024-10-23 21:23:32 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:32 --> Input Class Initialized
INFO - 2024-10-23 21:23:32 --> Language Class Initialized
INFO - 2024-10-23 21:23:32 --> Loader Class Initialized
INFO - 2024-10-23 21:23:32 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:32 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:32 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:32 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:32 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:32 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:32 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:34 --> Upload Class Initialized
INFO - 2024-10-23 21:23:34 --> Email Class Initialized
INFO - 2024-10-23 21:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:35 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:35 --> Controller Class Initialized
INFO - 2024-10-23 21:23:39 --> Config Class Initialized
INFO - 2024-10-23 21:23:39 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:39 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:39 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:39 --> URI Class Initialized
INFO - 2024-10-23 21:23:39 --> Router Class Initialized
INFO - 2024-10-23 21:23:39 --> Output Class Initialized
INFO - 2024-10-23 21:23:39 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:39 --> Input Class Initialized
INFO - 2024-10-23 21:23:39 --> Language Class Initialized
INFO - 2024-10-23 21:23:39 --> Loader Class Initialized
INFO - 2024-10-23 21:23:39 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:39 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:39 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:39 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:39 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:39 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:39 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:41 --> Upload Class Initialized
INFO - 2024-10-23 21:23:41 --> Email Class Initialized
INFO - 2024-10-23 21:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:41 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:41 --> Controller Class Initialized
INFO - 2024-10-23 21:23:42 --> Config Class Initialized
INFO - 2024-10-23 21:23:42 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:42 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:42 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:42 --> URI Class Initialized
DEBUG - 2024-10-23 21:23:42 --> No URI present. Default controller set.
INFO - 2024-10-23 21:23:42 --> Router Class Initialized
INFO - 2024-10-23 21:23:42 --> Output Class Initialized
INFO - 2024-10-23 21:23:42 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:42 --> Input Class Initialized
INFO - 2024-10-23 21:23:42 --> Language Class Initialized
INFO - 2024-10-23 21:23:42 --> Loader Class Initialized
INFO - 2024-10-23 21:23:42 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:42 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:42 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:42 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:42 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:42 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:42 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:44 --> Upload Class Initialized
INFO - 2024-10-23 21:23:44 --> Email Class Initialized
INFO - 2024-10-23 21:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:44 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:44 --> Controller Class Initialized
INFO - 2024-10-23 21:23:46 --> Config Class Initialized
INFO - 2024-10-23 21:23:46 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:46 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:46 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:46 --> URI Class Initialized
INFO - 2024-10-23 21:23:46 --> Router Class Initialized
INFO - 2024-10-23 21:23:46 --> Output Class Initialized
INFO - 2024-10-23 21:23:46 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:46 --> Input Class Initialized
INFO - 2024-10-23 21:23:46 --> Language Class Initialized
INFO - 2024-10-23 21:23:46 --> Loader Class Initialized
INFO - 2024-10-23 21:23:46 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:46 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:46 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:46 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:46 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:46 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:46 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:48 --> Upload Class Initialized
INFO - 2024-10-23 21:23:48 --> Email Class Initialized
INFO - 2024-10-23 21:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:48 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:48 --> Controller Class Initialized
INFO - 2024-10-23 21:23:49 --> Config Class Initialized
INFO - 2024-10-23 21:23:49 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:23:49 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:23:49 --> Utf8 Class Initialized
INFO - 2024-10-23 21:23:49 --> URI Class Initialized
DEBUG - 2024-10-23 21:23:49 --> No URI present. Default controller set.
INFO - 2024-10-23 21:23:49 --> Router Class Initialized
INFO - 2024-10-23 21:23:49 --> Output Class Initialized
INFO - 2024-10-23 21:23:49 --> Security Class Initialized
DEBUG - 2024-10-23 21:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:23:49 --> Input Class Initialized
INFO - 2024-10-23 21:23:49 --> Language Class Initialized
INFO - 2024-10-23 21:23:49 --> Loader Class Initialized
INFO - 2024-10-23 21:23:49 --> Helper loaded: url_helper
INFO - 2024-10-23 21:23:49 --> Helper loaded: html_helper
INFO - 2024-10-23 21:23:49 --> Helper loaded: file_helper
INFO - 2024-10-23 21:23:49 --> Helper loaded: string_helper
INFO - 2024-10-23 21:23:49 --> Helper loaded: form_helper
INFO - 2024-10-23 21:23:49 --> Helper loaded: my_helper
INFO - 2024-10-23 21:23:49 --> Database Driver Class Initialized
INFO - 2024-10-23 21:23:51 --> Upload Class Initialized
INFO - 2024-10-23 21:23:51 --> Email Class Initialized
INFO - 2024-10-23 21:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:23:51 --> Form Validation Class Initialized
INFO - 2024-10-23 21:23:51 --> Controller Class Initialized
INFO - 2024-10-23 21:24:34 --> Config Class Initialized
INFO - 2024-10-23 21:24:34 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:24:34 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:24:34 --> Utf8 Class Initialized
INFO - 2024-10-23 21:24:34 --> URI Class Initialized
DEBUG - 2024-10-23 21:24:34 --> No URI present. Default controller set.
INFO - 2024-10-23 21:24:34 --> Router Class Initialized
INFO - 2024-10-23 21:24:34 --> Output Class Initialized
INFO - 2024-10-23 21:24:34 --> Security Class Initialized
DEBUG - 2024-10-23 21:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:24:34 --> Input Class Initialized
INFO - 2024-10-23 21:24:34 --> Language Class Initialized
INFO - 2024-10-23 21:24:34 --> Loader Class Initialized
INFO - 2024-10-23 21:24:34 --> Helper loaded: url_helper
INFO - 2024-10-23 21:24:34 --> Helper loaded: html_helper
INFO - 2024-10-23 21:24:34 --> Helper loaded: file_helper
INFO - 2024-10-23 21:24:34 --> Helper loaded: string_helper
INFO - 2024-10-23 21:24:34 --> Helper loaded: form_helper
INFO - 2024-10-23 21:24:34 --> Helper loaded: my_helper
INFO - 2024-10-23 21:24:34 --> Database Driver Class Initialized
INFO - 2024-10-23 21:24:36 --> Upload Class Initialized
INFO - 2024-10-23 21:24:36 --> Email Class Initialized
INFO - 2024-10-23 21:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:24:37 --> Form Validation Class Initialized
INFO - 2024-10-23 21:24:37 --> Controller Class Initialized
INFO - 2024-10-23 21:24:38 --> Config Class Initialized
INFO - 2024-10-23 21:24:38 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:24:38 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:24:38 --> Utf8 Class Initialized
INFO - 2024-10-23 21:24:38 --> URI Class Initialized
DEBUG - 2024-10-23 21:24:38 --> No URI present. Default controller set.
INFO - 2024-10-23 21:24:38 --> Router Class Initialized
INFO - 2024-10-23 21:24:38 --> Output Class Initialized
INFO - 2024-10-23 21:24:38 --> Security Class Initialized
DEBUG - 2024-10-23 21:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:24:38 --> Input Class Initialized
INFO - 2024-10-23 21:24:38 --> Language Class Initialized
INFO - 2024-10-23 21:24:38 --> Loader Class Initialized
INFO - 2024-10-23 21:24:38 --> Helper loaded: url_helper
INFO - 2024-10-23 21:24:38 --> Helper loaded: html_helper
INFO - 2024-10-23 21:24:38 --> Helper loaded: file_helper
INFO - 2024-10-23 21:24:38 --> Helper loaded: string_helper
INFO - 2024-10-23 21:24:38 --> Helper loaded: form_helper
INFO - 2024-10-23 21:24:38 --> Helper loaded: my_helper
INFO - 2024-10-23 21:24:38 --> Database Driver Class Initialized
INFO - 2024-10-23 21:24:41 --> Upload Class Initialized
INFO - 2024-10-23 21:24:41 --> Email Class Initialized
INFO - 2024-10-23 21:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:24:41 --> Form Validation Class Initialized
INFO - 2024-10-23 21:24:41 --> Controller Class Initialized
INFO - 2024-10-23 21:24:51 --> Config Class Initialized
INFO - 2024-10-23 21:24:51 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:24:51 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:24:51 --> Utf8 Class Initialized
INFO - 2024-10-23 21:24:51 --> URI Class Initialized
INFO - 2024-10-23 21:24:51 --> Router Class Initialized
INFO - 2024-10-23 21:24:51 --> Output Class Initialized
INFO - 2024-10-23 21:24:51 --> Security Class Initialized
DEBUG - 2024-10-23 21:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:24:51 --> Input Class Initialized
INFO - 2024-10-23 21:24:51 --> Language Class Initialized
INFO - 2024-10-23 21:24:51 --> Loader Class Initialized
INFO - 2024-10-23 21:24:51 --> Helper loaded: url_helper
INFO - 2024-10-23 21:24:51 --> Helper loaded: html_helper
INFO - 2024-10-23 21:24:51 --> Helper loaded: file_helper
INFO - 2024-10-23 21:24:51 --> Helper loaded: string_helper
INFO - 2024-10-23 21:24:51 --> Helper loaded: form_helper
INFO - 2024-10-23 21:24:51 --> Helper loaded: my_helper
INFO - 2024-10-23 21:24:51 --> Database Driver Class Initialized
INFO - 2024-10-23 21:24:53 --> Upload Class Initialized
INFO - 2024-10-23 21:24:53 --> Email Class Initialized
INFO - 2024-10-23 21:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:24:53 --> Form Validation Class Initialized
INFO - 2024-10-23 21:24:53 --> Controller Class Initialized
INFO - 2024-10-23 21:24:54 --> Config Class Initialized
INFO - 2024-10-23 21:24:54 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:24:54 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:24:54 --> Config Class Initialized
INFO - 2024-10-23 21:24:55 --> Utf8 Class Initialized
INFO - 2024-10-23 21:24:55 --> Hooks Class Initialized
INFO - 2024-10-23 21:24:55 --> URI Class Initialized
DEBUG - 2024-10-23 21:24:55 --> No URI present. Default controller set.
DEBUG - 2024-10-23 21:24:55 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:24:55 --> Router Class Initialized
INFO - 2024-10-23 21:24:55 --> Utf8 Class Initialized
INFO - 2024-10-23 21:24:55 --> URI Class Initialized
INFO - 2024-10-23 21:24:55 --> Output Class Initialized
INFO - 2024-10-23 21:24:55 --> Router Class Initialized
INFO - 2024-10-23 21:24:55 --> Security Class Initialized
DEBUG - 2024-10-23 21:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:24:55 --> Output Class Initialized
INFO - 2024-10-23 21:24:55 --> Input Class Initialized
INFO - 2024-10-23 21:24:55 --> Security Class Initialized
INFO - 2024-10-23 21:24:55 --> Language Class Initialized
DEBUG - 2024-10-23 21:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:24:55 --> Loader Class Initialized
INFO - 2024-10-23 21:24:55 --> Input Class Initialized
INFO - 2024-10-23 21:24:55 --> Helper loaded: url_helper
INFO - 2024-10-23 21:24:55 --> Language Class Initialized
INFO - 2024-10-23 21:24:55 --> Helper loaded: html_helper
ERROR - 2024-10-23 21:24:55 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-23 21:24:55 --> Helper loaded: file_helper
INFO - 2024-10-23 21:24:55 --> Helper loaded: string_helper
INFO - 2024-10-23 21:24:55 --> Helper loaded: form_helper
INFO - 2024-10-23 21:24:55 --> Helper loaded: my_helper
INFO - 2024-10-23 21:24:55 --> Database Driver Class Initialized
INFO - 2024-10-23 21:24:57 --> Upload Class Initialized
INFO - 2024-10-23 21:24:57 --> Email Class Initialized
INFO - 2024-10-23 21:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:24:57 --> Form Validation Class Initialized
INFO - 2024-10-23 21:24:57 --> Controller Class Initialized
INFO - 2024-10-23 21:25:00 --> Config Class Initialized
INFO - 2024-10-23 21:25:00 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:01 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:01 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:01 --> URI Class Initialized
INFO - 2024-10-23 21:25:01 --> Router Class Initialized
INFO - 2024-10-23 21:25:01 --> Output Class Initialized
INFO - 2024-10-23 21:25:01 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:01 --> Input Class Initialized
INFO - 2024-10-23 21:25:01 --> Language Class Initialized
INFO - 2024-10-23 21:25:01 --> Loader Class Initialized
INFO - 2024-10-23 21:25:01 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:01 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:01 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:01 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:01 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:01 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:01 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:03 --> Upload Class Initialized
INFO - 2024-10-23 21:25:03 --> Email Class Initialized
INFO - 2024-10-23 21:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:03 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:03 --> Controller Class Initialized
INFO - 2024-10-23 21:25:03 --> Config Class Initialized
INFO - 2024-10-23 21:25:03 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:04 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:04 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:04 --> URI Class Initialized
DEBUG - 2024-10-23 21:25:04 --> No URI present. Default controller set.
INFO - 2024-10-23 21:25:04 --> Router Class Initialized
INFO - 2024-10-23 21:25:04 --> Output Class Initialized
INFO - 2024-10-23 21:25:04 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:04 --> Input Class Initialized
INFO - 2024-10-23 21:25:04 --> Language Class Initialized
INFO - 2024-10-23 21:25:04 --> Loader Class Initialized
INFO - 2024-10-23 21:25:04 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:04 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:04 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:04 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:05 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:05 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:05 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:07 --> Upload Class Initialized
INFO - 2024-10-23 21:25:07 --> Email Class Initialized
INFO - 2024-10-23 21:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:07 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:07 --> Controller Class Initialized
INFO - 2024-10-23 21:25:09 --> Config Class Initialized
INFO - 2024-10-23 21:25:09 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:09 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:09 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:09 --> URI Class Initialized
INFO - 2024-10-23 21:25:09 --> Router Class Initialized
INFO - 2024-10-23 21:25:09 --> Output Class Initialized
INFO - 2024-10-23 21:25:09 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:09 --> Input Class Initialized
INFO - 2024-10-23 21:25:09 --> Language Class Initialized
INFO - 2024-10-23 21:25:09 --> Loader Class Initialized
INFO - 2024-10-23 21:25:09 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:09 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:09 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:09 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:09 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:09 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:09 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:11 --> Upload Class Initialized
INFO - 2024-10-23 21:25:11 --> Email Class Initialized
INFO - 2024-10-23 21:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:11 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:11 --> Controller Class Initialized
INFO - 2024-10-23 21:25:11 --> Config Class Initialized
INFO - 2024-10-23 21:25:11 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:11 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:11 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:11 --> URI Class Initialized
DEBUG - 2024-10-23 21:25:11 --> No URI present. Default controller set.
INFO - 2024-10-23 21:25:12 --> Router Class Initialized
INFO - 2024-10-23 21:25:12 --> Output Class Initialized
INFO - 2024-10-23 21:25:12 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:12 --> Input Class Initialized
INFO - 2024-10-23 21:25:12 --> Language Class Initialized
INFO - 2024-10-23 21:25:12 --> Loader Class Initialized
INFO - 2024-10-23 21:25:12 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:12 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:12 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:12 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:12 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:12 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:12 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:14 --> Upload Class Initialized
INFO - 2024-10-23 21:25:14 --> Email Class Initialized
INFO - 2024-10-23 21:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:14 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:14 --> Controller Class Initialized
INFO - 2024-10-23 21:25:15 --> Config Class Initialized
INFO - 2024-10-23 21:25:15 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:15 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:15 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:15 --> URI Class Initialized
INFO - 2024-10-23 21:25:15 --> Router Class Initialized
INFO - 2024-10-23 21:25:15 --> Output Class Initialized
INFO - 2024-10-23 21:25:15 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:15 --> Input Class Initialized
INFO - 2024-10-23 21:25:15 --> Language Class Initialized
INFO - 2024-10-23 21:25:15 --> Loader Class Initialized
INFO - 2024-10-23 21:25:15 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:15 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:15 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:15 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:15 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:15 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:16 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:18 --> Upload Class Initialized
INFO - 2024-10-23 21:25:18 --> Email Class Initialized
INFO - 2024-10-23 21:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:18 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:18 --> Controller Class Initialized
INFO - 2024-10-23 21:25:18 --> Config Class Initialized
INFO - 2024-10-23 21:25:18 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:18 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:18 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:18 --> URI Class Initialized
DEBUG - 2024-10-23 21:25:18 --> No URI present. Default controller set.
INFO - 2024-10-23 21:25:18 --> Router Class Initialized
INFO - 2024-10-23 21:25:18 --> Output Class Initialized
INFO - 2024-10-23 21:25:18 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:18 --> Input Class Initialized
INFO - 2024-10-23 21:25:18 --> Language Class Initialized
INFO - 2024-10-23 21:25:18 --> Loader Class Initialized
INFO - 2024-10-23 21:25:18 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:18 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:18 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:18 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:18 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:18 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:18 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:20 --> Upload Class Initialized
INFO - 2024-10-23 21:25:20 --> Email Class Initialized
INFO - 2024-10-23 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:20 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:20 --> Controller Class Initialized
INFO - 2024-10-23 21:25:22 --> Config Class Initialized
INFO - 2024-10-23 21:25:22 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:22 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:22 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:22 --> URI Class Initialized
INFO - 2024-10-23 21:25:22 --> Router Class Initialized
INFO - 2024-10-23 21:25:22 --> Output Class Initialized
INFO - 2024-10-23 21:25:22 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:22 --> Input Class Initialized
INFO - 2024-10-23 21:25:22 --> Language Class Initialized
INFO - 2024-10-23 21:25:22 --> Loader Class Initialized
INFO - 2024-10-23 21:25:22 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:22 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:22 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:22 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:22 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:22 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:22 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:24 --> Upload Class Initialized
INFO - 2024-10-23 21:25:24 --> Email Class Initialized
INFO - 2024-10-23 21:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:24 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:24 --> Controller Class Initialized
INFO - 2024-10-23 21:25:25 --> Config Class Initialized
INFO - 2024-10-23 21:25:25 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:25 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:25 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:25 --> URI Class Initialized
DEBUG - 2024-10-23 21:25:25 --> No URI present. Default controller set.
INFO - 2024-10-23 21:25:25 --> Router Class Initialized
INFO - 2024-10-23 21:25:25 --> Output Class Initialized
INFO - 2024-10-23 21:25:25 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:25 --> Input Class Initialized
INFO - 2024-10-23 21:25:25 --> Language Class Initialized
INFO - 2024-10-23 21:25:25 --> Loader Class Initialized
INFO - 2024-10-23 21:25:25 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:25 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:25 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:25 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:25 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:25 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:25 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:27 --> Upload Class Initialized
INFO - 2024-10-23 21:25:27 --> Email Class Initialized
INFO - 2024-10-23 21:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:27 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:27 --> Controller Class Initialized
INFO - 2024-10-23 21:25:28 --> Config Class Initialized
INFO - 2024-10-23 21:25:28 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:28 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:28 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:28 --> URI Class Initialized
INFO - 2024-10-23 21:25:28 --> Router Class Initialized
INFO - 2024-10-23 21:25:28 --> Output Class Initialized
INFO - 2024-10-23 21:25:28 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:28 --> Input Class Initialized
INFO - 2024-10-23 21:25:28 --> Language Class Initialized
INFO - 2024-10-23 21:25:28 --> Loader Class Initialized
INFO - 2024-10-23 21:25:28 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:28 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:28 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:28 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:28 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:28 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:28 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:30 --> Upload Class Initialized
INFO - 2024-10-23 21:25:31 --> Email Class Initialized
INFO - 2024-10-23 21:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:31 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:31 --> Controller Class Initialized
INFO - 2024-10-23 21:25:31 --> Config Class Initialized
INFO - 2024-10-23 21:25:31 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:31 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:31 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:31 --> URI Class Initialized
DEBUG - 2024-10-23 21:25:31 --> No URI present. Default controller set.
INFO - 2024-10-23 21:25:31 --> Router Class Initialized
INFO - 2024-10-23 21:25:31 --> Output Class Initialized
INFO - 2024-10-23 21:25:31 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:31 --> Input Class Initialized
INFO - 2024-10-23 21:25:31 --> Language Class Initialized
INFO - 2024-10-23 21:25:31 --> Loader Class Initialized
INFO - 2024-10-23 21:25:31 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:31 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:31 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:31 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:31 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:31 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:31 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:33 --> Upload Class Initialized
INFO - 2024-10-23 21:25:33 --> Email Class Initialized
INFO - 2024-10-23 21:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:33 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:33 --> Controller Class Initialized
INFO - 2024-10-23 21:25:38 --> Config Class Initialized
INFO - 2024-10-23 21:25:38 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:38 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:38 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:38 --> URI Class Initialized
INFO - 2024-10-23 21:25:38 --> Router Class Initialized
INFO - 2024-10-23 21:25:38 --> Output Class Initialized
INFO - 2024-10-23 21:25:38 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:38 --> Input Class Initialized
INFO - 2024-10-23 21:25:38 --> Language Class Initialized
INFO - 2024-10-23 21:25:38 --> Loader Class Initialized
INFO - 2024-10-23 21:25:38 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:38 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:38 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:38 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:38 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:38 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:38 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:40 --> Upload Class Initialized
INFO - 2024-10-23 21:25:40 --> Email Class Initialized
INFO - 2024-10-23 21:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:41 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:41 --> Controller Class Initialized
INFO - 2024-10-23 21:25:41 --> Config Class Initialized
INFO - 2024-10-23 21:25:41 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:41 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:41 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:41 --> URI Class Initialized
DEBUG - 2024-10-23 21:25:41 --> No URI present. Default controller set.
INFO - 2024-10-23 21:25:41 --> Router Class Initialized
INFO - 2024-10-23 21:25:41 --> Output Class Initialized
INFO - 2024-10-23 21:25:41 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:41 --> Input Class Initialized
INFO - 2024-10-23 21:25:41 --> Language Class Initialized
INFO - 2024-10-23 21:25:41 --> Loader Class Initialized
INFO - 2024-10-23 21:25:41 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:41 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:41 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:41 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:41 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:41 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:41 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:43 --> Upload Class Initialized
INFO - 2024-10-23 21:25:43 --> Email Class Initialized
INFO - 2024-10-23 21:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:43 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:43 --> Controller Class Initialized
INFO - 2024-10-23 21:25:44 --> Config Class Initialized
INFO - 2024-10-23 21:25:44 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:44 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:44 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:44 --> URI Class Initialized
INFO - 2024-10-23 21:25:44 --> Router Class Initialized
INFO - 2024-10-23 21:25:44 --> Output Class Initialized
INFO - 2024-10-23 21:25:44 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:44 --> Input Class Initialized
INFO - 2024-10-23 21:25:44 --> Language Class Initialized
INFO - 2024-10-23 21:25:44 --> Loader Class Initialized
INFO - 2024-10-23 21:25:45 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:45 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:45 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:45 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:45 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:45 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:45 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:47 --> Upload Class Initialized
INFO - 2024-10-23 21:25:47 --> Email Class Initialized
INFO - 2024-10-23 21:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:47 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:47 --> Controller Class Initialized
INFO - 2024-10-23 21:25:47 --> Config Class Initialized
INFO - 2024-10-23 21:25:47 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:25:47 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:25:47 --> Utf8 Class Initialized
INFO - 2024-10-23 21:25:47 --> URI Class Initialized
DEBUG - 2024-10-23 21:25:47 --> No URI present. Default controller set.
INFO - 2024-10-23 21:25:47 --> Router Class Initialized
INFO - 2024-10-23 21:25:47 --> Output Class Initialized
INFO - 2024-10-23 21:25:47 --> Security Class Initialized
DEBUG - 2024-10-23 21:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:25:47 --> Input Class Initialized
INFO - 2024-10-23 21:25:47 --> Language Class Initialized
INFO - 2024-10-23 21:25:47 --> Loader Class Initialized
INFO - 2024-10-23 21:25:47 --> Helper loaded: url_helper
INFO - 2024-10-23 21:25:47 --> Helper loaded: html_helper
INFO - 2024-10-23 21:25:47 --> Helper loaded: file_helper
INFO - 2024-10-23 21:25:47 --> Helper loaded: string_helper
INFO - 2024-10-23 21:25:47 --> Helper loaded: form_helper
INFO - 2024-10-23 21:25:47 --> Helper loaded: my_helper
INFO - 2024-10-23 21:25:47 --> Database Driver Class Initialized
INFO - 2024-10-23 21:25:49 --> Upload Class Initialized
INFO - 2024-10-23 21:25:49 --> Email Class Initialized
INFO - 2024-10-23 21:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:25:49 --> Form Validation Class Initialized
INFO - 2024-10-23 21:25:49 --> Controller Class Initialized
INFO - 2024-10-23 21:32:32 --> Config Class Initialized
INFO - 2024-10-23 21:32:32 --> Hooks Class Initialized
DEBUG - 2024-10-23 21:32:33 --> UTF-8 Support Enabled
INFO - 2024-10-23 21:32:33 --> Utf8 Class Initialized
INFO - 2024-10-23 21:32:33 --> URI Class Initialized
DEBUG - 2024-10-23 21:32:33 --> No URI present. Default controller set.
INFO - 2024-10-23 21:32:33 --> Router Class Initialized
INFO - 2024-10-23 21:32:33 --> Output Class Initialized
INFO - 2024-10-23 21:32:33 --> Security Class Initialized
DEBUG - 2024-10-23 21:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 21:32:33 --> Input Class Initialized
INFO - 2024-10-23 21:32:33 --> Language Class Initialized
INFO - 2024-10-23 21:32:33 --> Loader Class Initialized
INFO - 2024-10-23 21:32:33 --> Helper loaded: url_helper
INFO - 2024-10-23 21:32:33 --> Helper loaded: html_helper
INFO - 2024-10-23 21:32:33 --> Helper loaded: file_helper
INFO - 2024-10-23 21:32:33 --> Helper loaded: string_helper
INFO - 2024-10-23 21:32:33 --> Helper loaded: form_helper
INFO - 2024-10-23 21:32:33 --> Helper loaded: my_helper
INFO - 2024-10-23 21:32:33 --> Database Driver Class Initialized
INFO - 2024-10-23 21:32:35 --> Upload Class Initialized
INFO - 2024-10-23 21:32:35 --> Email Class Initialized
INFO - 2024-10-23 21:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 21:32:35 --> Form Validation Class Initialized
INFO - 2024-10-23 21:32:35 --> Controller Class Initialized
INFO - 2024-10-23 22:01:09 --> Config Class Initialized
INFO - 2024-10-23 22:01:09 --> Hooks Class Initialized
DEBUG - 2024-10-23 22:01:09 --> UTF-8 Support Enabled
INFO - 2024-10-23 22:01:09 --> Utf8 Class Initialized
INFO - 2024-10-23 22:01:09 --> URI Class Initialized
DEBUG - 2024-10-23 22:01:09 --> No URI present. Default controller set.
INFO - 2024-10-23 22:01:09 --> Router Class Initialized
INFO - 2024-10-23 22:01:09 --> Output Class Initialized
INFO - 2024-10-23 22:01:09 --> Security Class Initialized
DEBUG - 2024-10-23 22:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 22:01:09 --> Input Class Initialized
INFO - 2024-10-23 22:01:09 --> Language Class Initialized
INFO - 2024-10-23 22:01:09 --> Loader Class Initialized
INFO - 2024-10-23 22:01:09 --> Helper loaded: url_helper
INFO - 2024-10-23 22:01:09 --> Helper loaded: html_helper
INFO - 2024-10-23 22:01:09 --> Helper loaded: file_helper
INFO - 2024-10-23 22:01:09 --> Helper loaded: string_helper
INFO - 2024-10-23 22:01:09 --> Helper loaded: form_helper
INFO - 2024-10-23 22:01:09 --> Helper loaded: my_helper
INFO - 2024-10-23 22:01:09 --> Database Driver Class Initialized
INFO - 2024-10-23 22:01:11 --> Upload Class Initialized
INFO - 2024-10-23 22:01:11 --> Email Class Initialized
INFO - 2024-10-23 22:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 22:01:11 --> Form Validation Class Initialized
INFO - 2024-10-23 22:01:11 --> Controller Class Initialized
INFO - 2024-10-23 22:07:16 --> Config Class Initialized
INFO - 2024-10-23 22:07:16 --> Hooks Class Initialized
DEBUG - 2024-10-23 22:07:16 --> UTF-8 Support Enabled
INFO - 2024-10-23 22:07:16 --> Utf8 Class Initialized
INFO - 2024-10-23 22:07:16 --> URI Class Initialized
DEBUG - 2024-10-23 22:07:16 --> No URI present. Default controller set.
INFO - 2024-10-23 22:07:16 --> Router Class Initialized
INFO - 2024-10-23 22:07:16 --> Output Class Initialized
INFO - 2024-10-23 22:07:16 --> Security Class Initialized
DEBUG - 2024-10-23 22:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 22:07:16 --> Input Class Initialized
INFO - 2024-10-23 22:07:16 --> Language Class Initialized
INFO - 2024-10-23 22:07:16 --> Loader Class Initialized
INFO - 2024-10-23 22:07:16 --> Helper loaded: url_helper
INFO - 2024-10-23 22:07:16 --> Helper loaded: html_helper
INFO - 2024-10-23 22:07:16 --> Helper loaded: file_helper
INFO - 2024-10-23 22:07:16 --> Helper loaded: string_helper
INFO - 2024-10-23 22:07:16 --> Helper loaded: form_helper
INFO - 2024-10-23 22:07:16 --> Helper loaded: my_helper
INFO - 2024-10-23 22:07:16 --> Database Driver Class Initialized
INFO - 2024-10-23 22:07:18 --> Upload Class Initialized
INFO - 2024-10-23 22:07:18 --> Email Class Initialized
INFO - 2024-10-23 22:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 22:07:18 --> Form Validation Class Initialized
INFO - 2024-10-23 22:07:18 --> Controller Class Initialized
INFO - 2024-10-23 22:07:20 --> Config Class Initialized
INFO - 2024-10-23 22:07:20 --> Hooks Class Initialized
DEBUG - 2024-10-23 22:07:20 --> UTF-8 Support Enabled
INFO - 2024-10-23 22:07:20 --> Utf8 Class Initialized
INFO - 2024-10-23 22:07:20 --> URI Class Initialized
DEBUG - 2024-10-23 22:07:20 --> No URI present. Default controller set.
INFO - 2024-10-23 22:07:20 --> Router Class Initialized
INFO - 2024-10-23 22:07:20 --> Output Class Initialized
INFO - 2024-10-23 22:07:20 --> Security Class Initialized
DEBUG - 2024-10-23 22:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 22:07:20 --> Input Class Initialized
INFO - 2024-10-23 22:07:20 --> Language Class Initialized
INFO - 2024-10-23 22:07:20 --> Loader Class Initialized
INFO - 2024-10-23 22:07:20 --> Helper loaded: url_helper
INFO - 2024-10-23 22:07:20 --> Helper loaded: html_helper
INFO - 2024-10-23 22:07:20 --> Helper loaded: file_helper
INFO - 2024-10-23 22:07:20 --> Helper loaded: string_helper
INFO - 2024-10-23 22:07:20 --> Helper loaded: form_helper
INFO - 2024-10-23 22:07:20 --> Helper loaded: my_helper
INFO - 2024-10-23 22:07:20 --> Database Driver Class Initialized
INFO - 2024-10-23 22:07:22 --> Upload Class Initialized
INFO - 2024-10-23 22:07:22 --> Email Class Initialized
INFO - 2024-10-23 22:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 22:07:22 --> Form Validation Class Initialized
INFO - 2024-10-23 22:07:22 --> Controller Class Initialized
INFO - 2024-10-23 22:10:07 --> Config Class Initialized
INFO - 2024-10-23 22:10:07 --> Hooks Class Initialized
DEBUG - 2024-10-23 22:10:07 --> UTF-8 Support Enabled
INFO - 2024-10-23 22:10:07 --> Utf8 Class Initialized
INFO - 2024-10-23 22:10:07 --> URI Class Initialized
DEBUG - 2024-10-23 22:10:07 --> No URI present. Default controller set.
INFO - 2024-10-23 22:10:07 --> Router Class Initialized
INFO - 2024-10-23 22:10:07 --> Output Class Initialized
INFO - 2024-10-23 22:10:07 --> Security Class Initialized
DEBUG - 2024-10-23 22:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 22:10:07 --> Input Class Initialized
INFO - 2024-10-23 22:10:07 --> Language Class Initialized
INFO - 2024-10-23 22:10:08 --> Loader Class Initialized
INFO - 2024-10-23 22:10:08 --> Helper loaded: url_helper
INFO - 2024-10-23 22:10:08 --> Helper loaded: html_helper
INFO - 2024-10-23 22:10:08 --> Helper loaded: file_helper
INFO - 2024-10-23 22:10:08 --> Helper loaded: string_helper
INFO - 2024-10-23 22:10:08 --> Helper loaded: form_helper
INFO - 2024-10-23 22:10:08 --> Helper loaded: my_helper
INFO - 2024-10-23 22:10:08 --> Database Driver Class Initialized
INFO - 2024-10-23 22:10:10 --> Upload Class Initialized
INFO - 2024-10-23 22:10:10 --> Email Class Initialized
INFO - 2024-10-23 22:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 22:10:10 --> Form Validation Class Initialized
INFO - 2024-10-23 22:10:10 --> Controller Class Initialized
INFO - 2024-10-23 22:10:14 --> Config Class Initialized
INFO - 2024-10-23 22:10:14 --> Hooks Class Initialized
DEBUG - 2024-10-23 22:10:14 --> UTF-8 Support Enabled
INFO - 2024-10-23 22:10:14 --> Utf8 Class Initialized
INFO - 2024-10-23 22:10:14 --> URI Class Initialized
DEBUG - 2024-10-23 22:10:14 --> No URI present. Default controller set.
INFO - 2024-10-23 22:10:14 --> Router Class Initialized
INFO - 2024-10-23 22:10:14 --> Output Class Initialized
INFO - 2024-10-23 22:10:14 --> Security Class Initialized
DEBUG - 2024-10-23 22:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-23 22:10:14 --> Input Class Initialized
INFO - 2024-10-23 22:10:14 --> Language Class Initialized
INFO - 2024-10-23 22:10:14 --> Loader Class Initialized
INFO - 2024-10-23 22:10:14 --> Helper loaded: url_helper
INFO - 2024-10-23 22:10:14 --> Helper loaded: html_helper
INFO - 2024-10-23 22:10:14 --> Helper loaded: file_helper
INFO - 2024-10-23 22:10:14 --> Helper loaded: string_helper
INFO - 2024-10-23 22:10:14 --> Helper loaded: form_helper
INFO - 2024-10-23 22:10:14 --> Helper loaded: my_helper
INFO - 2024-10-23 22:10:14 --> Database Driver Class Initialized
INFO - 2024-10-23 22:10:16 --> Upload Class Initialized
INFO - 2024-10-23 22:10:16 --> Email Class Initialized
INFO - 2024-10-23 22:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-23 22:10:16 --> Form Validation Class Initialized
INFO - 2024-10-23 22:10:16 --> Controller Class Initialized
