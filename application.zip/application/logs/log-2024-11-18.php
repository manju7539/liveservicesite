<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-18 02:32:17 --> Model "MainModel" initialized
INFO - 2024-11-18 02:32:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-18 02:32:17 --> Final output sent to browser
DEBUG - 2024-11-18 02:32:17 --> Total execution time: 2.2351
INFO - 2024-11-18 18:39:45 --> Config Class Initialized
INFO - 2024-11-18 18:39:45 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:39:46 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:39:46 --> Utf8 Class Initialized
INFO - 2024-11-18 18:39:46 --> URI Class Initialized
DEBUG - 2024-11-18 18:39:47 --> No URI present. Default controller set.
INFO - 2024-11-18 18:39:47 --> Router Class Initialized
INFO - 2024-11-18 18:39:47 --> Output Class Initialized
INFO - 2024-11-18 18:39:47 --> Security Class Initialized
DEBUG - 2024-11-18 18:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:39:47 --> Input Class Initialized
INFO - 2024-11-18 18:39:48 --> Language Class Initialized
INFO - 2024-11-18 18:39:48 --> Loader Class Initialized
INFO - 2024-11-18 18:39:48 --> Helper loaded: url_helper
INFO - 2024-11-18 18:39:49 --> Helper loaded: html_helper
INFO - 2024-11-18 18:39:49 --> Helper loaded: file_helper
INFO - 2024-11-18 18:39:49 --> Helper loaded: string_helper
INFO - 2024-11-18 18:39:49 --> Helper loaded: form_helper
INFO - 2024-11-18 18:39:49 --> Helper loaded: my_helper
INFO - 2024-11-18 18:39:49 --> Database Driver Class Initialized
INFO - 2024-11-18 18:39:52 --> Upload Class Initialized
INFO - 2024-11-18 18:39:52 --> Email Class Initialized
INFO - 2024-11-18 18:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 18:39:52 --> Form Validation Class Initialized
INFO - 2024-11-18 18:39:52 --> Controller Class Initialized
INFO - 2024-11-18 18:57:06 --> Config Class Initialized
INFO - 2024-11-18 18:57:06 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:57:06 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:57:06 --> Utf8 Class Initialized
INFO - 2024-11-18 18:57:06 --> URI Class Initialized
DEBUG - 2024-11-18 18:57:06 --> No URI present. Default controller set.
INFO - 2024-11-18 18:57:06 --> Router Class Initialized
INFO - 2024-11-18 18:57:06 --> Output Class Initialized
INFO - 2024-11-18 18:57:06 --> Security Class Initialized
DEBUG - 2024-11-18 18:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:57:06 --> Input Class Initialized
INFO - 2024-11-18 18:57:06 --> Language Class Initialized
INFO - 2024-11-18 18:57:06 --> Loader Class Initialized
INFO - 2024-11-18 18:57:06 --> Helper loaded: url_helper
INFO - 2024-11-18 18:57:06 --> Helper loaded: html_helper
INFO - 2024-11-18 18:57:06 --> Helper loaded: file_helper
INFO - 2024-11-18 18:57:06 --> Helper loaded: string_helper
INFO - 2024-11-18 18:57:06 --> Helper loaded: form_helper
INFO - 2024-11-18 18:57:06 --> Helper loaded: my_helper
INFO - 2024-11-18 18:57:06 --> Database Driver Class Initialized
INFO - 2024-11-18 18:57:08 --> Upload Class Initialized
INFO - 2024-11-18 18:57:08 --> Email Class Initialized
INFO - 2024-11-18 18:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 18:57:08 --> Form Validation Class Initialized
INFO - 2024-11-18 18:57:08 --> Controller Class Initialized
INFO - 2024-11-18 18:57:27 --> Config Class Initialized
INFO - 2024-11-18 18:57:27 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:57:27 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:57:27 --> Utf8 Class Initialized
INFO - 2024-11-18 18:57:27 --> URI Class Initialized
INFO - 2024-11-18 18:57:28 --> Router Class Initialized
INFO - 2024-11-18 18:57:28 --> Output Class Initialized
INFO - 2024-11-18 18:57:28 --> Security Class Initialized
DEBUG - 2024-11-18 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:57:28 --> Input Class Initialized
INFO - 2024-11-18 18:57:28 --> Language Class Initialized
ERROR - 2024-11-18 18:57:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-18 18:57:28 --> Config Class Initialized
INFO - 2024-11-18 18:57:28 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:57:28 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:57:28 --> Utf8 Class Initialized
INFO - 2024-11-18 18:57:28 --> URI Class Initialized
INFO - 2024-11-18 18:57:28 --> Router Class Initialized
INFO - 2024-11-18 18:57:28 --> Output Class Initialized
INFO - 2024-11-18 18:57:28 --> Security Class Initialized
DEBUG - 2024-11-18 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:57:28 --> Input Class Initialized
INFO - 2024-11-18 18:57:28 --> Language Class Initialized
ERROR - 2024-11-18 18:57:28 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-11-18 18:57:32 --> Config Class Initialized
INFO - 2024-11-18 18:57:32 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:57:32 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:57:32 --> Utf8 Class Initialized
INFO - 2024-11-18 18:57:32 --> URI Class Initialized
INFO - 2024-11-18 18:57:32 --> Router Class Initialized
INFO - 2024-11-18 18:57:32 --> Output Class Initialized
INFO - 2024-11-18 18:57:32 --> Security Class Initialized
DEBUG - 2024-11-18 18:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:57:32 --> Input Class Initialized
INFO - 2024-11-18 18:57:32 --> Language Class Initialized
ERROR - 2024-11-18 18:57:32 --> 404 Page Not Found: Configjson/index
INFO - 2024-11-18 18:58:37 --> Config Class Initialized
INFO - 2024-11-18 18:58:37 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:58:37 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:58:37 --> Utf8 Class Initialized
INFO - 2024-11-18 18:58:37 --> URI Class Initialized
DEBUG - 2024-11-18 18:58:37 --> No URI present. Default controller set.
INFO - 2024-11-18 18:58:37 --> Router Class Initialized
INFO - 2024-11-18 18:58:37 --> Output Class Initialized
INFO - 2024-11-18 18:58:37 --> Security Class Initialized
DEBUG - 2024-11-18 18:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:58:37 --> Input Class Initialized
INFO - 2024-11-18 18:58:37 --> Language Class Initialized
INFO - 2024-11-18 18:58:37 --> Loader Class Initialized
INFO - 2024-11-18 18:58:37 --> Helper loaded: url_helper
INFO - 2024-11-18 18:58:37 --> Helper loaded: html_helper
INFO - 2024-11-18 18:58:37 --> Helper loaded: file_helper
INFO - 2024-11-18 18:58:37 --> Helper loaded: string_helper
INFO - 2024-11-18 18:58:37 --> Helper loaded: form_helper
INFO - 2024-11-18 18:58:37 --> Helper loaded: my_helper
INFO - 2024-11-18 18:58:37 --> Database Driver Class Initialized
INFO - 2024-11-18 18:58:39 --> Upload Class Initialized
INFO - 2024-11-18 18:58:39 --> Email Class Initialized
INFO - 2024-11-18 18:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-18 18:58:39 --> Form Validation Class Initialized
INFO - 2024-11-18 18:58:39 --> Controller Class Initialized
INFO - 2024-11-18 18:58:41 --> Config Class Initialized
INFO - 2024-11-18 18:58:41 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:58:41 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:58:41 --> Utf8 Class Initialized
INFO - 2024-11-18 18:58:41 --> URI Class Initialized
INFO - 2024-11-18 18:58:41 --> Router Class Initialized
INFO - 2024-11-18 18:58:41 --> Output Class Initialized
INFO - 2024-11-18 18:58:41 --> Security Class Initialized
DEBUG - 2024-11-18 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:58:41 --> Input Class Initialized
INFO - 2024-11-18 18:58:41 --> Language Class Initialized
ERROR - 2024-11-18 18:58:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-18 18:58:41 --> Config Class Initialized
INFO - 2024-11-18 18:58:41 --> Hooks Class Initialized
DEBUG - 2024-11-18 18:58:41 --> UTF-8 Support Enabled
INFO - 2024-11-18 18:58:41 --> Utf8 Class Initialized
INFO - 2024-11-18 18:58:41 --> URI Class Initialized
INFO - 2024-11-18 18:58:41 --> Router Class Initialized
INFO - 2024-11-18 18:58:41 --> Output Class Initialized
INFO - 2024-11-18 18:58:41 --> Security Class Initialized
DEBUG - 2024-11-18 18:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-18 18:58:41 --> Input Class Initialized
INFO - 2024-11-18 18:58:41 --> Language Class Initialized
ERROR - 2024-11-18 18:58:41 --> 404 Page Not Found: Sitemapxml/index
