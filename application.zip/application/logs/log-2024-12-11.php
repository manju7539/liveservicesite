<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-11 01:18:39 --> Model "MainModel" initialized
INFO - 2024-12-11 01:18:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-11 01:18:39 --> Final output sent to browser
DEBUG - 2024-12-11 01:18:39 --> Total execution time: 2.4327
INFO - 2024-12-11 18:51:41 --> Config Class Initialized
INFO - 2024-12-11 18:51:41 --> Hooks Class Initialized
DEBUG - 2024-12-11 18:51:41 --> UTF-8 Support Enabled
INFO - 2024-12-11 18:51:41 --> Utf8 Class Initialized
INFO - 2024-12-11 18:51:41 --> URI Class Initialized
INFO - 2024-12-11 18:51:41 --> Router Class Initialized
INFO - 2024-12-11 18:51:41 --> Output Class Initialized
INFO - 2024-12-11 18:51:41 --> Security Class Initialized
DEBUG - 2024-12-11 18:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 18:51:41 --> Input Class Initialized
INFO - 2024-12-11 18:51:41 --> Language Class Initialized
ERROR - 2024-12-11 18:51:42 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-11 18:51:42 --> Config Class Initialized
INFO - 2024-12-11 18:51:42 --> Hooks Class Initialized
DEBUG - 2024-12-11 18:51:42 --> UTF-8 Support Enabled
INFO - 2024-12-11 18:51:42 --> Utf8 Class Initialized
INFO - 2024-12-11 18:51:42 --> URI Class Initialized
DEBUG - 2024-12-11 18:51:42 --> No URI present. Default controller set.
INFO - 2024-12-11 18:51:42 --> Router Class Initialized
INFO - 2024-12-11 18:51:42 --> Output Class Initialized
INFO - 2024-12-11 18:51:42 --> Security Class Initialized
DEBUG - 2024-12-11 18:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-11 18:51:42 --> Input Class Initialized
INFO - 2024-12-11 18:51:42 --> Language Class Initialized
INFO - 2024-12-11 18:51:42 --> Loader Class Initialized
INFO - 2024-12-11 18:51:43 --> Helper loaded: url_helper
INFO - 2024-12-11 18:51:43 --> Helper loaded: html_helper
INFO - 2024-12-11 18:51:43 --> Helper loaded: file_helper
INFO - 2024-12-11 18:51:43 --> Helper loaded: string_helper
INFO - 2024-12-11 18:51:43 --> Helper loaded: form_helper
INFO - 2024-12-11 18:51:43 --> Helper loaded: my_helper
INFO - 2024-12-11 18:51:43 --> Database Driver Class Initialized
INFO - 2024-12-11 18:51:45 --> Upload Class Initialized
INFO - 2024-12-11 18:51:45 --> Email Class Initialized
INFO - 2024-12-11 18:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-11 18:51:46 --> Form Validation Class Initialized
INFO - 2024-12-11 18:51:46 --> Controller Class Initialized
