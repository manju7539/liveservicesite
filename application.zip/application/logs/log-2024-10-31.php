<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-31 05:24:24 --> Model "MainModel" initialized
INFO - 2024-10-31 05:24:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-31 05:24:24 --> Final output sent to browser
DEBUG - 2024-10-31 05:24:24 --> Total execution time: 2.6278
INFO - 2024-10-31 05:25:56 --> Model "MainModel" initialized
INFO - 2024-10-31 05:25:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-31 05:25:56 --> Final output sent to browser
DEBUG - 2024-10-31 05:25:56 --> Total execution time: 2.1358
INFO - 2024-10-31 04:08:29 --> Config Class Initialized
INFO - 2024-10-31 04:08:29 --> Hooks Class Initialized
DEBUG - 2024-10-31 04:08:29 --> UTF-8 Support Enabled
INFO - 2024-10-31 04:08:29 --> Utf8 Class Initialized
INFO - 2024-10-31 04:08:29 --> URI Class Initialized
DEBUG - 2024-10-31 04:08:29 --> No URI present. Default controller set.
INFO - 2024-10-31 04:08:29 --> Router Class Initialized
INFO - 2024-10-31 04:08:29 --> Output Class Initialized
INFO - 2024-10-31 04:08:29 --> Security Class Initialized
DEBUG - 2024-10-31 04:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 04:08:29 --> Input Class Initialized
INFO - 2024-10-31 04:08:29 --> Language Class Initialized
INFO - 2024-10-31 04:08:29 --> Loader Class Initialized
INFO - 2024-10-31 04:08:29 --> Helper loaded: url_helper
INFO - 2024-10-31 04:08:29 --> Helper loaded: html_helper
INFO - 2024-10-31 04:08:29 --> Helper loaded: file_helper
INFO - 2024-10-31 04:08:29 --> Helper loaded: string_helper
INFO - 2024-10-31 04:08:29 --> Helper loaded: form_helper
INFO - 2024-10-31 04:08:29 --> Helper loaded: my_helper
INFO - 2024-10-31 04:08:29 --> Database Driver Class Initialized
INFO - 2024-10-31 04:08:31 --> Upload Class Initialized
INFO - 2024-10-31 04:08:31 --> Email Class Initialized
INFO - 2024-10-31 04:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-31 04:08:31 --> Form Validation Class Initialized
INFO - 2024-10-31 04:08:31 --> Controller Class Initialized
INFO - 2024-10-31 09:38:31 --> Model "MainModel" initialized
INFO - 2024-10-31 09:38:32 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-31 09:38:32 --> Final output sent to browser
DEBUG - 2024-10-31 09:38:32 --> Total execution time: 2.3507
INFO - 2024-10-31 08:40:57 --> Config Class Initialized
INFO - 2024-10-31 08:40:57 --> Hooks Class Initialized
DEBUG - 2024-10-31 08:40:57 --> UTF-8 Support Enabled
INFO - 2024-10-31 08:40:57 --> Utf8 Class Initialized
INFO - 2024-10-31 08:40:57 --> URI Class Initialized
DEBUG - 2024-10-31 08:40:57 --> No URI present. Default controller set.
INFO - 2024-10-31 08:40:57 --> Router Class Initialized
INFO - 2024-10-31 08:40:57 --> Output Class Initialized
INFO - 2024-10-31 08:40:57 --> Security Class Initialized
DEBUG - 2024-10-31 08:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 08:40:57 --> Input Class Initialized
INFO - 2024-10-31 08:40:57 --> Language Class Initialized
INFO - 2024-10-31 08:40:57 --> Loader Class Initialized
INFO - 2024-10-31 08:40:57 --> Helper loaded: url_helper
INFO - 2024-10-31 08:40:57 --> Helper loaded: html_helper
INFO - 2024-10-31 08:40:57 --> Helper loaded: file_helper
INFO - 2024-10-31 08:40:57 --> Helper loaded: string_helper
INFO - 2024-10-31 08:40:57 --> Helper loaded: form_helper
INFO - 2024-10-31 08:40:57 --> Helper loaded: my_helper
INFO - 2024-10-31 08:40:57 --> Database Driver Class Initialized
INFO - 2024-10-31 08:40:59 --> Upload Class Initialized
INFO - 2024-10-31 08:40:59 --> Email Class Initialized
INFO - 2024-10-31 08:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-31 08:40:59 --> Form Validation Class Initialized
INFO - 2024-10-31 08:40:59 --> Controller Class Initialized
INFO - 2024-10-31 14:10:59 --> Model "MainModel" initialized
INFO - 2024-10-31 14:10:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-31 14:10:59 --> Final output sent to browser
DEBUG - 2024-10-31 14:10:59 --> Total execution time: 2.2643
INFO - 2024-10-31 22:43:22 --> Config Class Initialized
INFO - 2024-10-31 22:43:22 --> Hooks Class Initialized
DEBUG - 2024-10-31 22:43:22 --> UTF-8 Support Enabled
INFO - 2024-10-31 22:43:22 --> Utf8 Class Initialized
INFO - 2024-10-31 22:43:22 --> URI Class Initialized
DEBUG - 2024-10-31 22:43:22 --> No URI present. Default controller set.
INFO - 2024-10-31 22:43:22 --> Router Class Initialized
INFO - 2024-10-31 22:43:22 --> Output Class Initialized
INFO - 2024-10-31 22:43:22 --> Security Class Initialized
DEBUG - 2024-10-31 22:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-31 22:43:22 --> Input Class Initialized
INFO - 2024-10-31 22:43:22 --> Language Class Initialized
INFO - 2024-10-31 22:43:22 --> Loader Class Initialized
INFO - 2024-10-31 22:43:22 --> Helper loaded: url_helper
INFO - 2024-10-31 22:43:22 --> Helper loaded: html_helper
INFO - 2024-10-31 22:43:22 --> Helper loaded: file_helper
INFO - 2024-10-31 22:43:22 --> Helper loaded: string_helper
INFO - 2024-10-31 22:43:22 --> Helper loaded: form_helper
INFO - 2024-10-31 22:43:22 --> Helper loaded: my_helper
INFO - 2024-10-31 22:43:22 --> Database Driver Class Initialized
INFO - 2024-10-31 22:43:24 --> Upload Class Initialized
INFO - 2024-10-31 22:43:24 --> Email Class Initialized
INFO - 2024-10-31 22:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-31 22:43:24 --> Form Validation Class Initialized
INFO - 2024-10-31 22:43:24 --> Controller Class Initialized
