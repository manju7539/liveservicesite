<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-16 16:53:35 --> Config Class Initialized
INFO - 2024-11-16 16:53:35 --> Hooks Class Initialized
DEBUG - 2024-11-16 16:53:35 --> UTF-8 Support Enabled
INFO - 2024-11-16 16:53:35 --> Utf8 Class Initialized
INFO - 2024-11-16 16:53:35 --> URI Class Initialized
DEBUG - 2024-11-16 16:53:35 --> No URI present. Default controller set.
INFO - 2024-11-16 16:53:35 --> Router Class Initialized
INFO - 2024-11-16 16:53:35 --> Output Class Initialized
INFO - 2024-11-16 16:53:35 --> Security Class Initialized
DEBUG - 2024-11-16 16:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-16 16:53:35 --> Input Class Initialized
INFO - 2024-11-16 16:53:35 --> Language Class Initialized
INFO - 2024-11-16 16:53:35 --> Loader Class Initialized
INFO - 2024-11-16 16:53:35 --> Helper loaded: url_helper
INFO - 2024-11-16 16:53:35 --> Helper loaded: html_helper
INFO - 2024-11-16 16:53:35 --> Helper loaded: file_helper
INFO - 2024-11-16 16:53:35 --> Helper loaded: string_helper
INFO - 2024-11-16 16:53:35 --> Helper loaded: form_helper
INFO - 2024-11-16 16:53:35 --> Helper loaded: my_helper
INFO - 2024-11-16 16:53:35 --> Database Driver Class Initialized
INFO - 2024-11-16 16:53:37 --> Upload Class Initialized
INFO - 2024-11-16 16:53:37 --> Email Class Initialized
INFO - 2024-11-16 16:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-16 16:53:37 --> Form Validation Class Initialized
INFO - 2024-11-16 16:53:37 --> Controller Class Initialized
INFO - 2024-11-16 22:23:37 --> Model "MainModel" initialized
INFO - 2024-11-16 22:23:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-16 22:23:37 --> Final output sent to browser
DEBUG - 2024-11-16 22:23:37 --> Total execution time: 2.9261
