<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-07 01:51:28 --> Config Class Initialized
INFO - 2024-12-07 01:51:28 --> Hooks Class Initialized
DEBUG - 2024-12-07 01:51:28 --> UTF-8 Support Enabled
INFO - 2024-12-07 01:51:28 --> Utf8 Class Initialized
INFO - 2024-12-07 01:51:28 --> URI Class Initialized
DEBUG - 2024-12-07 01:51:29 --> No URI present. Default controller set.
INFO - 2024-12-07 01:51:29 --> Router Class Initialized
INFO - 2024-12-07 01:51:29 --> Output Class Initialized
INFO - 2024-12-07 01:51:29 --> Security Class Initialized
DEBUG - 2024-12-07 01:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 01:51:29 --> Input Class Initialized
INFO - 2024-12-07 01:51:29 --> Language Class Initialized
INFO - 2024-12-07 01:51:29 --> Loader Class Initialized
INFO - 2024-12-07 01:51:29 --> Helper loaded: url_helper
INFO - 2024-12-07 01:51:29 --> Helper loaded: html_helper
INFO - 2024-12-07 01:51:29 --> Helper loaded: file_helper
INFO - 2024-12-07 01:51:29 --> Helper loaded: string_helper
INFO - 2024-12-07 01:51:29 --> Helper loaded: form_helper
INFO - 2024-12-07 01:51:29 --> Helper loaded: my_helper
INFO - 2024-12-07 01:51:29 --> Database Driver Class Initialized
INFO - 2024-12-07 01:51:31 --> Upload Class Initialized
INFO - 2024-12-07 01:51:31 --> Email Class Initialized
INFO - 2024-12-07 01:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 01:51:31 --> Form Validation Class Initialized
INFO - 2024-12-07 01:51:31 --> Controller Class Initialized
INFO - 2024-12-07 07:21:31 --> Model "MainModel" initialized
INFO - 2024-12-07 07:21:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-07 07:21:31 --> Final output sent to browser
DEBUG - 2024-12-07 07:21:31 --> Total execution time: 2.9900
INFO - 2024-12-07 04:25:28 --> Config Class Initialized
INFO - 2024-12-07 04:25:28 --> Hooks Class Initialized
DEBUG - 2024-12-07 04:25:28 --> UTF-8 Support Enabled
INFO - 2024-12-07 04:25:28 --> Utf8 Class Initialized
INFO - 2024-12-07 04:25:28 --> URI Class Initialized
INFO - 2024-12-07 04:25:28 --> Router Class Initialized
INFO - 2024-12-07 04:25:28 --> Output Class Initialized
INFO - 2024-12-07 04:25:28 --> Security Class Initialized
DEBUG - 2024-12-07 04:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 04:25:28 --> Input Class Initialized
INFO - 2024-12-07 04:25:28 --> Language Class Initialized
ERROR - 2024-12-07 04:25:28 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-07 05:43:41 --> Config Class Initialized
INFO - 2024-12-07 05:43:41 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:43:44 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:43:44 --> Utf8 Class Initialized
INFO - 2024-12-07 05:43:49 --> URI Class Initialized
DEBUG - 2024-12-07 05:43:51 --> No URI present. Default controller set.
INFO - 2024-12-07 05:43:51 --> Router Class Initialized
INFO - 2024-12-07 05:43:51 --> Output Class Initialized
INFO - 2024-12-07 05:43:51 --> Security Class Initialized
DEBUG - 2024-12-07 05:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:43:53 --> Input Class Initialized
INFO - 2024-12-07 05:43:54 --> Language Class Initialized
INFO - 2024-12-07 05:43:57 --> Loader Class Initialized
INFO - 2024-12-07 05:43:58 --> Helper loaded: url_helper
INFO - 2024-12-07 05:43:58 --> Helper loaded: html_helper
INFO - 2024-12-07 05:43:59 --> Helper loaded: file_helper
INFO - 2024-12-07 05:43:59 --> Helper loaded: string_helper
INFO - 2024-12-07 05:43:59 --> Helper loaded: form_helper
INFO - 2024-12-07 05:43:59 --> Helper loaded: my_helper
ERROR - 2024-12-07 05:44:06 --> Severity: Error --> Maximum execution time of 60 seconds exceeded C:\inetpub\vhosts\livservice.in\httpdocs\system\database\DB.php 197
INFO - 2024-12-07 05:44:09 --> Config Class Initialized
INFO - 2024-12-07 05:44:09 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:09 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:09 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:10 --> URI Class Initialized
INFO - 2024-12-07 05:44:11 --> Router Class Initialized
INFO - 2024-12-07 05:44:11 --> Output Class Initialized
INFO - 2024-12-07 05:44:11 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:11 --> Input Class Initialized
INFO - 2024-12-07 05:44:11 --> Language Class Initialized
ERROR - 2024-12-07 05:44:11 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-07 05:44:11 --> Config Class Initialized
INFO - 2024-12-07 05:44:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:11 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:11 --> URI Class Initialized
INFO - 2024-12-07 05:44:11 --> Router Class Initialized
INFO - 2024-12-07 05:44:11 --> Output Class Initialized
INFO - 2024-12-07 05:44:11 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:11 --> Input Class Initialized
INFO - 2024-12-07 05:44:11 --> Language Class Initialized
ERROR - 2024-12-07 05:44:11 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-07 05:44:11 --> Config Class Initialized
INFO - 2024-12-07 05:44:11 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:11 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:11 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:11 --> URI Class Initialized
INFO - 2024-12-07 05:44:11 --> Router Class Initialized
INFO - 2024-12-07 05:44:11 --> Output Class Initialized
INFO - 2024-12-07 05:44:11 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:11 --> Input Class Initialized
INFO - 2024-12-07 05:44:11 --> Language Class Initialized
ERROR - 2024-12-07 05:44:11 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-07 05:44:12 --> Config Class Initialized
INFO - 2024-12-07 05:44:12 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:12 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:12 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:12 --> URI Class Initialized
INFO - 2024-12-07 05:44:12 --> Router Class Initialized
INFO - 2024-12-07 05:44:12 --> Output Class Initialized
INFO - 2024-12-07 05:44:12 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:12 --> Input Class Initialized
INFO - 2024-12-07 05:44:12 --> Language Class Initialized
ERROR - 2024-12-07 05:44:12 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-07 05:44:12 --> Config Class Initialized
INFO - 2024-12-07 05:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:13 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:13 --> URI Class Initialized
INFO - 2024-12-07 05:44:13 --> Router Class Initialized
INFO - 2024-12-07 05:44:13 --> Output Class Initialized
INFO - 2024-12-07 05:44:13 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:13 --> Input Class Initialized
INFO - 2024-12-07 05:44:13 --> Language Class Initialized
ERROR - 2024-12-07 05:44:13 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-07 05:44:13 --> Config Class Initialized
INFO - 2024-12-07 05:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:13 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:13 --> URI Class Initialized
INFO - 2024-12-07 05:44:13 --> Router Class Initialized
INFO - 2024-12-07 05:44:13 --> Output Class Initialized
INFO - 2024-12-07 05:44:13 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:13 --> Input Class Initialized
INFO - 2024-12-07 05:44:13 --> Language Class Initialized
ERROR - 2024-12-07 05:44:13 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-07 05:44:13 --> Config Class Initialized
INFO - 2024-12-07 05:44:13 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:13 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:13 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:13 --> URI Class Initialized
INFO - 2024-12-07 05:44:13 --> Router Class Initialized
INFO - 2024-12-07 05:44:13 --> Output Class Initialized
INFO - 2024-12-07 05:44:13 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:13 --> Input Class Initialized
INFO - 2024-12-07 05:44:13 --> Language Class Initialized
ERROR - 2024-12-07 05:44:13 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-12-07 05:44:14 --> Config Class Initialized
INFO - 2024-12-07 05:44:14 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:14 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:14 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:14 --> URI Class Initialized
INFO - 2024-12-07 05:44:14 --> Router Class Initialized
INFO - 2024-12-07 05:44:14 --> Output Class Initialized
INFO - 2024-12-07 05:44:14 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:14 --> Input Class Initialized
INFO - 2024-12-07 05:44:14 --> Language Class Initialized
ERROR - 2024-12-07 05:44:14 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-07 05:44:14 --> Config Class Initialized
INFO - 2024-12-07 05:44:15 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:15 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:15 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:15 --> URI Class Initialized
INFO - 2024-12-07 05:44:15 --> Router Class Initialized
INFO - 2024-12-07 05:44:15 --> Output Class Initialized
INFO - 2024-12-07 05:44:15 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:15 --> Input Class Initialized
INFO - 2024-12-07 05:44:15 --> Language Class Initialized
ERROR - 2024-12-07 05:44:15 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-07 05:44:15 --> Config Class Initialized
INFO - 2024-12-07 05:44:15 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:15 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:15 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:15 --> URI Class Initialized
INFO - 2024-12-07 05:44:15 --> Router Class Initialized
INFO - 2024-12-07 05:44:15 --> Output Class Initialized
INFO - 2024-12-07 05:44:15 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:15 --> Input Class Initialized
INFO - 2024-12-07 05:44:15 --> Language Class Initialized
ERROR - 2024-12-07 05:44:15 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-07 05:44:16 --> Config Class Initialized
INFO - 2024-12-07 05:44:16 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:16 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:16 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:16 --> URI Class Initialized
INFO - 2024-12-07 05:44:16 --> Router Class Initialized
INFO - 2024-12-07 05:44:16 --> Output Class Initialized
INFO - 2024-12-07 05:44:16 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:16 --> Input Class Initialized
INFO - 2024-12-07 05:44:16 --> Language Class Initialized
ERROR - 2024-12-07 05:44:16 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-07 05:44:16 --> Config Class Initialized
INFO - 2024-12-07 05:44:17 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:17 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:17 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:17 --> URI Class Initialized
INFO - 2024-12-07 05:44:17 --> Router Class Initialized
INFO - 2024-12-07 05:44:17 --> Output Class Initialized
INFO - 2024-12-07 05:44:17 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:17 --> Input Class Initialized
INFO - 2024-12-07 05:44:17 --> Language Class Initialized
ERROR - 2024-12-07 05:44:17 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-12-07 05:44:17 --> Config Class Initialized
INFO - 2024-12-07 05:44:17 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:17 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:17 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:17 --> URI Class Initialized
INFO - 2024-12-07 05:44:17 --> Router Class Initialized
INFO - 2024-12-07 05:44:17 --> Output Class Initialized
INFO - 2024-12-07 05:44:17 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:17 --> Input Class Initialized
INFO - 2024-12-07 05:44:17 --> Language Class Initialized
ERROR - 2024-12-07 05:44:17 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-07 05:44:18 --> Config Class Initialized
INFO - 2024-12-07 05:44:18 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:18 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:18 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:18 --> URI Class Initialized
INFO - 2024-12-07 05:44:18 --> Router Class Initialized
INFO - 2024-12-07 05:44:18 --> Output Class Initialized
INFO - 2024-12-07 05:44:18 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:18 --> Input Class Initialized
INFO - 2024-12-07 05:44:18 --> Language Class Initialized
ERROR - 2024-12-07 05:44:18 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-07 05:44:18 --> Config Class Initialized
INFO - 2024-12-07 05:44:18 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:18 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:18 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:18 --> URI Class Initialized
INFO - 2024-12-07 05:44:18 --> Router Class Initialized
INFO - 2024-12-07 05:44:18 --> Output Class Initialized
INFO - 2024-12-07 05:44:18 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:18 --> Input Class Initialized
INFO - 2024-12-07 05:44:18 --> Language Class Initialized
ERROR - 2024-12-07 05:44:18 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-07 05:44:18 --> Config Class Initialized
INFO - 2024-12-07 05:44:18 --> Hooks Class Initialized
DEBUG - 2024-12-07 05:44:18 --> UTF-8 Support Enabled
INFO - 2024-12-07 05:44:18 --> Utf8 Class Initialized
INFO - 2024-12-07 05:44:18 --> URI Class Initialized
INFO - 2024-12-07 05:44:18 --> Router Class Initialized
INFO - 2024-12-07 05:44:18 --> Output Class Initialized
INFO - 2024-12-07 05:44:18 --> Security Class Initialized
DEBUG - 2024-12-07 05:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 05:44:19 --> Input Class Initialized
INFO - 2024-12-07 05:44:19 --> Language Class Initialized
ERROR - 2024-12-07 05:44:19 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-12-07 11:34:08 --> Config Class Initialized
INFO - 2024-12-07 11:34:08 --> Hooks Class Initialized
DEBUG - 2024-12-07 11:34:08 --> UTF-8 Support Enabled
INFO - 2024-12-07 11:34:08 --> Utf8 Class Initialized
INFO - 2024-12-07 11:34:08 --> URI Class Initialized
INFO - 2024-12-07 11:34:08 --> Router Class Initialized
INFO - 2024-12-07 11:34:08 --> Output Class Initialized
INFO - 2024-12-07 11:34:08 --> Security Class Initialized
DEBUG - 2024-12-07 11:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 11:34:08 --> Input Class Initialized
INFO - 2024-12-07 11:34:08 --> Language Class Initialized
ERROR - 2024-12-07 11:34:08 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-07 11:34:10 --> Config Class Initialized
INFO - 2024-12-07 11:34:10 --> Hooks Class Initialized
DEBUG - 2024-12-07 11:34:10 --> UTF-8 Support Enabled
INFO - 2024-12-07 11:34:10 --> Utf8 Class Initialized
INFO - 2024-12-07 11:34:10 --> URI Class Initialized
DEBUG - 2024-12-07 11:34:10 --> No URI present. Default controller set.
INFO - 2024-12-07 11:34:10 --> Router Class Initialized
INFO - 2024-12-07 11:34:10 --> Output Class Initialized
INFO - 2024-12-07 11:34:10 --> Security Class Initialized
DEBUG - 2024-12-07 11:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-07 11:34:10 --> Input Class Initialized
INFO - 2024-12-07 11:34:10 --> Language Class Initialized
INFO - 2024-12-07 11:34:10 --> Loader Class Initialized
INFO - 2024-12-07 11:34:10 --> Helper loaded: url_helper
INFO - 2024-12-07 11:34:10 --> Helper loaded: html_helper
INFO - 2024-12-07 11:34:10 --> Helper loaded: file_helper
INFO - 2024-12-07 11:34:10 --> Helper loaded: string_helper
INFO - 2024-12-07 11:34:10 --> Helper loaded: form_helper
INFO - 2024-12-07 11:34:10 --> Helper loaded: my_helper
INFO - 2024-12-07 11:34:10 --> Database Driver Class Initialized
INFO - 2024-12-07 11:34:12 --> Upload Class Initialized
INFO - 2024-12-07 11:34:12 --> Email Class Initialized
INFO - 2024-12-07 11:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-07 11:34:12 --> Form Validation Class Initialized
INFO - 2024-12-07 11:34:12 --> Controller Class Initialized
INFO - 2024-12-07 17:04:12 --> Model "MainModel" initialized
INFO - 2024-12-07 17:04:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-07 17:04:13 --> Final output sent to browser
DEBUG - 2024-12-07 17:04:13 --> Total execution time: 3.0111
