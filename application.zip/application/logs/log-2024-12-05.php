<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-05 08:36:34 --> Config Class Initialized
INFO - 2024-12-05 08:36:34 --> Hooks Class Initialized
DEBUG - 2024-12-05 08:36:34 --> UTF-8 Support Enabled
INFO - 2024-12-05 08:36:34 --> Utf8 Class Initialized
INFO - 2024-12-05 08:36:34 --> URI Class Initialized
DEBUG - 2024-12-05 08:36:34 --> No URI present. Default controller set.
INFO - 2024-12-05 08:36:34 --> Router Class Initialized
INFO - 2024-12-05 08:36:34 --> Output Class Initialized
INFO - 2024-12-05 08:36:34 --> Security Class Initialized
DEBUG - 2024-12-05 08:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 08:36:34 --> Input Class Initialized
INFO - 2024-12-05 08:36:34 --> Language Class Initialized
INFO - 2024-12-05 08:36:34 --> Loader Class Initialized
INFO - 2024-12-05 08:36:34 --> Helper loaded: url_helper
INFO - 2024-12-05 08:36:34 --> Helper loaded: html_helper
INFO - 2024-12-05 08:36:34 --> Helper loaded: file_helper
INFO - 2024-12-05 08:36:34 --> Helper loaded: string_helper
INFO - 2024-12-05 08:36:34 --> Helper loaded: form_helper
INFO - 2024-12-05 08:36:34 --> Helper loaded: my_helper
INFO - 2024-12-05 08:36:34 --> Database Driver Class Initialized
INFO - 2024-12-05 08:36:36 --> Upload Class Initialized
INFO - 2024-12-05 08:36:36 --> Email Class Initialized
INFO - 2024-12-05 08:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 08:36:37 --> Form Validation Class Initialized
INFO - 2024-12-05 08:36:37 --> Controller Class Initialized
INFO - 2024-12-05 14:06:37 --> Model "MainModel" initialized
INFO - 2024-12-05 14:06:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-05 14:06:37 --> Final output sent to browser
DEBUG - 2024-12-05 14:06:37 --> Total execution time: 3.3012
INFO - 2024-12-05 08:36:41 --> Config Class Initialized
INFO - 2024-12-05 08:36:41 --> Hooks Class Initialized
DEBUG - 2024-12-05 08:36:41 --> UTF-8 Support Enabled
INFO - 2024-12-05 08:36:41 --> Utf8 Class Initialized
INFO - 2024-12-05 08:36:41 --> URI Class Initialized
INFO - 2024-12-05 08:36:41 --> Router Class Initialized
INFO - 2024-12-05 08:36:41 --> Output Class Initialized
INFO - 2024-12-05 08:36:41 --> Security Class Initialized
DEBUG - 2024-12-05 08:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 08:36:41 --> Input Class Initialized
INFO - 2024-12-05 08:36:41 --> Language Class Initialized
ERROR - 2024-12-05 08:36:41 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-05 10:37:11 --> Config Class Initialized
INFO - 2024-12-05 10:37:11 --> Hooks Class Initialized
DEBUG - 2024-12-05 10:37:11 --> UTF-8 Support Enabled
INFO - 2024-12-05 10:37:11 --> Utf8 Class Initialized
INFO - 2024-12-05 10:37:11 --> URI Class Initialized
DEBUG - 2024-12-05 10:37:11 --> No URI present. Default controller set.
INFO - 2024-12-05 10:37:11 --> Router Class Initialized
INFO - 2024-12-05 10:37:11 --> Output Class Initialized
INFO - 2024-12-05 10:37:11 --> Security Class Initialized
DEBUG - 2024-12-05 10:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 10:37:11 --> Input Class Initialized
INFO - 2024-12-05 10:37:11 --> Language Class Initialized
INFO - 2024-12-05 10:37:11 --> Loader Class Initialized
INFO - 2024-12-05 10:37:11 --> Helper loaded: url_helper
INFO - 2024-12-05 10:37:11 --> Helper loaded: html_helper
INFO - 2024-12-05 10:37:11 --> Helper loaded: file_helper
INFO - 2024-12-05 10:37:11 --> Helper loaded: string_helper
INFO - 2024-12-05 10:37:11 --> Helper loaded: form_helper
INFO - 2024-12-05 10:37:11 --> Helper loaded: my_helper
INFO - 2024-12-05 10:37:11 --> Database Driver Class Initialized
INFO - 2024-12-05 10:37:13 --> Upload Class Initialized
INFO - 2024-12-05 10:37:13 --> Email Class Initialized
INFO - 2024-12-05 10:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-05 10:37:13 --> Form Validation Class Initialized
INFO - 2024-12-05 10:37:13 --> Controller Class Initialized
INFO - 2024-12-05 16:07:13 --> Model "MainModel" initialized
INFO - 2024-12-05 16:07:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-05 16:07:13 --> Final output sent to browser
DEBUG - 2024-12-05 16:07:13 --> Total execution time: 2.3574
INFO - 2024-12-05 10:37:18 --> Config Class Initialized
INFO - 2024-12-05 10:37:18 --> Hooks Class Initialized
DEBUG - 2024-12-05 10:37:18 --> UTF-8 Support Enabled
INFO - 2024-12-05 10:37:18 --> Utf8 Class Initialized
INFO - 2024-12-05 10:37:18 --> URI Class Initialized
INFO - 2024-12-05 10:37:18 --> Router Class Initialized
INFO - 2024-12-05 10:37:18 --> Output Class Initialized
INFO - 2024-12-05 10:37:18 --> Security Class Initialized
DEBUG - 2024-12-05 10:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-05 10:37:18 --> Input Class Initialized
INFO - 2024-12-05 10:37:18 --> Language Class Initialized
ERROR - 2024-12-05 10:37:18 --> 404 Page Not Found: Faviconico/index
