<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-06 01:55:46 --> Model "MainModel" initialized
INFO - 2024-11-06 01:55:46 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-06 01:55:46 --> Final output sent to browser
DEBUG - 2024-11-06 01:55:46 --> Total execution time: 2.2020
INFO - 2024-11-06 03:16:03 --> Config Class Initialized
INFO - 2024-11-06 03:16:03 --> Hooks Class Initialized
DEBUG - 2024-11-06 03:16:03 --> UTF-8 Support Enabled
INFO - 2024-11-06 03:16:03 --> Utf8 Class Initialized
INFO - 2024-11-06 03:16:03 --> URI Class Initialized
DEBUG - 2024-11-06 03:16:03 --> No URI present. Default controller set.
INFO - 2024-11-06 03:16:03 --> Router Class Initialized
INFO - 2024-11-06 03:16:03 --> Output Class Initialized
INFO - 2024-11-06 03:16:03 --> Security Class Initialized
DEBUG - 2024-11-06 03:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 03:16:03 --> Input Class Initialized
INFO - 2024-11-06 03:16:03 --> Language Class Initialized
INFO - 2024-11-06 03:16:03 --> Loader Class Initialized
INFO - 2024-11-06 03:16:03 --> Helper loaded: url_helper
INFO - 2024-11-06 03:16:03 --> Helper loaded: html_helper
INFO - 2024-11-06 03:16:03 --> Helper loaded: file_helper
INFO - 2024-11-06 03:16:03 --> Helper loaded: string_helper
INFO - 2024-11-06 03:16:03 --> Helper loaded: form_helper
INFO - 2024-11-06 03:16:03 --> Helper loaded: my_helper
INFO - 2024-11-06 03:16:03 --> Database Driver Class Initialized
INFO - 2024-11-06 03:16:05 --> Upload Class Initialized
INFO - 2024-11-06 03:16:05 --> Email Class Initialized
INFO - 2024-11-06 03:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 03:16:06 --> Form Validation Class Initialized
INFO - 2024-11-06 03:16:06 --> Controller Class Initialized
INFO - 2024-11-06 08:46:06 --> Model "MainModel" initialized
INFO - 2024-11-06 08:46:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-06 08:46:06 --> Final output sent to browser
DEBUG - 2024-11-06 08:46:06 --> Total execution time: 2.6165
INFO - 2024-11-06 10:04:16 --> Config Class Initialized
INFO - 2024-11-06 10:04:16 --> Hooks Class Initialized
DEBUG - 2024-11-06 10:04:16 --> UTF-8 Support Enabled
INFO - 2024-11-06 10:04:16 --> Utf8 Class Initialized
INFO - 2024-11-06 10:04:17 --> URI Class Initialized
DEBUG - 2024-11-06 10:04:17 --> No URI present. Default controller set.
INFO - 2024-11-06 10:04:17 --> Router Class Initialized
INFO - 2024-11-06 10:04:17 --> Output Class Initialized
INFO - 2024-11-06 10:04:17 --> Security Class Initialized
DEBUG - 2024-11-06 10:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 10:04:17 --> Input Class Initialized
INFO - 2024-11-06 10:04:17 --> Language Class Initialized
INFO - 2024-11-06 10:04:17 --> Loader Class Initialized
INFO - 2024-11-06 10:04:17 --> Helper loaded: url_helper
INFO - 2024-11-06 10:04:17 --> Helper loaded: html_helper
INFO - 2024-11-06 10:04:17 --> Helper loaded: file_helper
INFO - 2024-11-06 10:04:17 --> Helper loaded: string_helper
INFO - 2024-11-06 10:04:17 --> Helper loaded: form_helper
INFO - 2024-11-06 10:04:17 --> Helper loaded: my_helper
INFO - 2024-11-06 10:04:17 --> Database Driver Class Initialized
INFO - 2024-11-06 10:04:19 --> Upload Class Initialized
INFO - 2024-11-06 10:04:19 --> Email Class Initialized
INFO - 2024-11-06 10:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 10:04:19 --> Form Validation Class Initialized
INFO - 2024-11-06 10:04:19 --> Controller Class Initialized
INFO - 2024-11-06 15:34:19 --> Model "MainModel" initialized
INFO - 2024-11-06 15:34:19 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-06 15:34:19 --> Final output sent to browser
DEBUG - 2024-11-06 15:34:19 --> Total execution time: 3.0738
INFO - 2024-11-06 17:52:19 --> Config Class Initialized
INFO - 2024-11-06 17:52:19 --> Hooks Class Initialized
DEBUG - 2024-11-06 17:52:19 --> UTF-8 Support Enabled
INFO - 2024-11-06 17:52:19 --> Utf8 Class Initialized
INFO - 2024-11-06 17:52:19 --> URI Class Initialized
DEBUG - 2024-11-06 17:52:19 --> No URI present. Default controller set.
INFO - 2024-11-06 17:52:19 --> Router Class Initialized
INFO - 2024-11-06 17:52:19 --> Output Class Initialized
INFO - 2024-11-06 17:52:19 --> Security Class Initialized
DEBUG - 2024-11-06 17:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 17:52:19 --> Input Class Initialized
INFO - 2024-11-06 17:52:19 --> Language Class Initialized
INFO - 2024-11-06 17:52:19 --> Loader Class Initialized
INFO - 2024-11-06 17:52:19 --> Helper loaded: url_helper
INFO - 2024-11-06 17:52:19 --> Helper loaded: html_helper
INFO - 2024-11-06 17:52:19 --> Helper loaded: file_helper
INFO - 2024-11-06 17:52:19 --> Helper loaded: string_helper
INFO - 2024-11-06 17:52:19 --> Helper loaded: form_helper
INFO - 2024-11-06 17:52:19 --> Helper loaded: my_helper
INFO - 2024-11-06 17:52:19 --> Database Driver Class Initialized
INFO - 2024-11-06 17:52:21 --> Upload Class Initialized
INFO - 2024-11-06 17:52:21 --> Email Class Initialized
INFO - 2024-11-06 17:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 17:52:21 --> Form Validation Class Initialized
INFO - 2024-11-06 17:52:21 --> Controller Class Initialized
INFO - 2024-11-06 23:22:21 --> Model "MainModel" initialized
INFO - 2024-11-06 23:22:21 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-06 23:22:21 --> Final output sent to browser
DEBUG - 2024-11-06 23:22:21 --> Total execution time: 2.6654
INFO - 2024-11-06 17:52:23 --> Config Class Initialized
INFO - 2024-11-06 17:52:23 --> Hooks Class Initialized
DEBUG - 2024-11-06 17:52:23 --> UTF-8 Support Enabled
INFO - 2024-11-06 17:52:23 --> Utf8 Class Initialized
INFO - 2024-11-06 17:52:23 --> URI Class Initialized
DEBUG - 2024-11-06 17:52:23 --> No URI present. Default controller set.
INFO - 2024-11-06 17:52:23 --> Router Class Initialized
INFO - 2024-11-06 17:52:23 --> Output Class Initialized
INFO - 2024-11-06 17:52:23 --> Security Class Initialized
DEBUG - 2024-11-06 17:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 17:52:23 --> Input Class Initialized
INFO - 2024-11-06 17:52:23 --> Language Class Initialized
INFO - 2024-11-06 17:52:23 --> Loader Class Initialized
INFO - 2024-11-06 17:52:23 --> Helper loaded: url_helper
INFO - 2024-11-06 17:52:23 --> Helper loaded: html_helper
INFO - 2024-11-06 17:52:23 --> Helper loaded: file_helper
INFO - 2024-11-06 17:52:23 --> Helper loaded: string_helper
INFO - 2024-11-06 17:52:23 --> Helper loaded: form_helper
INFO - 2024-11-06 17:52:23 --> Helper loaded: my_helper
INFO - 2024-11-06 17:52:23 --> Database Driver Class Initialized
INFO - 2024-11-06 17:52:25 --> Upload Class Initialized
INFO - 2024-11-06 17:52:25 --> Email Class Initialized
INFO - 2024-11-06 17:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 17:52:25 --> Form Validation Class Initialized
INFO - 2024-11-06 17:52:25 --> Controller Class Initialized
INFO - 2024-11-06 23:22:25 --> Model "MainModel" initialized
INFO - 2024-11-06 23:22:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-06 23:22:25 --> Final output sent to browser
DEBUG - 2024-11-06 23:22:25 --> Total execution time: 2.2028
INFO - 2024-11-06 17:52:26 --> Config Class Initialized
INFO - 2024-11-06 17:52:26 --> Hooks Class Initialized
DEBUG - 2024-11-06 17:52:26 --> UTF-8 Support Enabled
INFO - 2024-11-06 17:52:26 --> Utf8 Class Initialized
INFO - 2024-11-06 17:52:26 --> URI Class Initialized
DEBUG - 2024-11-06 17:52:26 --> No URI present. Default controller set.
INFO - 2024-11-06 17:52:26 --> Router Class Initialized
INFO - 2024-11-06 17:52:26 --> Output Class Initialized
INFO - 2024-11-06 17:52:26 --> Security Class Initialized
DEBUG - 2024-11-06 17:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 17:52:26 --> Input Class Initialized
INFO - 2024-11-06 17:52:26 --> Language Class Initialized
INFO - 2024-11-06 17:52:26 --> Loader Class Initialized
INFO - 2024-11-06 17:52:26 --> Helper loaded: url_helper
INFO - 2024-11-06 17:52:26 --> Helper loaded: html_helper
INFO - 2024-11-06 17:52:26 --> Helper loaded: file_helper
INFO - 2024-11-06 17:52:26 --> Helper loaded: string_helper
INFO - 2024-11-06 17:52:26 --> Helper loaded: form_helper
INFO - 2024-11-06 17:52:26 --> Helper loaded: my_helper
INFO - 2024-11-06 17:52:26 --> Database Driver Class Initialized
INFO - 2024-11-06 17:52:28 --> Upload Class Initialized
INFO - 2024-11-06 17:52:28 --> Email Class Initialized
INFO - 2024-11-06 17:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 17:52:28 --> Form Validation Class Initialized
INFO - 2024-11-06 17:52:28 --> Controller Class Initialized
INFO - 2024-11-06 23:22:28 --> Model "MainModel" initialized
INFO - 2024-11-06 23:22:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-06 23:22:28 --> Final output sent to browser
DEBUG - 2024-11-06 23:22:28 --> Total execution time: 2.1098
INFO - 2024-11-06 17:52:30 --> Config Class Initialized
INFO - 2024-11-06 17:52:30 --> Hooks Class Initialized
DEBUG - 2024-11-06 17:52:30 --> UTF-8 Support Enabled
INFO - 2024-11-06 17:52:30 --> Utf8 Class Initialized
INFO - 2024-11-06 17:52:30 --> URI Class Initialized
DEBUG - 2024-11-06 17:52:30 --> No URI present. Default controller set.
INFO - 2024-11-06 17:52:30 --> Router Class Initialized
INFO - 2024-11-06 17:52:30 --> Output Class Initialized
INFO - 2024-11-06 17:52:30 --> Security Class Initialized
DEBUG - 2024-11-06 17:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 17:52:30 --> Input Class Initialized
INFO - 2024-11-06 17:52:30 --> Language Class Initialized
INFO - 2024-11-06 17:52:30 --> Loader Class Initialized
INFO - 2024-11-06 17:52:30 --> Helper loaded: url_helper
INFO - 2024-11-06 17:52:30 --> Helper loaded: html_helper
INFO - 2024-11-06 17:52:30 --> Helper loaded: file_helper
INFO - 2024-11-06 17:52:30 --> Helper loaded: string_helper
INFO - 2024-11-06 17:52:30 --> Helper loaded: form_helper
INFO - 2024-11-06 17:52:30 --> Helper loaded: my_helper
INFO - 2024-11-06 17:52:30 --> Database Driver Class Initialized
INFO - 2024-11-06 17:52:32 --> Upload Class Initialized
INFO - 2024-11-06 17:52:32 --> Email Class Initialized
INFO - 2024-11-06 17:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 17:52:32 --> Form Validation Class Initialized
INFO - 2024-11-06 17:52:32 --> Controller Class Initialized
INFO - 2024-11-06 23:22:32 --> Model "MainModel" initialized
INFO - 2024-11-06 23:22:32 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-06 23:22:32 --> Final output sent to browser
DEBUG - 2024-11-06 23:22:32 --> Total execution time: 2.1588
INFO - 2024-11-06 23:47:08 --> Config Class Initialized
INFO - 2024-11-06 23:47:08 --> Hooks Class Initialized
DEBUG - 2024-11-06 23:47:08 --> UTF-8 Support Enabled
INFO - 2024-11-06 23:47:08 --> Utf8 Class Initialized
INFO - 2024-11-06 23:47:08 --> URI Class Initialized
INFO - 2024-11-06 23:47:08 --> Router Class Initialized
INFO - 2024-11-06 23:47:08 --> Output Class Initialized
INFO - 2024-11-06 23:47:08 --> Security Class Initialized
DEBUG - 2024-11-06 23:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 23:47:08 --> Input Class Initialized
INFO - 2024-11-06 23:47:08 --> Language Class Initialized
ERROR - 2024-11-06 23:47:08 --> 404 Page Not Found: Wp-loginphp/index
