<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-09 01:07:20 --> Config Class Initialized
INFO - 2024-12-09 01:07:20 --> Hooks Class Initialized
DEBUG - 2024-12-09 01:07:20 --> UTF-8 Support Enabled
INFO - 2024-12-09 01:07:20 --> Utf8 Class Initialized
INFO - 2024-12-09 01:07:20 --> URI Class Initialized
DEBUG - 2024-12-09 01:07:20 --> No URI present. Default controller set.
INFO - 2024-12-09 01:07:20 --> Router Class Initialized
INFO - 2024-12-09 01:07:20 --> Output Class Initialized
INFO - 2024-12-09 01:07:20 --> Security Class Initialized
DEBUG - 2024-12-09 01:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 01:07:20 --> Input Class Initialized
INFO - 2024-12-09 01:07:20 --> Language Class Initialized
INFO - 2024-12-09 01:07:20 --> Loader Class Initialized
INFO - 2024-12-09 01:07:20 --> Helper loaded: url_helper
INFO - 2024-12-09 01:07:20 --> Helper loaded: html_helper
INFO - 2024-12-09 01:07:20 --> Helper loaded: file_helper
INFO - 2024-12-09 01:07:20 --> Helper loaded: string_helper
INFO - 2024-12-09 01:07:20 --> Helper loaded: form_helper
INFO - 2024-12-09 01:07:20 --> Helper loaded: my_helper
INFO - 2024-12-09 01:07:20 --> Database Driver Class Initialized
INFO - 2024-12-09 01:07:22 --> Upload Class Initialized
INFO - 2024-12-09 01:07:22 --> Email Class Initialized
INFO - 2024-12-09 01:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 01:07:22 --> Form Validation Class Initialized
INFO - 2024-12-09 01:07:22 --> Controller Class Initialized
INFO - 2024-12-09 06:37:22 --> Model "MainModel" initialized
INFO - 2024-12-09 06:37:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-09 06:37:22 --> Final output sent to browser
DEBUG - 2024-12-09 06:37:22 --> Total execution time: 2.4860
INFO - 2024-12-09 05:07:34 --> Config Class Initialized
INFO - 2024-12-09 05:07:34 --> Hooks Class Initialized
DEBUG - 2024-12-09 05:07:34 --> UTF-8 Support Enabled
INFO - 2024-12-09 05:07:34 --> Utf8 Class Initialized
INFO - 2024-12-09 05:07:34 --> URI Class Initialized
INFO - 2024-12-09 05:07:34 --> Router Class Initialized
INFO - 2024-12-09 05:07:34 --> Output Class Initialized
INFO - 2024-12-09 05:07:34 --> Security Class Initialized
DEBUG - 2024-12-09 05:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 05:07:34 --> Input Class Initialized
INFO - 2024-12-09 05:07:34 --> Language Class Initialized
ERROR - 2024-12-09 05:07:34 --> 404 Page Not Found: Wp-loginphp/index
INFO - 2024-12-09 05:14:32 --> Config Class Initialized
INFO - 2024-12-09 05:14:32 --> Hooks Class Initialized
DEBUG - 2024-12-09 05:14:32 --> UTF-8 Support Enabled
INFO - 2024-12-09 05:14:32 --> Utf8 Class Initialized
INFO - 2024-12-09 05:14:32 --> URI Class Initialized
DEBUG - 2024-12-09 05:14:32 --> No URI present. Default controller set.
INFO - 2024-12-09 05:14:32 --> Router Class Initialized
INFO - 2024-12-09 05:14:32 --> Output Class Initialized
INFO - 2024-12-09 05:14:32 --> Security Class Initialized
DEBUG - 2024-12-09 05:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 05:14:32 --> Input Class Initialized
INFO - 2024-12-09 05:14:32 --> Language Class Initialized
INFO - 2024-12-09 05:14:32 --> Loader Class Initialized
INFO - 2024-12-09 05:14:32 --> Helper loaded: url_helper
INFO - 2024-12-09 05:14:32 --> Helper loaded: html_helper
INFO - 2024-12-09 05:14:32 --> Helper loaded: file_helper
INFO - 2024-12-09 05:14:32 --> Helper loaded: string_helper
INFO - 2024-12-09 05:14:32 --> Helper loaded: form_helper
INFO - 2024-12-09 05:14:32 --> Helper loaded: my_helper
INFO - 2024-12-09 05:14:32 --> Database Driver Class Initialized
INFO - 2024-12-09 05:14:34 --> Upload Class Initialized
INFO - 2024-12-09 05:14:34 --> Email Class Initialized
INFO - 2024-12-09 05:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-09 05:14:34 --> Form Validation Class Initialized
INFO - 2024-12-09 05:14:34 --> Controller Class Initialized
INFO - 2024-12-09 10:44:34 --> Model "MainModel" initialized
INFO - 2024-12-09 10:44:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-09 10:44:34 --> Final output sent to browser
DEBUG - 2024-12-09 10:44:34 --> Total execution time: 2.2857
INFO - 2024-12-09 05:14:38 --> Config Class Initialized
INFO - 2024-12-09 05:14:38 --> Hooks Class Initialized
DEBUG - 2024-12-09 05:14:38 --> UTF-8 Support Enabled
INFO - 2024-12-09 05:14:38 --> Utf8 Class Initialized
INFO - 2024-12-09 05:14:38 --> URI Class Initialized
INFO - 2024-12-09 05:14:38 --> Router Class Initialized
INFO - 2024-12-09 05:14:38 --> Output Class Initialized
INFO - 2024-12-09 05:14:38 --> Security Class Initialized
DEBUG - 2024-12-09 05:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-09 05:14:38 --> Input Class Initialized
INFO - 2024-12-09 05:14:38 --> Language Class Initialized
ERROR - 2024-12-09 05:14:38 --> 404 Page Not Found: Adstxt/index
