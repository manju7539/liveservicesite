<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-30 03:18:35 --> Config Class Initialized
INFO - 2024-10-30 03:18:35 --> Hooks Class Initialized
DEBUG - 2024-10-30 03:18:35 --> UTF-8 Support Enabled
INFO - 2024-10-30 03:18:35 --> Utf8 Class Initialized
INFO - 2024-10-30 03:18:35 --> URI Class Initialized
DEBUG - 2024-10-30 03:18:35 --> No URI present. Default controller set.
INFO - 2024-10-30 03:18:35 --> Router Class Initialized
INFO - 2024-10-30 03:18:35 --> Output Class Initialized
INFO - 2024-10-30 03:18:35 --> Security Class Initialized
DEBUG - 2024-10-30 03:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 03:18:35 --> Input Class Initialized
INFO - 2024-10-30 03:18:35 --> Language Class Initialized
INFO - 2024-10-30 03:18:35 --> Loader Class Initialized
INFO - 2024-10-30 03:18:35 --> Helper loaded: url_helper
INFO - 2024-10-30 03:18:35 --> Helper loaded: html_helper
INFO - 2024-10-30 03:18:35 --> Helper loaded: file_helper
INFO - 2024-10-30 03:18:35 --> Helper loaded: string_helper
INFO - 2024-10-30 03:18:35 --> Helper loaded: form_helper
INFO - 2024-10-30 03:18:35 --> Helper loaded: my_helper
INFO - 2024-10-30 03:18:35 --> Database Driver Class Initialized
INFO - 2024-10-30 03:18:37 --> Upload Class Initialized
INFO - 2024-10-30 03:18:38 --> Email Class Initialized
INFO - 2024-10-30 03:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 03:18:38 --> Form Validation Class Initialized
INFO - 2024-10-30 03:18:38 --> Controller Class Initialized
INFO - 2024-10-30 08:48:38 --> Model "MainModel" initialized
INFO - 2024-10-30 08:48:38 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 08:48:38 --> Final output sent to browser
DEBUG - 2024-10-30 08:48:38 --> Total execution time: 2.6281
INFO - 2024-10-30 07:19:18 --> Config Class Initialized
INFO - 2024-10-30 07:19:18 --> Hooks Class Initialized
DEBUG - 2024-10-30 07:19:18 --> UTF-8 Support Enabled
INFO - 2024-10-30 07:19:18 --> Utf8 Class Initialized
INFO - 2024-10-30 07:19:18 --> URI Class Initialized
INFO - 2024-10-30 07:19:18 --> Router Class Initialized
INFO - 2024-10-30 07:19:18 --> Output Class Initialized
INFO - 2024-10-30 07:19:18 --> Security Class Initialized
DEBUG - 2024-10-30 07:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 07:19:18 --> Input Class Initialized
INFO - 2024-10-30 07:19:18 --> Language Class Initialized
INFO - 2024-10-30 07:19:18 --> Loader Class Initialized
INFO - 2024-10-30 07:19:18 --> Helper loaded: url_helper
INFO - 2024-10-30 07:19:18 --> Helper loaded: html_helper
INFO - 2024-10-30 07:19:18 --> Helper loaded: file_helper
INFO - 2024-10-30 07:19:18 --> Helper loaded: string_helper
INFO - 2024-10-30 07:19:18 --> Helper loaded: form_helper
INFO - 2024-10-30 07:19:18 --> Helper loaded: my_helper
INFO - 2024-10-30 07:19:18 --> Database Driver Class Initialized
INFO - 2024-10-30 07:19:20 --> Upload Class Initialized
INFO - 2024-10-30 07:19:20 --> Email Class Initialized
INFO - 2024-10-30 07:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 07:19:20 --> Form Validation Class Initialized
INFO - 2024-10-30 07:19:20 --> Controller Class Initialized
INFO - 2024-10-30 12:49:20 --> Model "SuperAdminModel" initialized
INFO - 2024-10-30 12:49:20 --> Helper loaded: notification_helper
INFO - 2024-10-30 12:49:20 --> Model "MainModel" initialized
INFO - 2024-10-30 07:19:21 --> Config Class Initialized
INFO - 2024-10-30 07:19:21 --> Hooks Class Initialized
DEBUG - 2024-10-30 07:19:21 --> UTF-8 Support Enabled
INFO - 2024-10-30 07:19:21 --> Utf8 Class Initialized
INFO - 2024-10-30 07:19:21 --> URI Class Initialized
DEBUG - 2024-10-30 07:19:21 --> No URI present. Default controller set.
INFO - 2024-10-30 07:19:21 --> Router Class Initialized
INFO - 2024-10-30 07:19:21 --> Output Class Initialized
INFO - 2024-10-30 07:19:21 --> Security Class Initialized
DEBUG - 2024-10-30 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 07:19:21 --> Input Class Initialized
INFO - 2024-10-30 07:19:21 --> Language Class Initialized
INFO - 2024-10-30 07:19:21 --> Loader Class Initialized
INFO - 2024-10-30 07:19:21 --> Helper loaded: url_helper
INFO - 2024-10-30 07:19:21 --> Helper loaded: html_helper
INFO - 2024-10-30 07:19:21 --> Helper loaded: file_helper
INFO - 2024-10-30 07:19:21 --> Helper loaded: string_helper
INFO - 2024-10-30 07:19:21 --> Helper loaded: form_helper
INFO - 2024-10-30 07:19:21 --> Helper loaded: my_helper
INFO - 2024-10-30 07:19:21 --> Database Driver Class Initialized
INFO - 2024-10-30 07:19:22 --> Config Class Initialized
INFO - 2024-10-30 07:19:22 --> Hooks Class Initialized
DEBUG - 2024-10-30 07:19:22 --> UTF-8 Support Enabled
INFO - 2024-10-30 07:19:22 --> Utf8 Class Initialized
INFO - 2024-10-30 07:19:22 --> URI Class Initialized
INFO - 2024-10-30 07:19:22 --> Router Class Initialized
INFO - 2024-10-30 07:19:22 --> Output Class Initialized
INFO - 2024-10-30 07:19:22 --> Security Class Initialized
DEBUG - 2024-10-30 07:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 07:19:22 --> Input Class Initialized
INFO - 2024-10-30 07:19:22 --> Language Class Initialized
ERROR - 2024-10-30 07:19:22 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-30 07:19:23 --> Upload Class Initialized
INFO - 2024-10-30 07:19:24 --> Email Class Initialized
INFO - 2024-10-30 07:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 07:19:24 --> Form Validation Class Initialized
INFO - 2024-10-30 07:19:24 --> Controller Class Initialized
INFO - 2024-10-30 12:49:24 --> Model "MainModel" initialized
INFO - 2024-10-30 12:49:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 12:49:24 --> Final output sent to browser
DEBUG - 2024-10-30 12:49:24 --> Total execution time: 2.3500
INFO - 2024-10-30 07:41:09 --> Config Class Initialized
INFO - 2024-10-30 07:41:09 --> Hooks Class Initialized
DEBUG - 2024-10-30 07:41:09 --> UTF-8 Support Enabled
INFO - 2024-10-30 07:41:09 --> Utf8 Class Initialized
INFO - 2024-10-30 07:41:09 --> URI Class Initialized
DEBUG - 2024-10-30 07:41:09 --> No URI present. Default controller set.
INFO - 2024-10-30 07:41:09 --> Router Class Initialized
INFO - 2024-10-30 07:41:09 --> Output Class Initialized
INFO - 2024-10-30 07:41:09 --> Security Class Initialized
DEBUG - 2024-10-30 07:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 07:41:09 --> Input Class Initialized
INFO - 2024-10-30 07:41:09 --> Language Class Initialized
INFO - 2024-10-30 07:41:09 --> Loader Class Initialized
INFO - 2024-10-30 07:41:09 --> Helper loaded: url_helper
INFO - 2024-10-30 07:41:09 --> Helper loaded: html_helper
INFO - 2024-10-30 07:41:09 --> Helper loaded: file_helper
INFO - 2024-10-30 07:41:09 --> Helper loaded: string_helper
INFO - 2024-10-30 07:41:09 --> Helper loaded: form_helper
INFO - 2024-10-30 07:41:09 --> Helper loaded: my_helper
INFO - 2024-10-30 07:41:09 --> Database Driver Class Initialized
INFO - 2024-10-30 07:41:11 --> Upload Class Initialized
INFO - 2024-10-30 07:41:11 --> Email Class Initialized
INFO - 2024-10-30 07:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 07:41:11 --> Form Validation Class Initialized
INFO - 2024-10-30 07:41:11 --> Controller Class Initialized
INFO - 2024-10-30 13:11:11 --> Model "MainModel" initialized
INFO - 2024-10-30 13:11:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 13:11:11 --> Final output sent to browser
DEBUG - 2024-10-30 13:11:11 --> Total execution time: 2.2095
INFO - 2024-10-30 07:41:13 --> Config Class Initialized
INFO - 2024-10-30 07:41:13 --> Hooks Class Initialized
DEBUG - 2024-10-30 07:41:13 --> UTF-8 Support Enabled
INFO - 2024-10-30 07:41:13 --> Utf8 Class Initialized
INFO - 2024-10-30 07:41:13 --> URI Class Initialized
INFO - 2024-10-30 07:41:13 --> Router Class Initialized
INFO - 2024-10-30 07:41:13 --> Output Class Initialized
INFO - 2024-10-30 07:41:13 --> Security Class Initialized
DEBUG - 2024-10-30 07:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 07:41:13 --> Input Class Initialized
INFO - 2024-10-30 07:41:13 --> Language Class Initialized
ERROR - 2024-10-30 07:41:13 --> 404 Page Not Found: Adstxt/index
INFO - 2024-10-30 07:41:13 --> Config Class Initialized
INFO - 2024-10-30 07:41:13 --> Hooks Class Initialized
DEBUG - 2024-10-30 07:41:13 --> UTF-8 Support Enabled
INFO - 2024-10-30 07:41:13 --> Utf8 Class Initialized
INFO - 2024-10-30 07:41:13 --> URI Class Initialized
INFO - 2024-10-30 07:41:13 --> Router Class Initialized
INFO - 2024-10-30 07:41:13 --> Output Class Initialized
INFO - 2024-10-30 07:41:13 --> Security Class Initialized
DEBUG - 2024-10-30 07:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 07:41:13 --> Input Class Initialized
INFO - 2024-10-30 07:41:13 --> Language Class Initialized
ERROR - 2024-10-30 07:41:13 --> 404 Page Not Found: App-adstxt/index
INFO - 2024-10-30 07:41:14 --> Config Class Initialized
INFO - 2024-10-30 07:41:14 --> Hooks Class Initialized
DEBUG - 2024-10-30 07:41:14 --> UTF-8 Support Enabled
INFO - 2024-10-30 07:41:14 --> Utf8 Class Initialized
INFO - 2024-10-30 07:41:14 --> URI Class Initialized
INFO - 2024-10-30 07:41:14 --> Router Class Initialized
INFO - 2024-10-30 07:41:14 --> Output Class Initialized
INFO - 2024-10-30 07:41:14 --> Security Class Initialized
DEBUG - 2024-10-30 07:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 07:41:14 --> Input Class Initialized
INFO - 2024-10-30 07:41:14 --> Language Class Initialized
ERROR - 2024-10-30 07:41:14 --> 404 Page Not Found: Sellersjson/index
INFO - 2024-10-30 08:12:52 --> Config Class Initialized
INFO - 2024-10-30 08:12:52 --> Hooks Class Initialized
DEBUG - 2024-10-30 08:12:52 --> UTF-8 Support Enabled
INFO - 2024-10-30 08:12:52 --> Utf8 Class Initialized
INFO - 2024-10-30 08:12:52 --> URI Class Initialized
DEBUG - 2024-10-30 08:12:52 --> No URI present. Default controller set.
INFO - 2024-10-30 08:12:52 --> Router Class Initialized
INFO - 2024-10-30 08:12:52 --> Output Class Initialized
INFO - 2024-10-30 08:12:52 --> Security Class Initialized
DEBUG - 2024-10-30 08:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 08:12:52 --> Input Class Initialized
INFO - 2024-10-30 08:12:52 --> Language Class Initialized
INFO - 2024-10-30 08:12:52 --> Loader Class Initialized
INFO - 2024-10-30 08:12:52 --> Helper loaded: url_helper
INFO - 2024-10-30 08:12:52 --> Helper loaded: html_helper
INFO - 2024-10-30 08:12:52 --> Helper loaded: file_helper
INFO - 2024-10-30 08:12:52 --> Helper loaded: string_helper
INFO - 2024-10-30 08:12:52 --> Helper loaded: form_helper
INFO - 2024-10-30 08:12:52 --> Helper loaded: my_helper
INFO - 2024-10-30 08:12:52 --> Database Driver Class Initialized
INFO - 2024-10-30 08:12:54 --> Upload Class Initialized
INFO - 2024-10-30 08:12:55 --> Email Class Initialized
INFO - 2024-10-30 08:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 08:12:55 --> Form Validation Class Initialized
INFO - 2024-10-30 08:12:55 --> Controller Class Initialized
INFO - 2024-10-30 13:42:55 --> Model "MainModel" initialized
INFO - 2024-10-30 13:42:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 13:42:55 --> Final output sent to browser
DEBUG - 2024-10-30 13:42:55 --> Total execution time: 2.2038
INFO - 2024-10-30 09:26:10 --> Config Class Initialized
INFO - 2024-10-30 09:26:10 --> Hooks Class Initialized
INFO - 2024-10-30 09:26:10 --> Config Class Initialized
INFO - 2024-10-30 09:26:10 --> Hooks Class Initialized
DEBUG - 2024-10-30 09:26:10 --> UTF-8 Support Enabled
INFO - 2024-10-30 09:26:10 --> Utf8 Class Initialized
DEBUG - 2024-10-30 09:26:10 --> UTF-8 Support Enabled
INFO - 2024-10-30 09:26:10 --> URI Class Initialized
INFO - 2024-10-30 09:26:10 --> Utf8 Class Initialized
INFO - 2024-10-30 09:26:10 --> URI Class Initialized
DEBUG - 2024-10-30 09:26:10 --> No URI present. Default controller set.
INFO - 2024-10-30 09:26:10 --> Router Class Initialized
DEBUG - 2024-10-30 09:26:10 --> No URI present. Default controller set.
INFO - 2024-10-30 09:26:10 --> Router Class Initialized
INFO - 2024-10-30 09:26:10 --> Output Class Initialized
INFO - 2024-10-30 09:26:10 --> Output Class Initialized
INFO - 2024-10-30 09:26:10 --> Security Class Initialized
INFO - 2024-10-30 09:26:10 --> Security Class Initialized
DEBUG - 2024-10-30 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-30 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 09:26:10 --> Input Class Initialized
INFO - 2024-10-30 09:26:10 --> Input Class Initialized
INFO - 2024-10-30 09:26:10 --> Language Class Initialized
INFO - 2024-10-30 09:26:10 --> Language Class Initialized
INFO - 2024-10-30 09:26:10 --> Loader Class Initialized
INFO - 2024-10-30 09:26:10 --> Loader Class Initialized
INFO - 2024-10-30 09:26:10 --> Helper loaded: url_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: url_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: html_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: html_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: file_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: file_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: string_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: string_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: form_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: form_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: my_helper
INFO - 2024-10-30 09:26:10 --> Helper loaded: my_helper
INFO - 2024-10-30 09:26:10 --> Database Driver Class Initialized
INFO - 2024-10-30 09:26:10 --> Database Driver Class Initialized
INFO - 2024-10-30 09:26:12 --> Upload Class Initialized
INFO - 2024-10-30 09:26:12 --> Upload Class Initialized
INFO - 2024-10-30 09:26:12 --> Email Class Initialized
INFO - 2024-10-30 09:26:12 --> Email Class Initialized
INFO - 2024-10-30 09:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 09:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 09:26:12 --> Form Validation Class Initialized
INFO - 2024-10-30 09:26:12 --> Controller Class Initialized
INFO - 2024-10-30 09:26:12 --> Form Validation Class Initialized
INFO - 2024-10-30 09:26:12 --> Controller Class Initialized
INFO - 2024-10-30 14:56:12 --> Model "MainModel" initialized
INFO - 2024-10-30 14:56:12 --> Model "MainModel" initialized
INFO - 2024-10-30 14:56:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 14:56:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 14:56:12 --> Final output sent to browser
INFO - 2024-10-30 14:56:12 --> Final output sent to browser
DEBUG - 2024-10-30 14:56:12 --> Total execution time: 2.3102
DEBUG - 2024-10-30 14:56:12 --> Total execution time: 2.3221
INFO - 2024-10-30 09:26:13 --> Config Class Initialized
INFO - 2024-10-30 09:26:13 --> Hooks Class Initialized
DEBUG - 2024-10-30 09:26:13 --> UTF-8 Support Enabled
INFO - 2024-10-30 09:26:13 --> Utf8 Class Initialized
INFO - 2024-10-30 09:26:13 --> URI Class Initialized
DEBUG - 2024-10-30 09:26:13 --> No URI present. Default controller set.
INFO - 2024-10-30 09:26:13 --> Router Class Initialized
INFO - 2024-10-30 09:26:13 --> Output Class Initialized
INFO - 2024-10-30 09:26:13 --> Security Class Initialized
DEBUG - 2024-10-30 09:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 09:26:13 --> Input Class Initialized
INFO - 2024-10-30 09:26:13 --> Language Class Initialized
INFO - 2024-10-30 09:26:13 --> Loader Class Initialized
INFO - 2024-10-30 09:26:14 --> Helper loaded: url_helper
INFO - 2024-10-30 09:26:14 --> Helper loaded: html_helper
INFO - 2024-10-30 09:26:14 --> Helper loaded: file_helper
INFO - 2024-10-30 09:26:14 --> Helper loaded: string_helper
INFO - 2024-10-30 09:26:14 --> Helper loaded: form_helper
INFO - 2024-10-30 09:26:14 --> Helper loaded: my_helper
INFO - 2024-10-30 09:26:14 --> Database Driver Class Initialized
INFO - 2024-10-30 09:26:16 --> Upload Class Initialized
INFO - 2024-10-30 09:26:16 --> Email Class Initialized
INFO - 2024-10-30 09:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 09:26:16 --> Form Validation Class Initialized
INFO - 2024-10-30 09:26:16 --> Controller Class Initialized
INFO - 2024-10-30 14:56:16 --> Model "MainModel" initialized
INFO - 2024-10-30 14:56:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 14:56:16 --> Final output sent to browser
DEBUG - 2024-10-30 14:56:16 --> Total execution time: 2.4339
INFO - 2024-10-30 09:26:16 --> Config Class Initialized
INFO - 2024-10-30 09:26:16 --> Hooks Class Initialized
DEBUG - 2024-10-30 09:26:16 --> UTF-8 Support Enabled
INFO - 2024-10-30 09:26:16 --> Utf8 Class Initialized
INFO - 2024-10-30 09:26:16 --> URI Class Initialized
DEBUG - 2024-10-30 09:26:16 --> No URI present. Default controller set.
INFO - 2024-10-30 09:26:16 --> Router Class Initialized
INFO - 2024-10-30 09:26:16 --> Output Class Initialized
INFO - 2024-10-30 09:26:16 --> Security Class Initialized
DEBUG - 2024-10-30 09:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 09:26:16 --> Input Class Initialized
INFO - 2024-10-30 09:26:16 --> Language Class Initialized
INFO - 2024-10-30 09:26:16 --> Loader Class Initialized
INFO - 2024-10-30 09:26:16 --> Helper loaded: url_helper
INFO - 2024-10-30 09:26:16 --> Helper loaded: html_helper
INFO - 2024-10-30 09:26:16 --> Helper loaded: file_helper
INFO - 2024-10-30 09:26:16 --> Helper loaded: string_helper
INFO - 2024-10-30 09:26:16 --> Helper loaded: form_helper
INFO - 2024-10-30 09:26:16 --> Helper loaded: my_helper
INFO - 2024-10-30 09:26:16 --> Database Driver Class Initialized
INFO - 2024-10-30 09:26:18 --> Upload Class Initialized
INFO - 2024-10-30 09:26:18 --> Email Class Initialized
INFO - 2024-10-30 09:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 09:26:18 --> Form Validation Class Initialized
INFO - 2024-10-30 09:26:18 --> Controller Class Initialized
INFO - 2024-10-30 14:56:18 --> Model "MainModel" initialized
INFO - 2024-10-30 14:56:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 14:56:18 --> Final output sent to browser
DEBUG - 2024-10-30 14:56:18 --> Total execution time: 2.2258
INFO - 2024-10-30 09:59:25 --> Config Class Initialized
INFO - 2024-10-30 09:59:25 --> Hooks Class Initialized
DEBUG - 2024-10-30 09:59:25 --> UTF-8 Support Enabled
INFO - 2024-10-30 09:59:25 --> Utf8 Class Initialized
INFO - 2024-10-30 09:59:25 --> URI Class Initialized
DEBUG - 2024-10-30 09:59:25 --> No URI present. Default controller set.
INFO - 2024-10-30 09:59:25 --> Router Class Initialized
INFO - 2024-10-30 09:59:25 --> Output Class Initialized
INFO - 2024-10-30 09:59:25 --> Security Class Initialized
DEBUG - 2024-10-30 09:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 09:59:25 --> Input Class Initialized
INFO - 2024-10-30 09:59:25 --> Language Class Initialized
INFO - 2024-10-30 09:59:25 --> Loader Class Initialized
INFO - 2024-10-30 09:59:25 --> Helper loaded: url_helper
INFO - 2024-10-30 09:59:25 --> Helper loaded: html_helper
INFO - 2024-10-30 09:59:25 --> Helper loaded: file_helper
INFO - 2024-10-30 09:59:25 --> Helper loaded: string_helper
INFO - 2024-10-30 09:59:25 --> Helper loaded: form_helper
INFO - 2024-10-30 09:59:25 --> Helper loaded: my_helper
INFO - 2024-10-30 09:59:25 --> Database Driver Class Initialized
INFO - 2024-10-30 09:59:27 --> Upload Class Initialized
INFO - 2024-10-30 09:59:27 --> Email Class Initialized
INFO - 2024-10-30 09:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 09:59:27 --> Form Validation Class Initialized
INFO - 2024-10-30 09:59:27 --> Controller Class Initialized
INFO - 2024-10-30 15:29:27 --> Model "MainModel" initialized
INFO - 2024-10-30 15:29:27 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 15:29:27 --> Final output sent to browser
DEBUG - 2024-10-30 15:29:27 --> Total execution time: 2.1935
INFO - 2024-10-30 11:18:32 --> Config Class Initialized
INFO - 2024-10-30 11:18:32 --> Hooks Class Initialized
DEBUG - 2024-10-30 11:18:32 --> UTF-8 Support Enabled
INFO - 2024-10-30 11:18:32 --> Utf8 Class Initialized
INFO - 2024-10-30 11:18:33 --> URI Class Initialized
DEBUG - 2024-10-30 11:18:33 --> No URI present. Default controller set.
INFO - 2024-10-30 11:18:33 --> Router Class Initialized
INFO - 2024-10-30 11:18:33 --> Output Class Initialized
INFO - 2024-10-30 11:18:33 --> Security Class Initialized
DEBUG - 2024-10-30 11:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 11:18:33 --> Input Class Initialized
INFO - 2024-10-30 11:18:33 --> Language Class Initialized
INFO - 2024-10-30 11:18:33 --> Loader Class Initialized
INFO - 2024-10-30 11:18:33 --> Helper loaded: url_helper
INFO - 2024-10-30 11:18:33 --> Helper loaded: html_helper
INFO - 2024-10-30 11:18:33 --> Helper loaded: file_helper
INFO - 2024-10-30 11:18:33 --> Helper loaded: string_helper
INFO - 2024-10-30 11:18:33 --> Helper loaded: form_helper
INFO - 2024-10-30 11:18:33 --> Helper loaded: my_helper
INFO - 2024-10-30 11:18:33 --> Database Driver Class Initialized
INFO - 2024-10-30 11:18:35 --> Upload Class Initialized
INFO - 2024-10-30 11:18:35 --> Email Class Initialized
INFO - 2024-10-30 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 11:18:35 --> Form Validation Class Initialized
INFO - 2024-10-30 11:18:35 --> Controller Class Initialized
INFO - 2024-10-30 16:48:35 --> Model "MainModel" initialized
INFO - 2024-10-30 16:48:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-30 16:48:35 --> Final output sent to browser
DEBUG - 2024-10-30 16:48:35 --> Total execution time: 2.2668
INFO - 2024-10-30 23:54:21 --> Config Class Initialized
INFO - 2024-10-30 23:54:21 --> Hooks Class Initialized
DEBUG - 2024-10-30 23:54:21 --> UTF-8 Support Enabled
INFO - 2024-10-30 23:54:21 --> Utf8 Class Initialized
INFO - 2024-10-30 23:54:21 --> URI Class Initialized
DEBUG - 2024-10-30 23:54:21 --> No URI present. Default controller set.
INFO - 2024-10-30 23:54:21 --> Router Class Initialized
INFO - 2024-10-30 23:54:22 --> Output Class Initialized
INFO - 2024-10-30 23:54:22 --> Security Class Initialized
DEBUG - 2024-10-30 23:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 23:54:22 --> Input Class Initialized
INFO - 2024-10-30 23:54:22 --> Language Class Initialized
INFO - 2024-10-30 23:54:22 --> Loader Class Initialized
INFO - 2024-10-30 23:54:22 --> Helper loaded: url_helper
INFO - 2024-10-30 23:54:22 --> Helper loaded: html_helper
INFO - 2024-10-30 23:54:22 --> Helper loaded: file_helper
INFO - 2024-10-30 23:54:22 --> Helper loaded: string_helper
INFO - 2024-10-30 23:54:22 --> Helper loaded: form_helper
INFO - 2024-10-30 23:54:22 --> Helper loaded: my_helper
INFO - 2024-10-30 23:54:22 --> Database Driver Class Initialized
INFO - 2024-10-30 23:54:24 --> Upload Class Initialized
INFO - 2024-10-30 23:54:24 --> Email Class Initialized
INFO - 2024-10-30 23:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 23:54:24 --> Form Validation Class Initialized
INFO - 2024-10-30 23:54:24 --> Controller Class Initialized
INFO - 2024-10-30 23:54:27 --> Config Class Initialized
INFO - 2024-10-30 23:54:27 --> Hooks Class Initialized
DEBUG - 2024-10-30 23:54:27 --> UTF-8 Support Enabled
INFO - 2024-10-30 23:54:27 --> Utf8 Class Initialized
INFO - 2024-10-30 23:54:27 --> URI Class Initialized
INFO - 2024-10-30 23:54:27 --> Router Class Initialized
INFO - 2024-10-30 23:54:27 --> Output Class Initialized
INFO - 2024-10-30 23:54:27 --> Security Class Initialized
DEBUG - 2024-10-30 23:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 23:54:27 --> Input Class Initialized
INFO - 2024-10-30 23:54:27 --> Language Class Initialized
ERROR - 2024-10-30 23:54:27 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-30 23:54:29 --> Config Class Initialized
INFO - 2024-10-30 23:54:29 --> Hooks Class Initialized
DEBUG - 2024-10-30 23:54:29 --> UTF-8 Support Enabled
INFO - 2024-10-30 23:54:29 --> Utf8 Class Initialized
INFO - 2024-10-30 23:54:29 --> URI Class Initialized
INFO - 2024-10-30 23:54:29 --> Router Class Initialized
INFO - 2024-10-30 23:54:29 --> Output Class Initialized
INFO - 2024-10-30 23:54:29 --> Security Class Initialized
DEBUG - 2024-10-30 23:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 23:54:29 --> Input Class Initialized
INFO - 2024-10-30 23:54:29 --> Language Class Initialized
ERROR - 2024-10-30 23:54:29 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-10-30 23:55:54 --> Config Class Initialized
INFO - 2024-10-30 23:55:54 --> Hooks Class Initialized
DEBUG - 2024-10-30 23:55:54 --> UTF-8 Support Enabled
INFO - 2024-10-30 23:55:54 --> Utf8 Class Initialized
INFO - 2024-10-30 23:55:54 --> URI Class Initialized
DEBUG - 2024-10-30 23:55:54 --> No URI present. Default controller set.
INFO - 2024-10-30 23:55:54 --> Router Class Initialized
INFO - 2024-10-30 23:55:54 --> Output Class Initialized
INFO - 2024-10-30 23:55:54 --> Security Class Initialized
DEBUG - 2024-10-30 23:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 23:55:54 --> Input Class Initialized
INFO - 2024-10-30 23:55:54 --> Language Class Initialized
INFO - 2024-10-30 23:55:54 --> Loader Class Initialized
INFO - 2024-10-30 23:55:54 --> Helper loaded: url_helper
INFO - 2024-10-30 23:55:54 --> Helper loaded: html_helper
INFO - 2024-10-30 23:55:54 --> Helper loaded: file_helper
INFO - 2024-10-30 23:55:54 --> Helper loaded: string_helper
INFO - 2024-10-30 23:55:54 --> Helper loaded: form_helper
INFO - 2024-10-30 23:55:54 --> Helper loaded: my_helper
INFO - 2024-10-30 23:55:54 --> Database Driver Class Initialized
INFO - 2024-10-30 23:55:56 --> Upload Class Initialized
INFO - 2024-10-30 23:55:56 --> Email Class Initialized
INFO - 2024-10-30 23:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-30 23:55:56 --> Form Validation Class Initialized
INFO - 2024-10-30 23:55:56 --> Controller Class Initialized
INFO - 2024-10-30 23:56:16 --> Config Class Initialized
INFO - 2024-10-30 23:56:16 --> Hooks Class Initialized
DEBUG - 2024-10-30 23:56:16 --> UTF-8 Support Enabled
INFO - 2024-10-30 23:56:16 --> Utf8 Class Initialized
INFO - 2024-10-30 23:56:16 --> URI Class Initialized
INFO - 2024-10-30 23:56:16 --> Router Class Initialized
INFO - 2024-10-30 23:56:16 --> Output Class Initialized
INFO - 2024-10-30 23:56:16 --> Security Class Initialized
DEBUG - 2024-10-30 23:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 23:56:16 --> Input Class Initialized
INFO - 2024-10-30 23:56:16 --> Language Class Initialized
ERROR - 2024-10-30 23:56:16 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-30 23:56:17 --> Config Class Initialized
INFO - 2024-10-30 23:56:17 --> Hooks Class Initialized
DEBUG - 2024-10-30 23:56:17 --> UTF-8 Support Enabled
INFO - 2024-10-30 23:56:17 --> Utf8 Class Initialized
INFO - 2024-10-30 23:56:17 --> URI Class Initialized
INFO - 2024-10-30 23:56:17 --> Router Class Initialized
INFO - 2024-10-30 23:56:17 --> Output Class Initialized
INFO - 2024-10-30 23:56:17 --> Security Class Initialized
DEBUG - 2024-10-30 23:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 23:56:17 --> Input Class Initialized
INFO - 2024-10-30 23:56:17 --> Language Class Initialized
ERROR - 2024-10-30 23:56:17 --> 404 Page Not Found: Sitemapxml/index
INFO - 2024-10-30 23:56:24 --> Config Class Initialized
INFO - 2024-10-30 23:56:24 --> Hooks Class Initialized
DEBUG - 2024-10-30 23:56:24 --> UTF-8 Support Enabled
INFO - 2024-10-30 23:56:24 --> Utf8 Class Initialized
INFO - 2024-10-30 23:56:24 --> URI Class Initialized
INFO - 2024-10-30 23:56:24 --> Router Class Initialized
INFO - 2024-10-30 23:56:24 --> Output Class Initialized
INFO - 2024-10-30 23:56:24 --> Security Class Initialized
DEBUG - 2024-10-30 23:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-30 23:56:24 --> Input Class Initialized
INFO - 2024-10-30 23:56:24 --> Language Class Initialized
ERROR - 2024-10-30 23:56:24 --> 404 Page Not Found: Configjson/index
