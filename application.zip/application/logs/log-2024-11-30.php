<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-30 07:56:33 --> Config Class Initialized
INFO - 2024-11-30 07:56:33 --> Hooks Class Initialized
DEBUG - 2024-11-30 07:56:33 --> UTF-8 Support Enabled
INFO - 2024-11-30 07:56:33 --> Utf8 Class Initialized
INFO - 2024-11-30 07:56:33 --> URI Class Initialized
INFO - 2024-11-30 07:56:33 --> Router Class Initialized
INFO - 2024-11-30 07:56:33 --> Output Class Initialized
INFO - 2024-11-30 07:56:33 --> Security Class Initialized
DEBUG - 2024-11-30 07:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-30 07:56:33 --> Input Class Initialized
INFO - 2024-11-30 07:56:33 --> Language Class Initialized
ERROR - 2024-11-30 07:56:33 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-11-30 12:50:49 --> Config Class Initialized
INFO - 2024-11-30 12:50:49 --> Hooks Class Initialized
DEBUG - 2024-11-30 12:50:49 --> UTF-8 Support Enabled
INFO - 2024-11-30 12:50:49 --> Utf8 Class Initialized
INFO - 2024-11-30 12:50:49 --> URI Class Initialized
DEBUG - 2024-11-30 12:50:49 --> No URI present. Default controller set.
INFO - 2024-11-30 12:50:49 --> Router Class Initialized
INFO - 2024-11-30 12:50:49 --> Output Class Initialized
INFO - 2024-11-30 12:50:49 --> Security Class Initialized
DEBUG - 2024-11-30 12:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-30 12:50:49 --> Input Class Initialized
INFO - 2024-11-30 12:50:49 --> Language Class Initialized
INFO - 2024-11-30 12:50:49 --> Loader Class Initialized
INFO - 2024-11-30 12:50:49 --> Helper loaded: url_helper
INFO - 2024-11-30 12:50:49 --> Helper loaded: html_helper
INFO - 2024-11-30 12:50:49 --> Helper loaded: file_helper
INFO - 2024-11-30 12:50:49 --> Helper loaded: string_helper
INFO - 2024-11-30 12:50:49 --> Helper loaded: form_helper
INFO - 2024-11-30 12:50:49 --> Helper loaded: my_helper
INFO - 2024-11-30 12:50:49 --> Database Driver Class Initialized
INFO - 2024-11-30 12:50:52 --> Upload Class Initialized
INFO - 2024-11-30 12:50:52 --> Email Class Initialized
INFO - 2024-11-30 12:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-30 12:50:52 --> Form Validation Class Initialized
INFO - 2024-11-30 12:50:52 --> Controller Class Initialized
INFO - 2024-11-30 18:20:52 --> Model "MainModel" initialized
INFO - 2024-11-30 18:20:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-30 18:20:52 --> Final output sent to browser
DEBUG - 2024-11-30 18:20:52 --> Total execution time: 2.8541
INFO - 2024-11-30 14:53:30 --> Config Class Initialized
INFO - 2024-11-30 14:53:30 --> Hooks Class Initialized
DEBUG - 2024-11-30 14:53:30 --> UTF-8 Support Enabled
INFO - 2024-11-30 14:53:30 --> Utf8 Class Initialized
INFO - 2024-11-30 14:53:30 --> URI Class Initialized
DEBUG - 2024-11-30 14:53:30 --> No URI present. Default controller set.
INFO - 2024-11-30 14:53:30 --> Router Class Initialized
INFO - 2024-11-30 14:53:30 --> Output Class Initialized
INFO - 2024-11-30 14:53:30 --> Security Class Initialized
DEBUG - 2024-11-30 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-30 14:53:30 --> Input Class Initialized
INFO - 2024-11-30 14:53:30 --> Language Class Initialized
INFO - 2024-11-30 14:53:30 --> Loader Class Initialized
INFO - 2024-11-30 14:53:30 --> Helper loaded: url_helper
INFO - 2024-11-30 14:53:30 --> Helper loaded: html_helper
INFO - 2024-11-30 14:53:30 --> Helper loaded: file_helper
INFO - 2024-11-30 14:53:30 --> Helper loaded: string_helper
INFO - 2024-11-30 14:53:30 --> Helper loaded: form_helper
INFO - 2024-11-30 14:53:30 --> Helper loaded: my_helper
INFO - 2024-11-30 14:53:30 --> Database Driver Class Initialized
INFO - 2024-11-30 14:53:32 --> Upload Class Initialized
INFO - 2024-11-30 14:53:32 --> Email Class Initialized
INFO - 2024-11-30 14:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-30 14:53:32 --> Form Validation Class Initialized
INFO - 2024-11-30 14:53:32 --> Controller Class Initialized
INFO - 2024-11-30 20:23:32 --> Model "MainModel" initialized
INFO - 2024-11-30 20:23:32 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-30 20:23:32 --> Final output sent to browser
DEBUG - 2024-11-30 20:23:32 --> Total execution time: 2.3252
