<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-29 01:56:23 --> Config Class Initialized
INFO - 2024-12-29 01:56:23 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:23 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:23 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:23 --> URI Class Initialized
INFO - 2024-12-29 01:56:23 --> Router Class Initialized
INFO - 2024-12-29 01:56:23 --> Output Class Initialized
INFO - 2024-12-29 01:56:23 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:23 --> Input Class Initialized
INFO - 2024-12-29 01:56:23 --> Language Class Initialized
ERROR - 2024-12-29 01:56:23 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:56:24 --> Config Class Initialized
INFO - 2024-12-29 01:56:24 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:24 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:24 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:24 --> URI Class Initialized
INFO - 2024-12-29 01:56:24 --> Router Class Initialized
INFO - 2024-12-29 01:56:24 --> Output Class Initialized
INFO - 2024-12-29 01:56:24 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:24 --> Input Class Initialized
INFO - 2024-12-29 01:56:24 --> Language Class Initialized
ERROR - 2024-12-29 01:56:24 --> 404 Page Not Found: 403php/index
INFO - 2024-12-29 01:56:24 --> Config Class Initialized
INFO - 2024-12-29 01:56:24 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:24 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:24 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:24 --> URI Class Initialized
INFO - 2024-12-29 01:56:24 --> Router Class Initialized
INFO - 2024-12-29 01:56:24 --> Output Class Initialized
INFO - 2024-12-29 01:56:24 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:24 --> Input Class Initialized
INFO - 2024-12-29 01:56:24 --> Language Class Initialized
ERROR - 2024-12-29 01:56:24 --> 404 Page Not Found: Contentphp/index
INFO - 2024-12-29 01:56:25 --> Config Class Initialized
INFO - 2024-12-29 01:56:25 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:25 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:25 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:25 --> URI Class Initialized
INFO - 2024-12-29 01:56:25 --> Router Class Initialized
INFO - 2024-12-29 01:56:25 --> Output Class Initialized
INFO - 2024-12-29 01:56:25 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:25 --> Input Class Initialized
INFO - 2024-12-29 01:56:25 --> Language Class Initialized
ERROR - 2024-12-29 01:56:25 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:56:25 --> Config Class Initialized
INFO - 2024-12-29 01:56:25 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:25 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:25 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:25 --> URI Class Initialized
INFO - 2024-12-29 01:56:25 --> Router Class Initialized
INFO - 2024-12-29 01:56:25 --> Output Class Initialized
INFO - 2024-12-29 01:56:25 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:25 --> Input Class Initialized
INFO - 2024-12-29 01:56:25 --> Language Class Initialized
ERROR - 2024-12-29 01:56:25 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:56:26 --> Config Class Initialized
INFO - 2024-12-29 01:56:26 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:26 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:26 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:26 --> URI Class Initialized
INFO - 2024-12-29 01:56:26 --> Router Class Initialized
INFO - 2024-12-29 01:56:26 --> Output Class Initialized
INFO - 2024-12-29 01:56:26 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:26 --> Input Class Initialized
INFO - 2024-12-29 01:56:26 --> Language Class Initialized
ERROR - 2024-12-29 01:56:26 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:56:26 --> Config Class Initialized
INFO - 2024-12-29 01:56:26 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:26 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:26 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:26 --> URI Class Initialized
INFO - 2024-12-29 01:56:26 --> Router Class Initialized
INFO - 2024-12-29 01:56:26 --> Output Class Initialized
INFO - 2024-12-29 01:56:26 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:26 --> Input Class Initialized
INFO - 2024-12-29 01:56:26 --> Language Class Initialized
ERROR - 2024-12-29 01:56:26 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:56:27 --> Config Class Initialized
INFO - 2024-12-29 01:56:27 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:27 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:27 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:27 --> URI Class Initialized
INFO - 2024-12-29 01:56:27 --> Router Class Initialized
INFO - 2024-12-29 01:56:27 --> Output Class Initialized
INFO - 2024-12-29 01:56:27 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:27 --> Input Class Initialized
INFO - 2024-12-29 01:56:27 --> Language Class Initialized
ERROR - 2024-12-29 01:56:27 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-29 01:56:27 --> Config Class Initialized
INFO - 2024-12-29 01:56:27 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:27 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:27 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:27 --> URI Class Initialized
INFO - 2024-12-29 01:56:27 --> Router Class Initialized
INFO - 2024-12-29 01:56:27 --> Output Class Initialized
INFO - 2024-12-29 01:56:27 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:27 --> Input Class Initialized
INFO - 2024-12-29 01:56:27 --> Language Class Initialized
ERROR - 2024-12-29 01:56:27 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:56:28 --> Config Class Initialized
INFO - 2024-12-29 01:56:28 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:28 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:28 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:28 --> URI Class Initialized
INFO - 2024-12-29 01:56:28 --> Router Class Initialized
INFO - 2024-12-29 01:56:28 --> Output Class Initialized
INFO - 2024-12-29 01:56:28 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:28 --> Input Class Initialized
INFO - 2024-12-29 01:56:28 --> Language Class Initialized
ERROR - 2024-12-29 01:56:28 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:56:28 --> Config Class Initialized
INFO - 2024-12-29 01:56:28 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:28 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:28 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:28 --> URI Class Initialized
INFO - 2024-12-29 01:56:28 --> Router Class Initialized
INFO - 2024-12-29 01:56:28 --> Output Class Initialized
INFO - 2024-12-29 01:56:28 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:28 --> Input Class Initialized
INFO - 2024-12-29 01:56:28 --> Language Class Initialized
ERROR - 2024-12-29 01:56:28 --> 404 Page Not Found: Berlinphp/index
INFO - 2024-12-29 01:56:29 --> Config Class Initialized
INFO - 2024-12-29 01:56:29 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:29 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:29 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:29 --> URI Class Initialized
INFO - 2024-12-29 01:56:29 --> Router Class Initialized
INFO - 2024-12-29 01:56:29 --> Output Class Initialized
INFO - 2024-12-29 01:56:29 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:29 --> Input Class Initialized
INFO - 2024-12-29 01:56:29 --> Language Class Initialized
ERROR - 2024-12-29 01:56:29 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-29 01:56:29 --> Config Class Initialized
INFO - 2024-12-29 01:56:29 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:29 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:29 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:29 --> URI Class Initialized
INFO - 2024-12-29 01:56:29 --> Router Class Initialized
INFO - 2024-12-29 01:56:29 --> Output Class Initialized
INFO - 2024-12-29 01:56:29 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:29 --> Input Class Initialized
INFO - 2024-12-29 01:56:29 --> Language Class Initialized
ERROR - 2024-12-29 01:56:29 --> 404 Page Not Found: Wp-includes/style-engine
INFO - 2024-12-29 01:56:30 --> Config Class Initialized
INFO - 2024-12-29 01:56:30 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:30 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:30 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:30 --> URI Class Initialized
INFO - 2024-12-29 01:56:30 --> Router Class Initialized
INFO - 2024-12-29 01:56:30 --> Output Class Initialized
INFO - 2024-12-29 01:56:30 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:30 --> Input Class Initialized
INFO - 2024-12-29 01:56:30 --> Language Class Initialized
ERROR - 2024-12-29 01:56:30 --> 404 Page Not Found: Wp-includes/rest-api
INFO - 2024-12-29 01:56:30 --> Config Class Initialized
INFO - 2024-12-29 01:56:30 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:30 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:30 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:30 --> URI Class Initialized
INFO - 2024-12-29 01:56:30 --> Router Class Initialized
INFO - 2024-12-29 01:56:30 --> Output Class Initialized
INFO - 2024-12-29 01:56:30 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:30 --> Input Class Initialized
INFO - 2024-12-29 01:56:30 --> Language Class Initialized
ERROR - 2024-12-29 01:56:30 --> 404 Page Not Found: Wp-includes/SimplePie
INFO - 2024-12-29 01:56:31 --> Config Class Initialized
INFO - 2024-12-29 01:56:31 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:31 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:31 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:31 --> URI Class Initialized
INFO - 2024-12-29 01:56:31 --> Router Class Initialized
INFO - 2024-12-29 01:56:31 --> Output Class Initialized
INFO - 2024-12-29 01:56:31 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:31 --> Input Class Initialized
INFO - 2024-12-29 01:56:31 --> Language Class Initialized
ERROR - 2024-12-29 01:56:31 --> 404 Page Not Found: Wp-content/banners
INFO - 2024-12-29 01:56:31 --> Config Class Initialized
INFO - 2024-12-29 01:56:31 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:31 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:31 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:31 --> URI Class Initialized
INFO - 2024-12-29 01:56:31 --> Router Class Initialized
INFO - 2024-12-29 01:56:31 --> Output Class Initialized
INFO - 2024-12-29 01:56:31 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:31 --> Input Class Initialized
INFO - 2024-12-29 01:56:31 --> Language Class Initialized
ERROR - 2024-12-29 01:56:31 --> 404 Page Not Found: Wp-content/about.php
INFO - 2024-12-29 01:56:32 --> Config Class Initialized
INFO - 2024-12-29 01:56:32 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:32 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:32 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:32 --> URI Class Initialized
INFO - 2024-12-29 01:56:32 --> Router Class Initialized
INFO - 2024-12-29 01:56:32 --> Output Class Initialized
INFO - 2024-12-29 01:56:32 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:32 --> Input Class Initialized
INFO - 2024-12-29 01:56:32 --> Language Class Initialized
ERROR - 2024-12-29 01:56:32 --> 404 Page Not Found: Well-known/about.php
INFO - 2024-12-29 01:56:32 --> Config Class Initialized
INFO - 2024-12-29 01:56:32 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:32 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:32 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:32 --> URI Class Initialized
INFO - 2024-12-29 01:56:32 --> Router Class Initialized
INFO - 2024-12-29 01:56:32 --> Output Class Initialized
INFO - 2024-12-29 01:56:32 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:32 --> Input Class Initialized
INFO - 2024-12-29 01:56:32 --> Language Class Initialized
ERROR - 2024-12-29 01:56:32 --> 404 Page Not Found: Wp-includes/Text
INFO - 2024-12-29 01:56:33 --> Config Class Initialized
INFO - 2024-12-29 01:56:33 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:33 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:33 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:33 --> URI Class Initialized
INFO - 2024-12-29 01:56:33 --> Router Class Initialized
INFO - 2024-12-29 01:56:33 --> Output Class Initialized
INFO - 2024-12-29 01:56:33 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:33 --> Input Class Initialized
INFO - 2024-12-29 01:56:33 --> Language Class Initialized
ERROR - 2024-12-29 01:56:33 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2024-12-29 01:56:33 --> Config Class Initialized
INFO - 2024-12-29 01:56:33 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:33 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:33 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:33 --> URI Class Initialized
INFO - 2024-12-29 01:56:33 --> Router Class Initialized
INFO - 2024-12-29 01:56:33 --> Output Class Initialized
INFO - 2024-12-29 01:56:33 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:33 --> Input Class Initialized
INFO - 2024-12-29 01:56:33 --> Language Class Initialized
ERROR - 2024-12-29 01:56:33 --> 404 Page Not Found: Img/about.php
INFO - 2024-12-29 01:56:34 --> Config Class Initialized
INFO - 2024-12-29 01:56:34 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:34 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:34 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:34 --> URI Class Initialized
INFO - 2024-12-29 01:56:34 --> Router Class Initialized
INFO - 2024-12-29 01:56:34 --> Output Class Initialized
INFO - 2024-12-29 01:56:34 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:34 --> Input Class Initialized
INFO - 2024-12-29 01:56:34 --> Language Class Initialized
ERROR - 2024-12-29 01:56:34 --> 404 Page Not Found: Wp-content/languages
INFO - 2024-12-29 01:56:34 --> Config Class Initialized
INFO - 2024-12-29 01:56:34 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:34 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:34 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:34 --> URI Class Initialized
INFO - 2024-12-29 01:56:34 --> Router Class Initialized
INFO - 2024-12-29 01:56:34 --> Output Class Initialized
INFO - 2024-12-29 01:56:34 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:34 --> Input Class Initialized
INFO - 2024-12-29 01:56:34 --> Language Class Initialized
ERROR - 2024-12-29 01:56:34 --> 404 Page Not Found: Wp-includes/customize
INFO - 2024-12-29 01:56:35 --> Config Class Initialized
INFO - 2024-12-29 01:56:35 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:35 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:35 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:35 --> URI Class Initialized
INFO - 2024-12-29 01:56:35 --> Router Class Initialized
INFO - 2024-12-29 01:56:35 --> Output Class Initialized
INFO - 2024-12-29 01:56:35 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:35 --> Input Class Initialized
INFO - 2024-12-29 01:56:35 --> Language Class Initialized
ERROR - 2024-12-29 01:56:35 --> 404 Page Not Found: Wp-includesbak/html-api
INFO - 2024-12-29 01:56:35 --> Config Class Initialized
INFO - 2024-12-29 01:56:35 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:35 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:35 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:35 --> URI Class Initialized
INFO - 2024-12-29 01:56:35 --> Router Class Initialized
INFO - 2024-12-29 01:56:35 --> Output Class Initialized
INFO - 2024-12-29 01:56:35 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:35 --> Input Class Initialized
INFO - 2024-12-29 01:56:35 --> Language Class Initialized
ERROR - 2024-12-29 01:56:35 --> 404 Page Not Found: Wp-includes/widgets
INFO - 2024-12-29 01:56:36 --> Config Class Initialized
INFO - 2024-12-29 01:56:36 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:36 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:36 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:36 --> URI Class Initialized
INFO - 2024-12-29 01:56:36 --> Router Class Initialized
INFO - 2024-12-29 01:56:36 --> Output Class Initialized
INFO - 2024-12-29 01:56:36 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:36 --> Input Class Initialized
INFO - 2024-12-29 01:56:36 --> Language Class Initialized
ERROR - 2024-12-29 01:56:36 --> 404 Page Not Found: Wp-includes/IXR
INFO - 2024-12-29 01:56:36 --> Config Class Initialized
INFO - 2024-12-29 01:56:36 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:36 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:36 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:36 --> URI Class Initialized
INFO - 2024-12-29 01:56:36 --> Router Class Initialized
INFO - 2024-12-29 01:56:36 --> Output Class Initialized
INFO - 2024-12-29 01:56:36 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:36 --> Input Class Initialized
INFO - 2024-12-29 01:56:36 --> Language Class Initialized
ERROR - 2024-12-29 01:56:36 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:56:37 --> Config Class Initialized
INFO - 2024-12-29 01:56:37 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:37 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:37 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:37 --> URI Class Initialized
INFO - 2024-12-29 01:56:37 --> Router Class Initialized
INFO - 2024-12-29 01:56:37 --> Output Class Initialized
INFO - 2024-12-29 01:56:37 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:37 --> Input Class Initialized
INFO - 2024-12-29 01:56:37 --> Language Class Initialized
ERROR - 2024-12-29 01:56:37 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-29 01:56:37 --> Config Class Initialized
INFO - 2024-12-29 01:56:37 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:37 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:37 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:37 --> URI Class Initialized
INFO - 2024-12-29 01:56:37 --> Router Class Initialized
INFO - 2024-12-29 01:56:37 --> Output Class Initialized
INFO - 2024-12-29 01:56:37 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:37 --> Input Class Initialized
INFO - 2024-12-29 01:56:37 --> Language Class Initialized
ERROR - 2024-12-29 01:56:37 --> 404 Page Not Found: Wp-includes/pomo
INFO - 2024-12-29 01:56:38 --> Config Class Initialized
INFO - 2024-12-29 01:56:38 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:38 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:38 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:38 --> URI Class Initialized
INFO - 2024-12-29 01:56:38 --> Router Class Initialized
INFO - 2024-12-29 01:56:38 --> Output Class Initialized
INFO - 2024-12-29 01:56:38 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:38 --> Input Class Initialized
INFO - 2024-12-29 01:56:38 --> Language Class Initialized
ERROR - 2024-12-29 01:56:38 --> 404 Page Not Found: Wp-includes/block-patterns
INFO - 2024-12-29 01:56:38 --> Config Class Initialized
INFO - 2024-12-29 01:56:38 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:38 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:38 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:38 --> URI Class Initialized
INFO - 2024-12-29 01:56:38 --> Router Class Initialized
INFO - 2024-12-29 01:56:38 --> Output Class Initialized
INFO - 2024-12-29 01:56:38 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:38 --> Input Class Initialized
INFO - 2024-12-29 01:56:38 --> Language Class Initialized
ERROR - 2024-12-29 01:56:38 --> 404 Page Not Found: Wp-content/updraft
INFO - 2024-12-29 01:56:39 --> Config Class Initialized
INFO - 2024-12-29 01:56:39 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:39 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:39 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:39 --> URI Class Initialized
INFO - 2024-12-29 01:56:39 --> Router Class Initialized
INFO - 2024-12-29 01:56:39 --> Output Class Initialized
INFO - 2024-12-29 01:56:39 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:39 --> Input Class Initialized
INFO - 2024-12-29 01:56:39 --> Language Class Initialized
ERROR - 2024-12-29 01:56:39 --> 404 Page Not Found: Wp-content/upgrade-temp-backup
INFO - 2024-12-29 01:56:39 --> Config Class Initialized
INFO - 2024-12-29 01:56:39 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:39 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:39 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:39 --> URI Class Initialized
INFO - 2024-12-29 01:56:39 --> Router Class Initialized
INFO - 2024-12-29 01:56:39 --> Output Class Initialized
INFO - 2024-12-29 01:56:39 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:39 --> Input Class Initialized
INFO - 2024-12-29 01:56:39 --> Language Class Initialized
ERROR - 2024-12-29 01:56:39 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:56:40 --> Config Class Initialized
INFO - 2024-12-29 01:56:40 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:40 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:40 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:40 --> URI Class Initialized
INFO - 2024-12-29 01:56:40 --> Router Class Initialized
INFO - 2024-12-29 01:56:40 --> Output Class Initialized
INFO - 2024-12-29 01:56:40 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:40 --> Input Class Initialized
INFO - 2024-12-29 01:56:40 --> Language Class Initialized
ERROR - 2024-12-29 01:56:40 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-29 01:56:40 --> Config Class Initialized
INFO - 2024-12-29 01:56:40 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:40 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:40 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:40 --> URI Class Initialized
INFO - 2024-12-29 01:56:40 --> Router Class Initialized
INFO - 2024-12-29 01:56:40 --> Output Class Initialized
INFO - 2024-12-29 01:56:40 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:40 --> Input Class Initialized
INFO - 2024-12-29 01:56:40 --> Language Class Initialized
ERROR - 2024-12-29 01:56:40 --> 404 Page Not Found: Images/about.php
INFO - 2024-12-29 01:56:41 --> Config Class Initialized
INFO - 2024-12-29 01:56:41 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:41 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:41 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:41 --> URI Class Initialized
INFO - 2024-12-29 01:56:41 --> Router Class Initialized
INFO - 2024-12-29 01:56:41 --> Output Class Initialized
INFO - 2024-12-29 01:56:41 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:41 --> Input Class Initialized
INFO - 2024-12-29 01:56:41 --> Language Class Initialized
ERROR - 2024-12-29 01:56:41 --> 404 Page Not Found: Wp-content/blogs.dir
INFO - 2024-12-29 01:56:41 --> Config Class Initialized
INFO - 2024-12-29 01:56:41 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:41 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:41 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:41 --> URI Class Initialized
INFO - 2024-12-29 01:56:41 --> Router Class Initialized
INFO - 2024-12-29 01:56:41 --> Output Class Initialized
INFO - 2024-12-29 01:56:41 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:41 --> Input Class Initialized
INFO - 2024-12-29 01:56:41 --> Language Class Initialized
ERROR - 2024-12-29 01:56:41 --> 404 Page Not Found: Wp-includes/images
INFO - 2024-12-29 01:56:42 --> Config Class Initialized
INFO - 2024-12-29 01:56:42 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:42 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:42 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:42 --> URI Class Initialized
INFO - 2024-12-29 01:56:42 --> Router Class Initialized
INFO - 2024-12-29 01:56:42 --> Output Class Initialized
INFO - 2024-12-29 01:56:42 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:42 --> Input Class Initialized
INFO - 2024-12-29 01:56:42 --> Language Class Initialized
ERROR - 2024-12-29 01:56:42 --> 404 Page Not Found: Wp-includes/about.php
INFO - 2024-12-29 01:56:42 --> Config Class Initialized
INFO - 2024-12-29 01:56:42 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:42 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:42 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:42 --> URI Class Initialized
INFO - 2024-12-29 01:56:42 --> Router Class Initialized
INFO - 2024-12-29 01:56:42 --> Output Class Initialized
INFO - 2024-12-29 01:56:42 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:42 --> Input Class Initialized
INFO - 2024-12-29 01:56:42 --> Language Class Initialized
ERROR - 2024-12-29 01:56:42 --> 404 Page Not Found: Cgi-bin/about.php
INFO - 2024-12-29 01:56:43 --> Config Class Initialized
INFO - 2024-12-29 01:56:43 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:43 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:43 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:43 --> URI Class Initialized
INFO - 2024-12-29 01:56:43 --> Router Class Initialized
INFO - 2024-12-29 01:56:43 --> Output Class Initialized
INFO - 2024-12-29 01:56:43 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:43 --> Input Class Initialized
INFO - 2024-12-29 01:56:43 --> Language Class Initialized
ERROR - 2024-12-29 01:56:43 --> 404 Page Not Found: Wp-content/gallery
INFO - 2024-12-29 01:56:43 --> Config Class Initialized
INFO - 2024-12-29 01:56:43 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:43 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:43 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:43 --> URI Class Initialized
INFO - 2024-12-29 01:56:43 --> Router Class Initialized
INFO - 2024-12-29 01:56:43 --> Output Class Initialized
INFO - 2024-12-29 01:56:43 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:43 --> Input Class Initialized
INFO - 2024-12-29 01:56:43 --> Language Class Initialized
ERROR - 2024-12-29 01:56:43 --> 404 Page Not Found: Wp-includes/blocks
INFO - 2024-12-29 01:56:44 --> Config Class Initialized
INFO - 2024-12-29 01:56:44 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:44 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:44 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:44 --> URI Class Initialized
INFO - 2024-12-29 01:56:44 --> Router Class Initialized
INFO - 2024-12-29 01:56:44 --> Output Class Initialized
INFO - 2024-12-29 01:56:44 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:44 --> Input Class Initialized
INFO - 2024-12-29 01:56:44 --> Language Class Initialized
ERROR - 2024-12-29 01:56:44 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:56:44 --> Config Class Initialized
INFO - 2024-12-29 01:56:44 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:44 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:44 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:44 --> URI Class Initialized
INFO - 2024-12-29 01:56:44 --> Router Class Initialized
INFO - 2024-12-29 01:56:44 --> Output Class Initialized
INFO - 2024-12-29 01:56:44 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:44 --> Input Class Initialized
INFO - 2024-12-29 01:56:44 --> Language Class Initialized
ERROR - 2024-12-29 01:56:44 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:56:45 --> Config Class Initialized
INFO - 2024-12-29 01:56:45 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:45 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:45 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:45 --> URI Class Initialized
INFO - 2024-12-29 01:56:45 --> Router Class Initialized
INFO - 2024-12-29 01:56:45 --> Output Class Initialized
INFO - 2024-12-29 01:56:45 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:45 --> Input Class Initialized
INFO - 2024-12-29 01:56:45 --> Language Class Initialized
ERROR - 2024-12-29 01:56:45 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-29 01:56:46 --> Config Class Initialized
INFO - 2024-12-29 01:56:46 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:46 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:46 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:46 --> URI Class Initialized
INFO - 2024-12-29 01:56:46 --> Router Class Initialized
INFO - 2024-12-29 01:56:46 --> Output Class Initialized
INFO - 2024-12-29 01:56:46 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:46 --> Input Class Initialized
INFO - 2024-12-29 01:56:46 --> Language Class Initialized
ERROR - 2024-12-29 01:56:46 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-29 01:56:47 --> Config Class Initialized
INFO - 2024-12-29 01:56:47 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:47 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:47 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:47 --> URI Class Initialized
INFO - 2024-12-29 01:56:47 --> Router Class Initialized
INFO - 2024-12-29 01:56:47 --> Output Class Initialized
INFO - 2024-12-29 01:56:47 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:47 --> Input Class Initialized
INFO - 2024-12-29 01:56:47 --> Language Class Initialized
ERROR - 2024-12-29 01:56:47 --> 404 Page Not Found: Cloudphp/index
INFO - 2024-12-29 01:56:47 --> Config Class Initialized
INFO - 2024-12-29 01:56:47 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:47 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:47 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:47 --> URI Class Initialized
INFO - 2024-12-29 01:56:47 --> Router Class Initialized
INFO - 2024-12-29 01:56:47 --> Output Class Initialized
INFO - 2024-12-29 01:56:47 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:47 --> Input Class Initialized
INFO - 2024-12-29 01:56:47 --> Language Class Initialized
ERROR - 2024-12-29 01:56:47 --> 404 Page Not Found: Cgi-bin/cloud.php
INFO - 2024-12-29 01:56:48 --> Config Class Initialized
INFO - 2024-12-29 01:56:48 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:48 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:48 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:48 --> URI Class Initialized
INFO - 2024-12-29 01:56:48 --> Router Class Initialized
INFO - 2024-12-29 01:56:48 --> Output Class Initialized
INFO - 2024-12-29 01:56:48 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:48 --> Input Class Initialized
INFO - 2024-12-29 01:56:48 --> Language Class Initialized
ERROR - 2024-12-29 01:56:48 --> 404 Page Not Found: Wp-content/updates.php
INFO - 2024-12-29 01:56:48 --> Config Class Initialized
INFO - 2024-12-29 01:56:48 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:48 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:48 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:48 --> URI Class Initialized
INFO - 2024-12-29 01:56:48 --> Router Class Initialized
INFO - 2024-12-29 01:56:48 --> Output Class Initialized
INFO - 2024-12-29 01:56:48 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:48 --> Input Class Initialized
INFO - 2024-12-29 01:56:48 --> Language Class Initialized
ERROR - 2024-12-29 01:56:48 --> 404 Page Not Found: Css/cloud.php
INFO - 2024-12-29 01:56:49 --> Config Class Initialized
INFO - 2024-12-29 01:56:49 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:49 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:49 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:49 --> URI Class Initialized
INFO - 2024-12-29 01:56:49 --> Router Class Initialized
INFO - 2024-12-29 01:56:49 --> Output Class Initialized
INFO - 2024-12-29 01:56:49 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:49 --> Input Class Initialized
INFO - 2024-12-29 01:56:49 --> Language Class Initialized
ERROR - 2024-12-29 01:56:49 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-29 01:56:49 --> Config Class Initialized
INFO - 2024-12-29 01:56:49 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:49 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:49 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:49 --> URI Class Initialized
INFO - 2024-12-29 01:56:49 --> Router Class Initialized
INFO - 2024-12-29 01:56:49 --> Output Class Initialized
INFO - 2024-12-29 01:56:49 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:49 --> Input Class Initialized
INFO - 2024-12-29 01:56:49 --> Language Class Initialized
ERROR - 2024-12-29 01:56:49 --> 404 Page Not Found: Img/cloud.php
INFO - 2024-12-29 01:56:50 --> Config Class Initialized
INFO - 2024-12-29 01:56:50 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:50 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:50 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:50 --> URI Class Initialized
INFO - 2024-12-29 01:56:50 --> Router Class Initialized
INFO - 2024-12-29 01:56:50 --> Output Class Initialized
INFO - 2024-12-29 01:56:50 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:50 --> Input Class Initialized
INFO - 2024-12-29 01:56:50 --> Language Class Initialized
ERROR - 2024-12-29 01:56:50 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:56:50 --> Config Class Initialized
INFO - 2024-12-29 01:56:50 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:50 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:50 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:50 --> URI Class Initialized
INFO - 2024-12-29 01:56:50 --> Router Class Initialized
INFO - 2024-12-29 01:56:50 --> Output Class Initialized
INFO - 2024-12-29 01:56:50 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:50 --> Input Class Initialized
INFO - 2024-12-29 01:56:50 --> Language Class Initialized
ERROR - 2024-12-29 01:56:50 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:56:51 --> Config Class Initialized
INFO - 2024-12-29 01:56:51 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:51 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:51 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:51 --> URI Class Initialized
INFO - 2024-12-29 01:56:51 --> Router Class Initialized
INFO - 2024-12-29 01:56:51 --> Output Class Initialized
INFO - 2024-12-29 01:56:51 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:51 --> Input Class Initialized
INFO - 2024-12-29 01:56:51 --> Language Class Initialized
ERROR - 2024-12-29 01:56:51 --> 404 Page Not Found: Avaaphp/index
INFO - 2024-12-29 01:56:51 --> Config Class Initialized
INFO - 2024-12-29 01:56:51 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:51 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:51 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:51 --> URI Class Initialized
INFO - 2024-12-29 01:56:51 --> Router Class Initialized
INFO - 2024-12-29 01:56:51 --> Output Class Initialized
INFO - 2024-12-29 01:56:51 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:51 --> Input Class Initialized
INFO - 2024-12-29 01:56:51 --> Language Class Initialized
ERROR - 2024-12-29 01:56:51 --> 404 Page Not Found: Images/cloud.php
INFO - 2024-12-29 01:56:52 --> Config Class Initialized
INFO - 2024-12-29 01:56:52 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:52 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:52 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:52 --> URI Class Initialized
INFO - 2024-12-29 01:56:52 --> Router Class Initialized
INFO - 2024-12-29 01:56:52 --> Output Class Initialized
INFO - 2024-12-29 01:56:52 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:52 --> Input Class Initialized
INFO - 2024-12-29 01:56:52 --> Language Class Initialized
ERROR - 2024-12-29 01:56:52 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:56:52 --> Config Class Initialized
INFO - 2024-12-29 01:56:52 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:52 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:52 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:52 --> URI Class Initialized
INFO - 2024-12-29 01:56:52 --> Router Class Initialized
INFO - 2024-12-29 01:56:52 --> Output Class Initialized
INFO - 2024-12-29 01:56:52 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:52 --> Input Class Initialized
INFO - 2024-12-29 01:56:52 --> Language Class Initialized
ERROR - 2024-12-29 01:56:52 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-29 01:56:53 --> Config Class Initialized
INFO - 2024-12-29 01:56:53 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:53 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:53 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:53 --> URI Class Initialized
INFO - 2024-12-29 01:56:53 --> Router Class Initialized
INFO - 2024-12-29 01:56:53 --> Output Class Initialized
INFO - 2024-12-29 01:56:53 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:53 --> Input Class Initialized
INFO - 2024-12-29 01:56:53 --> Language Class Initialized
ERROR - 2024-12-29 01:56:53 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:56:53 --> Config Class Initialized
INFO - 2024-12-29 01:56:53 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:53 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:53 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:53 --> URI Class Initialized
INFO - 2024-12-29 01:56:53 --> Router Class Initialized
INFO - 2024-12-29 01:56:53 --> Output Class Initialized
INFO - 2024-12-29 01:56:53 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:53 --> Input Class Initialized
INFO - 2024-12-29 01:56:53 --> Language Class Initialized
ERROR - 2024-12-29 01:56:53 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-29 01:56:54 --> Config Class Initialized
INFO - 2024-12-29 01:56:54 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:54 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:54 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:54 --> URI Class Initialized
INFO - 2024-12-29 01:56:54 --> Router Class Initialized
INFO - 2024-12-29 01:56:54 --> Output Class Initialized
INFO - 2024-12-29 01:56:54 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:54 --> Input Class Initialized
INFO - 2024-12-29 01:56:54 --> Language Class Initialized
ERROR - 2024-12-29 01:56:54 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:56:54 --> Config Class Initialized
INFO - 2024-12-29 01:56:54 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:54 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:54 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:54 --> URI Class Initialized
INFO - 2024-12-29 01:56:54 --> Router Class Initialized
INFO - 2024-12-29 01:56:54 --> Output Class Initialized
INFO - 2024-12-29 01:56:54 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:54 --> Input Class Initialized
INFO - 2024-12-29 01:56:54 --> Language Class Initialized
ERROR - 2024-12-29 01:56:54 --> 404 Page Not Found: Wp-admin/cloud.php
INFO - 2024-12-29 01:56:55 --> Config Class Initialized
INFO - 2024-12-29 01:56:55 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:55 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:55 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:55 --> URI Class Initialized
INFO - 2024-12-29 01:56:55 --> Router Class Initialized
INFO - 2024-12-29 01:56:55 --> Output Class Initialized
INFO - 2024-12-29 01:56:55 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:55 --> Input Class Initialized
INFO - 2024-12-29 01:56:55 --> Language Class Initialized
ERROR - 2024-12-29 01:56:55 --> 404 Page Not Found: Updatesphp/index
INFO - 2024-12-29 01:56:55 --> Config Class Initialized
INFO - 2024-12-29 01:56:55 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:55 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:55 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:55 --> URI Class Initialized
INFO - 2024-12-29 01:56:55 --> Router Class Initialized
INFO - 2024-12-29 01:56:55 --> Output Class Initialized
INFO - 2024-12-29 01:56:55 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:55 --> Input Class Initialized
INFO - 2024-12-29 01:56:55 --> Language Class Initialized
ERROR - 2024-12-29 01:56:55 --> 404 Page Not Found: Libraries/legacy
INFO - 2024-12-29 01:56:56 --> Config Class Initialized
INFO - 2024-12-29 01:56:56 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:56 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:56 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:56 --> URI Class Initialized
INFO - 2024-12-29 01:56:56 --> Router Class Initialized
INFO - 2024-12-29 01:56:56 --> Output Class Initialized
INFO - 2024-12-29 01:56:56 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:56 --> Input Class Initialized
INFO - 2024-12-29 01:56:56 --> Language Class Initialized
ERROR - 2024-12-29 01:56:56 --> 404 Page Not Found: Libraries/phpmailer
INFO - 2024-12-29 01:56:56 --> Config Class Initialized
INFO - 2024-12-29 01:56:56 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:56 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:56 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:56 --> URI Class Initialized
INFO - 2024-12-29 01:56:56 --> Router Class Initialized
INFO - 2024-12-29 01:56:56 --> Output Class Initialized
INFO - 2024-12-29 01:56:56 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:56 --> Input Class Initialized
INFO - 2024-12-29 01:56:56 --> Language Class Initialized
ERROR - 2024-12-29 01:56:56 --> 404 Page Not Found: Libraries/vendor
INFO - 2024-12-29 01:56:57 --> Config Class Initialized
INFO - 2024-12-29 01:56:57 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:57 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:57 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:57 --> URI Class Initialized
INFO - 2024-12-29 01:56:57 --> Router Class Initialized
INFO - 2024-12-29 01:56:57 --> Output Class Initialized
INFO - 2024-12-29 01:56:57 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:57 --> Input Class Initialized
INFO - 2024-12-29 01:56:57 --> Language Class Initialized
ERROR - 2024-12-29 01:56:57 --> 404 Page Not Found: Alfa-rexphp7/index
INFO - 2024-12-29 01:56:57 --> Config Class Initialized
INFO - 2024-12-29 01:56:57 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:57 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:57 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:57 --> URI Class Initialized
INFO - 2024-12-29 01:56:57 --> Router Class Initialized
INFO - 2024-12-29 01:56:57 --> Output Class Initialized
INFO - 2024-12-29 01:56:57 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:57 --> Input Class Initialized
INFO - 2024-12-29 01:56:57 --> Language Class Initialized
ERROR - 2024-12-29 01:56:57 --> 404 Page Not Found: Alfanewphp/index
INFO - 2024-12-29 01:56:58 --> Config Class Initialized
INFO - 2024-12-29 01:56:58 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:58 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:58 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:58 --> URI Class Initialized
INFO - 2024-12-29 01:56:58 --> Router Class Initialized
INFO - 2024-12-29 01:56:58 --> Output Class Initialized
INFO - 2024-12-29 01:56:58 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:58 --> Input Class Initialized
INFO - 2024-12-29 01:56:58 --> Language Class Initialized
ERROR - 2024-12-29 01:56:58 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:56:58 --> Config Class Initialized
INFO - 2024-12-29 01:56:58 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:58 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:58 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:58 --> URI Class Initialized
INFO - 2024-12-29 01:56:58 --> Router Class Initialized
INFO - 2024-12-29 01:56:58 --> Output Class Initialized
INFO - 2024-12-29 01:56:58 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:58 --> Input Class Initialized
INFO - 2024-12-29 01:56:58 --> Language Class Initialized
ERROR - 2024-12-29 01:56:59 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:56:59 --> Config Class Initialized
INFO - 2024-12-29 01:56:59 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:56:59 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:56:59 --> Utf8 Class Initialized
INFO - 2024-12-29 01:56:59 --> URI Class Initialized
INFO - 2024-12-29 01:56:59 --> Router Class Initialized
INFO - 2024-12-29 01:56:59 --> Output Class Initialized
INFO - 2024-12-29 01:56:59 --> Security Class Initialized
DEBUG - 2024-12-29 01:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:56:59 --> Input Class Initialized
INFO - 2024-12-29 01:56:59 --> Language Class Initialized
ERROR - 2024-12-29 01:56:59 --> 404 Page Not Found: Wp-pphp7/index
INFO - 2024-12-29 01:56:59 --> Config Class Initialized
INFO - 2024-12-29 01:56:59 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:00 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:00 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:00 --> URI Class Initialized
INFO - 2024-12-29 01:57:00 --> Router Class Initialized
INFO - 2024-12-29 01:57:00 --> Output Class Initialized
INFO - 2024-12-29 01:57:00 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:00 --> Input Class Initialized
INFO - 2024-12-29 01:57:00 --> Language Class Initialized
ERROR - 2024-12-29 01:57:00 --> 404 Page Not Found: Wp-admin/repeater.php
INFO - 2024-12-29 01:57:00 --> Config Class Initialized
INFO - 2024-12-29 01:57:00 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:00 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:00 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:00 --> URI Class Initialized
INFO - 2024-12-29 01:57:00 --> Router Class Initialized
INFO - 2024-12-29 01:57:00 --> Output Class Initialized
INFO - 2024-12-29 01:57:00 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:00 --> Input Class Initialized
INFO - 2024-12-29 01:57:00 --> Language Class Initialized
ERROR - 2024-12-29 01:57:00 --> 404 Page Not Found: Wp-includes/repeater.php
INFO - 2024-12-29 01:57:01 --> Config Class Initialized
INFO - 2024-12-29 01:57:01 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:01 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:01 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:01 --> URI Class Initialized
INFO - 2024-12-29 01:57:01 --> Router Class Initialized
INFO - 2024-12-29 01:57:01 --> Output Class Initialized
INFO - 2024-12-29 01:57:01 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:01 --> Input Class Initialized
INFO - 2024-12-29 01:57:01 --> Language Class Initialized
ERROR - 2024-12-29 01:57:01 --> 404 Page Not Found: Wp-content/repeater.php
INFO - 2024-12-29 01:57:01 --> Config Class Initialized
INFO - 2024-12-29 01:57:01 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:01 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:01 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:01 --> URI Class Initialized
INFO - 2024-12-29 01:57:01 --> Router Class Initialized
INFO - 2024-12-29 01:57:01 --> Output Class Initialized
INFO - 2024-12-29 01:57:01 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:01 --> Input Class Initialized
INFO - 2024-12-29 01:57:01 --> Language Class Initialized
ERROR - 2024-12-29 01:57:01 --> 404 Page Not Found: Wsoyanzphp/index
INFO - 2024-12-29 01:57:02 --> Config Class Initialized
INFO - 2024-12-29 01:57:02 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:02 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:02 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:02 --> URI Class Initialized
INFO - 2024-12-29 01:57:02 --> Router Class Initialized
INFO - 2024-12-29 01:57:02 --> Output Class Initialized
INFO - 2024-12-29 01:57:02 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:02 --> Input Class Initialized
INFO - 2024-12-29 01:57:02 --> Language Class Initialized
ERROR - 2024-12-29 01:57:02 --> 404 Page Not Found: Yanzphp/index
INFO - 2024-12-29 01:57:02 --> Config Class Initialized
INFO - 2024-12-29 01:57:02 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:02 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:02 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:02 --> URI Class Initialized
INFO - 2024-12-29 01:57:02 --> Router Class Initialized
INFO - 2024-12-29 01:57:02 --> Output Class Initialized
INFO - 2024-12-29 01:57:02 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:02 --> Input Class Initialized
INFO - 2024-12-29 01:57:02 --> Language Class Initialized
ERROR - 2024-12-29 01:57:02 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:57:03 --> Config Class Initialized
INFO - 2024-12-29 01:57:03 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:03 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:03 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:03 --> URI Class Initialized
INFO - 2024-12-29 01:57:03 --> Router Class Initialized
INFO - 2024-12-29 01:57:03 --> Output Class Initialized
INFO - 2024-12-29 01:57:03 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:03 --> Input Class Initialized
INFO - 2024-12-29 01:57:03 --> Language Class Initialized
ERROR - 2024-12-29 01:57:03 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:03 --> Config Class Initialized
INFO - 2024-12-29 01:57:03 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:03 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:03 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:03 --> URI Class Initialized
INFO - 2024-12-29 01:57:03 --> Router Class Initialized
INFO - 2024-12-29 01:57:03 --> Output Class Initialized
INFO - 2024-12-29 01:57:03 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:03 --> Input Class Initialized
INFO - 2024-12-29 01:57:03 --> Language Class Initialized
ERROR - 2024-12-29 01:57:03 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:04 --> Config Class Initialized
INFO - 2024-12-29 01:57:04 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:04 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:04 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:04 --> URI Class Initialized
INFO - 2024-12-29 01:57:04 --> Router Class Initialized
INFO - 2024-12-29 01:57:04 --> Output Class Initialized
INFO - 2024-12-29 01:57:04 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:04 --> Input Class Initialized
INFO - 2024-12-29 01:57:04 --> Language Class Initialized
ERROR - 2024-12-29 01:57:04 --> 404 Page Not Found: Cache-compatphp/index
INFO - 2024-12-29 01:57:04 --> Config Class Initialized
INFO - 2024-12-29 01:57:04 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:04 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:04 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:04 --> URI Class Initialized
INFO - 2024-12-29 01:57:04 --> Router Class Initialized
INFO - 2024-12-29 01:57:04 --> Output Class Initialized
INFO - 2024-12-29 01:57:04 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:04 --> Input Class Initialized
INFO - 2024-12-29 01:57:04 --> Language Class Initialized
ERROR - 2024-12-29 01:57:04 --> 404 Page Not Found: Ajax-actionsphp/index
INFO - 2024-12-29 01:57:05 --> Config Class Initialized
INFO - 2024-12-29 01:57:05 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:05 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:05 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:05 --> URI Class Initialized
INFO - 2024-12-29 01:57:05 --> Router Class Initialized
INFO - 2024-12-29 01:57:05 --> Output Class Initialized
INFO - 2024-12-29 01:57:05 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:05 --> Input Class Initialized
INFO - 2024-12-29 01:57:05 --> Language Class Initialized
ERROR - 2024-12-29 01:57:05 --> 404 Page Not Found: Wp-admin/ajax-actions.php
INFO - 2024-12-29 01:57:05 --> Config Class Initialized
INFO - 2024-12-29 01:57:05 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:05 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:05 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:05 --> URI Class Initialized
INFO - 2024-12-29 01:57:05 --> Router Class Initialized
INFO - 2024-12-29 01:57:05 --> Output Class Initialized
INFO - 2024-12-29 01:57:05 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:05 --> Input Class Initialized
INFO - 2024-12-29 01:57:05 --> Language Class Initialized
ERROR - 2024-12-29 01:57:05 --> 404 Page Not Found: Wp-consarphp/index
INFO - 2024-12-29 01:57:06 --> Config Class Initialized
INFO - 2024-12-29 01:57:06 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:06 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:06 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:06 --> URI Class Initialized
INFO - 2024-12-29 01:57:06 --> Router Class Initialized
INFO - 2024-12-29 01:57:06 --> Output Class Initialized
INFO - 2024-12-29 01:57:06 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:06 --> Input Class Initialized
INFO - 2024-12-29 01:57:06 --> Language Class Initialized
ERROR - 2024-12-29 01:57:06 --> 404 Page Not Found: Repeaterphp/index
INFO - 2024-12-29 01:57:06 --> Config Class Initialized
INFO - 2024-12-29 01:57:06 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:06 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:06 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:06 --> URI Class Initialized
INFO - 2024-12-29 01:57:06 --> Router Class Initialized
INFO - 2024-12-29 01:57:06 --> Output Class Initialized
INFO - 2024-12-29 01:57:06 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:06 --> Input Class Initialized
INFO - 2024-12-29 01:57:06 --> Language Class Initialized
ERROR - 2024-12-29 01:57:06 --> 404 Page Not Found: Admin-postphp/index
INFO - 2024-12-29 01:57:07 --> Config Class Initialized
INFO - 2024-12-29 01:57:07 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:07 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:07 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:07 --> URI Class Initialized
INFO - 2024-12-29 01:57:07 --> Router Class Initialized
INFO - 2024-12-29 01:57:07 --> Output Class Initialized
INFO - 2024-12-29 01:57:07 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:07 --> Input Class Initialized
INFO - 2024-12-29 01:57:07 --> Language Class Initialized
ERROR - 2024-12-29 01:57:07 --> 404 Page Not Found: Wp-admin/maint
INFO - 2024-12-29 01:57:07 --> Config Class Initialized
INFO - 2024-12-29 01:57:07 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:07 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:07 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:07 --> URI Class Initialized
INFO - 2024-12-29 01:57:07 --> Router Class Initialized
INFO - 2024-12-29 01:57:07 --> Output Class Initialized
INFO - 2024-12-29 01:57:07 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:07 --> Input Class Initialized
INFO - 2024-12-29 01:57:07 --> Language Class Initialized
ERROR - 2024-12-29 01:57:07 --> 404 Page Not Found: Wp-admin/dropdown.php
INFO - 2024-12-29 01:57:08 --> Config Class Initialized
INFO - 2024-12-29 01:57:08 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:08 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:08 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:08 --> URI Class Initialized
INFO - 2024-12-29 01:57:08 --> Router Class Initialized
INFO - 2024-12-29 01:57:08 --> Output Class Initialized
INFO - 2024-12-29 01:57:08 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:08 --> Input Class Initialized
INFO - 2024-12-29 01:57:08 --> Language Class Initialized
ERROR - 2024-12-29 01:57:08 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:08 --> Config Class Initialized
INFO - 2024-12-29 01:57:08 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:08 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:08 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:08 --> URI Class Initialized
INFO - 2024-12-29 01:57:08 --> Router Class Initialized
INFO - 2024-12-29 01:57:08 --> Output Class Initialized
INFO - 2024-12-29 01:57:08 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:08 --> Input Class Initialized
INFO - 2024-12-29 01:57:08 --> Language Class Initialized
ERROR - 2024-12-29 01:57:08 --> 404 Page Not Found: Dropdownphp/index
INFO - 2024-12-29 01:57:09 --> Config Class Initialized
INFO - 2024-12-29 01:57:09 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:09 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:09 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:09 --> URI Class Initialized
INFO - 2024-12-29 01:57:09 --> Router Class Initialized
INFO - 2024-12-29 01:57:09 --> Output Class Initialized
INFO - 2024-12-29 01:57:09 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:09 --> Input Class Initialized
INFO - 2024-12-29 01:57:09 --> Language Class Initialized
ERROR - 2024-12-29 01:57:09 --> 404 Page Not Found: Aboutphp/index
INFO - 2024-12-29 01:57:09 --> Config Class Initialized
INFO - 2024-12-29 01:57:09 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:09 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:09 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:09 --> URI Class Initialized
INFO - 2024-12-29 01:57:09 --> Router Class Initialized
INFO - 2024-12-29 01:57:09 --> Output Class Initialized
INFO - 2024-12-29 01:57:09 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:09 --> Input Class Initialized
INFO - 2024-12-29 01:57:09 --> Language Class Initialized
ERROR - 2024-12-29 01:57:09 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-29 01:57:10 --> Config Class Initialized
INFO - 2024-12-29 01:57:10 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:10 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:10 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:10 --> URI Class Initialized
INFO - 2024-12-29 01:57:10 --> Router Class Initialized
INFO - 2024-12-29 01:57:10 --> Output Class Initialized
INFO - 2024-12-29 01:57:10 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:10 --> Input Class Initialized
INFO - 2024-12-29 01:57:10 --> Language Class Initialized
ERROR - 2024-12-29 01:57:10 --> 404 Page Not Found: Aboutphp7/index
INFO - 2024-12-29 01:57:10 --> Config Class Initialized
INFO - 2024-12-29 01:57:10 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:10 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:10 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:10 --> URI Class Initialized
INFO - 2024-12-29 01:57:10 --> Router Class Initialized
INFO - 2024-12-29 01:57:10 --> Output Class Initialized
INFO - 2024-12-29 01:57:10 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:10 --> Input Class Initialized
INFO - 2024-12-29 01:57:10 --> Language Class Initialized
ERROR - 2024-12-29 01:57:10 --> 404 Page Not Found: Alfanewphp7/index
INFO - 2024-12-29 01:57:11 --> Config Class Initialized
INFO - 2024-12-29 01:57:11 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:11 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:11 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:11 --> URI Class Initialized
INFO - 2024-12-29 01:57:11 --> Router Class Initialized
INFO - 2024-12-29 01:57:11 --> Output Class Initialized
INFO - 2024-12-29 01:57:11 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:11 --> Input Class Initialized
INFO - 2024-12-29 01:57:11 --> Language Class Initialized
ERROR - 2024-12-29 01:57:11 --> 404 Page Not Found: Adminfunsphp7/index
INFO - 2024-12-29 01:57:11 --> Config Class Initialized
INFO - 2024-12-29 01:57:11 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:11 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:11 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:11 --> URI Class Initialized
INFO - 2024-12-29 01:57:11 --> Router Class Initialized
INFO - 2024-12-29 01:57:11 --> Output Class Initialized
INFO - 2024-12-29 01:57:11 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:11 --> Input Class Initialized
INFO - 2024-12-29 01:57:11 --> Language Class Initialized
ERROR - 2024-12-29 01:57:11 --> 404 Page Not Found: Ebsphp7/index
INFO - 2024-12-29 01:57:12 --> Config Class Initialized
INFO - 2024-12-29 01:57:12 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:12 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:12 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:12 --> URI Class Initialized
INFO - 2024-12-29 01:57:12 --> Router Class Initialized
INFO - 2024-12-29 01:57:12 --> Output Class Initialized
INFO - 2024-12-29 01:57:12 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:12 --> Input Class Initialized
INFO - 2024-12-29 01:57:12 --> Language Class Initialized
ERROR - 2024-12-29 01:57:12 --> 404 Page Not Found: Wsphp7/index
INFO - 2024-12-29 01:57:12 --> Config Class Initialized
INFO - 2024-12-29 01:57:12 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:12 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:12 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:12 --> URI Class Initialized
INFO - 2024-12-29 01:57:12 --> Router Class Initialized
INFO - 2024-12-29 01:57:12 --> Output Class Initialized
INFO - 2024-12-29 01:57:12 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:12 --> Input Class Initialized
INFO - 2024-12-29 01:57:12 --> Language Class Initialized
ERROR - 2024-12-29 01:57:12 --> 404 Page Not Found: Alfanew2php7/index
INFO - 2024-12-29 01:57:13 --> Config Class Initialized
INFO - 2024-12-29 01:57:13 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:13 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:13 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:13 --> URI Class Initialized
INFO - 2024-12-29 01:57:13 --> Router Class Initialized
INFO - 2024-12-29 01:57:13 --> Output Class Initialized
INFO - 2024-12-29 01:57:13 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:13 --> Input Class Initialized
INFO - 2024-12-29 01:57:13 --> Language Class Initialized
ERROR - 2024-12-29 01:57:13 --> 404 Page Not Found: Alfa-rex2php7/index
INFO - 2024-12-29 01:57:13 --> Config Class Initialized
INFO - 2024-12-29 01:57:13 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:13 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:13 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:13 --> URI Class Initialized
INFO - 2024-12-29 01:57:13 --> Router Class Initialized
INFO - 2024-12-29 01:57:13 --> Output Class Initialized
INFO - 2024-12-29 01:57:13 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:14 --> Input Class Initialized
INFO - 2024-12-29 01:57:14 --> Language Class Initialized
ERROR - 2024-12-29 01:57:14 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:57:14 --> Config Class Initialized
INFO - 2024-12-29 01:57:14 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:14 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:14 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:14 --> URI Class Initialized
INFO - 2024-12-29 01:57:14 --> Router Class Initialized
INFO - 2024-12-29 01:57:14 --> Output Class Initialized
INFO - 2024-12-29 01:57:14 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:14 --> Input Class Initialized
INFO - 2024-12-29 01:57:14 --> Language Class Initialized
ERROR - 2024-12-29 01:57:14 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:14 --> Config Class Initialized
INFO - 2024-12-29 01:57:14 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:14 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:14 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:14 --> URI Class Initialized
INFO - 2024-12-29 01:57:14 --> Router Class Initialized
INFO - 2024-12-29 01:57:14 --> Output Class Initialized
INFO - 2024-12-29 01:57:14 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:14 --> Input Class Initialized
INFO - 2024-12-29 01:57:14 --> Language Class Initialized
ERROR - 2024-12-29 01:57:15 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:57:15 --> Config Class Initialized
INFO - 2024-12-29 01:57:15 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:15 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:15 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:15 --> URI Class Initialized
INFO - 2024-12-29 01:57:15 --> Router Class Initialized
INFO - 2024-12-29 01:57:15 --> Output Class Initialized
INFO - 2024-12-29 01:57:15 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:15 --> Input Class Initialized
INFO - 2024-12-29 01:57:15 --> Language Class Initialized
ERROR - 2024-12-29 01:57:15 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:57:16 --> Config Class Initialized
INFO - 2024-12-29 01:57:16 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:16 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:16 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:16 --> URI Class Initialized
INFO - 2024-12-29 01:57:16 --> Router Class Initialized
INFO - 2024-12-29 01:57:16 --> Output Class Initialized
INFO - 2024-12-29 01:57:16 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:16 --> Input Class Initialized
INFO - 2024-12-29 01:57:16 --> Language Class Initialized
ERROR - 2024-12-29 01:57:16 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:16 --> Config Class Initialized
INFO - 2024-12-29 01:57:16 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:16 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:16 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:16 --> URI Class Initialized
INFO - 2024-12-29 01:57:16 --> Router Class Initialized
INFO - 2024-12-29 01:57:16 --> Output Class Initialized
INFO - 2024-12-29 01:57:16 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:16 --> Input Class Initialized
INFO - 2024-12-29 01:57:16 --> Language Class Initialized
ERROR - 2024-12-29 01:57:16 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:57:17 --> Config Class Initialized
INFO - 2024-12-29 01:57:17 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:17 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:17 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:17 --> URI Class Initialized
INFO - 2024-12-29 01:57:17 --> Router Class Initialized
INFO - 2024-12-29 01:57:17 --> Output Class Initialized
INFO - 2024-12-29 01:57:17 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:17 --> Input Class Initialized
INFO - 2024-12-29 01:57:17 --> Language Class Initialized
ERROR - 2024-12-29 01:57:17 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:17 --> Config Class Initialized
INFO - 2024-12-29 01:57:17 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:17 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:17 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:17 --> URI Class Initialized
INFO - 2024-12-29 01:57:17 --> Router Class Initialized
INFO - 2024-12-29 01:57:17 --> Output Class Initialized
INFO - 2024-12-29 01:57:17 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:17 --> Input Class Initialized
INFO - 2024-12-29 01:57:17 --> Language Class Initialized
ERROR - 2024-12-29 01:57:17 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:18 --> Config Class Initialized
INFO - 2024-12-29 01:57:18 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:18 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:18 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:18 --> URI Class Initialized
INFO - 2024-12-29 01:57:18 --> Router Class Initialized
INFO - 2024-12-29 01:57:18 --> Output Class Initialized
INFO - 2024-12-29 01:57:18 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:18 --> Input Class Initialized
INFO - 2024-12-29 01:57:18 --> Language Class Initialized
ERROR - 2024-12-29 01:57:18 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-29 01:57:18 --> Config Class Initialized
INFO - 2024-12-29 01:57:18 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:18 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:18 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:18 --> URI Class Initialized
INFO - 2024-12-29 01:57:18 --> Router Class Initialized
INFO - 2024-12-29 01:57:18 --> Output Class Initialized
INFO - 2024-12-29 01:57:18 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:18 --> Input Class Initialized
INFO - 2024-12-29 01:57:18 --> Language Class Initialized
ERROR - 2024-12-29 01:57:18 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-29 01:57:19 --> Config Class Initialized
INFO - 2024-12-29 01:57:19 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:19 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:19 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:19 --> URI Class Initialized
INFO - 2024-12-29 01:57:19 --> Router Class Initialized
INFO - 2024-12-29 01:57:19 --> Output Class Initialized
INFO - 2024-12-29 01:57:19 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:19 --> Input Class Initialized
INFO - 2024-12-29 01:57:19 --> Language Class Initialized
ERROR - 2024-12-29 01:57:19 --> 404 Page Not Found: Xmrlpcphp/index
INFO - 2024-12-29 01:57:19 --> Config Class Initialized
INFO - 2024-12-29 01:57:19 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:19 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:19 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:19 --> URI Class Initialized
INFO - 2024-12-29 01:57:19 --> Router Class Initialized
INFO - 2024-12-29 01:57:19 --> Output Class Initialized
INFO - 2024-12-29 01:57:19 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:19 --> Input Class Initialized
INFO - 2024-12-29 01:57:19 --> Language Class Initialized
ERROR - 2024-12-29 01:57:19 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
INFO - 2024-12-29 01:57:20 --> Config Class Initialized
INFO - 2024-12-29 01:57:20 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:20 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:20 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:20 --> URI Class Initialized
INFO - 2024-12-29 01:57:20 --> Router Class Initialized
INFO - 2024-12-29 01:57:20 --> Output Class Initialized
INFO - 2024-12-29 01:57:20 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:20 --> Input Class Initialized
INFO - 2024-12-29 01:57:20 --> Language Class Initialized
ERROR - 2024-12-29 01:57:20 --> 404 Page Not Found: Css/xmrlpc.php
INFO - 2024-12-29 01:57:20 --> Config Class Initialized
INFO - 2024-12-29 01:57:20 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:20 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:20 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:20 --> URI Class Initialized
INFO - 2024-12-29 01:57:20 --> Router Class Initialized
INFO - 2024-12-29 01:57:20 --> Output Class Initialized
INFO - 2024-12-29 01:57:20 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:20 --> Input Class Initialized
INFO - 2024-12-29 01:57:20 --> Language Class Initialized
ERROR - 2024-12-29 01:57:20 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-29 01:57:21 --> Config Class Initialized
INFO - 2024-12-29 01:57:21 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:21 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:21 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:21 --> URI Class Initialized
INFO - 2024-12-29 01:57:21 --> Router Class Initialized
INFO - 2024-12-29 01:57:21 --> Output Class Initialized
INFO - 2024-12-29 01:57:21 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:21 --> Input Class Initialized
INFO - 2024-12-29 01:57:21 --> Language Class Initialized
ERROR - 2024-12-29 01:57:21 --> 404 Page Not Found: Img/xmrlpc.php
INFO - 2024-12-29 01:57:21 --> Config Class Initialized
INFO - 2024-12-29 01:57:21 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:21 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:21 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:21 --> URI Class Initialized
INFO - 2024-12-29 01:57:21 --> Router Class Initialized
INFO - 2024-12-29 01:57:21 --> Output Class Initialized
INFO - 2024-12-29 01:57:21 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:21 --> Input Class Initialized
INFO - 2024-12-29 01:57:21 --> Language Class Initialized
ERROR - 2024-12-29 01:57:21 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:22 --> Config Class Initialized
INFO - 2024-12-29 01:57:22 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:22 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:22 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:22 --> URI Class Initialized
INFO - 2024-12-29 01:57:22 --> Router Class Initialized
INFO - 2024-12-29 01:57:22 --> Output Class Initialized
INFO - 2024-12-29 01:57:22 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:22 --> Input Class Initialized
INFO - 2024-12-29 01:57:22 --> Language Class Initialized
ERROR - 2024-12-29 01:57:22 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:57:23 --> Config Class Initialized
INFO - 2024-12-29 01:57:23 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:23 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:23 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:23 --> URI Class Initialized
INFO - 2024-12-29 01:57:23 --> Router Class Initialized
INFO - 2024-12-29 01:57:23 --> Output Class Initialized
INFO - 2024-12-29 01:57:23 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:23 --> Input Class Initialized
INFO - 2024-12-29 01:57:23 --> Language Class Initialized
ERROR - 2024-12-29 01:57:23 --> 404 Page Not Found: Images/xmrlpc.php
INFO - 2024-12-29 01:57:23 --> Config Class Initialized
INFO - 2024-12-29 01:57:23 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:23 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:23 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:23 --> URI Class Initialized
INFO - 2024-12-29 01:57:23 --> Router Class Initialized
INFO - 2024-12-29 01:57:23 --> Output Class Initialized
INFO - 2024-12-29 01:57:23 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:23 --> Input Class Initialized
INFO - 2024-12-29 01:57:23 --> Language Class Initialized
ERROR - 2024-12-29 01:57:23 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:57:24 --> Config Class Initialized
INFO - 2024-12-29 01:57:24 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:24 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:24 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:24 --> URI Class Initialized
INFO - 2024-12-29 01:57:24 --> Router Class Initialized
INFO - 2024-12-29 01:57:24 --> Output Class Initialized
INFO - 2024-12-29 01:57:24 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:24 --> Input Class Initialized
INFO - 2024-12-29 01:57:24 --> Language Class Initialized
ERROR - 2024-12-29 01:57:24 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:24 --> Config Class Initialized
INFO - 2024-12-29 01:57:24 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:24 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:24 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:24 --> URI Class Initialized
INFO - 2024-12-29 01:57:24 --> Router Class Initialized
INFO - 2024-12-29 01:57:24 --> Output Class Initialized
INFO - 2024-12-29 01:57:24 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:24 --> Input Class Initialized
INFO - 2024-12-29 01:57:24 --> Language Class Initialized
ERROR - 2024-12-29 01:57:24 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-29 01:57:25 --> Config Class Initialized
INFO - 2024-12-29 01:57:25 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:25 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:25 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:25 --> URI Class Initialized
INFO - 2024-12-29 01:57:25 --> Router Class Initialized
INFO - 2024-12-29 01:57:25 --> Output Class Initialized
INFO - 2024-12-29 01:57:25 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:25 --> Input Class Initialized
INFO - 2024-12-29 01:57:25 --> Language Class Initialized
ERROR - 2024-12-29 01:57:25 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:25 --> Config Class Initialized
INFO - 2024-12-29 01:57:25 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:25 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:25 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:25 --> URI Class Initialized
INFO - 2024-12-29 01:57:25 --> Router Class Initialized
INFO - 2024-12-29 01:57:25 --> Output Class Initialized
INFO - 2024-12-29 01:57:25 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:25 --> Input Class Initialized
INFO - 2024-12-29 01:57:25 --> Language Class Initialized
ERROR - 2024-12-29 01:57:25 --> 404 Page Not Found: Wp-admin/xmrlpc.php
INFO - 2024-12-29 01:57:26 --> Config Class Initialized
INFO - 2024-12-29 01:57:26 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:26 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:26 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:26 --> URI Class Initialized
INFO - 2024-12-29 01:57:26 --> Router Class Initialized
INFO - 2024-12-29 01:57:26 --> Output Class Initialized
INFO - 2024-12-29 01:57:26 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:26 --> Input Class Initialized
INFO - 2024-12-29 01:57:26 --> Language Class Initialized
ERROR - 2024-12-29 01:57:26 --> 404 Page Not Found: 403php/index
INFO - 2024-12-29 01:57:26 --> Config Class Initialized
INFO - 2024-12-29 01:57:26 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:26 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:26 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:26 --> URI Class Initialized
INFO - 2024-12-29 01:57:26 --> Router Class Initialized
INFO - 2024-12-29 01:57:26 --> Output Class Initialized
INFO - 2024-12-29 01:57:26 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:26 --> Input Class Initialized
INFO - 2024-12-29 01:57:26 --> Language Class Initialized
ERROR - 2024-12-29 01:57:26 --> 404 Page Not Found: Contentphp/index
INFO - 2024-12-29 01:57:27 --> Config Class Initialized
INFO - 2024-12-29 01:57:27 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:27 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:27 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:27 --> URI Class Initialized
INFO - 2024-12-29 01:57:27 --> Router Class Initialized
INFO - 2024-12-29 01:57:27 --> Output Class Initialized
INFO - 2024-12-29 01:57:27 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:27 --> Input Class Initialized
INFO - 2024-12-29 01:57:27 --> Language Class Initialized
ERROR - 2024-12-29 01:57:27 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:27 --> Config Class Initialized
INFO - 2024-12-29 01:57:27 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:27 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:27 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:27 --> URI Class Initialized
INFO - 2024-12-29 01:57:27 --> Router Class Initialized
INFO - 2024-12-29 01:57:27 --> Output Class Initialized
INFO - 2024-12-29 01:57:27 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:27 --> Input Class Initialized
INFO - 2024-12-29 01:57:27 --> Language Class Initialized
ERROR - 2024-12-29 01:57:27 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:28 --> Config Class Initialized
INFO - 2024-12-29 01:57:28 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:28 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:28 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:28 --> URI Class Initialized
INFO - 2024-12-29 01:57:28 --> Router Class Initialized
INFO - 2024-12-29 01:57:28 --> Output Class Initialized
INFO - 2024-12-29 01:57:28 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:28 --> Input Class Initialized
INFO - 2024-12-29 01:57:28 --> Language Class Initialized
ERROR - 2024-12-29 01:57:28 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:28 --> Config Class Initialized
INFO - 2024-12-29 01:57:28 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:28 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:28 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:28 --> URI Class Initialized
INFO - 2024-12-29 01:57:28 --> Router Class Initialized
INFO - 2024-12-29 01:57:28 --> Output Class Initialized
INFO - 2024-12-29 01:57:28 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:28 --> Input Class Initialized
INFO - 2024-12-29 01:57:28 --> Language Class Initialized
ERROR - 2024-12-29 01:57:28 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:57:29 --> Config Class Initialized
INFO - 2024-12-29 01:57:29 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:29 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:29 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:29 --> URI Class Initialized
INFO - 2024-12-29 01:57:29 --> Router Class Initialized
INFO - 2024-12-29 01:57:29 --> Output Class Initialized
INFO - 2024-12-29 01:57:29 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:29 --> Input Class Initialized
INFO - 2024-12-29 01:57:29 --> Language Class Initialized
ERROR - 2024-12-29 01:57:29 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-29 01:57:29 --> Config Class Initialized
INFO - 2024-12-29 01:57:29 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:29 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:29 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:29 --> URI Class Initialized
INFO - 2024-12-29 01:57:29 --> Router Class Initialized
INFO - 2024-12-29 01:57:29 --> Output Class Initialized
INFO - 2024-12-29 01:57:29 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:29 --> Input Class Initialized
INFO - 2024-12-29 01:57:29 --> Language Class Initialized
ERROR - 2024-12-29 01:57:29 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:30 --> Config Class Initialized
INFO - 2024-12-29 01:57:30 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:30 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:30 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:30 --> URI Class Initialized
INFO - 2024-12-29 01:57:30 --> Router Class Initialized
INFO - 2024-12-29 01:57:30 --> Output Class Initialized
INFO - 2024-12-29 01:57:30 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:30 --> Input Class Initialized
INFO - 2024-12-29 01:57:30 --> Language Class Initialized
ERROR - 2024-12-29 01:57:30 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:57:30 --> Config Class Initialized
INFO - 2024-12-29 01:57:30 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:30 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:30 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:30 --> URI Class Initialized
INFO - 2024-12-29 01:57:30 --> Router Class Initialized
INFO - 2024-12-29 01:57:30 --> Output Class Initialized
INFO - 2024-12-29 01:57:30 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:30 --> Input Class Initialized
INFO - 2024-12-29 01:57:30 --> Language Class Initialized
ERROR - 2024-12-29 01:57:30 --> 404 Page Not Found: Berlinphp/index
INFO - 2024-12-29 01:57:31 --> Config Class Initialized
INFO - 2024-12-29 01:57:31 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:31 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:31 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:31 --> URI Class Initialized
INFO - 2024-12-29 01:57:31 --> Router Class Initialized
INFO - 2024-12-29 01:57:31 --> Output Class Initialized
INFO - 2024-12-29 01:57:31 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:31 --> Input Class Initialized
INFO - 2024-12-29 01:57:31 --> Language Class Initialized
ERROR - 2024-12-29 01:57:31 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-29 01:57:31 --> Config Class Initialized
INFO - 2024-12-29 01:57:31 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:31 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:31 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:31 --> URI Class Initialized
INFO - 2024-12-29 01:57:31 --> Router Class Initialized
INFO - 2024-12-29 01:57:31 --> Output Class Initialized
INFO - 2024-12-29 01:57:31 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:31 --> Input Class Initialized
INFO - 2024-12-29 01:57:31 --> Language Class Initialized
ERROR - 2024-12-29 01:57:31 --> 404 Page Not Found: Wp-includes/style-engine
INFO - 2024-12-29 01:57:32 --> Config Class Initialized
INFO - 2024-12-29 01:57:32 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:32 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:32 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:32 --> URI Class Initialized
INFO - 2024-12-29 01:57:32 --> Router Class Initialized
INFO - 2024-12-29 01:57:32 --> Output Class Initialized
INFO - 2024-12-29 01:57:32 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:32 --> Input Class Initialized
INFO - 2024-12-29 01:57:32 --> Language Class Initialized
ERROR - 2024-12-29 01:57:32 --> 404 Page Not Found: Wp-includes/rest-api
INFO - 2024-12-29 01:57:32 --> Config Class Initialized
INFO - 2024-12-29 01:57:32 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:32 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:32 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:32 --> URI Class Initialized
INFO - 2024-12-29 01:57:32 --> Router Class Initialized
INFO - 2024-12-29 01:57:32 --> Output Class Initialized
INFO - 2024-12-29 01:57:32 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:32 --> Input Class Initialized
INFO - 2024-12-29 01:57:32 --> Language Class Initialized
ERROR - 2024-12-29 01:57:32 --> 404 Page Not Found: Wp-includes/SimplePie
INFO - 2024-12-29 01:57:33 --> Config Class Initialized
INFO - 2024-12-29 01:57:33 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:33 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:33 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:33 --> URI Class Initialized
INFO - 2024-12-29 01:57:33 --> Router Class Initialized
INFO - 2024-12-29 01:57:33 --> Output Class Initialized
INFO - 2024-12-29 01:57:33 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:33 --> Input Class Initialized
INFO - 2024-12-29 01:57:33 --> Language Class Initialized
ERROR - 2024-12-29 01:57:33 --> 404 Page Not Found: Wp-content/banners
INFO - 2024-12-29 01:57:33 --> Config Class Initialized
INFO - 2024-12-29 01:57:33 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:33 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:33 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:33 --> URI Class Initialized
INFO - 2024-12-29 01:57:33 --> Router Class Initialized
INFO - 2024-12-29 01:57:33 --> Output Class Initialized
INFO - 2024-12-29 01:57:33 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:33 --> Input Class Initialized
INFO - 2024-12-29 01:57:33 --> Language Class Initialized
ERROR - 2024-12-29 01:57:33 --> 404 Page Not Found: Wp-content/about.php
INFO - 2024-12-29 01:57:34 --> Config Class Initialized
INFO - 2024-12-29 01:57:34 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:34 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:34 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:34 --> URI Class Initialized
INFO - 2024-12-29 01:57:34 --> Router Class Initialized
INFO - 2024-12-29 01:57:34 --> Output Class Initialized
INFO - 2024-12-29 01:57:34 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:34 --> Input Class Initialized
INFO - 2024-12-29 01:57:34 --> Language Class Initialized
ERROR - 2024-12-29 01:57:34 --> 404 Page Not Found: Well-known/about.php
INFO - 2024-12-29 01:57:34 --> Config Class Initialized
INFO - 2024-12-29 01:57:34 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:34 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:34 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:34 --> URI Class Initialized
INFO - 2024-12-29 01:57:34 --> Router Class Initialized
INFO - 2024-12-29 01:57:34 --> Output Class Initialized
INFO - 2024-12-29 01:57:34 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:34 --> Input Class Initialized
INFO - 2024-12-29 01:57:34 --> Language Class Initialized
ERROR - 2024-12-29 01:57:34 --> 404 Page Not Found: Wp-includes/Text
INFO - 2024-12-29 01:57:35 --> Config Class Initialized
INFO - 2024-12-29 01:57:35 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:35 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:35 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:35 --> URI Class Initialized
INFO - 2024-12-29 01:57:35 --> Router Class Initialized
INFO - 2024-12-29 01:57:35 --> Output Class Initialized
INFO - 2024-12-29 01:57:35 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:35 --> Input Class Initialized
INFO - 2024-12-29 01:57:35 --> Language Class Initialized
ERROR - 2024-12-29 01:57:35 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2024-12-29 01:57:35 --> Config Class Initialized
INFO - 2024-12-29 01:57:35 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:35 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:35 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:35 --> URI Class Initialized
INFO - 2024-12-29 01:57:35 --> Router Class Initialized
INFO - 2024-12-29 01:57:35 --> Output Class Initialized
INFO - 2024-12-29 01:57:35 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:35 --> Input Class Initialized
INFO - 2024-12-29 01:57:35 --> Language Class Initialized
ERROR - 2024-12-29 01:57:35 --> 404 Page Not Found: Img/about.php
INFO - 2024-12-29 01:57:36 --> Config Class Initialized
INFO - 2024-12-29 01:57:36 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:36 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:36 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:36 --> URI Class Initialized
INFO - 2024-12-29 01:57:36 --> Router Class Initialized
INFO - 2024-12-29 01:57:36 --> Output Class Initialized
INFO - 2024-12-29 01:57:36 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:36 --> Input Class Initialized
INFO - 2024-12-29 01:57:36 --> Language Class Initialized
ERROR - 2024-12-29 01:57:36 --> 404 Page Not Found: Wp-content/languages
INFO - 2024-12-29 01:57:36 --> Config Class Initialized
INFO - 2024-12-29 01:57:36 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:36 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:36 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:36 --> URI Class Initialized
INFO - 2024-12-29 01:57:36 --> Router Class Initialized
INFO - 2024-12-29 01:57:36 --> Output Class Initialized
INFO - 2024-12-29 01:57:36 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:36 --> Input Class Initialized
INFO - 2024-12-29 01:57:36 --> Language Class Initialized
ERROR - 2024-12-29 01:57:36 --> 404 Page Not Found: Wp-includes/customize
INFO - 2024-12-29 01:57:37 --> Config Class Initialized
INFO - 2024-12-29 01:57:37 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:37 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:37 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:37 --> URI Class Initialized
INFO - 2024-12-29 01:57:37 --> Router Class Initialized
INFO - 2024-12-29 01:57:37 --> Output Class Initialized
INFO - 2024-12-29 01:57:37 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:37 --> Input Class Initialized
INFO - 2024-12-29 01:57:37 --> Language Class Initialized
ERROR - 2024-12-29 01:57:37 --> 404 Page Not Found: Wp-includesbak/html-api
INFO - 2024-12-29 01:57:37 --> Config Class Initialized
INFO - 2024-12-29 01:57:37 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:37 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:37 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:37 --> URI Class Initialized
INFO - 2024-12-29 01:57:37 --> Router Class Initialized
INFO - 2024-12-29 01:57:37 --> Output Class Initialized
INFO - 2024-12-29 01:57:37 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:37 --> Input Class Initialized
INFO - 2024-12-29 01:57:37 --> Language Class Initialized
ERROR - 2024-12-29 01:57:37 --> 404 Page Not Found: Wp-includes/widgets
INFO - 2024-12-29 01:57:38 --> Config Class Initialized
INFO - 2024-12-29 01:57:38 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:38 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:38 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:38 --> URI Class Initialized
INFO - 2024-12-29 01:57:38 --> Router Class Initialized
INFO - 2024-12-29 01:57:38 --> Output Class Initialized
INFO - 2024-12-29 01:57:38 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:38 --> Input Class Initialized
INFO - 2024-12-29 01:57:38 --> Language Class Initialized
ERROR - 2024-12-29 01:57:38 --> 404 Page Not Found: Wp-includes/IXR
INFO - 2024-12-29 01:57:38 --> Config Class Initialized
INFO - 2024-12-29 01:57:38 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:38 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:38 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:38 --> URI Class Initialized
INFO - 2024-12-29 01:57:38 --> Router Class Initialized
INFO - 2024-12-29 01:57:38 --> Output Class Initialized
INFO - 2024-12-29 01:57:38 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:38 --> Input Class Initialized
INFO - 2024-12-29 01:57:38 --> Language Class Initialized
ERROR - 2024-12-29 01:57:38 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:57:39 --> Config Class Initialized
INFO - 2024-12-29 01:57:39 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:39 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:39 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:39 --> URI Class Initialized
INFO - 2024-12-29 01:57:39 --> Router Class Initialized
INFO - 2024-12-29 01:57:39 --> Output Class Initialized
INFO - 2024-12-29 01:57:39 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:39 --> Input Class Initialized
INFO - 2024-12-29 01:57:39 --> Language Class Initialized
ERROR - 2024-12-29 01:57:39 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-29 01:57:39 --> Config Class Initialized
INFO - 2024-12-29 01:57:39 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:39 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:39 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:39 --> URI Class Initialized
INFO - 2024-12-29 01:57:39 --> Router Class Initialized
INFO - 2024-12-29 01:57:39 --> Output Class Initialized
INFO - 2024-12-29 01:57:39 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:39 --> Input Class Initialized
INFO - 2024-12-29 01:57:39 --> Language Class Initialized
ERROR - 2024-12-29 01:57:39 --> 404 Page Not Found: Wp-includes/pomo
INFO - 2024-12-29 01:57:40 --> Config Class Initialized
INFO - 2024-12-29 01:57:40 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:40 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:40 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:40 --> URI Class Initialized
INFO - 2024-12-29 01:57:40 --> Router Class Initialized
INFO - 2024-12-29 01:57:40 --> Output Class Initialized
INFO - 2024-12-29 01:57:40 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:40 --> Input Class Initialized
INFO - 2024-12-29 01:57:40 --> Language Class Initialized
ERROR - 2024-12-29 01:57:40 --> 404 Page Not Found: Wp-includes/block-patterns
INFO - 2024-12-29 01:57:40 --> Config Class Initialized
INFO - 2024-12-29 01:57:40 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:40 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:40 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:40 --> URI Class Initialized
INFO - 2024-12-29 01:57:40 --> Router Class Initialized
INFO - 2024-12-29 01:57:40 --> Output Class Initialized
INFO - 2024-12-29 01:57:40 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:40 --> Input Class Initialized
INFO - 2024-12-29 01:57:40 --> Language Class Initialized
ERROR - 2024-12-29 01:57:40 --> 404 Page Not Found: Wp-content/updraft
INFO - 2024-12-29 01:57:41 --> Config Class Initialized
INFO - 2024-12-29 01:57:41 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:41 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:41 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:41 --> URI Class Initialized
INFO - 2024-12-29 01:57:41 --> Router Class Initialized
INFO - 2024-12-29 01:57:41 --> Output Class Initialized
INFO - 2024-12-29 01:57:41 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:41 --> Input Class Initialized
INFO - 2024-12-29 01:57:41 --> Language Class Initialized
ERROR - 2024-12-29 01:57:41 --> 404 Page Not Found: Wp-content/upgrade-temp-backup
INFO - 2024-12-29 01:57:41 --> Config Class Initialized
INFO - 2024-12-29 01:57:41 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:41 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:41 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:41 --> URI Class Initialized
INFO - 2024-12-29 01:57:41 --> Router Class Initialized
INFO - 2024-12-29 01:57:41 --> Output Class Initialized
INFO - 2024-12-29 01:57:41 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:41 --> Input Class Initialized
INFO - 2024-12-29 01:57:41 --> Language Class Initialized
ERROR - 2024-12-29 01:57:41 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:57:42 --> Config Class Initialized
INFO - 2024-12-29 01:57:42 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:42 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:42 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:42 --> URI Class Initialized
INFO - 2024-12-29 01:57:42 --> Router Class Initialized
INFO - 2024-12-29 01:57:42 --> Output Class Initialized
INFO - 2024-12-29 01:57:42 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:42 --> Input Class Initialized
INFO - 2024-12-29 01:57:42 --> Language Class Initialized
ERROR - 2024-12-29 01:57:42 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-29 01:57:43 --> Config Class Initialized
INFO - 2024-12-29 01:57:43 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:43 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:43 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:43 --> URI Class Initialized
INFO - 2024-12-29 01:57:43 --> Router Class Initialized
INFO - 2024-12-29 01:57:43 --> Output Class Initialized
INFO - 2024-12-29 01:57:43 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:43 --> Input Class Initialized
INFO - 2024-12-29 01:57:43 --> Language Class Initialized
ERROR - 2024-12-29 01:57:43 --> 404 Page Not Found: Images/about.php
INFO - 2024-12-29 01:57:43 --> Config Class Initialized
INFO - 2024-12-29 01:57:43 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:43 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:43 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:43 --> URI Class Initialized
INFO - 2024-12-29 01:57:43 --> Router Class Initialized
INFO - 2024-12-29 01:57:43 --> Output Class Initialized
INFO - 2024-12-29 01:57:43 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:43 --> Input Class Initialized
INFO - 2024-12-29 01:57:43 --> Language Class Initialized
ERROR - 2024-12-29 01:57:43 --> 404 Page Not Found: Wp-content/blogs.dir
INFO - 2024-12-29 01:57:44 --> Config Class Initialized
INFO - 2024-12-29 01:57:44 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:44 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:44 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:44 --> URI Class Initialized
INFO - 2024-12-29 01:57:44 --> Router Class Initialized
INFO - 2024-12-29 01:57:44 --> Output Class Initialized
INFO - 2024-12-29 01:57:44 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:44 --> Input Class Initialized
INFO - 2024-12-29 01:57:44 --> Language Class Initialized
ERROR - 2024-12-29 01:57:44 --> 404 Page Not Found: Wp-includes/images
INFO - 2024-12-29 01:57:44 --> Config Class Initialized
INFO - 2024-12-29 01:57:44 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:44 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:44 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:44 --> URI Class Initialized
INFO - 2024-12-29 01:57:44 --> Router Class Initialized
INFO - 2024-12-29 01:57:44 --> Output Class Initialized
INFO - 2024-12-29 01:57:44 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:44 --> Input Class Initialized
INFO - 2024-12-29 01:57:44 --> Language Class Initialized
ERROR - 2024-12-29 01:57:44 --> 404 Page Not Found: Wp-includes/about.php
INFO - 2024-12-29 01:57:45 --> Config Class Initialized
INFO - 2024-12-29 01:57:45 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:45 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:45 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:45 --> URI Class Initialized
INFO - 2024-12-29 01:57:45 --> Router Class Initialized
INFO - 2024-12-29 01:57:45 --> Output Class Initialized
INFO - 2024-12-29 01:57:45 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:45 --> Input Class Initialized
INFO - 2024-12-29 01:57:45 --> Language Class Initialized
ERROR - 2024-12-29 01:57:45 --> 404 Page Not Found: Cgi-bin/about.php
INFO - 2024-12-29 01:57:45 --> Config Class Initialized
INFO - 2024-12-29 01:57:45 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:45 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:45 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:45 --> URI Class Initialized
INFO - 2024-12-29 01:57:45 --> Router Class Initialized
INFO - 2024-12-29 01:57:45 --> Output Class Initialized
INFO - 2024-12-29 01:57:45 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:45 --> Input Class Initialized
INFO - 2024-12-29 01:57:45 --> Language Class Initialized
ERROR - 2024-12-29 01:57:45 --> 404 Page Not Found: Wp-content/gallery
INFO - 2024-12-29 01:57:46 --> Config Class Initialized
INFO - 2024-12-29 01:57:46 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:46 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:46 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:46 --> URI Class Initialized
INFO - 2024-12-29 01:57:46 --> Router Class Initialized
INFO - 2024-12-29 01:57:46 --> Output Class Initialized
INFO - 2024-12-29 01:57:46 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:46 --> Input Class Initialized
INFO - 2024-12-29 01:57:46 --> Language Class Initialized
ERROR - 2024-12-29 01:57:46 --> 404 Page Not Found: Wp-includes/blocks
INFO - 2024-12-29 01:57:46 --> Config Class Initialized
INFO - 2024-12-29 01:57:46 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:46 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:46 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:46 --> URI Class Initialized
INFO - 2024-12-29 01:57:46 --> Router Class Initialized
INFO - 2024-12-29 01:57:46 --> Output Class Initialized
INFO - 2024-12-29 01:57:46 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:46 --> Input Class Initialized
INFO - 2024-12-29 01:57:46 --> Language Class Initialized
ERROR - 2024-12-29 01:57:46 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:47 --> Config Class Initialized
INFO - 2024-12-29 01:57:47 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:47 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:47 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:47 --> URI Class Initialized
INFO - 2024-12-29 01:57:47 --> Router Class Initialized
INFO - 2024-12-29 01:57:47 --> Output Class Initialized
INFO - 2024-12-29 01:57:47 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:47 --> Input Class Initialized
INFO - 2024-12-29 01:57:47 --> Language Class Initialized
ERROR - 2024-12-29 01:57:47 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:57:47 --> Config Class Initialized
INFO - 2024-12-29 01:57:47 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:47 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:47 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:47 --> URI Class Initialized
INFO - 2024-12-29 01:57:47 --> Router Class Initialized
INFO - 2024-12-29 01:57:47 --> Output Class Initialized
INFO - 2024-12-29 01:57:47 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:47 --> Input Class Initialized
INFO - 2024-12-29 01:57:47 --> Language Class Initialized
ERROR - 2024-12-29 01:57:47 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-29 01:57:48 --> Config Class Initialized
INFO - 2024-12-29 01:57:48 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:48 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:48 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:48 --> URI Class Initialized
INFO - 2024-12-29 01:57:48 --> Router Class Initialized
INFO - 2024-12-29 01:57:48 --> Output Class Initialized
INFO - 2024-12-29 01:57:48 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:48 --> Input Class Initialized
INFO - 2024-12-29 01:57:48 --> Language Class Initialized
ERROR - 2024-12-29 01:57:48 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-29 01:57:48 --> Config Class Initialized
INFO - 2024-12-29 01:57:48 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:48 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:48 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:48 --> URI Class Initialized
INFO - 2024-12-29 01:57:48 --> Router Class Initialized
INFO - 2024-12-29 01:57:48 --> Output Class Initialized
INFO - 2024-12-29 01:57:48 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:48 --> Input Class Initialized
INFO - 2024-12-29 01:57:48 --> Language Class Initialized
ERROR - 2024-12-29 01:57:48 --> 404 Page Not Found: Cloudphp/index
INFO - 2024-12-29 01:57:49 --> Config Class Initialized
INFO - 2024-12-29 01:57:49 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:49 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:49 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:49 --> URI Class Initialized
INFO - 2024-12-29 01:57:49 --> Router Class Initialized
INFO - 2024-12-29 01:57:49 --> Output Class Initialized
INFO - 2024-12-29 01:57:49 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:49 --> Input Class Initialized
INFO - 2024-12-29 01:57:49 --> Language Class Initialized
ERROR - 2024-12-29 01:57:49 --> 404 Page Not Found: Cgi-bin/cloud.php
INFO - 2024-12-29 01:57:49 --> Config Class Initialized
INFO - 2024-12-29 01:57:49 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:49 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:49 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:49 --> URI Class Initialized
INFO - 2024-12-29 01:57:49 --> Router Class Initialized
INFO - 2024-12-29 01:57:49 --> Output Class Initialized
INFO - 2024-12-29 01:57:49 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:49 --> Input Class Initialized
INFO - 2024-12-29 01:57:49 --> Language Class Initialized
ERROR - 2024-12-29 01:57:49 --> 404 Page Not Found: Wp-content/updates.php
INFO - 2024-12-29 01:57:50 --> Config Class Initialized
INFO - 2024-12-29 01:57:50 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:50 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:50 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:50 --> URI Class Initialized
INFO - 2024-12-29 01:57:50 --> Router Class Initialized
INFO - 2024-12-29 01:57:50 --> Output Class Initialized
INFO - 2024-12-29 01:57:50 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:50 --> Input Class Initialized
INFO - 2024-12-29 01:57:50 --> Language Class Initialized
ERROR - 2024-12-29 01:57:50 --> 404 Page Not Found: Css/cloud.php
INFO - 2024-12-29 01:57:50 --> Config Class Initialized
INFO - 2024-12-29 01:57:50 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:50 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:50 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:50 --> URI Class Initialized
INFO - 2024-12-29 01:57:50 --> Router Class Initialized
INFO - 2024-12-29 01:57:50 --> Output Class Initialized
INFO - 2024-12-29 01:57:50 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:50 --> Input Class Initialized
INFO - 2024-12-29 01:57:51 --> Language Class Initialized
ERROR - 2024-12-29 01:57:51 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-29 01:57:51 --> Config Class Initialized
INFO - 2024-12-29 01:57:51 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:51 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:51 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:51 --> URI Class Initialized
INFO - 2024-12-29 01:57:51 --> Router Class Initialized
INFO - 2024-12-29 01:57:51 --> Output Class Initialized
INFO - 2024-12-29 01:57:51 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:51 --> Input Class Initialized
INFO - 2024-12-29 01:57:51 --> Language Class Initialized
ERROR - 2024-12-29 01:57:51 --> 404 Page Not Found: Img/cloud.php
INFO - 2024-12-29 01:57:51 --> Config Class Initialized
INFO - 2024-12-29 01:57:51 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:51 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:51 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:51 --> URI Class Initialized
INFO - 2024-12-29 01:57:51 --> Router Class Initialized
INFO - 2024-12-29 01:57:51 --> Output Class Initialized
INFO - 2024-12-29 01:57:52 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:52 --> Input Class Initialized
INFO - 2024-12-29 01:57:52 --> Language Class Initialized
ERROR - 2024-12-29 01:57:52 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:52 --> Config Class Initialized
INFO - 2024-12-29 01:57:52 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:52 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:52 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:52 --> URI Class Initialized
INFO - 2024-12-29 01:57:52 --> Router Class Initialized
INFO - 2024-12-29 01:57:52 --> Output Class Initialized
INFO - 2024-12-29 01:57:52 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:52 --> Input Class Initialized
INFO - 2024-12-29 01:57:52 --> Language Class Initialized
ERROR - 2024-12-29 01:57:52 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:57:53 --> Config Class Initialized
INFO - 2024-12-29 01:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:53 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:53 --> URI Class Initialized
INFO - 2024-12-29 01:57:53 --> Router Class Initialized
INFO - 2024-12-29 01:57:53 --> Output Class Initialized
INFO - 2024-12-29 01:57:53 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:53 --> Input Class Initialized
INFO - 2024-12-29 01:57:53 --> Language Class Initialized
ERROR - 2024-12-29 01:57:53 --> 404 Page Not Found: Avaaphp/index
INFO - 2024-12-29 01:57:53 --> Config Class Initialized
INFO - 2024-12-29 01:57:53 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:53 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:53 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:53 --> URI Class Initialized
INFO - 2024-12-29 01:57:53 --> Router Class Initialized
INFO - 2024-12-29 01:57:53 --> Output Class Initialized
INFO - 2024-12-29 01:57:53 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:53 --> Input Class Initialized
INFO - 2024-12-29 01:57:53 --> Language Class Initialized
ERROR - 2024-12-29 01:57:53 --> 404 Page Not Found: Images/cloud.php
INFO - 2024-12-29 01:57:54 --> Config Class Initialized
INFO - 2024-12-29 01:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:54 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:54 --> URI Class Initialized
INFO - 2024-12-29 01:57:54 --> Router Class Initialized
INFO - 2024-12-29 01:57:54 --> Output Class Initialized
INFO - 2024-12-29 01:57:54 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:54 --> Input Class Initialized
INFO - 2024-12-29 01:57:54 --> Language Class Initialized
ERROR - 2024-12-29 01:57:54 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:57:54 --> Config Class Initialized
INFO - 2024-12-29 01:57:54 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:54 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:54 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:54 --> URI Class Initialized
INFO - 2024-12-29 01:57:54 --> Router Class Initialized
INFO - 2024-12-29 01:57:54 --> Output Class Initialized
INFO - 2024-12-29 01:57:54 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:54 --> Input Class Initialized
INFO - 2024-12-29 01:57:54 --> Language Class Initialized
ERROR - 2024-12-29 01:57:54 --> 404 Page Not Found: Wp-includes/Requests
INFO - 2024-12-29 01:57:55 --> Config Class Initialized
INFO - 2024-12-29 01:57:55 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:55 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:55 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:55 --> URI Class Initialized
INFO - 2024-12-29 01:57:55 --> Router Class Initialized
INFO - 2024-12-29 01:57:55 --> Output Class Initialized
INFO - 2024-12-29 01:57:55 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:55 --> Input Class Initialized
INFO - 2024-12-29 01:57:55 --> Language Class Initialized
ERROR - 2024-12-29 01:57:55 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:55 --> Config Class Initialized
INFO - 2024-12-29 01:57:55 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:55 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:55 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:55 --> URI Class Initialized
INFO - 2024-12-29 01:57:55 --> Router Class Initialized
INFO - 2024-12-29 01:57:55 --> Output Class Initialized
INFO - 2024-12-29 01:57:55 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:55 --> Input Class Initialized
INFO - 2024-12-29 01:57:55 --> Language Class Initialized
ERROR - 2024-12-29 01:57:55 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-29 01:57:56 --> Config Class Initialized
INFO - 2024-12-29 01:57:56 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:56 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:56 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:56 --> URI Class Initialized
INFO - 2024-12-29 01:57:56 --> Router Class Initialized
INFO - 2024-12-29 01:57:56 --> Output Class Initialized
INFO - 2024-12-29 01:57:56 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:56 --> Input Class Initialized
INFO - 2024-12-29 01:57:56 --> Language Class Initialized
ERROR - 2024-12-29 01:57:56 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:57:56 --> Config Class Initialized
INFO - 2024-12-29 01:57:56 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:56 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:56 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:56 --> URI Class Initialized
INFO - 2024-12-29 01:57:56 --> Router Class Initialized
INFO - 2024-12-29 01:57:56 --> Output Class Initialized
INFO - 2024-12-29 01:57:56 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:56 --> Input Class Initialized
INFO - 2024-12-29 01:57:56 --> Language Class Initialized
ERROR - 2024-12-29 01:57:56 --> 404 Page Not Found: Wp-admin/cloud.php
INFO - 2024-12-29 01:57:57 --> Config Class Initialized
INFO - 2024-12-29 01:57:57 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:57 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:57 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:57 --> URI Class Initialized
INFO - 2024-12-29 01:57:57 --> Router Class Initialized
INFO - 2024-12-29 01:57:57 --> Output Class Initialized
INFO - 2024-12-29 01:57:57 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:57 --> Input Class Initialized
INFO - 2024-12-29 01:57:57 --> Language Class Initialized
ERROR - 2024-12-29 01:57:57 --> 404 Page Not Found: Updatesphp/index
INFO - 2024-12-29 01:57:57 --> Config Class Initialized
INFO - 2024-12-29 01:57:57 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:57 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:57 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:57 --> URI Class Initialized
INFO - 2024-12-29 01:57:57 --> Router Class Initialized
INFO - 2024-12-29 01:57:57 --> Output Class Initialized
INFO - 2024-12-29 01:57:57 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:57 --> Input Class Initialized
INFO - 2024-12-29 01:57:57 --> Language Class Initialized
ERROR - 2024-12-29 01:57:57 --> 404 Page Not Found: Libraries/legacy
INFO - 2024-12-29 01:57:58 --> Config Class Initialized
INFO - 2024-12-29 01:57:58 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:58 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:58 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:58 --> URI Class Initialized
INFO - 2024-12-29 01:57:58 --> Router Class Initialized
INFO - 2024-12-29 01:57:58 --> Output Class Initialized
INFO - 2024-12-29 01:57:58 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:58 --> Input Class Initialized
INFO - 2024-12-29 01:57:58 --> Language Class Initialized
ERROR - 2024-12-29 01:57:58 --> 404 Page Not Found: Libraries/phpmailer
INFO - 2024-12-29 01:57:58 --> Config Class Initialized
INFO - 2024-12-29 01:57:58 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:58 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:58 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:58 --> URI Class Initialized
INFO - 2024-12-29 01:57:58 --> Router Class Initialized
INFO - 2024-12-29 01:57:58 --> Output Class Initialized
INFO - 2024-12-29 01:57:58 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:58 --> Input Class Initialized
INFO - 2024-12-29 01:57:58 --> Language Class Initialized
ERROR - 2024-12-29 01:57:58 --> 404 Page Not Found: Libraries/vendor
INFO - 2024-12-29 01:57:59 --> Config Class Initialized
INFO - 2024-12-29 01:57:59 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:59 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:59 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:59 --> URI Class Initialized
INFO - 2024-12-29 01:57:59 --> Router Class Initialized
INFO - 2024-12-29 01:57:59 --> Output Class Initialized
INFO - 2024-12-29 01:57:59 --> Security Class Initialized
DEBUG - 2024-12-29 01:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:57:59 --> Input Class Initialized
INFO - 2024-12-29 01:57:59 --> Language Class Initialized
ERROR - 2024-12-29 01:57:59 --> 404 Page Not Found: Alfa-rexphp7/index
INFO - 2024-12-29 01:57:59 --> Config Class Initialized
INFO - 2024-12-29 01:57:59 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:57:59 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:57:59 --> Utf8 Class Initialized
INFO - 2024-12-29 01:57:59 --> URI Class Initialized
INFO - 2024-12-29 01:57:59 --> Router Class Initialized
INFO - 2024-12-29 01:57:59 --> Output Class Initialized
INFO - 2024-12-29 01:58:00 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:00 --> Input Class Initialized
INFO - 2024-12-29 01:58:00 --> Language Class Initialized
ERROR - 2024-12-29 01:58:00 --> 404 Page Not Found: Alfanewphp/index
INFO - 2024-12-29 01:58:00 --> Config Class Initialized
INFO - 2024-12-29 01:58:00 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:00 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:00 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:00 --> URI Class Initialized
INFO - 2024-12-29 01:58:00 --> Router Class Initialized
INFO - 2024-12-29 01:58:00 --> Output Class Initialized
INFO - 2024-12-29 01:58:00 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:00 --> Input Class Initialized
INFO - 2024-12-29 01:58:00 --> Language Class Initialized
ERROR - 2024-12-29 01:58:00 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:58:01 --> Config Class Initialized
INFO - 2024-12-29 01:58:01 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:01 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:01 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:01 --> URI Class Initialized
INFO - 2024-12-29 01:58:01 --> Router Class Initialized
INFO - 2024-12-29 01:58:01 --> Output Class Initialized
INFO - 2024-12-29 01:58:01 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:01 --> Input Class Initialized
INFO - 2024-12-29 01:58:01 --> Language Class Initialized
ERROR - 2024-12-29 01:58:01 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:58:01 --> Config Class Initialized
INFO - 2024-12-29 01:58:01 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:01 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:01 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:01 --> URI Class Initialized
INFO - 2024-12-29 01:58:01 --> Router Class Initialized
INFO - 2024-12-29 01:58:01 --> Output Class Initialized
INFO - 2024-12-29 01:58:01 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:01 --> Input Class Initialized
INFO - 2024-12-29 01:58:01 --> Language Class Initialized
ERROR - 2024-12-29 01:58:01 --> 404 Page Not Found: Wp-pphp7/index
INFO - 2024-12-29 01:58:02 --> Config Class Initialized
INFO - 2024-12-29 01:58:02 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:02 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:02 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:02 --> URI Class Initialized
INFO - 2024-12-29 01:58:02 --> Router Class Initialized
INFO - 2024-12-29 01:58:02 --> Output Class Initialized
INFO - 2024-12-29 01:58:02 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:02 --> Input Class Initialized
INFO - 2024-12-29 01:58:02 --> Language Class Initialized
ERROR - 2024-12-29 01:58:02 --> 404 Page Not Found: Wp-admin/repeater.php
INFO - 2024-12-29 01:58:02 --> Config Class Initialized
INFO - 2024-12-29 01:58:02 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:02 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:02 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:02 --> URI Class Initialized
INFO - 2024-12-29 01:58:02 --> Router Class Initialized
INFO - 2024-12-29 01:58:02 --> Output Class Initialized
INFO - 2024-12-29 01:58:02 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:02 --> Input Class Initialized
INFO - 2024-12-29 01:58:02 --> Language Class Initialized
ERROR - 2024-12-29 01:58:02 --> 404 Page Not Found: Wp-includes/repeater.php
INFO - 2024-12-29 01:58:03 --> Config Class Initialized
INFO - 2024-12-29 01:58:03 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:03 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:03 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:03 --> URI Class Initialized
INFO - 2024-12-29 01:58:03 --> Router Class Initialized
INFO - 2024-12-29 01:58:03 --> Output Class Initialized
INFO - 2024-12-29 01:58:03 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:03 --> Input Class Initialized
INFO - 2024-12-29 01:58:03 --> Language Class Initialized
ERROR - 2024-12-29 01:58:03 --> 404 Page Not Found: Wp-content/repeater.php
INFO - 2024-12-29 01:58:03 --> Config Class Initialized
INFO - 2024-12-29 01:58:03 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:03 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:03 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:03 --> URI Class Initialized
INFO - 2024-12-29 01:58:03 --> Router Class Initialized
INFO - 2024-12-29 01:58:03 --> Output Class Initialized
INFO - 2024-12-29 01:58:03 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:03 --> Input Class Initialized
INFO - 2024-12-29 01:58:03 --> Language Class Initialized
ERROR - 2024-12-29 01:58:03 --> 404 Page Not Found: Wsoyanzphp/index
INFO - 2024-12-29 01:58:04 --> Config Class Initialized
INFO - 2024-12-29 01:58:04 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:04 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:04 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:04 --> URI Class Initialized
INFO - 2024-12-29 01:58:04 --> Router Class Initialized
INFO - 2024-12-29 01:58:04 --> Output Class Initialized
INFO - 2024-12-29 01:58:04 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:04 --> Input Class Initialized
INFO - 2024-12-29 01:58:04 --> Language Class Initialized
ERROR - 2024-12-29 01:58:04 --> 404 Page Not Found: Yanzphp/index
INFO - 2024-12-29 01:58:04 --> Config Class Initialized
INFO - 2024-12-29 01:58:04 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:04 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:04 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:04 --> URI Class Initialized
INFO - 2024-12-29 01:58:04 --> Router Class Initialized
INFO - 2024-12-29 01:58:04 --> Output Class Initialized
INFO - 2024-12-29 01:58:04 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:04 --> Input Class Initialized
INFO - 2024-12-29 01:58:04 --> Language Class Initialized
ERROR - 2024-12-29 01:58:04 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:58:05 --> Config Class Initialized
INFO - 2024-12-29 01:58:05 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:05 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:05 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:05 --> URI Class Initialized
INFO - 2024-12-29 01:58:05 --> Router Class Initialized
INFO - 2024-12-29 01:58:05 --> Output Class Initialized
INFO - 2024-12-29 01:58:05 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:05 --> Input Class Initialized
INFO - 2024-12-29 01:58:05 --> Language Class Initialized
ERROR - 2024-12-29 01:58:05 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:58:05 --> Config Class Initialized
INFO - 2024-12-29 01:58:05 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:05 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:05 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:05 --> URI Class Initialized
INFO - 2024-12-29 01:58:05 --> Router Class Initialized
INFO - 2024-12-29 01:58:05 --> Output Class Initialized
INFO - 2024-12-29 01:58:05 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:05 --> Input Class Initialized
INFO - 2024-12-29 01:58:05 --> Language Class Initialized
ERROR - 2024-12-29 01:58:05 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:58:06 --> Config Class Initialized
INFO - 2024-12-29 01:58:06 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:06 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:06 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:06 --> URI Class Initialized
INFO - 2024-12-29 01:58:06 --> Router Class Initialized
INFO - 2024-12-29 01:58:06 --> Output Class Initialized
INFO - 2024-12-29 01:58:06 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:06 --> Input Class Initialized
INFO - 2024-12-29 01:58:06 --> Language Class Initialized
ERROR - 2024-12-29 01:58:06 --> 404 Page Not Found: Cache-compatphp/index
INFO - 2024-12-29 01:58:06 --> Config Class Initialized
INFO - 2024-12-29 01:58:06 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:06 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:06 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:06 --> URI Class Initialized
INFO - 2024-12-29 01:58:06 --> Router Class Initialized
INFO - 2024-12-29 01:58:06 --> Output Class Initialized
INFO - 2024-12-29 01:58:06 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:06 --> Input Class Initialized
INFO - 2024-12-29 01:58:06 --> Language Class Initialized
ERROR - 2024-12-29 01:58:06 --> 404 Page Not Found: Ajax-actionsphp/index
INFO - 2024-12-29 01:58:07 --> Config Class Initialized
INFO - 2024-12-29 01:58:07 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:07 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:07 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:07 --> URI Class Initialized
INFO - 2024-12-29 01:58:07 --> Router Class Initialized
INFO - 2024-12-29 01:58:07 --> Output Class Initialized
INFO - 2024-12-29 01:58:07 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:07 --> Input Class Initialized
INFO - 2024-12-29 01:58:07 --> Language Class Initialized
ERROR - 2024-12-29 01:58:07 --> 404 Page Not Found: Wp-admin/ajax-actions.php
INFO - 2024-12-29 01:58:07 --> Config Class Initialized
INFO - 2024-12-29 01:58:07 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:07 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:07 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:07 --> URI Class Initialized
INFO - 2024-12-29 01:58:07 --> Router Class Initialized
INFO - 2024-12-29 01:58:07 --> Output Class Initialized
INFO - 2024-12-29 01:58:07 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:07 --> Input Class Initialized
INFO - 2024-12-29 01:58:07 --> Language Class Initialized
ERROR - 2024-12-29 01:58:07 --> 404 Page Not Found: Wp-consarphp/index
INFO - 2024-12-29 01:58:08 --> Config Class Initialized
INFO - 2024-12-29 01:58:08 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:08 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:08 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:08 --> URI Class Initialized
INFO - 2024-12-29 01:58:08 --> Router Class Initialized
INFO - 2024-12-29 01:58:08 --> Output Class Initialized
INFO - 2024-12-29 01:58:08 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:08 --> Input Class Initialized
INFO - 2024-12-29 01:58:08 --> Language Class Initialized
ERROR - 2024-12-29 01:58:08 --> 404 Page Not Found: Repeaterphp/index
INFO - 2024-12-29 01:58:08 --> Config Class Initialized
INFO - 2024-12-29 01:58:08 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:08 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:08 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:08 --> URI Class Initialized
INFO - 2024-12-29 01:58:08 --> Router Class Initialized
INFO - 2024-12-29 01:58:08 --> Output Class Initialized
INFO - 2024-12-29 01:58:08 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:08 --> Input Class Initialized
INFO - 2024-12-29 01:58:08 --> Language Class Initialized
ERROR - 2024-12-29 01:58:08 --> 404 Page Not Found: Admin-postphp/index
INFO - 2024-12-29 01:58:09 --> Config Class Initialized
INFO - 2024-12-29 01:58:09 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:09 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:09 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:09 --> URI Class Initialized
INFO - 2024-12-29 01:58:09 --> Router Class Initialized
INFO - 2024-12-29 01:58:09 --> Output Class Initialized
INFO - 2024-12-29 01:58:09 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:09 --> Input Class Initialized
INFO - 2024-12-29 01:58:09 --> Language Class Initialized
ERROR - 2024-12-29 01:58:09 --> 404 Page Not Found: Wp-admin/maint
INFO - 2024-12-29 01:58:09 --> Config Class Initialized
INFO - 2024-12-29 01:58:09 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:09 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:09 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:09 --> URI Class Initialized
INFO - 2024-12-29 01:58:09 --> Router Class Initialized
INFO - 2024-12-29 01:58:09 --> Output Class Initialized
INFO - 2024-12-29 01:58:09 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:09 --> Input Class Initialized
INFO - 2024-12-29 01:58:09 --> Language Class Initialized
ERROR - 2024-12-29 01:58:09 --> 404 Page Not Found: Wp-admin/dropdown.php
INFO - 2024-12-29 01:58:10 --> Config Class Initialized
INFO - 2024-12-29 01:58:10 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:10 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:10 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:10 --> URI Class Initialized
INFO - 2024-12-29 01:58:10 --> Router Class Initialized
INFO - 2024-12-29 01:58:10 --> Output Class Initialized
INFO - 2024-12-29 01:58:10 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:10 --> Input Class Initialized
INFO - 2024-12-29 01:58:10 --> Language Class Initialized
ERROR - 2024-12-29 01:58:10 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:58:10 --> Config Class Initialized
INFO - 2024-12-29 01:58:10 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:10 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:10 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:10 --> URI Class Initialized
INFO - 2024-12-29 01:58:10 --> Router Class Initialized
INFO - 2024-12-29 01:58:10 --> Output Class Initialized
INFO - 2024-12-29 01:58:10 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:10 --> Input Class Initialized
INFO - 2024-12-29 01:58:10 --> Language Class Initialized
ERROR - 2024-12-29 01:58:10 --> 404 Page Not Found: Dropdownphp/index
INFO - 2024-12-29 01:58:11 --> Config Class Initialized
INFO - 2024-12-29 01:58:11 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:11 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:11 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:11 --> URI Class Initialized
INFO - 2024-12-29 01:58:11 --> Router Class Initialized
INFO - 2024-12-29 01:58:11 --> Output Class Initialized
INFO - 2024-12-29 01:58:11 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:11 --> Input Class Initialized
INFO - 2024-12-29 01:58:11 --> Language Class Initialized
ERROR - 2024-12-29 01:58:11 --> 404 Page Not Found: Aboutphp/index
INFO - 2024-12-29 01:58:11 --> Config Class Initialized
INFO - 2024-12-29 01:58:11 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:11 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:11 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:11 --> URI Class Initialized
INFO - 2024-12-29 01:58:11 --> Router Class Initialized
INFO - 2024-12-29 01:58:11 --> Output Class Initialized
INFO - 2024-12-29 01:58:11 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:11 --> Input Class Initialized
INFO - 2024-12-29 01:58:11 --> Language Class Initialized
ERROR - 2024-12-29 01:58:11 --> 404 Page Not Found: Adminphp/index
INFO - 2024-12-29 01:58:12 --> Config Class Initialized
INFO - 2024-12-29 01:58:12 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:12 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:12 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:12 --> URI Class Initialized
INFO - 2024-12-29 01:58:12 --> Router Class Initialized
INFO - 2024-12-29 01:58:12 --> Output Class Initialized
INFO - 2024-12-29 01:58:12 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:12 --> Input Class Initialized
INFO - 2024-12-29 01:58:12 --> Language Class Initialized
ERROR - 2024-12-29 01:58:12 --> 404 Page Not Found: Aboutphp7/index
INFO - 2024-12-29 01:58:13 --> Config Class Initialized
INFO - 2024-12-29 01:58:13 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:13 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:13 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:13 --> URI Class Initialized
INFO - 2024-12-29 01:58:13 --> Router Class Initialized
INFO - 2024-12-29 01:58:13 --> Output Class Initialized
INFO - 2024-12-29 01:58:13 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:13 --> Input Class Initialized
INFO - 2024-12-29 01:58:13 --> Language Class Initialized
ERROR - 2024-12-29 01:58:13 --> 404 Page Not Found: Alfanewphp7/index
INFO - 2024-12-29 01:58:13 --> Config Class Initialized
INFO - 2024-12-29 01:58:13 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:13 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:13 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:13 --> URI Class Initialized
INFO - 2024-12-29 01:58:14 --> Router Class Initialized
INFO - 2024-12-29 01:58:14 --> Output Class Initialized
INFO - 2024-12-29 01:58:14 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:14 --> Input Class Initialized
INFO - 2024-12-29 01:58:14 --> Language Class Initialized
ERROR - 2024-12-29 01:58:14 --> 404 Page Not Found: Adminfunsphp7/index
INFO - 2024-12-29 01:58:14 --> Config Class Initialized
INFO - 2024-12-29 01:58:14 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:14 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:14 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:14 --> URI Class Initialized
INFO - 2024-12-29 01:58:14 --> Router Class Initialized
INFO - 2024-12-29 01:58:14 --> Output Class Initialized
INFO - 2024-12-29 01:58:14 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:14 --> Input Class Initialized
INFO - 2024-12-29 01:58:14 --> Language Class Initialized
ERROR - 2024-12-29 01:58:14 --> 404 Page Not Found: Ebsphp7/index
INFO - 2024-12-29 01:58:14 --> Config Class Initialized
INFO - 2024-12-29 01:58:14 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:14 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:14 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:14 --> URI Class Initialized
INFO - 2024-12-29 01:58:14 --> Router Class Initialized
INFO - 2024-12-29 01:58:15 --> Output Class Initialized
INFO - 2024-12-29 01:58:15 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:15 --> Input Class Initialized
INFO - 2024-12-29 01:58:15 --> Language Class Initialized
ERROR - 2024-12-29 01:58:15 --> 404 Page Not Found: Wsphp7/index
INFO - 2024-12-29 01:58:15 --> Config Class Initialized
INFO - 2024-12-29 01:58:15 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:15 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:15 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:15 --> URI Class Initialized
INFO - 2024-12-29 01:58:15 --> Router Class Initialized
INFO - 2024-12-29 01:58:15 --> Output Class Initialized
INFO - 2024-12-29 01:58:15 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:15 --> Input Class Initialized
INFO - 2024-12-29 01:58:15 --> Language Class Initialized
ERROR - 2024-12-29 01:58:15 --> 404 Page Not Found: Alfanew2php7/index
INFO - 2024-12-29 01:58:16 --> Config Class Initialized
INFO - 2024-12-29 01:58:16 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:16 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:16 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:16 --> URI Class Initialized
INFO - 2024-12-29 01:58:16 --> Router Class Initialized
INFO - 2024-12-29 01:58:16 --> Output Class Initialized
INFO - 2024-12-29 01:58:16 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:16 --> Input Class Initialized
INFO - 2024-12-29 01:58:16 --> Language Class Initialized
ERROR - 2024-12-29 01:58:16 --> 404 Page Not Found: Alfa-rex2php7/index
INFO - 2024-12-29 01:58:16 --> Config Class Initialized
INFO - 2024-12-29 01:58:16 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:16 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:16 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:16 --> URI Class Initialized
INFO - 2024-12-29 01:58:16 --> Router Class Initialized
INFO - 2024-12-29 01:58:16 --> Output Class Initialized
INFO - 2024-12-29 01:58:16 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:16 --> Input Class Initialized
INFO - 2024-12-29 01:58:16 --> Language Class Initialized
ERROR - 2024-12-29 01:58:16 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:58:17 --> Config Class Initialized
INFO - 2024-12-29 01:58:17 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:17 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:17 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:17 --> URI Class Initialized
INFO - 2024-12-29 01:58:17 --> Router Class Initialized
INFO - 2024-12-29 01:58:17 --> Output Class Initialized
INFO - 2024-12-29 01:58:17 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:17 --> Input Class Initialized
INFO - 2024-12-29 01:58:17 --> Language Class Initialized
ERROR - 2024-12-29 01:58:17 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:58:17 --> Config Class Initialized
INFO - 2024-12-29 01:58:17 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:17 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:17 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:17 --> URI Class Initialized
INFO - 2024-12-29 01:58:17 --> Router Class Initialized
INFO - 2024-12-29 01:58:17 --> Output Class Initialized
INFO - 2024-12-29 01:58:17 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:17 --> Input Class Initialized
INFO - 2024-12-29 01:58:17 --> Language Class Initialized
ERROR - 2024-12-29 01:58:17 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:58:18 --> Config Class Initialized
INFO - 2024-12-29 01:58:18 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:18 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:18 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:18 --> URI Class Initialized
INFO - 2024-12-29 01:58:18 --> Router Class Initialized
INFO - 2024-12-29 01:58:18 --> Output Class Initialized
INFO - 2024-12-29 01:58:18 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:18 --> Input Class Initialized
INFO - 2024-12-29 01:58:18 --> Language Class Initialized
ERROR - 2024-12-29 01:58:18 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:58:18 --> Config Class Initialized
INFO - 2024-12-29 01:58:18 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:18 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:18 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:18 --> URI Class Initialized
INFO - 2024-12-29 01:58:18 --> Router Class Initialized
INFO - 2024-12-29 01:58:18 --> Output Class Initialized
INFO - 2024-12-29 01:58:18 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:18 --> Input Class Initialized
INFO - 2024-12-29 01:58:18 --> Language Class Initialized
ERROR - 2024-12-29 01:58:18 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:58:19 --> Config Class Initialized
INFO - 2024-12-29 01:58:19 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:19 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:19 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:19 --> URI Class Initialized
INFO - 2024-12-29 01:58:19 --> Router Class Initialized
INFO - 2024-12-29 01:58:19 --> Output Class Initialized
INFO - 2024-12-29 01:58:19 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:19 --> Input Class Initialized
INFO - 2024-12-29 01:58:19 --> Language Class Initialized
ERROR - 2024-12-29 01:58:19 --> 404 Page Not Found: Wp-content/themes
INFO - 2024-12-29 01:58:19 --> Config Class Initialized
INFO - 2024-12-29 01:58:19 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:19 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:19 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:19 --> URI Class Initialized
INFO - 2024-12-29 01:58:19 --> Router Class Initialized
INFO - 2024-12-29 01:58:19 --> Output Class Initialized
INFO - 2024-12-29 01:58:19 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:19 --> Input Class Initialized
INFO - 2024-12-29 01:58:19 --> Language Class Initialized
ERROR - 2024-12-29 01:58:19 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:58:20 --> Config Class Initialized
INFO - 2024-12-29 01:58:20 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:20 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:20 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:20 --> URI Class Initialized
INFO - 2024-12-29 01:58:20 --> Router Class Initialized
INFO - 2024-12-29 01:58:20 --> Output Class Initialized
INFO - 2024-12-29 01:58:20 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:20 --> Input Class Initialized
INFO - 2024-12-29 01:58:20 --> Language Class Initialized
ERROR - 2024-12-29 01:58:20 --> 404 Page Not Found: Wp-content/plugins
INFO - 2024-12-29 01:58:20 --> Config Class Initialized
INFO - 2024-12-29 01:58:20 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:20 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:20 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:20 --> URI Class Initialized
INFO - 2024-12-29 01:58:20 --> Router Class Initialized
INFO - 2024-12-29 01:58:20 --> Output Class Initialized
INFO - 2024-12-29 01:58:20 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:20 --> Input Class Initialized
INFO - 2024-12-29 01:58:21 --> Language Class Initialized
ERROR - 2024-12-29 01:58:21 --> 404 Page Not Found: Well-known/pki-validation
INFO - 2024-12-29 01:58:21 --> Config Class Initialized
INFO - 2024-12-29 01:58:21 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:21 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:21 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:21 --> URI Class Initialized
INFO - 2024-12-29 01:58:21 --> Router Class Initialized
INFO - 2024-12-29 01:58:21 --> Output Class Initialized
INFO - 2024-12-29 01:58:21 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:21 --> Input Class Initialized
INFO - 2024-12-29 01:58:21 --> Language Class Initialized
ERROR - 2024-12-29 01:58:21 --> 404 Page Not Found: Wp-admin/network
INFO - 2024-12-29 01:58:22 --> Config Class Initialized
INFO - 2024-12-29 01:58:22 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:22 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:22 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:22 --> URI Class Initialized
INFO - 2024-12-29 01:58:22 --> Router Class Initialized
INFO - 2024-12-29 01:58:22 --> Output Class Initialized
INFO - 2024-12-29 01:58:22 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:22 --> Input Class Initialized
INFO - 2024-12-29 01:58:22 --> Language Class Initialized
ERROR - 2024-12-29 01:58:22 --> 404 Page Not Found: Xmrlpcphp/index
INFO - 2024-12-29 01:58:22 --> Config Class Initialized
INFO - 2024-12-29 01:58:22 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:22 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:22 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:22 --> URI Class Initialized
INFO - 2024-12-29 01:58:22 --> Router Class Initialized
INFO - 2024-12-29 01:58:22 --> Output Class Initialized
INFO - 2024-12-29 01:58:22 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:22 --> Input Class Initialized
INFO - 2024-12-29 01:58:22 --> Language Class Initialized
ERROR - 2024-12-29 01:58:22 --> 404 Page Not Found: Cgi-bin/xmrlpc.php
INFO - 2024-12-29 01:58:23 --> Config Class Initialized
INFO - 2024-12-29 01:58:23 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:23 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:23 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:23 --> URI Class Initialized
INFO - 2024-12-29 01:58:23 --> Router Class Initialized
INFO - 2024-12-29 01:58:23 --> Output Class Initialized
INFO - 2024-12-29 01:58:23 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:23 --> Input Class Initialized
INFO - 2024-12-29 01:58:23 --> Language Class Initialized
ERROR - 2024-12-29 01:58:23 --> 404 Page Not Found: Css/xmrlpc.php
INFO - 2024-12-29 01:58:23 --> Config Class Initialized
INFO - 2024-12-29 01:58:23 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:23 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:23 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:23 --> URI Class Initialized
INFO - 2024-12-29 01:58:23 --> Router Class Initialized
INFO - 2024-12-29 01:58:23 --> Output Class Initialized
INFO - 2024-12-29 01:58:23 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:23 --> Input Class Initialized
INFO - 2024-12-29 01:58:23 --> Language Class Initialized
ERROR - 2024-12-29 01:58:23 --> 404 Page Not Found: Wp-admin/user
INFO - 2024-12-29 01:58:24 --> Config Class Initialized
INFO - 2024-12-29 01:58:24 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:24 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:24 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:24 --> URI Class Initialized
INFO - 2024-12-29 01:58:24 --> Router Class Initialized
INFO - 2024-12-29 01:58:24 --> Output Class Initialized
INFO - 2024-12-29 01:58:24 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:24 --> Input Class Initialized
INFO - 2024-12-29 01:58:24 --> Language Class Initialized
ERROR - 2024-12-29 01:58:24 --> 404 Page Not Found: Img/xmrlpc.php
INFO - 2024-12-29 01:58:24 --> Config Class Initialized
INFO - 2024-12-29 01:58:24 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:24 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:24 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:24 --> URI Class Initialized
INFO - 2024-12-29 01:58:24 --> Router Class Initialized
INFO - 2024-12-29 01:58:24 --> Output Class Initialized
INFO - 2024-12-29 01:58:24 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:24 --> Input Class Initialized
INFO - 2024-12-29 01:58:24 --> Language Class Initialized
ERROR - 2024-12-29 01:58:24 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:58:25 --> Config Class Initialized
INFO - 2024-12-29 01:58:25 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:25 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:25 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:25 --> URI Class Initialized
INFO - 2024-12-29 01:58:25 --> Router Class Initialized
INFO - 2024-12-29 01:58:25 --> Output Class Initialized
INFO - 2024-12-29 01:58:25 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:25 --> Input Class Initialized
INFO - 2024-12-29 01:58:25 --> Language Class Initialized
ERROR - 2024-12-29 01:58:25 --> 404 Page Not Found: Wp-admin/images
INFO - 2024-12-29 01:58:25 --> Config Class Initialized
INFO - 2024-12-29 01:58:25 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:25 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:25 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:25 --> URI Class Initialized
INFO - 2024-12-29 01:58:25 --> Router Class Initialized
INFO - 2024-12-29 01:58:25 --> Output Class Initialized
INFO - 2024-12-29 01:58:25 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:25 --> Input Class Initialized
INFO - 2024-12-29 01:58:25 --> Language Class Initialized
ERROR - 2024-12-29 01:58:25 --> 404 Page Not Found: Images/xmrlpc.php
INFO - 2024-12-29 01:58:26 --> Config Class Initialized
INFO - 2024-12-29 01:58:26 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:26 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:26 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:26 --> URI Class Initialized
INFO - 2024-12-29 01:58:26 --> Router Class Initialized
INFO - 2024-12-29 01:58:26 --> Output Class Initialized
INFO - 2024-12-29 01:58:26 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:26 --> Input Class Initialized
INFO - 2024-12-29 01:58:26 --> Language Class Initialized
ERROR - 2024-12-29 01:58:26 --> 404 Page Not Found: Wp-admin/js
INFO - 2024-12-29 01:58:27 --> Config Class Initialized
INFO - 2024-12-29 01:58:27 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:27 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:27 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:27 --> URI Class Initialized
INFO - 2024-12-29 01:58:27 --> Router Class Initialized
INFO - 2024-12-29 01:58:27 --> Output Class Initialized
INFO - 2024-12-29 01:58:27 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:27 --> Input Class Initialized
INFO - 2024-12-29 01:58:27 --> Language Class Initialized
ERROR - 2024-12-29 01:58:27 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:58:27 --> Config Class Initialized
INFO - 2024-12-29 01:58:27 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:27 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:27 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:27 --> URI Class Initialized
INFO - 2024-12-29 01:58:27 --> Router Class Initialized
INFO - 2024-12-29 01:58:27 --> Output Class Initialized
INFO - 2024-12-29 01:58:27 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:27 --> Input Class Initialized
INFO - 2024-12-29 01:58:27 --> Language Class Initialized
ERROR - 2024-12-29 01:58:27 --> 404 Page Not Found: Wp-admin/includes
INFO - 2024-12-29 01:58:28 --> Config Class Initialized
INFO - 2024-12-29 01:58:28 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:28 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:28 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:28 --> URI Class Initialized
INFO - 2024-12-29 01:58:28 --> Router Class Initialized
INFO - 2024-12-29 01:58:28 --> Output Class Initialized
INFO - 2024-12-29 01:58:28 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:28 --> Input Class Initialized
INFO - 2024-12-29 01:58:28 --> Language Class Initialized
ERROR - 2024-12-29 01:58:28 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 01:58:28 --> Config Class Initialized
INFO - 2024-12-29 01:58:28 --> Hooks Class Initialized
DEBUG - 2024-12-29 01:58:28 --> UTF-8 Support Enabled
INFO - 2024-12-29 01:58:28 --> Utf8 Class Initialized
INFO - 2024-12-29 01:58:28 --> URI Class Initialized
INFO - 2024-12-29 01:58:28 --> Router Class Initialized
INFO - 2024-12-29 01:58:28 --> Output Class Initialized
INFO - 2024-12-29 01:58:28 --> Security Class Initialized
DEBUG - 2024-12-29 01:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 01:58:28 --> Input Class Initialized
INFO - 2024-12-29 01:58:28 --> Language Class Initialized
ERROR - 2024-12-29 01:58:28 --> 404 Page Not Found: Wp-admin/xmrlpc.php
INFO - 2024-12-29 17:45:22 --> Config Class Initialized
INFO - 2024-12-29 17:45:22 --> Hooks Class Initialized
DEBUG - 2024-12-29 17:45:22 --> UTF-8 Support Enabled
INFO - 2024-12-29 17:45:22 --> Utf8 Class Initialized
INFO - 2024-12-29 17:45:22 --> URI Class Initialized
DEBUG - 2024-12-29 17:45:22 --> No URI present. Default controller set.
INFO - 2024-12-29 17:45:22 --> Router Class Initialized
INFO - 2024-12-29 17:45:22 --> Output Class Initialized
INFO - 2024-12-29 17:45:22 --> Security Class Initialized
DEBUG - 2024-12-29 17:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 17:45:22 --> Input Class Initialized
INFO - 2024-12-29 17:45:22 --> Language Class Initialized
INFO - 2024-12-29 17:45:22 --> Loader Class Initialized
INFO - 2024-12-29 17:45:22 --> Helper loaded: url_helper
INFO - 2024-12-29 17:45:22 --> Helper loaded: html_helper
INFO - 2024-12-29 17:45:22 --> Helper loaded: file_helper
INFO - 2024-12-29 17:45:22 --> Helper loaded: string_helper
INFO - 2024-12-29 17:45:22 --> Helper loaded: form_helper
INFO - 2024-12-29 17:45:22 --> Helper loaded: my_helper
INFO - 2024-12-29 17:45:22 --> Database Driver Class Initialized
INFO - 2024-12-29 17:45:24 --> Upload Class Initialized
INFO - 2024-12-29 17:45:24 --> Email Class Initialized
INFO - 2024-12-29 17:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-29 17:45:24 --> Form Validation Class Initialized
INFO - 2024-12-29 17:45:24 --> Controller Class Initialized
INFO - 2024-12-29 23:15:25 --> Model "MainModel" initialized
INFO - 2024-12-29 23:15:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-29 23:15:25 --> Final output sent to browser
DEBUG - 2024-12-29 23:15:25 --> Total execution time: 2.8575
INFO - 2024-12-29 20:04:15 --> Config Class Initialized
INFO - 2024-12-29 20:04:15 --> Hooks Class Initialized
DEBUG - 2024-12-29 20:04:15 --> UTF-8 Support Enabled
INFO - 2024-12-29 20:04:15 --> Utf8 Class Initialized
INFO - 2024-12-29 20:04:15 --> URI Class Initialized
INFO - 2024-12-29 20:04:15 --> Router Class Initialized
INFO - 2024-12-29 20:04:15 --> Output Class Initialized
INFO - 2024-12-29 20:04:15 --> Security Class Initialized
DEBUG - 2024-12-29 20:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 20:04:15 --> Input Class Initialized
INFO - 2024-12-29 20:04:15 --> Language Class Initialized
ERROR - 2024-12-29 20:04:15 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-29 20:04:17 --> Config Class Initialized
INFO - 2024-12-29 20:04:17 --> Hooks Class Initialized
DEBUG - 2024-12-29 20:04:17 --> UTF-8 Support Enabled
INFO - 2024-12-29 20:04:17 --> Utf8 Class Initialized
INFO - 2024-12-29 20:04:17 --> URI Class Initialized
INFO - 2024-12-29 20:04:17 --> Router Class Initialized
INFO - 2024-12-29 20:04:17 --> Output Class Initialized
INFO - 2024-12-29 20:04:17 --> Security Class Initialized
DEBUG - 2024-12-29 20:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 20:04:17 --> Input Class Initialized
INFO - 2024-12-29 20:04:17 --> Language Class Initialized
ERROR - 2024-12-29 20:04:17 --> 404 Page Not Found: Well-known/index
INFO - 2024-12-29 20:04:18 --> Config Class Initialized
INFO - 2024-12-29 20:04:18 --> Hooks Class Initialized
DEBUG - 2024-12-29 20:04:18 --> UTF-8 Support Enabled
INFO - 2024-12-29 20:04:18 --> Utf8 Class Initialized
INFO - 2024-12-29 20:04:18 --> URI Class Initialized
INFO - 2024-12-29 20:04:18 --> Router Class Initialized
INFO - 2024-12-29 20:04:18 --> Output Class Initialized
INFO - 2024-12-29 20:04:18 --> Security Class Initialized
DEBUG - 2024-12-29 20:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 20:04:18 --> Input Class Initialized
INFO - 2024-12-29 20:04:18 --> Language Class Initialized
ERROR - 2024-12-29 20:04:18 --> 404 Page Not Found: Sites/default
INFO - 2024-12-29 20:04:20 --> Config Class Initialized
INFO - 2024-12-29 20:04:20 --> Hooks Class Initialized
DEBUG - 2024-12-29 20:04:20 --> UTF-8 Support Enabled
INFO - 2024-12-29 20:04:20 --> Utf8 Class Initialized
INFO - 2024-12-29 20:04:20 --> URI Class Initialized
INFO - 2024-12-29 20:04:20 --> Router Class Initialized
INFO - 2024-12-29 20:04:20 --> Output Class Initialized
INFO - 2024-12-29 20:04:20 --> Security Class Initialized
DEBUG - 2024-12-29 20:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 20:04:20 --> Input Class Initialized
INFO - 2024-12-29 20:04:20 --> Language Class Initialized
ERROR - 2024-12-29 20:04:20 --> 404 Page Not Found: Admin/controller
INFO - 2024-12-29 20:04:22 --> Config Class Initialized
INFO - 2024-12-29 20:04:22 --> Hooks Class Initialized
DEBUG - 2024-12-29 20:04:22 --> UTF-8 Support Enabled
INFO - 2024-12-29 20:04:22 --> Utf8 Class Initialized
INFO - 2024-12-29 20:04:22 --> URI Class Initialized
INFO - 2024-12-29 20:04:22 --> Router Class Initialized
INFO - 2024-12-29 20:04:22 --> Output Class Initialized
INFO - 2024-12-29 20:04:22 --> Security Class Initialized
DEBUG - 2024-12-29 20:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 20:04:22 --> Input Class Initialized
INFO - 2024-12-29 20:04:22 --> Language Class Initialized
ERROR - 2024-12-29 20:04:22 --> 404 Page Not Found: Uploads/index
INFO - 2024-12-29 20:04:24 --> Config Class Initialized
INFO - 2024-12-29 20:04:24 --> Hooks Class Initialized
DEBUG - 2024-12-29 20:04:24 --> UTF-8 Support Enabled
INFO - 2024-12-29 20:04:24 --> Utf8 Class Initialized
INFO - 2024-12-29 20:04:24 --> URI Class Initialized
INFO - 2024-12-29 20:04:24 --> Router Class Initialized
INFO - 2024-12-29 20:04:24 --> Output Class Initialized
INFO - 2024-12-29 20:04:24 --> Security Class Initialized
DEBUG - 2024-12-29 20:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 20:04:24 --> Input Class Initialized
INFO - 2024-12-29 20:04:24 --> Language Class Initialized
ERROR - 2024-12-29 20:04:24 --> 404 Page Not Found: Images/index
INFO - 2024-12-29 20:04:25 --> Config Class Initialized
INFO - 2024-12-29 20:04:25 --> Hooks Class Initialized
DEBUG - 2024-12-29 20:04:25 --> UTF-8 Support Enabled
INFO - 2024-12-29 20:04:25 --> Utf8 Class Initialized
INFO - 2024-12-29 20:04:25 --> URI Class Initialized
INFO - 2024-12-29 20:04:25 --> Router Class Initialized
INFO - 2024-12-29 20:04:25 --> Output Class Initialized
INFO - 2024-12-29 20:04:25 --> Security Class Initialized
DEBUG - 2024-12-29 20:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-29 20:04:25 --> Input Class Initialized
INFO - 2024-12-29 20:04:25 --> Language Class Initialized
ERROR - 2024-12-29 20:04:25 --> 404 Page Not Found: Files/index
