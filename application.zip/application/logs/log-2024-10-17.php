<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-17 03:03:49 --> Config Class Initialized
INFO - 2024-10-17 03:03:49 --> Hooks Class Initialized
DEBUG - 2024-10-17 03:03:49 --> UTF-8 Support Enabled
INFO - 2024-10-17 03:03:49 --> Utf8 Class Initialized
INFO - 2024-10-17 03:03:49 --> URI Class Initialized
DEBUG - 2024-10-17 03:03:49 --> No URI present. Default controller set.
INFO - 2024-10-17 03:03:49 --> Router Class Initialized
INFO - 2024-10-17 03:03:49 --> Output Class Initialized
INFO - 2024-10-17 03:03:49 --> Security Class Initialized
DEBUG - 2024-10-17 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-17 03:03:49 --> Input Class Initialized
INFO - 2024-10-17 03:03:49 --> Language Class Initialized
INFO - 2024-10-17 03:03:49 --> Loader Class Initialized
INFO - 2024-10-17 03:03:49 --> Helper loaded: url_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: html_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: file_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: string_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: form_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: my_helper
INFO - 2024-10-17 03:03:49 --> Database Driver Class Initialized
INFO - 2024-10-17 03:03:49 --> Config Class Initialized
INFO - 2024-10-17 03:03:49 --> Hooks Class Initialized
DEBUG - 2024-10-17 03:03:49 --> UTF-8 Support Enabled
INFO - 2024-10-17 03:03:49 --> Utf8 Class Initialized
INFO - 2024-10-17 03:03:49 --> URI Class Initialized
DEBUG - 2024-10-17 03:03:49 --> No URI present. Default controller set.
INFO - 2024-10-17 03:03:49 --> Router Class Initialized
INFO - 2024-10-17 03:03:49 --> Output Class Initialized
INFO - 2024-10-17 03:03:49 --> Security Class Initialized
DEBUG - 2024-10-17 03:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-17 03:03:49 --> Input Class Initialized
INFO - 2024-10-17 03:03:49 --> Language Class Initialized
INFO - 2024-10-17 03:03:49 --> Loader Class Initialized
INFO - 2024-10-17 03:03:49 --> Helper loaded: url_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: html_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: file_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: string_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: form_helper
INFO - 2024-10-17 03:03:49 --> Helper loaded: my_helper
INFO - 2024-10-17 03:03:49 --> Database Driver Class Initialized
INFO - 2024-10-17 03:03:51 --> Upload Class Initialized
INFO - 2024-10-17 03:03:51 --> Email Class Initialized
INFO - 2024-10-17 03:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-17 03:03:51 --> Form Validation Class Initialized
INFO - 2024-10-17 03:03:51 --> Controller Class Initialized
INFO - 2024-10-17 08:33:51 --> Model "MainModel" initialized
INFO - 2024-10-17 08:33:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-17 08:33:51 --> Final output sent to browser
DEBUG - 2024-10-17 08:33:51 --> Total execution time: 2.2260
INFO - 2024-10-17 03:03:51 --> Upload Class Initialized
INFO - 2024-10-17 03:03:51 --> Email Class Initialized
INFO - 2024-10-17 03:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-17 03:03:51 --> Form Validation Class Initialized
INFO - 2024-10-17 03:03:51 --> Controller Class Initialized
INFO - 2024-10-17 08:33:51 --> Model "MainModel" initialized
INFO - 2024-10-17 08:33:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-17 08:33:51 --> Final output sent to browser
DEBUG - 2024-10-17 08:33:51 --> Total execution time: 2.1347
INFO - 2024-10-17 05:37:07 --> Config Class Initialized
INFO - 2024-10-17 05:37:07 --> Hooks Class Initialized
DEBUG - 2024-10-17 05:37:07 --> UTF-8 Support Enabled
INFO - 2024-10-17 05:37:07 --> Utf8 Class Initialized
INFO - 2024-10-17 05:37:07 --> URI Class Initialized
INFO - 2024-10-17 05:37:07 --> Config Class Initialized
INFO - 2024-10-17 05:37:07 --> Hooks Class Initialized
DEBUG - 2024-10-17 05:37:07 --> UTF-8 Support Enabled
INFO - 2024-10-17 05:37:07 --> Utf8 Class Initialized
INFO - 2024-10-17 05:37:07 --> Router Class Initialized
INFO - 2024-10-17 05:37:07 --> URI Class Initialized
INFO - 2024-10-17 05:37:07 --> Router Class Initialized
INFO - 2024-10-17 05:37:07 --> Output Class Initialized
INFO - 2024-10-17 05:37:07 --> Output Class Initialized
INFO - 2024-10-17 05:37:07 --> Security Class Initialized
INFO - 2024-10-17 05:37:07 --> Security Class Initialized
DEBUG - 2024-10-17 05:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-17 05:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-17 05:37:07 --> Input Class Initialized
INFO - 2024-10-17 05:37:07 --> Input Class Initialized
INFO - 2024-10-17 05:37:07 --> Language Class Initialized
INFO - 2024-10-17 05:37:07 --> Language Class Initialized
INFO - 2024-10-17 05:37:07 --> Loader Class Initialized
INFO - 2024-10-17 05:37:07 --> Loader Class Initialized
INFO - 2024-10-17 05:37:07 --> Helper loaded: url_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: url_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: html_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: html_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: file_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: file_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: string_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: string_helper
INFO - 2024-10-17 05:37:07 --> Helper loaded: form_helper
INFO - 2024-10-17 05:37:08 --> Helper loaded: form_helper
INFO - 2024-10-17 05:37:08 --> Helper loaded: my_helper
INFO - 2024-10-17 05:37:08 --> Helper loaded: my_helper
INFO - 2024-10-17 05:37:08 --> Database Driver Class Initialized
INFO - 2024-10-17 05:37:08 --> Database Driver Class Initialized
INFO - 2024-10-17 05:37:10 --> Upload Class Initialized
INFO - 2024-10-17 05:37:10 --> Upload Class Initialized
INFO - 2024-10-17 05:37:10 --> Email Class Initialized
INFO - 2024-10-17 05:37:10 --> Email Class Initialized
INFO - 2024-10-17 05:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-17 05:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-17 05:37:10 --> Form Validation Class Initialized
INFO - 2024-10-17 05:37:10 --> Form Validation Class Initialized
INFO - 2024-10-17 05:37:10 --> Controller Class Initialized
INFO - 2024-10-17 05:37:10 --> Controller Class Initialized
INFO - 2024-10-17 11:07:10 --> Model "MainModel" initialized
INFO - 2024-10-17 11:07:10 --> Model "SuperAdminModel" initialized
INFO - 2024-10-17 11:07:10 --> Helper loaded: notification_helper
INFO - 2024-10-17 11:07:10 --> Model "FrontofficeModel" initialized
INFO - 2024-10-17 11:07:10 --> Model "MainModel" initialized
INFO - 2024-10-17 11:07:10 --> Model "HotelAdminModel" initialized
INFO - 2024-10-17 11:07:10 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-17 11:07:10 --> Model "FoodAdminModel" initialized
INFO - 2024-10-17 11:07:10 --> Model "SuperAdminModel" initialized
INFO - 2024-10-17 11:07:10 --> Helper loaded: notification_helper
INFO - 2024-10-17 11:07:10 --> Helper loaded: array_helper
INFO - 2024-10-17 08:30:13 --> Config Class Initialized
INFO - 2024-10-17 08:30:13 --> Hooks Class Initialized
DEBUG - 2024-10-17 08:30:13 --> UTF-8 Support Enabled
INFO - 2024-10-17 08:30:13 --> Utf8 Class Initialized
INFO - 2024-10-17 08:30:13 --> URI Class Initialized
DEBUG - 2024-10-17 08:30:13 --> No URI present. Default controller set.
INFO - 2024-10-17 08:30:13 --> Router Class Initialized
INFO - 2024-10-17 08:30:13 --> Output Class Initialized
INFO - 2024-10-17 08:30:13 --> Security Class Initialized
DEBUG - 2024-10-17 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-17 08:30:13 --> Input Class Initialized
INFO - 2024-10-17 08:30:13 --> Language Class Initialized
INFO - 2024-10-17 08:30:13 --> Loader Class Initialized
INFO - 2024-10-17 08:30:13 --> Helper loaded: url_helper
INFO - 2024-10-17 08:30:13 --> Helper loaded: html_helper
INFO - 2024-10-17 08:30:13 --> Helper loaded: file_helper
INFO - 2024-10-17 08:30:13 --> Helper loaded: string_helper
INFO - 2024-10-17 08:30:13 --> Helper loaded: form_helper
INFO - 2024-10-17 08:30:13 --> Helper loaded: my_helper
INFO - 2024-10-17 08:30:13 --> Database Driver Class Initialized
INFO - 2024-10-17 08:30:15 --> Upload Class Initialized
INFO - 2024-10-17 08:30:15 --> Email Class Initialized
INFO - 2024-10-17 08:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-17 08:30:15 --> Form Validation Class Initialized
INFO - 2024-10-17 08:30:15 --> Controller Class Initialized
INFO - 2024-10-17 14:00:15 --> Model "MainModel" initialized
INFO - 2024-10-17 14:00:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-17 14:00:15 --> Final output sent to browser
DEBUG - 2024-10-17 14:00:15 --> Total execution time: 2.2528
