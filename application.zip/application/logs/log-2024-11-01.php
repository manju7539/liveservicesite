<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-01 04:13:24 --> Model "MainModel" initialized
INFO - 2024-11-01 04:13:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-01 04:13:24 --> Final output sent to browser
DEBUG - 2024-11-01 04:13:24 --> Total execution time: 2.2722
INFO - 2024-11-01 10:36:55 --> Config Class Initialized
INFO - 2024-11-01 10:36:55 --> Hooks Class Initialized
DEBUG - 2024-11-01 10:36:55 --> UTF-8 Support Enabled
INFO - 2024-11-01 10:36:55 --> Utf8 Class Initialized
INFO - 2024-11-01 10:36:55 --> URI Class Initialized
DEBUG - 2024-11-01 10:36:55 --> No URI present. Default controller set.
INFO - 2024-11-01 10:36:55 --> Router Class Initialized
INFO - 2024-11-01 10:36:55 --> Output Class Initialized
INFO - 2024-11-01 10:36:55 --> Security Class Initialized
DEBUG - 2024-11-01 10:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 10:36:55 --> Input Class Initialized
INFO - 2024-11-01 10:36:55 --> Language Class Initialized
INFO - 2024-11-01 10:36:55 --> Loader Class Initialized
INFO - 2024-11-01 10:36:55 --> Helper loaded: url_helper
INFO - 2024-11-01 10:36:55 --> Helper loaded: html_helper
INFO - 2024-11-01 10:36:55 --> Helper loaded: file_helper
INFO - 2024-11-01 10:36:55 --> Helper loaded: string_helper
INFO - 2024-11-01 10:36:55 --> Helper loaded: form_helper
INFO - 2024-11-01 10:36:55 --> Helper loaded: my_helper
INFO - 2024-11-01 10:36:55 --> Database Driver Class Initialized
INFO - 2024-11-01 10:36:58 --> Upload Class Initialized
INFO - 2024-11-01 10:36:58 --> Email Class Initialized
INFO - 2024-11-01 10:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 10:36:58 --> Form Validation Class Initialized
INFO - 2024-11-01 10:36:58 --> Controller Class Initialized
INFO - 2024-11-01 16:06:58 --> Model "MainModel" initialized
INFO - 2024-11-01 16:06:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-01 16:06:58 --> Final output sent to browser
DEBUG - 2024-11-01 16:06:58 --> Total execution time: 2.8028
INFO - 2024-11-01 10:39:35 --> Config Class Initialized
INFO - 2024-11-01 10:39:35 --> Hooks Class Initialized
DEBUG - 2024-11-01 10:39:35 --> UTF-8 Support Enabled
INFO - 2024-11-01 10:39:35 --> Utf8 Class Initialized
INFO - 2024-11-01 10:39:35 --> URI Class Initialized
DEBUG - 2024-11-01 10:39:35 --> No URI present. Default controller set.
INFO - 2024-11-01 10:39:35 --> Router Class Initialized
INFO - 2024-11-01 10:39:35 --> Output Class Initialized
INFO - 2024-11-01 10:39:35 --> Security Class Initialized
DEBUG - 2024-11-01 10:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 10:39:35 --> Input Class Initialized
INFO - 2024-11-01 10:39:35 --> Language Class Initialized
INFO - 2024-11-01 10:39:35 --> Loader Class Initialized
INFO - 2024-11-01 10:39:35 --> Helper loaded: url_helper
INFO - 2024-11-01 10:39:35 --> Helper loaded: html_helper
INFO - 2024-11-01 10:39:35 --> Helper loaded: file_helper
INFO - 2024-11-01 10:39:35 --> Helper loaded: string_helper
INFO - 2024-11-01 10:39:35 --> Helper loaded: form_helper
INFO - 2024-11-01 10:39:35 --> Helper loaded: my_helper
INFO - 2024-11-01 10:39:35 --> Database Driver Class Initialized
INFO - 2024-11-01 10:39:37 --> Upload Class Initialized
INFO - 2024-11-01 10:39:37 --> Email Class Initialized
INFO - 2024-11-01 10:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 10:39:37 --> Form Validation Class Initialized
INFO - 2024-11-01 10:39:37 --> Controller Class Initialized
INFO - 2024-11-01 16:09:37 --> Model "MainModel" initialized
INFO - 2024-11-01 16:09:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-01 16:09:37 --> Final output sent to browser
DEBUG - 2024-11-01 16:09:37 --> Total execution time: 2.1602
INFO - 2024-11-01 10:43:32 --> Config Class Initialized
INFO - 2024-11-01 10:43:32 --> Hooks Class Initialized
DEBUG - 2024-11-01 10:43:32 --> UTF-8 Support Enabled
INFO - 2024-11-01 10:43:32 --> Utf8 Class Initialized
INFO - 2024-11-01 10:43:32 --> URI Class Initialized
DEBUG - 2024-11-01 10:43:32 --> No URI present. Default controller set.
INFO - 2024-11-01 10:43:32 --> Router Class Initialized
INFO - 2024-11-01 10:43:32 --> Output Class Initialized
INFO - 2024-11-01 10:43:32 --> Security Class Initialized
DEBUG - 2024-11-01 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 10:43:32 --> Input Class Initialized
INFO - 2024-11-01 10:43:32 --> Language Class Initialized
INFO - 2024-11-01 10:43:32 --> Loader Class Initialized
INFO - 2024-11-01 10:43:32 --> Helper loaded: url_helper
INFO - 2024-11-01 10:43:32 --> Helper loaded: html_helper
INFO - 2024-11-01 10:43:32 --> Helper loaded: file_helper
INFO - 2024-11-01 10:43:32 --> Helper loaded: string_helper
INFO - 2024-11-01 10:43:32 --> Helper loaded: form_helper
INFO - 2024-11-01 10:43:32 --> Helper loaded: my_helper
INFO - 2024-11-01 10:43:32 --> Database Driver Class Initialized
INFO - 2024-11-01 10:43:34 --> Upload Class Initialized
INFO - 2024-11-01 10:43:34 --> Email Class Initialized
INFO - 2024-11-01 10:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 10:43:34 --> Form Validation Class Initialized
INFO - 2024-11-01 10:43:34 --> Controller Class Initialized
INFO - 2024-11-01 16:13:34 --> Model "MainModel" initialized
INFO - 2024-11-01 16:13:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-01 16:13:34 --> Final output sent to browser
DEBUG - 2024-11-01 16:13:34 --> Total execution time: 2.1324
INFO - 2024-11-01 17:17:56 --> Config Class Initialized
INFO - 2024-11-01 17:17:56 --> Hooks Class Initialized
DEBUG - 2024-11-01 17:17:56 --> UTF-8 Support Enabled
INFO - 2024-11-01 17:17:56 --> Utf8 Class Initialized
INFO - 2024-11-01 17:17:56 --> URI Class Initialized
DEBUG - 2024-11-01 17:17:56 --> No URI present. Default controller set.
INFO - 2024-11-01 17:17:56 --> Router Class Initialized
INFO - 2024-11-01 17:17:56 --> Output Class Initialized
INFO - 2024-11-01 17:17:56 --> Security Class Initialized
DEBUG - 2024-11-01 17:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 17:17:56 --> Input Class Initialized
INFO - 2024-11-01 17:17:56 --> Language Class Initialized
INFO - 2024-11-01 17:17:56 --> Loader Class Initialized
INFO - 2024-11-01 17:17:56 --> Helper loaded: url_helper
INFO - 2024-11-01 17:17:56 --> Helper loaded: html_helper
INFO - 2024-11-01 17:17:56 --> Helper loaded: file_helper
INFO - 2024-11-01 17:17:56 --> Helper loaded: string_helper
INFO - 2024-11-01 17:17:56 --> Helper loaded: form_helper
INFO - 2024-11-01 17:17:56 --> Helper loaded: my_helper
INFO - 2024-11-01 17:17:56 --> Database Driver Class Initialized
INFO - 2024-11-01 17:17:58 --> Upload Class Initialized
INFO - 2024-11-01 17:17:58 --> Email Class Initialized
INFO - 2024-11-01 17:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 17:17:58 --> Form Validation Class Initialized
INFO - 2024-11-01 17:17:58 --> Controller Class Initialized
INFO - 2024-11-01 22:47:58 --> Model "MainModel" initialized
INFO - 2024-11-01 22:47:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-01 22:47:58 --> Final output sent to browser
DEBUG - 2024-11-01 22:47:58 --> Total execution time: 2.4298
