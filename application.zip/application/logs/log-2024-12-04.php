<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-04 12:42:58 --> Config Class Initialized
INFO - 2024-12-04 12:42:58 --> Hooks Class Initialized
DEBUG - 2024-12-04 12:42:58 --> UTF-8 Support Enabled
INFO - 2024-12-04 12:42:58 --> Utf8 Class Initialized
INFO - 2024-12-04 12:42:58 --> URI Class Initialized
DEBUG - 2024-12-04 12:42:58 --> No URI present. Default controller set.
INFO - 2024-12-04 12:42:58 --> Router Class Initialized
INFO - 2024-12-04 12:42:58 --> Output Class Initialized
INFO - 2024-12-04 12:42:59 --> Security Class Initialized
DEBUG - 2024-12-04 12:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 12:42:59 --> Input Class Initialized
INFO - 2024-12-04 12:42:59 --> Language Class Initialized
INFO - 2024-12-04 12:42:59 --> Loader Class Initialized
INFO - 2024-12-04 12:42:59 --> Helper loaded: url_helper
INFO - 2024-12-04 12:42:59 --> Helper loaded: html_helper
INFO - 2024-12-04 12:42:59 --> Helper loaded: file_helper
INFO - 2024-12-04 12:42:59 --> Helper loaded: string_helper
INFO - 2024-12-04 12:42:59 --> Helper loaded: form_helper
INFO - 2024-12-04 12:42:59 --> Helper loaded: my_helper
INFO - 2024-12-04 12:42:59 --> Database Driver Class Initialized
INFO - 2024-12-04 12:43:01 --> Upload Class Initialized
INFO - 2024-12-04 12:43:01 --> Email Class Initialized
INFO - 2024-12-04 12:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 12:43:01 --> Form Validation Class Initialized
INFO - 2024-12-04 12:43:01 --> Controller Class Initialized
INFO - 2024-12-04 18:13:01 --> Model "MainModel" initialized
INFO - 2024-12-04 18:13:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-04 18:13:01 --> Final output sent to browser
DEBUG - 2024-12-04 18:13:01 --> Total execution time: 3.4802
INFO - 2024-12-04 15:04:15 --> Config Class Initialized
INFO - 2024-12-04 15:04:15 --> Hooks Class Initialized
DEBUG - 2024-12-04 15:04:15 --> UTF-8 Support Enabled
INFO - 2024-12-04 15:04:15 --> Utf8 Class Initialized
INFO - 2024-12-04 15:04:15 --> URI Class Initialized
DEBUG - 2024-12-04 15:04:15 --> No URI present. Default controller set.
INFO - 2024-12-04 15:04:15 --> Router Class Initialized
INFO - 2024-12-04 15:04:15 --> Output Class Initialized
INFO - 2024-12-04 15:04:15 --> Security Class Initialized
DEBUG - 2024-12-04 15:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 15:04:15 --> Input Class Initialized
INFO - 2024-12-04 15:04:15 --> Language Class Initialized
INFO - 2024-12-04 15:04:15 --> Loader Class Initialized
INFO - 2024-12-04 15:04:15 --> Helper loaded: url_helper
INFO - 2024-12-04 15:04:15 --> Helper loaded: html_helper
INFO - 2024-12-04 15:04:15 --> Helper loaded: file_helper
INFO - 2024-12-04 15:04:15 --> Helper loaded: string_helper
INFO - 2024-12-04 15:04:15 --> Helper loaded: form_helper
INFO - 2024-12-04 15:04:15 --> Helper loaded: my_helper
INFO - 2024-12-04 15:04:15 --> Database Driver Class Initialized
INFO - 2024-12-04 15:04:17 --> Upload Class Initialized
INFO - 2024-12-04 15:04:17 --> Email Class Initialized
INFO - 2024-12-04 15:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 15:04:17 --> Form Validation Class Initialized
INFO - 2024-12-04 15:04:17 --> Controller Class Initialized
INFO - 2024-12-04 20:34:17 --> Model "MainModel" initialized
INFO - 2024-12-04 20:34:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-04 20:34:17 --> Final output sent to browser
DEBUG - 2024-12-04 20:34:17 --> Total execution time: 2.2442
INFO - 2024-12-04 15:04:21 --> Config Class Initialized
INFO - 2024-12-04 15:04:21 --> Hooks Class Initialized
DEBUG - 2024-12-04 15:04:21 --> UTF-8 Support Enabled
INFO - 2024-12-04 15:04:21 --> Utf8 Class Initialized
INFO - 2024-12-04 15:04:21 --> URI Class Initialized
INFO - 2024-12-04 15:04:21 --> Router Class Initialized
INFO - 2024-12-04 15:04:21 --> Output Class Initialized
INFO - 2024-12-04 15:04:21 --> Security Class Initialized
DEBUG - 2024-12-04 15:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 15:04:21 --> Input Class Initialized
INFO - 2024-12-04 15:04:21 --> Language Class Initialized
ERROR - 2024-12-04 15:04:21 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-04 16:00:44 --> Config Class Initialized
INFO - 2024-12-04 16:00:44 --> Hooks Class Initialized
DEBUG - 2024-12-04 16:00:44 --> UTF-8 Support Enabled
INFO - 2024-12-04 16:00:44 --> Utf8 Class Initialized
INFO - 2024-12-04 16:00:44 --> URI Class Initialized
DEBUG - 2024-12-04 16:00:44 --> No URI present. Default controller set.
INFO - 2024-12-04 16:00:44 --> Router Class Initialized
INFO - 2024-12-04 16:00:44 --> Output Class Initialized
INFO - 2024-12-04 16:00:44 --> Security Class Initialized
DEBUG - 2024-12-04 16:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 16:00:44 --> Input Class Initialized
INFO - 2024-12-04 16:00:44 --> Language Class Initialized
INFO - 2024-12-04 16:00:44 --> Loader Class Initialized
INFO - 2024-12-04 16:00:44 --> Helper loaded: url_helper
INFO - 2024-12-04 16:00:44 --> Helper loaded: html_helper
INFO - 2024-12-04 16:00:44 --> Helper loaded: file_helper
INFO - 2024-12-04 16:00:44 --> Helper loaded: string_helper
INFO - 2024-12-04 16:00:44 --> Helper loaded: form_helper
INFO - 2024-12-04 16:00:44 --> Helper loaded: my_helper
INFO - 2024-12-04 16:00:44 --> Database Driver Class Initialized
INFO - 2024-12-04 16:00:46 --> Upload Class Initialized
INFO - 2024-12-04 16:00:46 --> Email Class Initialized
INFO - 2024-12-04 16:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-04 16:00:46 --> Form Validation Class Initialized
INFO - 2024-12-04 16:00:46 --> Controller Class Initialized
INFO - 2024-12-04 21:30:46 --> Model "MainModel" initialized
INFO - 2024-12-04 21:30:46 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-04 21:30:46 --> Final output sent to browser
DEBUG - 2024-12-04 21:30:46 --> Total execution time: 2.2398
INFO - 2024-12-04 16:00:52 --> Config Class Initialized
INFO - 2024-12-04 16:00:52 --> Hooks Class Initialized
DEBUG - 2024-12-04 16:00:52 --> UTF-8 Support Enabled
INFO - 2024-12-04 16:00:52 --> Utf8 Class Initialized
INFO - 2024-12-04 16:00:52 --> URI Class Initialized
INFO - 2024-12-04 16:00:52 --> Router Class Initialized
INFO - 2024-12-04 16:00:52 --> Output Class Initialized
INFO - 2024-12-04 16:00:52 --> Security Class Initialized
DEBUG - 2024-12-04 16:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-04 16:00:52 --> Input Class Initialized
INFO - 2024-12-04 16:00:52 --> Language Class Initialized
ERROR - 2024-12-04 16:00:52 --> 404 Page Not Found: Faviconico/index
