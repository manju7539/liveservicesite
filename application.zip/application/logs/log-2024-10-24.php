<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-24 02:38:19 --> Model "MainModel" initialized
INFO - 2024-10-24 02:38:19 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:38:19 --> Final output sent to browser
DEBUG - 2024-10-24 02:38:19 --> Total execution time: 2.4687
INFO - 2024-10-24 02:38:24 --> Model "MainModel" initialized
INFO - 2024-10-24 02:38:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:38:24 --> Final output sent to browser
DEBUG - 2024-10-24 02:38:24 --> Total execution time: 2.5600
INFO - 2024-10-24 02:38:51 --> Model "MainModel" initialized
INFO - 2024-10-24 02:38:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:38:51 --> Final output sent to browser
DEBUG - 2024-10-24 02:38:51 --> Total execution time: 2.1151
INFO - 2024-10-24 02:38:53 --> Model "MainModel" initialized
INFO - 2024-10-24 02:38:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:38:53 --> Final output sent to browser
DEBUG - 2024-10-24 02:38:53 --> Total execution time: 2.2801
INFO - 2024-10-24 02:38:54 --> Model "MainModel" initialized
DEBUG - 2024-10-24 02:38:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-24 02:38:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-10-24 02:38:54 --> Final output sent to browser
DEBUG - 2024-10-24 02:38:54 --> Total execution time: 2.6311
INFO - 2024-10-24 02:38:54 --> Model "MainModel" initialized
INFO - 2024-10-24 02:38:56 --> Model "MainModel" initialized
DEBUG - 2024-10-24 02:38:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-24 02:39:36 --> Model "MainModel" initialized
INFO - 2024-10-24 02:39:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:39:36 --> Final output sent to browser
DEBUG - 2024-10-24 02:39:36 --> Total execution time: 2.9444
INFO - 2024-10-24 02:39:36 --> Model "MainModel" initialized
INFO - 2024-10-24 02:39:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:39:36 --> Final output sent to browser
DEBUG - 2024-10-24 02:39:36 --> Total execution time: 2.3564
INFO - 2024-10-24 02:39:36 --> Model "MainModel" initialized
INFO - 2024-10-24 02:39:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:39:36 --> Final output sent to browser
DEBUG - 2024-10-24 02:39:36 --> Total execution time: 2.8462
INFO - 2024-10-24 02:39:50 --> Model "MainModel" initialized
INFO - 2024-10-24 02:39:50 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:39:50 --> Final output sent to browser
DEBUG - 2024-10-24 02:39:50 --> Total execution time: 2.1880
INFO - 2024-10-24 02:39:59 --> Model "MainModel" initialized
INFO - 2024-10-24 02:39:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:39:59 --> Final output sent to browser
DEBUG - 2024-10-24 02:39:59 --> Total execution time: 2.9094
INFO - 2024-10-24 02:40:02 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:02 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:02 --> Total execution time: 3.3513
INFO - 2024-10-24 02:40:04 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:04 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:04 --> Total execution time: 2.1821
INFO - 2024-10-24 02:40:19 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:22 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:22 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:22 --> Total execution time: 2.3200
INFO - 2024-10-24 02:40:27 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:28 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:28 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:28 --> Total execution time: 2.1696
INFO - 2024-10-24 02:40:30 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:30 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:30 --> Total execution time: 2.4859
INFO - 2024-10-24 02:40:34 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:37 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:37 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:37 --> Total execution time: 3.0194
INFO - 2024-10-24 02:40:41 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:44 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:44 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:44 --> Total execution time: 3.4591
INFO - 2024-10-24 02:40:48 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:51 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:51 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:51 --> Total execution time: 2.6197
INFO - 2024-10-24 02:40:55 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:57 --> Model "MainModel" initialized
INFO - 2024-10-24 02:40:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:40:57 --> Final output sent to browser
DEBUG - 2024-10-24 02:40:57 --> Total execution time: 2.1284
INFO - 2024-10-24 02:41:02 --> Model "MainModel" initialized
INFO - 2024-10-24 02:41:05 --> Model "MainModel" initialized
INFO - 2024-10-24 02:41:05 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:41:05 --> Final output sent to browser
DEBUG - 2024-10-24 02:41:05 --> Total execution time: 2.2085
INFO - 2024-10-24 02:41:08 --> Model "MainModel" initialized
INFO - 2024-10-24 02:41:10 --> Model "MainModel" initialized
INFO - 2024-10-24 02:41:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:41:10 --> Final output sent to browser
DEBUG - 2024-10-24 02:41:10 --> Total execution time: 2.1273
INFO - 2024-10-24 02:41:57 --> Model "MainModel" initialized
INFO - 2024-10-24 02:41:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:41:57 --> Final output sent to browser
DEBUG - 2024-10-24 02:41:57 --> Total execution time: 3.4489
INFO - 2024-10-24 02:42:00 --> Model "MainModel" initialized
INFO - 2024-10-24 02:42:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:42:00 --> Final output sent to browser
DEBUG - 2024-10-24 02:42:00 --> Total execution time: 3.5266
INFO - 2024-10-24 02:42:02 --> Model "MainModel" initialized
INFO - 2024-10-24 02:42:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:42:02 --> Final output sent to browser
DEBUG - 2024-10-24 02:42:02 --> Total execution time: 2.2284
INFO - 2024-10-24 02:42:04 --> Model "MainModel" initialized
INFO - 2024-10-24 02:42:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:42:04 --> Final output sent to browser
DEBUG - 2024-10-24 02:42:04 --> Total execution time: 2.7143
INFO - 2024-10-24 02:42:17 --> Model "MainModel" initialized
INFO - 2024-10-24 02:42:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:42:17 --> Final output sent to browser
DEBUG - 2024-10-24 02:42:17 --> Total execution time: 2.1500
INFO - 2024-10-24 02:42:29 --> Model "MainModel" initialized
INFO - 2024-10-24 02:42:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:42:29 --> Final output sent to browser
DEBUG - 2024-10-24 02:42:29 --> Total execution time: 3.8667
INFO - 2024-10-24 02:42:33 --> Model "MainModel" initialized
INFO - 2024-10-24 02:42:33 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:42:33 --> Final output sent to browser
DEBUG - 2024-10-24 02:42:33 --> Total execution time: 2.2008
INFO - 2024-10-24 02:42:34 --> Model "MainModel" initialized
INFO - 2024-10-24 02:42:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:42:34 --> Final output sent to browser
DEBUG - 2024-10-24 02:42:34 --> Total execution time: 2.1751
INFO - 2024-10-24 02:44:17 --> Model "MainModel" initialized
INFO - 2024-10-24 02:44:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:44:17 --> Final output sent to browser
DEBUG - 2024-10-24 02:44:17 --> Total execution time: 2.3116
INFO - 2024-10-24 02:52:34 --> Model "MainModel" initialized
INFO - 2024-10-24 02:52:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:52:34 --> Final output sent to browser
DEBUG - 2024-10-24 02:52:34 --> Total execution time: 2.2033
INFO - 2024-10-24 02:52:51 --> Model "MainModel" initialized
INFO - 2024-10-24 02:52:55 --> Model "MainModel" initialized
INFO - 2024-10-24 02:52:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:52:55 --> Final output sent to browser
DEBUG - 2024-10-24 02:52:55 --> Total execution time: 2.7634
INFO - 2024-10-24 02:53:02 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:05 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:05 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:53:05 --> Final output sent to browser
DEBUG - 2024-10-24 02:53:05 --> Total execution time: 2.7385
INFO - 2024-10-24 02:53:09 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:13 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:53:13 --> Final output sent to browser
DEBUG - 2024-10-24 02:53:13 --> Total execution time: 3.0936
INFO - 2024-10-24 02:53:17 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:20 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:53:20 --> Final output sent to browser
DEBUG - 2024-10-24 02:53:20 --> Total execution time: 2.6903
INFO - 2024-10-24 02:53:24 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:28 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:53:28 --> Final output sent to browser
DEBUG - 2024-10-24 02:53:28 --> Total execution time: 3.3079
INFO - 2024-10-24 02:53:32 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:35 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:53:35 --> Final output sent to browser
DEBUG - 2024-10-24 02:53:35 --> Total execution time: 3.0710
INFO - 2024-10-24 02:53:41 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:44 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:53:44 --> Final output sent to browser
DEBUG - 2024-10-24 02:53:45 --> Total execution time: 3.2562
INFO - 2024-10-24 02:53:48 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:51 --> Model "MainModel" initialized
INFO - 2024-10-24 02:53:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:53:51 --> Final output sent to browser
DEBUG - 2024-10-24 02:53:51 --> Total execution time: 2.2021
INFO - 2024-10-24 02:54:37 --> Model "MainModel" initialized
INFO - 2024-10-24 02:54:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:54:37 --> Final output sent to browser
DEBUG - 2024-10-24 02:54:37 --> Total execution time: 3.0180
INFO - 2024-10-24 02:54:41 --> Model "MainModel" initialized
INFO - 2024-10-24 02:54:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:54:41 --> Final output sent to browser
DEBUG - 2024-10-24 02:54:41 --> Total execution time: 2.3568
INFO - 2024-10-24 02:54:54 --> Model "MainModel" initialized
INFO - 2024-10-24 02:54:57 --> Model "MainModel" initialized
INFO - 2024-10-24 02:54:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:54:57 --> Final output sent to browser
DEBUG - 2024-10-24 02:54:57 --> Total execution time: 3.1809
INFO - 2024-10-24 02:55:03 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:07 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:55:07 --> Final output sent to browser
DEBUG - 2024-10-24 02:55:07 --> Total execution time: 3.1635
INFO - 2024-10-24 02:55:11 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:14 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:55:14 --> Final output sent to browser
DEBUG - 2024-10-24 02:55:14 --> Total execution time: 2.2236
INFO - 2024-10-24 02:55:18 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:20 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:55:20 --> Final output sent to browser
DEBUG - 2024-10-24 02:55:20 --> Total execution time: 2.2820
INFO - 2024-10-24 02:55:24 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:27 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:27 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:55:27 --> Final output sent to browser
DEBUG - 2024-10-24 02:55:27 --> Total execution time: 2.3035
INFO - 2024-10-24 02:55:31 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:33 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:33 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:55:33 --> Final output sent to browser
DEBUG - 2024-10-24 02:55:33 --> Total execution time: 2.3319
INFO - 2024-10-24 02:55:41 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:43 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:43 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:55:43 --> Final output sent to browser
DEBUG - 2024-10-24 02:55:43 --> Total execution time: 2.1982
INFO - 2024-10-24 02:55:47 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:49 --> Model "MainModel" initialized
INFO - 2024-10-24 02:55:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 02:55:50 --> Final output sent to browser
DEBUG - 2024-10-24 02:55:50 --> Total execution time: 2.3601
INFO - 2024-10-24 03:02:35 --> Model "MainModel" initialized
INFO - 2024-10-24 03:02:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 03:02:35 --> Final output sent to browser
DEBUG - 2024-10-24 03:02:35 --> Total execution time: 2.3791
INFO - 2024-10-24 03:31:11 --> Model "MainModel" initialized
INFO - 2024-10-24 03:31:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 03:31:11 --> Final output sent to browser
DEBUG - 2024-10-24 03:31:11 --> Total execution time: 2.2073
INFO - 2024-10-24 03:37:18 --> Model "MainModel" initialized
INFO - 2024-10-24 03:37:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 03:37:18 --> Final output sent to browser
DEBUG - 2024-10-24 03:37:18 --> Total execution time: 2.1850
INFO - 2024-10-24 03:37:22 --> Model "MainModel" initialized
INFO - 2024-10-24 03:37:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 03:37:22 --> Final output sent to browser
DEBUG - 2024-10-24 03:37:22 --> Total execution time: 2.3203
INFO - 2024-10-24 03:40:10 --> Model "MainModel" initialized
INFO - 2024-10-24 03:40:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 03:40:10 --> Final output sent to browser
DEBUG - 2024-10-24 03:40:10 --> Total execution time: 2.1765
INFO - 2024-10-24 03:40:16 --> Model "MainModel" initialized
INFO - 2024-10-24 03:40:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 03:40:16 --> Final output sent to browser
DEBUG - 2024-10-24 03:40:16 --> Total execution time: 2.1815
INFO - 2024-10-24 00:58:23 --> Config Class Initialized
INFO - 2024-10-24 00:58:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 00:58:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 00:58:23 --> Utf8 Class Initialized
INFO - 2024-10-24 00:58:23 --> URI Class Initialized
DEBUG - 2024-10-24 00:58:23 --> No URI present. Default controller set.
INFO - 2024-10-24 00:58:23 --> Router Class Initialized
INFO - 2024-10-24 00:58:23 --> Output Class Initialized
INFO - 2024-10-24 00:58:23 --> Security Class Initialized
DEBUG - 2024-10-24 00:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 00:58:23 --> Input Class Initialized
INFO - 2024-10-24 00:58:23 --> Language Class Initialized
INFO - 2024-10-24 00:58:23 --> Loader Class Initialized
INFO - 2024-10-24 00:58:23 --> Helper loaded: url_helper
INFO - 2024-10-24 00:58:23 --> Helper loaded: html_helper
INFO - 2024-10-24 00:58:23 --> Helper loaded: file_helper
INFO - 2024-10-24 00:58:23 --> Helper loaded: string_helper
INFO - 2024-10-24 00:58:23 --> Helper loaded: form_helper
INFO - 2024-10-24 00:58:23 --> Helper loaded: my_helper
INFO - 2024-10-24 00:58:23 --> Database Driver Class Initialized
INFO - 2024-10-24 00:58:25 --> Upload Class Initialized
INFO - 2024-10-24 00:58:25 --> Email Class Initialized
INFO - 2024-10-24 00:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 00:58:26 --> Form Validation Class Initialized
INFO - 2024-10-24 00:58:26 --> Controller Class Initialized
INFO - 2024-10-24 06:28:26 --> Model "MainModel" initialized
INFO - 2024-10-24 06:28:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:28:26 --> Final output sent to browser
DEBUG - 2024-10-24 06:28:26 --> Total execution time: 2.2812
INFO - 2024-10-24 00:58:40 --> Config Class Initialized
INFO - 2024-10-24 00:58:40 --> Hooks Class Initialized
DEBUG - 2024-10-24 00:58:40 --> UTF-8 Support Enabled
INFO - 2024-10-24 00:58:40 --> Utf8 Class Initialized
INFO - 2024-10-24 00:58:40 --> URI Class Initialized
DEBUG - 2024-10-24 00:58:40 --> No URI present. Default controller set.
INFO - 2024-10-24 00:58:40 --> Router Class Initialized
INFO - 2024-10-24 00:58:40 --> Output Class Initialized
INFO - 2024-10-24 00:58:40 --> Security Class Initialized
DEBUG - 2024-10-24 00:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 00:58:40 --> Input Class Initialized
INFO - 2024-10-24 00:58:40 --> Language Class Initialized
INFO - 2024-10-24 00:58:40 --> Loader Class Initialized
INFO - 2024-10-24 00:58:40 --> Helper loaded: url_helper
INFO - 2024-10-24 00:58:40 --> Helper loaded: html_helper
INFO - 2024-10-24 00:58:40 --> Helper loaded: file_helper
INFO - 2024-10-24 00:58:40 --> Helper loaded: string_helper
INFO - 2024-10-24 00:58:40 --> Helper loaded: form_helper
INFO - 2024-10-24 00:58:40 --> Helper loaded: my_helper
INFO - 2024-10-24 00:58:40 --> Database Driver Class Initialized
INFO - 2024-10-24 00:58:42 --> Upload Class Initialized
INFO - 2024-10-24 00:58:42 --> Email Class Initialized
INFO - 2024-10-24 00:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 00:58:42 --> Form Validation Class Initialized
INFO - 2024-10-24 00:58:42 --> Controller Class Initialized
INFO - 2024-10-24 06:28:42 --> Model "MainModel" initialized
INFO - 2024-10-24 06:28:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:28:42 --> Final output sent to browser
DEBUG - 2024-10-24 06:28:42 --> Total execution time: 2.1566
INFO - 2024-10-24 00:58:44 --> Config Class Initialized
INFO - 2024-10-24 00:58:44 --> Hooks Class Initialized
DEBUG - 2024-10-24 00:58:44 --> UTF-8 Support Enabled
INFO - 2024-10-24 00:58:44 --> Utf8 Class Initialized
INFO - 2024-10-24 00:58:44 --> URI Class Initialized
INFO - 2024-10-24 00:58:44 --> Router Class Initialized
INFO - 2024-10-24 00:58:44 --> Output Class Initialized
INFO - 2024-10-24 00:58:44 --> Security Class Initialized
DEBUG - 2024-10-24 00:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 00:58:44 --> Input Class Initialized
INFO - 2024-10-24 00:58:44 --> Language Class Initialized
ERROR - 2024-10-24 00:58:44 --> 404 Page Not Found: Https:/livservice.in
INFO - 2024-10-24 00:58:44 --> Config Class Initialized
INFO - 2024-10-24 00:58:45 --> Hooks Class Initialized
DEBUG - 2024-10-24 00:58:45 --> UTF-8 Support Enabled
INFO - 2024-10-24 00:58:45 --> Utf8 Class Initialized
INFO - 2024-10-24 00:58:45 --> URI Class Initialized
DEBUG - 2024-10-24 00:58:45 --> No URI present. Default controller set.
INFO - 2024-10-24 00:58:45 --> Router Class Initialized
INFO - 2024-10-24 00:58:45 --> Output Class Initialized
INFO - 2024-10-24 00:58:45 --> Security Class Initialized
DEBUG - 2024-10-24 00:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 00:58:45 --> Input Class Initialized
INFO - 2024-10-24 00:58:45 --> Language Class Initialized
INFO - 2024-10-24 00:58:45 --> Loader Class Initialized
INFO - 2024-10-24 00:58:45 --> Helper loaded: url_helper
INFO - 2024-10-24 00:58:45 --> Helper loaded: html_helper
INFO - 2024-10-24 00:58:45 --> Helper loaded: file_helper
INFO - 2024-10-24 00:58:45 --> Helper loaded: string_helper
INFO - 2024-10-24 00:58:45 --> Helper loaded: form_helper
INFO - 2024-10-24 00:58:45 --> Helper loaded: my_helper
INFO - 2024-10-24 00:58:45 --> Database Driver Class Initialized
INFO - 2024-10-24 00:58:47 --> Upload Class Initialized
INFO - 2024-10-24 00:58:47 --> Email Class Initialized
INFO - 2024-10-24 00:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 00:58:47 --> Form Validation Class Initialized
INFO - 2024-10-24 00:58:47 --> Controller Class Initialized
INFO - 2024-10-24 06:28:47 --> Model "MainModel" initialized
INFO - 2024-10-24 06:28:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:28:47 --> Final output sent to browser
DEBUG - 2024-10-24 06:28:47 --> Total execution time: 2.1225
INFO - 2024-10-24 01:49:14 --> Config Class Initialized
INFO - 2024-10-24 01:49:14 --> Hooks Class Initialized
DEBUG - 2024-10-24 01:49:14 --> UTF-8 Support Enabled
INFO - 2024-10-24 01:49:14 --> Utf8 Class Initialized
INFO - 2024-10-24 01:49:14 --> URI Class Initialized
DEBUG - 2024-10-24 01:49:14 --> No URI present. Default controller set.
INFO - 2024-10-24 01:49:14 --> Router Class Initialized
INFO - 2024-10-24 01:49:14 --> Output Class Initialized
INFO - 2024-10-24 01:49:14 --> Security Class Initialized
DEBUG - 2024-10-24 01:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 01:49:14 --> Input Class Initialized
INFO - 2024-10-24 01:49:14 --> Language Class Initialized
INFO - 2024-10-24 01:49:14 --> Loader Class Initialized
INFO - 2024-10-24 01:49:14 --> Helper loaded: url_helper
INFO - 2024-10-24 01:49:14 --> Helper loaded: html_helper
INFO - 2024-10-24 01:49:14 --> Helper loaded: file_helper
INFO - 2024-10-24 01:49:14 --> Helper loaded: string_helper
INFO - 2024-10-24 01:49:14 --> Helper loaded: form_helper
INFO - 2024-10-24 01:49:14 --> Helper loaded: my_helper
INFO - 2024-10-24 01:49:14 --> Database Driver Class Initialized
INFO - 2024-10-24 01:49:16 --> Upload Class Initialized
INFO - 2024-10-24 01:49:16 --> Email Class Initialized
INFO - 2024-10-24 01:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 01:49:16 --> Form Validation Class Initialized
INFO - 2024-10-24 01:49:16 --> Controller Class Initialized
INFO - 2024-10-24 07:19:16 --> Model "MainModel" initialized
INFO - 2024-10-24 07:19:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 07:19:16 --> Final output sent to browser
DEBUG - 2024-10-24 07:19:16 --> Total execution time: 2.1804
INFO - 2024-10-24 01:49:39 --> Config Class Initialized
INFO - 2024-10-24 01:49:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 01:49:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 01:49:39 --> Utf8 Class Initialized
INFO - 2024-10-24 01:49:39 --> URI Class Initialized
INFO - 2024-10-24 01:49:39 --> Router Class Initialized
INFO - 2024-10-24 01:49:39 --> Output Class Initialized
INFO - 2024-10-24 01:49:39 --> Security Class Initialized
DEBUG - 2024-10-24 01:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 01:49:39 --> Input Class Initialized
INFO - 2024-10-24 01:49:39 --> Language Class Initialized
INFO - 2024-10-24 01:49:39 --> Loader Class Initialized
INFO - 2024-10-24 01:49:39 --> Helper loaded: url_helper
INFO - 2024-10-24 01:49:39 --> Helper loaded: html_helper
INFO - 2024-10-24 01:49:39 --> Helper loaded: file_helper
INFO - 2024-10-24 01:49:39 --> Helper loaded: string_helper
INFO - 2024-10-24 01:49:39 --> Helper loaded: form_helper
INFO - 2024-10-24 01:49:39 --> Helper loaded: my_helper
INFO - 2024-10-24 01:49:39 --> Database Driver Class Initialized
INFO - 2024-10-24 01:49:41 --> Upload Class Initialized
INFO - 2024-10-24 01:49:41 --> Email Class Initialized
INFO - 2024-10-24 01:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 01:49:41 --> Form Validation Class Initialized
INFO - 2024-10-24 01:49:41 --> Controller Class Initialized
INFO - 2024-10-24 07:19:41 --> Model "MainModel" initialized
DEBUG - 2024-10-24 07:19:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-24 07:19:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-10-24 07:19:41 --> Final output sent to browser
DEBUG - 2024-10-24 07:19:41 --> Total execution time: 2.1478
INFO - 2024-10-24 01:50:13 --> Config Class Initialized
INFO - 2024-10-24 01:50:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 01:50:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 01:50:13 --> Utf8 Class Initialized
INFO - 2024-10-24 01:50:13 --> URI Class Initialized
DEBUG - 2024-10-24 01:50:13 --> No URI present. Default controller set.
INFO - 2024-10-24 01:50:13 --> Router Class Initialized
INFO - 2024-10-24 01:50:13 --> Output Class Initialized
INFO - 2024-10-24 01:50:13 --> Security Class Initialized
DEBUG - 2024-10-24 01:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 01:50:13 --> Input Class Initialized
INFO - 2024-10-24 01:50:13 --> Language Class Initialized
INFO - 2024-10-24 01:50:13 --> Loader Class Initialized
INFO - 2024-10-24 01:50:13 --> Helper loaded: url_helper
INFO - 2024-10-24 01:50:13 --> Helper loaded: html_helper
INFO - 2024-10-24 01:50:13 --> Helper loaded: file_helper
INFO - 2024-10-24 01:50:13 --> Helper loaded: string_helper
INFO - 2024-10-24 01:50:13 --> Helper loaded: form_helper
INFO - 2024-10-24 01:50:13 --> Helper loaded: my_helper
INFO - 2024-10-24 01:50:13 --> Database Driver Class Initialized
INFO - 2024-10-24 01:50:15 --> Upload Class Initialized
INFO - 2024-10-24 01:50:15 --> Email Class Initialized
INFO - 2024-10-24 01:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 01:50:15 --> Form Validation Class Initialized
INFO - 2024-10-24 01:50:15 --> Controller Class Initialized
INFO - 2024-10-24 07:20:15 --> Model "MainModel" initialized
INFO - 2024-10-24 07:20:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 07:20:15 --> Final output sent to browser
DEBUG - 2024-10-24 07:20:15 --> Total execution time: 2.1418
INFO - 2024-10-24 01:50:50 --> Config Class Initialized
INFO - 2024-10-24 01:50:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 01:50:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 01:50:50 --> Utf8 Class Initialized
INFO - 2024-10-24 01:50:50 --> URI Class Initialized
INFO - 2024-10-24 01:50:50 --> Router Class Initialized
INFO - 2024-10-24 01:50:50 --> Output Class Initialized
INFO - 2024-10-24 01:50:50 --> Security Class Initialized
DEBUG - 2024-10-24 01:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 01:50:50 --> Input Class Initialized
INFO - 2024-10-24 01:50:50 --> Language Class Initialized
INFO - 2024-10-24 01:50:50 --> Loader Class Initialized
INFO - 2024-10-24 01:50:50 --> Helper loaded: url_helper
INFO - 2024-10-24 01:50:50 --> Helper loaded: html_helper
INFO - 2024-10-24 01:50:50 --> Helper loaded: file_helper
INFO - 2024-10-24 01:50:50 --> Helper loaded: string_helper
INFO - 2024-10-24 01:50:50 --> Helper loaded: form_helper
INFO - 2024-10-24 01:50:50 --> Helper loaded: my_helper
INFO - 2024-10-24 01:50:50 --> Database Driver Class Initialized
INFO - 2024-10-24 01:50:52 --> Upload Class Initialized
INFO - 2024-10-24 01:50:52 --> Email Class Initialized
INFO - 2024-10-24 01:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 01:50:52 --> Form Validation Class Initialized
INFO - 2024-10-24 01:50:52 --> Controller Class Initialized
INFO - 2024-10-24 07:20:52 --> Model "MainModel" initialized
DEBUG - 2024-10-24 07:20:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-24 07:20:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-10-24 07:20:52 --> Final output sent to browser
DEBUG - 2024-10-24 07:20:52 --> Total execution time: 2.1646
INFO - 2024-10-24 02:12:57 --> Config Class Initialized
INFO - 2024-10-24 02:12:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:12:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:12:57 --> Utf8 Class Initialized
INFO - 2024-10-24 02:12:57 --> URI Class Initialized
DEBUG - 2024-10-24 02:12:57 --> No URI present. Default controller set.
INFO - 2024-10-24 02:12:57 --> Router Class Initialized
INFO - 2024-10-24 02:12:57 --> Output Class Initialized
INFO - 2024-10-24 02:12:57 --> Security Class Initialized
DEBUG - 2024-10-24 02:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:12:57 --> Input Class Initialized
INFO - 2024-10-24 02:12:57 --> Language Class Initialized
INFO - 2024-10-24 02:12:57 --> Loader Class Initialized
INFO - 2024-10-24 02:12:57 --> Helper loaded: url_helper
INFO - 2024-10-24 02:12:57 --> Helper loaded: html_helper
INFO - 2024-10-24 02:12:57 --> Helper loaded: file_helper
INFO - 2024-10-24 02:12:57 --> Helper loaded: string_helper
INFO - 2024-10-24 02:12:57 --> Helper loaded: form_helper
INFO - 2024-10-24 02:12:57 --> Helper loaded: my_helper
INFO - 2024-10-24 02:12:57 --> Database Driver Class Initialized
INFO - 2024-10-24 02:12:59 --> Upload Class Initialized
INFO - 2024-10-24 02:12:59 --> Email Class Initialized
INFO - 2024-10-24 02:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:12:59 --> Form Validation Class Initialized
INFO - 2024-10-24 02:12:59 --> Controller Class Initialized
INFO - 2024-10-24 07:42:59 --> Model "MainModel" initialized
INFO - 2024-10-24 07:42:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 07:42:59 --> Final output sent to browser
DEBUG - 2024-10-24 07:42:59 --> Total execution time: 2.1794
INFO - 2024-10-24 02:13:24 --> Config Class Initialized
INFO - 2024-10-24 02:13:24 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:13:24 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:13:24 --> Utf8 Class Initialized
INFO - 2024-10-24 02:13:24 --> URI Class Initialized
DEBUG - 2024-10-24 02:13:24 --> No URI present. Default controller set.
INFO - 2024-10-24 02:13:24 --> Router Class Initialized
INFO - 2024-10-24 02:13:24 --> Output Class Initialized
INFO - 2024-10-24 02:13:24 --> Security Class Initialized
DEBUG - 2024-10-24 02:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:13:24 --> Input Class Initialized
INFO - 2024-10-24 02:13:24 --> Language Class Initialized
INFO - 2024-10-24 02:13:24 --> Loader Class Initialized
INFO - 2024-10-24 02:13:24 --> Helper loaded: url_helper
INFO - 2024-10-24 02:13:24 --> Helper loaded: html_helper
INFO - 2024-10-24 02:13:24 --> Helper loaded: file_helper
INFO - 2024-10-24 02:13:24 --> Helper loaded: string_helper
INFO - 2024-10-24 02:13:24 --> Helper loaded: form_helper
INFO - 2024-10-24 02:13:24 --> Helper loaded: my_helper
INFO - 2024-10-24 02:13:24 --> Database Driver Class Initialized
INFO - 2024-10-24 02:13:26 --> Upload Class Initialized
INFO - 2024-10-24 02:13:26 --> Email Class Initialized
INFO - 2024-10-24 02:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:13:26 --> Form Validation Class Initialized
INFO - 2024-10-24 02:13:26 --> Controller Class Initialized
INFO - 2024-10-24 07:43:26 --> Model "MainModel" initialized
INFO - 2024-10-24 07:43:26 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 07:43:26 --> Final output sent to browser
DEBUG - 2024-10-24 07:43:26 --> Total execution time: 2.1300
INFO - 2024-10-24 02:39:26 --> Config Class Initialized
INFO - 2024-10-24 02:39:26 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:39:26 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:39:26 --> Utf8 Class Initialized
INFO - 2024-10-24 02:39:26 --> URI Class Initialized
DEBUG - 2024-10-24 02:39:26 --> No URI present. Default controller set.
INFO - 2024-10-24 02:39:26 --> Router Class Initialized
INFO - 2024-10-24 02:39:26 --> Output Class Initialized
INFO - 2024-10-24 02:39:26 --> Security Class Initialized
DEBUG - 2024-10-24 02:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:39:26 --> Input Class Initialized
INFO - 2024-10-24 02:39:26 --> Language Class Initialized
INFO - 2024-10-24 02:39:26 --> Loader Class Initialized
INFO - 2024-10-24 02:39:26 --> Helper loaded: url_helper
INFO - 2024-10-24 02:39:26 --> Helper loaded: html_helper
INFO - 2024-10-24 02:39:26 --> Helper loaded: file_helper
INFO - 2024-10-24 02:39:26 --> Helper loaded: string_helper
INFO - 2024-10-24 02:39:26 --> Helper loaded: form_helper
INFO - 2024-10-24 02:39:26 --> Helper loaded: my_helper
INFO - 2024-10-24 02:39:26 --> Database Driver Class Initialized
INFO - 2024-10-24 02:39:28 --> Upload Class Initialized
INFO - 2024-10-24 02:39:28 --> Email Class Initialized
INFO - 2024-10-24 02:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:39:28 --> Form Validation Class Initialized
INFO - 2024-10-24 02:39:28 --> Controller Class Initialized
INFO - 2024-10-24 08:09:28 --> Model "MainModel" initialized
INFO - 2024-10-24 08:09:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 08:09:28 --> Final output sent to browser
DEBUG - 2024-10-24 08:09:28 --> Total execution time: 2.1953
INFO - 2024-10-24 04:46:37 --> Config Class Initialized
INFO - 2024-10-24 04:46:37 --> Hooks Class Initialized
DEBUG - 2024-10-24 04:46:37 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:46:37 --> Utf8 Class Initialized
INFO - 2024-10-24 04:46:37 --> URI Class Initialized
DEBUG - 2024-10-24 04:46:37 --> No URI present. Default controller set.
INFO - 2024-10-24 04:46:37 --> Router Class Initialized
INFO - 2024-10-24 04:46:37 --> Output Class Initialized
INFO - 2024-10-24 04:46:37 --> Security Class Initialized
DEBUG - 2024-10-24 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:46:37 --> Input Class Initialized
INFO - 2024-10-24 04:46:37 --> Language Class Initialized
INFO - 2024-10-24 04:46:37 --> Loader Class Initialized
INFO - 2024-10-24 04:46:37 --> Helper loaded: url_helper
INFO - 2024-10-24 04:46:37 --> Helper loaded: html_helper
INFO - 2024-10-24 04:46:37 --> Helper loaded: file_helper
INFO - 2024-10-24 04:46:37 --> Helper loaded: string_helper
INFO - 2024-10-24 04:46:37 --> Helper loaded: form_helper
INFO - 2024-10-24 04:46:37 --> Helper loaded: my_helper
INFO - 2024-10-24 04:46:37 --> Database Driver Class Initialized
INFO - 2024-10-24 04:46:39 --> Upload Class Initialized
INFO - 2024-10-24 04:46:39 --> Email Class Initialized
INFO - 2024-10-24 04:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:46:39 --> Form Validation Class Initialized
INFO - 2024-10-24 04:46:39 --> Controller Class Initialized
INFO - 2024-10-24 10:16:39 --> Model "MainModel" initialized
INFO - 2024-10-24 10:16:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 10:16:39 --> Final output sent to browser
DEBUG - 2024-10-24 10:16:39 --> Total execution time: 2.1928
INFO - 2024-10-24 04:46:39 --> Config Class Initialized
INFO - 2024-10-24 04:46:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 04:46:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:46:39 --> Utf8 Class Initialized
INFO - 2024-10-24 04:46:39 --> URI Class Initialized
DEBUG - 2024-10-24 04:46:39 --> No URI present. Default controller set.
INFO - 2024-10-24 04:46:39 --> Router Class Initialized
INFO - 2024-10-24 04:46:39 --> Output Class Initialized
INFO - 2024-10-24 04:46:39 --> Security Class Initialized
DEBUG - 2024-10-24 04:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:46:39 --> Input Class Initialized
INFO - 2024-10-24 04:46:39 --> Language Class Initialized
INFO - 2024-10-24 04:46:39 --> Loader Class Initialized
INFO - 2024-10-24 04:46:39 --> Helper loaded: url_helper
INFO - 2024-10-24 04:46:39 --> Helper loaded: html_helper
INFO - 2024-10-24 04:46:39 --> Helper loaded: file_helper
INFO - 2024-10-24 04:46:39 --> Helper loaded: string_helper
INFO - 2024-10-24 04:46:39 --> Helper loaded: form_helper
INFO - 2024-10-24 04:46:39 --> Helper loaded: my_helper
INFO - 2024-10-24 04:46:39 --> Database Driver Class Initialized
INFO - 2024-10-24 04:46:41 --> Upload Class Initialized
INFO - 2024-10-24 04:46:41 --> Email Class Initialized
INFO - 2024-10-24 04:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:46:41 --> Form Validation Class Initialized
INFO - 2024-10-24 04:46:41 --> Controller Class Initialized
INFO - 2024-10-24 10:16:41 --> Model "MainModel" initialized
INFO - 2024-10-24 10:16:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 10:16:41 --> Final output sent to browser
DEBUG - 2024-10-24 10:16:41 --> Total execution time: 2.1000
INFO - 2024-10-24 04:56:26 --> Config Class Initialized
INFO - 2024-10-24 04:56:26 --> Hooks Class Initialized
DEBUG - 2024-10-24 04:56:26 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:56:26 --> Utf8 Class Initialized
INFO - 2024-10-24 04:56:26 --> URI Class Initialized
DEBUG - 2024-10-24 04:56:26 --> No URI present. Default controller set.
INFO - 2024-10-24 04:56:26 --> Router Class Initialized
INFO - 2024-10-24 04:56:26 --> Output Class Initialized
INFO - 2024-10-24 04:56:26 --> Security Class Initialized
DEBUG - 2024-10-24 04:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:56:26 --> Input Class Initialized
INFO - 2024-10-24 04:56:26 --> Language Class Initialized
INFO - 2024-10-24 04:56:26 --> Loader Class Initialized
INFO - 2024-10-24 04:56:26 --> Helper loaded: url_helper
INFO - 2024-10-24 04:56:26 --> Helper loaded: html_helper
INFO - 2024-10-24 04:56:26 --> Helper loaded: file_helper
INFO - 2024-10-24 04:56:26 --> Helper loaded: string_helper
INFO - 2024-10-24 04:56:26 --> Helper loaded: form_helper
INFO - 2024-10-24 04:56:26 --> Helper loaded: my_helper
INFO - 2024-10-24 04:56:26 --> Database Driver Class Initialized
INFO - 2024-10-24 04:56:28 --> Upload Class Initialized
INFO - 2024-10-24 04:56:28 --> Config Class Initialized
INFO - 2024-10-24 04:56:28 --> Hooks Class Initialized
INFO - 2024-10-24 04:56:28 --> Email Class Initialized
DEBUG - 2024-10-24 04:56:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:56:28 --> Utf8 Class Initialized
INFO - 2024-10-24 04:56:28 --> URI Class Initialized
DEBUG - 2024-10-24 04:56:28 --> No URI present. Default controller set.
INFO - 2024-10-24 04:56:28 --> Router Class Initialized
INFO - 2024-10-24 04:56:28 --> Output Class Initialized
INFO - 2024-10-24 04:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:56:28 --> Security Class Initialized
DEBUG - 2024-10-24 04:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:56:28 --> Input Class Initialized
INFO - 2024-10-24 04:56:28 --> Form Validation Class Initialized
INFO - 2024-10-24 04:56:28 --> Language Class Initialized
INFO - 2024-10-24 04:56:28 --> Controller Class Initialized
INFO - 2024-10-24 04:56:28 --> Loader Class Initialized
INFO - 2024-10-24 10:26:28 --> Model "MainModel" initialized
INFO - 2024-10-24 10:26:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 04:56:28 --> Helper loaded: url_helper
INFO - 2024-10-24 10:26:28 --> Final output sent to browser
DEBUG - 2024-10-24 10:26:28 --> Total execution time: 2.2253
INFO - 2024-10-24 04:56:28 --> Helper loaded: html_helper
INFO - 2024-10-24 04:56:28 --> Helper loaded: file_helper
INFO - 2024-10-24 04:56:28 --> Helper loaded: string_helper
INFO - 2024-10-24 04:56:28 --> Helper loaded: form_helper
INFO - 2024-10-24 04:56:28 --> Helper loaded: my_helper
INFO - 2024-10-24 04:56:28 --> Database Driver Class Initialized
INFO - 2024-10-24 04:56:30 --> Upload Class Initialized
INFO - 2024-10-24 04:56:30 --> Email Class Initialized
INFO - 2024-10-24 04:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:56:30 --> Form Validation Class Initialized
INFO - 2024-10-24 04:56:30 --> Controller Class Initialized
INFO - 2024-10-24 10:26:30 --> Model "MainModel" initialized
INFO - 2024-10-24 10:26:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 10:26:30 --> Final output sent to browser
DEBUG - 2024-10-24 10:26:30 --> Total execution time: 2.1502
INFO - 2024-10-24 05:38:48 --> Config Class Initialized
INFO - 2024-10-24 05:38:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:38:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:38:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:38:48 --> URI Class Initialized
DEBUG - 2024-10-24 05:38:48 --> No URI present. Default controller set.
INFO - 2024-10-24 05:38:48 --> Router Class Initialized
INFO - 2024-10-24 05:38:48 --> Output Class Initialized
INFO - 2024-10-24 05:38:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:38:48 --> Input Class Initialized
INFO - 2024-10-24 05:38:48 --> Language Class Initialized
INFO - 2024-10-24 05:38:48 --> Loader Class Initialized
INFO - 2024-10-24 05:38:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:38:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:38:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:38:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:38:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:38:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:38:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:38:50 --> Upload Class Initialized
INFO - 2024-10-24 05:38:50 --> Email Class Initialized
INFO - 2024-10-24 05:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:38:50 --> Form Validation Class Initialized
INFO - 2024-10-24 05:38:50 --> Controller Class Initialized
INFO - 2024-10-24 11:08:50 --> Model "MainModel" initialized
INFO - 2024-10-24 11:08:50 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 11:08:50 --> Final output sent to browser
DEBUG - 2024-10-24 11:08:51 --> Total execution time: 2.2945
INFO - 2024-10-24 05:38:51 --> Config Class Initialized
INFO - 2024-10-24 05:38:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:38:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:38:51 --> Utf8 Class Initialized
INFO - 2024-10-24 05:38:51 --> URI Class Initialized
DEBUG - 2024-10-24 05:38:51 --> No URI present. Default controller set.
INFO - 2024-10-24 05:38:51 --> Router Class Initialized
INFO - 2024-10-24 05:38:51 --> Output Class Initialized
INFO - 2024-10-24 05:38:51 --> Security Class Initialized
DEBUG - 2024-10-24 05:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:38:51 --> Input Class Initialized
INFO - 2024-10-24 05:38:51 --> Language Class Initialized
INFO - 2024-10-24 05:38:51 --> Loader Class Initialized
INFO - 2024-10-24 05:38:51 --> Helper loaded: url_helper
INFO - 2024-10-24 05:38:51 --> Helper loaded: html_helper
INFO - 2024-10-24 05:38:51 --> Helper loaded: file_helper
INFO - 2024-10-24 05:38:51 --> Helper loaded: string_helper
INFO - 2024-10-24 05:38:51 --> Helper loaded: form_helper
INFO - 2024-10-24 05:38:51 --> Helper loaded: my_helper
INFO - 2024-10-24 05:38:51 --> Database Driver Class Initialized
INFO - 2024-10-24 05:38:53 --> Upload Class Initialized
INFO - 2024-10-24 05:38:53 --> Email Class Initialized
INFO - 2024-10-24 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:38:53 --> Form Validation Class Initialized
INFO - 2024-10-24 05:38:53 --> Controller Class Initialized
INFO - 2024-10-24 11:08:53 --> Model "MainModel" initialized
INFO - 2024-10-24 11:08:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 11:08:53 --> Final output sent to browser
DEBUG - 2024-10-24 11:08:53 --> Total execution time: 2.1674
INFO - 2024-10-24 05:39:00 --> Config Class Initialized
INFO - 2024-10-24 05:39:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:39:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:39:00 --> Utf8 Class Initialized
INFO - 2024-10-24 05:39:00 --> URI Class Initialized
INFO - 2024-10-24 05:39:00 --> Router Class Initialized
INFO - 2024-10-24 05:39:00 --> Output Class Initialized
INFO - 2024-10-24 05:39:00 --> Security Class Initialized
DEBUG - 2024-10-24 05:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:39:00 --> Input Class Initialized
INFO - 2024-10-24 05:39:00 --> Language Class Initialized
ERROR - 2024-10-24 05:39:00 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-24 05:44:38 --> Config Class Initialized
INFO - 2024-10-24 05:44:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:44:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:44:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:44:38 --> URI Class Initialized
INFO - 2024-10-24 05:44:38 --> Router Class Initialized
INFO - 2024-10-24 05:44:38 --> Output Class Initialized
INFO - 2024-10-24 05:44:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:44:38 --> Input Class Initialized
INFO - 2024-10-24 05:44:38 --> Language Class Initialized
ERROR - 2024-10-24 05:44:38 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-24 05:47:41 --> Config Class Initialized
INFO - 2024-10-24 05:47:41 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:47:41 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:47:41 --> Utf8 Class Initialized
INFO - 2024-10-24 05:47:41 --> URI Class Initialized
DEBUG - 2024-10-24 05:47:41 --> No URI present. Default controller set.
INFO - 2024-10-24 05:47:41 --> Router Class Initialized
INFO - 2024-10-24 05:47:41 --> Output Class Initialized
INFO - 2024-10-24 05:47:41 --> Security Class Initialized
DEBUG - 2024-10-24 05:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:47:41 --> Input Class Initialized
INFO - 2024-10-24 05:47:41 --> Language Class Initialized
INFO - 2024-10-24 05:47:41 --> Loader Class Initialized
INFO - 2024-10-24 05:47:41 --> Helper loaded: url_helper
INFO - 2024-10-24 05:47:41 --> Helper loaded: html_helper
INFO - 2024-10-24 05:47:41 --> Helper loaded: file_helper
INFO - 2024-10-24 05:47:41 --> Helper loaded: string_helper
INFO - 2024-10-24 05:47:41 --> Helper loaded: form_helper
INFO - 2024-10-24 05:47:41 --> Helper loaded: my_helper
INFO - 2024-10-24 05:47:41 --> Database Driver Class Initialized
INFO - 2024-10-24 05:47:43 --> Upload Class Initialized
INFO - 2024-10-24 05:47:43 --> Email Class Initialized
INFO - 2024-10-24 05:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:47:44 --> Form Validation Class Initialized
INFO - 2024-10-24 05:47:44 --> Controller Class Initialized
INFO - 2024-10-24 11:17:44 --> Model "MainModel" initialized
INFO - 2024-10-24 11:17:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 11:17:44 --> Final output sent to browser
DEBUG - 2024-10-24 11:17:44 --> Total execution time: 2.2493
INFO - 2024-10-24 05:47:49 --> Config Class Initialized
INFO - 2024-10-24 05:47:49 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:47:49 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:47:49 --> Utf8 Class Initialized
INFO - 2024-10-24 05:47:49 --> URI Class Initialized
INFO - 2024-10-24 05:47:49 --> Router Class Initialized
INFO - 2024-10-24 05:47:49 --> Output Class Initialized
INFO - 2024-10-24 05:47:49 --> Security Class Initialized
DEBUG - 2024-10-24 05:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:47:49 --> Input Class Initialized
INFO - 2024-10-24 05:47:49 --> Language Class Initialized
INFO - 2024-10-24 05:47:49 --> Loader Class Initialized
INFO - 2024-10-24 05:47:49 --> Helper loaded: url_helper
INFO - 2024-10-24 05:47:49 --> Helper loaded: html_helper
INFO - 2024-10-24 05:47:49 --> Helper loaded: file_helper
INFO - 2024-10-24 05:47:49 --> Helper loaded: string_helper
INFO - 2024-10-24 05:47:49 --> Helper loaded: form_helper
INFO - 2024-10-24 05:47:49 --> Helper loaded: my_helper
INFO - 2024-10-24 05:47:49 --> Database Driver Class Initialized
INFO - 2024-10-24 05:47:51 --> Upload Class Initialized
INFO - 2024-10-24 05:47:51 --> Email Class Initialized
INFO - 2024-10-24 05:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:47:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:47:51 --> Controller Class Initialized
INFO - 2024-10-24 11:17:51 --> Model "MainModel" initialized
INFO - 2024-10-24 05:47:52 --> Config Class Initialized
INFO - 2024-10-24 05:47:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:47:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:47:52 --> Utf8 Class Initialized
INFO - 2024-10-24 05:47:52 --> URI Class Initialized
INFO - 2024-10-24 05:47:52 --> Router Class Initialized
INFO - 2024-10-24 05:47:52 --> Output Class Initialized
INFO - 2024-10-24 05:47:52 --> Security Class Initialized
DEBUG - 2024-10-24 05:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:47:52 --> Input Class Initialized
INFO - 2024-10-24 05:47:52 --> Language Class Initialized
INFO - 2024-10-24 05:47:52 --> Loader Class Initialized
INFO - 2024-10-24 05:47:52 --> Helper loaded: url_helper
INFO - 2024-10-24 05:47:52 --> Helper loaded: html_helper
INFO - 2024-10-24 05:47:52 --> Helper loaded: file_helper
INFO - 2024-10-24 05:47:52 --> Helper loaded: string_helper
INFO - 2024-10-24 05:47:52 --> Helper loaded: form_helper
INFO - 2024-10-24 05:47:52 --> Helper loaded: my_helper
INFO - 2024-10-24 05:47:52 --> Database Driver Class Initialized
INFO - 2024-10-24 05:47:54 --> Upload Class Initialized
INFO - 2024-10-24 05:47:54 --> Email Class Initialized
INFO - 2024-10-24 05:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:47:54 --> Form Validation Class Initialized
INFO - 2024-10-24 05:47:54 --> Controller Class Initialized
INFO - 2024-10-24 11:17:54 --> Model "MainModel" initialized
INFO - 2024-10-24 11:17:54 --> Model "FrontofficeModel" initialized
INFO - 2024-10-24 11:17:54 --> Model "HotelAdminModel" initialized
INFO - 2024-10-24 11:17:54 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-24 11:17:54 --> Model "FoodAdminModel" initialized
INFO - 2024-10-24 11:17:54 --> Model "SuperAdminModel" initialized
INFO - 2024-10-24 11:17:54 --> Helper loaded: notification_helper
INFO - 2024-10-24 11:17:54 --> Helper loaded: array_helper
INFO - 2024-10-24 11:17:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-24 11:17:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-24 11:17:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-24 11:17:55 --> Final output sent to browser
DEBUG - 2024-10-24 11:17:55 --> Total execution time: 2.7448
INFO - 2024-10-24 05:47:57 --> Config Class Initialized
INFO - 2024-10-24 05:47:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:47:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:47:57 --> Utf8 Class Initialized
INFO - 2024-10-24 05:47:57 --> URI Class Initialized
INFO - 2024-10-24 05:47:57 --> Router Class Initialized
INFO - 2024-10-24 05:47:57 --> Output Class Initialized
INFO - 2024-10-24 05:47:57 --> Security Class Initialized
DEBUG - 2024-10-24 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:47:57 --> Input Class Initialized
INFO - 2024-10-24 05:47:57 --> Language Class Initialized
ERROR - 2024-10-24 05:47:57 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:47:57 --> Config Class Initialized
INFO - 2024-10-24 05:47:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:47:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:47:57 --> Utf8 Class Initialized
INFO - 2024-10-24 05:47:57 --> URI Class Initialized
INFO - 2024-10-24 05:47:57 --> Router Class Initialized
INFO - 2024-10-24 05:47:57 --> Output Class Initialized
INFO - 2024-10-24 05:47:57 --> Security Class Initialized
DEBUG - 2024-10-24 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:47:57 --> Input Class Initialized
INFO - 2024-10-24 05:47:57 --> Language Class Initialized
INFO - 2024-10-24 05:47:57 --> Loader Class Initialized
INFO - 2024-10-24 05:47:57 --> Helper loaded: url_helper
INFO - 2024-10-24 05:47:57 --> Config Class Initialized
INFO - 2024-10-24 05:47:57 --> Helper loaded: html_helper
INFO - 2024-10-24 05:47:57 --> Hooks Class Initialized
INFO - 2024-10-24 05:47:57 --> Helper loaded: file_helper
DEBUG - 2024-10-24 05:47:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:47:57 --> Utf8 Class Initialized
INFO - 2024-10-24 05:47:57 --> Helper loaded: string_helper
INFO - 2024-10-24 05:47:57 --> URI Class Initialized
INFO - 2024-10-24 05:47:57 --> Helper loaded: form_helper
INFO - 2024-10-24 05:47:57 --> Helper loaded: my_helper
INFO - 2024-10-24 05:47:57 --> Router Class Initialized
INFO - 2024-10-24 05:47:57 --> Database Driver Class Initialized
INFO - 2024-10-24 05:47:57 --> Output Class Initialized
INFO - 2024-10-24 05:47:57 --> Security Class Initialized
DEBUG - 2024-10-24 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:47:57 --> Input Class Initialized
INFO - 2024-10-24 05:47:57 --> Language Class Initialized
ERROR - 2024-10-24 05:47:57 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:47:57 --> Config Class Initialized
INFO - 2024-10-24 05:47:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:47:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:47:57 --> Utf8 Class Initialized
INFO - 2024-10-24 05:47:57 --> URI Class Initialized
INFO - 2024-10-24 05:47:57 --> Router Class Initialized
INFO - 2024-10-24 05:47:57 --> Output Class Initialized
INFO - 2024-10-24 05:47:57 --> Security Class Initialized
DEBUG - 2024-10-24 05:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:47:57 --> Input Class Initialized
INFO - 2024-10-24 05:47:57 --> Language Class Initialized
ERROR - 2024-10-24 05:47:57 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:47:59 --> Upload Class Initialized
INFO - 2024-10-24 05:47:59 --> Email Class Initialized
INFO - 2024-10-24 05:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:47:59 --> Form Validation Class Initialized
INFO - 2024-10-24 05:47:59 --> Controller Class Initialized
INFO - 2024-10-24 11:17:59 --> Model "FrontofficeModel" initialized
INFO - 2024-10-24 11:17:59 --> Model "MainModel" initialized
INFO - 2024-10-24 11:17:59 --> Model "ApiModel" initialized
INFO - 2024-10-24 11:17:59 --> Helper loaded: notification_helper
INFO - 2024-10-24 11:17:59 --> Final output sent to browser
DEBUG - 2024-10-24 11:17:59 --> Total execution time: 2.2508
INFO - 2024-10-24 05:48:02 --> Config Class Initialized
INFO - 2024-10-24 05:48:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:02 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:02 --> URI Class Initialized
INFO - 2024-10-24 05:48:02 --> Router Class Initialized
INFO - 2024-10-24 05:48:02 --> Output Class Initialized
INFO - 2024-10-24 05:48:02 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:02 --> Input Class Initialized
INFO - 2024-10-24 05:48:02 --> Language Class Initialized
INFO - 2024-10-24 05:48:02 --> Loader Class Initialized
INFO - 2024-10-24 05:48:02 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:02 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:02 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:02 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:02 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:02 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:02 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:04 --> Upload Class Initialized
INFO - 2024-10-24 05:48:04 --> Email Class Initialized
INFO - 2024-10-24 05:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:04 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:04 --> Controller Class Initialized
INFO - 2024-10-24 11:18:04 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:04 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:04 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:07 --> Config Class Initialized
INFO - 2024-10-24 05:48:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:07 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:07 --> URI Class Initialized
INFO - 2024-10-24 05:48:07 --> Router Class Initialized
INFO - 2024-10-24 05:48:07 --> Output Class Initialized
INFO - 2024-10-24 05:48:07 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:07 --> Input Class Initialized
INFO - 2024-10-24 05:48:07 --> Language Class Initialized
INFO - 2024-10-24 05:48:07 --> Loader Class Initialized
INFO - 2024-10-24 05:48:07 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:07 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:07 --> Config Class Initialized
INFO - 2024-10-24 05:48:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:07 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:07 --> URI Class Initialized
INFO - 2024-10-24 05:48:07 --> Router Class Initialized
INFO - 2024-10-24 05:48:07 --> Output Class Initialized
INFO - 2024-10-24 05:48:07 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:07 --> Input Class Initialized
INFO - 2024-10-24 05:48:07 --> Language Class Initialized
INFO - 2024-10-24 05:48:07 --> Loader Class Initialized
INFO - 2024-10-24 05:48:07 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:07 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:07 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:09 --> Upload Class Initialized
INFO - 2024-10-24 05:48:09 --> Email Class Initialized
INFO - 2024-10-24 05:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:09 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:09 --> Controller Class Initialized
INFO - 2024-10-24 11:18:09 --> Model "HotelAdminModel" initialized
INFO - 2024-10-24 11:18:09 --> Model "FrontofficeModel" initialized
INFO - 2024-10-24 11:18:09 --> Model "FoodAdminModel" initialized
INFO - 2024-10-24 11:18:09 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:09 --> Helper loaded: notification_helper
INFO - 2024-10-24 11:18:09 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-24 11:18:09 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\hoteladmin/viewFrontOfficeList.php
INFO - 2024-10-24 11:18:09 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-24 11:18:09 --> Final output sent to browser
DEBUG - 2024-10-24 11:18:09 --> Total execution time: 2.2522
INFO - 2024-10-24 05:48:09 --> Upload Class Initialized
INFO - 2024-10-24 05:48:09 --> Email Class Initialized
INFO - 2024-10-24 05:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:09 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:09 --> Controller Class Initialized
INFO - 2024-10-24 11:18:09 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:09 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:09 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:09 --> Config Class Initialized
INFO - 2024-10-24 05:48:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:10 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:10 --> URI Class Initialized
INFO - 2024-10-24 05:48:10 --> Router Class Initialized
INFO - 2024-10-24 05:48:10 --> Output Class Initialized
INFO - 2024-10-24 05:48:10 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:10 --> Input Class Initialized
INFO - 2024-10-24 05:48:10 --> Language Class Initialized
ERROR - 2024-10-24 05:48:10 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:48:10 --> Config Class Initialized
INFO - 2024-10-24 05:48:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:10 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:10 --> URI Class Initialized
INFO - 2024-10-24 05:48:10 --> Router Class Initialized
INFO - 2024-10-24 05:48:10 --> Output Class Initialized
INFO - 2024-10-24 05:48:10 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:10 --> Input Class Initialized
INFO - 2024-10-24 05:48:10 --> Language Class Initialized
ERROR - 2024-10-24 05:48:10 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:48:10 --> Config Class Initialized
INFO - 2024-10-24 05:48:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:10 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:10 --> URI Class Initialized
INFO - 2024-10-24 05:48:10 --> Router Class Initialized
INFO - 2024-10-24 05:48:10 --> Output Class Initialized
INFO - 2024-10-24 05:48:10 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:10 --> Input Class Initialized
INFO - 2024-10-24 05:48:10 --> Language Class Initialized
ERROR - 2024-10-24 05:48:10 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:48:11 --> Config Class Initialized
INFO - 2024-10-24 05:48:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:11 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:11 --> URI Class Initialized
INFO - 2024-10-24 05:48:11 --> Router Class Initialized
INFO - 2024-10-24 05:48:11 --> Output Class Initialized
INFO - 2024-10-24 05:48:11 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:11 --> Input Class Initialized
INFO - 2024-10-24 05:48:11 --> Language Class Initialized
INFO - 2024-10-24 05:48:11 --> Loader Class Initialized
INFO - 2024-10-24 05:48:11 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:11 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:11 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:11 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:11 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:11 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:11 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:13 --> Upload Class Initialized
INFO - 2024-10-24 05:48:13 --> Email Class Initialized
INFO - 2024-10-24 05:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:13 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:13 --> Controller Class Initialized
INFO - 2024-10-24 11:18:13 --> Model "HotelAdminModel" initialized
INFO - 2024-10-24 11:18:13 --> Model "FrontofficeModel" initialized
INFO - 2024-10-24 11:18:13 --> Model "FoodAdminModel" initialized
INFO - 2024-10-24 11:18:13 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:13 --> Helper loaded: notification_helper
INFO - 2024-10-24 11:18:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-24 11:18:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\hoteladmin/ViewHouseKeepingList.php
INFO - 2024-10-24 11:18:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-24 11:18:13 --> Final output sent to browser
DEBUG - 2024-10-24 11:18:13 --> Total execution time: 2.1985
INFO - 2024-10-24 05:48:13 --> Config Class Initialized
INFO - 2024-10-24 05:48:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:13 --> URI Class Initialized
INFO - 2024-10-24 05:48:13 --> Router Class Initialized
INFO - 2024-10-24 05:48:13 --> Output Class Initialized
INFO - 2024-10-24 05:48:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:13 --> Input Class Initialized
INFO - 2024-10-24 05:48:13 --> Language Class Initialized
ERROR - 2024-10-24 05:48:13 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:48:13 --> Config Class Initialized
INFO - 2024-10-24 05:48:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:13 --> URI Class Initialized
INFO - 2024-10-24 05:48:13 --> Router Class Initialized
INFO - 2024-10-24 05:48:13 --> Output Class Initialized
INFO - 2024-10-24 05:48:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:13 --> Input Class Initialized
INFO - 2024-10-24 05:48:13 --> Language Class Initialized
ERROR - 2024-10-24 05:48:13 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:48:13 --> Config Class Initialized
INFO - 2024-10-24 05:48:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:13 --> URI Class Initialized
INFO - 2024-10-24 05:48:13 --> Router Class Initialized
INFO - 2024-10-24 05:48:13 --> Output Class Initialized
INFO - 2024-10-24 05:48:14 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:14 --> Input Class Initialized
INFO - 2024-10-24 05:48:14 --> Language Class Initialized
ERROR - 2024-10-24 05:48:14 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-24 05:48:18 --> Config Class Initialized
INFO - 2024-10-24 05:48:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:18 --> URI Class Initialized
INFO - 2024-10-24 05:48:18 --> Router Class Initialized
INFO - 2024-10-24 05:48:18 --> Output Class Initialized
INFO - 2024-10-24 05:48:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:18 --> Input Class Initialized
INFO - 2024-10-24 05:48:18 --> Language Class Initialized
INFO - 2024-10-24 05:48:18 --> Loader Class Initialized
INFO - 2024-10-24 05:48:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:20 --> Config Class Initialized
INFO - 2024-10-24 05:48:20 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:20 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:20 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:20 --> URI Class Initialized
INFO - 2024-10-24 05:48:20 --> Router Class Initialized
INFO - 2024-10-24 05:48:20 --> Output Class Initialized
INFO - 2024-10-24 05:48:20 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:20 --> Input Class Initialized
INFO - 2024-10-24 05:48:20 --> Language Class Initialized
INFO - 2024-10-24 05:48:20 --> Loader Class Initialized
INFO - 2024-10-24 05:48:20 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:20 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:20 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:20 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:20 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:20 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:20 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:20 --> Upload Class Initialized
INFO - 2024-10-24 05:48:20 --> Email Class Initialized
INFO - 2024-10-24 05:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:20 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:20 --> Controller Class Initialized
INFO - 2024-10-24 11:18:20 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:20 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:20 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:22 --> Upload Class Initialized
INFO - 2024-10-24 05:48:22 --> Email Class Initialized
INFO - 2024-10-24 05:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:22 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:22 --> Controller Class Initialized
INFO - 2024-10-24 11:18:22 --> Model "HotelAdminModel" initialized
INFO - 2024-10-24 11:18:22 --> Model "FrontofficeModel" initialized
INFO - 2024-10-24 11:18:22 --> Model "FoodAdminModel" initialized
INFO - 2024-10-24 11:18:22 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:22 --> Helper loaded: notification_helper
ERROR - 2024-10-24 11:18:22 --> Severity: Warning --> Undefined variable $hk_s C:\inetpub\vhosts\livservice.in\httpdocs\application\views\hoteladmin\ajaxHousekeepingIcon.php 732
ERROR - 2024-10-24 11:18:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\inetpub\vhosts\livservice.in\httpdocs\application\views\hoteladmin\ajaxHousekeepingIcon.php 732
INFO - 2024-10-24 11:18:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\hoteladmin/ajaxHousekeepingIcon.php
INFO - 2024-10-24 11:18:22 --> Final output sent to browser
DEBUG - 2024-10-24 11:18:22 --> Total execution time: 2.2297
INFO - 2024-10-24 05:48:23 --> Config Class Initialized
INFO - 2024-10-24 05:48:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:23 --> URI Class Initialized
INFO - 2024-10-24 05:48:23 --> Router Class Initialized
INFO - 2024-10-24 05:48:23 --> Output Class Initialized
INFO - 2024-10-24 05:48:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:23 --> Input Class Initialized
INFO - 2024-10-24 05:48:23 --> Language Class Initialized
INFO - 2024-10-24 05:48:23 --> Loader Class Initialized
INFO - 2024-10-24 05:48:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:25 --> Upload Class Initialized
INFO - 2024-10-24 05:48:25 --> Email Class Initialized
INFO - 2024-10-24 05:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:25 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:25 --> Controller Class Initialized
INFO - 2024-10-24 11:18:25 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:28 --> Config Class Initialized
INFO - 2024-10-24 05:48:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:28 --> URI Class Initialized
INFO - 2024-10-24 05:48:28 --> Router Class Initialized
INFO - 2024-10-24 05:48:28 --> Output Class Initialized
INFO - 2024-10-24 05:48:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:28 --> Input Class Initialized
INFO - 2024-10-24 05:48:28 --> Language Class Initialized
INFO - 2024-10-24 05:48:28 --> Loader Class Initialized
INFO - 2024-10-24 05:48:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:30 --> Upload Class Initialized
INFO - 2024-10-24 05:48:31 --> Email Class Initialized
INFO - 2024-10-24 05:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:31 --> Controller Class Initialized
INFO - 2024-10-24 11:18:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:32 --> Config Class Initialized
INFO - 2024-10-24 05:48:32 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:32 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:32 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:32 --> URI Class Initialized
INFO - 2024-10-24 05:48:32 --> Router Class Initialized
INFO - 2024-10-24 05:48:32 --> Output Class Initialized
INFO - 2024-10-24 05:48:32 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:32 --> Input Class Initialized
INFO - 2024-10-24 05:48:32 --> Language Class Initialized
INFO - 2024-10-24 05:48:32 --> Loader Class Initialized
INFO - 2024-10-24 05:48:32 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:32 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:32 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:32 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:32 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:32 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:32 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:33 --> Config Class Initialized
INFO - 2024-10-24 05:48:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:33 --> URI Class Initialized
INFO - 2024-10-24 05:48:33 --> Router Class Initialized
INFO - 2024-10-24 05:48:33 --> Output Class Initialized
INFO - 2024-10-24 05:48:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:33 --> Input Class Initialized
INFO - 2024-10-24 05:48:33 --> Language Class Initialized
INFO - 2024-10-24 05:48:33 --> Loader Class Initialized
INFO - 2024-10-24 05:48:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:34 --> Upload Class Initialized
INFO - 2024-10-24 05:48:34 --> Email Class Initialized
INFO - 2024-10-24 05:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:34 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:34 --> Controller Class Initialized
INFO - 2024-10-24 11:18:34 --> Model "HotelAdminModel" initialized
INFO - 2024-10-24 11:18:34 --> Model "FrontofficeModel" initialized
INFO - 2024-10-24 11:18:34 --> Model "FoodAdminModel" initialized
INFO - 2024-10-24 11:18:34 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:34 --> Helper loaded: notification_helper
INFO - 2024-10-24 11:18:34 --> Final output sent to browser
DEBUG - 2024-10-24 11:18:34 --> Total execution time: 2.1775
INFO - 2024-10-24 05:48:35 --> Upload Class Initialized
INFO - 2024-10-24 05:48:35 --> Email Class Initialized
INFO - 2024-10-24 05:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:35 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:35 --> Controller Class Initialized
INFO - 2024-10-24 11:18:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:35 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:35 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:39 --> Config Class Initialized
INFO - 2024-10-24 05:48:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:39 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:39 --> URI Class Initialized
INFO - 2024-10-24 05:48:39 --> Router Class Initialized
INFO - 2024-10-24 05:48:39 --> Output Class Initialized
INFO - 2024-10-24 05:48:39 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:39 --> Input Class Initialized
INFO - 2024-10-24 05:48:39 --> Language Class Initialized
INFO - 2024-10-24 05:48:39 --> Loader Class Initialized
INFO - 2024-10-24 05:48:39 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:39 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:39 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:39 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:39 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:39 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:39 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:41 --> Upload Class Initialized
INFO - 2024-10-24 05:48:41 --> Email Class Initialized
INFO - 2024-10-24 05:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:41 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:41 --> Controller Class Initialized
INFO - 2024-10-24 11:18:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:44 --> Config Class Initialized
INFO - 2024-10-24 05:48:44 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:44 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:44 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:44 --> URI Class Initialized
INFO - 2024-10-24 05:48:44 --> Router Class Initialized
INFO - 2024-10-24 05:48:44 --> Output Class Initialized
INFO - 2024-10-24 05:48:44 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:44 --> Input Class Initialized
INFO - 2024-10-24 05:48:44 --> Language Class Initialized
INFO - 2024-10-24 05:48:44 --> Loader Class Initialized
INFO - 2024-10-24 05:48:44 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:44 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:44 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:44 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:44 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:44 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:44 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:46 --> Upload Class Initialized
INFO - 2024-10-24 05:48:46 --> Email Class Initialized
INFO - 2024-10-24 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:46 --> Controller Class Initialized
INFO - 2024-10-24 11:18:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:49 --> Config Class Initialized
INFO - 2024-10-24 05:48:49 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:49 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:49 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:49 --> URI Class Initialized
INFO - 2024-10-24 05:48:49 --> Router Class Initialized
INFO - 2024-10-24 05:48:49 --> Output Class Initialized
INFO - 2024-10-24 05:48:49 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:49 --> Input Class Initialized
INFO - 2024-10-24 05:48:49 --> Language Class Initialized
INFO - 2024-10-24 05:48:49 --> Loader Class Initialized
INFO - 2024-10-24 05:48:49 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:49 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:49 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:49 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:49 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:49 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:49 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:51 --> Upload Class Initialized
INFO - 2024-10-24 05:48:51 --> Email Class Initialized
INFO - 2024-10-24 05:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:51 --> Controller Class Initialized
INFO - 2024-10-24 11:18:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:54 --> Config Class Initialized
INFO - 2024-10-24 05:48:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:54 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:54 --> URI Class Initialized
INFO - 2024-10-24 05:48:54 --> Router Class Initialized
INFO - 2024-10-24 05:48:54 --> Output Class Initialized
INFO - 2024-10-24 05:48:54 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:54 --> Input Class Initialized
INFO - 2024-10-24 05:48:54 --> Language Class Initialized
INFO - 2024-10-24 05:48:54 --> Loader Class Initialized
INFO - 2024-10-24 05:48:54 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:54 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:54 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:54 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:54 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:54 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:54 --> Database Driver Class Initialized
INFO - 2024-10-24 05:48:56 --> Upload Class Initialized
INFO - 2024-10-24 05:48:56 --> Email Class Initialized
INFO - 2024-10-24 05:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:48:56 --> Form Validation Class Initialized
INFO - 2024-10-24 05:48:56 --> Controller Class Initialized
INFO - 2024-10-24 11:18:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:18:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:18:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:48:59 --> Config Class Initialized
INFO - 2024-10-24 05:48:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:48:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:48:59 --> Utf8 Class Initialized
INFO - 2024-10-24 05:48:59 --> URI Class Initialized
INFO - 2024-10-24 05:48:59 --> Router Class Initialized
INFO - 2024-10-24 05:48:59 --> Output Class Initialized
INFO - 2024-10-24 05:48:59 --> Security Class Initialized
DEBUG - 2024-10-24 05:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:48:59 --> Input Class Initialized
INFO - 2024-10-24 05:48:59 --> Language Class Initialized
INFO - 2024-10-24 05:48:59 --> Loader Class Initialized
INFO - 2024-10-24 05:48:59 --> Helper loaded: url_helper
INFO - 2024-10-24 05:48:59 --> Helper loaded: html_helper
INFO - 2024-10-24 05:48:59 --> Helper loaded: file_helper
INFO - 2024-10-24 05:48:59 --> Helper loaded: string_helper
INFO - 2024-10-24 05:48:59 --> Helper loaded: form_helper
INFO - 2024-10-24 05:48:59 --> Helper loaded: my_helper
INFO - 2024-10-24 05:48:59 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:01 --> Upload Class Initialized
INFO - 2024-10-24 05:49:01 --> Email Class Initialized
INFO - 2024-10-24 05:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:01 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:01 --> Controller Class Initialized
INFO - 2024-10-24 11:19:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:03 --> Config Class Initialized
INFO - 2024-10-24 05:49:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:03 --> URI Class Initialized
INFO - 2024-10-24 05:49:03 --> Router Class Initialized
INFO - 2024-10-24 05:49:03 --> Output Class Initialized
INFO - 2024-10-24 05:49:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:03 --> Input Class Initialized
INFO - 2024-10-24 05:49:03 --> Language Class Initialized
INFO - 2024-10-24 05:49:03 --> Loader Class Initialized
INFO - 2024-10-24 05:49:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:05 --> Upload Class Initialized
INFO - 2024-10-24 05:49:05 --> Email Class Initialized
INFO - 2024-10-24 05:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:05 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:05 --> Controller Class Initialized
INFO - 2024-10-24 11:19:05 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:05 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:05 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:08 --> Config Class Initialized
INFO - 2024-10-24 05:49:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:08 --> URI Class Initialized
INFO - 2024-10-24 05:49:08 --> Router Class Initialized
INFO - 2024-10-24 05:49:08 --> Output Class Initialized
INFO - 2024-10-24 05:49:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:08 --> Input Class Initialized
INFO - 2024-10-24 05:49:08 --> Language Class Initialized
INFO - 2024-10-24 05:49:08 --> Loader Class Initialized
INFO - 2024-10-24 05:49:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:10 --> Upload Class Initialized
INFO - 2024-10-24 05:49:10 --> Email Class Initialized
INFO - 2024-10-24 05:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:10 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:10 --> Controller Class Initialized
INFO - 2024-10-24 11:19:10 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:10 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:10 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:13 --> Config Class Initialized
INFO - 2024-10-24 05:49:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:13 --> URI Class Initialized
INFO - 2024-10-24 05:49:13 --> Router Class Initialized
INFO - 2024-10-24 05:49:13 --> Output Class Initialized
INFO - 2024-10-24 05:49:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:13 --> Input Class Initialized
INFO - 2024-10-24 05:49:13 --> Language Class Initialized
INFO - 2024-10-24 05:49:13 --> Loader Class Initialized
INFO - 2024-10-24 05:49:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:15 --> Upload Class Initialized
INFO - 2024-10-24 05:49:15 --> Email Class Initialized
INFO - 2024-10-24 05:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:16 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:16 --> Controller Class Initialized
INFO - 2024-10-24 11:19:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:18 --> Config Class Initialized
INFO - 2024-10-24 05:49:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:18 --> URI Class Initialized
INFO - 2024-10-24 05:49:18 --> Router Class Initialized
INFO - 2024-10-24 05:49:18 --> Output Class Initialized
INFO - 2024-10-24 05:49:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:18 --> Input Class Initialized
INFO - 2024-10-24 05:49:18 --> Language Class Initialized
INFO - 2024-10-24 05:49:18 --> Loader Class Initialized
INFO - 2024-10-24 05:49:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:20 --> Upload Class Initialized
INFO - 2024-10-24 05:49:20 --> Email Class Initialized
INFO - 2024-10-24 05:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:20 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:20 --> Controller Class Initialized
INFO - 2024-10-24 11:19:20 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:20 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:20 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:23 --> Config Class Initialized
INFO - 2024-10-24 05:49:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:23 --> URI Class Initialized
INFO - 2024-10-24 05:49:23 --> Router Class Initialized
INFO - 2024-10-24 05:49:23 --> Output Class Initialized
INFO - 2024-10-24 05:49:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:23 --> Input Class Initialized
INFO - 2024-10-24 05:49:23 --> Language Class Initialized
INFO - 2024-10-24 05:49:23 --> Loader Class Initialized
INFO - 2024-10-24 05:49:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:25 --> Upload Class Initialized
INFO - 2024-10-24 05:49:25 --> Email Class Initialized
INFO - 2024-10-24 05:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:25 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:25 --> Controller Class Initialized
INFO - 2024-10-24 11:19:25 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:25 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:28 --> Config Class Initialized
INFO - 2024-10-24 05:49:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:28 --> URI Class Initialized
INFO - 2024-10-24 05:49:28 --> Router Class Initialized
INFO - 2024-10-24 05:49:28 --> Output Class Initialized
INFO - 2024-10-24 05:49:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:28 --> Input Class Initialized
INFO - 2024-10-24 05:49:28 --> Language Class Initialized
INFO - 2024-10-24 05:49:28 --> Loader Class Initialized
INFO - 2024-10-24 05:49:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:30 --> Upload Class Initialized
INFO - 2024-10-24 05:49:30 --> Email Class Initialized
INFO - 2024-10-24 05:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:30 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:30 --> Controller Class Initialized
INFO - 2024-10-24 11:19:30 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:30 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:30 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:33 --> Config Class Initialized
INFO - 2024-10-24 05:49:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:33 --> URI Class Initialized
INFO - 2024-10-24 05:49:33 --> Router Class Initialized
INFO - 2024-10-24 05:49:33 --> Output Class Initialized
INFO - 2024-10-24 05:49:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:33 --> Input Class Initialized
INFO - 2024-10-24 05:49:33 --> Language Class Initialized
INFO - 2024-10-24 05:49:33 --> Loader Class Initialized
INFO - 2024-10-24 05:49:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:35 --> Upload Class Initialized
INFO - 2024-10-24 05:49:35 --> Email Class Initialized
INFO - 2024-10-24 05:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:36 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:36 --> Controller Class Initialized
INFO - 2024-10-24 11:19:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:38 --> Config Class Initialized
INFO - 2024-10-24 05:49:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:38 --> URI Class Initialized
INFO - 2024-10-24 05:49:38 --> Router Class Initialized
INFO - 2024-10-24 05:49:38 --> Output Class Initialized
INFO - 2024-10-24 05:49:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:38 --> Input Class Initialized
INFO - 2024-10-24 05:49:38 --> Language Class Initialized
INFO - 2024-10-24 05:49:38 --> Loader Class Initialized
INFO - 2024-10-24 05:49:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:40 --> Upload Class Initialized
INFO - 2024-10-24 05:49:40 --> Email Class Initialized
INFO - 2024-10-24 05:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:40 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:40 --> Controller Class Initialized
INFO - 2024-10-24 11:19:40 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:43 --> Config Class Initialized
INFO - 2024-10-24 05:49:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:43 --> URI Class Initialized
INFO - 2024-10-24 05:49:43 --> Router Class Initialized
INFO - 2024-10-24 05:49:43 --> Output Class Initialized
INFO - 2024-10-24 05:49:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:43 --> Input Class Initialized
INFO - 2024-10-24 05:49:43 --> Language Class Initialized
INFO - 2024-10-24 05:49:43 --> Loader Class Initialized
INFO - 2024-10-24 05:49:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:45 --> Upload Class Initialized
INFO - 2024-10-24 05:49:45 --> Email Class Initialized
INFO - 2024-10-24 05:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:45 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:45 --> Controller Class Initialized
INFO - 2024-10-24 11:19:45 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:45 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:45 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:48 --> Config Class Initialized
INFO - 2024-10-24 05:49:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:48 --> URI Class Initialized
INFO - 2024-10-24 05:49:48 --> Router Class Initialized
INFO - 2024-10-24 05:49:48 --> Output Class Initialized
INFO - 2024-10-24 05:49:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:48 --> Input Class Initialized
INFO - 2024-10-24 05:49:48 --> Language Class Initialized
INFO - 2024-10-24 05:49:48 --> Loader Class Initialized
INFO - 2024-10-24 05:49:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:50 --> Upload Class Initialized
INFO - 2024-10-24 05:49:50 --> Email Class Initialized
INFO - 2024-10-24 05:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:50 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:50 --> Controller Class Initialized
INFO - 2024-10-24 11:19:50 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:50 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:53 --> Config Class Initialized
INFO - 2024-10-24 05:49:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:53 --> URI Class Initialized
INFO - 2024-10-24 05:49:53 --> Router Class Initialized
INFO - 2024-10-24 05:49:53 --> Output Class Initialized
INFO - 2024-10-24 05:49:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:53 --> Input Class Initialized
INFO - 2024-10-24 05:49:53 --> Language Class Initialized
INFO - 2024-10-24 05:49:53 --> Loader Class Initialized
INFO - 2024-10-24 05:49:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:49:55 --> Upload Class Initialized
INFO - 2024-10-24 05:49:55 --> Email Class Initialized
INFO - 2024-10-24 05:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:49:55 --> Form Validation Class Initialized
INFO - 2024-10-24 05:49:55 --> Controller Class Initialized
INFO - 2024-10-24 11:19:55 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:19:55 --> Model "MainModel" initialized
INFO - 2024-10-24 11:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:19:55 --> Pagination Class Initialized
INFO - 2024-10-24 05:49:58 --> Config Class Initialized
INFO - 2024-10-24 05:49:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:49:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:49:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:49:58 --> URI Class Initialized
INFO - 2024-10-24 05:49:58 --> Router Class Initialized
INFO - 2024-10-24 05:49:58 --> Output Class Initialized
INFO - 2024-10-24 05:49:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:49:58 --> Input Class Initialized
INFO - 2024-10-24 05:49:58 --> Language Class Initialized
INFO - 2024-10-24 05:49:58 --> Loader Class Initialized
INFO - 2024-10-24 05:49:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:49:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:49:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:49:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:49:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:49:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:49:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:00 --> Upload Class Initialized
INFO - 2024-10-24 05:50:00 --> Email Class Initialized
INFO - 2024-10-24 05:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:00 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:00 --> Controller Class Initialized
INFO - 2024-10-24 11:20:00 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:00 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:03 --> Config Class Initialized
INFO - 2024-10-24 05:50:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:03 --> URI Class Initialized
INFO - 2024-10-24 05:50:03 --> Router Class Initialized
INFO - 2024-10-24 05:50:03 --> Output Class Initialized
INFO - 2024-10-24 05:50:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:03 --> Input Class Initialized
INFO - 2024-10-24 05:50:03 --> Language Class Initialized
INFO - 2024-10-24 05:50:03 --> Loader Class Initialized
INFO - 2024-10-24 05:50:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:06 --> Upload Class Initialized
INFO - 2024-10-24 05:50:06 --> Email Class Initialized
INFO - 2024-10-24 05:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:06 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:06 --> Controller Class Initialized
INFO - 2024-10-24 11:20:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:08 --> Config Class Initialized
INFO - 2024-10-24 05:50:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:08 --> URI Class Initialized
INFO - 2024-10-24 05:50:08 --> Router Class Initialized
INFO - 2024-10-24 05:50:08 --> Output Class Initialized
INFO - 2024-10-24 05:50:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:08 --> Input Class Initialized
INFO - 2024-10-24 05:50:08 --> Language Class Initialized
INFO - 2024-10-24 05:50:08 --> Loader Class Initialized
INFO - 2024-10-24 05:50:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:10 --> Upload Class Initialized
INFO - 2024-10-24 05:50:10 --> Email Class Initialized
INFO - 2024-10-24 05:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:10 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:10 --> Controller Class Initialized
INFO - 2024-10-24 11:20:10 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:10 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:10 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:13 --> Config Class Initialized
INFO - 2024-10-24 05:50:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:13 --> URI Class Initialized
INFO - 2024-10-24 05:50:13 --> Router Class Initialized
INFO - 2024-10-24 05:50:13 --> Output Class Initialized
INFO - 2024-10-24 05:50:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:13 --> Input Class Initialized
INFO - 2024-10-24 05:50:13 --> Language Class Initialized
INFO - 2024-10-24 05:50:13 --> Loader Class Initialized
INFO - 2024-10-24 05:50:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:15 --> Upload Class Initialized
INFO - 2024-10-24 05:50:15 --> Email Class Initialized
INFO - 2024-10-24 05:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:15 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:15 --> Controller Class Initialized
INFO - 2024-10-24 11:20:15 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:15 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:18 --> Config Class Initialized
INFO - 2024-10-24 05:50:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:18 --> URI Class Initialized
INFO - 2024-10-24 05:50:18 --> Router Class Initialized
INFO - 2024-10-24 05:50:18 --> Output Class Initialized
INFO - 2024-10-24 05:50:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:18 --> Input Class Initialized
INFO - 2024-10-24 05:50:18 --> Language Class Initialized
INFO - 2024-10-24 05:50:18 --> Loader Class Initialized
INFO - 2024-10-24 05:50:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:20 --> Upload Class Initialized
INFO - 2024-10-24 05:50:20 --> Email Class Initialized
INFO - 2024-10-24 05:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:20 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:20 --> Controller Class Initialized
INFO - 2024-10-24 11:20:20 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:20 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:20 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:23 --> Config Class Initialized
INFO - 2024-10-24 05:50:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:23 --> URI Class Initialized
INFO - 2024-10-24 05:50:23 --> Router Class Initialized
INFO - 2024-10-24 05:50:23 --> Output Class Initialized
INFO - 2024-10-24 05:50:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:23 --> Input Class Initialized
INFO - 2024-10-24 05:50:23 --> Language Class Initialized
INFO - 2024-10-24 05:50:23 --> Loader Class Initialized
INFO - 2024-10-24 05:50:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:25 --> Upload Class Initialized
INFO - 2024-10-24 05:50:25 --> Email Class Initialized
INFO - 2024-10-24 05:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:25 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:25 --> Controller Class Initialized
INFO - 2024-10-24 11:20:25 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:25 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:25 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:28 --> Config Class Initialized
INFO - 2024-10-24 05:50:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:28 --> URI Class Initialized
INFO - 2024-10-24 05:50:28 --> Router Class Initialized
INFO - 2024-10-24 05:50:28 --> Output Class Initialized
INFO - 2024-10-24 05:50:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:28 --> Input Class Initialized
INFO - 2024-10-24 05:50:28 --> Language Class Initialized
INFO - 2024-10-24 05:50:28 --> Loader Class Initialized
INFO - 2024-10-24 05:50:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:31 --> Upload Class Initialized
INFO - 2024-10-24 05:50:31 --> Email Class Initialized
INFO - 2024-10-24 05:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:31 --> Controller Class Initialized
INFO - 2024-10-24 11:20:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:33 --> Config Class Initialized
INFO - 2024-10-24 05:50:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:33 --> URI Class Initialized
INFO - 2024-10-24 05:50:33 --> Router Class Initialized
INFO - 2024-10-24 05:50:33 --> Output Class Initialized
INFO - 2024-10-24 05:50:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:33 --> Input Class Initialized
INFO - 2024-10-24 05:50:33 --> Language Class Initialized
INFO - 2024-10-24 05:50:33 --> Loader Class Initialized
INFO - 2024-10-24 05:50:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:35 --> Upload Class Initialized
INFO - 2024-10-24 05:50:35 --> Email Class Initialized
INFO - 2024-10-24 05:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:35 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:36 --> Controller Class Initialized
INFO - 2024-10-24 11:20:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:38 --> Config Class Initialized
INFO - 2024-10-24 05:50:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:38 --> URI Class Initialized
INFO - 2024-10-24 05:50:38 --> Router Class Initialized
INFO - 2024-10-24 05:50:38 --> Output Class Initialized
INFO - 2024-10-24 05:50:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:38 --> Input Class Initialized
INFO - 2024-10-24 05:50:38 --> Language Class Initialized
INFO - 2024-10-24 05:50:38 --> Loader Class Initialized
INFO - 2024-10-24 05:50:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:40 --> Upload Class Initialized
INFO - 2024-10-24 05:50:40 --> Email Class Initialized
INFO - 2024-10-24 05:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:40 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:40 --> Controller Class Initialized
INFO - 2024-10-24 11:20:40 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:40 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:40 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:43 --> Config Class Initialized
INFO - 2024-10-24 05:50:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:43 --> URI Class Initialized
INFO - 2024-10-24 05:50:43 --> Router Class Initialized
INFO - 2024-10-24 05:50:43 --> Output Class Initialized
INFO - 2024-10-24 05:50:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:43 --> Input Class Initialized
INFO - 2024-10-24 05:50:43 --> Language Class Initialized
INFO - 2024-10-24 05:50:43 --> Loader Class Initialized
INFO - 2024-10-24 05:50:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:45 --> Upload Class Initialized
INFO - 2024-10-24 05:50:45 --> Email Class Initialized
INFO - 2024-10-24 05:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:45 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:45 --> Controller Class Initialized
INFO - 2024-10-24 11:20:45 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:45 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:45 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:48 --> Config Class Initialized
INFO - 2024-10-24 05:50:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:48 --> URI Class Initialized
INFO - 2024-10-24 05:50:48 --> Router Class Initialized
INFO - 2024-10-24 05:50:48 --> Output Class Initialized
INFO - 2024-10-24 05:50:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:48 --> Input Class Initialized
INFO - 2024-10-24 05:50:48 --> Language Class Initialized
INFO - 2024-10-24 05:50:48 --> Loader Class Initialized
INFO - 2024-10-24 05:50:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:50 --> Upload Class Initialized
INFO - 2024-10-24 05:50:50 --> Email Class Initialized
INFO - 2024-10-24 05:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:50 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:50 --> Controller Class Initialized
INFO - 2024-10-24 11:20:50 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:50 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:50 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:53 --> Config Class Initialized
INFO - 2024-10-24 05:50:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:53 --> URI Class Initialized
INFO - 2024-10-24 05:50:53 --> Router Class Initialized
INFO - 2024-10-24 05:50:53 --> Output Class Initialized
INFO - 2024-10-24 05:50:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:53 --> Input Class Initialized
INFO - 2024-10-24 05:50:53 --> Language Class Initialized
INFO - 2024-10-24 05:50:53 --> Loader Class Initialized
INFO - 2024-10-24 05:50:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:50:55 --> Upload Class Initialized
INFO - 2024-10-24 05:50:55 --> Email Class Initialized
INFO - 2024-10-24 05:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:50:55 --> Form Validation Class Initialized
INFO - 2024-10-24 05:50:55 --> Controller Class Initialized
INFO - 2024-10-24 11:20:55 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:20:55 --> Model "MainModel" initialized
INFO - 2024-10-24 11:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:20:55 --> Pagination Class Initialized
INFO - 2024-10-24 05:50:58 --> Config Class Initialized
INFO - 2024-10-24 05:50:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:50:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:50:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:50:58 --> URI Class Initialized
INFO - 2024-10-24 05:50:58 --> Router Class Initialized
INFO - 2024-10-24 05:50:58 --> Output Class Initialized
INFO - 2024-10-24 05:50:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:50:58 --> Input Class Initialized
INFO - 2024-10-24 05:50:58 --> Language Class Initialized
INFO - 2024-10-24 05:50:58 --> Loader Class Initialized
INFO - 2024-10-24 05:50:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:50:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:50:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:50:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:50:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:50:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:50:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:00 --> Upload Class Initialized
INFO - 2024-10-24 05:51:00 --> Email Class Initialized
INFO - 2024-10-24 05:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:01 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:01 --> Controller Class Initialized
INFO - 2024-10-24 11:21:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:03 --> Config Class Initialized
INFO - 2024-10-24 05:51:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:03 --> URI Class Initialized
INFO - 2024-10-24 05:51:03 --> Router Class Initialized
INFO - 2024-10-24 05:51:03 --> Output Class Initialized
INFO - 2024-10-24 05:51:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:03 --> Input Class Initialized
INFO - 2024-10-24 05:51:03 --> Language Class Initialized
INFO - 2024-10-24 05:51:03 --> Loader Class Initialized
INFO - 2024-10-24 05:51:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:05 --> Upload Class Initialized
INFO - 2024-10-24 05:51:05 --> Email Class Initialized
INFO - 2024-10-24 05:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:05 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:06 --> Controller Class Initialized
INFO - 2024-10-24 11:21:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:08 --> Config Class Initialized
INFO - 2024-10-24 05:51:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:08 --> URI Class Initialized
INFO - 2024-10-24 05:51:08 --> Router Class Initialized
INFO - 2024-10-24 05:51:08 --> Output Class Initialized
INFO - 2024-10-24 05:51:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:08 --> Input Class Initialized
INFO - 2024-10-24 05:51:08 --> Language Class Initialized
INFO - 2024-10-24 05:51:08 --> Loader Class Initialized
INFO - 2024-10-24 05:51:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:10 --> Upload Class Initialized
INFO - 2024-10-24 05:51:10 --> Email Class Initialized
INFO - 2024-10-24 05:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:11 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:11 --> Controller Class Initialized
INFO - 2024-10-24 11:21:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:13 --> Config Class Initialized
INFO - 2024-10-24 05:51:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:13 --> URI Class Initialized
INFO - 2024-10-24 05:51:13 --> Router Class Initialized
INFO - 2024-10-24 05:51:13 --> Output Class Initialized
INFO - 2024-10-24 05:51:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:13 --> Input Class Initialized
INFO - 2024-10-24 05:51:13 --> Language Class Initialized
INFO - 2024-10-24 05:51:13 --> Loader Class Initialized
INFO - 2024-10-24 05:51:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:15 --> Upload Class Initialized
INFO - 2024-10-24 05:51:15 --> Email Class Initialized
INFO - 2024-10-24 05:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:15 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:15 --> Controller Class Initialized
INFO - 2024-10-24 11:21:15 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:15 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:15 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:19 --> Config Class Initialized
INFO - 2024-10-24 05:51:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:19 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:19 --> URI Class Initialized
INFO - 2024-10-24 05:51:19 --> Router Class Initialized
INFO - 2024-10-24 05:51:19 --> Output Class Initialized
INFO - 2024-10-24 05:51:19 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:19 --> Input Class Initialized
INFO - 2024-10-24 05:51:19 --> Language Class Initialized
INFO - 2024-10-24 05:51:19 --> Loader Class Initialized
INFO - 2024-10-24 05:51:19 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:19 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:19 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:19 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:19 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:19 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:19 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:21 --> Upload Class Initialized
INFO - 2024-10-24 05:51:21 --> Email Class Initialized
INFO - 2024-10-24 05:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:21 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:21 --> Controller Class Initialized
INFO - 2024-10-24 11:21:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:23 --> Config Class Initialized
INFO - 2024-10-24 05:51:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:23 --> URI Class Initialized
INFO - 2024-10-24 05:51:23 --> Router Class Initialized
INFO - 2024-10-24 05:51:23 --> Output Class Initialized
INFO - 2024-10-24 05:51:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:23 --> Input Class Initialized
INFO - 2024-10-24 05:51:23 --> Language Class Initialized
INFO - 2024-10-24 05:51:23 --> Loader Class Initialized
INFO - 2024-10-24 05:51:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:25 --> Upload Class Initialized
INFO - 2024-10-24 05:51:25 --> Email Class Initialized
INFO - 2024-10-24 05:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:26 --> Controller Class Initialized
INFO - 2024-10-24 11:21:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:28 --> Config Class Initialized
INFO - 2024-10-24 05:51:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:28 --> URI Class Initialized
INFO - 2024-10-24 05:51:28 --> Router Class Initialized
INFO - 2024-10-24 05:51:28 --> Output Class Initialized
INFO - 2024-10-24 05:51:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:28 --> Input Class Initialized
INFO - 2024-10-24 05:51:28 --> Language Class Initialized
INFO - 2024-10-24 05:51:28 --> Loader Class Initialized
INFO - 2024-10-24 05:51:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:30 --> Upload Class Initialized
INFO - 2024-10-24 05:51:30 --> Email Class Initialized
INFO - 2024-10-24 05:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:31 --> Controller Class Initialized
INFO - 2024-10-24 11:21:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:33 --> Config Class Initialized
INFO - 2024-10-24 05:51:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:33 --> URI Class Initialized
INFO - 2024-10-24 05:51:33 --> Router Class Initialized
INFO - 2024-10-24 05:51:33 --> Output Class Initialized
INFO - 2024-10-24 05:51:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:33 --> Input Class Initialized
INFO - 2024-10-24 05:51:33 --> Language Class Initialized
INFO - 2024-10-24 05:51:33 --> Loader Class Initialized
INFO - 2024-10-24 05:51:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:35 --> Upload Class Initialized
INFO - 2024-10-24 05:51:35 --> Email Class Initialized
INFO - 2024-10-24 05:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:35 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:35 --> Controller Class Initialized
INFO - 2024-10-24 11:21:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:38 --> Config Class Initialized
INFO - 2024-10-24 05:51:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:38 --> URI Class Initialized
INFO - 2024-10-24 05:51:38 --> Router Class Initialized
INFO - 2024-10-24 05:51:38 --> Output Class Initialized
INFO - 2024-10-24 05:51:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:38 --> Input Class Initialized
INFO - 2024-10-24 05:51:38 --> Language Class Initialized
INFO - 2024-10-24 05:51:38 --> Loader Class Initialized
INFO - 2024-10-24 05:51:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:40 --> Upload Class Initialized
INFO - 2024-10-24 05:51:40 --> Email Class Initialized
INFO - 2024-10-24 05:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:40 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:40 --> Controller Class Initialized
INFO - 2024-10-24 11:21:40 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:43 --> Config Class Initialized
INFO - 2024-10-24 05:51:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:43 --> URI Class Initialized
INFO - 2024-10-24 05:51:43 --> Router Class Initialized
INFO - 2024-10-24 05:51:43 --> Output Class Initialized
INFO - 2024-10-24 05:51:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:43 --> Input Class Initialized
INFO - 2024-10-24 05:51:43 --> Language Class Initialized
INFO - 2024-10-24 05:51:43 --> Loader Class Initialized
INFO - 2024-10-24 05:51:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:45 --> Upload Class Initialized
INFO - 2024-10-24 05:51:45 --> Email Class Initialized
INFO - 2024-10-24 05:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:46 --> Controller Class Initialized
INFO - 2024-10-24 11:21:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:48 --> Config Class Initialized
INFO - 2024-10-24 05:51:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:48 --> URI Class Initialized
INFO - 2024-10-24 05:51:48 --> Router Class Initialized
INFO - 2024-10-24 05:51:48 --> Output Class Initialized
INFO - 2024-10-24 05:51:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:48 --> Input Class Initialized
INFO - 2024-10-24 05:51:48 --> Language Class Initialized
INFO - 2024-10-24 05:51:48 --> Loader Class Initialized
INFO - 2024-10-24 05:51:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:50 --> Upload Class Initialized
INFO - 2024-10-24 05:51:50 --> Email Class Initialized
INFO - 2024-10-24 05:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:50 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:50 --> Controller Class Initialized
INFO - 2024-10-24 11:21:50 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:50 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:53 --> Config Class Initialized
INFO - 2024-10-24 05:51:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:53 --> URI Class Initialized
INFO - 2024-10-24 05:51:53 --> Router Class Initialized
INFO - 2024-10-24 05:51:53 --> Output Class Initialized
INFO - 2024-10-24 05:51:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:53 --> Input Class Initialized
INFO - 2024-10-24 05:51:53 --> Language Class Initialized
INFO - 2024-10-24 05:51:53 --> Loader Class Initialized
INFO - 2024-10-24 05:51:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:51:55 --> Upload Class Initialized
INFO - 2024-10-24 05:51:55 --> Email Class Initialized
INFO - 2024-10-24 05:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:51:55 --> Form Validation Class Initialized
INFO - 2024-10-24 05:51:55 --> Controller Class Initialized
INFO - 2024-10-24 11:21:55 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:21:55 --> Model "MainModel" initialized
INFO - 2024-10-24 11:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:21:55 --> Pagination Class Initialized
INFO - 2024-10-24 05:51:58 --> Config Class Initialized
INFO - 2024-10-24 05:51:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:51:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:51:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:51:58 --> URI Class Initialized
INFO - 2024-10-24 05:51:58 --> Router Class Initialized
INFO - 2024-10-24 05:51:58 --> Output Class Initialized
INFO - 2024-10-24 05:51:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:51:58 --> Input Class Initialized
INFO - 2024-10-24 05:51:58 --> Language Class Initialized
INFO - 2024-10-24 05:51:58 --> Loader Class Initialized
INFO - 2024-10-24 05:51:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:51:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:51:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:51:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:51:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:51:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:51:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:00 --> Upload Class Initialized
INFO - 2024-10-24 05:52:00 --> Email Class Initialized
INFO - 2024-10-24 05:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:00 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:00 --> Controller Class Initialized
INFO - 2024-10-24 11:22:00 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:00 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:03 --> Config Class Initialized
INFO - 2024-10-24 05:52:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:03 --> URI Class Initialized
INFO - 2024-10-24 05:52:03 --> Router Class Initialized
INFO - 2024-10-24 05:52:03 --> Output Class Initialized
INFO - 2024-10-24 05:52:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:03 --> Input Class Initialized
INFO - 2024-10-24 05:52:03 --> Language Class Initialized
INFO - 2024-10-24 05:52:03 --> Loader Class Initialized
INFO - 2024-10-24 05:52:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:05 --> Upload Class Initialized
INFO - 2024-10-24 05:52:05 --> Email Class Initialized
INFO - 2024-10-24 05:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:05 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:05 --> Controller Class Initialized
INFO - 2024-10-24 11:22:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:08 --> Config Class Initialized
INFO - 2024-10-24 05:52:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:08 --> URI Class Initialized
INFO - 2024-10-24 05:52:08 --> Router Class Initialized
INFO - 2024-10-24 05:52:08 --> Output Class Initialized
INFO - 2024-10-24 05:52:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:08 --> Input Class Initialized
INFO - 2024-10-24 05:52:08 --> Language Class Initialized
INFO - 2024-10-24 05:52:08 --> Loader Class Initialized
INFO - 2024-10-24 05:52:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:10 --> Upload Class Initialized
INFO - 2024-10-24 05:52:10 --> Email Class Initialized
INFO - 2024-10-24 05:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:10 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:10 --> Controller Class Initialized
INFO - 2024-10-24 11:22:10 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:10 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:13 --> Config Class Initialized
INFO - 2024-10-24 05:52:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:13 --> URI Class Initialized
INFO - 2024-10-24 05:52:13 --> Router Class Initialized
INFO - 2024-10-24 05:52:13 --> Output Class Initialized
INFO - 2024-10-24 05:52:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:13 --> Input Class Initialized
INFO - 2024-10-24 05:52:13 --> Language Class Initialized
INFO - 2024-10-24 05:52:13 --> Loader Class Initialized
INFO - 2024-10-24 05:52:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:16 --> Upload Class Initialized
INFO - 2024-10-24 05:52:16 --> Email Class Initialized
INFO - 2024-10-24 05:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:16 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:16 --> Controller Class Initialized
INFO - 2024-10-24 11:22:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:18 --> Config Class Initialized
INFO - 2024-10-24 05:52:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:18 --> URI Class Initialized
INFO - 2024-10-24 05:52:18 --> Router Class Initialized
INFO - 2024-10-24 05:52:18 --> Output Class Initialized
INFO - 2024-10-24 05:52:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:18 --> Input Class Initialized
INFO - 2024-10-24 05:52:18 --> Language Class Initialized
INFO - 2024-10-24 05:52:18 --> Loader Class Initialized
INFO - 2024-10-24 05:52:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:20 --> Upload Class Initialized
INFO - 2024-10-24 05:52:20 --> Email Class Initialized
INFO - 2024-10-24 05:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:20 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:20 --> Controller Class Initialized
INFO - 2024-10-24 11:22:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:23 --> Config Class Initialized
INFO - 2024-10-24 05:52:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:23 --> URI Class Initialized
INFO - 2024-10-24 05:52:23 --> Router Class Initialized
INFO - 2024-10-24 05:52:23 --> Output Class Initialized
INFO - 2024-10-24 05:52:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:23 --> Input Class Initialized
INFO - 2024-10-24 05:52:23 --> Language Class Initialized
INFO - 2024-10-24 05:52:23 --> Loader Class Initialized
INFO - 2024-10-24 05:52:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:25 --> Upload Class Initialized
INFO - 2024-10-24 05:52:25 --> Email Class Initialized
INFO - 2024-10-24 05:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:26 --> Controller Class Initialized
INFO - 2024-10-24 11:22:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:28 --> Config Class Initialized
INFO - 2024-10-24 05:52:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:29 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:29 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:29 --> URI Class Initialized
INFO - 2024-10-24 05:52:29 --> Router Class Initialized
INFO - 2024-10-24 05:52:29 --> Output Class Initialized
INFO - 2024-10-24 05:52:29 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:29 --> Input Class Initialized
INFO - 2024-10-24 05:52:29 --> Language Class Initialized
INFO - 2024-10-24 05:52:29 --> Loader Class Initialized
INFO - 2024-10-24 05:52:29 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:29 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:29 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:29 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:29 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:29 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:29 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:31 --> Upload Class Initialized
INFO - 2024-10-24 05:52:31 --> Email Class Initialized
INFO - 2024-10-24 05:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:31 --> Controller Class Initialized
INFO - 2024-10-24 11:22:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:33 --> Config Class Initialized
INFO - 2024-10-24 05:52:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:33 --> URI Class Initialized
INFO - 2024-10-24 05:52:33 --> Router Class Initialized
INFO - 2024-10-24 05:52:33 --> Output Class Initialized
INFO - 2024-10-24 05:52:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:33 --> Input Class Initialized
INFO - 2024-10-24 05:52:33 --> Language Class Initialized
INFO - 2024-10-24 05:52:33 --> Loader Class Initialized
INFO - 2024-10-24 05:52:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:35 --> Upload Class Initialized
INFO - 2024-10-24 05:52:35 --> Email Class Initialized
INFO - 2024-10-24 05:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:35 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:35 --> Controller Class Initialized
INFO - 2024-10-24 11:22:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:35 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:35 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:38 --> Config Class Initialized
INFO - 2024-10-24 05:52:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:38 --> URI Class Initialized
INFO - 2024-10-24 05:52:38 --> Router Class Initialized
INFO - 2024-10-24 05:52:38 --> Output Class Initialized
INFO - 2024-10-24 05:52:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:38 --> Input Class Initialized
INFO - 2024-10-24 05:52:38 --> Language Class Initialized
INFO - 2024-10-24 05:52:38 --> Loader Class Initialized
INFO - 2024-10-24 05:52:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:40 --> Upload Class Initialized
INFO - 2024-10-24 05:52:40 --> Email Class Initialized
INFO - 2024-10-24 05:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:40 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:40 --> Controller Class Initialized
INFO - 2024-10-24 11:22:40 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:40 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:43 --> Config Class Initialized
INFO - 2024-10-24 05:52:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:43 --> URI Class Initialized
INFO - 2024-10-24 05:52:43 --> Router Class Initialized
INFO - 2024-10-24 05:52:43 --> Output Class Initialized
INFO - 2024-10-24 05:52:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:43 --> Input Class Initialized
INFO - 2024-10-24 05:52:43 --> Language Class Initialized
INFO - 2024-10-24 05:52:43 --> Loader Class Initialized
INFO - 2024-10-24 05:52:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:45 --> Upload Class Initialized
INFO - 2024-10-24 05:52:45 --> Email Class Initialized
INFO - 2024-10-24 05:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:45 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:45 --> Controller Class Initialized
INFO - 2024-10-24 11:22:45 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:45 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:48 --> Config Class Initialized
INFO - 2024-10-24 05:52:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:48 --> URI Class Initialized
INFO - 2024-10-24 05:52:48 --> Router Class Initialized
INFO - 2024-10-24 05:52:48 --> Output Class Initialized
INFO - 2024-10-24 05:52:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:48 --> Input Class Initialized
INFO - 2024-10-24 05:52:48 --> Language Class Initialized
INFO - 2024-10-24 05:52:48 --> Loader Class Initialized
INFO - 2024-10-24 05:52:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:50 --> Upload Class Initialized
INFO - 2024-10-24 05:52:50 --> Email Class Initialized
INFO - 2024-10-24 05:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:50 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:50 --> Controller Class Initialized
INFO - 2024-10-24 11:22:50 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:50 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:53 --> Config Class Initialized
INFO - 2024-10-24 05:52:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:53 --> URI Class Initialized
INFO - 2024-10-24 05:52:53 --> Router Class Initialized
INFO - 2024-10-24 05:52:53 --> Output Class Initialized
INFO - 2024-10-24 05:52:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:53 --> Input Class Initialized
INFO - 2024-10-24 05:52:53 --> Language Class Initialized
INFO - 2024-10-24 05:52:53 --> Loader Class Initialized
INFO - 2024-10-24 05:52:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:52:55 --> Upload Class Initialized
INFO - 2024-10-24 05:52:55 --> Email Class Initialized
INFO - 2024-10-24 05:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:52:56 --> Form Validation Class Initialized
INFO - 2024-10-24 05:52:56 --> Controller Class Initialized
INFO - 2024-10-24 11:22:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:22:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:22:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:52:58 --> Config Class Initialized
INFO - 2024-10-24 05:52:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:52:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:52:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:52:58 --> URI Class Initialized
INFO - 2024-10-24 05:52:58 --> Router Class Initialized
INFO - 2024-10-24 05:52:58 --> Output Class Initialized
INFO - 2024-10-24 05:52:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:52:58 --> Input Class Initialized
INFO - 2024-10-24 05:52:58 --> Language Class Initialized
INFO - 2024-10-24 05:52:58 --> Loader Class Initialized
INFO - 2024-10-24 05:52:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:52:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:52:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:52:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:52:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:52:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:52:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:00 --> Upload Class Initialized
INFO - 2024-10-24 05:53:00 --> Email Class Initialized
INFO - 2024-10-24 05:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:01 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:01 --> Controller Class Initialized
INFO - 2024-10-24 11:23:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:03 --> Config Class Initialized
INFO - 2024-10-24 05:53:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:03 --> URI Class Initialized
INFO - 2024-10-24 05:53:03 --> Router Class Initialized
INFO - 2024-10-24 05:53:03 --> Output Class Initialized
INFO - 2024-10-24 05:53:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:03 --> Input Class Initialized
INFO - 2024-10-24 05:53:03 --> Language Class Initialized
INFO - 2024-10-24 05:53:03 --> Loader Class Initialized
INFO - 2024-10-24 05:53:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:05 --> Upload Class Initialized
INFO - 2024-10-24 05:53:05 --> Email Class Initialized
INFO - 2024-10-24 05:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:05 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:05 --> Controller Class Initialized
INFO - 2024-10-24 11:23:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:08 --> Config Class Initialized
INFO - 2024-10-24 05:53:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:08 --> URI Class Initialized
INFO - 2024-10-24 05:53:08 --> Router Class Initialized
INFO - 2024-10-24 05:53:08 --> Output Class Initialized
INFO - 2024-10-24 05:53:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:08 --> Input Class Initialized
INFO - 2024-10-24 05:53:08 --> Language Class Initialized
INFO - 2024-10-24 05:53:08 --> Loader Class Initialized
INFO - 2024-10-24 05:53:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:10 --> Upload Class Initialized
INFO - 2024-10-24 05:53:10 --> Email Class Initialized
INFO - 2024-10-24 05:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:11 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:11 --> Controller Class Initialized
INFO - 2024-10-24 11:23:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:13 --> Config Class Initialized
INFO - 2024-10-24 05:53:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:13 --> URI Class Initialized
INFO - 2024-10-24 05:53:13 --> Router Class Initialized
INFO - 2024-10-24 05:53:13 --> Output Class Initialized
INFO - 2024-10-24 05:53:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:13 --> Input Class Initialized
INFO - 2024-10-24 05:53:13 --> Language Class Initialized
INFO - 2024-10-24 05:53:13 --> Loader Class Initialized
INFO - 2024-10-24 05:53:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:15 --> Upload Class Initialized
INFO - 2024-10-24 05:53:15 --> Email Class Initialized
INFO - 2024-10-24 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:16 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:16 --> Controller Class Initialized
INFO - 2024-10-24 11:23:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:18 --> Config Class Initialized
INFO - 2024-10-24 05:53:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:18 --> URI Class Initialized
INFO - 2024-10-24 05:53:18 --> Router Class Initialized
INFO - 2024-10-24 05:53:18 --> Output Class Initialized
INFO - 2024-10-24 05:53:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:18 --> Input Class Initialized
INFO - 2024-10-24 05:53:18 --> Language Class Initialized
INFO - 2024-10-24 05:53:18 --> Loader Class Initialized
INFO - 2024-10-24 05:53:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:21 --> Upload Class Initialized
INFO - 2024-10-24 05:53:21 --> Email Class Initialized
INFO - 2024-10-24 05:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:21 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:21 --> Controller Class Initialized
INFO - 2024-10-24 11:23:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:23 --> Config Class Initialized
INFO - 2024-10-24 05:53:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:23 --> URI Class Initialized
INFO - 2024-10-24 05:53:23 --> Router Class Initialized
INFO - 2024-10-24 05:53:23 --> Output Class Initialized
INFO - 2024-10-24 05:53:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:23 --> Input Class Initialized
INFO - 2024-10-24 05:53:23 --> Language Class Initialized
INFO - 2024-10-24 05:53:23 --> Loader Class Initialized
INFO - 2024-10-24 05:53:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:25 --> Upload Class Initialized
INFO - 2024-10-24 05:53:25 --> Email Class Initialized
INFO - 2024-10-24 05:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:26 --> Controller Class Initialized
INFO - 2024-10-24 11:23:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:28 --> Config Class Initialized
INFO - 2024-10-24 05:53:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:28 --> URI Class Initialized
INFO - 2024-10-24 05:53:28 --> Router Class Initialized
INFO - 2024-10-24 05:53:28 --> Output Class Initialized
INFO - 2024-10-24 05:53:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:28 --> Input Class Initialized
INFO - 2024-10-24 05:53:28 --> Language Class Initialized
INFO - 2024-10-24 05:53:28 --> Loader Class Initialized
INFO - 2024-10-24 05:53:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:31 --> Upload Class Initialized
INFO - 2024-10-24 05:53:31 --> Email Class Initialized
INFO - 2024-10-24 05:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:31 --> Controller Class Initialized
INFO - 2024-10-24 11:23:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:33 --> Config Class Initialized
INFO - 2024-10-24 05:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:33 --> URI Class Initialized
INFO - 2024-10-24 05:53:33 --> Router Class Initialized
INFO - 2024-10-24 05:53:33 --> Output Class Initialized
INFO - 2024-10-24 05:53:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:33 --> Input Class Initialized
INFO - 2024-10-24 05:53:33 --> Language Class Initialized
INFO - 2024-10-24 05:53:33 --> Loader Class Initialized
INFO - 2024-10-24 05:53:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:35 --> Upload Class Initialized
INFO - 2024-10-24 05:53:35 --> Email Class Initialized
INFO - 2024-10-24 05:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:35 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:35 --> Controller Class Initialized
INFO - 2024-10-24 11:23:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:35 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:38 --> Config Class Initialized
INFO - 2024-10-24 05:53:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:38 --> URI Class Initialized
INFO - 2024-10-24 05:53:38 --> Router Class Initialized
INFO - 2024-10-24 05:53:38 --> Output Class Initialized
INFO - 2024-10-24 05:53:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:38 --> Input Class Initialized
INFO - 2024-10-24 05:53:38 --> Language Class Initialized
INFO - 2024-10-24 05:53:38 --> Loader Class Initialized
INFO - 2024-10-24 05:53:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:40 --> Upload Class Initialized
INFO - 2024-10-24 05:53:40 --> Email Class Initialized
INFO - 2024-10-24 05:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:40 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:40 --> Controller Class Initialized
INFO - 2024-10-24 11:23:40 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:40 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:43 --> Config Class Initialized
INFO - 2024-10-24 05:53:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:43 --> URI Class Initialized
INFO - 2024-10-24 05:53:43 --> Router Class Initialized
INFO - 2024-10-24 05:53:43 --> Output Class Initialized
INFO - 2024-10-24 05:53:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:43 --> Input Class Initialized
INFO - 2024-10-24 05:53:43 --> Language Class Initialized
INFO - 2024-10-24 05:53:43 --> Loader Class Initialized
INFO - 2024-10-24 05:53:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:45 --> Upload Class Initialized
INFO - 2024-10-24 05:53:45 --> Email Class Initialized
INFO - 2024-10-24 05:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:45 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:45 --> Controller Class Initialized
INFO - 2024-10-24 11:23:45 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:48 --> Config Class Initialized
INFO - 2024-10-24 05:53:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:48 --> URI Class Initialized
INFO - 2024-10-24 05:53:48 --> Router Class Initialized
INFO - 2024-10-24 05:53:48 --> Output Class Initialized
INFO - 2024-10-24 05:53:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:48 --> Input Class Initialized
INFO - 2024-10-24 05:53:48 --> Language Class Initialized
INFO - 2024-10-24 05:53:48 --> Loader Class Initialized
INFO - 2024-10-24 05:53:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:51 --> Upload Class Initialized
INFO - 2024-10-24 05:53:51 --> Email Class Initialized
INFO - 2024-10-24 05:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:51 --> Controller Class Initialized
INFO - 2024-10-24 11:23:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:53 --> Config Class Initialized
INFO - 2024-10-24 05:53:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:53 --> URI Class Initialized
INFO - 2024-10-24 05:53:53 --> Router Class Initialized
INFO - 2024-10-24 05:53:53 --> Output Class Initialized
INFO - 2024-10-24 05:53:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:53 --> Input Class Initialized
INFO - 2024-10-24 05:53:53 --> Language Class Initialized
INFO - 2024-10-24 05:53:53 --> Loader Class Initialized
INFO - 2024-10-24 05:53:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:53:55 --> Upload Class Initialized
INFO - 2024-10-24 05:53:55 --> Email Class Initialized
INFO - 2024-10-24 05:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:53:55 --> Form Validation Class Initialized
INFO - 2024-10-24 05:53:56 --> Controller Class Initialized
INFO - 2024-10-24 11:23:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:23:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:23:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:53:58 --> Config Class Initialized
INFO - 2024-10-24 05:53:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:53:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:53:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:53:58 --> URI Class Initialized
INFO - 2024-10-24 05:53:58 --> Router Class Initialized
INFO - 2024-10-24 05:53:58 --> Output Class Initialized
INFO - 2024-10-24 05:53:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:53:58 --> Input Class Initialized
INFO - 2024-10-24 05:53:58 --> Language Class Initialized
INFO - 2024-10-24 05:53:58 --> Loader Class Initialized
INFO - 2024-10-24 05:53:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:53:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:53:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:53:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:53:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:53:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:53:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:00 --> Upload Class Initialized
INFO - 2024-10-24 05:54:00 --> Email Class Initialized
INFO - 2024-10-24 05:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:00 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:01 --> Controller Class Initialized
INFO - 2024-10-24 11:24:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:03 --> Config Class Initialized
INFO - 2024-10-24 05:54:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:03 --> URI Class Initialized
INFO - 2024-10-24 05:54:03 --> Router Class Initialized
INFO - 2024-10-24 05:54:03 --> Output Class Initialized
INFO - 2024-10-24 05:54:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:03 --> Input Class Initialized
INFO - 2024-10-24 05:54:03 --> Language Class Initialized
INFO - 2024-10-24 05:54:03 --> Loader Class Initialized
INFO - 2024-10-24 05:54:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:05 --> Upload Class Initialized
INFO - 2024-10-24 05:54:05 --> Email Class Initialized
INFO - 2024-10-24 05:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:06 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:06 --> Controller Class Initialized
INFO - 2024-10-24 11:24:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:08 --> Config Class Initialized
INFO - 2024-10-24 05:54:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:08 --> URI Class Initialized
INFO - 2024-10-24 05:54:08 --> Router Class Initialized
INFO - 2024-10-24 05:54:08 --> Output Class Initialized
INFO - 2024-10-24 05:54:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:08 --> Input Class Initialized
INFO - 2024-10-24 05:54:08 --> Language Class Initialized
INFO - 2024-10-24 05:54:08 --> Loader Class Initialized
INFO - 2024-10-24 05:54:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:10 --> Upload Class Initialized
INFO - 2024-10-24 05:54:11 --> Email Class Initialized
INFO - 2024-10-24 05:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:11 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:11 --> Controller Class Initialized
INFO - 2024-10-24 11:24:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:13 --> Config Class Initialized
INFO - 2024-10-24 05:54:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:13 --> URI Class Initialized
INFO - 2024-10-24 05:54:13 --> Router Class Initialized
INFO - 2024-10-24 05:54:13 --> Output Class Initialized
INFO - 2024-10-24 05:54:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:13 --> Input Class Initialized
INFO - 2024-10-24 05:54:13 --> Language Class Initialized
INFO - 2024-10-24 05:54:13 --> Loader Class Initialized
INFO - 2024-10-24 05:54:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:15 --> Upload Class Initialized
INFO - 2024-10-24 05:54:15 --> Email Class Initialized
INFO - 2024-10-24 05:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:15 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:15 --> Controller Class Initialized
INFO - 2024-10-24 11:24:15 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:18 --> Config Class Initialized
INFO - 2024-10-24 05:54:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:18 --> URI Class Initialized
INFO - 2024-10-24 05:54:18 --> Router Class Initialized
INFO - 2024-10-24 05:54:18 --> Output Class Initialized
INFO - 2024-10-24 05:54:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:18 --> Input Class Initialized
INFO - 2024-10-24 05:54:18 --> Language Class Initialized
INFO - 2024-10-24 05:54:18 --> Loader Class Initialized
INFO - 2024-10-24 05:54:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:20 --> Upload Class Initialized
INFO - 2024-10-24 05:54:20 --> Email Class Initialized
INFO - 2024-10-24 05:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:20 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:20 --> Controller Class Initialized
INFO - 2024-10-24 11:24:20 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:20 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:23 --> Config Class Initialized
INFO - 2024-10-24 05:54:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:23 --> URI Class Initialized
INFO - 2024-10-24 05:54:23 --> Router Class Initialized
INFO - 2024-10-24 05:54:23 --> Output Class Initialized
INFO - 2024-10-24 05:54:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:23 --> Input Class Initialized
INFO - 2024-10-24 05:54:23 --> Language Class Initialized
INFO - 2024-10-24 05:54:23 --> Loader Class Initialized
INFO - 2024-10-24 05:54:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:26 --> Upload Class Initialized
INFO - 2024-10-24 05:54:26 --> Email Class Initialized
INFO - 2024-10-24 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:26 --> Controller Class Initialized
INFO - 2024-10-24 11:24:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:28 --> Config Class Initialized
INFO - 2024-10-24 05:54:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:28 --> URI Class Initialized
INFO - 2024-10-24 05:54:28 --> Router Class Initialized
INFO - 2024-10-24 05:54:28 --> Output Class Initialized
INFO - 2024-10-24 05:54:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:28 --> Input Class Initialized
INFO - 2024-10-24 05:54:28 --> Language Class Initialized
INFO - 2024-10-24 05:54:28 --> Loader Class Initialized
INFO - 2024-10-24 05:54:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:30 --> Upload Class Initialized
INFO - 2024-10-24 05:54:30 --> Email Class Initialized
INFO - 2024-10-24 05:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:31 --> Controller Class Initialized
INFO - 2024-10-24 11:24:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:33 --> Config Class Initialized
INFO - 2024-10-24 05:54:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:33 --> URI Class Initialized
INFO - 2024-10-24 05:54:33 --> Router Class Initialized
INFO - 2024-10-24 05:54:33 --> Output Class Initialized
INFO - 2024-10-24 05:54:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:33 --> Input Class Initialized
INFO - 2024-10-24 05:54:33 --> Language Class Initialized
INFO - 2024-10-24 05:54:33 --> Loader Class Initialized
INFO - 2024-10-24 05:54:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:35 --> Upload Class Initialized
INFO - 2024-10-24 05:54:35 --> Email Class Initialized
INFO - 2024-10-24 05:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:36 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:36 --> Controller Class Initialized
INFO - 2024-10-24 11:24:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:38 --> Config Class Initialized
INFO - 2024-10-24 05:54:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:38 --> URI Class Initialized
INFO - 2024-10-24 05:54:38 --> Router Class Initialized
INFO - 2024-10-24 05:54:38 --> Output Class Initialized
INFO - 2024-10-24 05:54:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:38 --> Input Class Initialized
INFO - 2024-10-24 05:54:38 --> Language Class Initialized
INFO - 2024-10-24 05:54:38 --> Loader Class Initialized
INFO - 2024-10-24 05:54:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:41 --> Upload Class Initialized
INFO - 2024-10-24 05:54:41 --> Email Class Initialized
INFO - 2024-10-24 05:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:41 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:41 --> Controller Class Initialized
INFO - 2024-10-24 11:24:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:43 --> Config Class Initialized
INFO - 2024-10-24 05:54:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:43 --> URI Class Initialized
INFO - 2024-10-24 05:54:43 --> Router Class Initialized
INFO - 2024-10-24 05:54:43 --> Output Class Initialized
INFO - 2024-10-24 05:54:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:43 --> Input Class Initialized
INFO - 2024-10-24 05:54:43 --> Language Class Initialized
INFO - 2024-10-24 05:54:43 --> Loader Class Initialized
INFO - 2024-10-24 05:54:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:46 --> Upload Class Initialized
INFO - 2024-10-24 05:54:46 --> Email Class Initialized
INFO - 2024-10-24 05:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:46 --> Controller Class Initialized
INFO - 2024-10-24 11:24:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:48 --> Config Class Initialized
INFO - 2024-10-24 05:54:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:48 --> URI Class Initialized
INFO - 2024-10-24 05:54:48 --> Router Class Initialized
INFO - 2024-10-24 05:54:48 --> Output Class Initialized
INFO - 2024-10-24 05:54:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:48 --> Input Class Initialized
INFO - 2024-10-24 05:54:48 --> Language Class Initialized
INFO - 2024-10-24 05:54:48 --> Loader Class Initialized
INFO - 2024-10-24 05:54:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:50 --> Upload Class Initialized
INFO - 2024-10-24 05:54:50 --> Email Class Initialized
INFO - 2024-10-24 05:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:50 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:50 --> Controller Class Initialized
INFO - 2024-10-24 11:24:50 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:53 --> Config Class Initialized
INFO - 2024-10-24 05:54:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:53 --> URI Class Initialized
INFO - 2024-10-24 05:54:53 --> Router Class Initialized
INFO - 2024-10-24 05:54:53 --> Output Class Initialized
INFO - 2024-10-24 05:54:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:53 --> Input Class Initialized
INFO - 2024-10-24 05:54:53 --> Language Class Initialized
INFO - 2024-10-24 05:54:53 --> Loader Class Initialized
INFO - 2024-10-24 05:54:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:54:55 --> Upload Class Initialized
INFO - 2024-10-24 05:54:55 --> Email Class Initialized
INFO - 2024-10-24 05:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:54:55 --> Form Validation Class Initialized
INFO - 2024-10-24 05:54:55 --> Controller Class Initialized
INFO - 2024-10-24 11:24:55 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:24:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:24:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:54:58 --> Config Class Initialized
INFO - 2024-10-24 05:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:54:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:54:58 --> URI Class Initialized
INFO - 2024-10-24 05:54:58 --> Router Class Initialized
INFO - 2024-10-24 05:54:58 --> Output Class Initialized
INFO - 2024-10-24 05:54:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:54:58 --> Input Class Initialized
INFO - 2024-10-24 05:54:58 --> Language Class Initialized
INFO - 2024-10-24 05:54:58 --> Loader Class Initialized
INFO - 2024-10-24 05:54:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:54:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:54:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:54:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:54:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:54:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:54:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:00 --> Upload Class Initialized
INFO - 2024-10-24 05:55:01 --> Email Class Initialized
INFO - 2024-10-24 05:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:01 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:01 --> Controller Class Initialized
INFO - 2024-10-24 11:25:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:03 --> Config Class Initialized
INFO - 2024-10-24 05:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:03 --> URI Class Initialized
INFO - 2024-10-24 05:55:03 --> Router Class Initialized
INFO - 2024-10-24 05:55:03 --> Output Class Initialized
INFO - 2024-10-24 05:55:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:03 --> Input Class Initialized
INFO - 2024-10-24 05:55:03 --> Language Class Initialized
INFO - 2024-10-24 05:55:03 --> Loader Class Initialized
INFO - 2024-10-24 05:55:04 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:04 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:04 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:04 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:04 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:04 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:04 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:06 --> Upload Class Initialized
INFO - 2024-10-24 05:55:06 --> Email Class Initialized
INFO - 2024-10-24 05:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:06 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:06 --> Controller Class Initialized
INFO - 2024-10-24 11:25:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:08 --> Config Class Initialized
INFO - 2024-10-24 05:55:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:08 --> URI Class Initialized
INFO - 2024-10-24 05:55:08 --> Router Class Initialized
INFO - 2024-10-24 05:55:08 --> Output Class Initialized
INFO - 2024-10-24 05:55:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:08 --> Input Class Initialized
INFO - 2024-10-24 05:55:08 --> Language Class Initialized
INFO - 2024-10-24 05:55:08 --> Loader Class Initialized
INFO - 2024-10-24 05:55:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:10 --> Upload Class Initialized
INFO - 2024-10-24 05:55:11 --> Email Class Initialized
INFO - 2024-10-24 05:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:11 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:11 --> Controller Class Initialized
INFO - 2024-10-24 11:25:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:13 --> Config Class Initialized
INFO - 2024-10-24 05:55:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:13 --> URI Class Initialized
INFO - 2024-10-24 05:55:13 --> Router Class Initialized
INFO - 2024-10-24 05:55:13 --> Output Class Initialized
INFO - 2024-10-24 05:55:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:13 --> Input Class Initialized
INFO - 2024-10-24 05:55:13 --> Language Class Initialized
INFO - 2024-10-24 05:55:13 --> Loader Class Initialized
INFO - 2024-10-24 05:55:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:15 --> Upload Class Initialized
INFO - 2024-10-24 05:55:16 --> Email Class Initialized
INFO - 2024-10-24 05:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:16 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:16 --> Controller Class Initialized
INFO - 2024-10-24 11:25:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:18 --> Config Class Initialized
INFO - 2024-10-24 05:55:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:18 --> URI Class Initialized
INFO - 2024-10-24 05:55:18 --> Router Class Initialized
INFO - 2024-10-24 05:55:18 --> Output Class Initialized
INFO - 2024-10-24 05:55:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:18 --> Input Class Initialized
INFO - 2024-10-24 05:55:18 --> Language Class Initialized
INFO - 2024-10-24 05:55:18 --> Loader Class Initialized
INFO - 2024-10-24 05:55:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:20 --> Upload Class Initialized
INFO - 2024-10-24 05:55:20 --> Email Class Initialized
INFO - 2024-10-24 05:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:21 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:21 --> Controller Class Initialized
INFO - 2024-10-24 11:25:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:23 --> Config Class Initialized
INFO - 2024-10-24 05:55:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:23 --> URI Class Initialized
INFO - 2024-10-24 05:55:23 --> Router Class Initialized
INFO - 2024-10-24 05:55:23 --> Output Class Initialized
INFO - 2024-10-24 05:55:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:23 --> Input Class Initialized
INFO - 2024-10-24 05:55:23 --> Language Class Initialized
INFO - 2024-10-24 05:55:23 --> Loader Class Initialized
INFO - 2024-10-24 05:55:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:26 --> Upload Class Initialized
INFO - 2024-10-24 05:55:26 --> Email Class Initialized
INFO - 2024-10-24 05:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:26 --> Controller Class Initialized
INFO - 2024-10-24 11:25:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:28 --> Config Class Initialized
INFO - 2024-10-24 05:55:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:28 --> URI Class Initialized
INFO - 2024-10-24 05:55:28 --> Router Class Initialized
INFO - 2024-10-24 05:55:28 --> Output Class Initialized
INFO - 2024-10-24 05:55:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:28 --> Input Class Initialized
INFO - 2024-10-24 05:55:28 --> Language Class Initialized
INFO - 2024-10-24 05:55:28 --> Loader Class Initialized
INFO - 2024-10-24 05:55:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:30 --> Upload Class Initialized
INFO - 2024-10-24 05:55:30 --> Email Class Initialized
INFO - 2024-10-24 05:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:30 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:30 --> Controller Class Initialized
INFO - 2024-10-24 11:25:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:33 --> Config Class Initialized
INFO - 2024-10-24 05:55:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:33 --> URI Class Initialized
INFO - 2024-10-24 05:55:33 --> Router Class Initialized
INFO - 2024-10-24 05:55:33 --> Output Class Initialized
INFO - 2024-10-24 05:55:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:33 --> Input Class Initialized
INFO - 2024-10-24 05:55:33 --> Language Class Initialized
INFO - 2024-10-24 05:55:33 --> Loader Class Initialized
INFO - 2024-10-24 05:55:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:35 --> Upload Class Initialized
INFO - 2024-10-24 05:55:35 --> Email Class Initialized
INFO - 2024-10-24 05:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:35 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:36 --> Controller Class Initialized
INFO - 2024-10-24 11:25:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:38 --> Config Class Initialized
INFO - 2024-10-24 05:55:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:38 --> URI Class Initialized
INFO - 2024-10-24 05:55:38 --> Router Class Initialized
INFO - 2024-10-24 05:55:38 --> Output Class Initialized
INFO - 2024-10-24 05:55:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:38 --> Input Class Initialized
INFO - 2024-10-24 05:55:38 --> Language Class Initialized
INFO - 2024-10-24 05:55:38 --> Loader Class Initialized
INFO - 2024-10-24 05:55:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:41 --> Upload Class Initialized
INFO - 2024-10-24 05:55:41 --> Email Class Initialized
INFO - 2024-10-24 05:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:41 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:41 --> Controller Class Initialized
INFO - 2024-10-24 11:25:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:43 --> Config Class Initialized
INFO - 2024-10-24 05:55:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:43 --> URI Class Initialized
INFO - 2024-10-24 05:55:43 --> Router Class Initialized
INFO - 2024-10-24 05:55:43 --> Output Class Initialized
INFO - 2024-10-24 05:55:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:43 --> Input Class Initialized
INFO - 2024-10-24 05:55:43 --> Language Class Initialized
INFO - 2024-10-24 05:55:43 --> Loader Class Initialized
INFO - 2024-10-24 05:55:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:46 --> Upload Class Initialized
INFO - 2024-10-24 05:55:46 --> Email Class Initialized
INFO - 2024-10-24 05:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:46 --> Controller Class Initialized
INFO - 2024-10-24 11:25:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:48 --> Config Class Initialized
INFO - 2024-10-24 05:55:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:48 --> URI Class Initialized
INFO - 2024-10-24 05:55:48 --> Router Class Initialized
INFO - 2024-10-24 05:55:48 --> Output Class Initialized
INFO - 2024-10-24 05:55:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:48 --> Input Class Initialized
INFO - 2024-10-24 05:55:48 --> Language Class Initialized
INFO - 2024-10-24 05:55:48 --> Loader Class Initialized
INFO - 2024-10-24 05:55:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:51 --> Upload Class Initialized
INFO - 2024-10-24 05:55:51 --> Email Class Initialized
INFO - 2024-10-24 05:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:51 --> Controller Class Initialized
INFO - 2024-10-24 11:25:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:53 --> Config Class Initialized
INFO - 2024-10-24 05:55:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:53 --> URI Class Initialized
INFO - 2024-10-24 05:55:53 --> Router Class Initialized
INFO - 2024-10-24 05:55:53 --> Output Class Initialized
INFO - 2024-10-24 05:55:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:53 --> Input Class Initialized
INFO - 2024-10-24 05:55:53 --> Language Class Initialized
INFO - 2024-10-24 05:55:53 --> Loader Class Initialized
INFO - 2024-10-24 05:55:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:55:55 --> Upload Class Initialized
INFO - 2024-10-24 05:55:55 --> Email Class Initialized
INFO - 2024-10-24 05:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:55:55 --> Form Validation Class Initialized
INFO - 2024-10-24 05:55:55 --> Controller Class Initialized
INFO - 2024-10-24 11:25:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:25:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:25:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:55:58 --> Config Class Initialized
INFO - 2024-10-24 05:55:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:55:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:55:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:55:58 --> URI Class Initialized
INFO - 2024-10-24 05:55:58 --> Router Class Initialized
INFO - 2024-10-24 05:55:58 --> Output Class Initialized
INFO - 2024-10-24 05:55:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:55:58 --> Input Class Initialized
INFO - 2024-10-24 05:55:58 --> Language Class Initialized
INFO - 2024-10-24 05:55:58 --> Loader Class Initialized
INFO - 2024-10-24 05:55:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:55:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:55:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:55:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:55:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:55:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:55:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:01 --> Upload Class Initialized
INFO - 2024-10-24 05:56:01 --> Email Class Initialized
INFO - 2024-10-24 05:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:01 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:01 --> Controller Class Initialized
INFO - 2024-10-24 11:26:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:03 --> Config Class Initialized
INFO - 2024-10-24 05:56:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:03 --> URI Class Initialized
INFO - 2024-10-24 05:56:03 --> Router Class Initialized
INFO - 2024-10-24 05:56:03 --> Output Class Initialized
INFO - 2024-10-24 05:56:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:03 --> Input Class Initialized
INFO - 2024-10-24 05:56:03 --> Language Class Initialized
INFO - 2024-10-24 05:56:03 --> Loader Class Initialized
INFO - 2024-10-24 05:56:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:06 --> Upload Class Initialized
INFO - 2024-10-24 05:56:06 --> Email Class Initialized
INFO - 2024-10-24 05:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:06 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:06 --> Controller Class Initialized
INFO - 2024-10-24 11:26:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:08 --> Config Class Initialized
INFO - 2024-10-24 05:56:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:08 --> URI Class Initialized
INFO - 2024-10-24 05:56:08 --> Router Class Initialized
INFO - 2024-10-24 05:56:08 --> Output Class Initialized
INFO - 2024-10-24 05:56:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:08 --> Input Class Initialized
INFO - 2024-10-24 05:56:08 --> Language Class Initialized
INFO - 2024-10-24 05:56:08 --> Loader Class Initialized
INFO - 2024-10-24 05:56:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:10 --> Upload Class Initialized
INFO - 2024-10-24 05:56:10 --> Email Class Initialized
INFO - 2024-10-24 05:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:10 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:10 --> Controller Class Initialized
INFO - 2024-10-24 11:26:10 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:13 --> Config Class Initialized
INFO - 2024-10-24 05:56:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:13 --> URI Class Initialized
INFO - 2024-10-24 05:56:13 --> Router Class Initialized
INFO - 2024-10-24 05:56:13 --> Output Class Initialized
INFO - 2024-10-24 05:56:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:13 --> Input Class Initialized
INFO - 2024-10-24 05:56:13 --> Language Class Initialized
INFO - 2024-10-24 05:56:13 --> Loader Class Initialized
INFO - 2024-10-24 05:56:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:15 --> Upload Class Initialized
INFO - 2024-10-24 05:56:15 --> Email Class Initialized
INFO - 2024-10-24 05:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:15 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:16 --> Controller Class Initialized
INFO - 2024-10-24 11:26:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:18 --> Config Class Initialized
INFO - 2024-10-24 05:56:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:18 --> URI Class Initialized
INFO - 2024-10-24 05:56:18 --> Router Class Initialized
INFO - 2024-10-24 05:56:18 --> Output Class Initialized
INFO - 2024-10-24 05:56:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:18 --> Input Class Initialized
INFO - 2024-10-24 05:56:18 --> Language Class Initialized
INFO - 2024-10-24 05:56:18 --> Loader Class Initialized
INFO - 2024-10-24 05:56:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:21 --> Upload Class Initialized
INFO - 2024-10-24 05:56:21 --> Email Class Initialized
INFO - 2024-10-24 05:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:21 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:21 --> Controller Class Initialized
INFO - 2024-10-24 11:26:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:23 --> Config Class Initialized
INFO - 2024-10-24 05:56:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:23 --> URI Class Initialized
INFO - 2024-10-24 05:56:23 --> Router Class Initialized
INFO - 2024-10-24 05:56:23 --> Output Class Initialized
INFO - 2024-10-24 05:56:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:23 --> Input Class Initialized
INFO - 2024-10-24 05:56:23 --> Language Class Initialized
INFO - 2024-10-24 05:56:23 --> Loader Class Initialized
INFO - 2024-10-24 05:56:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:25 --> Upload Class Initialized
INFO - 2024-10-24 05:56:25 --> Email Class Initialized
INFO - 2024-10-24 05:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:25 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:25 --> Controller Class Initialized
INFO - 2024-10-24 11:26:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:28 --> Config Class Initialized
INFO - 2024-10-24 05:56:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:28 --> URI Class Initialized
INFO - 2024-10-24 05:56:28 --> Router Class Initialized
INFO - 2024-10-24 05:56:28 --> Output Class Initialized
INFO - 2024-10-24 05:56:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:28 --> Input Class Initialized
INFO - 2024-10-24 05:56:28 --> Language Class Initialized
INFO - 2024-10-24 05:56:28 --> Loader Class Initialized
INFO - 2024-10-24 05:56:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:31 --> Upload Class Initialized
INFO - 2024-10-24 05:56:31 --> Email Class Initialized
INFO - 2024-10-24 05:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:31 --> Controller Class Initialized
INFO - 2024-10-24 11:26:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:33 --> Config Class Initialized
INFO - 2024-10-24 05:56:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:33 --> URI Class Initialized
INFO - 2024-10-24 05:56:33 --> Router Class Initialized
INFO - 2024-10-24 05:56:33 --> Output Class Initialized
INFO - 2024-10-24 05:56:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:33 --> Input Class Initialized
INFO - 2024-10-24 05:56:33 --> Language Class Initialized
INFO - 2024-10-24 05:56:33 --> Loader Class Initialized
INFO - 2024-10-24 05:56:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:36 --> Upload Class Initialized
INFO - 2024-10-24 05:56:36 --> Email Class Initialized
INFO - 2024-10-24 05:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:36 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:36 --> Controller Class Initialized
INFO - 2024-10-24 11:26:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:38 --> Config Class Initialized
INFO - 2024-10-24 05:56:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:38 --> URI Class Initialized
INFO - 2024-10-24 05:56:38 --> Router Class Initialized
INFO - 2024-10-24 05:56:38 --> Output Class Initialized
INFO - 2024-10-24 05:56:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:38 --> Input Class Initialized
INFO - 2024-10-24 05:56:38 --> Language Class Initialized
INFO - 2024-10-24 05:56:38 --> Loader Class Initialized
INFO - 2024-10-24 05:56:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:40 --> Upload Class Initialized
INFO - 2024-10-24 05:56:40 --> Email Class Initialized
INFO - 2024-10-24 05:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:40 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:41 --> Controller Class Initialized
INFO - 2024-10-24 11:26:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:43 --> Config Class Initialized
INFO - 2024-10-24 05:56:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:43 --> URI Class Initialized
INFO - 2024-10-24 05:56:43 --> Router Class Initialized
INFO - 2024-10-24 05:56:43 --> Output Class Initialized
INFO - 2024-10-24 05:56:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:43 --> Input Class Initialized
INFO - 2024-10-24 05:56:43 --> Language Class Initialized
INFO - 2024-10-24 05:56:43 --> Loader Class Initialized
INFO - 2024-10-24 05:56:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:45 --> Upload Class Initialized
INFO - 2024-10-24 05:56:45 --> Email Class Initialized
INFO - 2024-10-24 05:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:46 --> Controller Class Initialized
INFO - 2024-10-24 11:26:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:48 --> Config Class Initialized
INFO - 2024-10-24 05:56:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:48 --> URI Class Initialized
INFO - 2024-10-24 05:56:48 --> Router Class Initialized
INFO - 2024-10-24 05:56:48 --> Output Class Initialized
INFO - 2024-10-24 05:56:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:48 --> Input Class Initialized
INFO - 2024-10-24 05:56:48 --> Language Class Initialized
INFO - 2024-10-24 05:56:48 --> Loader Class Initialized
INFO - 2024-10-24 05:56:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:50 --> Upload Class Initialized
INFO - 2024-10-24 05:56:51 --> Email Class Initialized
INFO - 2024-10-24 05:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:51 --> Controller Class Initialized
INFO - 2024-10-24 11:26:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:53 --> Config Class Initialized
INFO - 2024-10-24 05:56:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:53 --> URI Class Initialized
INFO - 2024-10-24 05:56:53 --> Router Class Initialized
INFO - 2024-10-24 05:56:53 --> Output Class Initialized
INFO - 2024-10-24 05:56:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:53 --> Input Class Initialized
INFO - 2024-10-24 05:56:53 --> Language Class Initialized
INFO - 2024-10-24 05:56:53 --> Loader Class Initialized
INFO - 2024-10-24 05:56:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:56:55 --> Upload Class Initialized
INFO - 2024-10-24 05:56:55 --> Email Class Initialized
INFO - 2024-10-24 05:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:56:55 --> Form Validation Class Initialized
INFO - 2024-10-24 05:56:56 --> Controller Class Initialized
INFO - 2024-10-24 11:26:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:26:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:26:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:56:58 --> Config Class Initialized
INFO - 2024-10-24 05:56:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:56:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:56:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:56:58 --> URI Class Initialized
INFO - 2024-10-24 05:56:58 --> Router Class Initialized
INFO - 2024-10-24 05:56:58 --> Output Class Initialized
INFO - 2024-10-24 05:56:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:56:58 --> Input Class Initialized
INFO - 2024-10-24 05:56:58 --> Language Class Initialized
INFO - 2024-10-24 05:56:58 --> Loader Class Initialized
INFO - 2024-10-24 05:56:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:56:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:56:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:56:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:56:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:56:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:56:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:00 --> Upload Class Initialized
INFO - 2024-10-24 05:57:00 --> Email Class Initialized
INFO - 2024-10-24 05:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:00 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:00 --> Controller Class Initialized
INFO - 2024-10-24 11:27:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:03 --> Config Class Initialized
INFO - 2024-10-24 05:57:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:03 --> URI Class Initialized
INFO - 2024-10-24 05:57:03 --> Router Class Initialized
INFO - 2024-10-24 05:57:03 --> Output Class Initialized
INFO - 2024-10-24 05:57:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:03 --> Input Class Initialized
INFO - 2024-10-24 05:57:03 --> Language Class Initialized
INFO - 2024-10-24 05:57:03 --> Loader Class Initialized
INFO - 2024-10-24 05:57:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:05 --> Upload Class Initialized
INFO - 2024-10-24 05:57:05 --> Email Class Initialized
INFO - 2024-10-24 05:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:05 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:06 --> Controller Class Initialized
INFO - 2024-10-24 11:27:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:08 --> Config Class Initialized
INFO - 2024-10-24 05:57:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:08 --> URI Class Initialized
INFO - 2024-10-24 05:57:08 --> Router Class Initialized
INFO - 2024-10-24 05:57:08 --> Output Class Initialized
INFO - 2024-10-24 05:57:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:08 --> Input Class Initialized
INFO - 2024-10-24 05:57:08 --> Language Class Initialized
INFO - 2024-10-24 05:57:08 --> Loader Class Initialized
INFO - 2024-10-24 05:57:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:11 --> Upload Class Initialized
INFO - 2024-10-24 05:57:11 --> Email Class Initialized
INFO - 2024-10-24 05:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:11 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:11 --> Controller Class Initialized
INFO - 2024-10-24 11:27:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:13 --> Config Class Initialized
INFO - 2024-10-24 05:57:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:13 --> URI Class Initialized
INFO - 2024-10-24 05:57:13 --> Router Class Initialized
INFO - 2024-10-24 05:57:13 --> Output Class Initialized
INFO - 2024-10-24 05:57:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:13 --> Input Class Initialized
INFO - 2024-10-24 05:57:13 --> Language Class Initialized
INFO - 2024-10-24 05:57:13 --> Loader Class Initialized
INFO - 2024-10-24 05:57:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:16 --> Upload Class Initialized
INFO - 2024-10-24 05:57:16 --> Email Class Initialized
INFO - 2024-10-24 05:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:16 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:16 --> Controller Class Initialized
INFO - 2024-10-24 11:27:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:18 --> Config Class Initialized
INFO - 2024-10-24 05:57:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:18 --> URI Class Initialized
INFO - 2024-10-24 05:57:18 --> Router Class Initialized
INFO - 2024-10-24 05:57:18 --> Output Class Initialized
INFO - 2024-10-24 05:57:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:18 --> Input Class Initialized
INFO - 2024-10-24 05:57:18 --> Language Class Initialized
INFO - 2024-10-24 05:57:18 --> Loader Class Initialized
INFO - 2024-10-24 05:57:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:21 --> Upload Class Initialized
INFO - 2024-10-24 05:57:21 --> Email Class Initialized
INFO - 2024-10-24 05:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:21 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:21 --> Controller Class Initialized
INFO - 2024-10-24 11:27:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:23 --> Config Class Initialized
INFO - 2024-10-24 05:57:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:23 --> URI Class Initialized
INFO - 2024-10-24 05:57:23 --> Router Class Initialized
INFO - 2024-10-24 05:57:23 --> Output Class Initialized
INFO - 2024-10-24 05:57:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:23 --> Input Class Initialized
INFO - 2024-10-24 05:57:23 --> Language Class Initialized
INFO - 2024-10-24 05:57:23 --> Loader Class Initialized
INFO - 2024-10-24 05:57:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:25 --> Upload Class Initialized
INFO - 2024-10-24 05:57:25 --> Email Class Initialized
INFO - 2024-10-24 05:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:26 --> Controller Class Initialized
INFO - 2024-10-24 11:27:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:28 --> Config Class Initialized
INFO - 2024-10-24 05:57:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:28 --> URI Class Initialized
INFO - 2024-10-24 05:57:28 --> Router Class Initialized
INFO - 2024-10-24 05:57:28 --> Output Class Initialized
INFO - 2024-10-24 05:57:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:28 --> Input Class Initialized
INFO - 2024-10-24 05:57:28 --> Language Class Initialized
INFO - 2024-10-24 05:57:28 --> Loader Class Initialized
INFO - 2024-10-24 05:57:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:30 --> Upload Class Initialized
INFO - 2024-10-24 05:57:30 --> Email Class Initialized
INFO - 2024-10-24 05:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:31 --> Controller Class Initialized
INFO - 2024-10-24 11:27:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:33 --> Config Class Initialized
INFO - 2024-10-24 05:57:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:33 --> URI Class Initialized
INFO - 2024-10-24 05:57:33 --> Router Class Initialized
INFO - 2024-10-24 05:57:33 --> Output Class Initialized
INFO - 2024-10-24 05:57:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:33 --> Input Class Initialized
INFO - 2024-10-24 05:57:33 --> Language Class Initialized
INFO - 2024-10-24 05:57:33 --> Loader Class Initialized
INFO - 2024-10-24 05:57:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:36 --> Upload Class Initialized
INFO - 2024-10-24 05:57:36 --> Email Class Initialized
INFO - 2024-10-24 05:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:36 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:36 --> Controller Class Initialized
INFO - 2024-10-24 11:27:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:38 --> Config Class Initialized
INFO - 2024-10-24 05:57:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:38 --> URI Class Initialized
INFO - 2024-10-24 05:57:38 --> Router Class Initialized
INFO - 2024-10-24 05:57:38 --> Output Class Initialized
INFO - 2024-10-24 05:57:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:38 --> Input Class Initialized
INFO - 2024-10-24 05:57:38 --> Language Class Initialized
INFO - 2024-10-24 05:57:38 --> Loader Class Initialized
INFO - 2024-10-24 05:57:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:40 --> Upload Class Initialized
INFO - 2024-10-24 05:57:40 --> Email Class Initialized
INFO - 2024-10-24 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:40 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:41 --> Controller Class Initialized
INFO - 2024-10-24 11:27:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:43 --> Config Class Initialized
INFO - 2024-10-24 05:57:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:43 --> URI Class Initialized
INFO - 2024-10-24 05:57:43 --> Router Class Initialized
INFO - 2024-10-24 05:57:43 --> Output Class Initialized
INFO - 2024-10-24 05:57:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:43 --> Input Class Initialized
INFO - 2024-10-24 05:57:43 --> Language Class Initialized
INFO - 2024-10-24 05:57:43 --> Loader Class Initialized
INFO - 2024-10-24 05:57:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:45 --> Upload Class Initialized
INFO - 2024-10-24 05:57:45 --> Email Class Initialized
INFO - 2024-10-24 05:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:46 --> Controller Class Initialized
INFO - 2024-10-24 11:27:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:48 --> Config Class Initialized
INFO - 2024-10-24 05:57:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:48 --> URI Class Initialized
INFO - 2024-10-24 05:57:48 --> Router Class Initialized
INFO - 2024-10-24 05:57:48 --> Output Class Initialized
INFO - 2024-10-24 05:57:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:48 --> Input Class Initialized
INFO - 2024-10-24 05:57:48 --> Language Class Initialized
INFO - 2024-10-24 05:57:48 --> Loader Class Initialized
INFO - 2024-10-24 05:57:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:51 --> Upload Class Initialized
INFO - 2024-10-24 05:57:51 --> Email Class Initialized
INFO - 2024-10-24 05:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:51 --> Controller Class Initialized
INFO - 2024-10-24 11:27:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:53 --> Config Class Initialized
INFO - 2024-10-24 05:57:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:53 --> URI Class Initialized
INFO - 2024-10-24 05:57:53 --> Router Class Initialized
INFO - 2024-10-24 05:57:53 --> Output Class Initialized
INFO - 2024-10-24 05:57:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:53 --> Input Class Initialized
INFO - 2024-10-24 05:57:53 --> Language Class Initialized
INFO - 2024-10-24 05:57:53 --> Loader Class Initialized
INFO - 2024-10-24 05:57:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:57:56 --> Upload Class Initialized
INFO - 2024-10-24 05:57:56 --> Email Class Initialized
INFO - 2024-10-24 05:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:57:56 --> Form Validation Class Initialized
INFO - 2024-10-24 05:57:56 --> Controller Class Initialized
INFO - 2024-10-24 11:27:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:27:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:27:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:57:58 --> Config Class Initialized
INFO - 2024-10-24 05:57:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:57:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:57:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:57:58 --> URI Class Initialized
INFO - 2024-10-24 05:57:58 --> Router Class Initialized
INFO - 2024-10-24 05:57:58 --> Output Class Initialized
INFO - 2024-10-24 05:57:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:57:58 --> Input Class Initialized
INFO - 2024-10-24 05:57:58 --> Language Class Initialized
INFO - 2024-10-24 05:57:58 --> Loader Class Initialized
INFO - 2024-10-24 05:57:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:57:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:57:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:57:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:57:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:57:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:57:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:00 --> Upload Class Initialized
INFO - 2024-10-24 05:58:00 --> Email Class Initialized
INFO - 2024-10-24 05:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:01 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:01 --> Controller Class Initialized
INFO - 2024-10-24 11:28:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:03 --> Config Class Initialized
INFO - 2024-10-24 05:58:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:03 --> URI Class Initialized
INFO - 2024-10-24 05:58:03 --> Router Class Initialized
INFO - 2024-10-24 05:58:03 --> Output Class Initialized
INFO - 2024-10-24 05:58:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:03 --> Input Class Initialized
INFO - 2024-10-24 05:58:03 --> Language Class Initialized
INFO - 2024-10-24 05:58:03 --> Loader Class Initialized
INFO - 2024-10-24 05:58:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:03 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:05 --> Upload Class Initialized
INFO - 2024-10-24 05:58:05 --> Email Class Initialized
INFO - 2024-10-24 05:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:05 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:06 --> Controller Class Initialized
INFO - 2024-10-24 11:28:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:08 --> Config Class Initialized
INFO - 2024-10-24 05:58:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:08 --> URI Class Initialized
INFO - 2024-10-24 05:58:08 --> Router Class Initialized
INFO - 2024-10-24 05:58:08 --> Output Class Initialized
INFO - 2024-10-24 05:58:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:08 --> Input Class Initialized
INFO - 2024-10-24 05:58:08 --> Language Class Initialized
INFO - 2024-10-24 05:58:08 --> Loader Class Initialized
INFO - 2024-10-24 05:58:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:10 --> Upload Class Initialized
INFO - 2024-10-24 05:58:10 --> Email Class Initialized
INFO - 2024-10-24 05:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:10 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:11 --> Controller Class Initialized
INFO - 2024-10-24 11:28:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:13 --> Config Class Initialized
INFO - 2024-10-24 05:58:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:13 --> URI Class Initialized
INFO - 2024-10-24 05:58:13 --> Router Class Initialized
INFO - 2024-10-24 05:58:13 --> Output Class Initialized
INFO - 2024-10-24 05:58:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:13 --> Input Class Initialized
INFO - 2024-10-24 05:58:13 --> Language Class Initialized
INFO - 2024-10-24 05:58:13 --> Loader Class Initialized
INFO - 2024-10-24 05:58:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:16 --> Upload Class Initialized
INFO - 2024-10-24 05:58:16 --> Email Class Initialized
INFO - 2024-10-24 05:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:16 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:16 --> Controller Class Initialized
INFO - 2024-10-24 11:28:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:18 --> Config Class Initialized
INFO - 2024-10-24 05:58:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:18 --> URI Class Initialized
INFO - 2024-10-24 05:58:18 --> Router Class Initialized
INFO - 2024-10-24 05:58:18 --> Output Class Initialized
INFO - 2024-10-24 05:58:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:18 --> Input Class Initialized
INFO - 2024-10-24 05:58:18 --> Language Class Initialized
INFO - 2024-10-24 05:58:18 --> Loader Class Initialized
INFO - 2024-10-24 05:58:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:21 --> Upload Class Initialized
INFO - 2024-10-24 05:58:21 --> Email Class Initialized
INFO - 2024-10-24 05:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:21 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:21 --> Controller Class Initialized
INFO - 2024-10-24 11:28:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:23 --> Config Class Initialized
INFO - 2024-10-24 05:58:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:23 --> URI Class Initialized
INFO - 2024-10-24 05:58:23 --> Router Class Initialized
INFO - 2024-10-24 05:58:23 --> Output Class Initialized
INFO - 2024-10-24 05:58:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:23 --> Input Class Initialized
INFO - 2024-10-24 05:58:23 --> Language Class Initialized
INFO - 2024-10-24 05:58:23 --> Loader Class Initialized
INFO - 2024-10-24 05:58:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:25 --> Upload Class Initialized
INFO - 2024-10-24 05:58:25 --> Email Class Initialized
INFO - 2024-10-24 05:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:26 --> Controller Class Initialized
INFO - 2024-10-24 11:28:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:28 --> Config Class Initialized
INFO - 2024-10-24 05:58:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:28 --> URI Class Initialized
INFO - 2024-10-24 05:58:28 --> Router Class Initialized
INFO - 2024-10-24 05:58:28 --> Output Class Initialized
INFO - 2024-10-24 05:58:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:28 --> Input Class Initialized
INFO - 2024-10-24 05:58:28 --> Language Class Initialized
INFO - 2024-10-24 05:58:28 --> Loader Class Initialized
INFO - 2024-10-24 05:58:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:31 --> Upload Class Initialized
INFO - 2024-10-24 05:58:31 --> Email Class Initialized
INFO - 2024-10-24 05:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:31 --> Controller Class Initialized
INFO - 2024-10-24 11:28:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:33 --> Config Class Initialized
INFO - 2024-10-24 05:58:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:33 --> URI Class Initialized
INFO - 2024-10-24 05:58:33 --> Router Class Initialized
INFO - 2024-10-24 05:58:33 --> Output Class Initialized
INFO - 2024-10-24 05:58:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:33 --> Input Class Initialized
INFO - 2024-10-24 05:58:33 --> Language Class Initialized
INFO - 2024-10-24 05:58:33 --> Loader Class Initialized
INFO - 2024-10-24 05:58:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:35 --> Upload Class Initialized
INFO - 2024-10-24 05:58:35 --> Email Class Initialized
INFO - 2024-10-24 05:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:36 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:36 --> Controller Class Initialized
INFO - 2024-10-24 11:28:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:38 --> Config Class Initialized
INFO - 2024-10-24 05:58:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:38 --> URI Class Initialized
INFO - 2024-10-24 05:58:38 --> Router Class Initialized
INFO - 2024-10-24 05:58:38 --> Output Class Initialized
INFO - 2024-10-24 05:58:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:38 --> Input Class Initialized
INFO - 2024-10-24 05:58:38 --> Language Class Initialized
INFO - 2024-10-24 05:58:38 --> Loader Class Initialized
INFO - 2024-10-24 05:58:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:41 --> Upload Class Initialized
INFO - 2024-10-24 05:58:41 --> Email Class Initialized
INFO - 2024-10-24 05:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:41 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:41 --> Controller Class Initialized
INFO - 2024-10-24 11:28:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:43 --> Config Class Initialized
INFO - 2024-10-24 05:58:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:43 --> URI Class Initialized
INFO - 2024-10-24 05:58:43 --> Router Class Initialized
INFO - 2024-10-24 05:58:43 --> Output Class Initialized
INFO - 2024-10-24 05:58:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:43 --> Input Class Initialized
INFO - 2024-10-24 05:58:43 --> Language Class Initialized
INFO - 2024-10-24 05:58:43 --> Loader Class Initialized
INFO - 2024-10-24 05:58:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:45 --> Upload Class Initialized
INFO - 2024-10-24 05:58:45 --> Email Class Initialized
INFO - 2024-10-24 05:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:46 --> Controller Class Initialized
INFO - 2024-10-24 11:28:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:48 --> Config Class Initialized
INFO - 2024-10-24 05:58:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:48 --> URI Class Initialized
INFO - 2024-10-24 05:58:48 --> Router Class Initialized
INFO - 2024-10-24 05:58:48 --> Output Class Initialized
INFO - 2024-10-24 05:58:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:48 --> Input Class Initialized
INFO - 2024-10-24 05:58:48 --> Language Class Initialized
INFO - 2024-10-24 05:58:48 --> Loader Class Initialized
INFO - 2024-10-24 05:58:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:50 --> Upload Class Initialized
INFO - 2024-10-24 05:58:50 --> Email Class Initialized
INFO - 2024-10-24 05:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:51 --> Controller Class Initialized
INFO - 2024-10-24 11:28:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:53 --> Config Class Initialized
INFO - 2024-10-24 05:58:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:53 --> URI Class Initialized
INFO - 2024-10-24 05:58:53 --> Router Class Initialized
INFO - 2024-10-24 05:58:53 --> Output Class Initialized
INFO - 2024-10-24 05:58:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:53 --> Input Class Initialized
INFO - 2024-10-24 05:58:53 --> Language Class Initialized
INFO - 2024-10-24 05:58:53 --> Loader Class Initialized
INFO - 2024-10-24 05:58:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:58:56 --> Upload Class Initialized
INFO - 2024-10-24 05:58:56 --> Email Class Initialized
INFO - 2024-10-24 05:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:58:56 --> Form Validation Class Initialized
INFO - 2024-10-24 05:58:56 --> Controller Class Initialized
INFO - 2024-10-24 11:28:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:28:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:28:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:58:58 --> Config Class Initialized
INFO - 2024-10-24 05:58:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:58:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:58:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:58:58 --> URI Class Initialized
INFO - 2024-10-24 05:58:58 --> Router Class Initialized
INFO - 2024-10-24 05:58:58 --> Output Class Initialized
INFO - 2024-10-24 05:58:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:58:58 --> Input Class Initialized
INFO - 2024-10-24 05:58:58 --> Language Class Initialized
INFO - 2024-10-24 05:58:58 --> Loader Class Initialized
INFO - 2024-10-24 05:58:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:58:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:58:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:58:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:58:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:58:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:58:58 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:01 --> Upload Class Initialized
INFO - 2024-10-24 05:59:01 --> Email Class Initialized
INFO - 2024-10-24 05:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:01 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:01 --> Controller Class Initialized
INFO - 2024-10-24 11:29:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:01 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:03 --> Config Class Initialized
INFO - 2024-10-24 05:59:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:03 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:03 --> URI Class Initialized
INFO - 2024-10-24 05:59:03 --> Router Class Initialized
INFO - 2024-10-24 05:59:03 --> Output Class Initialized
INFO - 2024-10-24 05:59:03 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:03 --> Input Class Initialized
INFO - 2024-10-24 05:59:03 --> Language Class Initialized
INFO - 2024-10-24 05:59:03 --> Loader Class Initialized
INFO - 2024-10-24 05:59:03 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:03 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:03 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:03 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:03 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:03 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:04 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:06 --> Upload Class Initialized
INFO - 2024-10-24 05:59:06 --> Email Class Initialized
INFO - 2024-10-24 05:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:06 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:06 --> Controller Class Initialized
INFO - 2024-10-24 11:29:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:06 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:08 --> Config Class Initialized
INFO - 2024-10-24 05:59:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:08 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:08 --> URI Class Initialized
INFO - 2024-10-24 05:59:08 --> Router Class Initialized
INFO - 2024-10-24 05:59:08 --> Output Class Initialized
INFO - 2024-10-24 05:59:08 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:08 --> Input Class Initialized
INFO - 2024-10-24 05:59:08 --> Language Class Initialized
INFO - 2024-10-24 05:59:08 --> Loader Class Initialized
INFO - 2024-10-24 05:59:08 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:08 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:08 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:08 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:08 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:08 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:08 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:11 --> Upload Class Initialized
INFO - 2024-10-24 05:59:11 --> Email Class Initialized
INFO - 2024-10-24 05:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:11 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:11 --> Controller Class Initialized
INFO - 2024-10-24 11:29:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:11 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:13 --> Config Class Initialized
INFO - 2024-10-24 05:59:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:13 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:13 --> URI Class Initialized
INFO - 2024-10-24 05:59:13 --> Router Class Initialized
INFO - 2024-10-24 05:59:13 --> Output Class Initialized
INFO - 2024-10-24 05:59:13 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:13 --> Input Class Initialized
INFO - 2024-10-24 05:59:13 --> Language Class Initialized
INFO - 2024-10-24 05:59:13 --> Loader Class Initialized
INFO - 2024-10-24 05:59:13 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:13 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:13 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:13 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:13 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:13 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:13 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:15 --> Upload Class Initialized
INFO - 2024-10-24 05:59:15 --> Email Class Initialized
INFO - 2024-10-24 05:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:16 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:16 --> Controller Class Initialized
INFO - 2024-10-24 11:29:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:16 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:18 --> Config Class Initialized
INFO - 2024-10-24 05:59:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:18 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:18 --> URI Class Initialized
INFO - 2024-10-24 05:59:18 --> Router Class Initialized
INFO - 2024-10-24 05:59:18 --> Output Class Initialized
INFO - 2024-10-24 05:59:18 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:18 --> Input Class Initialized
INFO - 2024-10-24 05:59:18 --> Language Class Initialized
INFO - 2024-10-24 05:59:18 --> Loader Class Initialized
INFO - 2024-10-24 05:59:18 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:18 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:18 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:18 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:18 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:18 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:18 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:21 --> Upload Class Initialized
INFO - 2024-10-24 05:59:21 --> Email Class Initialized
INFO - 2024-10-24 05:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:21 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:21 --> Controller Class Initialized
INFO - 2024-10-24 11:29:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:21 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:23 --> Config Class Initialized
INFO - 2024-10-24 05:59:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:23 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:23 --> URI Class Initialized
INFO - 2024-10-24 05:59:23 --> Router Class Initialized
INFO - 2024-10-24 05:59:23 --> Output Class Initialized
INFO - 2024-10-24 05:59:23 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:23 --> Input Class Initialized
INFO - 2024-10-24 05:59:23 --> Language Class Initialized
INFO - 2024-10-24 05:59:23 --> Loader Class Initialized
INFO - 2024-10-24 05:59:23 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:23 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:23 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:23 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:23 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:23 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:23 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:26 --> Upload Class Initialized
INFO - 2024-10-24 05:59:26 --> Email Class Initialized
INFO - 2024-10-24 05:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:26 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:26 --> Controller Class Initialized
INFO - 2024-10-24 11:29:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:26 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:28 --> Config Class Initialized
INFO - 2024-10-24 05:59:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:28 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:28 --> URI Class Initialized
INFO - 2024-10-24 05:59:28 --> Router Class Initialized
INFO - 2024-10-24 05:59:28 --> Output Class Initialized
INFO - 2024-10-24 05:59:28 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:28 --> Input Class Initialized
INFO - 2024-10-24 05:59:28 --> Language Class Initialized
INFO - 2024-10-24 05:59:28 --> Loader Class Initialized
INFO - 2024-10-24 05:59:28 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:28 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:28 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:28 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:28 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:28 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:28 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:31 --> Upload Class Initialized
INFO - 2024-10-24 05:59:31 --> Email Class Initialized
INFO - 2024-10-24 05:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:31 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:31 --> Controller Class Initialized
INFO - 2024-10-24 11:29:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:31 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:33 --> Config Class Initialized
INFO - 2024-10-24 05:59:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:33 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:33 --> URI Class Initialized
INFO - 2024-10-24 05:59:33 --> Router Class Initialized
INFO - 2024-10-24 05:59:33 --> Output Class Initialized
INFO - 2024-10-24 05:59:33 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:33 --> Input Class Initialized
INFO - 2024-10-24 05:59:33 --> Language Class Initialized
INFO - 2024-10-24 05:59:33 --> Loader Class Initialized
INFO - 2024-10-24 05:59:33 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:33 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:33 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:33 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:33 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:33 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:33 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:35 --> Upload Class Initialized
INFO - 2024-10-24 05:59:35 --> Email Class Initialized
INFO - 2024-10-24 05:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:36 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:36 --> Controller Class Initialized
INFO - 2024-10-24 11:29:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:36 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:38 --> Config Class Initialized
INFO - 2024-10-24 05:59:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:38 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:38 --> URI Class Initialized
INFO - 2024-10-24 05:59:38 --> Router Class Initialized
INFO - 2024-10-24 05:59:38 --> Output Class Initialized
INFO - 2024-10-24 05:59:38 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:38 --> Input Class Initialized
INFO - 2024-10-24 05:59:38 --> Language Class Initialized
INFO - 2024-10-24 05:59:38 --> Loader Class Initialized
INFO - 2024-10-24 05:59:38 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:38 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:38 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:38 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:38 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:38 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:38 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:41 --> Upload Class Initialized
INFO - 2024-10-24 05:59:41 --> Email Class Initialized
INFO - 2024-10-24 05:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:41 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:41 --> Controller Class Initialized
INFO - 2024-10-24 11:29:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:41 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:43 --> Config Class Initialized
INFO - 2024-10-24 05:59:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:43 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:43 --> URI Class Initialized
INFO - 2024-10-24 05:59:43 --> Router Class Initialized
INFO - 2024-10-24 05:59:43 --> Output Class Initialized
INFO - 2024-10-24 05:59:43 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:43 --> Input Class Initialized
INFO - 2024-10-24 05:59:43 --> Language Class Initialized
INFO - 2024-10-24 05:59:43 --> Loader Class Initialized
INFO - 2024-10-24 05:59:43 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:43 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:43 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:43 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:43 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:43 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:43 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:46 --> Upload Class Initialized
INFO - 2024-10-24 05:59:46 --> Email Class Initialized
INFO - 2024-10-24 05:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:46 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:46 --> Controller Class Initialized
INFO - 2024-10-24 11:29:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:46 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:48 --> Config Class Initialized
INFO - 2024-10-24 05:59:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:48 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:48 --> URI Class Initialized
INFO - 2024-10-24 05:59:48 --> Router Class Initialized
INFO - 2024-10-24 05:59:48 --> Output Class Initialized
INFO - 2024-10-24 05:59:48 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:48 --> Input Class Initialized
INFO - 2024-10-24 05:59:48 --> Language Class Initialized
INFO - 2024-10-24 05:59:48 --> Loader Class Initialized
INFO - 2024-10-24 05:59:48 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:48 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:48 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:48 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:48 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:48 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:48 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:51 --> Upload Class Initialized
INFO - 2024-10-24 05:59:51 --> Email Class Initialized
INFO - 2024-10-24 05:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:51 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:51 --> Controller Class Initialized
INFO - 2024-10-24 11:29:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:51 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:53 --> Config Class Initialized
INFO - 2024-10-24 05:59:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:53 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:53 --> URI Class Initialized
INFO - 2024-10-24 05:59:53 --> Router Class Initialized
INFO - 2024-10-24 05:59:53 --> Output Class Initialized
INFO - 2024-10-24 05:59:53 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:53 --> Input Class Initialized
INFO - 2024-10-24 05:59:53 --> Language Class Initialized
INFO - 2024-10-24 05:59:53 --> Loader Class Initialized
INFO - 2024-10-24 05:59:53 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:53 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:53 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:53 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:53 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:53 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:53 --> Database Driver Class Initialized
INFO - 2024-10-24 05:59:56 --> Upload Class Initialized
INFO - 2024-10-24 05:59:56 --> Email Class Initialized
INFO - 2024-10-24 05:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 05:59:56 --> Form Validation Class Initialized
INFO - 2024-10-24 05:59:56 --> Controller Class Initialized
INFO - 2024-10-24 11:29:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:29:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:29:56 --> Pagination Class Initialized
INFO - 2024-10-24 05:59:58 --> Config Class Initialized
INFO - 2024-10-24 05:59:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 05:59:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 05:59:58 --> Utf8 Class Initialized
INFO - 2024-10-24 05:59:58 --> URI Class Initialized
INFO - 2024-10-24 05:59:58 --> Router Class Initialized
INFO - 2024-10-24 05:59:58 --> Output Class Initialized
INFO - 2024-10-24 05:59:58 --> Security Class Initialized
DEBUG - 2024-10-24 05:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 05:59:58 --> Input Class Initialized
INFO - 2024-10-24 05:59:58 --> Language Class Initialized
INFO - 2024-10-24 05:59:58 --> Loader Class Initialized
INFO - 2024-10-24 05:59:58 --> Helper loaded: url_helper
INFO - 2024-10-24 05:59:58 --> Helper loaded: html_helper
INFO - 2024-10-24 05:59:58 --> Helper loaded: file_helper
INFO - 2024-10-24 05:59:58 --> Helper loaded: string_helper
INFO - 2024-10-24 05:59:58 --> Helper loaded: form_helper
INFO - 2024-10-24 05:59:58 --> Helper loaded: my_helper
INFO - 2024-10-24 05:59:58 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:00 --> Upload Class Initialized
INFO - 2024-10-24 06:00:00 --> Email Class Initialized
INFO - 2024-10-24 06:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:01 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:01 --> Controller Class Initialized
INFO - 2024-10-24 11:30:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:01 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:03 --> Config Class Initialized
INFO - 2024-10-24 06:00:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:03 --> URI Class Initialized
INFO - 2024-10-24 06:00:04 --> Router Class Initialized
INFO - 2024-10-24 06:00:04 --> Output Class Initialized
INFO - 2024-10-24 06:00:04 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:04 --> Input Class Initialized
INFO - 2024-10-24 06:00:04 --> Language Class Initialized
INFO - 2024-10-24 06:00:04 --> Loader Class Initialized
INFO - 2024-10-24 06:00:04 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:04 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:04 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:04 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:04 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:04 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:04 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:06 --> Upload Class Initialized
INFO - 2024-10-24 06:00:06 --> Email Class Initialized
INFO - 2024-10-24 06:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:06 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:06 --> Controller Class Initialized
INFO - 2024-10-24 11:30:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:06 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:08 --> Config Class Initialized
INFO - 2024-10-24 06:00:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:08 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:08 --> URI Class Initialized
INFO - 2024-10-24 06:00:08 --> Router Class Initialized
INFO - 2024-10-24 06:00:08 --> Output Class Initialized
INFO - 2024-10-24 06:00:08 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:08 --> Input Class Initialized
INFO - 2024-10-24 06:00:08 --> Language Class Initialized
INFO - 2024-10-24 06:00:08 --> Loader Class Initialized
INFO - 2024-10-24 06:00:08 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:08 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:08 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:08 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:08 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:08 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:09 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:11 --> Upload Class Initialized
INFO - 2024-10-24 06:00:11 --> Email Class Initialized
INFO - 2024-10-24 06:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:11 --> Controller Class Initialized
INFO - 2024-10-24 11:30:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:13 --> Config Class Initialized
INFO - 2024-10-24 06:00:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:13 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:13 --> URI Class Initialized
INFO - 2024-10-24 06:00:13 --> Router Class Initialized
INFO - 2024-10-24 06:00:13 --> Output Class Initialized
INFO - 2024-10-24 06:00:13 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:13 --> Input Class Initialized
INFO - 2024-10-24 06:00:13 --> Language Class Initialized
INFO - 2024-10-24 06:00:13 --> Loader Class Initialized
INFO - 2024-10-24 06:00:13 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:13 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:13 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:13 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:13 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:13 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:13 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:16 --> Upload Class Initialized
INFO - 2024-10-24 06:00:16 --> Email Class Initialized
INFO - 2024-10-24 06:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:16 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:16 --> Controller Class Initialized
INFO - 2024-10-24 11:30:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:16 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:18 --> Config Class Initialized
INFO - 2024-10-24 06:00:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:18 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:18 --> URI Class Initialized
INFO - 2024-10-24 06:00:18 --> Router Class Initialized
INFO - 2024-10-24 06:00:18 --> Output Class Initialized
INFO - 2024-10-24 06:00:18 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:18 --> Input Class Initialized
INFO - 2024-10-24 06:00:18 --> Language Class Initialized
INFO - 2024-10-24 06:00:18 --> Loader Class Initialized
INFO - 2024-10-24 06:00:18 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:18 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:18 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:18 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:18 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:19 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:19 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:21 --> Upload Class Initialized
INFO - 2024-10-24 06:00:21 --> Email Class Initialized
INFO - 2024-10-24 06:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:21 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:21 --> Controller Class Initialized
INFO - 2024-10-24 11:30:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:21 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:23 --> Config Class Initialized
INFO - 2024-10-24 06:00:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:23 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:23 --> URI Class Initialized
INFO - 2024-10-24 06:00:23 --> Router Class Initialized
INFO - 2024-10-24 06:00:23 --> Output Class Initialized
INFO - 2024-10-24 06:00:23 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:23 --> Input Class Initialized
INFO - 2024-10-24 06:00:23 --> Language Class Initialized
INFO - 2024-10-24 06:00:23 --> Loader Class Initialized
INFO - 2024-10-24 06:00:23 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:23 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:23 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:23 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:23 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:23 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:23 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:26 --> Upload Class Initialized
INFO - 2024-10-24 06:00:26 --> Email Class Initialized
INFO - 2024-10-24 06:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:26 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:26 --> Controller Class Initialized
INFO - 2024-10-24 11:30:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:26 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:28 --> Config Class Initialized
INFO - 2024-10-24 06:00:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:28 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:28 --> URI Class Initialized
INFO - 2024-10-24 06:00:28 --> Router Class Initialized
INFO - 2024-10-24 06:00:28 --> Output Class Initialized
INFO - 2024-10-24 06:00:28 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:28 --> Input Class Initialized
INFO - 2024-10-24 06:00:28 --> Language Class Initialized
INFO - 2024-10-24 06:00:28 --> Loader Class Initialized
INFO - 2024-10-24 06:00:28 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:28 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:28 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:28 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:28 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:28 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:28 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:31 --> Upload Class Initialized
INFO - 2024-10-24 06:00:31 --> Email Class Initialized
INFO - 2024-10-24 06:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:31 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:31 --> Controller Class Initialized
INFO - 2024-10-24 11:30:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:31 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:33 --> Config Class Initialized
INFO - 2024-10-24 06:00:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:33 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:33 --> URI Class Initialized
INFO - 2024-10-24 06:00:33 --> Router Class Initialized
INFO - 2024-10-24 06:00:33 --> Output Class Initialized
INFO - 2024-10-24 06:00:33 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:33 --> Input Class Initialized
INFO - 2024-10-24 06:00:33 --> Language Class Initialized
INFO - 2024-10-24 06:00:33 --> Loader Class Initialized
INFO - 2024-10-24 06:00:33 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:33 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:33 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:33 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:33 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:33 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:33 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:36 --> Upload Class Initialized
INFO - 2024-10-24 06:00:36 --> Email Class Initialized
INFO - 2024-10-24 06:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:36 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:36 --> Controller Class Initialized
INFO - 2024-10-24 11:30:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:36 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:38 --> Config Class Initialized
INFO - 2024-10-24 06:00:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:38 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:38 --> URI Class Initialized
INFO - 2024-10-24 06:00:38 --> Router Class Initialized
INFO - 2024-10-24 06:00:38 --> Output Class Initialized
INFO - 2024-10-24 06:00:38 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:38 --> Input Class Initialized
INFO - 2024-10-24 06:00:38 --> Language Class Initialized
INFO - 2024-10-24 06:00:38 --> Loader Class Initialized
INFO - 2024-10-24 06:00:38 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:38 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:38 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:38 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:38 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:38 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:39 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:41 --> Upload Class Initialized
INFO - 2024-10-24 06:00:41 --> Email Class Initialized
INFO - 2024-10-24 06:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:41 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:41 --> Controller Class Initialized
INFO - 2024-10-24 11:30:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:41 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:43 --> Config Class Initialized
INFO - 2024-10-24 06:00:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:43 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:43 --> URI Class Initialized
INFO - 2024-10-24 06:00:43 --> Router Class Initialized
INFO - 2024-10-24 06:00:43 --> Output Class Initialized
INFO - 2024-10-24 06:00:43 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:43 --> Input Class Initialized
INFO - 2024-10-24 06:00:43 --> Language Class Initialized
INFO - 2024-10-24 06:00:43 --> Loader Class Initialized
INFO - 2024-10-24 06:00:43 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:43 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:43 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:43 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:43 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:43 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:43 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:46 --> Upload Class Initialized
INFO - 2024-10-24 06:00:46 --> Email Class Initialized
INFO - 2024-10-24 06:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:46 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:46 --> Controller Class Initialized
INFO - 2024-10-24 11:30:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:46 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:48 --> Config Class Initialized
INFO - 2024-10-24 06:00:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:48 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:48 --> URI Class Initialized
INFO - 2024-10-24 06:00:48 --> Router Class Initialized
INFO - 2024-10-24 06:00:48 --> Output Class Initialized
INFO - 2024-10-24 06:00:48 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:48 --> Input Class Initialized
INFO - 2024-10-24 06:00:48 --> Language Class Initialized
INFO - 2024-10-24 06:00:48 --> Loader Class Initialized
INFO - 2024-10-24 06:00:48 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:48 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:48 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:48 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:48 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:48 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:48 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:51 --> Upload Class Initialized
INFO - 2024-10-24 06:00:51 --> Email Class Initialized
INFO - 2024-10-24 06:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:51 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:51 --> Controller Class Initialized
INFO - 2024-10-24 11:30:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:51 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:53 --> Config Class Initialized
INFO - 2024-10-24 06:00:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:53 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:53 --> URI Class Initialized
INFO - 2024-10-24 06:00:53 --> Router Class Initialized
INFO - 2024-10-24 06:00:53 --> Output Class Initialized
INFO - 2024-10-24 06:00:53 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:53 --> Input Class Initialized
INFO - 2024-10-24 06:00:53 --> Language Class Initialized
INFO - 2024-10-24 06:00:53 --> Loader Class Initialized
INFO - 2024-10-24 06:00:53 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:53 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:53 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:53 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:53 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:53 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:53 --> Database Driver Class Initialized
INFO - 2024-10-24 06:00:56 --> Upload Class Initialized
INFO - 2024-10-24 06:00:56 --> Email Class Initialized
INFO - 2024-10-24 06:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:00:56 --> Form Validation Class Initialized
INFO - 2024-10-24 06:00:56 --> Controller Class Initialized
INFO - 2024-10-24 11:30:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:30:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:30:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:30:56 --> Pagination Class Initialized
INFO - 2024-10-24 06:00:58 --> Config Class Initialized
INFO - 2024-10-24 06:00:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:00:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:00:58 --> Utf8 Class Initialized
INFO - 2024-10-24 06:00:58 --> URI Class Initialized
INFO - 2024-10-24 06:00:58 --> Router Class Initialized
INFO - 2024-10-24 06:00:58 --> Output Class Initialized
INFO - 2024-10-24 06:00:58 --> Security Class Initialized
DEBUG - 2024-10-24 06:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:00:58 --> Input Class Initialized
INFO - 2024-10-24 06:00:58 --> Language Class Initialized
INFO - 2024-10-24 06:00:58 --> Loader Class Initialized
INFO - 2024-10-24 06:00:58 --> Helper loaded: url_helper
INFO - 2024-10-24 06:00:58 --> Helper loaded: html_helper
INFO - 2024-10-24 06:00:58 --> Helper loaded: file_helper
INFO - 2024-10-24 06:00:58 --> Helper loaded: string_helper
INFO - 2024-10-24 06:00:58 --> Helper loaded: form_helper
INFO - 2024-10-24 06:00:58 --> Helper loaded: my_helper
INFO - 2024-10-24 06:00:58 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:01 --> Upload Class Initialized
INFO - 2024-10-24 06:01:01 --> Email Class Initialized
INFO - 2024-10-24 06:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:01 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:01 --> Controller Class Initialized
INFO - 2024-10-24 11:31:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:01 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:03 --> Config Class Initialized
INFO - 2024-10-24 06:01:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:03 --> URI Class Initialized
INFO - 2024-10-24 06:01:03 --> Router Class Initialized
INFO - 2024-10-24 06:01:03 --> Output Class Initialized
INFO - 2024-10-24 06:01:03 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:03 --> Input Class Initialized
INFO - 2024-10-24 06:01:03 --> Language Class Initialized
INFO - 2024-10-24 06:01:03 --> Loader Class Initialized
INFO - 2024-10-24 06:01:03 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:03 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:03 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:03 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:03 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:03 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:03 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:06 --> Upload Class Initialized
INFO - 2024-10-24 06:01:06 --> Email Class Initialized
INFO - 2024-10-24 06:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:06 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:06 --> Controller Class Initialized
INFO - 2024-10-24 11:31:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:06 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:08 --> Config Class Initialized
INFO - 2024-10-24 06:01:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:08 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:08 --> URI Class Initialized
INFO - 2024-10-24 06:01:08 --> Router Class Initialized
INFO - 2024-10-24 06:01:08 --> Output Class Initialized
INFO - 2024-10-24 06:01:08 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:08 --> Input Class Initialized
INFO - 2024-10-24 06:01:08 --> Language Class Initialized
INFO - 2024-10-24 06:01:08 --> Loader Class Initialized
INFO - 2024-10-24 06:01:08 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:08 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:08 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:08 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:08 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:08 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:08 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:11 --> Upload Class Initialized
INFO - 2024-10-24 06:01:11 --> Email Class Initialized
INFO - 2024-10-24 06:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:11 --> Controller Class Initialized
INFO - 2024-10-24 11:31:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:13 --> Config Class Initialized
INFO - 2024-10-24 06:01:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:13 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:13 --> URI Class Initialized
INFO - 2024-10-24 06:01:13 --> Router Class Initialized
INFO - 2024-10-24 06:01:13 --> Output Class Initialized
INFO - 2024-10-24 06:01:13 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:13 --> Input Class Initialized
INFO - 2024-10-24 06:01:13 --> Language Class Initialized
INFO - 2024-10-24 06:01:13 --> Loader Class Initialized
INFO - 2024-10-24 06:01:13 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:13 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:13 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:13 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:13 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:13 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:13 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:16 --> Upload Class Initialized
INFO - 2024-10-24 06:01:16 --> Email Class Initialized
INFO - 2024-10-24 06:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:16 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:16 --> Controller Class Initialized
INFO - 2024-10-24 11:31:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:16 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:18 --> Config Class Initialized
INFO - 2024-10-24 06:01:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:18 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:18 --> URI Class Initialized
INFO - 2024-10-24 06:01:18 --> Router Class Initialized
INFO - 2024-10-24 06:01:18 --> Output Class Initialized
INFO - 2024-10-24 06:01:18 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:18 --> Input Class Initialized
INFO - 2024-10-24 06:01:18 --> Language Class Initialized
INFO - 2024-10-24 06:01:18 --> Loader Class Initialized
INFO - 2024-10-24 06:01:18 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:18 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:18 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:18 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:18 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:18 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:19 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:21 --> Upload Class Initialized
INFO - 2024-10-24 06:01:21 --> Email Class Initialized
INFO - 2024-10-24 06:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:21 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:21 --> Controller Class Initialized
INFO - 2024-10-24 11:31:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:21 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:23 --> Config Class Initialized
INFO - 2024-10-24 06:01:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:23 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:23 --> URI Class Initialized
INFO - 2024-10-24 06:01:23 --> Router Class Initialized
INFO - 2024-10-24 06:01:23 --> Output Class Initialized
INFO - 2024-10-24 06:01:23 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:23 --> Input Class Initialized
INFO - 2024-10-24 06:01:23 --> Language Class Initialized
INFO - 2024-10-24 06:01:23 --> Loader Class Initialized
INFO - 2024-10-24 06:01:23 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:23 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:23 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:23 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:23 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:23 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:23 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:26 --> Upload Class Initialized
INFO - 2024-10-24 06:01:26 --> Email Class Initialized
INFO - 2024-10-24 06:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:26 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:26 --> Controller Class Initialized
INFO - 2024-10-24 11:31:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:26 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:28 --> Config Class Initialized
INFO - 2024-10-24 06:01:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:28 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:28 --> URI Class Initialized
INFO - 2024-10-24 06:01:28 --> Router Class Initialized
INFO - 2024-10-24 06:01:28 --> Output Class Initialized
INFO - 2024-10-24 06:01:28 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:28 --> Input Class Initialized
INFO - 2024-10-24 06:01:28 --> Language Class Initialized
INFO - 2024-10-24 06:01:28 --> Loader Class Initialized
INFO - 2024-10-24 06:01:28 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:28 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:28 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:28 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:28 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:28 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:28 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:31 --> Upload Class Initialized
INFO - 2024-10-24 06:01:31 --> Email Class Initialized
INFO - 2024-10-24 06:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:31 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:31 --> Controller Class Initialized
INFO - 2024-10-24 11:31:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:31 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:33 --> Config Class Initialized
INFO - 2024-10-24 06:01:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:33 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:33 --> URI Class Initialized
INFO - 2024-10-24 06:01:33 --> Router Class Initialized
INFO - 2024-10-24 06:01:33 --> Output Class Initialized
INFO - 2024-10-24 06:01:33 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:33 --> Input Class Initialized
INFO - 2024-10-24 06:01:33 --> Language Class Initialized
INFO - 2024-10-24 06:01:33 --> Loader Class Initialized
INFO - 2024-10-24 06:01:33 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:33 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:34 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:34 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:34 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:34 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:34 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:36 --> Upload Class Initialized
INFO - 2024-10-24 06:01:36 --> Email Class Initialized
INFO - 2024-10-24 06:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:36 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:36 --> Controller Class Initialized
INFO - 2024-10-24 11:31:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:36 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:38 --> Config Class Initialized
INFO - 2024-10-24 06:01:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:38 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:38 --> URI Class Initialized
INFO - 2024-10-24 06:01:38 --> Router Class Initialized
INFO - 2024-10-24 06:01:38 --> Output Class Initialized
INFO - 2024-10-24 06:01:38 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:38 --> Input Class Initialized
INFO - 2024-10-24 06:01:38 --> Language Class Initialized
INFO - 2024-10-24 06:01:38 --> Loader Class Initialized
INFO - 2024-10-24 06:01:38 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:38 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:39 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:39 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:39 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:39 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:39 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:41 --> Upload Class Initialized
INFO - 2024-10-24 06:01:41 --> Email Class Initialized
INFO - 2024-10-24 06:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:41 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:41 --> Controller Class Initialized
INFO - 2024-10-24 11:31:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:41 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:43 --> Config Class Initialized
INFO - 2024-10-24 06:01:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:43 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:43 --> URI Class Initialized
INFO - 2024-10-24 06:01:43 --> Router Class Initialized
INFO - 2024-10-24 06:01:43 --> Output Class Initialized
INFO - 2024-10-24 06:01:43 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:43 --> Input Class Initialized
INFO - 2024-10-24 06:01:43 --> Language Class Initialized
INFO - 2024-10-24 06:01:43 --> Loader Class Initialized
INFO - 2024-10-24 06:01:43 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:43 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:43 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:43 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:43 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:43 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:43 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:46 --> Upload Class Initialized
INFO - 2024-10-24 06:01:46 --> Email Class Initialized
INFO - 2024-10-24 06:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:46 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:46 --> Controller Class Initialized
INFO - 2024-10-24 11:31:46 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:46 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:46 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:49 --> Config Class Initialized
INFO - 2024-10-24 06:01:49 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:49 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:49 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:49 --> URI Class Initialized
INFO - 2024-10-24 06:01:49 --> Router Class Initialized
INFO - 2024-10-24 06:01:49 --> Output Class Initialized
INFO - 2024-10-24 06:01:49 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:49 --> Input Class Initialized
INFO - 2024-10-24 06:01:49 --> Language Class Initialized
INFO - 2024-10-24 06:01:49 --> Loader Class Initialized
INFO - 2024-10-24 06:01:49 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:49 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:49 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:49 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:49 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:49 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:49 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:51 --> Upload Class Initialized
INFO - 2024-10-24 06:01:51 --> Email Class Initialized
INFO - 2024-10-24 06:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:51 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:51 --> Controller Class Initialized
INFO - 2024-10-24 11:31:51 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:51 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:51 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:54 --> Config Class Initialized
INFO - 2024-10-24 06:01:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:54 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:54 --> URI Class Initialized
INFO - 2024-10-24 06:01:54 --> Router Class Initialized
INFO - 2024-10-24 06:01:54 --> Output Class Initialized
INFO - 2024-10-24 06:01:54 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:54 --> Input Class Initialized
INFO - 2024-10-24 06:01:54 --> Language Class Initialized
INFO - 2024-10-24 06:01:54 --> Loader Class Initialized
INFO - 2024-10-24 06:01:54 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:54 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:54 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:54 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:54 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:54 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:54 --> Database Driver Class Initialized
INFO - 2024-10-24 06:01:56 --> Upload Class Initialized
INFO - 2024-10-24 06:01:56 --> Email Class Initialized
INFO - 2024-10-24 06:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:01:56 --> Form Validation Class Initialized
INFO - 2024-10-24 06:01:56 --> Controller Class Initialized
INFO - 2024-10-24 11:31:56 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:31:56 --> Model "MainModel" initialized
INFO - 2024-10-24 11:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:31:56 --> Pagination Class Initialized
INFO - 2024-10-24 06:01:59 --> Config Class Initialized
INFO - 2024-10-24 06:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:01:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:01:59 --> URI Class Initialized
INFO - 2024-10-24 06:01:59 --> Router Class Initialized
INFO - 2024-10-24 06:01:59 --> Output Class Initialized
INFO - 2024-10-24 06:01:59 --> Security Class Initialized
DEBUG - 2024-10-24 06:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:01:59 --> Input Class Initialized
INFO - 2024-10-24 06:01:59 --> Language Class Initialized
INFO - 2024-10-24 06:01:59 --> Loader Class Initialized
INFO - 2024-10-24 06:01:59 --> Helper loaded: url_helper
INFO - 2024-10-24 06:01:59 --> Helper loaded: html_helper
INFO - 2024-10-24 06:01:59 --> Helper loaded: file_helper
INFO - 2024-10-24 06:01:59 --> Helper loaded: string_helper
INFO - 2024-10-24 06:01:59 --> Helper loaded: form_helper
INFO - 2024-10-24 06:01:59 --> Helper loaded: my_helper
INFO - 2024-10-24 06:01:59 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:01 --> Upload Class Initialized
INFO - 2024-10-24 06:02:01 --> Email Class Initialized
INFO - 2024-10-24 06:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:01 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:01 --> Controller Class Initialized
INFO - 2024-10-24 11:32:01 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:01 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:01 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:04 --> Config Class Initialized
INFO - 2024-10-24 06:02:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:04 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:04 --> URI Class Initialized
INFO - 2024-10-24 06:02:04 --> Router Class Initialized
INFO - 2024-10-24 06:02:04 --> Output Class Initialized
INFO - 2024-10-24 06:02:04 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:04 --> Input Class Initialized
INFO - 2024-10-24 06:02:04 --> Language Class Initialized
INFO - 2024-10-24 06:02:04 --> Loader Class Initialized
INFO - 2024-10-24 06:02:04 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:04 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:04 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:04 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:04 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:04 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:04 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:06 --> Upload Class Initialized
INFO - 2024-10-24 06:02:06 --> Email Class Initialized
INFO - 2024-10-24 06:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:06 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:06 --> Controller Class Initialized
INFO - 2024-10-24 11:32:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:06 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:06 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:09 --> Config Class Initialized
INFO - 2024-10-24 06:02:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:09 --> URI Class Initialized
INFO - 2024-10-24 06:02:09 --> Router Class Initialized
INFO - 2024-10-24 06:02:09 --> Output Class Initialized
INFO - 2024-10-24 06:02:09 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:09 --> Input Class Initialized
INFO - 2024-10-24 06:02:09 --> Language Class Initialized
INFO - 2024-10-24 06:02:09 --> Loader Class Initialized
INFO - 2024-10-24 06:02:09 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:09 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:09 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:09 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:09 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:09 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:09 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:11 --> Upload Class Initialized
INFO - 2024-10-24 06:02:11 --> Email Class Initialized
INFO - 2024-10-24 06:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:11 --> Controller Class Initialized
INFO - 2024-10-24 11:32:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:14 --> Config Class Initialized
INFO - 2024-10-24 06:02:14 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:14 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:14 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:14 --> URI Class Initialized
INFO - 2024-10-24 06:02:14 --> Router Class Initialized
INFO - 2024-10-24 06:02:14 --> Output Class Initialized
INFO - 2024-10-24 06:02:14 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:14 --> Input Class Initialized
INFO - 2024-10-24 06:02:14 --> Language Class Initialized
INFO - 2024-10-24 06:02:14 --> Loader Class Initialized
INFO - 2024-10-24 06:02:14 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:14 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:14 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:14 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:14 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:14 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:14 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:16 --> Upload Class Initialized
INFO - 2024-10-24 06:02:16 --> Email Class Initialized
INFO - 2024-10-24 06:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:16 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:16 --> Controller Class Initialized
INFO - 2024-10-24 11:32:16 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:16 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:16 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:19 --> Config Class Initialized
INFO - 2024-10-24 06:02:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:19 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:19 --> URI Class Initialized
INFO - 2024-10-24 06:02:19 --> Router Class Initialized
INFO - 2024-10-24 06:02:19 --> Output Class Initialized
INFO - 2024-10-24 06:02:19 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:19 --> Input Class Initialized
INFO - 2024-10-24 06:02:19 --> Language Class Initialized
INFO - 2024-10-24 06:02:19 --> Loader Class Initialized
INFO - 2024-10-24 06:02:19 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:19 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:19 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:19 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:19 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:19 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:19 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:21 --> Upload Class Initialized
INFO - 2024-10-24 06:02:21 --> Email Class Initialized
INFO - 2024-10-24 06:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:21 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:21 --> Controller Class Initialized
INFO - 2024-10-24 11:32:21 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:21 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:21 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:24 --> Config Class Initialized
INFO - 2024-10-24 06:02:24 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:24 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:24 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:24 --> URI Class Initialized
INFO - 2024-10-24 06:02:24 --> Router Class Initialized
INFO - 2024-10-24 06:02:24 --> Output Class Initialized
INFO - 2024-10-24 06:02:24 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:24 --> Input Class Initialized
INFO - 2024-10-24 06:02:24 --> Language Class Initialized
INFO - 2024-10-24 06:02:24 --> Loader Class Initialized
INFO - 2024-10-24 06:02:24 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:24 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:24 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:24 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:24 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:24 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:24 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:26 --> Upload Class Initialized
INFO - 2024-10-24 06:02:26 --> Email Class Initialized
INFO - 2024-10-24 06:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:26 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:26 --> Controller Class Initialized
INFO - 2024-10-24 11:32:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:26 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:26 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:29 --> Config Class Initialized
INFO - 2024-10-24 06:02:29 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:29 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:29 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:29 --> URI Class Initialized
INFO - 2024-10-24 06:02:29 --> Router Class Initialized
INFO - 2024-10-24 06:02:29 --> Output Class Initialized
INFO - 2024-10-24 06:02:29 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:29 --> Input Class Initialized
INFO - 2024-10-24 06:02:29 --> Language Class Initialized
INFO - 2024-10-24 06:02:29 --> Loader Class Initialized
INFO - 2024-10-24 06:02:29 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:29 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:29 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:29 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:29 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:29 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:29 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:31 --> Upload Class Initialized
INFO - 2024-10-24 06:02:31 --> Email Class Initialized
INFO - 2024-10-24 06:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:31 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:31 --> Controller Class Initialized
INFO - 2024-10-24 11:32:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:31 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:31 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:34 --> Config Class Initialized
INFO - 2024-10-24 06:02:34 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:34 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:34 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:34 --> URI Class Initialized
INFO - 2024-10-24 06:02:34 --> Router Class Initialized
INFO - 2024-10-24 06:02:34 --> Output Class Initialized
INFO - 2024-10-24 06:02:34 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:34 --> Input Class Initialized
INFO - 2024-10-24 06:02:34 --> Language Class Initialized
INFO - 2024-10-24 06:02:34 --> Loader Class Initialized
INFO - 2024-10-24 06:02:34 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:34 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:34 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:34 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:34 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:34 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:34 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:36 --> Upload Class Initialized
INFO - 2024-10-24 06:02:36 --> Email Class Initialized
INFO - 2024-10-24 06:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:36 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:36 --> Controller Class Initialized
INFO - 2024-10-24 11:32:36 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:36 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:36 --> Pagination Class Initialized
INFO - 2024-10-24 06:02:39 --> Config Class Initialized
INFO - 2024-10-24 06:02:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:02:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:02:39 --> Utf8 Class Initialized
INFO - 2024-10-24 06:02:39 --> URI Class Initialized
INFO - 2024-10-24 06:02:39 --> Router Class Initialized
INFO - 2024-10-24 06:02:39 --> Output Class Initialized
INFO - 2024-10-24 06:02:39 --> Security Class Initialized
DEBUG - 2024-10-24 06:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:02:39 --> Input Class Initialized
INFO - 2024-10-24 06:02:39 --> Language Class Initialized
INFO - 2024-10-24 06:02:39 --> Loader Class Initialized
INFO - 2024-10-24 06:02:39 --> Helper loaded: url_helper
INFO - 2024-10-24 06:02:39 --> Helper loaded: html_helper
INFO - 2024-10-24 06:02:39 --> Helper loaded: file_helper
INFO - 2024-10-24 06:02:39 --> Helper loaded: string_helper
INFO - 2024-10-24 06:02:39 --> Helper loaded: form_helper
INFO - 2024-10-24 06:02:39 --> Helper loaded: my_helper
INFO - 2024-10-24 06:02:39 --> Database Driver Class Initialized
INFO - 2024-10-24 06:02:41 --> Upload Class Initialized
INFO - 2024-10-24 06:02:41 --> Email Class Initialized
INFO - 2024-10-24 06:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:02:41 --> Form Validation Class Initialized
INFO - 2024-10-24 06:02:41 --> Controller Class Initialized
INFO - 2024-10-24 11:32:41 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:32:41 --> Model "MainModel" initialized
INFO - 2024-10-24 11:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:32:41 --> Pagination Class Initialized
INFO - 2024-10-24 06:03:09 --> Config Class Initialized
INFO - 2024-10-24 06:03:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:03:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:03:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:03:09 --> URI Class Initialized
INFO - 2024-10-24 06:03:09 --> Router Class Initialized
INFO - 2024-10-24 06:03:09 --> Output Class Initialized
INFO - 2024-10-24 06:03:09 --> Security Class Initialized
DEBUG - 2024-10-24 06:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:03:09 --> Input Class Initialized
INFO - 2024-10-24 06:03:09 --> Language Class Initialized
INFO - 2024-10-24 06:03:09 --> Loader Class Initialized
INFO - 2024-10-24 06:03:09 --> Helper loaded: url_helper
INFO - 2024-10-24 06:03:09 --> Helper loaded: html_helper
INFO - 2024-10-24 06:03:09 --> Helper loaded: file_helper
INFO - 2024-10-24 06:03:09 --> Helper loaded: string_helper
INFO - 2024-10-24 06:03:09 --> Helper loaded: form_helper
INFO - 2024-10-24 06:03:09 --> Helper loaded: my_helper
INFO - 2024-10-24 06:03:09 --> Database Driver Class Initialized
INFO - 2024-10-24 06:03:11 --> Upload Class Initialized
INFO - 2024-10-24 06:03:11 --> Email Class Initialized
INFO - 2024-10-24 06:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:03:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:03:11 --> Controller Class Initialized
INFO - 2024-10-24 11:33:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:33:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:33:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:04:09 --> Config Class Initialized
INFO - 2024-10-24 06:04:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:04:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:04:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:04:09 --> URI Class Initialized
INFO - 2024-10-24 06:04:09 --> Router Class Initialized
INFO - 2024-10-24 06:04:09 --> Output Class Initialized
INFO - 2024-10-24 06:04:09 --> Security Class Initialized
DEBUG - 2024-10-24 06:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:04:09 --> Input Class Initialized
INFO - 2024-10-24 06:04:09 --> Language Class Initialized
INFO - 2024-10-24 06:04:09 --> Loader Class Initialized
INFO - 2024-10-24 06:04:09 --> Helper loaded: url_helper
INFO - 2024-10-24 06:04:09 --> Helper loaded: html_helper
INFO - 2024-10-24 06:04:09 --> Helper loaded: file_helper
INFO - 2024-10-24 06:04:09 --> Helper loaded: string_helper
INFO - 2024-10-24 06:04:09 --> Helper loaded: form_helper
INFO - 2024-10-24 06:04:09 --> Helper loaded: my_helper
INFO - 2024-10-24 06:04:09 --> Database Driver Class Initialized
INFO - 2024-10-24 06:04:11 --> Upload Class Initialized
INFO - 2024-10-24 06:04:11 --> Email Class Initialized
INFO - 2024-10-24 06:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:04:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:04:11 --> Controller Class Initialized
INFO - 2024-10-24 11:34:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:34:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:34:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:05:09 --> Config Class Initialized
INFO - 2024-10-24 06:05:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:05:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:05:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:05:09 --> URI Class Initialized
INFO - 2024-10-24 06:05:09 --> Router Class Initialized
INFO - 2024-10-24 06:05:09 --> Output Class Initialized
INFO - 2024-10-24 06:05:09 --> Security Class Initialized
DEBUG - 2024-10-24 06:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:05:09 --> Input Class Initialized
INFO - 2024-10-24 06:05:09 --> Language Class Initialized
INFO - 2024-10-24 06:05:09 --> Loader Class Initialized
INFO - 2024-10-24 06:05:09 --> Helper loaded: url_helper
INFO - 2024-10-24 06:05:09 --> Helper loaded: html_helper
INFO - 2024-10-24 06:05:09 --> Helper loaded: file_helper
INFO - 2024-10-24 06:05:09 --> Helper loaded: string_helper
INFO - 2024-10-24 06:05:09 --> Helper loaded: form_helper
INFO - 2024-10-24 06:05:09 --> Helper loaded: my_helper
INFO - 2024-10-24 06:05:09 --> Database Driver Class Initialized
INFO - 2024-10-24 06:05:11 --> Upload Class Initialized
INFO - 2024-10-24 06:05:11 --> Email Class Initialized
INFO - 2024-10-24 06:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:05:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:05:11 --> Controller Class Initialized
INFO - 2024-10-24 11:35:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:35:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:35:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:06:09 --> Config Class Initialized
INFO - 2024-10-24 06:06:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:06:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:06:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:06:09 --> URI Class Initialized
INFO - 2024-10-24 06:06:09 --> Router Class Initialized
INFO - 2024-10-24 06:06:09 --> Output Class Initialized
INFO - 2024-10-24 06:06:09 --> Security Class Initialized
DEBUG - 2024-10-24 06:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:06:09 --> Input Class Initialized
INFO - 2024-10-24 06:06:09 --> Language Class Initialized
INFO - 2024-10-24 06:06:09 --> Loader Class Initialized
INFO - 2024-10-24 06:06:09 --> Helper loaded: url_helper
INFO - 2024-10-24 06:06:09 --> Helper loaded: html_helper
INFO - 2024-10-24 06:06:09 --> Helper loaded: file_helper
INFO - 2024-10-24 06:06:09 --> Helper loaded: string_helper
INFO - 2024-10-24 06:06:09 --> Helper loaded: form_helper
INFO - 2024-10-24 06:06:09 --> Helper loaded: my_helper
INFO - 2024-10-24 06:06:09 --> Database Driver Class Initialized
INFO - 2024-10-24 06:06:11 --> Upload Class Initialized
INFO - 2024-10-24 06:06:11 --> Email Class Initialized
INFO - 2024-10-24 06:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:06:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:06:11 --> Controller Class Initialized
INFO - 2024-10-24 11:36:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:36:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:36:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:36:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:07:09 --> Config Class Initialized
INFO - 2024-10-24 06:07:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:07:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:07:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:07:09 --> URI Class Initialized
INFO - 2024-10-24 06:07:09 --> Router Class Initialized
INFO - 2024-10-24 06:07:09 --> Output Class Initialized
INFO - 2024-10-24 06:07:09 --> Security Class Initialized
DEBUG - 2024-10-24 06:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:07:09 --> Input Class Initialized
INFO - 2024-10-24 06:07:09 --> Language Class Initialized
INFO - 2024-10-24 06:07:09 --> Loader Class Initialized
INFO - 2024-10-24 06:07:09 --> Helper loaded: url_helper
INFO - 2024-10-24 06:07:09 --> Helper loaded: html_helper
INFO - 2024-10-24 06:07:09 --> Helper loaded: file_helper
INFO - 2024-10-24 06:07:09 --> Helper loaded: string_helper
INFO - 2024-10-24 06:07:09 --> Helper loaded: form_helper
INFO - 2024-10-24 06:07:09 --> Helper loaded: my_helper
INFO - 2024-10-24 06:07:09 --> Database Driver Class Initialized
INFO - 2024-10-24 06:07:11 --> Upload Class Initialized
INFO - 2024-10-24 06:07:11 --> Email Class Initialized
INFO - 2024-10-24 06:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:07:11 --> Form Validation Class Initialized
INFO - 2024-10-24 06:07:11 --> Controller Class Initialized
INFO - 2024-10-24 11:37:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:37:11 --> Model "MainModel" initialized
INFO - 2024-10-24 11:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:37:11 --> Pagination Class Initialized
INFO - 2024-10-24 06:08:21 --> Config Class Initialized
INFO - 2024-10-24 06:08:21 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:08:21 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:08:21 --> Utf8 Class Initialized
INFO - 2024-10-24 06:08:21 --> URI Class Initialized
INFO - 2024-10-24 06:08:21 --> Router Class Initialized
INFO - 2024-10-24 06:08:21 --> Output Class Initialized
INFO - 2024-10-24 06:08:21 --> Security Class Initialized
DEBUG - 2024-10-24 06:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:08:22 --> Input Class Initialized
INFO - 2024-10-24 06:08:22 --> Language Class Initialized
INFO - 2024-10-24 06:08:22 --> Loader Class Initialized
INFO - 2024-10-24 06:08:22 --> Helper loaded: url_helper
INFO - 2024-10-24 06:08:22 --> Helper loaded: html_helper
INFO - 2024-10-24 06:08:22 --> Helper loaded: file_helper
INFO - 2024-10-24 06:08:22 --> Helper loaded: string_helper
INFO - 2024-10-24 06:08:22 --> Helper loaded: form_helper
INFO - 2024-10-24 06:08:22 --> Helper loaded: my_helper
INFO - 2024-10-24 06:08:22 --> Database Driver Class Initialized
INFO - 2024-10-24 06:08:24 --> Upload Class Initialized
INFO - 2024-10-24 06:08:24 --> Email Class Initialized
INFO - 2024-10-24 06:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:08:24 --> Form Validation Class Initialized
INFO - 2024-10-24 06:08:24 --> Controller Class Initialized
INFO - 2024-10-24 11:38:24 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:38:24 --> Model "MainModel" initialized
INFO - 2024-10-24 11:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:38:24 --> Pagination Class Initialized
INFO - 2024-10-24 06:09:50 --> Config Class Initialized
INFO - 2024-10-24 06:09:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:09:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:09:50 --> Utf8 Class Initialized
INFO - 2024-10-24 06:09:50 --> URI Class Initialized
INFO - 2024-10-24 06:09:50 --> Router Class Initialized
INFO - 2024-10-24 06:09:50 --> Output Class Initialized
INFO - 2024-10-24 06:09:50 --> Security Class Initialized
DEBUG - 2024-10-24 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:09:50 --> Input Class Initialized
INFO - 2024-10-24 06:09:50 --> Language Class Initialized
INFO - 2024-10-24 06:09:50 --> Loader Class Initialized
INFO - 2024-10-24 06:09:50 --> Helper loaded: url_helper
INFO - 2024-10-24 06:09:50 --> Helper loaded: html_helper
INFO - 2024-10-24 06:09:50 --> Helper loaded: file_helper
INFO - 2024-10-24 06:09:50 --> Helper loaded: string_helper
INFO - 2024-10-24 06:09:50 --> Helper loaded: form_helper
INFO - 2024-10-24 06:09:50 --> Helper loaded: my_helper
INFO - 2024-10-24 06:09:50 --> Database Driver Class Initialized
INFO - 2024-10-24 06:09:52 --> Upload Class Initialized
INFO - 2024-10-24 06:09:52 --> Email Class Initialized
INFO - 2024-10-24 06:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:09:53 --> Form Validation Class Initialized
INFO - 2024-10-24 06:09:53 --> Controller Class Initialized
INFO - 2024-10-24 11:39:53 --> Model "HotelAdminModel" initialized
INFO - 2024-10-24 11:39:53 --> Model "FrontofficeModel" initialized
INFO - 2024-10-24 11:39:53 --> Model "FoodAdminModel" initialized
INFO - 2024-10-24 11:39:53 --> Model "MainModel" initialized
INFO - 2024-10-24 11:39:53 --> Helper loaded: notification_helper
INFO - 2024-10-24 11:39:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-24 11:39:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\hoteladmin/ViewHouseKeepingList.php
INFO - 2024-10-24 11:39:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-24 11:39:53 --> Final output sent to browser
DEBUG - 2024-10-24 11:39:53 --> Total execution time: 2.4130
INFO - 2024-10-24 06:09:59 --> Config Class Initialized
INFO - 2024-10-24 06:09:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:09:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:09:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:09:59 --> URI Class Initialized
INFO - 2024-10-24 06:09:59 --> Router Class Initialized
INFO - 2024-10-24 06:09:59 --> Output Class Initialized
INFO - 2024-10-24 06:09:59 --> Security Class Initialized
DEBUG - 2024-10-24 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:09:59 --> Input Class Initialized
INFO - 2024-10-24 06:09:59 --> Language Class Initialized
ERROR - 2024-10-24 06:09:59 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-24 06:10:12 --> Config Class Initialized
INFO - 2024-10-24 06:10:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:10:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:10:12 --> Utf8 Class Initialized
INFO - 2024-10-24 06:10:12 --> URI Class Initialized
INFO - 2024-10-24 06:10:12 --> Router Class Initialized
INFO - 2024-10-24 06:10:12 --> Output Class Initialized
INFO - 2024-10-24 06:10:12 --> Security Class Initialized
DEBUG - 2024-10-24 06:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:10:12 --> Input Class Initialized
INFO - 2024-10-24 06:10:12 --> Language Class Initialized
INFO - 2024-10-24 06:10:12 --> Loader Class Initialized
INFO - 2024-10-24 06:10:12 --> Helper loaded: url_helper
INFO - 2024-10-24 06:10:12 --> Helper loaded: html_helper
INFO - 2024-10-24 06:10:12 --> Helper loaded: file_helper
INFO - 2024-10-24 06:10:12 --> Helper loaded: string_helper
INFO - 2024-10-24 06:10:12 --> Helper loaded: form_helper
INFO - 2024-10-24 06:10:12 --> Helper loaded: my_helper
INFO - 2024-10-24 06:10:12 --> Database Driver Class Initialized
INFO - 2024-10-24 06:10:14 --> Upload Class Initialized
INFO - 2024-10-24 06:10:14 --> Email Class Initialized
INFO - 2024-10-24 06:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:10:14 --> Form Validation Class Initialized
INFO - 2024-10-24 06:10:14 --> Controller Class Initialized
INFO - 2024-10-24 11:40:14 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:40:14 --> Model "MainModel" initialized
INFO - 2024-10-24 11:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:40:14 --> Pagination Class Initialized
INFO - 2024-10-24 06:10:17 --> Config Class Initialized
INFO - 2024-10-24 06:10:17 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:10:17 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:10:17 --> Utf8 Class Initialized
INFO - 2024-10-24 06:10:17 --> URI Class Initialized
INFO - 2024-10-24 06:10:17 --> Router Class Initialized
INFO - 2024-10-24 06:10:17 --> Output Class Initialized
INFO - 2024-10-24 06:10:17 --> Security Class Initialized
DEBUG - 2024-10-24 06:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:10:17 --> Input Class Initialized
INFO - 2024-10-24 06:10:17 --> Language Class Initialized
INFO - 2024-10-24 06:10:17 --> Loader Class Initialized
INFO - 2024-10-24 06:10:17 --> Helper loaded: url_helper
INFO - 2024-10-24 06:10:17 --> Helper loaded: html_helper
INFO - 2024-10-24 06:10:17 --> Helper loaded: file_helper
INFO - 2024-10-24 06:10:17 --> Helper loaded: string_helper
INFO - 2024-10-24 06:10:17 --> Helper loaded: form_helper
INFO - 2024-10-24 06:10:17 --> Helper loaded: my_helper
INFO - 2024-10-24 06:10:17 --> Database Driver Class Initialized
INFO - 2024-10-24 06:10:19 --> Upload Class Initialized
INFO - 2024-10-24 06:10:19 --> Email Class Initialized
INFO - 2024-10-24 06:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:10:19 --> Form Validation Class Initialized
INFO - 2024-10-24 06:10:19 --> Controller Class Initialized
INFO - 2024-10-24 11:40:19 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:40:19 --> Model "MainModel" initialized
INFO - 2024-10-24 11:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:40:19 --> Pagination Class Initialized
INFO - 2024-10-24 06:10:22 --> Config Class Initialized
INFO - 2024-10-24 06:10:22 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:10:22 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:10:22 --> Utf8 Class Initialized
INFO - 2024-10-24 06:10:22 --> URI Class Initialized
INFO - 2024-10-24 06:10:22 --> Router Class Initialized
INFO - 2024-10-24 06:10:22 --> Output Class Initialized
INFO - 2024-10-24 06:10:22 --> Security Class Initialized
DEBUG - 2024-10-24 06:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:10:22 --> Input Class Initialized
INFO - 2024-10-24 06:10:22 --> Language Class Initialized
INFO - 2024-10-24 06:10:22 --> Loader Class Initialized
INFO - 2024-10-24 06:10:22 --> Helper loaded: url_helper
INFO - 2024-10-24 06:10:22 --> Helper loaded: html_helper
INFO - 2024-10-24 06:10:22 --> Helper loaded: file_helper
INFO - 2024-10-24 06:10:22 --> Helper loaded: string_helper
INFO - 2024-10-24 06:10:22 --> Helper loaded: form_helper
INFO - 2024-10-24 06:10:22 --> Helper loaded: my_helper
INFO - 2024-10-24 06:10:22 --> Database Driver Class Initialized
INFO - 2024-10-24 06:10:24 --> Upload Class Initialized
INFO - 2024-10-24 06:10:24 --> Email Class Initialized
INFO - 2024-10-24 06:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:10:24 --> Form Validation Class Initialized
INFO - 2024-10-24 06:10:24 --> Controller Class Initialized
INFO - 2024-10-24 11:40:24 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:40:24 --> Model "MainModel" initialized
INFO - 2024-10-24 11:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:40:24 --> Pagination Class Initialized
INFO - 2024-10-24 06:10:27 --> Config Class Initialized
INFO - 2024-10-24 06:10:27 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:10:27 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:10:27 --> Utf8 Class Initialized
INFO - 2024-10-24 06:10:27 --> URI Class Initialized
INFO - 2024-10-24 06:10:27 --> Router Class Initialized
INFO - 2024-10-24 06:10:27 --> Output Class Initialized
INFO - 2024-10-24 06:10:27 --> Security Class Initialized
DEBUG - 2024-10-24 06:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:10:27 --> Input Class Initialized
INFO - 2024-10-24 06:10:27 --> Language Class Initialized
INFO - 2024-10-24 06:10:27 --> Loader Class Initialized
INFO - 2024-10-24 06:10:27 --> Helper loaded: url_helper
INFO - 2024-10-24 06:10:27 --> Helper loaded: html_helper
INFO - 2024-10-24 06:10:27 --> Helper loaded: file_helper
INFO - 2024-10-24 06:10:27 --> Helper loaded: string_helper
INFO - 2024-10-24 06:10:27 --> Helper loaded: form_helper
INFO - 2024-10-24 06:10:27 --> Helper loaded: my_helper
INFO - 2024-10-24 06:10:27 --> Database Driver Class Initialized
INFO - 2024-10-24 06:10:29 --> Upload Class Initialized
INFO - 2024-10-24 06:10:29 --> Email Class Initialized
INFO - 2024-10-24 06:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:10:29 --> Form Validation Class Initialized
INFO - 2024-10-24 06:10:29 --> Controller Class Initialized
INFO - 2024-10-24 11:40:29 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:40:29 --> Model "MainModel" initialized
INFO - 2024-10-24 11:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:40:29 --> Pagination Class Initialized
INFO - 2024-10-24 06:10:32 --> Config Class Initialized
INFO - 2024-10-24 06:10:32 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:10:32 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:10:32 --> Utf8 Class Initialized
INFO - 2024-10-24 06:10:32 --> URI Class Initialized
INFO - 2024-10-24 06:10:32 --> Router Class Initialized
INFO - 2024-10-24 06:10:32 --> Output Class Initialized
INFO - 2024-10-24 06:10:32 --> Security Class Initialized
DEBUG - 2024-10-24 06:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:10:32 --> Input Class Initialized
INFO - 2024-10-24 06:10:32 --> Language Class Initialized
INFO - 2024-10-24 06:10:32 --> Loader Class Initialized
INFO - 2024-10-24 06:10:32 --> Helper loaded: url_helper
INFO - 2024-10-24 06:10:32 --> Helper loaded: html_helper
INFO - 2024-10-24 06:10:32 --> Helper loaded: file_helper
INFO - 2024-10-24 06:10:32 --> Helper loaded: string_helper
INFO - 2024-10-24 06:10:32 --> Helper loaded: form_helper
INFO - 2024-10-24 06:10:32 --> Helper loaded: my_helper
INFO - 2024-10-24 06:10:32 --> Database Driver Class Initialized
INFO - 2024-10-24 06:10:34 --> Upload Class Initialized
INFO - 2024-10-24 06:10:34 --> Email Class Initialized
INFO - 2024-10-24 06:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:10:34 --> Form Validation Class Initialized
INFO - 2024-10-24 06:10:34 --> Controller Class Initialized
INFO - 2024-10-24 11:40:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:40:34 --> Model "MainModel" initialized
INFO - 2024-10-24 11:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:40:34 --> Pagination Class Initialized
INFO - 2024-10-24 06:10:37 --> Config Class Initialized
INFO - 2024-10-24 06:10:37 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:10:37 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:10:37 --> Utf8 Class Initialized
INFO - 2024-10-24 06:10:37 --> URI Class Initialized
INFO - 2024-10-24 06:10:37 --> Router Class Initialized
INFO - 2024-10-24 06:10:37 --> Output Class Initialized
INFO - 2024-10-24 06:10:37 --> Security Class Initialized
DEBUG - 2024-10-24 06:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:10:37 --> Input Class Initialized
INFO - 2024-10-24 06:10:37 --> Language Class Initialized
INFO - 2024-10-24 06:10:37 --> Loader Class Initialized
INFO - 2024-10-24 06:10:37 --> Helper loaded: url_helper
INFO - 2024-10-24 06:10:37 --> Helper loaded: html_helper
INFO - 2024-10-24 06:10:37 --> Helper loaded: file_helper
INFO - 2024-10-24 06:10:38 --> Helper loaded: string_helper
INFO - 2024-10-24 06:10:38 --> Helper loaded: form_helper
INFO - 2024-10-24 06:10:38 --> Helper loaded: my_helper
INFO - 2024-10-24 06:10:38 --> Database Driver Class Initialized
INFO - 2024-10-24 06:10:40 --> Upload Class Initialized
INFO - 2024-10-24 06:10:40 --> Email Class Initialized
INFO - 2024-10-24 06:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:10:40 --> Form Validation Class Initialized
INFO - 2024-10-24 06:10:40 --> Controller Class Initialized
INFO - 2024-10-24 11:40:40 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:40:40 --> Model "MainModel" initialized
INFO - 2024-10-24 11:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:40:40 --> Pagination Class Initialized
INFO - 2024-10-24 06:10:42 --> Config Class Initialized
INFO - 2024-10-24 06:10:42 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:10:42 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:10:42 --> Utf8 Class Initialized
INFO - 2024-10-24 06:10:42 --> URI Class Initialized
INFO - 2024-10-24 06:10:42 --> Router Class Initialized
INFO - 2024-10-24 06:10:42 --> Output Class Initialized
INFO - 2024-10-24 06:10:42 --> Security Class Initialized
DEBUG - 2024-10-24 06:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:10:42 --> Input Class Initialized
INFO - 2024-10-24 06:10:42 --> Language Class Initialized
INFO - 2024-10-24 06:10:42 --> Loader Class Initialized
INFO - 2024-10-24 06:10:42 --> Helper loaded: url_helper
INFO - 2024-10-24 06:10:42 --> Helper loaded: html_helper
INFO - 2024-10-24 06:10:42 --> Helper loaded: file_helper
INFO - 2024-10-24 06:10:42 --> Helper loaded: string_helper
INFO - 2024-10-24 06:10:42 --> Helper loaded: form_helper
INFO - 2024-10-24 06:10:42 --> Helper loaded: my_helper
INFO - 2024-10-24 06:10:42 --> Database Driver Class Initialized
INFO - 2024-10-24 06:10:44 --> Upload Class Initialized
INFO - 2024-10-24 06:10:44 --> Email Class Initialized
INFO - 2024-10-24 06:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:10:44 --> Form Validation Class Initialized
INFO - 2024-10-24 06:10:44 --> Controller Class Initialized
INFO - 2024-10-24 11:40:44 --> Model "RoomserviceModel" initialized
INFO - 2024-10-24 11:40:44 --> Model "MainModel" initialized
INFO - 2024-10-24 11:40:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-24 11:40:44 --> Pagination Class Initialized
INFO - 2024-10-24 06:13:14 --> Config Class Initialized
INFO - 2024-10-24 06:13:14 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:13:14 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:13:14 --> Utf8 Class Initialized
INFO - 2024-10-24 06:13:14 --> URI Class Initialized
DEBUG - 2024-10-24 06:13:14 --> No URI present. Default controller set.
INFO - 2024-10-24 06:13:14 --> Router Class Initialized
INFO - 2024-10-24 06:13:14 --> Output Class Initialized
INFO - 2024-10-24 06:13:14 --> Security Class Initialized
DEBUG - 2024-10-24 06:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:13:14 --> Input Class Initialized
INFO - 2024-10-24 06:13:14 --> Language Class Initialized
INFO - 2024-10-24 06:13:14 --> Loader Class Initialized
INFO - 2024-10-24 06:13:14 --> Helper loaded: url_helper
INFO - 2024-10-24 06:13:14 --> Helper loaded: html_helper
INFO - 2024-10-24 06:13:14 --> Helper loaded: file_helper
INFO - 2024-10-24 06:13:14 --> Helper loaded: string_helper
INFO - 2024-10-24 06:13:14 --> Helper loaded: form_helper
INFO - 2024-10-24 06:13:14 --> Helper loaded: my_helper
INFO - 2024-10-24 06:13:14 --> Database Driver Class Initialized
INFO - 2024-10-24 06:13:17 --> Upload Class Initialized
INFO - 2024-10-24 06:13:17 --> Email Class Initialized
INFO - 2024-10-24 06:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:13:17 --> Form Validation Class Initialized
INFO - 2024-10-24 06:13:17 --> Controller Class Initialized
INFO - 2024-10-24 11:43:17 --> Model "MainModel" initialized
INFO - 2024-10-24 11:43:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 11:43:17 --> Final output sent to browser
DEBUG - 2024-10-24 11:43:17 --> Total execution time: 2.3495
INFO - 2024-10-24 06:43:48 --> Config Class Initialized
INFO - 2024-10-24 06:43:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:48 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:48 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:48 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:48 --> Router Class Initialized
INFO - 2024-10-24 06:43:48 --> Output Class Initialized
INFO - 2024-10-24 06:43:48 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:48 --> Input Class Initialized
INFO - 2024-10-24 06:43:48 --> Language Class Initialized
INFO - 2024-10-24 06:43:48 --> Loader Class Initialized
INFO - 2024-10-24 06:43:48 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:48 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:48 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:48 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:48 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:48 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:48 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:49 --> Config Class Initialized
INFO - 2024-10-24 06:43:49 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:49 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:49 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:49 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:49 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:49 --> Router Class Initialized
INFO - 2024-10-24 06:43:49 --> Output Class Initialized
INFO - 2024-10-24 06:43:49 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:49 --> Input Class Initialized
INFO - 2024-10-24 06:43:49 --> Language Class Initialized
INFO - 2024-10-24 06:43:49 --> Loader Class Initialized
INFO - 2024-10-24 06:43:49 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:49 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:49 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:49 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:49 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:49 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:49 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:50 --> Upload Class Initialized
INFO - 2024-10-24 06:43:50 --> Email Class Initialized
INFO - 2024-10-24 06:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:50 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:50 --> Controller Class Initialized
INFO - 2024-10-24 12:13:50 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:50 --> Config Class Initialized
INFO - 2024-10-24 12:13:50 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:43:50 --> Hooks Class Initialized
INFO - 2024-10-24 12:13:50 --> Final output sent to browser
DEBUG - 2024-10-24 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 12:13:50 --> Total execution time: 2.4757
INFO - 2024-10-24 06:43:50 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:50 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:50 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:50 --> Router Class Initialized
INFO - 2024-10-24 06:43:50 --> Output Class Initialized
INFO - 2024-10-24 06:43:50 --> Security Class Initialized
INFO - 2024-10-24 06:43:50 --> Config Class Initialized
DEBUG - 2024-10-24 06:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:50 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:50 --> Input Class Initialized
DEBUG - 2024-10-24 06:43:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:50 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:50 --> Language Class Initialized
INFO - 2024-10-24 06:43:51 --> URI Class Initialized
INFO - 2024-10-24 06:43:51 --> Loader Class Initialized
INFO - 2024-10-24 06:43:51 --> Router Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:51 --> Output Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:51 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:51 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:51 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:51 --> Input Class Initialized
INFO - 2024-10-24 06:43:51 --> Language Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: form_helper
ERROR - 2024-10-24 06:43:51 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 06:43:51 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:51 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:51 --> Config Class Initialized
INFO - 2024-10-24 06:43:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:51 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:51 --> URI Class Initialized
INFO - 2024-10-24 06:43:51 --> Router Class Initialized
INFO - 2024-10-24 06:43:51 --> Output Class Initialized
INFO - 2024-10-24 06:43:51 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:51 --> Input Class Initialized
INFO - 2024-10-24 06:43:51 --> Language Class Initialized
ERROR - 2024-10-24 06:43:51 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 06:43:51 --> Config Class Initialized
INFO - 2024-10-24 06:43:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:51 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:51 --> Upload Class Initialized
INFO - 2024-10-24 06:43:51 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:51 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:51 --> Email Class Initialized
INFO - 2024-10-24 06:43:51 --> Router Class Initialized
INFO - 2024-10-24 06:43:51 --> Output Class Initialized
INFO - 2024-10-24 06:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:51 --> Security Class Initialized
INFO - 2024-10-24 06:43:51 --> Form Validation Class Initialized
DEBUG - 2024-10-24 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:51 --> Controller Class Initialized
INFO - 2024-10-24 12:13:51 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:51 --> Input Class Initialized
INFO - 2024-10-24 12:13:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 12:13:51 --> Final output sent to browser
INFO - 2024-10-24 06:43:51 --> Language Class Initialized
DEBUG - 2024-10-24 12:13:51 --> Total execution time: 2.4101
INFO - 2024-10-24 06:43:51 --> Loader Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:51 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:51 --> Config Class Initialized
INFO - 2024-10-24 06:43:51 --> Config Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:51 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:51 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: string_helper
DEBUG - 2024-10-24 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:51 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:51 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:51 --> URI Class Initialized
INFO - 2024-10-24 06:43:51 --> URI Class Initialized
INFO - 2024-10-24 06:43:51 --> Helper loaded: my_helper
DEBUG - 2024-10-24 06:43:51 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:51 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:51 --> Router Class Initialized
INFO - 2024-10-24 06:43:51 --> Output Class Initialized
INFO - 2024-10-24 06:43:51 --> Router Class Initialized
INFO - 2024-10-24 06:43:51 --> Security Class Initialized
INFO - 2024-10-24 06:43:51 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:51 --> Security Class Initialized
INFO - 2024-10-24 06:43:51 --> Input Class Initialized
DEBUG - 2024-10-24 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:51 --> Language Class Initialized
INFO - 2024-10-24 06:43:51 --> Input Class Initialized
INFO - 2024-10-24 06:43:52 --> Language Class Initialized
ERROR - 2024-10-24 06:43:52 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 06:43:52 --> Loader Class Initialized
INFO - 2024-10-24 06:43:52 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:52 --> Config Class Initialized
INFO - 2024-10-24 06:43:52 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:52 --> Helper loaded: my_helper
DEBUG - 2024-10-24 06:43:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:52 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:52 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:52 --> URI Class Initialized
INFO - 2024-10-24 06:43:52 --> Router Class Initialized
INFO - 2024-10-24 06:43:52 --> Output Class Initialized
INFO - 2024-10-24 06:43:52 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:52 --> Input Class Initialized
INFO - 2024-10-24 06:43:52 --> Language Class Initialized
ERROR - 2024-10-24 06:43:52 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 06:43:52 --> Config Class Initialized
INFO - 2024-10-24 06:43:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:52 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:52 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:52 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:52 --> Router Class Initialized
INFO - 2024-10-24 06:43:52 --> Output Class Initialized
INFO - 2024-10-24 06:43:52 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:52 --> Input Class Initialized
INFO - 2024-10-24 06:43:52 --> Language Class Initialized
INFO - 2024-10-24 06:43:52 --> Loader Class Initialized
INFO - 2024-10-24 06:43:52 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:52 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:52 --> Config Class Initialized
INFO - 2024-10-24 06:43:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:52 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:52 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:52 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:52 --> Router Class Initialized
INFO - 2024-10-24 06:43:52 --> Output Class Initialized
INFO - 2024-10-24 06:43:52 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:52 --> Input Class Initialized
INFO - 2024-10-24 06:43:52 --> Language Class Initialized
INFO - 2024-10-24 06:43:52 --> Loader Class Initialized
INFO - 2024-10-24 06:43:52 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:52 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:53 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:53 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:53 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:53 --> Upload Class Initialized
INFO - 2024-10-24 06:43:53 --> Email Class Initialized
INFO - 2024-10-24 06:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:53 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:53 --> Controller Class Initialized
INFO - 2024-10-24 12:13:53 --> Model "MainModel" initialized
INFO - 2024-10-24 12:13:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 12:13:53 --> Final output sent to browser
DEBUG - 2024-10-24 12:13:53 --> Total execution time: 2.5136
INFO - 2024-10-24 06:43:53 --> Config Class Initialized
INFO - 2024-10-24 06:43:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:53 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:53 --> URI Class Initialized
INFO - 2024-10-24 06:43:53 --> Router Class Initialized
INFO - 2024-10-24 06:43:53 --> Output Class Initialized
INFO - 2024-10-24 06:43:53 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:53 --> Input Class Initialized
INFO - 2024-10-24 06:43:53 --> Language Class Initialized
ERROR - 2024-10-24 06:43:53 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 06:43:53 --> Config Class Initialized
INFO - 2024-10-24 06:43:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:53 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:53 --> URI Class Initialized
INFO - 2024-10-24 06:43:53 --> Router Class Initialized
INFO - 2024-10-24 06:43:53 --> Output Class Initialized
INFO - 2024-10-24 06:43:53 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:53 --> Input Class Initialized
INFO - 2024-10-24 06:43:53 --> Language Class Initialized
ERROR - 2024-10-24 06:43:53 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 06:43:53 --> Config Class Initialized
INFO - 2024-10-24 06:43:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:53 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:53 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:53 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:53 --> Router Class Initialized
INFO - 2024-10-24 06:43:53 --> Output Class Initialized
INFO - 2024-10-24 06:43:53 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:53 --> Input Class Initialized
INFO - 2024-10-24 06:43:53 --> Language Class Initialized
INFO - 2024-10-24 06:43:53 --> Loader Class Initialized
INFO - 2024-10-24 06:43:53 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:53 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:53 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:53 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:53 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:53 --> Upload Class Initialized
INFO - 2024-10-24 06:43:53 --> Config Class Initialized
INFO - 2024-10-24 06:43:53 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:53 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:53 --> Email Class Initialized
INFO - 2024-10-24 06:43:54 --> Database Driver Class Initialized
DEBUG - 2024-10-24 06:43:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:54 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:54 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:54 --> Controller Class Initialized
INFO - 2024-10-24 12:13:54 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:54 --> URI Class Initialized
INFO - 2024-10-24 12:13:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
DEBUG - 2024-10-24 06:43:54 --> No URI present. Default controller set.
INFO - 2024-10-24 12:13:54 --> Final output sent to browser
INFO - 2024-10-24 06:43:54 --> Router Class Initialized
DEBUG - 2024-10-24 12:13:54 --> Total execution time: 2.7309
INFO - 2024-10-24 06:43:54 --> Output Class Initialized
INFO - 2024-10-24 06:43:54 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:54 --> Upload Class Initialized
INFO - 2024-10-24 06:43:54 --> Input Class Initialized
INFO - 2024-10-24 06:43:54 --> Email Class Initialized
INFO - 2024-10-24 06:43:54 --> Language Class Initialized
INFO - 2024-10-24 06:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:54 --> Loader Class Initialized
INFO - 2024-10-24 06:43:54 --> Config Class Initialized
INFO - 2024-10-24 06:43:54 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:54 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:54 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:54 --> Controller Class Initialized
INFO - 2024-10-24 06:43:54 --> Helper loaded: html_helper
DEBUG - 2024-10-24 06:43:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:13:54 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:54 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:54 --> Utf8 Class Initialized
INFO - 2024-10-24 12:13:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:43:54 --> URI Class Initialized
INFO - 2024-10-24 06:43:54 --> Helper loaded: string_helper
INFO - 2024-10-24 12:13:54 --> Final output sent to browser
INFO - 2024-10-24 06:43:54 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:54 --> Router Class Initialized
DEBUG - 2024-10-24 12:13:54 --> Total execution time: 2.6793
INFO - 2024-10-24 06:43:54 --> Output Class Initialized
INFO - 2024-10-24 06:43:54 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:54 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:54 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:54 --> Input Class Initialized
INFO - 2024-10-24 06:43:54 --> Language Class Initialized
INFO - 2024-10-24 06:43:54 --> Config Class Initialized
ERROR - 2024-10-24 06:43:54 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-24 06:43:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:54 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:54 --> URI Class Initialized
INFO - 2024-10-24 06:43:54 --> Router Class Initialized
INFO - 2024-10-24 06:43:54 --> Upload Class Initialized
INFO - 2024-10-24 06:43:54 --> Config Class Initialized
INFO - 2024-10-24 06:43:54 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:54 --> Output Class Initialized
INFO - 2024-10-24 06:43:54 --> Email Class Initialized
INFO - 2024-10-24 06:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:54 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:54 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:54 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:54 --> Controller Class Initialized
INFO - 2024-10-24 06:43:54 --> URI Class Initialized
INFO - 2024-10-24 06:43:54 --> Input Class Initialized
INFO - 2024-10-24 12:13:54 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:54 --> Language Class Initialized
INFO - 2024-10-24 06:43:54 --> Router Class Initialized
INFO - 2024-10-24 06:43:54 --> Output Class Initialized
ERROR - 2024-10-24 06:43:54 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 12:13:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 12:13:54 --> Final output sent to browser
INFO - 2024-10-24 06:43:54 --> Security Class Initialized
DEBUG - 2024-10-24 12:13:54 --> Total execution time: 2.5128
INFO - 2024-10-24 06:43:54 --> Config Class Initialized
DEBUG - 2024-10-24 06:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:54 --> Config Class Initialized
INFO - 2024-10-24 06:43:54 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:54 --> Input Class Initialized
INFO - 2024-10-24 06:43:54 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:54 --> Language Class Initialized
DEBUG - 2024-10-24 06:43:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:55 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:43:55 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-24 06:43:55 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:55 --> Upload Class Initialized
INFO - 2024-10-24 06:43:55 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:55 --> URI Class Initialized
INFO - 2024-10-24 06:43:55 --> URI Class Initialized
INFO - 2024-10-24 06:43:55 --> Config Class Initialized
INFO - 2024-10-24 06:43:55 --> Email Class Initialized
INFO - 2024-10-24 06:43:55 --> Config Class Initialized
DEBUG - 2024-10-24 06:43:55 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:55 --> Router Class Initialized
INFO - 2024-10-24 06:43:55 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:55 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:55 --> Router Class Initialized
INFO - 2024-10-24 06:43:55 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:55 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:55 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:55 --> Output Class Initialized
INFO - 2024-10-24 06:43:55 --> Security Class Initialized
INFO - 2024-10-24 06:43:55 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:55 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:55 --> Security Class Initialized
INFO - 2024-10-24 06:43:55 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:55 --> Controller Class Initialized
INFO - 2024-10-24 06:43:55 --> URI Class Initialized
INFO - 2024-10-24 06:43:55 --> URI Class Initialized
INFO - 2024-10-24 06:43:55 --> Input Class Initialized
INFO - 2024-10-24 06:43:55 --> Input Class Initialized
INFO - 2024-10-24 12:13:55 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:55 --> Router Class Initialized
INFO - 2024-10-24 06:43:55 --> Language Class Initialized
INFO - 2024-10-24 06:43:55 --> Router Class Initialized
INFO - 2024-10-24 12:13:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:43:55 --> Language Class Initialized
INFO - 2024-10-24 06:43:55 --> Loader Class Initialized
INFO - 2024-10-24 06:43:55 --> Output Class Initialized
INFO - 2024-10-24 06:43:55 --> Output Class Initialized
INFO - 2024-10-24 12:13:55 --> Final output sent to browser
INFO - 2024-10-24 06:43:55 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:55 --> Security Class Initialized
INFO - 2024-10-24 06:43:55 --> Security Class Initialized
ERROR - 2024-10-24 06:43:55 --> 404 Page Not Found: Xmlrpcphp/index
DEBUG - 2024-10-24 12:13:55 --> Total execution time: 2.7654
INFO - 2024-10-24 06:43:55 --> Helper loaded: html_helper
DEBUG - 2024-10-24 06:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:55 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:55 --> Input Class Initialized
INFO - 2024-10-24 06:43:55 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:55 --> Config Class Initialized
INFO - 2024-10-24 06:43:55 --> Language Class Initialized
INFO - 2024-10-24 06:43:55 --> Config Class Initialized
INFO - 2024-10-24 06:43:55 --> Input Class Initialized
INFO - 2024-10-24 06:43:55 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:55 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:55 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:55 --> Language Class Initialized
ERROR - 2024-10-24 06:43:55 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-24 06:43:55 --> Helper loaded: my_helper
ERROR - 2024-10-24 06:43:56 --> 404 Page Not Found: Blog/wp-includes
DEBUG - 2024-10-24 06:43:56 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:56 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:56 --> Config Class Initialized
INFO - 2024-10-24 06:43:56 --> Upload Class Initialized
INFO - 2024-10-24 06:43:56 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:56 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:56 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:56 --> Config Class Initialized
INFO - 2024-10-24 06:43:56 --> Email Class Initialized
INFO - 2024-10-24 06:43:56 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:56 --> URI Class Initialized
INFO - 2024-10-24 06:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:56 --> Router Class Initialized
INFO - 2024-10-24 06:43:56 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:56 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:56 --> Form Validation Class Initialized
DEBUG - 2024-10-24 06:43:56 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:56 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:56 --> URI Class Initialized
INFO - 2024-10-24 06:43:56 --> Controller Class Initialized
INFO - 2024-10-24 06:43:56 --> Router Class Initialized
INFO - 2024-10-24 06:43:56 --> Security Class Initialized
INFO - 2024-10-24 06:43:56 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:56 --> Router Class Initialized
INFO - 2024-10-24 12:13:56 --> Model "MainModel" initialized
DEBUG - 2024-10-24 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:56 --> Output Class Initialized
INFO - 2024-10-24 06:43:56 --> URI Class Initialized
INFO - 2024-10-24 06:43:56 --> Output Class Initialized
INFO - 2024-10-24 12:13:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:43:56 --> Input Class Initialized
INFO - 2024-10-24 06:43:56 --> Security Class Initialized
INFO - 2024-10-24 06:43:56 --> Router Class Initialized
INFO - 2024-10-24 06:43:56 --> Upload Class Initialized
INFO - 2024-10-24 06:43:56 --> Security Class Initialized
INFO - 2024-10-24 06:43:56 --> Language Class Initialized
INFO - 2024-10-24 12:13:56 --> Final output sent to browser
INFO - 2024-10-24 06:43:56 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:56 --> Email Class Initialized
ERROR - 2024-10-24 06:43:56 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
DEBUG - 2024-10-24 12:13:56 --> Total execution time: 2.8143
DEBUG - 2024-10-24 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:56 --> Security Class Initialized
INFO - 2024-10-24 06:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:43:56 --> Input Class Initialized
DEBUG - 2024-10-24 06:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:56 --> Config Class Initialized
INFO - 2024-10-24 06:43:56 --> Input Class Initialized
INFO - 2024-10-24 06:43:56 --> Input Class Initialized
INFO - 2024-10-24 06:43:56 --> Config Class Initialized
INFO - 2024-10-24 06:43:56 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:56 --> Language Class Initialized
INFO - 2024-10-24 06:43:56 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:56 --> Language Class Initialized
INFO - 2024-10-24 06:43:56 --> Language Class Initialized
INFO - 2024-10-24 06:43:56 --> Loader Class Initialized
INFO - 2024-10-24 06:43:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:56 --> Controller Class Initialized
ERROR - 2024-10-24 06:43:56 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-24 06:43:56 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:56 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:43:56 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 06:43:56 --> Helper loaded: url_helper
INFO - 2024-10-24 12:13:56 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:56 --> URI Class Initialized
INFO - 2024-10-24 06:43:56 --> Utf8 Class Initialized
INFO - 2024-10-24 12:13:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:43:56 --> Helper loaded: html_helper
INFO - 2024-10-24 12:13:57 --> Final output sent to browser
INFO - 2024-10-24 06:43:57 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
DEBUG - 2024-10-24 12:13:57 --> Total execution time: 3.0572
INFO - 2024-10-24 06:43:57 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
DEBUG - 2024-10-24 06:43:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:57 --> Security Class Initialized
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
INFO - 2024-10-24 06:43:57 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
INFO - 2024-10-24 06:43:57 --> Helper loaded: my_helper
DEBUG - 2024-10-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:57 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:57 --> Security Class Initialized
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:57 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:57 --> Input Class Initialized
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:57 --> Language Class Initialized
DEBUG - 2024-10-24 06:43:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
INFO - 2024-10-24 06:43:57 --> Input Class Initialized
INFO - 2024-10-24 06:43:57 --> Utf8 Class Initialized
ERROR - 2024-10-24 06:43:57 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
INFO - 2024-10-24 06:43:57 --> Language Class Initialized
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
INFO - 2024-10-24 06:43:57 --> Security Class Initialized
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
ERROR - 2024-10-24 06:43:57 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
DEBUG - 2024-10-24 06:43:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:57 --> Input Class Initialized
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
INFO - 2024-10-24 06:43:57 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
INFO - 2024-10-24 06:43:57 --> Language Class Initialized
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:57 --> Security Class Initialized
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:57 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:43:57 --> 404 Page Not Found: Wordpress/wp-includes
DEBUG - 2024-10-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
INFO - 2024-10-24 06:43:57 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:57 --> Input Class Initialized
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
INFO - 2024-10-24 06:43:57 --> Security Class Initialized
INFO - 2024-10-24 06:43:57 --> Language Class Initialized
INFO - 2024-10-24 06:43:57 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:57 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
ERROR - 2024-10-24 06:43:57 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
INFO - 2024-10-24 06:43:57 --> Input Class Initialized
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
INFO - 2024-10-24 06:43:57 --> Language Class Initialized
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:57 --> Security Class Initialized
INFO - 2024-10-24 06:43:57 --> Security Class Initialized
INFO - 2024-10-24 06:43:57 --> Utf8 Class Initialized
ERROR - 2024-10-24 06:43:57 --> 404 Page Not Found: Wp/wp-includes
DEBUG - 2024-10-24 06:43:57 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
DEBUG - 2024-10-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:57 --> Input Class Initialized
INFO - 2024-10-24 06:43:57 --> Input Class Initialized
INFO - 2024-10-24 06:43:57 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:57 --> Router Class Initialized
INFO - 2024-10-24 06:43:57 --> Config Class Initialized
INFO - 2024-10-24 06:43:57 --> Language Class Initialized
INFO - 2024-10-24 06:43:57 --> URI Class Initialized
INFO - 2024-10-24 06:43:57 --> Language Class Initialized
INFO - 2024-10-24 06:43:57 --> Output Class Initialized
INFO - 2024-10-24 06:43:57 --> Hooks Class Initialized
ERROR - 2024-10-24 06:43:58 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-24 06:43:58 --> Loader Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
INFO - 2024-10-24 06:43:58 --> Helper loaded: url_helper
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:58 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
INFO - 2024-10-24 06:43:58 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:58 --> Config Class Initialized
INFO - 2024-10-24 06:43:58 --> Upload Class Initialized
INFO - 2024-10-24 06:43:58 --> Input Class Initialized
INFO - 2024-10-24 06:43:58 --> URI Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
INFO - 2024-10-24 06:43:58 --> Email Class Initialized
INFO - 2024-10-24 06:43:58 --> Helper loaded: file_helper
INFO - 2024-10-24 06:43:58 --> Language Class Initialized
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:58 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:58 --> Session: Class initialized using 'files' driver.
ERROR - 2024-10-24 06:43:58 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
INFO - 2024-10-24 06:43:58 --> Input Class Initialized
DEBUG - 2024-10-24 06:43:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:58 --> Helper loaded: string_helper
INFO - 2024-10-24 06:43:58 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
INFO - 2024-10-24 06:43:58 --> Language Class Initialized
INFO - 2024-10-24 06:43:58 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:58 --> Helper loaded: form_helper
ERROR - 2024-10-24 06:43:58 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 06:43:58 --> Controller Class Initialized
INFO - 2024-10-24 06:43:58 --> URI Class Initialized
INFO - 2024-10-24 06:43:58 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:58 --> Config Class Initialized
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
INFO - 2024-10-24 12:13:58 --> Model "MainModel" initialized
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:58 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:58 --> Hooks Class Initialized
INFO - 2024-10-24 12:13:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:43:58 --> Config Class Initialized
INFO - 2024-10-24 06:43:58 --> Input Class Initialized
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:13:58 --> Final output sent to browser
INFO - 2024-10-24 06:43:58 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
INFO - 2024-10-24 06:43:58 --> Language Class Initialized
DEBUG - 2024-10-24 06:43:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:58 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 12:13:58 --> Total execution time: 3.5338
ERROR - 2024-10-24 06:43:58 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 06:43:58 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:58 --> Input Class Initialized
INFO - 2024-10-24 06:43:58 --> URI Class Initialized
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
INFO - 2024-10-24 06:43:58 --> Language Class Initialized
INFO - 2024-10-24 06:43:58 --> URI Class Initialized
INFO - 2024-10-24 06:43:58 --> Config Class Initialized
ERROR - 2024-10-24 06:43:58 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-24 06:43:58 --> Config Class Initialized
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:58 --> No URI present. Default controller set.
INFO - 2024-10-24 06:43:58 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:58 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
DEBUG - 2024-10-24 06:43:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:58 --> Config Class Initialized
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:58 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:58 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:58 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:58 --> Input Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
INFO - 2024-10-24 06:43:58 --> URI Class Initialized
INFO - 2024-10-24 06:43:58 --> Language Class Initialized
DEBUG - 2024-10-24 06:43:58 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:58 --> URI Class Initialized
INFO - 2024-10-24 06:43:58 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
INFO - 2024-10-24 06:43:58 --> Input Class Initialized
ERROR - 2024-10-24 06:43:58 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
INFO - 2024-10-24 06:43:58 --> URI Class Initialized
INFO - 2024-10-24 06:43:58 --> Language Class Initialized
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
INFO - 2024-10-24 06:43:58 --> Loader Class Initialized
INFO - 2024-10-24 06:43:58 --> Config Class Initialized
INFO - 2024-10-24 06:43:58 --> Security Class Initialized
INFO - 2024-10-24 06:43:58 --> Router Class Initialized
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:58 --> Helper loaded: url_helper
INFO - 2024-10-24 06:43:58 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
INFO - 2024-10-24 06:43:59 --> Helper loaded: html_helper
INFO - 2024-10-24 06:43:59 --> Security Class Initialized
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:59 --> Helper loaded: file_helper
DEBUG - 2024-10-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
INFO - 2024-10-24 06:43:59 --> Helper loaded: string_helper
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
INFO - 2024-10-24 06:43:59 --> URI Class Initialized
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-24 06:43:59 --> Helper loaded: form_helper
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
INFO - 2024-10-24 06:43:59 --> Router Class Initialized
INFO - 2024-10-24 06:43:59 --> Helper loaded: my_helper
INFO - 2024-10-24 06:43:59 --> Output Class Initialized
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
INFO - 2024-10-24 06:43:59 --> Security Class Initialized
INFO - 2024-10-24 06:43:59 --> Database Driver Class Initialized
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:59 --> Upload Class Initialized
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:59 --> Email Class Initialized
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:59 --> URI Class Initialized
INFO - 2024-10-24 06:43:59 --> Session: Class initialized using 'files' driver.
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 06:43:59 --> URI Class Initialized
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:59 --> Router Class Initialized
INFO - 2024-10-24 06:43:59 --> Router Class Initialized
INFO - 2024-10-24 06:43:59 --> URI Class Initialized
INFO - 2024-10-24 06:43:59 --> Form Validation Class Initialized
INFO - 2024-10-24 06:43:59 --> Output Class Initialized
INFO - 2024-10-24 06:43:59 --> Controller Class Initialized
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
INFO - 2024-10-24 06:43:59 --> Output Class Initialized
INFO - 2024-10-24 06:43:59 --> Router Class Initialized
INFO - 2024-10-24 06:43:59 --> Security Class Initialized
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:59 --> Security Class Initialized
INFO - 2024-10-24 12:13:59 --> Model "MainModel" initialized
INFO - 2024-10-24 06:43:59 --> Output Class Initialized
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:13:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:43:59 --> Security Class Initialized
DEBUG - 2024-10-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
INFO - 2024-10-24 12:13:59 --> Final output sent to browser
DEBUG - 2024-10-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
INFO - 2024-10-24 06:43:59 --> URI Class Initialized
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
DEBUG - 2024-10-24 12:13:59 --> Total execution time: 3.7462
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
INFO - 2024-10-24 06:43:59 --> Router Class Initialized
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 06:43:59 --> Output Class Initialized
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-24 06:43:59 --> Security Class Initialized
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
DEBUG - 2024-10-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:59 --> Input Class Initialized
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:59 --> Language Class Initialized
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:59 --> Config Class Initialized
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:59 --> Hooks Class Initialized
INFO - 2024-10-24 06:43:59 --> URI Class Initialized
ERROR - 2024-10-24 06:43:59 --> 404 Page Not Found: 2018/wp-includes
DEBUG - 2024-10-24 06:43:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:43:59 --> Router Class Initialized
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:43:59 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
INFO - 2024-10-24 06:44:00 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:00 --> No URI present. Default controller set.
INFO - 2024-10-24 06:44:00 --> Config Class Initialized
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 06:44:00 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
INFO - 2024-10-24 06:44:00 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
INFO - 2024-10-24 06:44:00 --> Language Class Initialized
INFO - 2024-10-24 06:44:00 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 06:44:00 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:00 --> 404 Page Not Found: Blog/wp-includes
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:00 --> Language Class Initialized
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
INFO - 2024-10-24 06:44:00 --> Input Class Initialized
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
ERROR - 2024-10-24 06:44:00 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-24 06:44:00 --> Language Class Initialized
INFO - 2024-10-24 06:44:00 --> Input Class Initialized
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
INFO - 2024-10-24 06:44:00 --> Config Class Initialized
INFO - 2024-10-24 06:44:00 --> Loader Class Initialized
INFO - 2024-10-24 06:44:00 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:00 --> Helper loaded: url_helper
ERROR - 2024-10-24 06:44:00 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 06:44:00 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:00 --> Upload Class Initialized
DEBUG - 2024-10-24 06:44:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:00 --> Config Class Initialized
INFO - 2024-10-24 06:44:00 --> Helper loaded: html_helper
INFO - 2024-10-24 06:44:00 --> Input Class Initialized
INFO - 2024-10-24 06:44:00 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:00 --> Config Class Initialized
INFO - 2024-10-24 06:44:00 --> Helper loaded: file_helper
INFO - 2024-10-24 06:44:00 --> Email Class Initialized
INFO - 2024-10-24 06:44:00 --> Language Class Initialized
INFO - 2024-10-24 06:44:00 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:00 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:00 --> Session: Class initialized using 'files' driver.
ERROR - 2024-10-24 06:44:00 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-24 06:44:00 --> Helper loaded: string_helper
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 06:44:00 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:00 --> Form Validation Class Initialized
INFO - 2024-10-24 06:44:00 --> Helper loaded: form_helper
DEBUG - 2024-10-24 06:44:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:00 --> Controller Class Initialized
INFO - 2024-10-24 06:44:00 --> Config Class Initialized
INFO - 2024-10-24 06:44:00 --> Helper loaded: my_helper
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 06:44:00 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
INFO - 2024-10-24 06:44:00 --> Database Driver Class Initialized
INFO - 2024-10-24 06:44:00 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
INFO - 2024-10-24 12:14:00 --> Model "MainModel" initialized
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 12:14:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
INFO - 2024-10-24 12:14:00 --> Final output sent to browser
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
INFO - 2024-10-24 06:44:00 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:00 --> Input Class Initialized
DEBUG - 2024-10-24 12:14:00 --> Total execution time: 3.3758
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:00 --> Output Class Initialized
INFO - 2024-10-24 06:44:00 --> Input Class Initialized
INFO - 2024-10-24 06:44:00 --> URI Class Initialized
INFO - 2024-10-24 06:44:00 --> Security Class Initialized
INFO - 2024-10-24 06:44:00 --> Language Class Initialized
INFO - 2024-10-24 06:44:00 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:00 --> Config Class Initialized
INFO - 2024-10-24 06:44:00 --> Router Class Initialized
ERROR - 2024-10-24 06:44:00 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-10-24 06:44:01 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:01 --> Output Class Initialized
INFO - 2024-10-24 06:44:01 --> Input Class Initialized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
INFO - 2024-10-24 06:44:01 --> Language Class Initialized
INFO - 2024-10-24 06:44:01 --> Security Class Initialized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:01 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:44:01 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:01 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:01 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:01 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
INFO - 2024-10-24 06:44:01 --> Language Class Initialized
INFO - 2024-10-24 06:44:01 --> URI Class Initialized
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:01 --> Utf8 Class Initialized
ERROR - 2024-10-24 06:44:01 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-24 06:44:01 --> Router Class Initialized
INFO - 2024-10-24 06:44:01 --> Upload Class Initialized
INFO - 2024-10-24 06:44:01 --> Output Class Initialized
INFO - 2024-10-24 06:44:01 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:01 --> URI Class Initialized
INFO - 2024-10-24 06:44:01 --> Email Class Initialized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
INFO - 2024-10-24 06:44:01 --> Router Class Initialized
INFO - 2024-10-24 06:44:01 --> Security Class Initialized
INFO - 2024-10-24 06:44:01 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:01 --> Router Class Initialized
INFO - 2024-10-24 06:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:01 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:01 --> URI Class Initialized
INFO - 2024-10-24 06:44:01 --> Output Class Initialized
INFO - 2024-10-24 06:44:01 --> Form Validation Class Initialized
INFO - 2024-10-24 06:44:01 --> Security Class Initialized
INFO - 2024-10-24 06:44:01 --> Input Class Initialized
INFO - 2024-10-24 06:44:01 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:01 --> Controller Class Initialized
DEBUG - 2024-10-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:01 --> Security Class Initialized
INFO - 2024-10-24 06:44:01 --> Language Class Initialized
INFO - 2024-10-24 06:44:01 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:01 --> Output Class Initialized
INFO - 2024-10-24 12:14:01 --> Model "MainModel" initialized
ERROR - 2024-10-24 06:44:01 --> 404 Page Not Found: Blog/wp-includes
DEBUG - 2024-10-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:01 --> Security Class Initialized
INFO - 2024-10-24 06:44:01 --> URI Class Initialized
INFO - 2024-10-24 06:44:01 --> Input Class Initialized
INFO - 2024-10-24 12:14:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 06:44:01 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:01 --> Router Class Initialized
INFO - 2024-10-24 06:44:01 --> Language Class Initialized
INFO - 2024-10-24 12:14:01 --> Final output sent to browser
INFO - 2024-10-24 06:44:01 --> Input Class Initialized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
INFO - 2024-10-24 06:44:01 --> Language Class Initialized
ERROR - 2024-10-24 06:44:01 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-24 06:44:01 --> Output Class Initialized
DEBUG - 2024-10-24 12:14:01 --> Total execution time: 3.2767
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
ERROR - 2024-10-24 06:44:01 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-24 06:44:01 --> Security Class Initialized
INFO - 2024-10-24 06:44:01 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
ERROR - 2024-10-24 06:44:01 --> 404 Page Not Found: 2019/wp-includes
DEBUG - 2024-10-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:01 --> Input Class Initialized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
INFO - 2024-10-24 06:44:01 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:01 --> Config Class Initialized
INFO - 2024-10-24 06:44:01 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:01 --> Language Class Initialized
INFO - 2024-10-24 06:44:01 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:44:02 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-24 06:44:02 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:02 --> Output Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:02 --> Config Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:02 --> Router Class Initialized
INFO - 2024-10-24 06:44:02 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:02 --> Security Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:02 --> Router Class Initialized
INFO - 2024-10-24 06:44:02 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:02 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:02 --> Output Class Initialized
INFO - 2024-10-24 06:44:02 --> Router Class Initialized
INFO - 2024-10-24 06:44:02 --> Input Class Initialized
INFO - 2024-10-24 06:44:02 --> Output Class Initialized
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:02 --> Security Class Initialized
INFO - 2024-10-24 06:44:02 --> Security Class Initialized
INFO - 2024-10-24 06:44:02 --> Output Class Initialized
INFO - 2024-10-24 06:44:02 --> Language Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:02 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:02 --> Security Class Initialized
ERROR - 2024-10-24 06:44:02 --> 404 Page Not Found: Web/wp-includes
DEBUG - 2024-10-24 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:02 --> Router Class Initialized
INFO - 2024-10-24 06:44:02 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:02 --> Input Class Initialized
INFO - 2024-10-24 06:44:02 --> Output Class Initialized
INFO - 2024-10-24 06:44:02 --> Language Class Initialized
INFO - 2024-10-24 06:44:02 --> Input Class Initialized
INFO - 2024-10-24 06:44:02 --> Language Class Initialized
INFO - 2024-10-24 06:44:02 --> Input Class Initialized
INFO - 2024-10-24 06:44:02 --> Config Class Initialized
INFO - 2024-10-24 06:44:02 --> Security Class Initialized
INFO - 2024-10-24 06:44:02 --> Language Class Initialized
ERROR - 2024-10-24 06:44:02 --> 404 Page Not Found: Media/wp-includes
ERROR - 2024-10-24 06:44:02 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 06:44:02 --> Language Class Initialized
INFO - 2024-10-24 06:44:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:02 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2024-10-24 06:44:02 --> 404 Page Not Found: Blog/wp-includes
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:02 --> Config Class Initialized
INFO - 2024-10-24 06:44:02 --> Input Class Initialized
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:02 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:02 --> Config Class Initialized
INFO - 2024-10-24 06:44:02 --> Language Class Initialized
INFO - 2024-10-24 06:44:02 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:02 --> Config Class Initialized
INFO - 2024-10-24 06:44:02 --> Upload Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:02 --> Config Class Initialized
ERROR - 2024-10-24 06:44:02 --> 404 Page Not Found: Test/wp-includes
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:02 --> Email Class Initialized
INFO - 2024-10-24 06:44:02 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:02 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:02 --> Router Class Initialized
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:02 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 06:44:02 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:02 --> Config Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:02 --> URI Class Initialized
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> Security Class Initialized
INFO - 2024-10-24 06:44:03 --> Form Validation Class Initialized
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
INFO - 2024-10-24 06:44:03 --> Output Class Initialized
INFO - 2024-10-24 06:44:03 --> Controller Class Initialized
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
INFO - 2024-10-24 06:44:03 --> Input Class Initialized
INFO - 2024-10-24 06:44:03 --> Output Class Initialized
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
INFO - 2024-10-24 06:44:03 --> Security Class Initialized
INFO - 2024-10-24 12:14:03 --> Model "MainModel" initialized
INFO - 2024-10-24 06:44:03 --> Language Class Initialized
INFO - 2024-10-24 06:44:03 --> Output Class Initialized
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
INFO - 2024-10-24 06:44:03 --> Output Class Initialized
INFO - 2024-10-24 12:14:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
DEBUG - 2024-10-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:03 --> Security Class Initialized
ERROR - 2024-10-24 06:44:03 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
INFO - 2024-10-24 06:44:03 --> Security Class Initialized
INFO - 2024-10-24 06:44:03 --> Security Class Initialized
INFO - 2024-10-24 12:14:03 --> Final output sent to browser
DEBUG - 2024-10-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:03 --> Input Class Initialized
INFO - 2024-10-24 06:44:03 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:03 --> Language Class Initialized
INFO - 2024-10-24 06:44:03 --> Security Class Initialized
INFO - 2024-10-24 06:44:03 --> Config Class Initialized
DEBUG - 2024-10-24 12:14:03 --> Total execution time: 3.5221
INFO - 2024-10-24 06:44:03 --> Input Class Initialized
INFO - 2024-10-24 06:44:03 --> Input Class Initialized
INFO - 2024-10-24 06:44:03 --> Input Class Initialized
ERROR - 2024-10-24 06:44:03 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:03 --> Language Class Initialized
INFO - 2024-10-24 06:44:03 --> Language Class Initialized
INFO - 2024-10-24 06:44:03 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:03 --> Config Class Initialized
ERROR - 2024-10-24 06:44:03 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-10-24 06:44:03 --> 404 Page Not Found: Web/wp-includes
ERROR - 2024-10-24 06:44:03 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-24 06:44:03 --> Input Class Initialized
INFO - 2024-10-24 06:44:03 --> Config Class Initialized
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> Language Class Initialized
INFO - 2024-10-24 06:44:03 --> Config Class Initialized
INFO - 2024-10-24 06:44:03 --> Config Class Initialized
INFO - 2024-10-24 06:44:03 --> Config Class Initialized
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:44:03 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:03 --> Output Class Initialized
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> Config Class Initialized
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
INFO - 2024-10-24 06:44:03 --> Security Class Initialized
INFO - 2024-10-24 06:44:03 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
INFO - 2024-10-24 06:44:03 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
INFO - 2024-10-24 06:44:03 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
INFO - 2024-10-24 06:44:03 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:03 --> URI Class Initialized
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
INFO - 2024-10-24 06:44:04 --> Input Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
INFO - 2024-10-24 06:44:04 --> Language Class Initialized
INFO - 2024-10-24 06:44:04 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
INFO - 2024-10-24 06:44:04 --> Input Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
ERROR - 2024-10-24 06:44:04 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
INFO - 2024-10-24 06:44:04 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:04 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
INFO - 2024-10-24 06:44:04 --> Input Class Initialized
INFO - 2024-10-24 06:44:04 --> Language Class Initialized
INFO - 2024-10-24 06:44:04 --> Input Class Initialized
ERROR - 2024-10-24 06:44:04 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-24 06:44:04 --> Input Class Initialized
INFO - 2024-10-24 06:44:04 --> Config Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
ERROR - 2024-10-24 06:44:04 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-24 06:44:04 --> Language Class Initialized
INFO - 2024-10-24 06:44:04 --> Language Class Initialized
INFO - 2024-10-24 06:44:04 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:04 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-24 06:44:04 --> Hooks Class Initialized
ERROR - 2024-10-24 06:44:04 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-24 06:44:04 --> Config Class Initialized
ERROR - 2024-10-24 06:44:04 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 06:44:04 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:04 --> Config Class Initialized
INFO - 2024-10-24 06:44:04 --> Config Class Initialized
INFO - 2024-10-24 06:44:04 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:04 --> Language Class Initialized
INFO - 2024-10-24 06:44:04 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:04 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:04 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
ERROR - 2024-10-24 06:44:04 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 06:44:04 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:04 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:04 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:04 --> URI Class Initialized
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:04 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:04 --> URI Class Initialized
INFO - 2024-10-24 06:44:04 --> Config Class Initialized
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
INFO - 2024-10-24 06:44:04 --> URI Class Initialized
INFO - 2024-10-24 06:44:04 --> URI Class Initialized
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
INFO - 2024-10-24 06:44:04 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:04 --> Router Class Initialized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
INFO - 2024-10-24 06:44:04 --> URI Class Initialized
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
INFO - 2024-10-24 06:44:04 --> Output Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
INFO - 2024-10-24 06:44:04 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:04 --> URI Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
INFO - 2024-10-24 06:44:04 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
INFO - 2024-10-24 06:44:05 --> Security Class Initialized
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-24 06:44:05 --> Security Class Initialized
INFO - 2024-10-24 06:44:05 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: Media/wp-includes
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:05 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Config Class Initialized
INFO - 2024-10-24 06:44:05 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Config Class Initialized
INFO - 2024-10-24 06:44:05 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:05 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 06:44:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:05 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
INFO - 2024-10-24 06:44:05 --> Utf8 Class Initialized
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: Site/wp-includes
DEBUG - 2024-10-24 06:44:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:05 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:05 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
INFO - 2024-10-24 06:44:05 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:05 --> Config Class Initialized
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
INFO - 2024-10-24 06:44:05 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:05 --> Config Class Initialized
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
INFO - 2024-10-24 06:44:05 --> Config Class Initialized
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:05 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
INFO - 2024-10-24 06:44:05 --> Security Class Initialized
INFO - 2024-10-24 06:44:05 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:05 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:05 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
INFO - 2024-10-24 06:44:05 --> Security Class Initialized
INFO - 2024-10-24 06:44:05 --> Security Class Initialized
INFO - 2024-10-24 06:44:05 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:05 --> URI Class Initialized
INFO - 2024-10-24 06:44:05 --> Language Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Output Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Input Class Initialized
INFO - 2024-10-24 06:44:05 --> Router Class Initialized
ERROR - 2024-10-24 06:44:05 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: Sito/wp-includes
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:06 --> Input Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
INFO - 2024-10-24 06:44:06 --> Input Class Initialized
INFO - 2024-10-24 06:44:06 --> Input Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: 2019/wp-includes
DEBUG - 2024-10-24 06:44:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:06 --> UTF-8 Support Enabled
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-24 06:44:06 --> Utf8 Class Initialized
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-24 06:44:06 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:06 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:06 --> URI Class Initialized
INFO - 2024-10-24 06:44:06 --> URI Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
INFO - 2024-10-24 06:44:06 --> URI Class Initialized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
INFO - 2024-10-24 06:44:06 --> Router Class Initialized
INFO - 2024-10-24 06:44:06 --> Router Class Initialized
INFO - 2024-10-24 06:44:06 --> Router Class Initialized
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
INFO - 2024-10-24 06:44:06 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:06 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:06 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:06 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:06 --> Input Class Initialized
INFO - 2024-10-24 06:44:06 --> Input Class Initialized
INFO - 2024-10-24 06:44:06 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:06 --> URI Class Initialized
INFO - 2024-10-24 06:44:06 --> Input Class Initialized
INFO - 2024-10-24 06:44:06 --> Router Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> URI Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> Router Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-10-24 06:44:06 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
INFO - 2024-10-24 06:44:06 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:06 --> Output Class Initialized
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
INFO - 2024-10-24 06:44:06 --> Input Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:06 --> Config Class Initialized
INFO - 2024-10-24 06:44:06 --> Security Class Initialized
INFO - 2024-10-24 06:44:06 --> Language Class Initialized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:06 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: Shop/wp-includes
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
INFO - 2024-10-24 06:44:07 --> Config Class Initialized
INFO - 2024-10-24 06:44:07 --> Language Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Config Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
INFO - 2024-10-24 06:44:07 --> Language Class Initialized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
INFO - 2024-10-24 06:44:07 --> Language Class Initialized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:07 --> Language Class Initialized
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: Wp/wp-includes
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:07 --> Language Class Initialized
INFO - 2024-10-24 06:44:07 --> Config Class Initialized
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
INFO - 2024-10-24 06:44:07 --> Language Class Initialized
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:07 --> Config Class Initialized
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2024-10-24 06:44:07 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-24 06:44:07 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Config Class Initialized
INFO - 2024-10-24 06:44:07 --> Config Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:07 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:07 --> URI Class Initialized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Security Class Initialized
INFO - 2024-10-24 06:44:07 --> Router Class Initialized
INFO - 2024-10-24 06:44:07 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:07 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: Sito/wp-includes
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:08 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
INFO - 2024-10-24 06:44:08 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:08 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
INFO - 2024-10-24 06:44:08 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
INFO - 2024-10-24 06:44:08 --> Language Class Initialized
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
ERROR - 2024-10-24 06:44:08 --> 404 Page Not Found: Shop/wp-includes
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:08 --> Config Class Initialized
INFO - 2024-10-24 06:44:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:08 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
INFO - 2024-10-24 06:44:08 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
INFO - 2024-10-24 06:44:08 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
INFO - 2024-10-24 06:44:08 --> URI Class Initialized
INFO - 2024-10-24 06:44:08 --> Security Class Initialized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:08 --> Output Class Initialized
INFO - 2024-10-24 06:44:08 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:08 --> Router Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
INFO - 2024-10-24 06:44:09 --> Input Class Initialized
INFO - 2024-10-24 06:44:09 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: Test/wp-includes
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: 2019/wp-includes
DEBUG - 2024-10-24 06:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:09 --> Input Class Initialized
INFO - 2024-10-24 06:44:09 --> Input Class Initialized
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:09 --> Output Class Initialized
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
INFO - 2024-10-24 06:44:09 --> Output Class Initialized
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:09 --> Output Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
INFO - 2024-10-24 06:44:09 --> Input Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:09 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
INFO - 2024-10-24 06:44:09 --> Input Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
INFO - 2024-10-24 06:44:09 --> Input Class Initialized
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
INFO - 2024-10-24 06:44:09 --> Input Class Initialized
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-24 06:44:09 --> Language Class Initialized
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: Site/wp-includes
ERROR - 2024-10-24 06:44:09 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
INFO - 2024-10-24 06:44:09 --> Config Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:09 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:09 --> Output Class Initialized
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:09 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
INFO - 2024-10-24 06:44:09 --> Output Class Initialized
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
INFO - 2024-10-24 06:44:09 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
INFO - 2024-10-24 06:44:09 --> Security Class Initialized
INFO - 2024-10-24 06:44:09 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-24 06:44:10 --> Config Class Initialized
INFO - 2024-10-24 06:44:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:10 --> Config Class Initialized
INFO - 2024-10-24 06:44:10 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:10 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:10 --> Config Class Initialized
INFO - 2024-10-24 06:44:10 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:10 --> Config Class Initialized
INFO - 2024-10-24 06:44:10 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:10 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
INFO - 2024-10-24 06:44:10 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:10 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
INFO - 2024-10-24 06:44:10 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:10 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:10 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
INFO - 2024-10-24 06:44:10 --> URI Class Initialized
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
INFO - 2024-10-24 06:44:10 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
INFO - 2024-10-24 06:44:10 --> Config Class Initialized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
INFO - 2024-10-24 06:44:10 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Wp2/wp-includes
DEBUG - 2024-10-24 06:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:10 --> Config Class Initialized
INFO - 2024-10-24 06:44:10 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:10 --> Utf8 Class Initialized
DEBUG - 2024-10-24 06:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:10 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:10 --> URI Class Initialized
INFO - 2024-10-24 06:44:10 --> URI Class Initialized
INFO - 2024-10-24 06:44:10 --> Config Class Initialized
INFO - 2024-10-24 06:44:10 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
INFO - 2024-10-24 06:44:10 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
INFO - 2024-10-24 06:44:10 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:10 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:10 --> URI Class Initialized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
DEBUG - 2024-10-24 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:10 --> Router Class Initialized
INFO - 2024-10-24 06:44:10 --> Input Class Initialized
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
INFO - 2024-10-24 06:44:10 --> Output Class Initialized
ERROR - 2024-10-24 06:44:10 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-24 06:44:10 --> Language Class Initialized
INFO - 2024-10-24 06:44:11 --> Security Class Initialized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Media/wp-includes
DEBUG - 2024-10-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:11 --> Input Class Initialized
INFO - 2024-10-24 06:44:11 --> Language Class Initialized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-24 06:44:11 --> Config Class Initialized
INFO - 2024-10-24 06:44:11 --> Config Class Initialized
INFO - 2024-10-24 06:44:11 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2024-10-24 06:44:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:11 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:11 --> Config Class Initialized
INFO - 2024-10-24 06:44:11 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:11 --> URI Class Initialized
INFO - 2024-10-24 06:44:11 --> URI Class Initialized
INFO - 2024-10-24 06:44:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:11 --> Router Class Initialized
INFO - 2024-10-24 06:44:11 --> Router Class Initialized
INFO - 2024-10-24 06:44:11 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:11 --> Output Class Initialized
INFO - 2024-10-24 06:44:11 --> Output Class Initialized
INFO - 2024-10-24 06:44:11 --> URI Class Initialized
INFO - 2024-10-24 06:44:11 --> Security Class Initialized
INFO - 2024-10-24 06:44:11 --> Security Class Initialized
INFO - 2024-10-24 06:44:11 --> Router Class Initialized
DEBUG - 2024-10-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:11 --> Output Class Initialized
INFO - 2024-10-24 06:44:11 --> Input Class Initialized
INFO - 2024-10-24 06:44:11 --> Input Class Initialized
INFO - 2024-10-24 06:44:11 --> Language Class Initialized
INFO - 2024-10-24 06:44:11 --> Language Class Initialized
INFO - 2024-10-24 06:44:11 --> Security Class Initialized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Sito/wp-includes
DEBUG - 2024-10-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 06:44:11 --> Input Class Initialized
INFO - 2024-10-24 06:44:11 --> Language Class Initialized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-24 06:44:11 --> Config Class Initialized
INFO - 2024-10-24 06:44:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:11 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:11 --> URI Class Initialized
INFO - 2024-10-24 06:44:11 --> Config Class Initialized
INFO - 2024-10-24 06:44:11 --> Router Class Initialized
INFO - 2024-10-24 06:44:11 --> Hooks Class Initialized
INFO - 2024-10-24 06:44:11 --> Output Class Initialized
DEBUG - 2024-10-24 06:44:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:11 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:11 --> Security Class Initialized
INFO - 2024-10-24 06:44:11 --> URI Class Initialized
DEBUG - 2024-10-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:11 --> Router Class Initialized
INFO - 2024-10-24 06:44:11 --> Input Class Initialized
INFO - 2024-10-24 06:44:11 --> Output Class Initialized
INFO - 2024-10-24 06:44:11 --> Language Class Initialized
INFO - 2024-10-24 06:44:11 --> Security Class Initialized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Site/wp-includes
DEBUG - 2024-10-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:11 --> Input Class Initialized
INFO - 2024-10-24 06:44:11 --> Language Class Initialized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-24 06:44:11 --> Config Class Initialized
INFO - 2024-10-24 06:44:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:11 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:11 --> URI Class Initialized
INFO - 2024-10-24 06:44:11 --> Router Class Initialized
INFO - 2024-10-24 06:44:11 --> Output Class Initialized
INFO - 2024-10-24 06:44:11 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:11 --> Input Class Initialized
INFO - 2024-10-24 06:44:11 --> Language Class Initialized
ERROR - 2024-10-24 06:44:11 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-24 06:44:11 --> Config Class Initialized
INFO - 2024-10-24 06:44:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 06:44:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 06:44:12 --> Utf8 Class Initialized
INFO - 2024-10-24 06:44:12 --> URI Class Initialized
INFO - 2024-10-24 06:44:12 --> Router Class Initialized
INFO - 2024-10-24 06:44:12 --> Output Class Initialized
INFO - 2024-10-24 06:44:12 --> Security Class Initialized
DEBUG - 2024-10-24 06:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 06:44:12 --> Input Class Initialized
INFO - 2024-10-24 06:44:12 --> Language Class Initialized
ERROR - 2024-10-24 06:44:12 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-24 07:33:03 --> Config Class Initialized
INFO - 2024-10-24 07:33:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 07:33:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 07:33:03 --> Utf8 Class Initialized
INFO - 2024-10-24 07:33:03 --> URI Class Initialized
DEBUG - 2024-10-24 07:33:03 --> No URI present. Default controller set.
INFO - 2024-10-24 07:33:03 --> Router Class Initialized
INFO - 2024-10-24 07:33:03 --> Output Class Initialized
INFO - 2024-10-24 07:33:03 --> Security Class Initialized
DEBUG - 2024-10-24 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 07:33:04 --> Input Class Initialized
INFO - 2024-10-24 07:33:04 --> Language Class Initialized
INFO - 2024-10-24 07:33:04 --> Loader Class Initialized
INFO - 2024-10-24 07:33:04 --> Helper loaded: url_helper
INFO - 2024-10-24 07:33:04 --> Helper loaded: html_helper
INFO - 2024-10-24 07:33:04 --> Helper loaded: file_helper
INFO - 2024-10-24 07:33:04 --> Helper loaded: string_helper
INFO - 2024-10-24 07:33:04 --> Helper loaded: form_helper
INFO - 2024-10-24 07:33:04 --> Helper loaded: my_helper
INFO - 2024-10-24 07:33:04 --> Database Driver Class Initialized
INFO - 2024-10-24 07:33:06 --> Upload Class Initialized
INFO - 2024-10-24 07:33:06 --> Email Class Initialized
INFO - 2024-10-24 07:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 07:33:06 --> Form Validation Class Initialized
INFO - 2024-10-24 07:33:06 --> Controller Class Initialized
INFO - 2024-10-24 13:03:06 --> Model "MainModel" initialized
INFO - 2024-10-24 13:03:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 13:03:06 --> Final output sent to browser
DEBUG - 2024-10-24 13:03:06 --> Total execution time: 2.3977
INFO - 2024-10-24 08:41:03 --> Config Class Initialized
INFO - 2024-10-24 08:41:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:41:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:41:04 --> Utf8 Class Initialized
INFO - 2024-10-24 08:41:04 --> URI Class Initialized
DEBUG - 2024-10-24 08:41:04 --> No URI present. Default controller set.
INFO - 2024-10-24 08:41:04 --> Router Class Initialized
INFO - 2024-10-24 08:41:04 --> Output Class Initialized
INFO - 2024-10-24 08:41:04 --> Security Class Initialized
DEBUG - 2024-10-24 08:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:41:04 --> Input Class Initialized
INFO - 2024-10-24 08:41:04 --> Language Class Initialized
INFO - 2024-10-24 08:41:04 --> Loader Class Initialized
INFO - 2024-10-24 08:41:04 --> Helper loaded: url_helper
INFO - 2024-10-24 08:41:04 --> Helper loaded: html_helper
INFO - 2024-10-24 08:41:04 --> Helper loaded: file_helper
INFO - 2024-10-24 08:41:04 --> Helper loaded: string_helper
INFO - 2024-10-24 08:41:04 --> Helper loaded: form_helper
INFO - 2024-10-24 08:41:04 --> Helper loaded: my_helper
INFO - 2024-10-24 08:41:04 --> Database Driver Class Initialized
INFO - 2024-10-24 08:41:06 --> Upload Class Initialized
INFO - 2024-10-24 08:41:06 --> Email Class Initialized
INFO - 2024-10-24 08:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:41:06 --> Form Validation Class Initialized
INFO - 2024-10-24 08:41:06 --> Controller Class Initialized
INFO - 2024-10-24 14:11:06 --> Model "MainModel" initialized
INFO - 2024-10-24 14:11:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 14:11:06 --> Final output sent to browser
DEBUG - 2024-10-24 14:11:06 --> Total execution time: 2.3936
INFO - 2024-10-24 08:41:19 --> Config Class Initialized
INFO - 2024-10-24 08:41:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:41:20 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:41:20 --> Utf8 Class Initialized
INFO - 2024-10-24 08:41:20 --> URI Class Initialized
DEBUG - 2024-10-24 08:41:20 --> No URI present. Default controller set.
INFO - 2024-10-24 08:41:20 --> Router Class Initialized
INFO - 2024-10-24 08:41:20 --> Output Class Initialized
INFO - 2024-10-24 08:41:20 --> Security Class Initialized
DEBUG - 2024-10-24 08:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:41:20 --> Input Class Initialized
INFO - 2024-10-24 08:41:20 --> Language Class Initialized
INFO - 2024-10-24 08:41:20 --> Loader Class Initialized
INFO - 2024-10-24 08:41:20 --> Helper loaded: url_helper
INFO - 2024-10-24 08:41:20 --> Helper loaded: html_helper
INFO - 2024-10-24 08:41:20 --> Helper loaded: file_helper
INFO - 2024-10-24 08:41:20 --> Helper loaded: string_helper
INFO - 2024-10-24 08:41:20 --> Helper loaded: form_helper
INFO - 2024-10-24 08:41:20 --> Helper loaded: my_helper
INFO - 2024-10-24 08:41:20 --> Database Driver Class Initialized
INFO - 2024-10-24 08:41:22 --> Upload Class Initialized
INFO - 2024-10-24 08:41:22 --> Email Class Initialized
INFO - 2024-10-24 08:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:41:22 --> Form Validation Class Initialized
INFO - 2024-10-24 08:41:22 --> Controller Class Initialized
INFO - 2024-10-24 14:11:22 --> Model "MainModel" initialized
INFO - 2024-10-24 14:11:22 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 14:11:22 --> Final output sent to browser
DEBUG - 2024-10-24 14:11:22 --> Total execution time: 2.4139
INFO - 2024-10-24 08:41:59 --> Config Class Initialized
INFO - 2024-10-24 08:41:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 08:41:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 08:41:59 --> Utf8 Class Initialized
INFO - 2024-10-24 08:41:59 --> URI Class Initialized
DEBUG - 2024-10-24 08:41:59 --> No URI present. Default controller set.
INFO - 2024-10-24 08:41:59 --> Router Class Initialized
INFO - 2024-10-24 08:41:59 --> Output Class Initialized
INFO - 2024-10-24 08:41:59 --> Security Class Initialized
DEBUG - 2024-10-24 08:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 08:41:59 --> Input Class Initialized
INFO - 2024-10-24 08:41:59 --> Language Class Initialized
INFO - 2024-10-24 08:41:59 --> Loader Class Initialized
INFO - 2024-10-24 08:41:59 --> Helper loaded: url_helper
INFO - 2024-10-24 08:41:59 --> Helper loaded: html_helper
INFO - 2024-10-24 08:41:59 --> Helper loaded: file_helper
INFO - 2024-10-24 08:41:59 --> Helper loaded: string_helper
INFO - 2024-10-24 08:41:59 --> Helper loaded: form_helper
INFO - 2024-10-24 08:41:59 --> Helper loaded: my_helper
INFO - 2024-10-24 08:41:59 --> Database Driver Class Initialized
INFO - 2024-10-24 08:42:01 --> Upload Class Initialized
INFO - 2024-10-24 08:42:01 --> Email Class Initialized
INFO - 2024-10-24 08:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 08:42:01 --> Form Validation Class Initialized
INFO - 2024-10-24 08:42:01 --> Controller Class Initialized
INFO - 2024-10-24 14:12:01 --> Model "MainModel" initialized
INFO - 2024-10-24 14:12:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 14:12:01 --> Final output sent to browser
DEBUG - 2024-10-24 14:12:01 --> Total execution time: 2.3708
INFO - 2024-10-24 09:44:01 --> Config Class Initialized
INFO - 2024-10-24 09:44:01 --> Hooks Class Initialized
DEBUG - 2024-10-24 09:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 09:44:01 --> Utf8 Class Initialized
INFO - 2024-10-24 09:44:01 --> URI Class Initialized
DEBUG - 2024-10-24 09:44:01 --> No URI present. Default controller set.
INFO - 2024-10-24 09:44:01 --> Router Class Initialized
INFO - 2024-10-24 09:44:01 --> Output Class Initialized
INFO - 2024-10-24 09:44:01 --> Security Class Initialized
DEBUG - 2024-10-24 09:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 09:44:01 --> Input Class Initialized
INFO - 2024-10-24 09:44:01 --> Language Class Initialized
INFO - 2024-10-24 09:44:01 --> Loader Class Initialized
INFO - 2024-10-24 09:44:01 --> Helper loaded: url_helper
INFO - 2024-10-24 09:44:01 --> Helper loaded: html_helper
INFO - 2024-10-24 09:44:01 --> Helper loaded: file_helper
INFO - 2024-10-24 09:44:01 --> Helper loaded: string_helper
INFO - 2024-10-24 09:44:01 --> Helper loaded: form_helper
INFO - 2024-10-24 09:44:01 --> Helper loaded: my_helper
INFO - 2024-10-24 09:44:01 --> Database Driver Class Initialized
INFO - 2024-10-24 09:44:03 --> Upload Class Initialized
INFO - 2024-10-24 09:44:03 --> Email Class Initialized
INFO - 2024-10-24 09:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 09:44:03 --> Form Validation Class Initialized
INFO - 2024-10-24 09:44:03 --> Controller Class Initialized
INFO - 2024-10-24 15:14:03 --> Model "MainModel" initialized
INFO - 2024-10-24 15:14:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 15:14:03 --> Final output sent to browser
DEBUG - 2024-10-24 15:14:03 --> Total execution time: 2.4773
INFO - 2024-10-24 09:45:54 --> Config Class Initialized
INFO - 2024-10-24 09:45:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 09:45:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 09:45:54 --> Utf8 Class Initialized
INFO - 2024-10-24 09:45:54 --> URI Class Initialized
DEBUG - 2024-10-24 09:45:54 --> No URI present. Default controller set.
INFO - 2024-10-24 09:45:54 --> Router Class Initialized
INFO - 2024-10-24 09:45:54 --> Output Class Initialized
INFO - 2024-10-24 09:45:54 --> Security Class Initialized
DEBUG - 2024-10-24 09:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 09:45:54 --> Input Class Initialized
INFO - 2024-10-24 09:45:54 --> Language Class Initialized
INFO - 2024-10-24 09:45:54 --> Loader Class Initialized
INFO - 2024-10-24 09:45:54 --> Helper loaded: url_helper
INFO - 2024-10-24 09:45:54 --> Helper loaded: html_helper
INFO - 2024-10-24 09:45:54 --> Helper loaded: file_helper
INFO - 2024-10-24 09:45:54 --> Helper loaded: string_helper
INFO - 2024-10-24 09:45:54 --> Helper loaded: form_helper
INFO - 2024-10-24 09:45:54 --> Helper loaded: my_helper
INFO - 2024-10-24 09:45:54 --> Database Driver Class Initialized
INFO - 2024-10-24 09:45:56 --> Upload Class Initialized
INFO - 2024-10-24 09:45:56 --> Email Class Initialized
INFO - 2024-10-24 09:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 09:45:56 --> Form Validation Class Initialized
INFO - 2024-10-24 09:45:56 --> Controller Class Initialized
INFO - 2024-10-24 15:15:56 --> Model "MainModel" initialized
INFO - 2024-10-24 15:15:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 15:15:56 --> Final output sent to browser
DEBUG - 2024-10-24 15:15:56 --> Total execution time: 2.3096
INFO - 2024-10-24 09:45:58 --> Config Class Initialized
INFO - 2024-10-24 09:45:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 09:45:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 09:45:58 --> Utf8 Class Initialized
INFO - 2024-10-24 09:45:58 --> URI Class Initialized
INFO - 2024-10-24 09:45:58 --> Router Class Initialized
INFO - 2024-10-24 09:45:58 --> Output Class Initialized
INFO - 2024-10-24 09:45:58 --> Security Class Initialized
DEBUG - 2024-10-24 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 09:45:58 --> Input Class Initialized
INFO - 2024-10-24 09:45:58 --> Language Class Initialized
ERROR - 2024-10-24 09:45:58 --> 404 Page Not Found: Adstxt/index
INFO - 2024-10-24 09:45:58 --> Config Class Initialized
INFO - 2024-10-24 09:45:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 09:45:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 09:45:58 --> Utf8 Class Initialized
INFO - 2024-10-24 09:45:58 --> URI Class Initialized
INFO - 2024-10-24 09:45:58 --> Router Class Initialized
INFO - 2024-10-24 09:45:58 --> Output Class Initialized
INFO - 2024-10-24 09:45:58 --> Security Class Initialized
DEBUG - 2024-10-24 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 09:45:58 --> Input Class Initialized
INFO - 2024-10-24 09:45:58 --> Language Class Initialized
ERROR - 2024-10-24 09:45:59 --> 404 Page Not Found: App-adstxt/index
INFO - 2024-10-24 09:45:59 --> Config Class Initialized
INFO - 2024-10-24 09:45:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 09:45:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 09:45:59 --> Utf8 Class Initialized
INFO - 2024-10-24 09:45:59 --> URI Class Initialized
INFO - 2024-10-24 09:45:59 --> Router Class Initialized
INFO - 2024-10-24 09:45:59 --> Output Class Initialized
INFO - 2024-10-24 09:45:59 --> Security Class Initialized
DEBUG - 2024-10-24 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 09:45:59 --> Input Class Initialized
INFO - 2024-10-24 09:45:59 --> Language Class Initialized
ERROR - 2024-10-24 09:45:59 --> 404 Page Not Found: Sellersjson/index
INFO - 2024-10-24 10:39:34 --> Config Class Initialized
INFO - 2024-10-24 10:39:34 --> Hooks Class Initialized
DEBUG - 2024-10-24 10:39:34 --> UTF-8 Support Enabled
INFO - 2024-10-24 10:39:35 --> Utf8 Class Initialized
INFO - 2024-10-24 10:39:35 --> URI Class Initialized
DEBUG - 2024-10-24 10:39:35 --> No URI present. Default controller set.
INFO - 2024-10-24 10:39:35 --> Router Class Initialized
INFO - 2024-10-24 10:39:35 --> Output Class Initialized
INFO - 2024-10-24 10:39:35 --> Security Class Initialized
DEBUG - 2024-10-24 10:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 10:39:35 --> Input Class Initialized
INFO - 2024-10-24 10:39:35 --> Language Class Initialized
INFO - 2024-10-24 10:39:35 --> Loader Class Initialized
INFO - 2024-10-24 10:39:35 --> Helper loaded: url_helper
INFO - 2024-10-24 10:39:35 --> Helper loaded: html_helper
INFO - 2024-10-24 10:39:35 --> Helper loaded: file_helper
INFO - 2024-10-24 10:39:35 --> Helper loaded: string_helper
INFO - 2024-10-24 10:39:35 --> Helper loaded: form_helper
INFO - 2024-10-24 10:39:35 --> Helper loaded: my_helper
INFO - 2024-10-24 10:39:35 --> Database Driver Class Initialized
INFO - 2024-10-24 10:39:37 --> Upload Class Initialized
INFO - 2024-10-24 10:39:37 --> Email Class Initialized
INFO - 2024-10-24 10:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 10:39:37 --> Form Validation Class Initialized
INFO - 2024-10-24 10:39:37 --> Controller Class Initialized
INFO - 2024-10-24 16:09:37 --> Model "MainModel" initialized
INFO - 2024-10-24 16:09:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 16:09:37 --> Final output sent to browser
DEBUG - 2024-10-24 16:09:37 --> Total execution time: 2.3950
INFO - 2024-10-24 11:48:06 --> Config Class Initialized
INFO - 2024-10-24 11:48:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 11:48:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 11:48:06 --> Utf8 Class Initialized
INFO - 2024-10-24 11:48:06 --> URI Class Initialized
DEBUG - 2024-10-24 11:48:06 --> No URI present. Default controller set.
INFO - 2024-10-24 11:48:06 --> Router Class Initialized
INFO - 2024-10-24 11:48:06 --> Output Class Initialized
INFO - 2024-10-24 11:48:06 --> Security Class Initialized
DEBUG - 2024-10-24 11:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 11:48:06 --> Input Class Initialized
INFO - 2024-10-24 11:48:06 --> Language Class Initialized
INFO - 2024-10-24 11:48:06 --> Loader Class Initialized
INFO - 2024-10-24 11:48:06 --> Helper loaded: url_helper
INFO - 2024-10-24 11:48:06 --> Helper loaded: html_helper
INFO - 2024-10-24 11:48:06 --> Helper loaded: file_helper
INFO - 2024-10-24 11:48:06 --> Helper loaded: string_helper
INFO - 2024-10-24 11:48:06 --> Helper loaded: form_helper
INFO - 2024-10-24 11:48:06 --> Helper loaded: my_helper
INFO - 2024-10-24 11:48:06 --> Database Driver Class Initialized
INFO - 2024-10-24 11:48:08 --> Upload Class Initialized
INFO - 2024-10-24 11:48:08 --> Email Class Initialized
INFO - 2024-10-24 11:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 11:48:08 --> Form Validation Class Initialized
INFO - 2024-10-24 11:48:08 --> Controller Class Initialized
INFO - 2024-10-24 17:18:08 --> Model "MainModel" initialized
INFO - 2024-10-24 17:18:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 17:18:08 --> Final output sent to browser
DEBUG - 2024-10-24 17:18:08 --> Total execution time: 2.3577
INFO - 2024-10-24 12:21:33 --> Config Class Initialized
INFO - 2024-10-24 12:21:33 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:21:33 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:21:33 --> Utf8 Class Initialized
INFO - 2024-10-24 12:21:33 --> URI Class Initialized
DEBUG - 2024-10-24 12:21:33 --> No URI present. Default controller set.
INFO - 2024-10-24 12:21:33 --> Router Class Initialized
INFO - 2024-10-24 12:21:33 --> Output Class Initialized
INFO - 2024-10-24 12:21:33 --> Security Class Initialized
DEBUG - 2024-10-24 12:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:21:33 --> Input Class Initialized
INFO - 2024-10-24 12:21:33 --> Language Class Initialized
INFO - 2024-10-24 12:21:33 --> Loader Class Initialized
INFO - 2024-10-24 12:21:33 --> Helper loaded: url_helper
INFO - 2024-10-24 12:21:33 --> Helper loaded: html_helper
INFO - 2024-10-24 12:21:33 --> Helper loaded: file_helper
INFO - 2024-10-24 12:21:33 --> Helper loaded: string_helper
INFO - 2024-10-24 12:21:33 --> Helper loaded: form_helper
INFO - 2024-10-24 12:21:33 --> Helper loaded: my_helper
INFO - 2024-10-24 12:21:33 --> Database Driver Class Initialized
INFO - 2024-10-24 12:21:35 --> Upload Class Initialized
INFO - 2024-10-24 12:21:35 --> Email Class Initialized
INFO - 2024-10-24 12:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:21:35 --> Form Validation Class Initialized
INFO - 2024-10-24 12:21:35 --> Controller Class Initialized
INFO - 2024-10-24 17:51:35 --> Model "MainModel" initialized
INFO - 2024-10-24 17:51:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 17:51:35 --> Final output sent to browser
DEBUG - 2024-10-24 17:51:35 --> Total execution time: 2.4560
INFO - 2024-10-24 14:03:18 --> Config Class Initialized
INFO - 2024-10-24 14:03:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 14:03:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 14:03:18 --> Utf8 Class Initialized
INFO - 2024-10-24 14:03:18 --> URI Class Initialized
DEBUG - 2024-10-24 14:03:18 --> No URI present. Default controller set.
INFO - 2024-10-24 14:03:18 --> Router Class Initialized
INFO - 2024-10-24 14:03:18 --> Output Class Initialized
INFO - 2024-10-24 14:03:18 --> Security Class Initialized
DEBUG - 2024-10-24 14:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 14:03:18 --> Input Class Initialized
INFO - 2024-10-24 14:03:18 --> Language Class Initialized
INFO - 2024-10-24 14:03:18 --> Loader Class Initialized
INFO - 2024-10-24 14:03:18 --> Helper loaded: url_helper
INFO - 2024-10-24 14:03:18 --> Helper loaded: html_helper
INFO - 2024-10-24 14:03:18 --> Helper loaded: file_helper
INFO - 2024-10-24 14:03:18 --> Helper loaded: string_helper
INFO - 2024-10-24 14:03:18 --> Helper loaded: form_helper
INFO - 2024-10-24 14:03:18 --> Helper loaded: my_helper
INFO - 2024-10-24 14:03:18 --> Database Driver Class Initialized
INFO - 2024-10-24 14:03:20 --> Upload Class Initialized
INFO - 2024-10-24 14:03:20 --> Email Class Initialized
INFO - 2024-10-24 14:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 14:03:20 --> Form Validation Class Initialized
INFO - 2024-10-24 14:03:20 --> Controller Class Initialized
INFO - 2024-10-24 19:33:20 --> Model "MainModel" initialized
INFO - 2024-10-24 19:33:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 19:33:20 --> Final output sent to browser
DEBUG - 2024-10-24 19:33:20 --> Total execution time: 2.4113
INFO - 2024-10-24 15:12:31 --> Config Class Initialized
INFO - 2024-10-24 15:12:31 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:12:31 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:12:31 --> Utf8 Class Initialized
INFO - 2024-10-24 15:12:32 --> URI Class Initialized
DEBUG - 2024-10-24 15:12:32 --> No URI present. Default controller set.
INFO - 2024-10-24 15:12:32 --> Router Class Initialized
INFO - 2024-10-24 15:12:32 --> Output Class Initialized
INFO - 2024-10-24 15:12:32 --> Security Class Initialized
DEBUG - 2024-10-24 15:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:12:32 --> Input Class Initialized
INFO - 2024-10-24 15:12:32 --> Language Class Initialized
INFO - 2024-10-24 15:12:32 --> Loader Class Initialized
INFO - 2024-10-24 15:12:32 --> Helper loaded: url_helper
INFO - 2024-10-24 15:12:32 --> Helper loaded: html_helper
INFO - 2024-10-24 15:12:32 --> Helper loaded: file_helper
INFO - 2024-10-24 15:12:32 --> Helper loaded: string_helper
INFO - 2024-10-24 15:12:32 --> Helper loaded: form_helper
INFO - 2024-10-24 15:12:32 --> Helper loaded: my_helper
INFO - 2024-10-24 15:12:32 --> Database Driver Class Initialized
INFO - 2024-10-24 15:12:34 --> Upload Class Initialized
INFO - 2024-10-24 15:12:34 --> Email Class Initialized
INFO - 2024-10-24 15:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:12:34 --> Form Validation Class Initialized
INFO - 2024-10-24 15:12:34 --> Controller Class Initialized
INFO - 2024-10-24 20:42:34 --> Model "MainModel" initialized
INFO - 2024-10-24 20:42:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 20:42:34 --> Final output sent to browser
DEBUG - 2024-10-24 20:42:34 --> Total execution time: 2.4518
INFO - 2024-10-24 15:45:03 --> Config Class Initialized
INFO - 2024-10-24 15:45:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:45:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:45:03 --> Utf8 Class Initialized
INFO - 2024-10-24 15:45:03 --> URI Class Initialized
DEBUG - 2024-10-24 15:45:03 --> No URI present. Default controller set.
INFO - 2024-10-24 15:45:03 --> Router Class Initialized
INFO - 2024-10-24 15:45:03 --> Output Class Initialized
INFO - 2024-10-24 15:45:03 --> Security Class Initialized
DEBUG - 2024-10-24 15:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:45:03 --> Input Class Initialized
INFO - 2024-10-24 15:45:03 --> Language Class Initialized
INFO - 2024-10-24 15:45:03 --> Loader Class Initialized
INFO - 2024-10-24 15:45:03 --> Helper loaded: url_helper
INFO - 2024-10-24 15:45:03 --> Helper loaded: html_helper
INFO - 2024-10-24 15:45:03 --> Helper loaded: file_helper
INFO - 2024-10-24 15:45:03 --> Helper loaded: string_helper
INFO - 2024-10-24 15:45:03 --> Helper loaded: form_helper
INFO - 2024-10-24 15:45:03 --> Helper loaded: my_helper
INFO - 2024-10-24 15:45:03 --> Database Driver Class Initialized
INFO - 2024-10-24 15:45:04 --> Config Class Initialized
INFO - 2024-10-24 15:45:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:45:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:45:05 --> Utf8 Class Initialized
INFO - 2024-10-24 15:45:05 --> URI Class Initialized
DEBUG - 2024-10-24 15:45:05 --> No URI present. Default controller set.
INFO - 2024-10-24 15:45:05 --> Router Class Initialized
INFO - 2024-10-24 15:45:05 --> Output Class Initialized
INFO - 2024-10-24 15:45:05 --> Security Class Initialized
DEBUG - 2024-10-24 15:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:45:05 --> Input Class Initialized
INFO - 2024-10-24 15:45:05 --> Language Class Initialized
INFO - 2024-10-24 15:45:05 --> Loader Class Initialized
INFO - 2024-10-24 15:45:05 --> Helper loaded: url_helper
INFO - 2024-10-24 15:45:05 --> Helper loaded: html_helper
INFO - 2024-10-24 15:45:05 --> Helper loaded: file_helper
INFO - 2024-10-24 15:45:05 --> Helper loaded: string_helper
INFO - 2024-10-24 15:45:05 --> Helper loaded: form_helper
INFO - 2024-10-24 15:45:05 --> Helper loaded: my_helper
INFO - 2024-10-24 15:45:05 --> Database Driver Class Initialized
INFO - 2024-10-24 15:45:05 --> Upload Class Initialized
INFO - 2024-10-24 15:45:05 --> Email Class Initialized
INFO - 2024-10-24 15:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:45:05 --> Form Validation Class Initialized
INFO - 2024-10-24 15:45:05 --> Controller Class Initialized
INFO - 2024-10-24 21:15:05 --> Model "MainModel" initialized
INFO - 2024-10-24 21:15:05 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 21:15:05 --> Final output sent to browser
DEBUG - 2024-10-24 21:15:05 --> Total execution time: 2.4217
INFO - 2024-10-24 15:45:07 --> Upload Class Initialized
INFO - 2024-10-24 15:45:07 --> Email Class Initialized
INFO - 2024-10-24 15:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:45:07 --> Form Validation Class Initialized
INFO - 2024-10-24 15:45:07 --> Controller Class Initialized
INFO - 2024-10-24 21:15:07 --> Model "MainModel" initialized
INFO - 2024-10-24 21:15:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 21:15:07 --> Final output sent to browser
DEBUG - 2024-10-24 21:15:07 --> Total execution time: 2.3322
INFO - 2024-10-24 15:45:08 --> Config Class Initialized
INFO - 2024-10-24 15:45:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:45:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:45:08 --> Utf8 Class Initialized
INFO - 2024-10-24 15:45:08 --> URI Class Initialized
DEBUG - 2024-10-24 15:45:08 --> No URI present. Default controller set.
INFO - 2024-10-24 15:45:08 --> Router Class Initialized
INFO - 2024-10-24 15:45:08 --> Output Class Initialized
INFO - 2024-10-24 15:45:08 --> Security Class Initialized
DEBUG - 2024-10-24 15:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:45:08 --> Input Class Initialized
INFO - 2024-10-24 15:45:08 --> Language Class Initialized
INFO - 2024-10-24 15:45:08 --> Loader Class Initialized
INFO - 2024-10-24 15:45:08 --> Helper loaded: url_helper
INFO - 2024-10-24 15:45:08 --> Helper loaded: html_helper
INFO - 2024-10-24 15:45:08 --> Helper loaded: file_helper
INFO - 2024-10-24 15:45:08 --> Helper loaded: string_helper
INFO - 2024-10-24 15:45:08 --> Helper loaded: form_helper
INFO - 2024-10-24 15:45:08 --> Helper loaded: my_helper
INFO - 2024-10-24 15:45:08 --> Database Driver Class Initialized
INFO - 2024-10-24 15:45:09 --> Config Class Initialized
INFO - 2024-10-24 15:45:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:45:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:45:09 --> Utf8 Class Initialized
INFO - 2024-10-24 15:45:09 --> URI Class Initialized
DEBUG - 2024-10-24 15:45:09 --> No URI present. Default controller set.
INFO - 2024-10-24 15:45:09 --> Router Class Initialized
INFO - 2024-10-24 15:45:09 --> Output Class Initialized
INFO - 2024-10-24 15:45:09 --> Security Class Initialized
DEBUG - 2024-10-24 15:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:45:09 --> Input Class Initialized
INFO - 2024-10-24 15:45:09 --> Language Class Initialized
INFO - 2024-10-24 15:45:09 --> Loader Class Initialized
INFO - 2024-10-24 15:45:09 --> Helper loaded: url_helper
INFO - 2024-10-24 15:45:09 --> Helper loaded: html_helper
INFO - 2024-10-24 15:45:09 --> Helper loaded: file_helper
INFO - 2024-10-24 15:45:09 --> Helper loaded: string_helper
INFO - 2024-10-24 15:45:09 --> Helper loaded: form_helper
INFO - 2024-10-24 15:45:09 --> Helper loaded: my_helper
INFO - 2024-10-24 15:45:09 --> Database Driver Class Initialized
INFO - 2024-10-24 15:45:10 --> Upload Class Initialized
INFO - 2024-10-24 15:45:10 --> Email Class Initialized
INFO - 2024-10-24 15:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:45:10 --> Form Validation Class Initialized
INFO - 2024-10-24 15:45:10 --> Controller Class Initialized
INFO - 2024-10-24 21:15:10 --> Model "MainModel" initialized
INFO - 2024-10-24 21:15:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 21:15:10 --> Final output sent to browser
DEBUG - 2024-10-24 21:15:10 --> Total execution time: 2.3106
INFO - 2024-10-24 15:45:11 --> Upload Class Initialized
INFO - 2024-10-24 15:45:11 --> Email Class Initialized
INFO - 2024-10-24 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:45:11 --> Form Validation Class Initialized
INFO - 2024-10-24 15:45:11 --> Controller Class Initialized
INFO - 2024-10-24 21:15:11 --> Model "MainModel" initialized
INFO - 2024-10-24 21:15:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 21:15:12 --> Final output sent to browser
DEBUG - 2024-10-24 21:15:12 --> Total execution time: 2.3331
INFO - 2024-10-24 15:45:54 --> Config Class Initialized
INFO - 2024-10-24 15:45:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:45:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:45:54 --> Utf8 Class Initialized
INFO - 2024-10-24 15:45:54 --> URI Class Initialized
INFO - 2024-10-24 15:45:54 --> Router Class Initialized
INFO - 2024-10-24 15:45:54 --> Output Class Initialized
INFO - 2024-10-24 15:45:54 --> Security Class Initialized
DEBUG - 2024-10-24 15:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:45:54 --> Input Class Initialized
INFO - 2024-10-24 15:45:54 --> Language Class Initialized
ERROR - 2024-10-24 15:45:54 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-24 15:50:18 --> Config Class Initialized
INFO - 2024-10-24 15:50:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 15:50:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 15:50:18 --> Utf8 Class Initialized
INFO - 2024-10-24 15:50:18 --> URI Class Initialized
DEBUG - 2024-10-24 15:50:18 --> No URI present. Default controller set.
INFO - 2024-10-24 15:50:18 --> Router Class Initialized
INFO - 2024-10-24 15:50:18 --> Output Class Initialized
INFO - 2024-10-24 15:50:18 --> Security Class Initialized
DEBUG - 2024-10-24 15:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 15:50:18 --> Input Class Initialized
INFO - 2024-10-24 15:50:18 --> Language Class Initialized
INFO - 2024-10-24 15:50:18 --> Loader Class Initialized
INFO - 2024-10-24 15:50:18 --> Helper loaded: url_helper
INFO - 2024-10-24 15:50:18 --> Helper loaded: html_helper
INFO - 2024-10-24 15:50:18 --> Helper loaded: file_helper
INFO - 2024-10-24 15:50:18 --> Helper loaded: string_helper
INFO - 2024-10-24 15:50:18 --> Helper loaded: form_helper
INFO - 2024-10-24 15:50:18 --> Helper loaded: my_helper
INFO - 2024-10-24 15:50:18 --> Database Driver Class Initialized
INFO - 2024-10-24 15:50:20 --> Upload Class Initialized
INFO - 2024-10-24 15:50:20 --> Email Class Initialized
INFO - 2024-10-24 15:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 15:50:20 --> Form Validation Class Initialized
INFO - 2024-10-24 15:50:20 --> Controller Class Initialized
INFO - 2024-10-24 21:20:20 --> Model "MainModel" initialized
INFO - 2024-10-24 21:20:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 21:20:20 --> Final output sent to browser
DEBUG - 2024-10-24 21:20:20 --> Total execution time: 2.3332
INFO - 2024-10-24 16:11:28 --> Config Class Initialized
INFO - 2024-10-24 16:11:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 16:11:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 16:11:28 --> Utf8 Class Initialized
INFO - 2024-10-24 16:11:28 --> URI Class Initialized
DEBUG - 2024-10-24 16:11:28 --> No URI present. Default controller set.
INFO - 2024-10-24 16:11:28 --> Router Class Initialized
INFO - 2024-10-24 16:11:28 --> Output Class Initialized
INFO - 2024-10-24 16:11:28 --> Security Class Initialized
DEBUG - 2024-10-24 16:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 16:11:28 --> Input Class Initialized
INFO - 2024-10-24 16:11:28 --> Language Class Initialized
INFO - 2024-10-24 16:11:28 --> Loader Class Initialized
INFO - 2024-10-24 16:11:28 --> Helper loaded: url_helper
INFO - 2024-10-24 16:11:28 --> Helper loaded: html_helper
INFO - 2024-10-24 16:11:28 --> Helper loaded: file_helper
INFO - 2024-10-24 16:11:28 --> Helper loaded: string_helper
INFO - 2024-10-24 16:11:28 --> Helper loaded: form_helper
INFO - 2024-10-24 16:11:28 --> Helper loaded: my_helper
INFO - 2024-10-24 16:11:29 --> Database Driver Class Initialized
INFO - 2024-10-24 16:11:31 --> Upload Class Initialized
INFO - 2024-10-24 16:11:31 --> Email Class Initialized
INFO - 2024-10-24 16:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 16:11:31 --> Form Validation Class Initialized
INFO - 2024-10-24 16:11:31 --> Controller Class Initialized
INFO - 2024-10-24 21:41:31 --> Model "MainModel" initialized
INFO - 2024-10-24 21:41:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-24 21:41:31 --> Final output sent to browser
DEBUG - 2024-10-24 21:41:31 --> Total execution time: 2.3372
INFO - 2024-10-24 18:55:01 --> Config Class Initialized
INFO - 2024-10-24 18:55:01 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:01 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:01 --> URI Class Initialized
DEBUG - 2024-10-24 18:55:01 --> No URI present. Default controller set.
INFO - 2024-10-24 18:55:01 --> Router Class Initialized
INFO - 2024-10-24 18:55:01 --> Output Class Initialized
INFO - 2024-10-24 18:55:01 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:01 --> Input Class Initialized
INFO - 2024-10-24 18:55:01 --> Language Class Initialized
INFO - 2024-10-24 18:55:01 --> Loader Class Initialized
INFO - 2024-10-24 18:55:01 --> Helper loaded: url_helper
INFO - 2024-10-24 18:55:01 --> Helper loaded: html_helper
INFO - 2024-10-24 18:55:01 --> Helper loaded: file_helper
INFO - 2024-10-24 18:55:01 --> Helper loaded: string_helper
INFO - 2024-10-24 18:55:01 --> Helper loaded: form_helper
INFO - 2024-10-24 18:55:01 --> Helper loaded: my_helper
INFO - 2024-10-24 18:55:01 --> Database Driver Class Initialized
INFO - 2024-10-24 18:55:03 --> Upload Class Initialized
INFO - 2024-10-24 18:55:03 --> Email Class Initialized
INFO - 2024-10-24 18:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:55:04 --> Form Validation Class Initialized
INFO - 2024-10-24 18:55:04 --> Controller Class Initialized
INFO - 2024-10-24 18:55:04 --> Config Class Initialized
INFO - 2024-10-24 18:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:04 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:04 --> URI Class Initialized
INFO - 2024-10-24 18:55:04 --> Router Class Initialized
INFO - 2024-10-24 18:55:04 --> Output Class Initialized
INFO - 2024-10-24 18:55:04 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:04 --> Input Class Initialized
INFO - 2024-10-24 18:55:04 --> Language Class Initialized
ERROR - 2024-10-24 18:55:04 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 18:55:04 --> Config Class Initialized
INFO - 2024-10-24 18:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:04 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:04 --> URI Class Initialized
INFO - 2024-10-24 18:55:04 --> Router Class Initialized
INFO - 2024-10-24 18:55:04 --> Output Class Initialized
INFO - 2024-10-24 18:55:04 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:04 --> Input Class Initialized
INFO - 2024-10-24 18:55:04 --> Language Class Initialized
ERROR - 2024-10-24 18:55:04 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 18:55:05 --> Config Class Initialized
INFO - 2024-10-24 18:55:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:05 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:05 --> URI Class Initialized
DEBUG - 2024-10-24 18:55:05 --> No URI present. Default controller set.
INFO - 2024-10-24 18:55:05 --> Router Class Initialized
INFO - 2024-10-24 18:55:05 --> Output Class Initialized
INFO - 2024-10-24 18:55:05 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:05 --> Input Class Initialized
INFO - 2024-10-24 18:55:05 --> Language Class Initialized
INFO - 2024-10-24 18:55:05 --> Loader Class Initialized
INFO - 2024-10-24 18:55:05 --> Helper loaded: url_helper
INFO - 2024-10-24 18:55:05 --> Helper loaded: html_helper
INFO - 2024-10-24 18:55:05 --> Helper loaded: file_helper
INFO - 2024-10-24 18:55:05 --> Helper loaded: string_helper
INFO - 2024-10-24 18:55:05 --> Helper loaded: form_helper
INFO - 2024-10-24 18:55:05 --> Helper loaded: my_helper
INFO - 2024-10-24 18:55:05 --> Database Driver Class Initialized
INFO - 2024-10-24 18:55:07 --> Upload Class Initialized
INFO - 2024-10-24 18:55:07 --> Email Class Initialized
INFO - 2024-10-24 18:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:55:07 --> Form Validation Class Initialized
INFO - 2024-10-24 18:55:07 --> Controller Class Initialized
INFO - 2024-10-24 18:55:07 --> Config Class Initialized
INFO - 2024-10-24 18:55:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:07 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:07 --> URI Class Initialized
INFO - 2024-10-24 18:55:07 --> Router Class Initialized
INFO - 2024-10-24 18:55:07 --> Output Class Initialized
INFO - 2024-10-24 18:55:07 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:07 --> Input Class Initialized
INFO - 2024-10-24 18:55:07 --> Language Class Initialized
ERROR - 2024-10-24 18:55:07 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-24 18:55:07 --> Config Class Initialized
INFO - 2024-10-24 18:55:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:07 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:08 --> URI Class Initialized
INFO - 2024-10-24 18:55:08 --> Router Class Initialized
INFO - 2024-10-24 18:55:08 --> Output Class Initialized
INFO - 2024-10-24 18:55:08 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:08 --> Input Class Initialized
INFO - 2024-10-24 18:55:08 --> Language Class Initialized
ERROR - 2024-10-24 18:55:08 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-24 18:55:08 --> Config Class Initialized
INFO - 2024-10-24 18:55:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:08 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:08 --> URI Class Initialized
INFO - 2024-10-24 18:55:08 --> Router Class Initialized
INFO - 2024-10-24 18:55:08 --> Output Class Initialized
INFO - 2024-10-24 18:55:08 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:08 --> Input Class Initialized
INFO - 2024-10-24 18:55:08 --> Language Class Initialized
ERROR - 2024-10-24 18:55:08 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-24 18:55:08 --> Config Class Initialized
INFO - 2024-10-24 18:55:08 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:08 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:08 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:08 --> URI Class Initialized
INFO - 2024-10-24 18:55:08 --> Router Class Initialized
INFO - 2024-10-24 18:55:08 --> Output Class Initialized
INFO - 2024-10-24 18:55:08 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:08 --> Input Class Initialized
INFO - 2024-10-24 18:55:08 --> Language Class Initialized
ERROR - 2024-10-24 18:55:08 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 18:55:09 --> Config Class Initialized
INFO - 2024-10-24 18:55:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:09 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:09 --> URI Class Initialized
INFO - 2024-10-24 18:55:09 --> Router Class Initialized
INFO - 2024-10-24 18:55:09 --> Output Class Initialized
INFO - 2024-10-24 18:55:09 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:09 --> Input Class Initialized
INFO - 2024-10-24 18:55:09 --> Language Class Initialized
ERROR - 2024-10-24 18:55:09 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-24 18:55:09 --> Config Class Initialized
INFO - 2024-10-24 18:55:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:09 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:09 --> URI Class Initialized
INFO - 2024-10-24 18:55:09 --> Router Class Initialized
INFO - 2024-10-24 18:55:09 --> Output Class Initialized
INFO - 2024-10-24 18:55:09 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:09 --> Input Class Initialized
INFO - 2024-10-24 18:55:09 --> Language Class Initialized
ERROR - 2024-10-24 18:55:09 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 18:55:09 --> Config Class Initialized
INFO - 2024-10-24 18:55:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:09 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:09 --> URI Class Initialized
INFO - 2024-10-24 18:55:09 --> Router Class Initialized
INFO - 2024-10-24 18:55:09 --> Output Class Initialized
INFO - 2024-10-24 18:55:09 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:09 --> Input Class Initialized
INFO - 2024-10-24 18:55:09 --> Language Class Initialized
ERROR - 2024-10-24 18:55:09 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-10-24 18:55:10 --> Config Class Initialized
INFO - 2024-10-24 18:55:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:10 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:10 --> URI Class Initialized
INFO - 2024-10-24 18:55:10 --> Router Class Initialized
INFO - 2024-10-24 18:55:10 --> Output Class Initialized
INFO - 2024-10-24 18:55:10 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:10 --> Input Class Initialized
INFO - 2024-10-24 18:55:10 --> Language Class Initialized
ERROR - 2024-10-24 18:55:10 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-24 18:55:10 --> Config Class Initialized
INFO - 2024-10-24 18:55:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:10 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:10 --> URI Class Initialized
INFO - 2024-10-24 18:55:10 --> Router Class Initialized
INFO - 2024-10-24 18:55:10 --> Output Class Initialized
INFO - 2024-10-24 18:55:10 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:10 --> Input Class Initialized
INFO - 2024-10-24 18:55:10 --> Language Class Initialized
ERROR - 2024-10-24 18:55:10 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-24 18:55:10 --> Config Class Initialized
INFO - 2024-10-24 18:55:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:10 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:10 --> URI Class Initialized
INFO - 2024-10-24 18:55:11 --> Router Class Initialized
INFO - 2024-10-24 18:55:11 --> Output Class Initialized
INFO - 2024-10-24 18:55:11 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:11 --> Input Class Initialized
INFO - 2024-10-24 18:55:11 --> Language Class Initialized
ERROR - 2024-10-24 18:55:11 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-24 18:55:11 --> Config Class Initialized
INFO - 2024-10-24 18:55:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:11 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:11 --> URI Class Initialized
INFO - 2024-10-24 18:55:11 --> Router Class Initialized
INFO - 2024-10-24 18:55:11 --> Output Class Initialized
INFO - 2024-10-24 18:55:11 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:11 --> Input Class Initialized
INFO - 2024-10-24 18:55:11 --> Language Class Initialized
ERROR - 2024-10-24 18:55:11 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-24 18:55:11 --> Config Class Initialized
INFO - 2024-10-24 18:55:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:11 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:11 --> URI Class Initialized
INFO - 2024-10-24 18:55:11 --> Router Class Initialized
INFO - 2024-10-24 18:55:11 --> Output Class Initialized
INFO - 2024-10-24 18:55:11 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:11 --> Input Class Initialized
INFO - 2024-10-24 18:55:11 --> Language Class Initialized
ERROR - 2024-10-24 18:55:11 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 18:55:12 --> Config Class Initialized
INFO - 2024-10-24 18:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:12 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:12 --> URI Class Initialized
INFO - 2024-10-24 18:55:12 --> Router Class Initialized
INFO - 2024-10-24 18:55:12 --> Output Class Initialized
INFO - 2024-10-24 18:55:12 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:12 --> Input Class Initialized
INFO - 2024-10-24 18:55:12 --> Language Class Initialized
ERROR - 2024-10-24 18:55:12 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-24 18:55:12 --> Config Class Initialized
INFO - 2024-10-24 18:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:12 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:12 --> URI Class Initialized
INFO - 2024-10-24 18:55:12 --> Router Class Initialized
INFO - 2024-10-24 18:55:12 --> Output Class Initialized
INFO - 2024-10-24 18:55:12 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:12 --> Input Class Initialized
INFO - 2024-10-24 18:55:12 --> Language Class Initialized
ERROR - 2024-10-24 18:55:12 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-24 18:55:12 --> Config Class Initialized
INFO - 2024-10-24 18:55:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:55:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:55:12 --> Utf8 Class Initialized
INFO - 2024-10-24 18:55:12 --> URI Class Initialized
INFO - 2024-10-24 18:55:12 --> Router Class Initialized
INFO - 2024-10-24 18:55:12 --> Output Class Initialized
INFO - 2024-10-24 18:55:12 --> Security Class Initialized
DEBUG - 2024-10-24 18:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:55:12 --> Input Class Initialized
INFO - 2024-10-24 18:55:12 --> Language Class Initialized
ERROR - 2024-10-24 18:55:12 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-24 19:20:48 --> Config Class Initialized
INFO - 2024-10-24 19:20:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:48 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:48 --> URI Class Initialized
DEBUG - 2024-10-24 19:20:48 --> No URI present. Default controller set.
INFO - 2024-10-24 19:20:48 --> Router Class Initialized
INFO - 2024-10-24 19:20:48 --> Output Class Initialized
INFO - 2024-10-24 19:20:48 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:48 --> Input Class Initialized
INFO - 2024-10-24 19:20:48 --> Language Class Initialized
INFO - 2024-10-24 19:20:48 --> Loader Class Initialized
INFO - 2024-10-24 19:20:48 --> Helper loaded: url_helper
INFO - 2024-10-24 19:20:48 --> Helper loaded: html_helper
INFO - 2024-10-24 19:20:49 --> Helper loaded: file_helper
INFO - 2024-10-24 19:20:49 --> Helper loaded: string_helper
INFO - 2024-10-24 19:20:49 --> Helper loaded: form_helper
INFO - 2024-10-24 19:20:49 --> Helper loaded: my_helper
INFO - 2024-10-24 19:20:49 --> Database Driver Class Initialized
INFO - 2024-10-24 19:20:51 --> Upload Class Initialized
INFO - 2024-10-24 19:20:51 --> Email Class Initialized
INFO - 2024-10-24 19:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 19:20:51 --> Form Validation Class Initialized
INFO - 2024-10-24 19:20:51 --> Controller Class Initialized
INFO - 2024-10-24 19:20:51 --> Config Class Initialized
INFO - 2024-10-24 19:20:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:51 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:51 --> URI Class Initialized
INFO - 2024-10-24 19:20:51 --> Router Class Initialized
INFO - 2024-10-24 19:20:51 --> Output Class Initialized
INFO - 2024-10-24 19:20:51 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:51 --> Input Class Initialized
INFO - 2024-10-24 19:20:51 --> Language Class Initialized
ERROR - 2024-10-24 19:20:51 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-24 19:20:51 --> Config Class Initialized
INFO - 2024-10-24 19:20:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:51 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:51 --> URI Class Initialized
INFO - 2024-10-24 19:20:51 --> Router Class Initialized
INFO - 2024-10-24 19:20:51 --> Output Class Initialized
INFO - 2024-10-24 19:20:51 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:51 --> Input Class Initialized
INFO - 2024-10-24 19:20:51 --> Language Class Initialized
ERROR - 2024-10-24 19:20:51 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-24 19:20:52 --> Config Class Initialized
INFO - 2024-10-24 19:20:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:52 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:52 --> URI Class Initialized
DEBUG - 2024-10-24 19:20:52 --> No URI present. Default controller set.
INFO - 2024-10-24 19:20:52 --> Router Class Initialized
INFO - 2024-10-24 19:20:52 --> Output Class Initialized
INFO - 2024-10-24 19:20:52 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:52 --> Input Class Initialized
INFO - 2024-10-24 19:20:52 --> Language Class Initialized
INFO - 2024-10-24 19:20:52 --> Loader Class Initialized
INFO - 2024-10-24 19:20:52 --> Helper loaded: url_helper
INFO - 2024-10-24 19:20:52 --> Helper loaded: html_helper
INFO - 2024-10-24 19:20:52 --> Helper loaded: file_helper
INFO - 2024-10-24 19:20:52 --> Helper loaded: string_helper
INFO - 2024-10-24 19:20:52 --> Helper loaded: form_helper
INFO - 2024-10-24 19:20:52 --> Helper loaded: my_helper
INFO - 2024-10-24 19:20:52 --> Database Driver Class Initialized
INFO - 2024-10-24 19:20:54 --> Upload Class Initialized
INFO - 2024-10-24 19:20:54 --> Email Class Initialized
INFO - 2024-10-24 19:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 19:20:54 --> Form Validation Class Initialized
INFO - 2024-10-24 19:20:54 --> Controller Class Initialized
INFO - 2024-10-24 19:20:54 --> Config Class Initialized
INFO - 2024-10-24 19:20:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:54 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:54 --> URI Class Initialized
INFO - 2024-10-24 19:20:54 --> Router Class Initialized
INFO - 2024-10-24 19:20:54 --> Output Class Initialized
INFO - 2024-10-24 19:20:54 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:54 --> Input Class Initialized
INFO - 2024-10-24 19:20:54 --> Language Class Initialized
ERROR - 2024-10-24 19:20:54 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-24 19:20:55 --> Config Class Initialized
INFO - 2024-10-24 19:20:55 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:55 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:55 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:55 --> URI Class Initialized
INFO - 2024-10-24 19:20:55 --> Router Class Initialized
INFO - 2024-10-24 19:20:55 --> Output Class Initialized
INFO - 2024-10-24 19:20:55 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:55 --> Input Class Initialized
INFO - 2024-10-24 19:20:55 --> Language Class Initialized
ERROR - 2024-10-24 19:20:55 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-24 19:20:55 --> Config Class Initialized
INFO - 2024-10-24 19:20:55 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:55 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:55 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:55 --> URI Class Initialized
INFO - 2024-10-24 19:20:55 --> Router Class Initialized
INFO - 2024-10-24 19:20:55 --> Output Class Initialized
INFO - 2024-10-24 19:20:55 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:55 --> Input Class Initialized
INFO - 2024-10-24 19:20:55 --> Language Class Initialized
ERROR - 2024-10-24 19:20:55 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-24 19:20:56 --> Config Class Initialized
INFO - 2024-10-24 19:20:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:56 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:56 --> URI Class Initialized
INFO - 2024-10-24 19:20:56 --> Router Class Initialized
INFO - 2024-10-24 19:20:56 --> Output Class Initialized
INFO - 2024-10-24 19:20:56 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:56 --> Input Class Initialized
INFO - 2024-10-24 19:20:56 --> Language Class Initialized
ERROR - 2024-10-24 19:20:56 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-24 19:20:56 --> Config Class Initialized
INFO - 2024-10-24 19:20:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:56 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:56 --> URI Class Initialized
INFO - 2024-10-24 19:20:56 --> Router Class Initialized
INFO - 2024-10-24 19:20:56 --> Output Class Initialized
INFO - 2024-10-24 19:20:56 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:56 --> Input Class Initialized
INFO - 2024-10-24 19:20:56 --> Language Class Initialized
ERROR - 2024-10-24 19:20:56 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-24 19:20:56 --> Config Class Initialized
INFO - 2024-10-24 19:20:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:56 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:56 --> URI Class Initialized
INFO - 2024-10-24 19:20:56 --> Router Class Initialized
INFO - 2024-10-24 19:20:56 --> Output Class Initialized
INFO - 2024-10-24 19:20:56 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:56 --> Input Class Initialized
INFO - 2024-10-24 19:20:56 --> Language Class Initialized
ERROR - 2024-10-24 19:20:56 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-24 19:20:57 --> Config Class Initialized
INFO - 2024-10-24 19:20:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:57 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:57 --> URI Class Initialized
INFO - 2024-10-24 19:20:57 --> Router Class Initialized
INFO - 2024-10-24 19:20:57 --> Output Class Initialized
INFO - 2024-10-24 19:20:57 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:57 --> Input Class Initialized
INFO - 2024-10-24 19:20:57 --> Language Class Initialized
ERROR - 2024-10-24 19:20:57 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-10-24 19:20:57 --> Config Class Initialized
INFO - 2024-10-24 19:20:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:57 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:57 --> URI Class Initialized
INFO - 2024-10-24 19:20:57 --> Router Class Initialized
INFO - 2024-10-24 19:20:57 --> Output Class Initialized
INFO - 2024-10-24 19:20:57 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:57 --> Input Class Initialized
INFO - 2024-10-24 19:20:57 --> Language Class Initialized
ERROR - 2024-10-24 19:20:57 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-24 19:20:58 --> Config Class Initialized
INFO - 2024-10-24 19:20:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:58 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:58 --> URI Class Initialized
INFO - 2024-10-24 19:20:58 --> Router Class Initialized
INFO - 2024-10-24 19:20:58 --> Output Class Initialized
INFO - 2024-10-24 19:20:58 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:58 --> Input Class Initialized
INFO - 2024-10-24 19:20:58 --> Language Class Initialized
ERROR - 2024-10-24 19:20:58 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-24 19:20:58 --> Config Class Initialized
INFO - 2024-10-24 19:20:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:58 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:58 --> URI Class Initialized
INFO - 2024-10-24 19:20:58 --> Router Class Initialized
INFO - 2024-10-24 19:20:58 --> Output Class Initialized
INFO - 2024-10-24 19:20:58 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:58 --> Input Class Initialized
INFO - 2024-10-24 19:20:58 --> Language Class Initialized
ERROR - 2024-10-24 19:20:58 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-24 19:20:58 --> Config Class Initialized
INFO - 2024-10-24 19:20:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:59 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:59 --> URI Class Initialized
INFO - 2024-10-24 19:20:59 --> Router Class Initialized
INFO - 2024-10-24 19:20:59 --> Output Class Initialized
INFO - 2024-10-24 19:20:59 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:59 --> Input Class Initialized
INFO - 2024-10-24 19:20:59 --> Language Class Initialized
ERROR - 2024-10-24 19:20:59 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-24 19:20:59 --> Config Class Initialized
INFO - 2024-10-24 19:20:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:59 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:59 --> URI Class Initialized
INFO - 2024-10-24 19:20:59 --> Router Class Initialized
INFO - 2024-10-24 19:20:59 --> Output Class Initialized
INFO - 2024-10-24 19:20:59 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:59 --> Input Class Initialized
INFO - 2024-10-24 19:20:59 --> Language Class Initialized
ERROR - 2024-10-24 19:20:59 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-24 19:20:59 --> Config Class Initialized
INFO - 2024-10-24 19:20:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:20:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:20:59 --> Utf8 Class Initialized
INFO - 2024-10-24 19:20:59 --> URI Class Initialized
INFO - 2024-10-24 19:20:59 --> Router Class Initialized
INFO - 2024-10-24 19:20:59 --> Output Class Initialized
INFO - 2024-10-24 19:20:59 --> Security Class Initialized
DEBUG - 2024-10-24 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:20:59 --> Input Class Initialized
INFO - 2024-10-24 19:20:59 --> Language Class Initialized
ERROR - 2024-10-24 19:20:59 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-24 19:21:00 --> Config Class Initialized
INFO - 2024-10-24 19:21:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:21:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:21:00 --> Utf8 Class Initialized
INFO - 2024-10-24 19:21:00 --> URI Class Initialized
INFO - 2024-10-24 19:21:00 --> Router Class Initialized
INFO - 2024-10-24 19:21:00 --> Output Class Initialized
INFO - 2024-10-24 19:21:00 --> Security Class Initialized
DEBUG - 2024-10-24 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:21:00 --> Input Class Initialized
INFO - 2024-10-24 19:21:00 --> Language Class Initialized
ERROR - 2024-10-24 19:21:00 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-24 19:21:00 --> Config Class Initialized
INFO - 2024-10-24 19:21:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 19:21:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 19:21:00 --> Utf8 Class Initialized
INFO - 2024-10-24 19:21:00 --> URI Class Initialized
INFO - 2024-10-24 19:21:00 --> Router Class Initialized
INFO - 2024-10-24 19:21:00 --> Output Class Initialized
INFO - 2024-10-24 19:21:00 --> Security Class Initialized
DEBUG - 2024-10-24 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 19:21:00 --> Input Class Initialized
INFO - 2024-10-24 19:21:00 --> Language Class Initialized
ERROR - 2024-10-24 19:21:00 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-24 22:48:15 --> Config Class Initialized
INFO - 2024-10-24 22:48:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:48:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:48:15 --> Utf8 Class Initialized
INFO - 2024-10-24 22:48:15 --> URI Class Initialized
DEBUG - 2024-10-24 22:48:16 --> No URI present. Default controller set.
INFO - 2024-10-24 22:48:16 --> Router Class Initialized
INFO - 2024-10-24 22:48:16 --> Output Class Initialized
INFO - 2024-10-24 22:48:16 --> Security Class Initialized
DEBUG - 2024-10-24 22:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:48:16 --> Input Class Initialized
INFO - 2024-10-24 22:48:16 --> Language Class Initialized
INFO - 2024-10-24 22:48:16 --> Loader Class Initialized
INFO - 2024-10-24 22:48:16 --> Helper loaded: url_helper
INFO - 2024-10-24 22:48:16 --> Helper loaded: html_helper
INFO - 2024-10-24 22:48:16 --> Helper loaded: file_helper
INFO - 2024-10-24 22:48:16 --> Helper loaded: string_helper
INFO - 2024-10-24 22:48:16 --> Helper loaded: form_helper
INFO - 2024-10-24 22:48:16 --> Helper loaded: my_helper
INFO - 2024-10-24 22:48:16 --> Database Driver Class Initialized
INFO - 2024-10-24 22:48:18 --> Upload Class Initialized
INFO - 2024-10-24 22:48:18 --> Email Class Initialized
INFO - 2024-10-24 22:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:48:18 --> Form Validation Class Initialized
INFO - 2024-10-24 22:48:18 --> Controller Class Initialized
INFO - 2024-10-24 22:48:23 --> Config Class Initialized
INFO - 2024-10-24 22:48:23 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:48:23 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:48:23 --> Utf8 Class Initialized
INFO - 2024-10-24 22:48:23 --> URI Class Initialized
DEBUG - 2024-10-24 22:48:23 --> No URI present. Default controller set.
INFO - 2024-10-24 22:48:23 --> Router Class Initialized
INFO - 2024-10-24 22:48:23 --> Output Class Initialized
INFO - 2024-10-24 22:48:23 --> Security Class Initialized
DEBUG - 2024-10-24 22:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:48:23 --> Input Class Initialized
INFO - 2024-10-24 22:48:23 --> Language Class Initialized
INFO - 2024-10-24 22:48:23 --> Loader Class Initialized
INFO - 2024-10-24 22:48:23 --> Helper loaded: url_helper
INFO - 2024-10-24 22:48:23 --> Helper loaded: html_helper
INFO - 2024-10-24 22:48:23 --> Helper loaded: file_helper
INFO - 2024-10-24 22:48:23 --> Helper loaded: string_helper
INFO - 2024-10-24 22:48:23 --> Helper loaded: form_helper
INFO - 2024-10-24 22:48:23 --> Helper loaded: my_helper
INFO - 2024-10-24 22:48:23 --> Database Driver Class Initialized
INFO - 2024-10-24 22:48:25 --> Upload Class Initialized
INFO - 2024-10-24 22:48:25 --> Email Class Initialized
INFO - 2024-10-24 22:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:48:25 --> Form Validation Class Initialized
INFO - 2024-10-24 22:48:25 --> Controller Class Initialized
INFO - 2024-10-24 22:50:15 --> Config Class Initialized
INFO - 2024-10-24 22:50:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:50:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:50:15 --> Utf8 Class Initialized
INFO - 2024-10-24 22:50:15 --> URI Class Initialized
DEBUG - 2024-10-24 22:50:15 --> No URI present. Default controller set.
INFO - 2024-10-24 22:50:15 --> Router Class Initialized
INFO - 2024-10-24 22:50:15 --> Output Class Initialized
INFO - 2024-10-24 22:50:15 --> Security Class Initialized
DEBUG - 2024-10-24 22:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:50:15 --> Input Class Initialized
INFO - 2024-10-24 22:50:15 --> Language Class Initialized
INFO - 2024-10-24 22:50:15 --> Loader Class Initialized
INFO - 2024-10-24 22:50:15 --> Helper loaded: url_helper
INFO - 2024-10-24 22:50:15 --> Helper loaded: html_helper
INFO - 2024-10-24 22:50:15 --> Helper loaded: file_helper
INFO - 2024-10-24 22:50:15 --> Helper loaded: string_helper
INFO - 2024-10-24 22:50:15 --> Helper loaded: form_helper
INFO - 2024-10-24 22:50:15 --> Helper loaded: my_helper
INFO - 2024-10-24 22:50:15 --> Database Driver Class Initialized
INFO - 2024-10-24 22:50:17 --> Upload Class Initialized
INFO - 2024-10-24 22:50:17 --> Email Class Initialized
INFO - 2024-10-24 22:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:50:17 --> Form Validation Class Initialized
INFO - 2024-10-24 22:50:17 --> Controller Class Initialized
INFO - 2024-10-24 23:00:50 --> Config Class Initialized
INFO - 2024-10-24 23:00:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:00:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:00:50 --> Utf8 Class Initialized
INFO - 2024-10-24 23:00:50 --> URI Class Initialized
DEBUG - 2024-10-24 23:00:50 --> No URI present. Default controller set.
INFO - 2024-10-24 23:00:50 --> Router Class Initialized
INFO - 2024-10-24 23:00:50 --> Output Class Initialized
INFO - 2024-10-24 23:00:50 --> Security Class Initialized
DEBUG - 2024-10-24 23:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:00:50 --> Input Class Initialized
INFO - 2024-10-24 23:00:50 --> Language Class Initialized
INFO - 2024-10-24 23:00:50 --> Loader Class Initialized
INFO - 2024-10-24 23:00:50 --> Helper loaded: url_helper
INFO - 2024-10-24 23:00:50 --> Helper loaded: html_helper
INFO - 2024-10-24 23:00:50 --> Helper loaded: file_helper
INFO - 2024-10-24 23:00:50 --> Helper loaded: string_helper
INFO - 2024-10-24 23:00:50 --> Helper loaded: form_helper
INFO - 2024-10-24 23:00:50 --> Helper loaded: my_helper
INFO - 2024-10-24 23:00:50 --> Database Driver Class Initialized
INFO - 2024-10-24 23:00:52 --> Upload Class Initialized
INFO - 2024-10-24 23:00:52 --> Email Class Initialized
INFO - 2024-10-24 23:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:00:52 --> Form Validation Class Initialized
INFO - 2024-10-24 23:00:52 --> Controller Class Initialized
INFO - 2024-10-24 23:01:44 --> Config Class Initialized
INFO - 2024-10-24 23:01:44 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:01:44 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:01:44 --> Utf8 Class Initialized
INFO - 2024-10-24 23:01:44 --> URI Class Initialized
DEBUG - 2024-10-24 23:01:44 --> No URI present. Default controller set.
INFO - 2024-10-24 23:01:44 --> Router Class Initialized
INFO - 2024-10-24 23:01:44 --> Output Class Initialized
INFO - 2024-10-24 23:01:44 --> Security Class Initialized
DEBUG - 2024-10-24 23:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:01:44 --> Input Class Initialized
INFO - 2024-10-24 23:01:44 --> Language Class Initialized
INFO - 2024-10-24 23:01:44 --> Loader Class Initialized
INFO - 2024-10-24 23:01:44 --> Helper loaded: url_helper
INFO - 2024-10-24 23:01:44 --> Helper loaded: html_helper
INFO - 2024-10-24 23:01:44 --> Helper loaded: file_helper
INFO - 2024-10-24 23:01:44 --> Helper loaded: string_helper
INFO - 2024-10-24 23:01:44 --> Helper loaded: form_helper
INFO - 2024-10-24 23:01:44 --> Helper loaded: my_helper
INFO - 2024-10-24 23:01:44 --> Database Driver Class Initialized
INFO - 2024-10-24 23:01:46 --> Upload Class Initialized
INFO - 2024-10-24 23:01:46 --> Email Class Initialized
INFO - 2024-10-24 23:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:01:46 --> Form Validation Class Initialized
INFO - 2024-10-24 23:01:46 --> Controller Class Initialized
