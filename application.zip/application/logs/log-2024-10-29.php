<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-29 01:10:13 --> Model "MainModel" initialized
INFO - 2024-10-29 01:10:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 01:10:13 --> Final output sent to browser
DEBUG - 2024-10-29 01:10:13 --> Total execution time: 2.2864
INFO - 2024-10-29 02:51:37 --> Model "MainModel" initialized
INFO - 2024-10-29 02:51:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 02:51:37 --> Final output sent to browser
DEBUG - 2024-10-29 02:51:37 --> Total execution time: 2.3868
INFO - 2024-10-29 00:41:56 --> Config Class Initialized
INFO - 2024-10-29 00:41:56 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:41:56 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:41:56 --> Utf8 Class Initialized
INFO - 2024-10-29 00:41:56 --> URI Class Initialized
DEBUG - 2024-10-29 00:41:56 --> No URI present. Default controller set.
INFO - 2024-10-29 00:41:56 --> Router Class Initialized
INFO - 2024-10-29 00:41:56 --> Output Class Initialized
INFO - 2024-10-29 00:41:56 --> Security Class Initialized
DEBUG - 2024-10-29 00:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:41:56 --> Input Class Initialized
INFO - 2024-10-29 00:41:56 --> Language Class Initialized
INFO - 2024-10-29 00:41:56 --> Loader Class Initialized
INFO - 2024-10-29 00:41:56 --> Helper loaded: url_helper
INFO - 2024-10-29 00:41:56 --> Helper loaded: html_helper
INFO - 2024-10-29 00:41:56 --> Helper loaded: file_helper
INFO - 2024-10-29 00:41:56 --> Helper loaded: string_helper
INFO - 2024-10-29 00:41:56 --> Helper loaded: form_helper
INFO - 2024-10-29 00:41:56 --> Helper loaded: my_helper
INFO - 2024-10-29 00:41:56 --> Database Driver Class Initialized
INFO - 2024-10-29 00:41:58 --> Upload Class Initialized
INFO - 2024-10-29 00:41:58 --> Email Class Initialized
INFO - 2024-10-29 00:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:41:58 --> Form Validation Class Initialized
INFO - 2024-10-29 00:41:58 --> Controller Class Initialized
INFO - 2024-10-29 06:11:58 --> Model "MainModel" initialized
INFO - 2024-10-29 06:11:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:11:58 --> Final output sent to browser
DEBUG - 2024-10-29 06:11:58 --> Total execution time: 2.1753
INFO - 2024-10-29 00:42:03 --> Config Class Initialized
INFO - 2024-10-29 00:42:03 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:42:03 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:42:03 --> Utf8 Class Initialized
INFO - 2024-10-29 00:42:03 --> URI Class Initialized
DEBUG - 2024-10-29 00:42:03 --> No URI present. Default controller set.
INFO - 2024-10-29 00:42:03 --> Router Class Initialized
INFO - 2024-10-29 00:42:03 --> Output Class Initialized
INFO - 2024-10-29 00:42:03 --> Security Class Initialized
DEBUG - 2024-10-29 00:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:42:03 --> Input Class Initialized
INFO - 2024-10-29 00:42:03 --> Language Class Initialized
INFO - 2024-10-29 00:42:03 --> Loader Class Initialized
INFO - 2024-10-29 00:42:03 --> Helper loaded: url_helper
INFO - 2024-10-29 00:42:03 --> Helper loaded: html_helper
INFO - 2024-10-29 00:42:03 --> Helper loaded: file_helper
INFO - 2024-10-29 00:42:03 --> Helper loaded: string_helper
INFO - 2024-10-29 00:42:03 --> Helper loaded: form_helper
INFO - 2024-10-29 00:42:03 --> Helper loaded: my_helper
INFO - 2024-10-29 00:42:03 --> Database Driver Class Initialized
INFO - 2024-10-29 00:42:05 --> Upload Class Initialized
INFO - 2024-10-29 00:42:05 --> Email Class Initialized
INFO - 2024-10-29 00:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:42:05 --> Form Validation Class Initialized
INFO - 2024-10-29 00:42:05 --> Controller Class Initialized
INFO - 2024-10-29 06:12:05 --> Model "MainModel" initialized
INFO - 2024-10-29 06:12:05 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:12:05 --> Final output sent to browser
DEBUG - 2024-10-29 06:12:05 --> Total execution time: 2.1655
INFO - 2024-10-29 00:42:21 --> Config Class Initialized
INFO - 2024-10-29 00:42:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:42:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:42:21 --> Utf8 Class Initialized
INFO - 2024-10-29 00:42:21 --> URI Class Initialized
DEBUG - 2024-10-29 00:42:21 --> No URI present. Default controller set.
INFO - 2024-10-29 00:42:21 --> Router Class Initialized
INFO - 2024-10-29 00:42:21 --> Output Class Initialized
INFO - 2024-10-29 00:42:21 --> Security Class Initialized
DEBUG - 2024-10-29 00:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:42:21 --> Input Class Initialized
INFO - 2024-10-29 00:42:21 --> Language Class Initialized
INFO - 2024-10-29 00:42:21 --> Loader Class Initialized
INFO - 2024-10-29 00:42:21 --> Helper loaded: url_helper
INFO - 2024-10-29 00:42:21 --> Helper loaded: html_helper
INFO - 2024-10-29 00:42:21 --> Helper loaded: file_helper
INFO - 2024-10-29 00:42:21 --> Helper loaded: string_helper
INFO - 2024-10-29 00:42:21 --> Helper loaded: form_helper
INFO - 2024-10-29 00:42:21 --> Helper loaded: my_helper
INFO - 2024-10-29 00:42:21 --> Database Driver Class Initialized
INFO - 2024-10-29 00:42:24 --> Upload Class Initialized
INFO - 2024-10-29 00:42:24 --> Email Class Initialized
INFO - 2024-10-29 00:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:42:24 --> Form Validation Class Initialized
INFO - 2024-10-29 00:42:24 --> Controller Class Initialized
INFO - 2024-10-29 06:12:24 --> Model "MainModel" initialized
INFO - 2024-10-29 06:12:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:12:24 --> Final output sent to browser
DEBUG - 2024-10-29 06:12:24 --> Total execution time: 2.1687
INFO - 2024-10-29 00:42:54 --> Config Class Initialized
INFO - 2024-10-29 00:42:54 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:42:54 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:42:54 --> Utf8 Class Initialized
INFO - 2024-10-29 00:42:54 --> URI Class Initialized
DEBUG - 2024-10-29 00:42:54 --> No URI present. Default controller set.
INFO - 2024-10-29 00:42:54 --> Router Class Initialized
INFO - 2024-10-29 00:42:54 --> Output Class Initialized
INFO - 2024-10-29 00:42:54 --> Security Class Initialized
DEBUG - 2024-10-29 00:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:42:54 --> Input Class Initialized
INFO - 2024-10-29 00:42:54 --> Language Class Initialized
INFO - 2024-10-29 00:42:54 --> Loader Class Initialized
INFO - 2024-10-29 00:42:54 --> Helper loaded: url_helper
INFO - 2024-10-29 00:42:54 --> Helper loaded: html_helper
INFO - 2024-10-29 00:42:54 --> Helper loaded: file_helper
INFO - 2024-10-29 00:42:54 --> Helper loaded: string_helper
INFO - 2024-10-29 00:42:54 --> Helper loaded: form_helper
INFO - 2024-10-29 00:42:54 --> Helper loaded: my_helper
INFO - 2024-10-29 00:42:54 --> Database Driver Class Initialized
INFO - 2024-10-29 00:42:57 --> Upload Class Initialized
INFO - 2024-10-29 00:42:57 --> Email Class Initialized
INFO - 2024-10-29 00:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:42:57 --> Form Validation Class Initialized
INFO - 2024-10-29 00:42:57 --> Controller Class Initialized
INFO - 2024-10-29 06:12:57 --> Model "MainModel" initialized
INFO - 2024-10-29 06:12:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:12:57 --> Final output sent to browser
DEBUG - 2024-10-29 06:12:57 --> Total execution time: 2.1108
INFO - 2024-10-29 00:43:31 --> Config Class Initialized
INFO - 2024-10-29 00:43:31 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:43:31 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:43:31 --> Utf8 Class Initialized
INFO - 2024-10-29 00:43:31 --> URI Class Initialized
DEBUG - 2024-10-29 00:43:31 --> No URI present. Default controller set.
INFO - 2024-10-29 00:43:31 --> Router Class Initialized
INFO - 2024-10-29 00:43:31 --> Output Class Initialized
INFO - 2024-10-29 00:43:31 --> Security Class Initialized
DEBUG - 2024-10-29 00:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:43:31 --> Input Class Initialized
INFO - 2024-10-29 00:43:31 --> Language Class Initialized
INFO - 2024-10-29 00:43:31 --> Loader Class Initialized
INFO - 2024-10-29 00:43:31 --> Helper loaded: url_helper
INFO - 2024-10-29 00:43:31 --> Helper loaded: html_helper
INFO - 2024-10-29 00:43:31 --> Helper loaded: file_helper
INFO - 2024-10-29 00:43:31 --> Helper loaded: string_helper
INFO - 2024-10-29 00:43:31 --> Helper loaded: form_helper
INFO - 2024-10-29 00:43:31 --> Helper loaded: my_helper
INFO - 2024-10-29 00:43:31 --> Database Driver Class Initialized
INFO - 2024-10-29 00:43:33 --> Upload Class Initialized
INFO - 2024-10-29 00:43:33 --> Email Class Initialized
INFO - 2024-10-29 00:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:43:33 --> Form Validation Class Initialized
INFO - 2024-10-29 00:43:33 --> Controller Class Initialized
INFO - 2024-10-29 06:13:33 --> Model "MainModel" initialized
INFO - 2024-10-29 06:13:33 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:13:33 --> Final output sent to browser
DEBUG - 2024-10-29 06:13:33 --> Total execution time: 2.1287
INFO - 2024-10-29 00:43:53 --> Config Class Initialized
INFO - 2024-10-29 00:43:53 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:43:53 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:43:53 --> Utf8 Class Initialized
INFO - 2024-10-29 00:43:53 --> URI Class Initialized
INFO - 2024-10-29 00:43:53 --> Router Class Initialized
INFO - 2024-10-29 00:43:53 --> Output Class Initialized
INFO - 2024-10-29 00:43:53 --> Security Class Initialized
DEBUG - 2024-10-29 00:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:43:53 --> Input Class Initialized
INFO - 2024-10-29 00:43:53 --> Language Class Initialized
ERROR - 2024-10-29 00:43:53 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-29 00:44:09 --> Config Class Initialized
INFO - 2024-10-29 00:44:09 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:44:09 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:44:09 --> Utf8 Class Initialized
INFO - 2024-10-29 00:44:09 --> URI Class Initialized
DEBUG - 2024-10-29 00:44:09 --> No URI present. Default controller set.
INFO - 2024-10-29 00:44:09 --> Router Class Initialized
INFO - 2024-10-29 00:44:09 --> Output Class Initialized
INFO - 2024-10-29 00:44:09 --> Security Class Initialized
DEBUG - 2024-10-29 00:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:44:09 --> Input Class Initialized
INFO - 2024-10-29 00:44:09 --> Language Class Initialized
INFO - 2024-10-29 00:44:09 --> Loader Class Initialized
INFO - 2024-10-29 00:44:09 --> Helper loaded: url_helper
INFO - 2024-10-29 00:44:09 --> Helper loaded: html_helper
INFO - 2024-10-29 00:44:09 --> Helper loaded: file_helper
INFO - 2024-10-29 00:44:09 --> Helper loaded: string_helper
INFO - 2024-10-29 00:44:09 --> Helper loaded: form_helper
INFO - 2024-10-29 00:44:09 --> Helper loaded: my_helper
INFO - 2024-10-29 00:44:09 --> Database Driver Class Initialized
INFO - 2024-10-29 00:44:11 --> Upload Class Initialized
INFO - 2024-10-29 00:44:11 --> Email Class Initialized
INFO - 2024-10-29 00:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:44:11 --> Form Validation Class Initialized
INFO - 2024-10-29 00:44:11 --> Controller Class Initialized
INFO - 2024-10-29 06:14:11 --> Model "MainModel" initialized
INFO - 2024-10-29 06:14:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:14:11 --> Final output sent to browser
DEBUG - 2024-10-29 06:14:11 --> Total execution time: 2.1055
INFO - 2024-10-29 00:45:31 --> Config Class Initialized
INFO - 2024-10-29 00:45:31 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:45:31 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:45:31 --> Utf8 Class Initialized
INFO - 2024-10-29 00:45:31 --> URI Class Initialized
DEBUG - 2024-10-29 00:45:31 --> No URI present. Default controller set.
INFO - 2024-10-29 00:45:31 --> Router Class Initialized
INFO - 2024-10-29 00:45:31 --> Output Class Initialized
INFO - 2024-10-29 00:45:31 --> Security Class Initialized
DEBUG - 2024-10-29 00:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:45:31 --> Input Class Initialized
INFO - 2024-10-29 00:45:31 --> Language Class Initialized
INFO - 2024-10-29 00:45:31 --> Loader Class Initialized
INFO - 2024-10-29 00:45:31 --> Helper loaded: url_helper
INFO - 2024-10-29 00:45:31 --> Helper loaded: html_helper
INFO - 2024-10-29 00:45:31 --> Helper loaded: file_helper
INFO - 2024-10-29 00:45:31 --> Helper loaded: string_helper
INFO - 2024-10-29 00:45:31 --> Helper loaded: form_helper
INFO - 2024-10-29 00:45:31 --> Helper loaded: my_helper
INFO - 2024-10-29 00:45:31 --> Database Driver Class Initialized
INFO - 2024-10-29 00:45:33 --> Upload Class Initialized
INFO - 2024-10-29 00:45:33 --> Email Class Initialized
INFO - 2024-10-29 00:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:45:33 --> Form Validation Class Initialized
INFO - 2024-10-29 00:45:33 --> Controller Class Initialized
INFO - 2024-10-29 06:15:33 --> Model "MainModel" initialized
INFO - 2024-10-29 06:15:33 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:15:33 --> Final output sent to browser
DEBUG - 2024-10-29 06:15:33 --> Total execution time: 2.1297
INFO - 2024-10-29 00:45:35 --> Config Class Initialized
INFO - 2024-10-29 00:45:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:45:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:45:35 --> Utf8 Class Initialized
INFO - 2024-10-29 00:45:35 --> URI Class Initialized
DEBUG - 2024-10-29 00:45:35 --> No URI present. Default controller set.
INFO - 2024-10-29 00:45:35 --> Router Class Initialized
INFO - 2024-10-29 00:45:35 --> Output Class Initialized
INFO - 2024-10-29 00:45:35 --> Security Class Initialized
DEBUG - 2024-10-29 00:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:45:35 --> Input Class Initialized
INFO - 2024-10-29 00:45:35 --> Language Class Initialized
INFO - 2024-10-29 00:45:35 --> Loader Class Initialized
INFO - 2024-10-29 00:45:35 --> Helper loaded: url_helper
INFO - 2024-10-29 00:45:35 --> Helper loaded: html_helper
INFO - 2024-10-29 00:45:35 --> Helper loaded: file_helper
INFO - 2024-10-29 00:45:35 --> Helper loaded: string_helper
INFO - 2024-10-29 00:45:35 --> Helper loaded: form_helper
INFO - 2024-10-29 00:45:35 --> Helper loaded: my_helper
INFO - 2024-10-29 00:45:35 --> Database Driver Class Initialized
INFO - 2024-10-29 00:45:37 --> Upload Class Initialized
INFO - 2024-10-29 00:45:37 --> Email Class Initialized
INFO - 2024-10-29 00:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:45:37 --> Form Validation Class Initialized
INFO - 2024-10-29 00:45:37 --> Controller Class Initialized
INFO - 2024-10-29 06:15:37 --> Model "MainModel" initialized
INFO - 2024-10-29 06:15:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:15:37 --> Final output sent to browser
DEBUG - 2024-10-29 06:15:37 --> Total execution time: 2.1537
INFO - 2024-10-29 00:51:22 --> Config Class Initialized
INFO - 2024-10-29 00:51:22 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:51:22 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:51:22 --> Utf8 Class Initialized
INFO - 2024-10-29 00:51:22 --> URI Class Initialized
DEBUG - 2024-10-29 00:51:22 --> No URI present. Default controller set.
INFO - 2024-10-29 00:51:22 --> Router Class Initialized
INFO - 2024-10-29 00:51:22 --> Output Class Initialized
INFO - 2024-10-29 00:51:22 --> Security Class Initialized
DEBUG - 2024-10-29 00:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:51:22 --> Input Class Initialized
INFO - 2024-10-29 00:51:22 --> Language Class Initialized
INFO - 2024-10-29 00:51:22 --> Loader Class Initialized
INFO - 2024-10-29 00:51:22 --> Helper loaded: url_helper
INFO - 2024-10-29 00:51:22 --> Helper loaded: html_helper
INFO - 2024-10-29 00:51:22 --> Helper loaded: file_helper
INFO - 2024-10-29 00:51:22 --> Helper loaded: string_helper
INFO - 2024-10-29 00:51:22 --> Helper loaded: form_helper
INFO - 2024-10-29 00:51:22 --> Helper loaded: my_helper
INFO - 2024-10-29 00:51:22 --> Database Driver Class Initialized
INFO - 2024-10-29 00:51:23 --> Config Class Initialized
INFO - 2024-10-29 00:51:23 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:51:23 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:51:23 --> Utf8 Class Initialized
INFO - 2024-10-29 00:51:23 --> URI Class Initialized
DEBUG - 2024-10-29 00:51:23 --> No URI present. Default controller set.
INFO - 2024-10-29 00:51:23 --> Router Class Initialized
INFO - 2024-10-29 00:51:23 --> Output Class Initialized
INFO - 2024-10-29 00:51:23 --> Security Class Initialized
DEBUG - 2024-10-29 00:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:51:23 --> Input Class Initialized
INFO - 2024-10-29 00:51:23 --> Language Class Initialized
INFO - 2024-10-29 00:51:23 --> Loader Class Initialized
INFO - 2024-10-29 00:51:23 --> Helper loaded: url_helper
INFO - 2024-10-29 00:51:23 --> Helper loaded: html_helper
INFO - 2024-10-29 00:51:23 --> Helper loaded: file_helper
INFO - 2024-10-29 00:51:23 --> Helper loaded: string_helper
INFO - 2024-10-29 00:51:23 --> Helper loaded: form_helper
INFO - 2024-10-29 00:51:23 --> Helper loaded: my_helper
INFO - 2024-10-29 00:51:23 --> Database Driver Class Initialized
INFO - 2024-10-29 00:51:24 --> Upload Class Initialized
INFO - 2024-10-29 00:51:25 --> Email Class Initialized
INFO - 2024-10-29 00:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:51:25 --> Form Validation Class Initialized
INFO - 2024-10-29 00:51:25 --> Controller Class Initialized
INFO - 2024-10-29 06:21:25 --> Model "MainModel" initialized
INFO - 2024-10-29 06:21:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:21:25 --> Final output sent to browser
DEBUG - 2024-10-29 06:21:25 --> Total execution time: 2.1841
INFO - 2024-10-29 00:51:25 --> Upload Class Initialized
INFO - 2024-10-29 00:51:25 --> Email Class Initialized
INFO - 2024-10-29 00:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 00:51:25 --> Form Validation Class Initialized
INFO - 2024-10-29 00:51:25 --> Controller Class Initialized
INFO - 2024-10-29 06:21:25 --> Model "MainModel" initialized
INFO - 2024-10-29 06:21:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:21:25 --> Final output sent to browser
DEBUG - 2024-10-29 06:21:25 --> Total execution time: 2.1543
INFO - 2024-10-29 00:51:33 --> Config Class Initialized
INFO - 2024-10-29 00:51:33 --> Hooks Class Initialized
DEBUG - 2024-10-29 00:51:33 --> UTF-8 Support Enabled
INFO - 2024-10-29 00:51:33 --> Utf8 Class Initialized
INFO - 2024-10-29 00:51:33 --> URI Class Initialized
INFO - 2024-10-29 00:51:33 --> Router Class Initialized
INFO - 2024-10-29 00:51:33 --> Output Class Initialized
INFO - 2024-10-29 00:51:33 --> Security Class Initialized
DEBUG - 2024-10-29 00:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 00:51:33 --> Input Class Initialized
INFO - 2024-10-29 00:51:33 --> Language Class Initialized
ERROR - 2024-10-29 00:51:33 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-29 01:05:56 --> Config Class Initialized
INFO - 2024-10-29 01:05:56 --> Hooks Class Initialized
DEBUG - 2024-10-29 01:05:56 --> UTF-8 Support Enabled
INFO - 2024-10-29 01:05:56 --> Utf8 Class Initialized
INFO - 2024-10-29 01:05:56 --> URI Class Initialized
DEBUG - 2024-10-29 01:05:56 --> No URI present. Default controller set.
INFO - 2024-10-29 01:05:56 --> Router Class Initialized
INFO - 2024-10-29 01:05:56 --> Output Class Initialized
INFO - 2024-10-29 01:05:56 --> Security Class Initialized
DEBUG - 2024-10-29 01:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 01:05:56 --> Input Class Initialized
INFO - 2024-10-29 01:05:56 --> Language Class Initialized
INFO - 2024-10-29 01:05:56 --> Loader Class Initialized
INFO - 2024-10-29 01:05:56 --> Helper loaded: url_helper
INFO - 2024-10-29 01:05:56 --> Helper loaded: html_helper
INFO - 2024-10-29 01:05:56 --> Helper loaded: file_helper
INFO - 2024-10-29 01:05:56 --> Helper loaded: string_helper
INFO - 2024-10-29 01:05:56 --> Helper loaded: form_helper
INFO - 2024-10-29 01:05:56 --> Helper loaded: my_helper
INFO - 2024-10-29 01:05:56 --> Database Driver Class Initialized
INFO - 2024-10-29 01:05:58 --> Upload Class Initialized
INFO - 2024-10-29 01:05:58 --> Email Class Initialized
INFO - 2024-10-29 01:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 01:05:58 --> Form Validation Class Initialized
INFO - 2024-10-29 01:05:58 --> Controller Class Initialized
INFO - 2024-10-29 06:35:58 --> Model "MainModel" initialized
INFO - 2024-10-29 06:35:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 06:35:58 --> Final output sent to browser
DEBUG - 2024-10-29 06:35:58 --> Total execution time: 2.2165
INFO - 2024-10-29 02:44:32 --> Config Class Initialized
INFO - 2024-10-29 02:44:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 02:44:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 02:44:32 --> Utf8 Class Initialized
INFO - 2024-10-29 02:44:32 --> URI Class Initialized
DEBUG - 2024-10-29 02:44:32 --> No URI present. Default controller set.
INFO - 2024-10-29 02:44:32 --> Router Class Initialized
INFO - 2024-10-29 02:44:32 --> Output Class Initialized
INFO - 2024-10-29 02:44:32 --> Security Class Initialized
DEBUG - 2024-10-29 02:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 02:44:32 --> Input Class Initialized
INFO - 2024-10-29 02:44:32 --> Language Class Initialized
INFO - 2024-10-29 02:44:32 --> Loader Class Initialized
INFO - 2024-10-29 02:44:32 --> Helper loaded: url_helper
INFO - 2024-10-29 02:44:32 --> Helper loaded: html_helper
INFO - 2024-10-29 02:44:32 --> Helper loaded: file_helper
INFO - 2024-10-29 02:44:32 --> Helper loaded: string_helper
INFO - 2024-10-29 02:44:32 --> Helper loaded: form_helper
INFO - 2024-10-29 02:44:32 --> Helper loaded: my_helper
INFO - 2024-10-29 02:44:32 --> Database Driver Class Initialized
INFO - 2024-10-29 02:44:34 --> Upload Class Initialized
INFO - 2024-10-29 02:44:34 --> Email Class Initialized
INFO - 2024-10-29 02:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 02:44:34 --> Form Validation Class Initialized
INFO - 2024-10-29 02:44:34 --> Controller Class Initialized
INFO - 2024-10-29 08:14:34 --> Model "MainModel" initialized
INFO - 2024-10-29 08:14:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 08:14:34 --> Final output sent to browser
DEBUG - 2024-10-29 08:14:34 --> Total execution time: 2.2824
INFO - 2024-10-29 03:03:27 --> Config Class Initialized
INFO - 2024-10-29 03:03:27 --> Hooks Class Initialized
DEBUG - 2024-10-29 03:03:27 --> UTF-8 Support Enabled
INFO - 2024-10-29 03:03:27 --> Utf8 Class Initialized
INFO - 2024-10-29 03:03:27 --> URI Class Initialized
DEBUG - 2024-10-29 03:03:27 --> No URI present. Default controller set.
INFO - 2024-10-29 03:03:27 --> Router Class Initialized
INFO - 2024-10-29 03:03:27 --> Output Class Initialized
INFO - 2024-10-29 03:03:27 --> Security Class Initialized
DEBUG - 2024-10-29 03:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 03:03:27 --> Input Class Initialized
INFO - 2024-10-29 03:03:27 --> Language Class Initialized
INFO - 2024-10-29 03:03:27 --> Loader Class Initialized
INFO - 2024-10-29 03:03:27 --> Helper loaded: url_helper
INFO - 2024-10-29 03:03:27 --> Helper loaded: html_helper
INFO - 2024-10-29 03:03:27 --> Helper loaded: file_helper
INFO - 2024-10-29 03:03:27 --> Helper loaded: string_helper
INFO - 2024-10-29 03:03:27 --> Helper loaded: form_helper
INFO - 2024-10-29 03:03:27 --> Helper loaded: my_helper
INFO - 2024-10-29 03:03:27 --> Database Driver Class Initialized
INFO - 2024-10-29 03:03:29 --> Upload Class Initialized
INFO - 2024-10-29 03:03:29 --> Email Class Initialized
INFO - 2024-10-29 03:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 03:03:29 --> Form Validation Class Initialized
INFO - 2024-10-29 03:03:29 --> Controller Class Initialized
INFO - 2024-10-29 08:33:29 --> Model "MainModel" initialized
INFO - 2024-10-29 08:33:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 08:33:29 --> Final output sent to browser
DEBUG - 2024-10-29 08:33:29 --> Total execution time: 2.2002
INFO - 2024-10-29 04:07:12 --> Config Class Initialized
INFO - 2024-10-29 04:07:12 --> Hooks Class Initialized
DEBUG - 2024-10-29 04:07:12 --> UTF-8 Support Enabled
INFO - 2024-10-29 04:07:12 --> Utf8 Class Initialized
INFO - 2024-10-29 04:07:12 --> URI Class Initialized
DEBUG - 2024-10-29 04:07:12 --> No URI present. Default controller set.
INFO - 2024-10-29 04:07:12 --> Router Class Initialized
INFO - 2024-10-29 04:07:12 --> Output Class Initialized
INFO - 2024-10-29 04:07:12 --> Security Class Initialized
DEBUG - 2024-10-29 04:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 04:07:12 --> Input Class Initialized
INFO - 2024-10-29 04:07:12 --> Language Class Initialized
INFO - 2024-10-29 04:07:12 --> Loader Class Initialized
INFO - 2024-10-29 04:07:12 --> Helper loaded: url_helper
INFO - 2024-10-29 04:07:12 --> Helper loaded: html_helper
INFO - 2024-10-29 04:07:12 --> Helper loaded: file_helper
INFO - 2024-10-29 04:07:12 --> Helper loaded: string_helper
INFO - 2024-10-29 04:07:12 --> Helper loaded: form_helper
INFO - 2024-10-29 04:07:12 --> Helper loaded: my_helper
INFO - 2024-10-29 04:07:12 --> Database Driver Class Initialized
INFO - 2024-10-29 04:07:14 --> Upload Class Initialized
INFO - 2024-10-29 04:07:14 --> Email Class Initialized
INFO - 2024-10-29 04:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 04:07:14 --> Form Validation Class Initialized
INFO - 2024-10-29 04:07:14 --> Controller Class Initialized
INFO - 2024-10-29 09:37:14 --> Model "MainModel" initialized
INFO - 2024-10-29 09:37:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 09:37:14 --> Final output sent to browser
DEBUG - 2024-10-29 09:37:14 --> Total execution time: 2.2149
INFO - 2024-10-29 04:14:21 --> Config Class Initialized
INFO - 2024-10-29 04:14:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 04:14:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 04:14:21 --> Utf8 Class Initialized
INFO - 2024-10-29 04:14:21 --> URI Class Initialized
INFO - 2024-10-29 04:14:21 --> Router Class Initialized
INFO - 2024-10-29 04:14:21 --> Output Class Initialized
INFO - 2024-10-29 04:14:21 --> Security Class Initialized
DEBUG - 2024-10-29 04:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 04:14:21 --> Input Class Initialized
INFO - 2024-10-29 04:14:21 --> Language Class Initialized
ERROR - 2024-10-29 04:14:21 --> 404 Page Not Found: Https:/livservice.in
INFO - 2024-10-29 08:09:58 --> Config Class Initialized
INFO - 2024-10-29 08:09:58 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:09:58 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:09:58 --> Utf8 Class Initialized
INFO - 2024-10-29 08:09:58 --> URI Class Initialized
DEBUG - 2024-10-29 08:09:58 --> No URI present. Default controller set.
INFO - 2024-10-29 08:09:58 --> Router Class Initialized
INFO - 2024-10-29 08:09:58 --> Output Class Initialized
INFO - 2024-10-29 08:09:58 --> Security Class Initialized
DEBUG - 2024-10-29 08:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:09:58 --> Input Class Initialized
INFO - 2024-10-29 08:09:58 --> Language Class Initialized
INFO - 2024-10-29 08:09:58 --> Loader Class Initialized
INFO - 2024-10-29 08:09:58 --> Helper loaded: url_helper
INFO - 2024-10-29 08:09:58 --> Helper loaded: html_helper
INFO - 2024-10-29 08:09:58 --> Helper loaded: file_helper
INFO - 2024-10-29 08:09:58 --> Helper loaded: string_helper
INFO - 2024-10-29 08:09:58 --> Helper loaded: form_helper
INFO - 2024-10-29 08:09:58 --> Helper loaded: my_helper
INFO - 2024-10-29 08:09:58 --> Database Driver Class Initialized
INFO - 2024-10-29 08:10:00 --> Upload Class Initialized
INFO - 2024-10-29 08:10:00 --> Email Class Initialized
INFO - 2024-10-29 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:10:00 --> Form Validation Class Initialized
INFO - 2024-10-29 08:10:00 --> Controller Class Initialized
INFO - 2024-10-29 13:40:00 --> Model "MainModel" initialized
INFO - 2024-10-29 13:40:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 13:40:00 --> Final output sent to browser
DEBUG - 2024-10-29 13:40:00 --> Total execution time: 2.3404
INFO - 2024-10-29 08:10:58 --> Config Class Initialized
INFO - 2024-10-29 08:10:58 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:10:58 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:10:58 --> Utf8 Class Initialized
INFO - 2024-10-29 08:10:58 --> URI Class Initialized
INFO - 2024-10-29 08:10:58 --> Router Class Initialized
INFO - 2024-10-29 08:10:58 --> Output Class Initialized
INFO - 2024-10-29 08:10:58 --> Security Class Initialized
DEBUG - 2024-10-29 08:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:10:58 --> Input Class Initialized
INFO - 2024-10-29 08:10:58 --> Language Class Initialized
INFO - 2024-10-29 08:10:58 --> Loader Class Initialized
INFO - 2024-10-29 08:10:58 --> Helper loaded: url_helper
INFO - 2024-10-29 08:10:58 --> Helper loaded: html_helper
INFO - 2024-10-29 08:10:58 --> Helper loaded: file_helper
INFO - 2024-10-29 08:10:58 --> Helper loaded: string_helper
INFO - 2024-10-29 08:10:58 --> Helper loaded: form_helper
INFO - 2024-10-29 08:10:58 --> Helper loaded: my_helper
INFO - 2024-10-29 08:10:58 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:00 --> Upload Class Initialized
INFO - 2024-10-29 08:11:00 --> Email Class Initialized
INFO - 2024-10-29 08:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:00 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:00 --> Controller Class Initialized
INFO - 2024-10-29 13:41:00 --> Model "MainModel" initialized
INFO - 2024-10-29 08:11:00 --> Config Class Initialized
INFO - 2024-10-29 08:11:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:00 --> URI Class Initialized
INFO - 2024-10-29 08:11:00 --> Router Class Initialized
INFO - 2024-10-29 08:11:00 --> Output Class Initialized
INFO - 2024-10-29 08:11:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:00 --> Input Class Initialized
INFO - 2024-10-29 08:11:00 --> Language Class Initialized
INFO - 2024-10-29 08:11:01 --> Config Class Initialized
INFO - 2024-10-29 08:11:01 --> Loader Class Initialized
INFO - 2024-10-29 08:11:01 --> Hooks Class Initialized
INFO - 2024-10-29 08:11:01 --> Helper loaded: url_helper
DEBUG - 2024-10-29 08:11:01 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:01 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:01 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:01 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:01 --> URI Class Initialized
INFO - 2024-10-29 08:11:01 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:01 --> Router Class Initialized
INFO - 2024-10-29 08:11:01 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:01 --> Output Class Initialized
INFO - 2024-10-29 08:11:01 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:01 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:01 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:01 --> Input Class Initialized
INFO - 2024-10-29 08:11:01 --> Language Class Initialized
ERROR - 2024-10-29 08:11:01 --> 404 Page Not Found: Faviconico/index
INFO - 2024-10-29 08:11:03 --> Upload Class Initialized
INFO - 2024-10-29 08:11:03 --> Email Class Initialized
INFO - 2024-10-29 08:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:03 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:03 --> Controller Class Initialized
INFO - 2024-10-29 13:41:03 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:03 --> Model "FrontofficeModel" initialized
INFO - 2024-10-29 13:41:03 --> Model "HotelAdminModel" initialized
INFO - 2024-10-29 13:41:03 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-29 13:41:03 --> Model "FoodAdminModel" initialized
INFO - 2024-10-29 13:41:03 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 13:41:03 --> Helper loaded: notification_helper
INFO - 2024-10-29 13:41:03 --> Helper loaded: array_helper
INFO - 2024-10-29 13:41:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-29 13:41:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/superadmindashboard.php
INFO - 2024-10-29 13:41:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-29 13:41:03 --> Final output sent to browser
DEBUG - 2024-10-29 13:41:03 --> Total execution time: 3.1428
INFO - 2024-10-29 08:11:05 --> Config Class Initialized
INFO - 2024-10-29 08:11:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:05 --> URI Class Initialized
INFO - 2024-10-29 08:11:05 --> Router Class Initialized
INFO - 2024-10-29 08:11:05 --> Output Class Initialized
INFO - 2024-10-29 08:11:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:05 --> Input Class Initialized
INFO - 2024-10-29 08:11:05 --> Language Class Initialized
ERROR - 2024-10-29 08:11:05 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:05 --> Config Class Initialized
INFO - 2024-10-29 08:11:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:05 --> URI Class Initialized
INFO - 2024-10-29 08:11:05 --> Router Class Initialized
INFO - 2024-10-29 08:11:05 --> Output Class Initialized
INFO - 2024-10-29 08:11:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:05 --> Input Class Initialized
INFO - 2024-10-29 08:11:05 --> Language Class Initialized
INFO - 2024-10-29 08:11:05 --> Loader Class Initialized
INFO - 2024-10-29 08:11:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:06 --> Config Class Initialized
INFO - 2024-10-29 08:11:06 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:06 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:06 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:06 --> URI Class Initialized
INFO - 2024-10-29 08:11:06 --> Router Class Initialized
INFO - 2024-10-29 08:11:06 --> Output Class Initialized
INFO - 2024-10-29 08:11:06 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:06 --> Input Class Initialized
INFO - 2024-10-29 08:11:06 --> Language Class Initialized
ERROR - 2024-10-29 08:11:06 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:06 --> Config Class Initialized
INFO - 2024-10-29 08:11:06 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:06 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:06 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:06 --> URI Class Initialized
INFO - 2024-10-29 08:11:06 --> Router Class Initialized
INFO - 2024-10-29 08:11:06 --> Output Class Initialized
INFO - 2024-10-29 08:11:06 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:06 --> Input Class Initialized
INFO - 2024-10-29 08:11:06 --> Language Class Initialized
ERROR - 2024-10-29 08:11:06 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:07 --> Upload Class Initialized
INFO - 2024-10-29 08:11:07 --> Email Class Initialized
INFO - 2024-10-29 08:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:07 --> Controller Class Initialized
INFO - 2024-10-29 13:41:07 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:07 --> Model "FrontofficeModel" initialized
INFO - 2024-10-29 13:41:07 --> Model "HotelAdminModel" initialized
INFO - 2024-10-29 13:41:07 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-29 13:41:07 --> Model "FoodAdminModel" initialized
INFO - 2024-10-29 13:41:07 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 13:41:07 --> Helper loaded: notification_helper
INFO - 2024-10-29 13:41:07 --> Helper loaded: array_helper
INFO - 2024-10-29 13:41:07 --> Final output sent to browser
DEBUG - 2024-10-29 13:41:07 --> Total execution time: 2.1936
INFO - 2024-10-29 08:11:11 --> Config Class Initialized
INFO - 2024-10-29 08:11:11 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:11 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:11 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:11 --> URI Class Initialized
INFO - 2024-10-29 08:11:11 --> Router Class Initialized
INFO - 2024-10-29 08:11:11 --> Output Class Initialized
INFO - 2024-10-29 08:11:11 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:11 --> Input Class Initialized
INFO - 2024-10-29 08:11:11 --> Language Class Initialized
INFO - 2024-10-29 08:11:11 --> Loader Class Initialized
INFO - 2024-10-29 08:11:11 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:11 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:11 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:11 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:11 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:11 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:11 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:12 --> Config Class Initialized
INFO - 2024-10-29 08:11:12 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:12 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:12 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:12 --> URI Class Initialized
INFO - 2024-10-29 08:11:12 --> Router Class Initialized
INFO - 2024-10-29 08:11:12 --> Output Class Initialized
INFO - 2024-10-29 08:11:12 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:12 --> Input Class Initialized
INFO - 2024-10-29 08:11:12 --> Language Class Initialized
INFO - 2024-10-29 08:11:12 --> Loader Class Initialized
INFO - 2024-10-29 08:11:12 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:12 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:12 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:12 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:12 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:12 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:12 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:13 --> Upload Class Initialized
INFO - 2024-10-29 08:11:13 --> Email Class Initialized
INFO - 2024-10-29 08:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:13 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:13 --> Controller Class Initialized
INFO - 2024-10-29 13:41:13 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:13 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:13 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:14 --> Upload Class Initialized
INFO - 2024-10-29 08:11:14 --> Email Class Initialized
INFO - 2024-10-29 08:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:14 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:14 --> Controller Class Initialized
INFO - 2024-10-29 13:41:14 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 13:41:15 --> Helper loaded: notification_helper
INFO - 2024-10-29 13:41:15 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 13:41:15 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
INFO - 2024-10-29 13:41:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin/hotelLists.php
INFO - 2024-10-29 13:41:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-29 13:41:15 --> Final output sent to browser
DEBUG - 2024-10-29 13:41:15 --> Total execution time: 2.7968
INFO - 2024-10-29 08:11:15 --> Config Class Initialized
INFO - 2024-10-29 08:11:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:15 --> URI Class Initialized
INFO - 2024-10-29 08:11:15 --> Router Class Initialized
INFO - 2024-10-29 08:11:15 --> Output Class Initialized
INFO - 2024-10-29 08:11:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:15 --> Input Class Initialized
INFO - 2024-10-29 08:11:15 --> Language Class Initialized
ERROR - 2024-10-29 08:11:15 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:15 --> Config Class Initialized
INFO - 2024-10-29 08:11:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:15 --> URI Class Initialized
INFO - 2024-10-29 08:11:15 --> Router Class Initialized
INFO - 2024-10-29 08:11:15 --> Output Class Initialized
INFO - 2024-10-29 08:11:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:15 --> Input Class Initialized
INFO - 2024-10-29 08:11:15 --> Language Class Initialized
ERROR - 2024-10-29 08:11:15 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:15 --> Config Class Initialized
INFO - 2024-10-29 08:11:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:15 --> URI Class Initialized
INFO - 2024-10-29 08:11:15 --> Router Class Initialized
INFO - 2024-10-29 08:11:15 --> Output Class Initialized
INFO - 2024-10-29 08:11:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:15 --> Input Class Initialized
INFO - 2024-10-29 08:11:15 --> Language Class Initialized
ERROR - 2024-10-29 08:11:15 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:18 --> Config Class Initialized
INFO - 2024-10-29 08:11:18 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:18 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:18 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:18 --> URI Class Initialized
INFO - 2024-10-29 08:11:18 --> Router Class Initialized
INFO - 2024-10-29 08:11:18 --> Output Class Initialized
INFO - 2024-10-29 08:11:18 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:18 --> Input Class Initialized
INFO - 2024-10-29 08:11:18 --> Language Class Initialized
INFO - 2024-10-29 08:11:18 --> Loader Class Initialized
INFO - 2024-10-29 08:11:18 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:18 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:18 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:18 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:18 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:18 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:18 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:20 --> Config Class Initialized
INFO - 2024-10-29 08:11:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:20 --> URI Class Initialized
INFO - 2024-10-29 08:11:20 --> Router Class Initialized
INFO - 2024-10-29 08:11:20 --> Output Class Initialized
INFO - 2024-10-29 08:11:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:20 --> Input Class Initialized
INFO - 2024-10-29 08:11:20 --> Language Class Initialized
INFO - 2024-10-29 08:11:20 --> Loader Class Initialized
INFO - 2024-10-29 08:11:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:20 --> Upload Class Initialized
INFO - 2024-10-29 08:11:20 --> Email Class Initialized
INFO - 2024-10-29 08:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:20 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:20 --> Controller Class Initialized
INFO - 2024-10-29 13:41:20 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 13:41:20 --> Helper loaded: notification_helper
INFO - 2024-10-29 13:41:20 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-29 13:41:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin/leadsPlan.php
INFO - 2024-10-29 13:41:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-29 13:41:20 --> Final output sent to browser
DEBUG - 2024-10-29 13:41:20 --> Total execution time: 2.1450
INFO - 2024-10-29 08:11:21 --> Config Class Initialized
INFO - 2024-10-29 08:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:21 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:21 --> URI Class Initialized
INFO - 2024-10-29 08:11:21 --> Router Class Initialized
INFO - 2024-10-29 08:11:21 --> Output Class Initialized
INFO - 2024-10-29 08:11:21 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:21 --> Input Class Initialized
INFO - 2024-10-29 08:11:21 --> Language Class Initialized
ERROR - 2024-10-29 08:11:21 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:21 --> Config Class Initialized
INFO - 2024-10-29 08:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:21 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:21 --> URI Class Initialized
INFO - 2024-10-29 08:11:21 --> Router Class Initialized
INFO - 2024-10-29 08:11:21 --> Output Class Initialized
INFO - 2024-10-29 08:11:21 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:21 --> Input Class Initialized
INFO - 2024-10-29 08:11:21 --> Language Class Initialized
ERROR - 2024-10-29 08:11:21 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:21 --> Config Class Initialized
INFO - 2024-10-29 08:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:21 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:21 --> URI Class Initialized
INFO - 2024-10-29 08:11:21 --> Router Class Initialized
INFO - 2024-10-29 08:11:21 --> Output Class Initialized
INFO - 2024-10-29 08:11:21 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:21 --> Input Class Initialized
INFO - 2024-10-29 08:11:21 --> Language Class Initialized
ERROR - 2024-10-29 08:11:21 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:21 --> Config Class Initialized
INFO - 2024-10-29 08:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:21 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:21 --> URI Class Initialized
INFO - 2024-10-29 08:11:21 --> Router Class Initialized
INFO - 2024-10-29 08:11:21 --> Output Class Initialized
INFO - 2024-10-29 08:11:21 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:21 --> Input Class Initialized
INFO - 2024-10-29 08:11:21 --> Language Class Initialized
INFO - 2024-10-29 08:11:21 --> Loader Class Initialized
INFO - 2024-10-29 08:11:21 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:21 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:21 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:21 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:21 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:21 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:21 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:22 --> Upload Class Initialized
INFO - 2024-10-29 08:11:22 --> Email Class Initialized
INFO - 2024-10-29 08:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:22 --> Controller Class Initialized
INFO - 2024-10-29 13:41:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:22 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:23 --> Upload Class Initialized
INFO - 2024-10-29 08:11:23 --> Email Class Initialized
INFO - 2024-10-29 08:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:24 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:24 --> Controller Class Initialized
INFO - 2024-10-29 13:41:24 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:24 --> Model "FrontofficeModel" initialized
INFO - 2024-10-29 13:41:24 --> Model "HotelAdminModel" initialized
INFO - 2024-10-29 13:41:24 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-29 13:41:24 --> Model "FoodAdminModel" initialized
INFO - 2024-10-29 13:41:24 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 13:41:24 --> Helper loaded: notification_helper
INFO - 2024-10-29 13:41:24 --> Helper loaded: array_helper
INFO - 2024-10-29 13:41:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-29 13:41:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/superadmindashboard.php
INFO - 2024-10-29 13:41:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-29 13:41:24 --> Final output sent to browser
DEBUG - 2024-10-29 13:41:24 --> Total execution time: 2.2450
INFO - 2024-10-29 08:11:24 --> Config Class Initialized
INFO - 2024-10-29 08:11:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:24 --> URI Class Initialized
INFO - 2024-10-29 08:11:24 --> Router Class Initialized
INFO - 2024-10-29 08:11:24 --> Output Class Initialized
INFO - 2024-10-29 08:11:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:24 --> Input Class Initialized
INFO - 2024-10-29 08:11:24 --> Config Class Initialized
INFO - 2024-10-29 08:11:24 --> Language Class Initialized
INFO - 2024-10-29 08:11:24 --> Hooks Class Initialized
ERROR - 2024-10-29 08:11:24 --> 404 Page Not Found: Fonts/poppins
DEBUG - 2024-10-29 08:11:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:24 --> URI Class Initialized
INFO - 2024-10-29 08:11:24 --> Router Class Initialized
INFO - 2024-10-29 08:11:24 --> Output Class Initialized
INFO - 2024-10-29 08:11:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:24 --> Input Class Initialized
INFO - 2024-10-29 08:11:24 --> Language Class Initialized
INFO - 2024-10-29 08:11:24 --> Loader Class Initialized
INFO - 2024-10-29 08:11:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:24 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:24 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:24 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:24 --> Config Class Initialized
INFO - 2024-10-29 08:11:24 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:24 --> Hooks Class Initialized
INFO - 2024-10-29 08:11:24 --> Database Driver Class Initialized
DEBUG - 2024-10-29 08:11:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:24 --> URI Class Initialized
INFO - 2024-10-29 08:11:24 --> Router Class Initialized
INFO - 2024-10-29 08:11:24 --> Output Class Initialized
INFO - 2024-10-29 08:11:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:24 --> Input Class Initialized
INFO - 2024-10-29 08:11:24 --> Language Class Initialized
ERROR - 2024-10-29 08:11:24 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:24 --> Config Class Initialized
INFO - 2024-10-29 08:11:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:24 --> URI Class Initialized
INFO - 2024-10-29 08:11:24 --> Router Class Initialized
INFO - 2024-10-29 08:11:24 --> Output Class Initialized
INFO - 2024-10-29 08:11:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:24 --> Input Class Initialized
INFO - 2024-10-29 08:11:24 --> Language Class Initialized
ERROR - 2024-10-29 08:11:24 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:11:26 --> Upload Class Initialized
INFO - 2024-10-29 08:11:26 --> Email Class Initialized
INFO - 2024-10-29 08:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:26 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:26 --> Controller Class Initialized
INFO - 2024-10-29 13:41:26 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:26 --> Model "FrontofficeModel" initialized
INFO - 2024-10-29 13:41:26 --> Model "HotelAdminModel" initialized
INFO - 2024-10-29 13:41:26 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-29 13:41:26 --> Model "FoodAdminModel" initialized
INFO - 2024-10-29 13:41:26 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 13:41:26 --> Helper loaded: notification_helper
INFO - 2024-10-29 13:41:26 --> Helper loaded: array_helper
INFO - 2024-10-29 13:41:26 --> Final output sent to browser
DEBUG - 2024-10-29 13:41:26 --> Total execution time: 2.2017
INFO - 2024-10-29 08:11:29 --> Config Class Initialized
INFO - 2024-10-29 08:11:29 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:29 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:29 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:29 --> URI Class Initialized
INFO - 2024-10-29 08:11:29 --> Router Class Initialized
INFO - 2024-10-29 08:11:29 --> Output Class Initialized
INFO - 2024-10-29 08:11:29 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:29 --> Input Class Initialized
INFO - 2024-10-29 08:11:29 --> Language Class Initialized
INFO - 2024-10-29 08:11:29 --> Loader Class Initialized
INFO - 2024-10-29 08:11:29 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:29 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:29 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:29 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:29 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:29 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:29 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:31 --> Upload Class Initialized
INFO - 2024-10-29 08:11:31 --> Email Class Initialized
INFO - 2024-10-29 08:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:31 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:31 --> Controller Class Initialized
INFO - 2024-10-29 13:41:31 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:31 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:31 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:34 --> Config Class Initialized
INFO - 2024-10-29 08:11:34 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:35 --> URI Class Initialized
INFO - 2024-10-29 08:11:35 --> Router Class Initialized
INFO - 2024-10-29 08:11:35 --> Output Class Initialized
INFO - 2024-10-29 08:11:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:35 --> Input Class Initialized
INFO - 2024-10-29 08:11:35 --> Language Class Initialized
INFO - 2024-10-29 08:11:35 --> Loader Class Initialized
INFO - 2024-10-29 08:11:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:37 --> Upload Class Initialized
INFO - 2024-10-29 08:11:37 --> Email Class Initialized
INFO - 2024-10-29 08:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:37 --> Controller Class Initialized
INFO - 2024-10-29 13:41:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:37 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:39 --> Config Class Initialized
INFO - 2024-10-29 08:11:39 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:39 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:39 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:39 --> URI Class Initialized
INFO - 2024-10-29 08:11:39 --> Router Class Initialized
INFO - 2024-10-29 08:11:39 --> Output Class Initialized
INFO - 2024-10-29 08:11:39 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:39 --> Input Class Initialized
INFO - 2024-10-29 08:11:39 --> Language Class Initialized
INFO - 2024-10-29 08:11:39 --> Loader Class Initialized
INFO - 2024-10-29 08:11:39 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:39 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:39 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:39 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:39 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:39 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:42 --> Upload Class Initialized
INFO - 2024-10-29 08:11:42 --> Email Class Initialized
INFO - 2024-10-29 08:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:42 --> Controller Class Initialized
INFO - 2024-10-29 13:41:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:42 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:44 --> Config Class Initialized
INFO - 2024-10-29 08:11:44 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:44 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:44 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:44 --> URI Class Initialized
INFO - 2024-10-29 08:11:44 --> Router Class Initialized
INFO - 2024-10-29 08:11:44 --> Output Class Initialized
INFO - 2024-10-29 08:11:44 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:44 --> Input Class Initialized
INFO - 2024-10-29 08:11:44 --> Language Class Initialized
INFO - 2024-10-29 08:11:44 --> Loader Class Initialized
INFO - 2024-10-29 08:11:44 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:44 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:44 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:44 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:44 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:44 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:44 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:47 --> Upload Class Initialized
INFO - 2024-10-29 08:11:47 --> Email Class Initialized
INFO - 2024-10-29 08:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:47 --> Controller Class Initialized
INFO - 2024-10-29 13:41:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:47 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:49 --> Config Class Initialized
INFO - 2024-10-29 08:11:49 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:49 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:49 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:49 --> URI Class Initialized
INFO - 2024-10-29 08:11:49 --> Router Class Initialized
INFO - 2024-10-29 08:11:49 --> Output Class Initialized
INFO - 2024-10-29 08:11:49 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:49 --> Input Class Initialized
INFO - 2024-10-29 08:11:49 --> Language Class Initialized
INFO - 2024-10-29 08:11:49 --> Loader Class Initialized
INFO - 2024-10-29 08:11:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:52 --> Upload Class Initialized
INFO - 2024-10-29 08:11:52 --> Email Class Initialized
INFO - 2024-10-29 08:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:52 --> Controller Class Initialized
INFO - 2024-10-29 13:41:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:52 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:54 --> Config Class Initialized
INFO - 2024-10-29 08:11:54 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:54 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:54 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:54 --> URI Class Initialized
INFO - 2024-10-29 08:11:54 --> Router Class Initialized
INFO - 2024-10-29 08:11:54 --> Output Class Initialized
INFO - 2024-10-29 08:11:54 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:54 --> Input Class Initialized
INFO - 2024-10-29 08:11:54 --> Language Class Initialized
INFO - 2024-10-29 08:11:54 --> Loader Class Initialized
INFO - 2024-10-29 08:11:54 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:54 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:54 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:54 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:54 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:11:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:11:57 --> Upload Class Initialized
INFO - 2024-10-29 08:11:57 --> Email Class Initialized
INFO - 2024-10-29 08:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:11:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:11:57 --> Controller Class Initialized
INFO - 2024-10-29 13:41:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:41:57 --> Model "MainModel" initialized
INFO - 2024-10-29 13:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:41:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:11:59 --> Config Class Initialized
INFO - 2024-10-29 08:11:59 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:11:59 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:11:59 --> Utf8 Class Initialized
INFO - 2024-10-29 08:11:59 --> URI Class Initialized
INFO - 2024-10-29 08:11:59 --> Router Class Initialized
INFO - 2024-10-29 08:11:59 --> Output Class Initialized
INFO - 2024-10-29 08:11:59 --> Security Class Initialized
DEBUG - 2024-10-29 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:11:59 --> Input Class Initialized
INFO - 2024-10-29 08:11:59 --> Language Class Initialized
INFO - 2024-10-29 08:11:59 --> Loader Class Initialized
INFO - 2024-10-29 08:11:59 --> Helper loaded: url_helper
INFO - 2024-10-29 08:11:59 --> Helper loaded: html_helper
INFO - 2024-10-29 08:11:59 --> Helper loaded: file_helper
INFO - 2024-10-29 08:11:59 --> Helper loaded: string_helper
INFO - 2024-10-29 08:11:59 --> Helper loaded: form_helper
INFO - 2024-10-29 08:11:59 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:02 --> Upload Class Initialized
INFO - 2024-10-29 08:12:02 --> Email Class Initialized
INFO - 2024-10-29 08:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:02 --> Controller Class Initialized
INFO - 2024-10-29 13:42:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:02 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:04 --> Config Class Initialized
INFO - 2024-10-29 08:12:04 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:04 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:04 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:04 --> URI Class Initialized
INFO - 2024-10-29 08:12:04 --> Router Class Initialized
INFO - 2024-10-29 08:12:05 --> Output Class Initialized
INFO - 2024-10-29 08:12:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:05 --> Input Class Initialized
INFO - 2024-10-29 08:12:05 --> Language Class Initialized
INFO - 2024-10-29 08:12:05 --> Loader Class Initialized
INFO - 2024-10-29 08:12:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:07 --> Upload Class Initialized
INFO - 2024-10-29 08:12:07 --> Email Class Initialized
INFO - 2024-10-29 08:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:07 --> Controller Class Initialized
INFO - 2024-10-29 13:42:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:07 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:09 --> Config Class Initialized
INFO - 2024-10-29 08:12:09 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:09 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:09 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:09 --> URI Class Initialized
INFO - 2024-10-29 08:12:09 --> Router Class Initialized
INFO - 2024-10-29 08:12:09 --> Output Class Initialized
INFO - 2024-10-29 08:12:09 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:09 --> Input Class Initialized
INFO - 2024-10-29 08:12:10 --> Language Class Initialized
INFO - 2024-10-29 08:12:10 --> Loader Class Initialized
INFO - 2024-10-29 08:12:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:12 --> Upload Class Initialized
INFO - 2024-10-29 08:12:12 --> Email Class Initialized
INFO - 2024-10-29 08:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:12 --> Controller Class Initialized
INFO - 2024-10-29 13:42:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:12 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:14 --> Config Class Initialized
INFO - 2024-10-29 08:12:14 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:14 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:14 --> URI Class Initialized
INFO - 2024-10-29 08:12:14 --> Router Class Initialized
INFO - 2024-10-29 08:12:14 --> Output Class Initialized
INFO - 2024-10-29 08:12:14 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:14 --> Input Class Initialized
INFO - 2024-10-29 08:12:14 --> Language Class Initialized
INFO - 2024-10-29 08:12:14 --> Loader Class Initialized
INFO - 2024-10-29 08:12:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:17 --> Upload Class Initialized
INFO - 2024-10-29 08:12:17 --> Email Class Initialized
INFO - 2024-10-29 08:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:17 --> Controller Class Initialized
INFO - 2024-10-29 13:42:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:17 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:19 --> Config Class Initialized
INFO - 2024-10-29 08:12:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:19 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:19 --> URI Class Initialized
INFO - 2024-10-29 08:12:19 --> Router Class Initialized
INFO - 2024-10-29 08:12:19 --> Output Class Initialized
INFO - 2024-10-29 08:12:19 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:19 --> Input Class Initialized
INFO - 2024-10-29 08:12:19 --> Language Class Initialized
INFO - 2024-10-29 08:12:20 --> Loader Class Initialized
INFO - 2024-10-29 08:12:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:22 --> Upload Class Initialized
INFO - 2024-10-29 08:12:22 --> Email Class Initialized
INFO - 2024-10-29 08:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:22 --> Controller Class Initialized
INFO - 2024-10-29 13:42:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:22 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:24 --> Config Class Initialized
INFO - 2024-10-29 08:12:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:24 --> URI Class Initialized
INFO - 2024-10-29 08:12:24 --> Router Class Initialized
INFO - 2024-10-29 08:12:24 --> Output Class Initialized
INFO - 2024-10-29 08:12:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:24 --> Input Class Initialized
INFO - 2024-10-29 08:12:24 --> Language Class Initialized
INFO - 2024-10-29 08:12:24 --> Loader Class Initialized
INFO - 2024-10-29 08:12:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:24 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:27 --> Upload Class Initialized
INFO - 2024-10-29 08:12:27 --> Email Class Initialized
INFO - 2024-10-29 08:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:27 --> Controller Class Initialized
INFO - 2024-10-29 13:42:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:27 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:29 --> Config Class Initialized
INFO - 2024-10-29 08:12:29 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:29 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:29 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:29 --> URI Class Initialized
INFO - 2024-10-29 08:12:29 --> Router Class Initialized
INFO - 2024-10-29 08:12:29 --> Output Class Initialized
INFO - 2024-10-29 08:12:29 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:29 --> Input Class Initialized
INFO - 2024-10-29 08:12:29 --> Language Class Initialized
INFO - 2024-10-29 08:12:29 --> Loader Class Initialized
INFO - 2024-10-29 08:12:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:32 --> Upload Class Initialized
INFO - 2024-10-29 08:12:32 --> Email Class Initialized
INFO - 2024-10-29 08:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:32 --> Controller Class Initialized
INFO - 2024-10-29 13:42:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:32 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:34 --> Config Class Initialized
INFO - 2024-10-29 08:12:34 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:34 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:34 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:34 --> URI Class Initialized
INFO - 2024-10-29 08:12:34 --> Router Class Initialized
INFO - 2024-10-29 08:12:34 --> Output Class Initialized
INFO - 2024-10-29 08:12:34 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:34 --> Input Class Initialized
INFO - 2024-10-29 08:12:34 --> Language Class Initialized
INFO - 2024-10-29 08:12:34 --> Loader Class Initialized
INFO - 2024-10-29 08:12:34 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:34 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:34 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:34 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:37 --> Upload Class Initialized
INFO - 2024-10-29 08:12:37 --> Email Class Initialized
INFO - 2024-10-29 08:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:37 --> Controller Class Initialized
INFO - 2024-10-29 13:42:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:37 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:39 --> Config Class Initialized
INFO - 2024-10-29 08:12:39 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:39 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:39 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:39 --> URI Class Initialized
INFO - 2024-10-29 08:12:39 --> Router Class Initialized
INFO - 2024-10-29 08:12:39 --> Output Class Initialized
INFO - 2024-10-29 08:12:39 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:39 --> Input Class Initialized
INFO - 2024-10-29 08:12:39 --> Language Class Initialized
INFO - 2024-10-29 08:12:39 --> Loader Class Initialized
INFO - 2024-10-29 08:12:39 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:39 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:39 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:39 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:39 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:39 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:42 --> Upload Class Initialized
INFO - 2024-10-29 08:12:42 --> Email Class Initialized
INFO - 2024-10-29 08:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:42 --> Controller Class Initialized
INFO - 2024-10-29 13:42:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:42 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:44 --> Config Class Initialized
INFO - 2024-10-29 08:12:44 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:44 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:44 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:44 --> URI Class Initialized
INFO - 2024-10-29 08:12:44 --> Router Class Initialized
INFO - 2024-10-29 08:12:44 --> Output Class Initialized
INFO - 2024-10-29 08:12:44 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:45 --> Input Class Initialized
INFO - 2024-10-29 08:12:45 --> Language Class Initialized
INFO - 2024-10-29 08:12:45 --> Loader Class Initialized
INFO - 2024-10-29 08:12:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:47 --> Upload Class Initialized
INFO - 2024-10-29 08:12:47 --> Email Class Initialized
INFO - 2024-10-29 08:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:47 --> Controller Class Initialized
INFO - 2024-10-29 13:42:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:47 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:49 --> Config Class Initialized
INFO - 2024-10-29 08:12:49 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:49 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:49 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:49 --> URI Class Initialized
INFO - 2024-10-29 08:12:49 --> Router Class Initialized
INFO - 2024-10-29 08:12:49 --> Output Class Initialized
INFO - 2024-10-29 08:12:49 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:49 --> Input Class Initialized
INFO - 2024-10-29 08:12:49 --> Language Class Initialized
INFO - 2024-10-29 08:12:49 --> Loader Class Initialized
INFO - 2024-10-29 08:12:49 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:49 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:49 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:52 --> Upload Class Initialized
INFO - 2024-10-29 08:12:52 --> Email Class Initialized
INFO - 2024-10-29 08:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:52 --> Controller Class Initialized
INFO - 2024-10-29 13:42:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:52 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:54 --> Config Class Initialized
INFO - 2024-10-29 08:12:54 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:54 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:54 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:54 --> URI Class Initialized
INFO - 2024-10-29 08:12:54 --> Router Class Initialized
INFO - 2024-10-29 08:12:54 --> Output Class Initialized
INFO - 2024-10-29 08:12:54 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:54 --> Input Class Initialized
INFO - 2024-10-29 08:12:54 --> Language Class Initialized
INFO - 2024-10-29 08:12:54 --> Loader Class Initialized
INFO - 2024-10-29 08:12:54 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:54 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:54 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:12:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:12:57 --> Upload Class Initialized
INFO - 2024-10-29 08:12:57 --> Email Class Initialized
INFO - 2024-10-29 08:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:12:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:12:57 --> Controller Class Initialized
INFO - 2024-10-29 13:42:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:42:57 --> Model "MainModel" initialized
INFO - 2024-10-29 13:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:42:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:12:59 --> Config Class Initialized
INFO - 2024-10-29 08:12:59 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:12:59 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:12:59 --> Utf8 Class Initialized
INFO - 2024-10-29 08:12:59 --> URI Class Initialized
INFO - 2024-10-29 08:12:59 --> Router Class Initialized
INFO - 2024-10-29 08:12:59 --> Output Class Initialized
INFO - 2024-10-29 08:12:59 --> Security Class Initialized
DEBUG - 2024-10-29 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:12:59 --> Input Class Initialized
INFO - 2024-10-29 08:12:59 --> Language Class Initialized
INFO - 2024-10-29 08:12:59 --> Loader Class Initialized
INFO - 2024-10-29 08:12:59 --> Helper loaded: url_helper
INFO - 2024-10-29 08:12:59 --> Helper loaded: html_helper
INFO - 2024-10-29 08:12:59 --> Helper loaded: file_helper
INFO - 2024-10-29 08:12:59 --> Helper loaded: string_helper
INFO - 2024-10-29 08:12:59 --> Helper loaded: form_helper
INFO - 2024-10-29 08:12:59 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:02 --> Upload Class Initialized
INFO - 2024-10-29 08:13:02 --> Email Class Initialized
INFO - 2024-10-29 08:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:02 --> Controller Class Initialized
INFO - 2024-10-29 13:43:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:02 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:04 --> Config Class Initialized
INFO - 2024-10-29 08:13:04 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:04 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:04 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:04 --> URI Class Initialized
INFO - 2024-10-29 08:13:04 --> Router Class Initialized
INFO - 2024-10-29 08:13:04 --> Output Class Initialized
INFO - 2024-10-29 08:13:04 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:04 --> Input Class Initialized
INFO - 2024-10-29 08:13:04 --> Language Class Initialized
INFO - 2024-10-29 08:13:05 --> Loader Class Initialized
INFO - 2024-10-29 08:13:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:07 --> Upload Class Initialized
INFO - 2024-10-29 08:13:07 --> Email Class Initialized
INFO - 2024-10-29 08:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:07 --> Controller Class Initialized
INFO - 2024-10-29 13:43:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:07 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:09 --> Config Class Initialized
INFO - 2024-10-29 08:13:09 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:09 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:09 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:09 --> URI Class Initialized
INFO - 2024-10-29 08:13:09 --> Router Class Initialized
INFO - 2024-10-29 08:13:09 --> Output Class Initialized
INFO - 2024-10-29 08:13:09 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:09 --> Input Class Initialized
INFO - 2024-10-29 08:13:09 --> Language Class Initialized
INFO - 2024-10-29 08:13:09 --> Loader Class Initialized
INFO - 2024-10-29 08:13:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:12 --> Upload Class Initialized
INFO - 2024-10-29 08:13:12 --> Email Class Initialized
INFO - 2024-10-29 08:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:12 --> Controller Class Initialized
INFO - 2024-10-29 13:43:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:12 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:14 --> Config Class Initialized
INFO - 2024-10-29 08:13:14 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:14 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:14 --> URI Class Initialized
INFO - 2024-10-29 08:13:14 --> Router Class Initialized
INFO - 2024-10-29 08:13:14 --> Output Class Initialized
INFO - 2024-10-29 08:13:14 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:14 --> Input Class Initialized
INFO - 2024-10-29 08:13:14 --> Language Class Initialized
INFO - 2024-10-29 08:13:14 --> Loader Class Initialized
INFO - 2024-10-29 08:13:14 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:14 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:17 --> Upload Class Initialized
INFO - 2024-10-29 08:13:17 --> Email Class Initialized
INFO - 2024-10-29 08:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:17 --> Controller Class Initialized
INFO - 2024-10-29 13:43:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:17 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:19 --> Config Class Initialized
INFO - 2024-10-29 08:13:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:19 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:19 --> URI Class Initialized
INFO - 2024-10-29 08:13:19 --> Router Class Initialized
INFO - 2024-10-29 08:13:19 --> Output Class Initialized
INFO - 2024-10-29 08:13:19 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:20 --> Input Class Initialized
INFO - 2024-10-29 08:13:20 --> Language Class Initialized
INFO - 2024-10-29 08:13:20 --> Loader Class Initialized
INFO - 2024-10-29 08:13:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:22 --> Upload Class Initialized
INFO - 2024-10-29 08:13:22 --> Email Class Initialized
INFO - 2024-10-29 08:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:22 --> Controller Class Initialized
INFO - 2024-10-29 13:43:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:22 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:24 --> Config Class Initialized
INFO - 2024-10-29 08:13:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:24 --> URI Class Initialized
INFO - 2024-10-29 08:13:24 --> Router Class Initialized
INFO - 2024-10-29 08:13:24 --> Output Class Initialized
INFO - 2024-10-29 08:13:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:25 --> Input Class Initialized
INFO - 2024-10-29 08:13:25 --> Language Class Initialized
INFO - 2024-10-29 08:13:25 --> Loader Class Initialized
INFO - 2024-10-29 08:13:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:27 --> Upload Class Initialized
INFO - 2024-10-29 08:13:27 --> Email Class Initialized
INFO - 2024-10-29 08:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:27 --> Controller Class Initialized
INFO - 2024-10-29 13:43:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:27 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:29 --> Config Class Initialized
INFO - 2024-10-29 08:13:29 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:29 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:29 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:29 --> URI Class Initialized
INFO - 2024-10-29 08:13:29 --> Router Class Initialized
INFO - 2024-10-29 08:13:29 --> Output Class Initialized
INFO - 2024-10-29 08:13:29 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:29 --> Input Class Initialized
INFO - 2024-10-29 08:13:29 --> Language Class Initialized
INFO - 2024-10-29 08:13:29 --> Loader Class Initialized
INFO - 2024-10-29 08:13:29 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:29 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:32 --> Upload Class Initialized
INFO - 2024-10-29 08:13:32 --> Email Class Initialized
INFO - 2024-10-29 08:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:32 --> Controller Class Initialized
INFO - 2024-10-29 13:43:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:32 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:34 --> Config Class Initialized
INFO - 2024-10-29 08:13:34 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:34 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:34 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:34 --> URI Class Initialized
INFO - 2024-10-29 08:13:34 --> Router Class Initialized
INFO - 2024-10-29 08:13:35 --> Output Class Initialized
INFO - 2024-10-29 08:13:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:35 --> Input Class Initialized
INFO - 2024-10-29 08:13:35 --> Language Class Initialized
INFO - 2024-10-29 08:13:35 --> Loader Class Initialized
INFO - 2024-10-29 08:13:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:37 --> Upload Class Initialized
INFO - 2024-10-29 08:13:37 --> Email Class Initialized
INFO - 2024-10-29 08:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:37 --> Controller Class Initialized
INFO - 2024-10-29 13:43:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:37 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:39 --> Config Class Initialized
INFO - 2024-10-29 08:13:39 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:39 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:39 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:39 --> URI Class Initialized
INFO - 2024-10-29 08:13:39 --> Router Class Initialized
INFO - 2024-10-29 08:13:39 --> Output Class Initialized
INFO - 2024-10-29 08:13:39 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:39 --> Input Class Initialized
INFO - 2024-10-29 08:13:39 --> Language Class Initialized
INFO - 2024-10-29 08:13:39 --> Loader Class Initialized
INFO - 2024-10-29 08:13:39 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:39 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:39 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:39 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:42 --> Upload Class Initialized
INFO - 2024-10-29 08:13:42 --> Email Class Initialized
INFO - 2024-10-29 08:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:42 --> Controller Class Initialized
INFO - 2024-10-29 13:43:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:42 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:44 --> Config Class Initialized
INFO - 2024-10-29 08:13:44 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:44 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:44 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:44 --> URI Class Initialized
INFO - 2024-10-29 08:13:44 --> Router Class Initialized
INFO - 2024-10-29 08:13:44 --> Output Class Initialized
INFO - 2024-10-29 08:13:44 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:44 --> Input Class Initialized
INFO - 2024-10-29 08:13:45 --> Language Class Initialized
INFO - 2024-10-29 08:13:45 --> Loader Class Initialized
INFO - 2024-10-29 08:13:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:47 --> Upload Class Initialized
INFO - 2024-10-29 08:13:47 --> Email Class Initialized
INFO - 2024-10-29 08:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:47 --> Controller Class Initialized
INFO - 2024-10-29 13:43:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:47 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:49 --> Config Class Initialized
INFO - 2024-10-29 08:13:49 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:49 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:49 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:49 --> URI Class Initialized
INFO - 2024-10-29 08:13:49 --> Router Class Initialized
INFO - 2024-10-29 08:13:49 --> Output Class Initialized
INFO - 2024-10-29 08:13:49 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:50 --> Input Class Initialized
INFO - 2024-10-29 08:13:50 --> Language Class Initialized
INFO - 2024-10-29 08:13:50 --> Loader Class Initialized
INFO - 2024-10-29 08:13:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:52 --> Upload Class Initialized
INFO - 2024-10-29 08:13:52 --> Email Class Initialized
INFO - 2024-10-29 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:52 --> Controller Class Initialized
INFO - 2024-10-29 13:43:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:52 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:54 --> Config Class Initialized
INFO - 2024-10-29 08:13:54 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:54 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:54 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:54 --> URI Class Initialized
INFO - 2024-10-29 08:13:54 --> Router Class Initialized
INFO - 2024-10-29 08:13:54 --> Output Class Initialized
INFO - 2024-10-29 08:13:54 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:54 --> Input Class Initialized
INFO - 2024-10-29 08:13:54 --> Language Class Initialized
INFO - 2024-10-29 08:13:54 --> Loader Class Initialized
INFO - 2024-10-29 08:13:54 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:54 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:54 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:13:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:13:57 --> Upload Class Initialized
INFO - 2024-10-29 08:13:57 --> Email Class Initialized
INFO - 2024-10-29 08:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:13:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:13:57 --> Controller Class Initialized
INFO - 2024-10-29 13:43:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:43:57 --> Model "MainModel" initialized
INFO - 2024-10-29 13:43:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:43:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:13:59 --> Config Class Initialized
INFO - 2024-10-29 08:13:59 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:13:59 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:13:59 --> Utf8 Class Initialized
INFO - 2024-10-29 08:13:59 --> URI Class Initialized
INFO - 2024-10-29 08:13:59 --> Router Class Initialized
INFO - 2024-10-29 08:13:59 --> Output Class Initialized
INFO - 2024-10-29 08:13:59 --> Security Class Initialized
DEBUG - 2024-10-29 08:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:13:59 --> Input Class Initialized
INFO - 2024-10-29 08:13:59 --> Language Class Initialized
INFO - 2024-10-29 08:13:59 --> Loader Class Initialized
INFO - 2024-10-29 08:13:59 --> Helper loaded: url_helper
INFO - 2024-10-29 08:13:59 --> Helper loaded: html_helper
INFO - 2024-10-29 08:13:59 --> Helper loaded: file_helper
INFO - 2024-10-29 08:13:59 --> Helper loaded: string_helper
INFO - 2024-10-29 08:13:59 --> Helper loaded: form_helper
INFO - 2024-10-29 08:13:59 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:02 --> Upload Class Initialized
INFO - 2024-10-29 08:14:02 --> Email Class Initialized
INFO - 2024-10-29 08:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:02 --> Controller Class Initialized
INFO - 2024-10-29 13:44:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:02 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:04 --> Config Class Initialized
INFO - 2024-10-29 08:14:04 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:04 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:04 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:04 --> URI Class Initialized
INFO - 2024-10-29 08:14:04 --> Router Class Initialized
INFO - 2024-10-29 08:14:04 --> Output Class Initialized
INFO - 2024-10-29 08:14:04 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:04 --> Input Class Initialized
INFO - 2024-10-29 08:14:04 --> Language Class Initialized
INFO - 2024-10-29 08:14:04 --> Loader Class Initialized
INFO - 2024-10-29 08:14:04 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:04 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:07 --> Upload Class Initialized
INFO - 2024-10-29 08:14:07 --> Email Class Initialized
INFO - 2024-10-29 08:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:07 --> Controller Class Initialized
INFO - 2024-10-29 13:44:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:07 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:09 --> Config Class Initialized
INFO - 2024-10-29 08:14:09 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:09 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:09 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:09 --> URI Class Initialized
INFO - 2024-10-29 08:14:09 --> Router Class Initialized
INFO - 2024-10-29 08:14:09 --> Output Class Initialized
INFO - 2024-10-29 08:14:09 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:10 --> Input Class Initialized
INFO - 2024-10-29 08:14:10 --> Language Class Initialized
INFO - 2024-10-29 08:14:10 --> Loader Class Initialized
INFO - 2024-10-29 08:14:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:12 --> Upload Class Initialized
INFO - 2024-10-29 08:14:12 --> Email Class Initialized
INFO - 2024-10-29 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:12 --> Controller Class Initialized
INFO - 2024-10-29 13:44:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:12 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:14 --> Config Class Initialized
INFO - 2024-10-29 08:14:14 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:14 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:14 --> URI Class Initialized
INFO - 2024-10-29 08:14:14 --> Router Class Initialized
INFO - 2024-10-29 08:14:14 --> Output Class Initialized
INFO - 2024-10-29 08:14:14 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:14 --> Input Class Initialized
INFO - 2024-10-29 08:14:14 --> Language Class Initialized
INFO - 2024-10-29 08:14:14 --> Loader Class Initialized
INFO - 2024-10-29 08:14:14 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:14 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:17 --> Upload Class Initialized
INFO - 2024-10-29 08:14:17 --> Email Class Initialized
INFO - 2024-10-29 08:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:17 --> Controller Class Initialized
INFO - 2024-10-29 13:44:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:17 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:19 --> Config Class Initialized
INFO - 2024-10-29 08:14:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:19 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:19 --> URI Class Initialized
INFO - 2024-10-29 08:14:19 --> Router Class Initialized
INFO - 2024-10-29 08:14:19 --> Output Class Initialized
INFO - 2024-10-29 08:14:19 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:19 --> Input Class Initialized
INFO - 2024-10-29 08:14:19 --> Language Class Initialized
INFO - 2024-10-29 08:14:20 --> Loader Class Initialized
INFO - 2024-10-29 08:14:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:22 --> Upload Class Initialized
INFO - 2024-10-29 08:14:22 --> Email Class Initialized
INFO - 2024-10-29 08:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:22 --> Controller Class Initialized
INFO - 2024-10-29 13:44:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:22 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:24 --> Config Class Initialized
INFO - 2024-10-29 08:14:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:24 --> URI Class Initialized
INFO - 2024-10-29 08:14:24 --> Router Class Initialized
INFO - 2024-10-29 08:14:24 --> Output Class Initialized
INFO - 2024-10-29 08:14:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:24 --> Input Class Initialized
INFO - 2024-10-29 08:14:24 --> Language Class Initialized
INFO - 2024-10-29 08:14:25 --> Loader Class Initialized
INFO - 2024-10-29 08:14:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:27 --> Upload Class Initialized
INFO - 2024-10-29 08:14:27 --> Email Class Initialized
INFO - 2024-10-29 08:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:27 --> Controller Class Initialized
INFO - 2024-10-29 13:44:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:27 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:29 --> Config Class Initialized
INFO - 2024-10-29 08:14:29 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:29 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:29 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:29 --> URI Class Initialized
INFO - 2024-10-29 08:14:29 --> Router Class Initialized
INFO - 2024-10-29 08:14:29 --> Output Class Initialized
INFO - 2024-10-29 08:14:29 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:30 --> Input Class Initialized
INFO - 2024-10-29 08:14:30 --> Language Class Initialized
INFO - 2024-10-29 08:14:30 --> Loader Class Initialized
INFO - 2024-10-29 08:14:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:32 --> Upload Class Initialized
INFO - 2024-10-29 08:14:32 --> Email Class Initialized
INFO - 2024-10-29 08:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:32 --> Controller Class Initialized
INFO - 2024-10-29 13:44:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:32 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:34 --> Config Class Initialized
INFO - 2024-10-29 08:14:34 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:34 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:34 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:34 --> URI Class Initialized
INFO - 2024-10-29 08:14:34 --> Router Class Initialized
INFO - 2024-10-29 08:14:34 --> Output Class Initialized
INFO - 2024-10-29 08:14:34 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:34 --> Input Class Initialized
INFO - 2024-10-29 08:14:34 --> Language Class Initialized
INFO - 2024-10-29 08:14:35 --> Loader Class Initialized
INFO - 2024-10-29 08:14:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:37 --> Upload Class Initialized
INFO - 2024-10-29 08:14:37 --> Email Class Initialized
INFO - 2024-10-29 08:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:37 --> Controller Class Initialized
INFO - 2024-10-29 13:44:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:37 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:39 --> Config Class Initialized
INFO - 2024-10-29 08:14:39 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:39 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:39 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:39 --> URI Class Initialized
INFO - 2024-10-29 08:14:39 --> Router Class Initialized
INFO - 2024-10-29 08:14:39 --> Output Class Initialized
INFO - 2024-10-29 08:14:39 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:39 --> Input Class Initialized
INFO - 2024-10-29 08:14:39 --> Language Class Initialized
INFO - 2024-10-29 08:14:39 --> Loader Class Initialized
INFO - 2024-10-29 08:14:39 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:42 --> Upload Class Initialized
INFO - 2024-10-29 08:14:42 --> Email Class Initialized
INFO - 2024-10-29 08:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:42 --> Controller Class Initialized
INFO - 2024-10-29 13:44:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:42 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:44 --> Config Class Initialized
INFO - 2024-10-29 08:14:44 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:44 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:44 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:44 --> URI Class Initialized
INFO - 2024-10-29 08:14:44 --> Router Class Initialized
INFO - 2024-10-29 08:14:44 --> Output Class Initialized
INFO - 2024-10-29 08:14:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:45 --> Input Class Initialized
INFO - 2024-10-29 08:14:45 --> Language Class Initialized
INFO - 2024-10-29 08:14:45 --> Loader Class Initialized
INFO - 2024-10-29 08:14:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:47 --> Upload Class Initialized
INFO - 2024-10-29 08:14:47 --> Email Class Initialized
INFO - 2024-10-29 08:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:47 --> Controller Class Initialized
INFO - 2024-10-29 13:44:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:47 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:49 --> Config Class Initialized
INFO - 2024-10-29 08:14:49 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:49 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:49 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:49 --> URI Class Initialized
INFO - 2024-10-29 08:14:49 --> Router Class Initialized
INFO - 2024-10-29 08:14:49 --> Output Class Initialized
INFO - 2024-10-29 08:14:49 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:49 --> Input Class Initialized
INFO - 2024-10-29 08:14:49 --> Language Class Initialized
INFO - 2024-10-29 08:14:50 --> Loader Class Initialized
INFO - 2024-10-29 08:14:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:52 --> Upload Class Initialized
INFO - 2024-10-29 08:14:52 --> Email Class Initialized
INFO - 2024-10-29 08:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:52 --> Controller Class Initialized
INFO - 2024-10-29 13:44:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:52 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:54 --> Config Class Initialized
INFO - 2024-10-29 08:14:54 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:54 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:54 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:54 --> URI Class Initialized
INFO - 2024-10-29 08:14:54 --> Router Class Initialized
INFO - 2024-10-29 08:14:54 --> Output Class Initialized
INFO - 2024-10-29 08:14:54 --> Security Class Initialized
DEBUG - 2024-10-29 08:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:14:54 --> Input Class Initialized
INFO - 2024-10-29 08:14:54 --> Language Class Initialized
INFO - 2024-10-29 08:14:54 --> Loader Class Initialized
INFO - 2024-10-29 08:14:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:14:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:14:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:14:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:14:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:14:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:14:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:14:57 --> Upload Class Initialized
INFO - 2024-10-29 08:14:57 --> Email Class Initialized
INFO - 2024-10-29 08:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:14:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:14:57 --> Controller Class Initialized
INFO - 2024-10-29 13:44:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:44:57 --> Model "MainModel" initialized
INFO - 2024-10-29 13:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:44:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:14:59 --> Config Class Initialized
INFO - 2024-10-29 08:14:59 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:14:59 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:14:59 --> Utf8 Class Initialized
INFO - 2024-10-29 08:14:59 --> URI Class Initialized
INFO - 2024-10-29 08:14:59 --> Router Class Initialized
INFO - 2024-10-29 08:15:00 --> Output Class Initialized
INFO - 2024-10-29 08:15:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:00 --> Input Class Initialized
INFO - 2024-10-29 08:15:00 --> Language Class Initialized
INFO - 2024-10-29 08:15:00 --> Loader Class Initialized
INFO - 2024-10-29 08:15:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:02 --> Upload Class Initialized
INFO - 2024-10-29 08:15:02 --> Email Class Initialized
INFO - 2024-10-29 08:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:02 --> Controller Class Initialized
INFO - 2024-10-29 13:45:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:02 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:04 --> Config Class Initialized
INFO - 2024-10-29 08:15:04 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:04 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:04 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:04 --> URI Class Initialized
INFO - 2024-10-29 08:15:04 --> Router Class Initialized
INFO - 2024-10-29 08:15:04 --> Output Class Initialized
INFO - 2024-10-29 08:15:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:05 --> Input Class Initialized
INFO - 2024-10-29 08:15:05 --> Language Class Initialized
INFO - 2024-10-29 08:15:05 --> Loader Class Initialized
INFO - 2024-10-29 08:15:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:07 --> Upload Class Initialized
INFO - 2024-10-29 08:15:07 --> Email Class Initialized
INFO - 2024-10-29 08:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:07 --> Controller Class Initialized
INFO - 2024-10-29 13:45:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:07 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:09 --> Config Class Initialized
INFO - 2024-10-29 08:15:09 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:09 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:09 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:09 --> URI Class Initialized
INFO - 2024-10-29 08:15:09 --> Router Class Initialized
INFO - 2024-10-29 08:15:09 --> Output Class Initialized
INFO - 2024-10-29 08:15:09 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:09 --> Input Class Initialized
INFO - 2024-10-29 08:15:10 --> Language Class Initialized
INFO - 2024-10-29 08:15:10 --> Loader Class Initialized
INFO - 2024-10-29 08:15:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:12 --> Upload Class Initialized
INFO - 2024-10-29 08:15:12 --> Email Class Initialized
INFO - 2024-10-29 08:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:12 --> Controller Class Initialized
INFO - 2024-10-29 13:45:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:12 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:14 --> Config Class Initialized
INFO - 2024-10-29 08:15:14 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:14 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:14 --> URI Class Initialized
INFO - 2024-10-29 08:15:14 --> Router Class Initialized
INFO - 2024-10-29 08:15:14 --> Output Class Initialized
INFO - 2024-10-29 08:15:14 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:14 --> Input Class Initialized
INFO - 2024-10-29 08:15:14 --> Language Class Initialized
INFO - 2024-10-29 08:15:14 --> Loader Class Initialized
INFO - 2024-10-29 08:15:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:17 --> Upload Class Initialized
INFO - 2024-10-29 08:15:17 --> Email Class Initialized
INFO - 2024-10-29 08:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:17 --> Controller Class Initialized
INFO - 2024-10-29 13:45:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:17 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:19 --> Config Class Initialized
INFO - 2024-10-29 08:15:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:19 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:19 --> URI Class Initialized
INFO - 2024-10-29 08:15:19 --> Router Class Initialized
INFO - 2024-10-29 08:15:19 --> Output Class Initialized
INFO - 2024-10-29 08:15:19 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:19 --> Input Class Initialized
INFO - 2024-10-29 08:15:19 --> Language Class Initialized
INFO - 2024-10-29 08:15:20 --> Loader Class Initialized
INFO - 2024-10-29 08:15:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:22 --> Upload Class Initialized
INFO - 2024-10-29 08:15:22 --> Email Class Initialized
INFO - 2024-10-29 08:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:22 --> Controller Class Initialized
INFO - 2024-10-29 13:45:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:22 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:24 --> Config Class Initialized
INFO - 2024-10-29 08:15:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:24 --> URI Class Initialized
INFO - 2024-10-29 08:15:24 --> Router Class Initialized
INFO - 2024-10-29 08:15:24 --> Output Class Initialized
INFO - 2024-10-29 08:15:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:25 --> Input Class Initialized
INFO - 2024-10-29 08:15:25 --> Language Class Initialized
INFO - 2024-10-29 08:15:25 --> Loader Class Initialized
INFO - 2024-10-29 08:15:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:27 --> Upload Class Initialized
INFO - 2024-10-29 08:15:27 --> Email Class Initialized
INFO - 2024-10-29 08:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:27 --> Controller Class Initialized
INFO - 2024-10-29 13:45:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:27 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:29 --> Config Class Initialized
INFO - 2024-10-29 08:15:29 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:29 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:29 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:29 --> URI Class Initialized
INFO - 2024-10-29 08:15:29 --> Router Class Initialized
INFO - 2024-10-29 08:15:29 --> Output Class Initialized
INFO - 2024-10-29 08:15:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:30 --> Input Class Initialized
INFO - 2024-10-29 08:15:30 --> Language Class Initialized
INFO - 2024-10-29 08:15:30 --> Loader Class Initialized
INFO - 2024-10-29 08:15:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:32 --> Upload Class Initialized
INFO - 2024-10-29 08:15:32 --> Email Class Initialized
INFO - 2024-10-29 08:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:32 --> Controller Class Initialized
INFO - 2024-10-29 13:45:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:32 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:34 --> Config Class Initialized
INFO - 2024-10-29 08:15:34 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:34 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:34 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:34 --> URI Class Initialized
INFO - 2024-10-29 08:15:34 --> Router Class Initialized
INFO - 2024-10-29 08:15:34 --> Output Class Initialized
INFO - 2024-10-29 08:15:34 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:34 --> Input Class Initialized
INFO - 2024-10-29 08:15:34 --> Language Class Initialized
INFO - 2024-10-29 08:15:35 --> Loader Class Initialized
INFO - 2024-10-29 08:15:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:37 --> Upload Class Initialized
INFO - 2024-10-29 08:15:37 --> Email Class Initialized
INFO - 2024-10-29 08:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:37 --> Controller Class Initialized
INFO - 2024-10-29 13:45:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:37 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:39 --> Config Class Initialized
INFO - 2024-10-29 08:15:39 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:39 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:39 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:39 --> URI Class Initialized
INFO - 2024-10-29 08:15:39 --> Router Class Initialized
INFO - 2024-10-29 08:15:39 --> Output Class Initialized
INFO - 2024-10-29 08:15:39 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:40 --> Input Class Initialized
INFO - 2024-10-29 08:15:40 --> Language Class Initialized
INFO - 2024-10-29 08:15:40 --> Loader Class Initialized
INFO - 2024-10-29 08:15:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:42 --> Upload Class Initialized
INFO - 2024-10-29 08:15:42 --> Email Class Initialized
INFO - 2024-10-29 08:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:42 --> Controller Class Initialized
INFO - 2024-10-29 13:45:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:42 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:44 --> Config Class Initialized
INFO - 2024-10-29 08:15:44 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:44 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:44 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:44 --> URI Class Initialized
INFO - 2024-10-29 08:15:44 --> Router Class Initialized
INFO - 2024-10-29 08:15:44 --> Output Class Initialized
INFO - 2024-10-29 08:15:44 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:44 --> Input Class Initialized
INFO - 2024-10-29 08:15:44 --> Language Class Initialized
INFO - 2024-10-29 08:15:44 --> Loader Class Initialized
INFO - 2024-10-29 08:15:44 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:44 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:44 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:44 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:44 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:47 --> Upload Class Initialized
INFO - 2024-10-29 08:15:47 --> Email Class Initialized
INFO - 2024-10-29 08:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:47 --> Controller Class Initialized
INFO - 2024-10-29 13:45:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:47 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:49 --> Config Class Initialized
INFO - 2024-10-29 08:15:49 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:49 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:49 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:49 --> URI Class Initialized
INFO - 2024-10-29 08:15:49 --> Router Class Initialized
INFO - 2024-10-29 08:15:49 --> Output Class Initialized
INFO - 2024-10-29 08:15:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:50 --> Input Class Initialized
INFO - 2024-10-29 08:15:50 --> Language Class Initialized
INFO - 2024-10-29 08:15:50 --> Loader Class Initialized
INFO - 2024-10-29 08:15:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:52 --> Upload Class Initialized
INFO - 2024-10-29 08:15:52 --> Email Class Initialized
INFO - 2024-10-29 08:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:52 --> Controller Class Initialized
INFO - 2024-10-29 13:45:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:52 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:54 --> Config Class Initialized
INFO - 2024-10-29 08:15:54 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:54 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:54 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:54 --> URI Class Initialized
INFO - 2024-10-29 08:15:55 --> Router Class Initialized
INFO - 2024-10-29 08:15:55 --> Output Class Initialized
INFO - 2024-10-29 08:15:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:55 --> Input Class Initialized
INFO - 2024-10-29 08:15:55 --> Language Class Initialized
INFO - 2024-10-29 08:15:55 --> Loader Class Initialized
INFO - 2024-10-29 08:15:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:15:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:15:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:15:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:15:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:15:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:15:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:15:57 --> Upload Class Initialized
INFO - 2024-10-29 08:15:57 --> Email Class Initialized
INFO - 2024-10-29 08:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:15:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:15:57 --> Controller Class Initialized
INFO - 2024-10-29 13:45:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:45:57 --> Model "MainModel" initialized
INFO - 2024-10-29 13:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:45:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:15:59 --> Config Class Initialized
INFO - 2024-10-29 08:15:59 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:15:59 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:15:59 --> Utf8 Class Initialized
INFO - 2024-10-29 08:15:59 --> URI Class Initialized
INFO - 2024-10-29 08:15:59 --> Router Class Initialized
INFO - 2024-10-29 08:15:59 --> Output Class Initialized
INFO - 2024-10-29 08:15:59 --> Security Class Initialized
DEBUG - 2024-10-29 08:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:15:59 --> Input Class Initialized
INFO - 2024-10-29 08:15:59 --> Language Class Initialized
INFO - 2024-10-29 08:16:00 --> Loader Class Initialized
INFO - 2024-10-29 08:16:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:16:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:16:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:16:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:16:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:16:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:16:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:16:02 --> Upload Class Initialized
INFO - 2024-10-29 08:16:02 --> Email Class Initialized
INFO - 2024-10-29 08:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:16:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:16:02 --> Controller Class Initialized
INFO - 2024-10-29 13:46:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:46:02 --> Model "MainModel" initialized
INFO - 2024-10-29 13:46:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:46:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:16:04 --> Config Class Initialized
INFO - 2024-10-29 08:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:16:04 --> Utf8 Class Initialized
INFO - 2024-10-29 08:16:04 --> URI Class Initialized
INFO - 2024-10-29 08:16:04 --> Router Class Initialized
INFO - 2024-10-29 08:16:04 --> Output Class Initialized
INFO - 2024-10-29 08:16:04 --> Security Class Initialized
DEBUG - 2024-10-29 08:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:16:04 --> Input Class Initialized
INFO - 2024-10-29 08:16:04 --> Language Class Initialized
INFO - 2024-10-29 08:16:04 --> Loader Class Initialized
INFO - 2024-10-29 08:16:04 --> Helper loaded: url_helper
INFO - 2024-10-29 08:16:04 --> Helper loaded: html_helper
INFO - 2024-10-29 08:16:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:16:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:16:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:16:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:16:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:16:07 --> Upload Class Initialized
INFO - 2024-10-29 08:16:07 --> Email Class Initialized
INFO - 2024-10-29 08:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:16:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:16:07 --> Controller Class Initialized
INFO - 2024-10-29 13:46:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:46:07 --> Model "MainModel" initialized
INFO - 2024-10-29 13:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:46:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:16:09 --> Config Class Initialized
INFO - 2024-10-29 08:16:09 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:16:09 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:16:09 --> Utf8 Class Initialized
INFO - 2024-10-29 08:16:09 --> URI Class Initialized
INFO - 2024-10-29 08:16:09 --> Router Class Initialized
INFO - 2024-10-29 08:16:10 --> Output Class Initialized
INFO - 2024-10-29 08:16:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:16:10 --> Input Class Initialized
INFO - 2024-10-29 08:16:10 --> Language Class Initialized
INFO - 2024-10-29 08:16:10 --> Loader Class Initialized
INFO - 2024-10-29 08:16:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:16:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:16:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:16:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:16:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:16:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:16:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:16:12 --> Upload Class Initialized
INFO - 2024-10-29 08:16:12 --> Email Class Initialized
INFO - 2024-10-29 08:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:16:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:16:12 --> Controller Class Initialized
INFO - 2024-10-29 13:46:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:46:12 --> Model "MainModel" initialized
INFO - 2024-10-29 13:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:46:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:16:14 --> Config Class Initialized
INFO - 2024-10-29 08:16:14 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:16:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:16:14 --> Utf8 Class Initialized
INFO - 2024-10-29 08:16:14 --> URI Class Initialized
INFO - 2024-10-29 08:16:15 --> Router Class Initialized
INFO - 2024-10-29 08:16:15 --> Output Class Initialized
INFO - 2024-10-29 08:16:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:16:15 --> Input Class Initialized
INFO - 2024-10-29 08:16:15 --> Language Class Initialized
INFO - 2024-10-29 08:16:15 --> Loader Class Initialized
INFO - 2024-10-29 08:16:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:16:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:16:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:16:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:16:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:16:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:16:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:16:17 --> Upload Class Initialized
INFO - 2024-10-29 08:16:17 --> Email Class Initialized
INFO - 2024-10-29 08:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:16:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:16:17 --> Controller Class Initialized
INFO - 2024-10-29 13:46:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:46:17 --> Model "MainModel" initialized
INFO - 2024-10-29 13:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:46:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:16:19 --> Config Class Initialized
INFO - 2024-10-29 08:16:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:16:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:16:19 --> Utf8 Class Initialized
INFO - 2024-10-29 08:16:19 --> URI Class Initialized
INFO - 2024-10-29 08:16:19 --> Router Class Initialized
INFO - 2024-10-29 08:16:19 --> Output Class Initialized
INFO - 2024-10-29 08:16:19 --> Security Class Initialized
DEBUG - 2024-10-29 08:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:16:19 --> Input Class Initialized
INFO - 2024-10-29 08:16:20 --> Language Class Initialized
INFO - 2024-10-29 08:16:20 --> Loader Class Initialized
INFO - 2024-10-29 08:16:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:16:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:16:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:16:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:16:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:16:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:16:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:16:22 --> Upload Class Initialized
INFO - 2024-10-29 08:16:22 --> Email Class Initialized
INFO - 2024-10-29 08:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:16:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:16:22 --> Controller Class Initialized
INFO - 2024-10-29 13:46:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:46:22 --> Model "MainModel" initialized
INFO - 2024-10-29 13:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:46:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:16:24 --> Config Class Initialized
INFO - 2024-10-29 08:16:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:16:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:16:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:16:24 --> URI Class Initialized
INFO - 2024-10-29 08:16:24 --> Router Class Initialized
INFO - 2024-10-29 08:16:24 --> Output Class Initialized
INFO - 2024-10-29 08:16:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:16:24 --> Input Class Initialized
INFO - 2024-10-29 08:16:24 --> Language Class Initialized
INFO - 2024-10-29 08:16:24 --> Loader Class Initialized
INFO - 2024-10-29 08:16:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:16:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:16:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:16:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:16:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:16:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:16:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:16:27 --> Upload Class Initialized
INFO - 2024-10-29 08:16:27 --> Email Class Initialized
INFO - 2024-10-29 08:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:16:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:16:27 --> Controller Class Initialized
INFO - 2024-10-29 13:46:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:46:27 --> Model "MainModel" initialized
INFO - 2024-10-29 13:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:46:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:16:29 --> Config Class Initialized
INFO - 2024-10-29 08:16:29 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:16:29 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:16:29 --> Utf8 Class Initialized
INFO - 2024-10-29 08:16:29 --> URI Class Initialized
INFO - 2024-10-29 08:16:30 --> Router Class Initialized
INFO - 2024-10-29 08:16:30 --> Output Class Initialized
INFO - 2024-10-29 08:16:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:16:30 --> Input Class Initialized
INFO - 2024-10-29 08:16:30 --> Language Class Initialized
INFO - 2024-10-29 08:16:30 --> Loader Class Initialized
INFO - 2024-10-29 08:16:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:16:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:16:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:16:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:16:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:16:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:16:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:16:32 --> Upload Class Initialized
INFO - 2024-10-29 08:16:32 --> Email Class Initialized
INFO - 2024-10-29 08:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:16:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:16:32 --> Controller Class Initialized
INFO - 2024-10-29 13:46:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:46:32 --> Model "MainModel" initialized
INFO - 2024-10-29 13:46:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:46:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:17:24 --> Config Class Initialized
INFO - 2024-10-29 08:17:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:17:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:17:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:17:24 --> URI Class Initialized
INFO - 2024-10-29 08:17:24 --> Router Class Initialized
INFO - 2024-10-29 08:17:24 --> Output Class Initialized
INFO - 2024-10-29 08:17:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:17:24 --> Input Class Initialized
INFO - 2024-10-29 08:17:24 --> Language Class Initialized
INFO - 2024-10-29 08:17:24 --> Loader Class Initialized
INFO - 2024-10-29 08:17:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:17:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:17:24 --> Helper loaded: file_helper
INFO - 2024-10-29 08:17:24 --> Helper loaded: string_helper
INFO - 2024-10-29 08:17:24 --> Helper loaded: form_helper
INFO - 2024-10-29 08:17:24 --> Helper loaded: my_helper
INFO - 2024-10-29 08:17:24 --> Database Driver Class Initialized
INFO - 2024-10-29 08:17:26 --> Upload Class Initialized
INFO - 2024-10-29 08:17:26 --> Email Class Initialized
INFO - 2024-10-29 08:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:17:26 --> Form Validation Class Initialized
INFO - 2024-10-29 08:17:26 --> Controller Class Initialized
INFO - 2024-10-29 13:47:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:47:26 --> Model "MainModel" initialized
INFO - 2024-10-29 13:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:47:26 --> Pagination Class Initialized
INFO - 2024-10-29 08:18:24 --> Config Class Initialized
INFO - 2024-10-29 08:18:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:18:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:18:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:18:24 --> URI Class Initialized
INFO - 2024-10-29 08:18:24 --> Router Class Initialized
INFO - 2024-10-29 08:18:24 --> Output Class Initialized
INFO - 2024-10-29 08:18:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:18:24 --> Input Class Initialized
INFO - 2024-10-29 08:18:24 --> Language Class Initialized
INFO - 2024-10-29 08:18:24 --> Loader Class Initialized
INFO - 2024-10-29 08:18:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:18:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:18:24 --> Helper loaded: file_helper
INFO - 2024-10-29 08:18:24 --> Helper loaded: string_helper
INFO - 2024-10-29 08:18:24 --> Helper loaded: form_helper
INFO - 2024-10-29 08:18:24 --> Helper loaded: my_helper
INFO - 2024-10-29 08:18:24 --> Database Driver Class Initialized
INFO - 2024-10-29 08:18:26 --> Upload Class Initialized
INFO - 2024-10-29 08:18:26 --> Email Class Initialized
INFO - 2024-10-29 08:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:18:26 --> Form Validation Class Initialized
INFO - 2024-10-29 08:18:26 --> Controller Class Initialized
INFO - 2024-10-29 13:48:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:48:26 --> Model "MainModel" initialized
INFO - 2024-10-29 13:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:48:26 --> Pagination Class Initialized
INFO - 2024-10-29 08:19:24 --> Config Class Initialized
INFO - 2024-10-29 08:19:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:19:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:19:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:19:24 --> URI Class Initialized
INFO - 2024-10-29 08:19:24 --> Router Class Initialized
INFO - 2024-10-29 08:19:24 --> Output Class Initialized
INFO - 2024-10-29 08:19:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:19:24 --> Input Class Initialized
INFO - 2024-10-29 08:19:24 --> Language Class Initialized
INFO - 2024-10-29 08:19:24 --> Loader Class Initialized
INFO - 2024-10-29 08:19:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:19:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:19:24 --> Helper loaded: file_helper
INFO - 2024-10-29 08:19:24 --> Helper loaded: string_helper
INFO - 2024-10-29 08:19:24 --> Helper loaded: form_helper
INFO - 2024-10-29 08:19:24 --> Helper loaded: my_helper
INFO - 2024-10-29 08:19:24 --> Database Driver Class Initialized
INFO - 2024-10-29 08:19:26 --> Upload Class Initialized
INFO - 2024-10-29 08:19:26 --> Email Class Initialized
INFO - 2024-10-29 08:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:19:26 --> Form Validation Class Initialized
INFO - 2024-10-29 08:19:26 --> Controller Class Initialized
INFO - 2024-10-29 13:49:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:49:26 --> Model "MainModel" initialized
INFO - 2024-10-29 13:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:49:26 --> Pagination Class Initialized
INFO - 2024-10-29 08:20:24 --> Config Class Initialized
INFO - 2024-10-29 08:20:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:20:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:20:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:20:24 --> URI Class Initialized
INFO - 2024-10-29 08:20:24 --> Router Class Initialized
INFO - 2024-10-29 08:20:24 --> Output Class Initialized
INFO - 2024-10-29 08:20:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:20:24 --> Input Class Initialized
INFO - 2024-10-29 08:20:24 --> Language Class Initialized
INFO - 2024-10-29 08:20:24 --> Loader Class Initialized
INFO - 2024-10-29 08:20:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:20:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:20:24 --> Helper loaded: file_helper
INFO - 2024-10-29 08:20:24 --> Helper loaded: string_helper
INFO - 2024-10-29 08:20:24 --> Helper loaded: form_helper
INFO - 2024-10-29 08:20:24 --> Helper loaded: my_helper
INFO - 2024-10-29 08:20:24 --> Database Driver Class Initialized
INFO - 2024-10-29 08:20:26 --> Upload Class Initialized
INFO - 2024-10-29 08:20:26 --> Email Class Initialized
INFO - 2024-10-29 08:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:20:26 --> Form Validation Class Initialized
INFO - 2024-10-29 08:20:26 --> Controller Class Initialized
INFO - 2024-10-29 13:50:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:50:26 --> Model "MainModel" initialized
INFO - 2024-10-29 13:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:50:26 --> Pagination Class Initialized
INFO - 2024-10-29 08:21:24 --> Config Class Initialized
INFO - 2024-10-29 08:21:24 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:21:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:21:24 --> Utf8 Class Initialized
INFO - 2024-10-29 08:21:24 --> URI Class Initialized
INFO - 2024-10-29 08:21:24 --> Router Class Initialized
INFO - 2024-10-29 08:21:24 --> Output Class Initialized
INFO - 2024-10-29 08:21:24 --> Security Class Initialized
DEBUG - 2024-10-29 08:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:21:24 --> Input Class Initialized
INFO - 2024-10-29 08:21:24 --> Language Class Initialized
INFO - 2024-10-29 08:21:24 --> Loader Class Initialized
INFO - 2024-10-29 08:21:24 --> Helper loaded: url_helper
INFO - 2024-10-29 08:21:24 --> Helper loaded: html_helper
INFO - 2024-10-29 08:21:24 --> Helper loaded: file_helper
INFO - 2024-10-29 08:21:24 --> Helper loaded: string_helper
INFO - 2024-10-29 08:21:24 --> Helper loaded: form_helper
INFO - 2024-10-29 08:21:24 --> Helper loaded: my_helper
INFO - 2024-10-29 08:21:24 --> Database Driver Class Initialized
INFO - 2024-10-29 08:21:26 --> Upload Class Initialized
INFO - 2024-10-29 08:21:26 --> Email Class Initialized
INFO - 2024-10-29 08:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:21:26 --> Form Validation Class Initialized
INFO - 2024-10-29 08:21:26 --> Controller Class Initialized
INFO - 2024-10-29 13:51:26 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:51:26 --> Model "MainModel" initialized
INFO - 2024-10-29 13:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:51:26 --> Pagination Class Initialized
INFO - 2024-10-29 08:24:32 --> Config Class Initialized
INFO - 2024-10-29 08:24:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:24:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:24:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:24:32 --> URI Class Initialized
INFO - 2024-10-29 08:24:32 --> Router Class Initialized
INFO - 2024-10-29 08:24:32 --> Output Class Initialized
INFO - 2024-10-29 08:24:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:24:32 --> Input Class Initialized
INFO - 2024-10-29 08:24:32 --> Language Class Initialized
INFO - 2024-10-29 08:24:32 --> Loader Class Initialized
INFO - 2024-10-29 08:24:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:24:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:24:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:24:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:24:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:24:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:24:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:24:34 --> Upload Class Initialized
INFO - 2024-10-29 08:24:34 --> Email Class Initialized
INFO - 2024-10-29 08:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:24:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:24:34 --> Controller Class Initialized
INFO - 2024-10-29 13:54:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:54:34 --> Model "MainModel" initialized
INFO - 2024-10-29 13:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:54:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:25:32 --> Config Class Initialized
INFO - 2024-10-29 08:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:25:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:25:32 --> URI Class Initialized
INFO - 2024-10-29 08:25:32 --> Router Class Initialized
INFO - 2024-10-29 08:25:32 --> Output Class Initialized
INFO - 2024-10-29 08:25:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:25:32 --> Input Class Initialized
INFO - 2024-10-29 08:25:32 --> Language Class Initialized
INFO - 2024-10-29 08:25:32 --> Loader Class Initialized
INFO - 2024-10-29 08:25:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:25:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:25:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:25:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:25:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:25:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:25:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:25:34 --> Upload Class Initialized
INFO - 2024-10-29 08:25:34 --> Email Class Initialized
INFO - 2024-10-29 08:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:25:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:25:34 --> Controller Class Initialized
INFO - 2024-10-29 13:55:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:55:34 --> Model "MainModel" initialized
INFO - 2024-10-29 13:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:55:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:26:32 --> Config Class Initialized
INFO - 2024-10-29 08:26:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:26:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:26:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:26:32 --> URI Class Initialized
INFO - 2024-10-29 08:26:32 --> Router Class Initialized
INFO - 2024-10-29 08:26:32 --> Output Class Initialized
INFO - 2024-10-29 08:26:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:26:32 --> Input Class Initialized
INFO - 2024-10-29 08:26:32 --> Language Class Initialized
INFO - 2024-10-29 08:26:32 --> Loader Class Initialized
INFO - 2024-10-29 08:26:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:26:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:26:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:26:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:26:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:26:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:26:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:26:34 --> Upload Class Initialized
INFO - 2024-10-29 08:26:34 --> Email Class Initialized
INFO - 2024-10-29 08:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:26:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:26:34 --> Controller Class Initialized
INFO - 2024-10-29 13:56:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:56:34 --> Model "MainModel" initialized
INFO - 2024-10-29 13:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:56:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:27:32 --> Config Class Initialized
INFO - 2024-10-29 08:27:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:27:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:27:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:27:32 --> URI Class Initialized
INFO - 2024-10-29 08:27:32 --> Router Class Initialized
INFO - 2024-10-29 08:27:32 --> Output Class Initialized
INFO - 2024-10-29 08:27:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:27:32 --> Input Class Initialized
INFO - 2024-10-29 08:27:32 --> Language Class Initialized
INFO - 2024-10-29 08:27:32 --> Loader Class Initialized
INFO - 2024-10-29 08:27:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:27:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:27:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:27:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:27:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:27:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:27:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:27:34 --> Upload Class Initialized
INFO - 2024-10-29 08:27:34 --> Email Class Initialized
INFO - 2024-10-29 08:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:27:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:27:34 --> Controller Class Initialized
INFO - 2024-10-29 13:57:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:57:34 --> Model "MainModel" initialized
INFO - 2024-10-29 13:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:57:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:28:32 --> Config Class Initialized
INFO - 2024-10-29 08:28:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:28:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:28:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:28:32 --> URI Class Initialized
INFO - 2024-10-29 08:28:32 --> Router Class Initialized
INFO - 2024-10-29 08:28:32 --> Output Class Initialized
INFO - 2024-10-29 08:28:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:28:32 --> Input Class Initialized
INFO - 2024-10-29 08:28:32 --> Language Class Initialized
INFO - 2024-10-29 08:28:32 --> Loader Class Initialized
INFO - 2024-10-29 08:28:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:28:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:28:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:28:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:28:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:28:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:28:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:28:34 --> Upload Class Initialized
INFO - 2024-10-29 08:28:34 --> Email Class Initialized
INFO - 2024-10-29 08:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:28:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:28:34 --> Controller Class Initialized
INFO - 2024-10-29 13:58:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:58:34 --> Model "MainModel" initialized
INFO - 2024-10-29 13:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:58:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:29:32 --> Config Class Initialized
INFO - 2024-10-29 08:29:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:29:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:29:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:29:32 --> URI Class Initialized
INFO - 2024-10-29 08:29:32 --> Router Class Initialized
INFO - 2024-10-29 08:29:32 --> Output Class Initialized
INFO - 2024-10-29 08:29:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:29:32 --> Input Class Initialized
INFO - 2024-10-29 08:29:32 --> Language Class Initialized
INFO - 2024-10-29 08:29:32 --> Loader Class Initialized
INFO - 2024-10-29 08:29:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:29:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:29:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:29:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:29:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:29:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:29:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:29:34 --> Upload Class Initialized
INFO - 2024-10-29 08:29:34 --> Email Class Initialized
INFO - 2024-10-29 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:29:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:29:34 --> Controller Class Initialized
INFO - 2024-10-29 13:59:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 13:59:34 --> Model "MainModel" initialized
INFO - 2024-10-29 13:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 13:59:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:30:32 --> Config Class Initialized
INFO - 2024-10-29 08:30:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:30:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:30:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:30:32 --> URI Class Initialized
INFO - 2024-10-29 08:30:32 --> Router Class Initialized
INFO - 2024-10-29 08:30:32 --> Output Class Initialized
INFO - 2024-10-29 08:30:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:30:32 --> Input Class Initialized
INFO - 2024-10-29 08:30:32 --> Language Class Initialized
INFO - 2024-10-29 08:30:32 --> Loader Class Initialized
INFO - 2024-10-29 08:30:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:30:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:30:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:30:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:30:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:30:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:30:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:30:34 --> Upload Class Initialized
INFO - 2024-10-29 08:30:34 --> Email Class Initialized
INFO - 2024-10-29 08:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:30:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:30:34 --> Controller Class Initialized
INFO - 2024-10-29 14:00:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:00:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:00:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:31:32 --> Config Class Initialized
INFO - 2024-10-29 08:31:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:31:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:31:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:31:32 --> URI Class Initialized
INFO - 2024-10-29 08:31:32 --> Router Class Initialized
INFO - 2024-10-29 08:31:32 --> Output Class Initialized
INFO - 2024-10-29 08:31:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:31:32 --> Input Class Initialized
INFO - 2024-10-29 08:31:32 --> Language Class Initialized
INFO - 2024-10-29 08:31:32 --> Loader Class Initialized
INFO - 2024-10-29 08:31:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:31:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:31:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:31:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:31:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:31:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:31:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:31:34 --> Upload Class Initialized
INFO - 2024-10-29 08:31:34 --> Email Class Initialized
INFO - 2024-10-29 08:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:31:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:31:34 --> Controller Class Initialized
INFO - 2024-10-29 14:01:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:01:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:01:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:31:56 --> Config Class Initialized
INFO - 2024-10-29 08:31:56 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:31:56 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:31:56 --> Utf8 Class Initialized
INFO - 2024-10-29 08:31:56 --> URI Class Initialized
INFO - 2024-10-29 08:31:56 --> Router Class Initialized
INFO - 2024-10-29 08:31:56 --> Output Class Initialized
INFO - 2024-10-29 08:31:56 --> Security Class Initialized
DEBUG - 2024-10-29 08:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:31:56 --> Input Class Initialized
INFO - 2024-10-29 08:31:56 --> Language Class Initialized
INFO - 2024-10-29 08:31:56 --> Loader Class Initialized
INFO - 2024-10-29 08:31:56 --> Helper loaded: url_helper
INFO - 2024-10-29 08:31:56 --> Helper loaded: html_helper
INFO - 2024-10-29 08:31:56 --> Helper loaded: file_helper
INFO - 2024-10-29 08:31:56 --> Helper loaded: string_helper
INFO - 2024-10-29 08:31:56 --> Helper loaded: form_helper
INFO - 2024-10-29 08:31:56 --> Helper loaded: my_helper
INFO - 2024-10-29 08:31:56 --> Database Driver Class Initialized
INFO - 2024-10-29 08:31:58 --> Config Class Initialized
INFO - 2024-10-29 08:31:58 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:31:58 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:31:58 --> Utf8 Class Initialized
INFO - 2024-10-29 08:31:58 --> URI Class Initialized
INFO - 2024-10-29 08:31:58 --> Router Class Initialized
INFO - 2024-10-29 08:31:58 --> Output Class Initialized
INFO - 2024-10-29 08:31:58 --> Security Class Initialized
DEBUG - 2024-10-29 08:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:31:58 --> Input Class Initialized
INFO - 2024-10-29 08:31:58 --> Language Class Initialized
INFO - 2024-10-29 08:31:58 --> Loader Class Initialized
INFO - 2024-10-29 08:31:58 --> Helper loaded: url_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: html_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: file_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: string_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: form_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: my_helper
INFO - 2024-10-29 08:31:58 --> Database Driver Class Initialized
INFO - 2024-10-29 08:31:58 --> Upload Class Initialized
INFO - 2024-10-29 08:31:58 --> Email Class Initialized
INFO - 2024-10-29 08:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:31:58 --> Form Validation Class Initialized
INFO - 2024-10-29 08:31:58 --> Controller Class Initialized
INFO - 2024-10-29 14:01:58 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:01:58 --> Model "MainModel" initialized
INFO - 2024-10-29 14:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:01:58 --> Pagination Class Initialized
INFO - 2024-10-29 08:31:58 --> Config Class Initialized
INFO - 2024-10-29 08:31:58 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:31:58 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:31:58 --> Utf8 Class Initialized
INFO - 2024-10-29 08:31:58 --> URI Class Initialized
INFO - 2024-10-29 08:31:58 --> Router Class Initialized
INFO - 2024-10-29 08:31:58 --> Output Class Initialized
INFO - 2024-10-29 08:31:58 --> Security Class Initialized
DEBUG - 2024-10-29 08:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:31:58 --> Input Class Initialized
INFO - 2024-10-29 08:31:58 --> Language Class Initialized
INFO - 2024-10-29 08:31:58 --> Loader Class Initialized
INFO - 2024-10-29 08:31:58 --> Helper loaded: url_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: html_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: file_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: string_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: form_helper
INFO - 2024-10-29 08:31:58 --> Helper loaded: my_helper
INFO - 2024-10-29 08:31:58 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:00 --> Upload Class Initialized
INFO - 2024-10-29 08:32:00 --> Email Class Initialized
INFO - 2024-10-29 08:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:00 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:00 --> Controller Class Initialized
INFO - 2024-10-29 14:02:00 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 14:02:00 --> Helper loaded: notification_helper
INFO - 2024-10-29 14:02:00 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:02:00 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
INFO - 2024-10-29 14:02:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin/hotelLists.php
INFO - 2024-10-29 14:02:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-29 14:02:00 --> Final output sent to browser
DEBUG - 2024-10-29 14:02:00 --> Total execution time: 2.3912
INFO - 2024-10-29 08:32:00 --> Upload Class Initialized
INFO - 2024-10-29 08:32:00 --> Email Class Initialized
INFO - 2024-10-29 08:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:00 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:00 --> Controller Class Initialized
INFO - 2024-10-29 14:02:00 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:00 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:00 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:00 --> Config Class Initialized
INFO - 2024-10-29 08:32:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:00 --> URI Class Initialized
INFO - 2024-10-29 08:32:00 --> Router Class Initialized
INFO - 2024-10-29 08:32:00 --> Output Class Initialized
INFO - 2024-10-29 08:32:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:00 --> Input Class Initialized
INFO - 2024-10-29 08:32:00 --> Language Class Initialized
ERROR - 2024-10-29 08:32:01 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:32:01 --> Config Class Initialized
INFO - 2024-10-29 08:32:01 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:01 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:01 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:01 --> URI Class Initialized
INFO - 2024-10-29 08:32:01 --> Router Class Initialized
INFO - 2024-10-29 08:32:01 --> Output Class Initialized
INFO - 2024-10-29 08:32:01 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:01 --> Input Class Initialized
INFO - 2024-10-29 08:32:01 --> Language Class Initialized
ERROR - 2024-10-29 08:32:01 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:32:01 --> Config Class Initialized
INFO - 2024-10-29 08:32:01 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:01 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:01 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:01 --> URI Class Initialized
INFO - 2024-10-29 08:32:01 --> Router Class Initialized
INFO - 2024-10-29 08:32:01 --> Output Class Initialized
INFO - 2024-10-29 08:32:01 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:01 --> Input Class Initialized
INFO - 2024-10-29 08:32:01 --> Language Class Initialized
ERROR - 2024-10-29 08:32:01 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:32:05 --> Config Class Initialized
INFO - 2024-10-29 08:32:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:06 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:06 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:06 --> URI Class Initialized
INFO - 2024-10-29 08:32:06 --> Router Class Initialized
INFO - 2024-10-29 08:32:06 --> Output Class Initialized
INFO - 2024-10-29 08:32:06 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:06 --> Input Class Initialized
INFO - 2024-10-29 08:32:06 --> Language Class Initialized
INFO - 2024-10-29 08:32:06 --> Loader Class Initialized
INFO - 2024-10-29 08:32:06 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:06 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:06 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:06 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:06 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:06 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:06 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:08 --> Upload Class Initialized
INFO - 2024-10-29 08:32:08 --> Email Class Initialized
INFO - 2024-10-29 08:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:08 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:08 --> Controller Class Initialized
INFO - 2024-10-29 14:02:08 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:08 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:08 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:10 --> Config Class Initialized
INFO - 2024-10-29 08:32:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:11 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:11 --> URI Class Initialized
INFO - 2024-10-29 08:32:11 --> Router Class Initialized
INFO - 2024-10-29 08:32:11 --> Output Class Initialized
INFO - 2024-10-29 08:32:11 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:11 --> Input Class Initialized
INFO - 2024-10-29 08:32:11 --> Language Class Initialized
INFO - 2024-10-29 08:32:11 --> Loader Class Initialized
INFO - 2024-10-29 08:32:11 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:11 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:11 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:11 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:11 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:11 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:11 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:13 --> Upload Class Initialized
INFO - 2024-10-29 08:32:13 --> Email Class Initialized
INFO - 2024-10-29 08:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:13 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:13 --> Controller Class Initialized
INFO - 2024-10-29 14:02:13 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:13 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:13 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:15 --> Config Class Initialized
INFO - 2024-10-29 08:32:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:16 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:16 --> URI Class Initialized
INFO - 2024-10-29 08:32:16 --> Router Class Initialized
INFO - 2024-10-29 08:32:16 --> Output Class Initialized
INFO - 2024-10-29 08:32:16 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:16 --> Input Class Initialized
INFO - 2024-10-29 08:32:16 --> Language Class Initialized
INFO - 2024-10-29 08:32:16 --> Loader Class Initialized
INFO - 2024-10-29 08:32:16 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:16 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:16 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:16 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:16 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:16 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:16 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:18 --> Upload Class Initialized
INFO - 2024-10-29 08:32:18 --> Email Class Initialized
INFO - 2024-10-29 08:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:18 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:18 --> Controller Class Initialized
INFO - 2024-10-29 14:02:18 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:18 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:18 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:20 --> Config Class Initialized
INFO - 2024-10-29 08:32:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:21 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:21 --> URI Class Initialized
INFO - 2024-10-29 08:32:21 --> Router Class Initialized
INFO - 2024-10-29 08:32:21 --> Output Class Initialized
INFO - 2024-10-29 08:32:21 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:21 --> Input Class Initialized
INFO - 2024-10-29 08:32:21 --> Language Class Initialized
INFO - 2024-10-29 08:32:21 --> Loader Class Initialized
INFO - 2024-10-29 08:32:21 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:21 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:21 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:21 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:21 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:21 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:21 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:23 --> Upload Class Initialized
INFO - 2024-10-29 08:32:23 --> Email Class Initialized
INFO - 2024-10-29 08:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:23 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:23 --> Controller Class Initialized
INFO - 2024-10-29 14:02:23 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:23 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:23 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:25 --> Config Class Initialized
INFO - 2024-10-29 08:32:26 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:26 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:26 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:26 --> URI Class Initialized
INFO - 2024-10-29 08:32:26 --> Router Class Initialized
INFO - 2024-10-29 08:32:26 --> Output Class Initialized
INFO - 2024-10-29 08:32:26 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:26 --> Input Class Initialized
INFO - 2024-10-29 08:32:26 --> Language Class Initialized
INFO - 2024-10-29 08:32:26 --> Loader Class Initialized
INFO - 2024-10-29 08:32:26 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:26 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:26 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:26 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:26 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:26 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:26 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:28 --> Upload Class Initialized
INFO - 2024-10-29 08:32:28 --> Email Class Initialized
INFO - 2024-10-29 08:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:28 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:28 --> Controller Class Initialized
INFO - 2024-10-29 14:02:28 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:28 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:28 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:30 --> Config Class Initialized
INFO - 2024-10-29 08:32:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:31 --> URI Class Initialized
INFO - 2024-10-29 08:32:31 --> Router Class Initialized
INFO - 2024-10-29 08:32:31 --> Output Class Initialized
INFO - 2024-10-29 08:32:31 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:31 --> Input Class Initialized
INFO - 2024-10-29 08:32:31 --> Language Class Initialized
INFO - 2024-10-29 08:32:31 --> Loader Class Initialized
INFO - 2024-10-29 08:32:31 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:31 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:31 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:31 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:31 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:31 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:31 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:33 --> Upload Class Initialized
INFO - 2024-10-29 08:32:33 --> Email Class Initialized
INFO - 2024-10-29 08:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:33 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:33 --> Controller Class Initialized
INFO - 2024-10-29 14:02:33 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:33 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:33 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:35 --> Config Class Initialized
INFO - 2024-10-29 08:32:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:36 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:36 --> URI Class Initialized
INFO - 2024-10-29 08:32:36 --> Router Class Initialized
INFO - 2024-10-29 08:32:36 --> Output Class Initialized
INFO - 2024-10-29 08:32:36 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:36 --> Input Class Initialized
INFO - 2024-10-29 08:32:36 --> Language Class Initialized
INFO - 2024-10-29 08:32:36 --> Loader Class Initialized
INFO - 2024-10-29 08:32:36 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:36 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:36 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:36 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:36 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:36 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:36 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:38 --> Upload Class Initialized
INFO - 2024-10-29 08:32:38 --> Email Class Initialized
INFO - 2024-10-29 08:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:38 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:38 --> Controller Class Initialized
INFO - 2024-10-29 14:02:38 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:38 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:38 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:40 --> Config Class Initialized
INFO - 2024-10-29 08:32:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:41 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:41 --> URI Class Initialized
INFO - 2024-10-29 08:32:41 --> Router Class Initialized
INFO - 2024-10-29 08:32:41 --> Output Class Initialized
INFO - 2024-10-29 08:32:41 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:41 --> Input Class Initialized
INFO - 2024-10-29 08:32:41 --> Language Class Initialized
INFO - 2024-10-29 08:32:41 --> Loader Class Initialized
INFO - 2024-10-29 08:32:41 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:41 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:41 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:41 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:41 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:41 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:41 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:43 --> Upload Class Initialized
INFO - 2024-10-29 08:32:43 --> Email Class Initialized
INFO - 2024-10-29 08:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:43 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:43 --> Controller Class Initialized
INFO - 2024-10-29 14:02:43 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:43 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:43 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:45 --> Config Class Initialized
INFO - 2024-10-29 08:32:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:46 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:46 --> URI Class Initialized
INFO - 2024-10-29 08:32:46 --> Router Class Initialized
INFO - 2024-10-29 08:32:46 --> Output Class Initialized
INFO - 2024-10-29 08:32:46 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:46 --> Input Class Initialized
INFO - 2024-10-29 08:32:46 --> Language Class Initialized
INFO - 2024-10-29 08:32:46 --> Loader Class Initialized
INFO - 2024-10-29 08:32:46 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:46 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:46 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:46 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:46 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:46 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:46 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:48 --> Upload Class Initialized
INFO - 2024-10-29 08:32:48 --> Email Class Initialized
INFO - 2024-10-29 08:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:48 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:48 --> Controller Class Initialized
INFO - 2024-10-29 14:02:48 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:48 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:48 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:50 --> Config Class Initialized
INFO - 2024-10-29 08:32:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:51 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:51 --> URI Class Initialized
INFO - 2024-10-29 08:32:51 --> Router Class Initialized
INFO - 2024-10-29 08:32:51 --> Output Class Initialized
INFO - 2024-10-29 08:32:51 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:51 --> Input Class Initialized
INFO - 2024-10-29 08:32:51 --> Language Class Initialized
INFO - 2024-10-29 08:32:51 --> Loader Class Initialized
INFO - 2024-10-29 08:32:51 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:51 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:51 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:51 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:51 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:51 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:51 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:53 --> Upload Class Initialized
INFO - 2024-10-29 08:32:53 --> Email Class Initialized
INFO - 2024-10-29 08:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:53 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:53 --> Controller Class Initialized
INFO - 2024-10-29 14:02:53 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:53 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:53 --> Pagination Class Initialized
INFO - 2024-10-29 08:32:55 --> Config Class Initialized
INFO - 2024-10-29 08:32:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:32:56 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:32:56 --> Utf8 Class Initialized
INFO - 2024-10-29 08:32:56 --> URI Class Initialized
INFO - 2024-10-29 08:32:56 --> Router Class Initialized
INFO - 2024-10-29 08:32:56 --> Output Class Initialized
INFO - 2024-10-29 08:32:56 --> Security Class Initialized
DEBUG - 2024-10-29 08:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:32:56 --> Input Class Initialized
INFO - 2024-10-29 08:32:56 --> Language Class Initialized
INFO - 2024-10-29 08:32:56 --> Loader Class Initialized
INFO - 2024-10-29 08:32:56 --> Helper loaded: url_helper
INFO - 2024-10-29 08:32:56 --> Helper loaded: html_helper
INFO - 2024-10-29 08:32:56 --> Helper loaded: file_helper
INFO - 2024-10-29 08:32:56 --> Helper loaded: string_helper
INFO - 2024-10-29 08:32:56 --> Helper loaded: form_helper
INFO - 2024-10-29 08:32:56 --> Helper loaded: my_helper
INFO - 2024-10-29 08:32:56 --> Database Driver Class Initialized
INFO - 2024-10-29 08:32:58 --> Upload Class Initialized
INFO - 2024-10-29 08:32:58 --> Email Class Initialized
INFO - 2024-10-29 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:32:58 --> Form Validation Class Initialized
INFO - 2024-10-29 08:32:58 --> Controller Class Initialized
INFO - 2024-10-29 14:02:58 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:02:58 --> Model "MainModel" initialized
INFO - 2024-10-29 14:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:02:58 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:00 --> Config Class Initialized
INFO - 2024-10-29 08:33:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:01 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:01 --> URI Class Initialized
INFO - 2024-10-29 08:33:01 --> Router Class Initialized
INFO - 2024-10-29 08:33:01 --> Output Class Initialized
INFO - 2024-10-29 08:33:01 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:01 --> Input Class Initialized
INFO - 2024-10-29 08:33:01 --> Language Class Initialized
INFO - 2024-10-29 08:33:01 --> Loader Class Initialized
INFO - 2024-10-29 08:33:01 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:01 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:01 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:01 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:01 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:01 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:01 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:03 --> Upload Class Initialized
INFO - 2024-10-29 08:33:03 --> Email Class Initialized
INFO - 2024-10-29 08:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:03 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:03 --> Controller Class Initialized
INFO - 2024-10-29 14:03:03 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:03 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:03 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:05 --> Config Class Initialized
INFO - 2024-10-29 08:33:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:06 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:06 --> URI Class Initialized
INFO - 2024-10-29 08:33:06 --> Router Class Initialized
INFO - 2024-10-29 08:33:06 --> Output Class Initialized
INFO - 2024-10-29 08:33:06 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:06 --> Input Class Initialized
INFO - 2024-10-29 08:33:06 --> Language Class Initialized
INFO - 2024-10-29 08:33:06 --> Loader Class Initialized
INFO - 2024-10-29 08:33:06 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:06 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:06 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:06 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:06 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:06 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:06 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:08 --> Upload Class Initialized
INFO - 2024-10-29 08:33:08 --> Email Class Initialized
INFO - 2024-10-29 08:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:08 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:08 --> Controller Class Initialized
INFO - 2024-10-29 14:03:08 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:08 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:08 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:10 --> Config Class Initialized
INFO - 2024-10-29 08:33:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:11 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:11 --> URI Class Initialized
INFO - 2024-10-29 08:33:11 --> Router Class Initialized
INFO - 2024-10-29 08:33:11 --> Output Class Initialized
INFO - 2024-10-29 08:33:11 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:11 --> Input Class Initialized
INFO - 2024-10-29 08:33:11 --> Language Class Initialized
INFO - 2024-10-29 08:33:11 --> Loader Class Initialized
INFO - 2024-10-29 08:33:11 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:11 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:11 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:11 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:11 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:11 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:11 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:13 --> Upload Class Initialized
INFO - 2024-10-29 08:33:13 --> Email Class Initialized
INFO - 2024-10-29 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:13 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:13 --> Controller Class Initialized
INFO - 2024-10-29 14:03:13 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:13 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:13 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:15 --> Config Class Initialized
INFO - 2024-10-29 08:33:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:15 --> URI Class Initialized
INFO - 2024-10-29 08:33:16 --> Router Class Initialized
INFO - 2024-10-29 08:33:16 --> Output Class Initialized
INFO - 2024-10-29 08:33:16 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:16 --> Input Class Initialized
INFO - 2024-10-29 08:33:16 --> Language Class Initialized
INFO - 2024-10-29 08:33:16 --> Loader Class Initialized
INFO - 2024-10-29 08:33:16 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:16 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:16 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:16 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:16 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:16 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:16 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:18 --> Upload Class Initialized
INFO - 2024-10-29 08:33:18 --> Email Class Initialized
INFO - 2024-10-29 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:18 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:18 --> Controller Class Initialized
INFO - 2024-10-29 14:03:18 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:18 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:18 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:20 --> Config Class Initialized
INFO - 2024-10-29 08:33:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:21 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:21 --> URI Class Initialized
INFO - 2024-10-29 08:33:21 --> Router Class Initialized
INFO - 2024-10-29 08:33:21 --> Output Class Initialized
INFO - 2024-10-29 08:33:21 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:21 --> Input Class Initialized
INFO - 2024-10-29 08:33:21 --> Language Class Initialized
INFO - 2024-10-29 08:33:21 --> Loader Class Initialized
INFO - 2024-10-29 08:33:21 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:21 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:21 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:21 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:21 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:21 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:21 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:23 --> Upload Class Initialized
INFO - 2024-10-29 08:33:23 --> Email Class Initialized
INFO - 2024-10-29 08:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:23 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:23 --> Controller Class Initialized
INFO - 2024-10-29 14:03:23 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:23 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:23 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:25 --> Config Class Initialized
INFO - 2024-10-29 08:33:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:26 --> URI Class Initialized
INFO - 2024-10-29 08:33:26 --> Router Class Initialized
INFO - 2024-10-29 08:33:26 --> Output Class Initialized
INFO - 2024-10-29 08:33:26 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:26 --> Input Class Initialized
INFO - 2024-10-29 08:33:26 --> Language Class Initialized
INFO - 2024-10-29 08:33:26 --> Loader Class Initialized
INFO - 2024-10-29 08:33:26 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:26 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:26 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:26 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:26 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:26 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:26 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:28 --> Upload Class Initialized
INFO - 2024-10-29 08:33:28 --> Email Class Initialized
INFO - 2024-10-29 08:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:28 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:28 --> Controller Class Initialized
INFO - 2024-10-29 14:03:28 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:28 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:28 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:30 --> Config Class Initialized
INFO - 2024-10-29 08:33:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:31 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:31 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:31 --> URI Class Initialized
INFO - 2024-10-29 08:33:31 --> Router Class Initialized
INFO - 2024-10-29 08:33:31 --> Output Class Initialized
INFO - 2024-10-29 08:33:31 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:31 --> Input Class Initialized
INFO - 2024-10-29 08:33:31 --> Language Class Initialized
INFO - 2024-10-29 08:33:31 --> Loader Class Initialized
INFO - 2024-10-29 08:33:31 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:31 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:31 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:31 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:31 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:31 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:31 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:33 --> Upload Class Initialized
INFO - 2024-10-29 08:33:33 --> Email Class Initialized
INFO - 2024-10-29 08:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:33 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:33 --> Controller Class Initialized
INFO - 2024-10-29 14:03:33 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:33 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:33 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:34 --> Config Class Initialized
INFO - 2024-10-29 08:33:34 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:34 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:34 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:34 --> URI Class Initialized
INFO - 2024-10-29 08:33:34 --> Router Class Initialized
INFO - 2024-10-29 08:33:34 --> Output Class Initialized
INFO - 2024-10-29 08:33:34 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:34 --> Input Class Initialized
INFO - 2024-10-29 08:33:34 --> Language Class Initialized
INFO - 2024-10-29 08:33:34 --> Loader Class Initialized
INFO - 2024-10-29 08:33:34 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:34 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:34 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:34 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:34 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:34 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:34 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:35 --> Config Class Initialized
INFO - 2024-10-29 08:33:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:36 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:36 --> URI Class Initialized
INFO - 2024-10-29 08:33:36 --> Router Class Initialized
INFO - 2024-10-29 08:33:36 --> Output Class Initialized
INFO - 2024-10-29 08:33:36 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:36 --> Input Class Initialized
INFO - 2024-10-29 08:33:36 --> Language Class Initialized
INFO - 2024-10-29 08:33:36 --> Loader Class Initialized
INFO - 2024-10-29 08:33:36 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:36 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:36 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:36 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:36 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:36 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:36 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:36 --> Upload Class Initialized
INFO - 2024-10-29 08:33:36 --> Email Class Initialized
INFO - 2024-10-29 08:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:36 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:36 --> Controller Class Initialized
INFO - 2024-10-29 14:03:36 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:36 --> Model "FrontofficeModel" initialized
INFO - 2024-10-29 14:03:36 --> Model "HotelAdminModel" initialized
INFO - 2024-10-29 14:03:36 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-29 14:03:36 --> Model "FoodAdminModel" initialized
INFO - 2024-10-29 14:03:36 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 14:03:36 --> Helper loaded: notification_helper
INFO - 2024-10-29 14:03:36 --> Helper loaded: array_helper
INFO - 2024-10-29 14:03:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-29 14:03:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/superadmindashboard.php
INFO - 2024-10-29 14:03:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-29 14:03:36 --> Final output sent to browser
DEBUG - 2024-10-29 14:03:36 --> Total execution time: 2.3155
INFO - 2024-10-29 08:33:37 --> Config Class Initialized
INFO - 2024-10-29 08:33:37 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:37 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:37 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:37 --> URI Class Initialized
INFO - 2024-10-29 08:33:37 --> Router Class Initialized
INFO - 2024-10-29 08:33:37 --> Output Class Initialized
INFO - 2024-10-29 08:33:37 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:37 --> Input Class Initialized
INFO - 2024-10-29 08:33:37 --> Language Class Initialized
ERROR - 2024-10-29 08:33:37 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:33:37 --> Config Class Initialized
INFO - 2024-10-29 08:33:37 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:37 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:37 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:37 --> Config Class Initialized
INFO - 2024-10-29 08:33:37 --> URI Class Initialized
INFO - 2024-10-29 08:33:37 --> Hooks Class Initialized
INFO - 2024-10-29 08:33:37 --> Router Class Initialized
DEBUG - 2024-10-29 08:33:37 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:37 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:37 --> Output Class Initialized
INFO - 2024-10-29 08:33:37 --> URI Class Initialized
INFO - 2024-10-29 08:33:37 --> Security Class Initialized
INFO - 2024-10-29 08:33:37 --> Router Class Initialized
DEBUG - 2024-10-29 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:37 --> Output Class Initialized
INFO - 2024-10-29 08:33:37 --> Input Class Initialized
INFO - 2024-10-29 08:33:37 --> Security Class Initialized
INFO - 2024-10-29 08:33:37 --> Language Class Initialized
DEBUG - 2024-10-29 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:37 --> Loader Class Initialized
INFO - 2024-10-29 08:33:37 --> Input Class Initialized
INFO - 2024-10-29 08:33:37 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:37 --> Language Class Initialized
ERROR - 2024-10-29 08:33:37 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:33:37 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:37 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:37 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:37 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:37 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:37 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:37 --> Config Class Initialized
INFO - 2024-10-29 08:33:37 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:37 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:37 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:37 --> URI Class Initialized
INFO - 2024-10-29 08:33:37 --> Router Class Initialized
INFO - 2024-10-29 08:33:37 --> Output Class Initialized
INFO - 2024-10-29 08:33:37 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:37 --> Input Class Initialized
INFO - 2024-10-29 08:33:37 --> Language Class Initialized
ERROR - 2024-10-29 08:33:37 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:33:38 --> Upload Class Initialized
INFO - 2024-10-29 08:33:38 --> Email Class Initialized
INFO - 2024-10-29 08:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:38 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:38 --> Controller Class Initialized
INFO - 2024-10-29 14:03:38 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:38 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:38 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:39 --> Upload Class Initialized
INFO - 2024-10-29 08:33:39 --> Email Class Initialized
INFO - 2024-10-29 08:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:39 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:39 --> Controller Class Initialized
INFO - 2024-10-29 14:03:39 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:39 --> Model "FrontofficeModel" initialized
INFO - 2024-10-29 14:03:39 --> Model "HotelAdminModel" initialized
INFO - 2024-10-29 14:03:39 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-29 14:03:39 --> Model "FoodAdminModel" initialized
INFO - 2024-10-29 14:03:39 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 14:03:39 --> Helper loaded: notification_helper
INFO - 2024-10-29 14:03:39 --> Helper loaded: array_helper
INFO - 2024-10-29 14:03:39 --> Final output sent to browser
DEBUG - 2024-10-29 14:03:39 --> Total execution time: 2.3042
INFO - 2024-10-29 08:33:42 --> Config Class Initialized
INFO - 2024-10-29 08:33:42 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:42 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:42 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:42 --> URI Class Initialized
INFO - 2024-10-29 08:33:42 --> Router Class Initialized
INFO - 2024-10-29 08:33:42 --> Output Class Initialized
INFO - 2024-10-29 08:33:42 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:42 --> Input Class Initialized
INFO - 2024-10-29 08:33:42 --> Language Class Initialized
INFO - 2024-10-29 08:33:42 --> Loader Class Initialized
INFO - 2024-10-29 08:33:42 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:42 --> Config Class Initialized
INFO - 2024-10-29 08:33:42 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:42 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:42 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:42 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:42 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:42 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:42 --> URI Class Initialized
INFO - 2024-10-29 08:33:42 --> Router Class Initialized
INFO - 2024-10-29 08:33:42 --> Output Class Initialized
INFO - 2024-10-29 08:33:42 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:42 --> Input Class Initialized
INFO - 2024-10-29 08:33:42 --> Language Class Initialized
INFO - 2024-10-29 08:33:42 --> Loader Class Initialized
INFO - 2024-10-29 08:33:42 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:42 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:42 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:44 --> Upload Class Initialized
INFO - 2024-10-29 08:33:44 --> Email Class Initialized
INFO - 2024-10-29 08:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:44 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:44 --> Controller Class Initialized
INFO - 2024-10-29 14:03:44 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:44 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:44 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:44 --> Upload Class Initialized
INFO - 2024-10-29 08:33:44 --> Email Class Initialized
INFO - 2024-10-29 08:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:44 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:44 --> Controller Class Initialized
INFO - 2024-10-29 14:03:44 --> Model "SuperAdminModel" initialized
INFO - 2024-10-29 14:03:44 --> Helper loaded: notification_helper
INFO - 2024-10-29 14:03:44 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
ERROR - 2024-10-29 14:03:44 --> Severity: Warning --> Undefined array key "u_id" C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin\hotelLists.php 369
INFO - 2024-10-29 14:03:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\superadmin/hotelLists.php
INFO - 2024-10-29 14:03:44 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-29 14:03:44 --> Final output sent to browser
DEBUG - 2024-10-29 14:03:44 --> Total execution time: 2.6747
INFO - 2024-10-29 08:33:45 --> Config Class Initialized
INFO - 2024-10-29 08:33:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:45 --> URI Class Initialized
INFO - 2024-10-29 08:33:45 --> Router Class Initialized
INFO - 2024-10-29 08:33:45 --> Output Class Initialized
INFO - 2024-10-29 08:33:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:45 --> Input Class Initialized
INFO - 2024-10-29 08:33:45 --> Language Class Initialized
ERROR - 2024-10-29 08:33:45 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:33:45 --> Config Class Initialized
INFO - 2024-10-29 08:33:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:45 --> URI Class Initialized
INFO - 2024-10-29 08:33:45 --> Router Class Initialized
INFO - 2024-10-29 08:33:45 --> Output Class Initialized
INFO - 2024-10-29 08:33:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:45 --> Input Class Initialized
INFO - 2024-10-29 08:33:45 --> Language Class Initialized
ERROR - 2024-10-29 08:33:45 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:33:45 --> Config Class Initialized
INFO - 2024-10-29 08:33:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:45 --> URI Class Initialized
INFO - 2024-10-29 08:33:45 --> Router Class Initialized
INFO - 2024-10-29 08:33:45 --> Output Class Initialized
INFO - 2024-10-29 08:33:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:45 --> Input Class Initialized
INFO - 2024-10-29 08:33:45 --> Language Class Initialized
ERROR - 2024-10-29 08:33:45 --> 404 Page Not Found: Fonts/poppins
INFO - 2024-10-29 08:33:50 --> Config Class Initialized
INFO - 2024-10-29 08:33:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:50 --> URI Class Initialized
INFO - 2024-10-29 08:33:50 --> Router Class Initialized
INFO - 2024-10-29 08:33:50 --> Output Class Initialized
INFO - 2024-10-29 08:33:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:50 --> Input Class Initialized
INFO - 2024-10-29 08:33:50 --> Language Class Initialized
INFO - 2024-10-29 08:33:50 --> Loader Class Initialized
INFO - 2024-10-29 08:33:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:52 --> Upload Class Initialized
INFO - 2024-10-29 08:33:52 --> Email Class Initialized
INFO - 2024-10-29 08:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:52 --> Controller Class Initialized
INFO - 2024-10-29 14:03:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:33:55 --> Config Class Initialized
INFO - 2024-10-29 08:33:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:33:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:33:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:33:55 --> URI Class Initialized
INFO - 2024-10-29 08:33:55 --> Router Class Initialized
INFO - 2024-10-29 08:33:55 --> Output Class Initialized
INFO - 2024-10-29 08:33:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:33:55 --> Input Class Initialized
INFO - 2024-10-29 08:33:55 --> Language Class Initialized
INFO - 2024-10-29 08:33:55 --> Loader Class Initialized
INFO - 2024-10-29 08:33:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:33:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:33:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:33:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:33:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:33:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:33:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:33:57 --> Upload Class Initialized
INFO - 2024-10-29 08:33:57 --> Email Class Initialized
INFO - 2024-10-29 08:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:33:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:33:57 --> Controller Class Initialized
INFO - 2024-10-29 14:03:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:03:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:03:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:00 --> Config Class Initialized
INFO - 2024-10-29 08:34:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:00 --> URI Class Initialized
INFO - 2024-10-29 08:34:00 --> Router Class Initialized
INFO - 2024-10-29 08:34:00 --> Output Class Initialized
INFO - 2024-10-29 08:34:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:00 --> Input Class Initialized
INFO - 2024-10-29 08:34:00 --> Language Class Initialized
INFO - 2024-10-29 08:34:00 --> Loader Class Initialized
INFO - 2024-10-29 08:34:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:02 --> Upload Class Initialized
INFO - 2024-10-29 08:34:02 --> Email Class Initialized
INFO - 2024-10-29 08:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:02 --> Controller Class Initialized
INFO - 2024-10-29 14:04:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:05 --> Config Class Initialized
INFO - 2024-10-29 08:34:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:05 --> URI Class Initialized
INFO - 2024-10-29 08:34:05 --> Router Class Initialized
INFO - 2024-10-29 08:34:05 --> Output Class Initialized
INFO - 2024-10-29 08:34:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:05 --> Input Class Initialized
INFO - 2024-10-29 08:34:05 --> Language Class Initialized
INFO - 2024-10-29 08:34:05 --> Loader Class Initialized
INFO - 2024-10-29 08:34:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:07 --> Upload Class Initialized
INFO - 2024-10-29 08:34:07 --> Email Class Initialized
INFO - 2024-10-29 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:07 --> Controller Class Initialized
INFO - 2024-10-29 14:04:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:10 --> Config Class Initialized
INFO - 2024-10-29 08:34:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:10 --> URI Class Initialized
INFO - 2024-10-29 08:34:10 --> Router Class Initialized
INFO - 2024-10-29 08:34:10 --> Output Class Initialized
INFO - 2024-10-29 08:34:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:10 --> Input Class Initialized
INFO - 2024-10-29 08:34:10 --> Language Class Initialized
INFO - 2024-10-29 08:34:10 --> Loader Class Initialized
INFO - 2024-10-29 08:34:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:12 --> Upload Class Initialized
INFO - 2024-10-29 08:34:12 --> Email Class Initialized
INFO - 2024-10-29 08:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:12 --> Controller Class Initialized
INFO - 2024-10-29 14:04:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:15 --> Config Class Initialized
INFO - 2024-10-29 08:34:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:15 --> URI Class Initialized
INFO - 2024-10-29 08:34:15 --> Router Class Initialized
INFO - 2024-10-29 08:34:15 --> Output Class Initialized
INFO - 2024-10-29 08:34:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:15 --> Input Class Initialized
INFO - 2024-10-29 08:34:15 --> Language Class Initialized
INFO - 2024-10-29 08:34:15 --> Loader Class Initialized
INFO - 2024-10-29 08:34:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:17 --> Upload Class Initialized
INFO - 2024-10-29 08:34:17 --> Email Class Initialized
INFO - 2024-10-29 08:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:17 --> Controller Class Initialized
INFO - 2024-10-29 14:04:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:17 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:20 --> Config Class Initialized
INFO - 2024-10-29 08:34:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:20 --> URI Class Initialized
INFO - 2024-10-29 08:34:20 --> Router Class Initialized
INFO - 2024-10-29 08:34:20 --> Output Class Initialized
INFO - 2024-10-29 08:34:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:20 --> Input Class Initialized
INFO - 2024-10-29 08:34:20 --> Language Class Initialized
INFO - 2024-10-29 08:34:20 --> Loader Class Initialized
INFO - 2024-10-29 08:34:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:22 --> Upload Class Initialized
INFO - 2024-10-29 08:34:22 --> Email Class Initialized
INFO - 2024-10-29 08:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:22 --> Controller Class Initialized
INFO - 2024-10-29 14:04:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:25 --> Config Class Initialized
INFO - 2024-10-29 08:34:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:25 --> URI Class Initialized
INFO - 2024-10-29 08:34:25 --> Router Class Initialized
INFO - 2024-10-29 08:34:25 --> Output Class Initialized
INFO - 2024-10-29 08:34:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:25 --> Input Class Initialized
INFO - 2024-10-29 08:34:25 --> Language Class Initialized
INFO - 2024-10-29 08:34:25 --> Loader Class Initialized
INFO - 2024-10-29 08:34:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:27 --> Upload Class Initialized
INFO - 2024-10-29 08:34:27 --> Email Class Initialized
INFO - 2024-10-29 08:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:27 --> Controller Class Initialized
INFO - 2024-10-29 14:04:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:30 --> Config Class Initialized
INFO - 2024-10-29 08:34:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:30 --> URI Class Initialized
INFO - 2024-10-29 08:34:30 --> Router Class Initialized
INFO - 2024-10-29 08:34:30 --> Output Class Initialized
INFO - 2024-10-29 08:34:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:30 --> Input Class Initialized
INFO - 2024-10-29 08:34:30 --> Language Class Initialized
INFO - 2024-10-29 08:34:30 --> Loader Class Initialized
INFO - 2024-10-29 08:34:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:32 --> Upload Class Initialized
INFO - 2024-10-29 08:34:32 --> Email Class Initialized
INFO - 2024-10-29 08:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:32 --> Controller Class Initialized
INFO - 2024-10-29 14:04:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:35 --> Config Class Initialized
INFO - 2024-10-29 08:34:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:35 --> URI Class Initialized
INFO - 2024-10-29 08:34:35 --> Router Class Initialized
INFO - 2024-10-29 08:34:35 --> Output Class Initialized
INFO - 2024-10-29 08:34:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:35 --> Input Class Initialized
INFO - 2024-10-29 08:34:35 --> Language Class Initialized
INFO - 2024-10-29 08:34:35 --> Loader Class Initialized
INFO - 2024-10-29 08:34:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:37 --> Upload Class Initialized
INFO - 2024-10-29 08:34:37 --> Email Class Initialized
INFO - 2024-10-29 08:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:37 --> Controller Class Initialized
INFO - 2024-10-29 14:04:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:40 --> Config Class Initialized
INFO - 2024-10-29 08:34:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:40 --> URI Class Initialized
INFO - 2024-10-29 08:34:40 --> Router Class Initialized
INFO - 2024-10-29 08:34:40 --> Output Class Initialized
INFO - 2024-10-29 08:34:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:40 --> Input Class Initialized
INFO - 2024-10-29 08:34:40 --> Language Class Initialized
INFO - 2024-10-29 08:34:40 --> Loader Class Initialized
INFO - 2024-10-29 08:34:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:42 --> Upload Class Initialized
INFO - 2024-10-29 08:34:42 --> Email Class Initialized
INFO - 2024-10-29 08:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:43 --> Controller Class Initialized
INFO - 2024-10-29 14:04:43 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:43 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:43 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:45 --> Config Class Initialized
INFO - 2024-10-29 08:34:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:45 --> URI Class Initialized
INFO - 2024-10-29 08:34:45 --> Router Class Initialized
INFO - 2024-10-29 08:34:45 --> Output Class Initialized
INFO - 2024-10-29 08:34:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:45 --> Input Class Initialized
INFO - 2024-10-29 08:34:45 --> Language Class Initialized
INFO - 2024-10-29 08:34:45 --> Loader Class Initialized
INFO - 2024-10-29 08:34:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:47 --> Upload Class Initialized
INFO - 2024-10-29 08:34:47 --> Email Class Initialized
INFO - 2024-10-29 08:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:47 --> Controller Class Initialized
INFO - 2024-10-29 14:04:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:50 --> Config Class Initialized
INFO - 2024-10-29 08:34:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:50 --> URI Class Initialized
INFO - 2024-10-29 08:34:50 --> Router Class Initialized
INFO - 2024-10-29 08:34:50 --> Output Class Initialized
INFO - 2024-10-29 08:34:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:50 --> Input Class Initialized
INFO - 2024-10-29 08:34:50 --> Language Class Initialized
INFO - 2024-10-29 08:34:50 --> Loader Class Initialized
INFO - 2024-10-29 08:34:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:52 --> Upload Class Initialized
INFO - 2024-10-29 08:34:52 --> Email Class Initialized
INFO - 2024-10-29 08:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:52 --> Controller Class Initialized
INFO - 2024-10-29 14:04:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:34:55 --> Config Class Initialized
INFO - 2024-10-29 08:34:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:34:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:34:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:34:55 --> URI Class Initialized
INFO - 2024-10-29 08:34:55 --> Router Class Initialized
INFO - 2024-10-29 08:34:55 --> Output Class Initialized
INFO - 2024-10-29 08:34:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:34:55 --> Input Class Initialized
INFO - 2024-10-29 08:34:55 --> Language Class Initialized
INFO - 2024-10-29 08:34:55 --> Loader Class Initialized
INFO - 2024-10-29 08:34:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:34:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:34:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:34:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:34:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:34:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:34:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:34:57 --> Upload Class Initialized
INFO - 2024-10-29 08:34:57 --> Email Class Initialized
INFO - 2024-10-29 08:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:34:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:34:57 --> Controller Class Initialized
INFO - 2024-10-29 14:04:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:04:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:04:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:04:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:00 --> Config Class Initialized
INFO - 2024-10-29 08:35:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:00 --> URI Class Initialized
INFO - 2024-10-29 08:35:00 --> Router Class Initialized
INFO - 2024-10-29 08:35:00 --> Output Class Initialized
INFO - 2024-10-29 08:35:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:00 --> Input Class Initialized
INFO - 2024-10-29 08:35:00 --> Language Class Initialized
INFO - 2024-10-29 08:35:00 --> Loader Class Initialized
INFO - 2024-10-29 08:35:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:02 --> Upload Class Initialized
INFO - 2024-10-29 08:35:02 --> Email Class Initialized
INFO - 2024-10-29 08:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:02 --> Controller Class Initialized
INFO - 2024-10-29 14:05:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:05 --> Config Class Initialized
INFO - 2024-10-29 08:35:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:05 --> URI Class Initialized
INFO - 2024-10-29 08:35:05 --> Router Class Initialized
INFO - 2024-10-29 08:35:05 --> Output Class Initialized
INFO - 2024-10-29 08:35:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:05 --> Input Class Initialized
INFO - 2024-10-29 08:35:05 --> Language Class Initialized
INFO - 2024-10-29 08:35:05 --> Loader Class Initialized
INFO - 2024-10-29 08:35:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:07 --> Upload Class Initialized
INFO - 2024-10-29 08:35:07 --> Email Class Initialized
INFO - 2024-10-29 08:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:07 --> Controller Class Initialized
INFO - 2024-10-29 14:05:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:10 --> Config Class Initialized
INFO - 2024-10-29 08:35:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:10 --> URI Class Initialized
INFO - 2024-10-29 08:35:10 --> Router Class Initialized
INFO - 2024-10-29 08:35:10 --> Output Class Initialized
INFO - 2024-10-29 08:35:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:10 --> Input Class Initialized
INFO - 2024-10-29 08:35:10 --> Language Class Initialized
INFO - 2024-10-29 08:35:10 --> Loader Class Initialized
INFO - 2024-10-29 08:35:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:12 --> Upload Class Initialized
INFO - 2024-10-29 08:35:12 --> Email Class Initialized
INFO - 2024-10-29 08:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:12 --> Controller Class Initialized
INFO - 2024-10-29 14:05:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:15 --> Config Class Initialized
INFO - 2024-10-29 08:35:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:15 --> URI Class Initialized
INFO - 2024-10-29 08:35:15 --> Router Class Initialized
INFO - 2024-10-29 08:35:15 --> Output Class Initialized
INFO - 2024-10-29 08:35:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:15 --> Input Class Initialized
INFO - 2024-10-29 08:35:15 --> Language Class Initialized
INFO - 2024-10-29 08:35:15 --> Loader Class Initialized
INFO - 2024-10-29 08:35:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:17 --> Upload Class Initialized
INFO - 2024-10-29 08:35:17 --> Email Class Initialized
INFO - 2024-10-29 08:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:17 --> Controller Class Initialized
INFO - 2024-10-29 14:05:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:17 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:20 --> Config Class Initialized
INFO - 2024-10-29 08:35:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:20 --> URI Class Initialized
INFO - 2024-10-29 08:35:20 --> Router Class Initialized
INFO - 2024-10-29 08:35:20 --> Output Class Initialized
INFO - 2024-10-29 08:35:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:20 --> Input Class Initialized
INFO - 2024-10-29 08:35:20 --> Language Class Initialized
INFO - 2024-10-29 08:35:20 --> Loader Class Initialized
INFO - 2024-10-29 08:35:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:22 --> Upload Class Initialized
INFO - 2024-10-29 08:35:22 --> Email Class Initialized
INFO - 2024-10-29 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:22 --> Controller Class Initialized
INFO - 2024-10-29 14:05:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:25 --> Config Class Initialized
INFO - 2024-10-29 08:35:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:25 --> URI Class Initialized
INFO - 2024-10-29 08:35:25 --> Router Class Initialized
INFO - 2024-10-29 08:35:25 --> Output Class Initialized
INFO - 2024-10-29 08:35:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:25 --> Input Class Initialized
INFO - 2024-10-29 08:35:25 --> Language Class Initialized
INFO - 2024-10-29 08:35:25 --> Loader Class Initialized
INFO - 2024-10-29 08:35:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:27 --> Upload Class Initialized
INFO - 2024-10-29 08:35:27 --> Email Class Initialized
INFO - 2024-10-29 08:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:27 --> Controller Class Initialized
INFO - 2024-10-29 14:05:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:30 --> Config Class Initialized
INFO - 2024-10-29 08:35:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:30 --> URI Class Initialized
INFO - 2024-10-29 08:35:30 --> Router Class Initialized
INFO - 2024-10-29 08:35:30 --> Output Class Initialized
INFO - 2024-10-29 08:35:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:30 --> Input Class Initialized
INFO - 2024-10-29 08:35:30 --> Language Class Initialized
INFO - 2024-10-29 08:35:30 --> Loader Class Initialized
INFO - 2024-10-29 08:35:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:32 --> Upload Class Initialized
INFO - 2024-10-29 08:35:32 --> Email Class Initialized
INFO - 2024-10-29 08:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:32 --> Controller Class Initialized
INFO - 2024-10-29 14:05:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:35 --> Config Class Initialized
INFO - 2024-10-29 08:35:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:35 --> URI Class Initialized
INFO - 2024-10-29 08:35:35 --> Router Class Initialized
INFO - 2024-10-29 08:35:35 --> Output Class Initialized
INFO - 2024-10-29 08:35:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:35 --> Input Class Initialized
INFO - 2024-10-29 08:35:35 --> Language Class Initialized
INFO - 2024-10-29 08:35:35 --> Loader Class Initialized
INFO - 2024-10-29 08:35:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:37 --> Upload Class Initialized
INFO - 2024-10-29 08:35:37 --> Email Class Initialized
INFO - 2024-10-29 08:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:37 --> Controller Class Initialized
INFO - 2024-10-29 14:05:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:40 --> Config Class Initialized
INFO - 2024-10-29 08:35:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:40 --> URI Class Initialized
INFO - 2024-10-29 08:35:40 --> Router Class Initialized
INFO - 2024-10-29 08:35:40 --> Output Class Initialized
INFO - 2024-10-29 08:35:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:40 --> Input Class Initialized
INFO - 2024-10-29 08:35:40 --> Language Class Initialized
INFO - 2024-10-29 08:35:40 --> Loader Class Initialized
INFO - 2024-10-29 08:35:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:42 --> Upload Class Initialized
INFO - 2024-10-29 08:35:42 --> Email Class Initialized
INFO - 2024-10-29 08:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:42 --> Controller Class Initialized
INFO - 2024-10-29 14:05:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:45 --> Config Class Initialized
INFO - 2024-10-29 08:35:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:45 --> URI Class Initialized
INFO - 2024-10-29 08:35:45 --> Router Class Initialized
INFO - 2024-10-29 08:35:45 --> Output Class Initialized
INFO - 2024-10-29 08:35:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:45 --> Input Class Initialized
INFO - 2024-10-29 08:35:45 --> Language Class Initialized
INFO - 2024-10-29 08:35:45 --> Loader Class Initialized
INFO - 2024-10-29 08:35:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:47 --> Upload Class Initialized
INFO - 2024-10-29 08:35:47 --> Email Class Initialized
INFO - 2024-10-29 08:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:47 --> Controller Class Initialized
INFO - 2024-10-29 14:05:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:50 --> Config Class Initialized
INFO - 2024-10-29 08:35:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:50 --> URI Class Initialized
INFO - 2024-10-29 08:35:50 --> Router Class Initialized
INFO - 2024-10-29 08:35:50 --> Output Class Initialized
INFO - 2024-10-29 08:35:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:50 --> Input Class Initialized
INFO - 2024-10-29 08:35:50 --> Language Class Initialized
INFO - 2024-10-29 08:35:50 --> Loader Class Initialized
INFO - 2024-10-29 08:35:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:52 --> Upload Class Initialized
INFO - 2024-10-29 08:35:52 --> Email Class Initialized
INFO - 2024-10-29 08:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:52 --> Controller Class Initialized
INFO - 2024-10-29 14:05:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:35:55 --> Config Class Initialized
INFO - 2024-10-29 08:35:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:35:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:35:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:35:55 --> URI Class Initialized
INFO - 2024-10-29 08:35:55 --> Router Class Initialized
INFO - 2024-10-29 08:35:55 --> Output Class Initialized
INFO - 2024-10-29 08:35:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:35:55 --> Input Class Initialized
INFO - 2024-10-29 08:35:55 --> Language Class Initialized
INFO - 2024-10-29 08:35:55 --> Loader Class Initialized
INFO - 2024-10-29 08:35:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:35:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:35:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:35:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:35:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:35:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:35:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:35:57 --> Upload Class Initialized
INFO - 2024-10-29 08:35:57 --> Email Class Initialized
INFO - 2024-10-29 08:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:35:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:35:57 --> Controller Class Initialized
INFO - 2024-10-29 14:05:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:05:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:05:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:00 --> Config Class Initialized
INFO - 2024-10-29 08:36:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:00 --> URI Class Initialized
INFO - 2024-10-29 08:36:00 --> Router Class Initialized
INFO - 2024-10-29 08:36:00 --> Output Class Initialized
INFO - 2024-10-29 08:36:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:00 --> Input Class Initialized
INFO - 2024-10-29 08:36:00 --> Language Class Initialized
INFO - 2024-10-29 08:36:00 --> Loader Class Initialized
INFO - 2024-10-29 08:36:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:02 --> Upload Class Initialized
INFO - 2024-10-29 08:36:02 --> Email Class Initialized
INFO - 2024-10-29 08:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:02 --> Controller Class Initialized
INFO - 2024-10-29 14:06:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:05 --> Config Class Initialized
INFO - 2024-10-29 08:36:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:05 --> URI Class Initialized
INFO - 2024-10-29 08:36:05 --> Router Class Initialized
INFO - 2024-10-29 08:36:05 --> Output Class Initialized
INFO - 2024-10-29 08:36:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:05 --> Input Class Initialized
INFO - 2024-10-29 08:36:05 --> Language Class Initialized
INFO - 2024-10-29 08:36:05 --> Loader Class Initialized
INFO - 2024-10-29 08:36:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:07 --> Upload Class Initialized
INFO - 2024-10-29 08:36:07 --> Email Class Initialized
INFO - 2024-10-29 08:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:07 --> Controller Class Initialized
INFO - 2024-10-29 14:06:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:10 --> Config Class Initialized
INFO - 2024-10-29 08:36:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:10 --> URI Class Initialized
INFO - 2024-10-29 08:36:10 --> Router Class Initialized
INFO - 2024-10-29 08:36:10 --> Output Class Initialized
INFO - 2024-10-29 08:36:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:10 --> Input Class Initialized
INFO - 2024-10-29 08:36:10 --> Language Class Initialized
INFO - 2024-10-29 08:36:10 --> Loader Class Initialized
INFO - 2024-10-29 08:36:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:12 --> Upload Class Initialized
INFO - 2024-10-29 08:36:12 --> Email Class Initialized
INFO - 2024-10-29 08:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:12 --> Controller Class Initialized
INFO - 2024-10-29 14:06:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:15 --> Config Class Initialized
INFO - 2024-10-29 08:36:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:15 --> URI Class Initialized
INFO - 2024-10-29 08:36:15 --> Router Class Initialized
INFO - 2024-10-29 08:36:15 --> Output Class Initialized
INFO - 2024-10-29 08:36:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:15 --> Input Class Initialized
INFO - 2024-10-29 08:36:15 --> Language Class Initialized
INFO - 2024-10-29 08:36:15 --> Loader Class Initialized
INFO - 2024-10-29 08:36:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:17 --> Upload Class Initialized
INFO - 2024-10-29 08:36:17 --> Email Class Initialized
INFO - 2024-10-29 08:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:17 --> Controller Class Initialized
INFO - 2024-10-29 14:06:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:17 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:20 --> Config Class Initialized
INFO - 2024-10-29 08:36:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:20 --> URI Class Initialized
INFO - 2024-10-29 08:36:20 --> Router Class Initialized
INFO - 2024-10-29 08:36:20 --> Output Class Initialized
INFO - 2024-10-29 08:36:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:20 --> Input Class Initialized
INFO - 2024-10-29 08:36:20 --> Language Class Initialized
INFO - 2024-10-29 08:36:20 --> Loader Class Initialized
INFO - 2024-10-29 08:36:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:22 --> Upload Class Initialized
INFO - 2024-10-29 08:36:22 --> Email Class Initialized
INFO - 2024-10-29 08:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:22 --> Controller Class Initialized
INFO - 2024-10-29 14:06:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:25 --> Config Class Initialized
INFO - 2024-10-29 08:36:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:25 --> URI Class Initialized
INFO - 2024-10-29 08:36:25 --> Router Class Initialized
INFO - 2024-10-29 08:36:25 --> Output Class Initialized
INFO - 2024-10-29 08:36:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:25 --> Input Class Initialized
INFO - 2024-10-29 08:36:25 --> Language Class Initialized
INFO - 2024-10-29 08:36:25 --> Loader Class Initialized
INFO - 2024-10-29 08:36:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:27 --> Upload Class Initialized
INFO - 2024-10-29 08:36:27 --> Email Class Initialized
INFO - 2024-10-29 08:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:27 --> Controller Class Initialized
INFO - 2024-10-29 14:06:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:30 --> Config Class Initialized
INFO - 2024-10-29 08:36:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:30 --> URI Class Initialized
INFO - 2024-10-29 08:36:30 --> Router Class Initialized
INFO - 2024-10-29 08:36:30 --> Output Class Initialized
INFO - 2024-10-29 08:36:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:30 --> Input Class Initialized
INFO - 2024-10-29 08:36:30 --> Language Class Initialized
INFO - 2024-10-29 08:36:30 --> Loader Class Initialized
INFO - 2024-10-29 08:36:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:32 --> Upload Class Initialized
INFO - 2024-10-29 08:36:32 --> Email Class Initialized
INFO - 2024-10-29 08:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:32 --> Controller Class Initialized
INFO - 2024-10-29 14:06:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:35 --> Config Class Initialized
INFO - 2024-10-29 08:36:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:35 --> URI Class Initialized
INFO - 2024-10-29 08:36:35 --> Router Class Initialized
INFO - 2024-10-29 08:36:35 --> Output Class Initialized
INFO - 2024-10-29 08:36:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:35 --> Input Class Initialized
INFO - 2024-10-29 08:36:35 --> Language Class Initialized
INFO - 2024-10-29 08:36:35 --> Loader Class Initialized
INFO - 2024-10-29 08:36:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:37 --> Upload Class Initialized
INFO - 2024-10-29 08:36:37 --> Email Class Initialized
INFO - 2024-10-29 08:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:37 --> Controller Class Initialized
INFO - 2024-10-29 14:06:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:40 --> Config Class Initialized
INFO - 2024-10-29 08:36:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:40 --> URI Class Initialized
INFO - 2024-10-29 08:36:40 --> Router Class Initialized
INFO - 2024-10-29 08:36:40 --> Output Class Initialized
INFO - 2024-10-29 08:36:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:40 --> Input Class Initialized
INFO - 2024-10-29 08:36:40 --> Language Class Initialized
INFO - 2024-10-29 08:36:40 --> Loader Class Initialized
INFO - 2024-10-29 08:36:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:42 --> Upload Class Initialized
INFO - 2024-10-29 08:36:42 --> Email Class Initialized
INFO - 2024-10-29 08:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:42 --> Controller Class Initialized
INFO - 2024-10-29 14:06:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:45 --> Config Class Initialized
INFO - 2024-10-29 08:36:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:45 --> URI Class Initialized
INFO - 2024-10-29 08:36:45 --> Router Class Initialized
INFO - 2024-10-29 08:36:45 --> Output Class Initialized
INFO - 2024-10-29 08:36:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:45 --> Input Class Initialized
INFO - 2024-10-29 08:36:45 --> Language Class Initialized
INFO - 2024-10-29 08:36:45 --> Loader Class Initialized
INFO - 2024-10-29 08:36:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:47 --> Upload Class Initialized
INFO - 2024-10-29 08:36:47 --> Email Class Initialized
INFO - 2024-10-29 08:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:47 --> Controller Class Initialized
INFO - 2024-10-29 14:06:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:50 --> Config Class Initialized
INFO - 2024-10-29 08:36:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:50 --> URI Class Initialized
INFO - 2024-10-29 08:36:50 --> Router Class Initialized
INFO - 2024-10-29 08:36:50 --> Output Class Initialized
INFO - 2024-10-29 08:36:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:50 --> Input Class Initialized
INFO - 2024-10-29 08:36:50 --> Language Class Initialized
INFO - 2024-10-29 08:36:50 --> Loader Class Initialized
INFO - 2024-10-29 08:36:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:52 --> Upload Class Initialized
INFO - 2024-10-29 08:36:52 --> Email Class Initialized
INFO - 2024-10-29 08:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:52 --> Controller Class Initialized
INFO - 2024-10-29 14:06:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:36:55 --> Config Class Initialized
INFO - 2024-10-29 08:36:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:36:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:36:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:36:55 --> URI Class Initialized
INFO - 2024-10-29 08:36:55 --> Router Class Initialized
INFO - 2024-10-29 08:36:55 --> Output Class Initialized
INFO - 2024-10-29 08:36:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:36:55 --> Input Class Initialized
INFO - 2024-10-29 08:36:55 --> Language Class Initialized
INFO - 2024-10-29 08:36:55 --> Loader Class Initialized
INFO - 2024-10-29 08:36:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:36:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:36:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:36:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:36:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:36:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:36:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:36:57 --> Upload Class Initialized
INFO - 2024-10-29 08:36:57 --> Email Class Initialized
INFO - 2024-10-29 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:36:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:36:57 --> Controller Class Initialized
INFO - 2024-10-29 14:06:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:06:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:06:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:00 --> Config Class Initialized
INFO - 2024-10-29 08:37:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:00 --> URI Class Initialized
INFO - 2024-10-29 08:37:00 --> Router Class Initialized
INFO - 2024-10-29 08:37:00 --> Output Class Initialized
INFO - 2024-10-29 08:37:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:00 --> Input Class Initialized
INFO - 2024-10-29 08:37:00 --> Language Class Initialized
INFO - 2024-10-29 08:37:00 --> Loader Class Initialized
INFO - 2024-10-29 08:37:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:02 --> Upload Class Initialized
INFO - 2024-10-29 08:37:02 --> Email Class Initialized
INFO - 2024-10-29 08:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:02 --> Controller Class Initialized
INFO - 2024-10-29 14:07:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:05 --> Config Class Initialized
INFO - 2024-10-29 08:37:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:05 --> URI Class Initialized
INFO - 2024-10-29 08:37:05 --> Router Class Initialized
INFO - 2024-10-29 08:37:05 --> Output Class Initialized
INFO - 2024-10-29 08:37:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:05 --> Input Class Initialized
INFO - 2024-10-29 08:37:05 --> Language Class Initialized
INFO - 2024-10-29 08:37:05 --> Loader Class Initialized
INFO - 2024-10-29 08:37:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:07 --> Upload Class Initialized
INFO - 2024-10-29 08:37:07 --> Email Class Initialized
INFO - 2024-10-29 08:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:07 --> Controller Class Initialized
INFO - 2024-10-29 14:07:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:10 --> Config Class Initialized
INFO - 2024-10-29 08:37:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:10 --> URI Class Initialized
INFO - 2024-10-29 08:37:10 --> Router Class Initialized
INFO - 2024-10-29 08:37:10 --> Output Class Initialized
INFO - 2024-10-29 08:37:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:10 --> Input Class Initialized
INFO - 2024-10-29 08:37:10 --> Language Class Initialized
INFO - 2024-10-29 08:37:10 --> Loader Class Initialized
INFO - 2024-10-29 08:37:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:12 --> Upload Class Initialized
INFO - 2024-10-29 08:37:12 --> Email Class Initialized
INFO - 2024-10-29 08:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:12 --> Controller Class Initialized
INFO - 2024-10-29 14:07:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:15 --> Config Class Initialized
INFO - 2024-10-29 08:37:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:15 --> URI Class Initialized
INFO - 2024-10-29 08:37:15 --> Router Class Initialized
INFO - 2024-10-29 08:37:15 --> Output Class Initialized
INFO - 2024-10-29 08:37:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:15 --> Input Class Initialized
INFO - 2024-10-29 08:37:15 --> Language Class Initialized
INFO - 2024-10-29 08:37:15 --> Loader Class Initialized
INFO - 2024-10-29 08:37:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:17 --> Upload Class Initialized
INFO - 2024-10-29 08:37:17 --> Email Class Initialized
INFO - 2024-10-29 08:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:18 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:18 --> Controller Class Initialized
INFO - 2024-10-29 14:07:18 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:18 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:18 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:20 --> Config Class Initialized
INFO - 2024-10-29 08:37:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:20 --> URI Class Initialized
INFO - 2024-10-29 08:37:20 --> Router Class Initialized
INFO - 2024-10-29 08:37:20 --> Output Class Initialized
INFO - 2024-10-29 08:37:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:20 --> Input Class Initialized
INFO - 2024-10-29 08:37:20 --> Language Class Initialized
INFO - 2024-10-29 08:37:20 --> Loader Class Initialized
INFO - 2024-10-29 08:37:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:22 --> Upload Class Initialized
INFO - 2024-10-29 08:37:22 --> Email Class Initialized
INFO - 2024-10-29 08:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:22 --> Controller Class Initialized
INFO - 2024-10-29 14:07:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:25 --> Config Class Initialized
INFO - 2024-10-29 08:37:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:25 --> URI Class Initialized
INFO - 2024-10-29 08:37:25 --> Router Class Initialized
INFO - 2024-10-29 08:37:25 --> Output Class Initialized
INFO - 2024-10-29 08:37:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:25 --> Input Class Initialized
INFO - 2024-10-29 08:37:25 --> Language Class Initialized
INFO - 2024-10-29 08:37:25 --> Loader Class Initialized
INFO - 2024-10-29 08:37:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:27 --> Upload Class Initialized
INFO - 2024-10-29 08:37:27 --> Email Class Initialized
INFO - 2024-10-29 08:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:27 --> Controller Class Initialized
INFO - 2024-10-29 14:07:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:30 --> Config Class Initialized
INFO - 2024-10-29 08:37:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:30 --> URI Class Initialized
INFO - 2024-10-29 08:37:30 --> Router Class Initialized
INFO - 2024-10-29 08:37:30 --> Output Class Initialized
INFO - 2024-10-29 08:37:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:30 --> Input Class Initialized
INFO - 2024-10-29 08:37:30 --> Language Class Initialized
INFO - 2024-10-29 08:37:30 --> Loader Class Initialized
INFO - 2024-10-29 08:37:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:32 --> Upload Class Initialized
INFO - 2024-10-29 08:37:32 --> Email Class Initialized
INFO - 2024-10-29 08:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:32 --> Controller Class Initialized
INFO - 2024-10-29 14:07:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:35 --> Config Class Initialized
INFO - 2024-10-29 08:37:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:35 --> URI Class Initialized
INFO - 2024-10-29 08:37:35 --> Router Class Initialized
INFO - 2024-10-29 08:37:35 --> Output Class Initialized
INFO - 2024-10-29 08:37:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:35 --> Input Class Initialized
INFO - 2024-10-29 08:37:35 --> Language Class Initialized
INFO - 2024-10-29 08:37:35 --> Loader Class Initialized
INFO - 2024-10-29 08:37:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:37 --> Upload Class Initialized
INFO - 2024-10-29 08:37:37 --> Email Class Initialized
INFO - 2024-10-29 08:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:37 --> Controller Class Initialized
INFO - 2024-10-29 14:07:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:40 --> Config Class Initialized
INFO - 2024-10-29 08:37:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:40 --> URI Class Initialized
INFO - 2024-10-29 08:37:40 --> Router Class Initialized
INFO - 2024-10-29 08:37:40 --> Output Class Initialized
INFO - 2024-10-29 08:37:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:40 --> Input Class Initialized
INFO - 2024-10-29 08:37:40 --> Language Class Initialized
INFO - 2024-10-29 08:37:40 --> Loader Class Initialized
INFO - 2024-10-29 08:37:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:42 --> Upload Class Initialized
INFO - 2024-10-29 08:37:42 --> Email Class Initialized
INFO - 2024-10-29 08:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:42 --> Controller Class Initialized
INFO - 2024-10-29 14:07:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:45 --> Config Class Initialized
INFO - 2024-10-29 08:37:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:45 --> URI Class Initialized
INFO - 2024-10-29 08:37:45 --> Router Class Initialized
INFO - 2024-10-29 08:37:45 --> Output Class Initialized
INFO - 2024-10-29 08:37:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:45 --> Input Class Initialized
INFO - 2024-10-29 08:37:45 --> Language Class Initialized
INFO - 2024-10-29 08:37:45 --> Loader Class Initialized
INFO - 2024-10-29 08:37:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:47 --> Upload Class Initialized
INFO - 2024-10-29 08:37:47 --> Email Class Initialized
INFO - 2024-10-29 08:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:47 --> Controller Class Initialized
INFO - 2024-10-29 14:07:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:50 --> Config Class Initialized
INFO - 2024-10-29 08:37:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:50 --> URI Class Initialized
INFO - 2024-10-29 08:37:50 --> Router Class Initialized
INFO - 2024-10-29 08:37:50 --> Output Class Initialized
INFO - 2024-10-29 08:37:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:50 --> Input Class Initialized
INFO - 2024-10-29 08:37:50 --> Language Class Initialized
INFO - 2024-10-29 08:37:50 --> Loader Class Initialized
INFO - 2024-10-29 08:37:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:52 --> Upload Class Initialized
INFO - 2024-10-29 08:37:52 --> Email Class Initialized
INFO - 2024-10-29 08:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:52 --> Controller Class Initialized
INFO - 2024-10-29 14:07:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:37:55 --> Config Class Initialized
INFO - 2024-10-29 08:37:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:37:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:37:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:37:55 --> URI Class Initialized
INFO - 2024-10-29 08:37:55 --> Router Class Initialized
INFO - 2024-10-29 08:37:55 --> Output Class Initialized
INFO - 2024-10-29 08:37:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:37:55 --> Input Class Initialized
INFO - 2024-10-29 08:37:55 --> Language Class Initialized
INFO - 2024-10-29 08:37:55 --> Loader Class Initialized
INFO - 2024-10-29 08:37:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:37:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:37:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:37:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:37:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:37:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:37:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:37:57 --> Upload Class Initialized
INFO - 2024-10-29 08:37:57 --> Email Class Initialized
INFO - 2024-10-29 08:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:37:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:37:57 --> Controller Class Initialized
INFO - 2024-10-29 14:07:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:07:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:07:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:00 --> Config Class Initialized
INFO - 2024-10-29 08:38:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:00 --> URI Class Initialized
INFO - 2024-10-29 08:38:00 --> Router Class Initialized
INFO - 2024-10-29 08:38:00 --> Output Class Initialized
INFO - 2024-10-29 08:38:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:00 --> Input Class Initialized
INFO - 2024-10-29 08:38:00 --> Language Class Initialized
INFO - 2024-10-29 08:38:00 --> Loader Class Initialized
INFO - 2024-10-29 08:38:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:02 --> Upload Class Initialized
INFO - 2024-10-29 08:38:02 --> Email Class Initialized
INFO - 2024-10-29 08:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:02 --> Controller Class Initialized
INFO - 2024-10-29 14:08:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:05 --> Config Class Initialized
INFO - 2024-10-29 08:38:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:05 --> URI Class Initialized
INFO - 2024-10-29 08:38:05 --> Router Class Initialized
INFO - 2024-10-29 08:38:05 --> Output Class Initialized
INFO - 2024-10-29 08:38:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:05 --> Input Class Initialized
INFO - 2024-10-29 08:38:05 --> Language Class Initialized
INFO - 2024-10-29 08:38:05 --> Loader Class Initialized
INFO - 2024-10-29 08:38:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:07 --> Upload Class Initialized
INFO - 2024-10-29 08:38:07 --> Email Class Initialized
INFO - 2024-10-29 08:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:07 --> Controller Class Initialized
INFO - 2024-10-29 14:08:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:10 --> Config Class Initialized
INFO - 2024-10-29 08:38:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:10 --> URI Class Initialized
INFO - 2024-10-29 08:38:10 --> Router Class Initialized
INFO - 2024-10-29 08:38:10 --> Output Class Initialized
INFO - 2024-10-29 08:38:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:10 --> Input Class Initialized
INFO - 2024-10-29 08:38:10 --> Language Class Initialized
INFO - 2024-10-29 08:38:10 --> Loader Class Initialized
INFO - 2024-10-29 08:38:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:12 --> Upload Class Initialized
INFO - 2024-10-29 08:38:12 --> Email Class Initialized
INFO - 2024-10-29 08:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:12 --> Controller Class Initialized
INFO - 2024-10-29 14:08:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:15 --> Config Class Initialized
INFO - 2024-10-29 08:38:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:15 --> URI Class Initialized
INFO - 2024-10-29 08:38:15 --> Router Class Initialized
INFO - 2024-10-29 08:38:15 --> Output Class Initialized
INFO - 2024-10-29 08:38:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:15 --> Input Class Initialized
INFO - 2024-10-29 08:38:15 --> Language Class Initialized
INFO - 2024-10-29 08:38:15 --> Loader Class Initialized
INFO - 2024-10-29 08:38:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:17 --> Upload Class Initialized
INFO - 2024-10-29 08:38:17 --> Email Class Initialized
INFO - 2024-10-29 08:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:17 --> Controller Class Initialized
INFO - 2024-10-29 14:08:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:17 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:20 --> Config Class Initialized
INFO - 2024-10-29 08:38:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:20 --> URI Class Initialized
INFO - 2024-10-29 08:38:20 --> Router Class Initialized
INFO - 2024-10-29 08:38:20 --> Output Class Initialized
INFO - 2024-10-29 08:38:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:20 --> Input Class Initialized
INFO - 2024-10-29 08:38:20 --> Language Class Initialized
INFO - 2024-10-29 08:38:20 --> Loader Class Initialized
INFO - 2024-10-29 08:38:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:22 --> Upload Class Initialized
INFO - 2024-10-29 08:38:22 --> Email Class Initialized
INFO - 2024-10-29 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:22 --> Controller Class Initialized
INFO - 2024-10-29 14:08:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:25 --> Config Class Initialized
INFO - 2024-10-29 08:38:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:25 --> URI Class Initialized
INFO - 2024-10-29 08:38:25 --> Router Class Initialized
INFO - 2024-10-29 08:38:25 --> Output Class Initialized
INFO - 2024-10-29 08:38:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:25 --> Input Class Initialized
INFO - 2024-10-29 08:38:25 --> Language Class Initialized
INFO - 2024-10-29 08:38:25 --> Loader Class Initialized
INFO - 2024-10-29 08:38:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:27 --> Upload Class Initialized
INFO - 2024-10-29 08:38:27 --> Email Class Initialized
INFO - 2024-10-29 08:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:27 --> Controller Class Initialized
INFO - 2024-10-29 14:08:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:30 --> Config Class Initialized
INFO - 2024-10-29 08:38:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:30 --> URI Class Initialized
INFO - 2024-10-29 08:38:30 --> Router Class Initialized
INFO - 2024-10-29 08:38:30 --> Output Class Initialized
INFO - 2024-10-29 08:38:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:30 --> Input Class Initialized
INFO - 2024-10-29 08:38:30 --> Language Class Initialized
INFO - 2024-10-29 08:38:30 --> Loader Class Initialized
INFO - 2024-10-29 08:38:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:32 --> Upload Class Initialized
INFO - 2024-10-29 08:38:32 --> Email Class Initialized
INFO - 2024-10-29 08:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:32 --> Controller Class Initialized
INFO - 2024-10-29 14:08:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:35 --> Config Class Initialized
INFO - 2024-10-29 08:38:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:35 --> URI Class Initialized
INFO - 2024-10-29 08:38:35 --> Router Class Initialized
INFO - 2024-10-29 08:38:35 --> Output Class Initialized
INFO - 2024-10-29 08:38:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:35 --> Input Class Initialized
INFO - 2024-10-29 08:38:35 --> Language Class Initialized
INFO - 2024-10-29 08:38:35 --> Loader Class Initialized
INFO - 2024-10-29 08:38:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:37 --> Upload Class Initialized
INFO - 2024-10-29 08:38:37 --> Email Class Initialized
INFO - 2024-10-29 08:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:37 --> Controller Class Initialized
INFO - 2024-10-29 14:08:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:40 --> Config Class Initialized
INFO - 2024-10-29 08:38:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:40 --> URI Class Initialized
INFO - 2024-10-29 08:38:40 --> Router Class Initialized
INFO - 2024-10-29 08:38:40 --> Output Class Initialized
INFO - 2024-10-29 08:38:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:40 --> Input Class Initialized
INFO - 2024-10-29 08:38:40 --> Language Class Initialized
INFO - 2024-10-29 08:38:40 --> Loader Class Initialized
INFO - 2024-10-29 08:38:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:42 --> Upload Class Initialized
INFO - 2024-10-29 08:38:42 --> Email Class Initialized
INFO - 2024-10-29 08:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:42 --> Controller Class Initialized
INFO - 2024-10-29 14:08:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:38:45 --> Config Class Initialized
INFO - 2024-10-29 08:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:38:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:38:45 --> URI Class Initialized
INFO - 2024-10-29 08:38:45 --> Router Class Initialized
INFO - 2024-10-29 08:38:45 --> Output Class Initialized
INFO - 2024-10-29 08:38:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:38:45 --> Input Class Initialized
INFO - 2024-10-29 08:38:45 --> Language Class Initialized
INFO - 2024-10-29 08:38:45 --> Loader Class Initialized
INFO - 2024-10-29 08:38:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:38:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:38:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:38:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:38:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:38:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:38:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:38:47 --> Upload Class Initialized
INFO - 2024-10-29 08:38:47 --> Email Class Initialized
INFO - 2024-10-29 08:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:38:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:38:47 --> Controller Class Initialized
INFO - 2024-10-29 14:08:48 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:08:48 --> Model "MainModel" initialized
INFO - 2024-10-29 14:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:08:48 --> Pagination Class Initialized
INFO - 2024-10-29 08:39:32 --> Config Class Initialized
INFO - 2024-10-29 08:39:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:39:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:39:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:39:32 --> URI Class Initialized
INFO - 2024-10-29 08:39:32 --> Router Class Initialized
INFO - 2024-10-29 08:39:32 --> Output Class Initialized
INFO - 2024-10-29 08:39:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:39:32 --> Input Class Initialized
INFO - 2024-10-29 08:39:32 --> Language Class Initialized
INFO - 2024-10-29 08:39:32 --> Loader Class Initialized
INFO - 2024-10-29 08:39:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:39:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:39:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:39:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:39:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:39:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:39:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:39:34 --> Upload Class Initialized
INFO - 2024-10-29 08:39:34 --> Email Class Initialized
INFO - 2024-10-29 08:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:39:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:39:34 --> Controller Class Initialized
INFO - 2024-10-29 14:09:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:09:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:09:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:40:32 --> Config Class Initialized
INFO - 2024-10-29 08:40:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:40:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:40:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:40:32 --> URI Class Initialized
INFO - 2024-10-29 08:40:32 --> Router Class Initialized
INFO - 2024-10-29 08:40:32 --> Output Class Initialized
INFO - 2024-10-29 08:40:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:40:32 --> Input Class Initialized
INFO - 2024-10-29 08:40:32 --> Language Class Initialized
INFO - 2024-10-29 08:40:32 --> Loader Class Initialized
INFO - 2024-10-29 08:40:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:40:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:40:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:40:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:40:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:40:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:40:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:40:34 --> Upload Class Initialized
INFO - 2024-10-29 08:40:34 --> Email Class Initialized
INFO - 2024-10-29 08:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:40:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:40:34 --> Controller Class Initialized
INFO - 2024-10-29 14:10:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:10:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:10:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:10:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:41:32 --> Config Class Initialized
INFO - 2024-10-29 08:41:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:41:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:41:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:41:32 --> URI Class Initialized
INFO - 2024-10-29 08:41:32 --> Router Class Initialized
INFO - 2024-10-29 08:41:32 --> Output Class Initialized
INFO - 2024-10-29 08:41:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:41:32 --> Input Class Initialized
INFO - 2024-10-29 08:41:32 --> Language Class Initialized
INFO - 2024-10-29 08:41:32 --> Loader Class Initialized
INFO - 2024-10-29 08:41:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:41:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:41:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:41:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:41:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:41:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:41:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:41:34 --> Upload Class Initialized
INFO - 2024-10-29 08:41:34 --> Email Class Initialized
INFO - 2024-10-29 08:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:41:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:41:34 --> Controller Class Initialized
INFO - 2024-10-29 14:11:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:11:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:11:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:42:32 --> Config Class Initialized
INFO - 2024-10-29 08:42:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:42:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:42:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:42:32 --> URI Class Initialized
INFO - 2024-10-29 08:42:32 --> Router Class Initialized
INFO - 2024-10-29 08:42:32 --> Output Class Initialized
INFO - 2024-10-29 08:42:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:42:32 --> Input Class Initialized
INFO - 2024-10-29 08:42:32 --> Language Class Initialized
INFO - 2024-10-29 08:42:32 --> Loader Class Initialized
INFO - 2024-10-29 08:42:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:42:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:42:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:42:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:42:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:42:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:42:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:42:34 --> Upload Class Initialized
INFO - 2024-10-29 08:42:34 --> Email Class Initialized
INFO - 2024-10-29 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:42:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:42:34 --> Controller Class Initialized
INFO - 2024-10-29 14:12:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:12:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:12:35 --> Pagination Class Initialized
INFO - 2024-10-29 08:43:32 --> Config Class Initialized
INFO - 2024-10-29 08:43:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:43:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:43:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:43:32 --> URI Class Initialized
INFO - 2024-10-29 08:43:32 --> Router Class Initialized
INFO - 2024-10-29 08:43:32 --> Output Class Initialized
INFO - 2024-10-29 08:43:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:43:32 --> Input Class Initialized
INFO - 2024-10-29 08:43:32 --> Language Class Initialized
INFO - 2024-10-29 08:43:32 --> Loader Class Initialized
INFO - 2024-10-29 08:43:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:43:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:43:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:43:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:43:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:43:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:43:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:43:34 --> Upload Class Initialized
INFO - 2024-10-29 08:43:34 --> Email Class Initialized
INFO - 2024-10-29 08:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:43:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:43:34 --> Controller Class Initialized
INFO - 2024-10-29 14:13:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:13:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:13:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:44:32 --> Config Class Initialized
INFO - 2024-10-29 08:44:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:44:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:44:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:44:32 --> URI Class Initialized
INFO - 2024-10-29 08:44:32 --> Router Class Initialized
INFO - 2024-10-29 08:44:32 --> Output Class Initialized
INFO - 2024-10-29 08:44:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:44:32 --> Input Class Initialized
INFO - 2024-10-29 08:44:32 --> Language Class Initialized
INFO - 2024-10-29 08:44:32 --> Loader Class Initialized
INFO - 2024-10-29 08:44:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:44:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:44:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:44:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:44:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:44:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:44:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:44:34 --> Upload Class Initialized
INFO - 2024-10-29 08:44:34 --> Email Class Initialized
INFO - 2024-10-29 08:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:44:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:44:34 --> Controller Class Initialized
INFO - 2024-10-29 14:14:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:14:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:14:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:45:32 --> Config Class Initialized
INFO - 2024-10-29 08:45:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:45:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:45:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:45:32 --> URI Class Initialized
INFO - 2024-10-29 08:45:32 --> Router Class Initialized
INFO - 2024-10-29 08:45:32 --> Output Class Initialized
INFO - 2024-10-29 08:45:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:45:32 --> Input Class Initialized
INFO - 2024-10-29 08:45:32 --> Language Class Initialized
INFO - 2024-10-29 08:45:32 --> Loader Class Initialized
INFO - 2024-10-29 08:45:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:45:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:45:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:45:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:45:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:45:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:45:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:45:34 --> Upload Class Initialized
INFO - 2024-10-29 08:45:34 --> Email Class Initialized
INFO - 2024-10-29 08:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:45:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:45:34 --> Controller Class Initialized
INFO - 2024-10-29 14:15:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:15:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:15:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:46:32 --> Config Class Initialized
INFO - 2024-10-29 08:46:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:46:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:46:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:46:32 --> URI Class Initialized
INFO - 2024-10-29 08:46:32 --> Router Class Initialized
INFO - 2024-10-29 08:46:32 --> Output Class Initialized
INFO - 2024-10-29 08:46:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:46:32 --> Input Class Initialized
INFO - 2024-10-29 08:46:32 --> Language Class Initialized
INFO - 2024-10-29 08:46:32 --> Loader Class Initialized
INFO - 2024-10-29 08:46:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:46:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:46:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:46:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:46:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:46:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:46:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:46:34 --> Upload Class Initialized
INFO - 2024-10-29 08:46:34 --> Email Class Initialized
INFO - 2024-10-29 08:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:46:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:46:34 --> Controller Class Initialized
INFO - 2024-10-29 14:16:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:16:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:16:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:47:32 --> Config Class Initialized
INFO - 2024-10-29 08:47:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:47:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:47:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:47:32 --> URI Class Initialized
INFO - 2024-10-29 08:47:32 --> Router Class Initialized
INFO - 2024-10-29 08:47:32 --> Output Class Initialized
INFO - 2024-10-29 08:47:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:47:32 --> Input Class Initialized
INFO - 2024-10-29 08:47:32 --> Language Class Initialized
INFO - 2024-10-29 08:47:32 --> Loader Class Initialized
INFO - 2024-10-29 08:47:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:47:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:47:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:47:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:47:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:47:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:47:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:47:34 --> Upload Class Initialized
INFO - 2024-10-29 08:47:34 --> Email Class Initialized
INFO - 2024-10-29 08:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:47:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:47:34 --> Controller Class Initialized
INFO - 2024-10-29 14:17:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:17:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:17:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:48:32 --> Config Class Initialized
INFO - 2024-10-29 08:48:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:48:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:48:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:48:32 --> URI Class Initialized
INFO - 2024-10-29 08:48:32 --> Router Class Initialized
INFO - 2024-10-29 08:48:32 --> Output Class Initialized
INFO - 2024-10-29 08:48:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:48:32 --> Input Class Initialized
INFO - 2024-10-29 08:48:32 --> Language Class Initialized
INFO - 2024-10-29 08:48:32 --> Loader Class Initialized
INFO - 2024-10-29 08:48:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:48:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:48:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:48:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:48:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:48:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:48:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:48:34 --> Upload Class Initialized
INFO - 2024-10-29 08:48:34 --> Email Class Initialized
INFO - 2024-10-29 08:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:48:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:48:34 --> Controller Class Initialized
INFO - 2024-10-29 14:18:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:18:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:18:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:49:32 --> Config Class Initialized
INFO - 2024-10-29 08:49:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:49:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:49:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:49:32 --> URI Class Initialized
INFO - 2024-10-29 08:49:32 --> Router Class Initialized
INFO - 2024-10-29 08:49:32 --> Output Class Initialized
INFO - 2024-10-29 08:49:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:49:32 --> Input Class Initialized
INFO - 2024-10-29 08:49:32 --> Language Class Initialized
INFO - 2024-10-29 08:49:32 --> Loader Class Initialized
INFO - 2024-10-29 08:49:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:49:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:49:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:49:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:49:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:49:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:49:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:49:34 --> Upload Class Initialized
INFO - 2024-10-29 08:49:34 --> Email Class Initialized
INFO - 2024-10-29 08:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:49:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:49:34 --> Controller Class Initialized
INFO - 2024-10-29 14:19:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:19:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:19:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:50:32 --> Config Class Initialized
INFO - 2024-10-29 08:50:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:50:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:50:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:50:32 --> URI Class Initialized
INFO - 2024-10-29 08:50:32 --> Router Class Initialized
INFO - 2024-10-29 08:50:32 --> Output Class Initialized
INFO - 2024-10-29 08:50:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:50:32 --> Input Class Initialized
INFO - 2024-10-29 08:50:32 --> Language Class Initialized
INFO - 2024-10-29 08:50:32 --> Loader Class Initialized
INFO - 2024-10-29 08:50:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:50:33 --> Helper loaded: html_helper
INFO - 2024-10-29 08:50:33 --> Helper loaded: file_helper
INFO - 2024-10-29 08:50:33 --> Helper loaded: string_helper
INFO - 2024-10-29 08:50:33 --> Helper loaded: form_helper
INFO - 2024-10-29 08:50:33 --> Helper loaded: my_helper
INFO - 2024-10-29 08:50:33 --> Database Driver Class Initialized
INFO - 2024-10-29 08:50:35 --> Upload Class Initialized
INFO - 2024-10-29 08:50:35 --> Email Class Initialized
INFO - 2024-10-29 08:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:50:35 --> Form Validation Class Initialized
INFO - 2024-10-29 08:50:35 --> Controller Class Initialized
INFO - 2024-10-29 14:20:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:20:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:20:35 --> Pagination Class Initialized
INFO - 2024-10-29 08:51:32 --> Config Class Initialized
INFO - 2024-10-29 08:51:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:51:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:51:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:51:32 --> URI Class Initialized
INFO - 2024-10-29 08:51:32 --> Router Class Initialized
INFO - 2024-10-29 08:51:32 --> Output Class Initialized
INFO - 2024-10-29 08:51:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:51:32 --> Input Class Initialized
INFO - 2024-10-29 08:51:32 --> Language Class Initialized
INFO - 2024-10-29 08:51:32 --> Loader Class Initialized
INFO - 2024-10-29 08:51:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:51:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:51:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:51:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:51:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:51:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:51:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:51:34 --> Upload Class Initialized
INFO - 2024-10-29 08:51:34 --> Email Class Initialized
INFO - 2024-10-29 08:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:51:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:51:34 --> Controller Class Initialized
INFO - 2024-10-29 14:21:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:21:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:21:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:52:32 --> Config Class Initialized
INFO - 2024-10-29 08:52:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:52:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:52:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:52:32 --> URI Class Initialized
INFO - 2024-10-29 08:52:32 --> Router Class Initialized
INFO - 2024-10-29 08:52:32 --> Output Class Initialized
INFO - 2024-10-29 08:52:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:52:32 --> Input Class Initialized
INFO - 2024-10-29 08:52:32 --> Language Class Initialized
INFO - 2024-10-29 08:52:32 --> Loader Class Initialized
INFO - 2024-10-29 08:52:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:52:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:52:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:52:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:52:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:52:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:52:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:52:34 --> Upload Class Initialized
INFO - 2024-10-29 08:52:34 --> Email Class Initialized
INFO - 2024-10-29 08:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:52:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:52:34 --> Controller Class Initialized
INFO - 2024-10-29 14:22:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:22:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:22:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:53:32 --> Config Class Initialized
INFO - 2024-10-29 08:53:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:53:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:53:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:53:32 --> URI Class Initialized
INFO - 2024-10-29 08:53:32 --> Router Class Initialized
INFO - 2024-10-29 08:53:32 --> Output Class Initialized
INFO - 2024-10-29 08:53:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:53:32 --> Input Class Initialized
INFO - 2024-10-29 08:53:32 --> Language Class Initialized
INFO - 2024-10-29 08:53:32 --> Loader Class Initialized
INFO - 2024-10-29 08:53:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:53:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:53:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:53:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:53:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:53:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:53:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:53:34 --> Upload Class Initialized
INFO - 2024-10-29 08:53:34 --> Email Class Initialized
INFO - 2024-10-29 08:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:53:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:53:34 --> Controller Class Initialized
INFO - 2024-10-29 14:23:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:23:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:23:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:54:32 --> Config Class Initialized
INFO - 2024-10-29 08:54:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:54:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:54:32 --> Utf8 Class Initialized
INFO - 2024-10-29 08:54:32 --> URI Class Initialized
INFO - 2024-10-29 08:54:32 --> Router Class Initialized
INFO - 2024-10-29 08:54:32 --> Output Class Initialized
INFO - 2024-10-29 08:54:32 --> Security Class Initialized
DEBUG - 2024-10-29 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:54:32 --> Input Class Initialized
INFO - 2024-10-29 08:54:32 --> Language Class Initialized
INFO - 2024-10-29 08:54:32 --> Loader Class Initialized
INFO - 2024-10-29 08:54:32 --> Helper loaded: url_helper
INFO - 2024-10-29 08:54:32 --> Helper loaded: html_helper
INFO - 2024-10-29 08:54:32 --> Helper loaded: file_helper
INFO - 2024-10-29 08:54:32 --> Helper loaded: string_helper
INFO - 2024-10-29 08:54:32 --> Helper loaded: form_helper
INFO - 2024-10-29 08:54:32 --> Helper loaded: my_helper
INFO - 2024-10-29 08:54:32 --> Database Driver Class Initialized
INFO - 2024-10-29 08:54:34 --> Upload Class Initialized
INFO - 2024-10-29 08:54:34 --> Email Class Initialized
INFO - 2024-10-29 08:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:54:34 --> Form Validation Class Initialized
INFO - 2024-10-29 08:54:34 --> Controller Class Initialized
INFO - 2024-10-29 14:24:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:24:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:24:34 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:18 --> Config Class Initialized
INFO - 2024-10-29 08:55:18 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:18 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:18 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:18 --> URI Class Initialized
INFO - 2024-10-29 08:55:18 --> Router Class Initialized
INFO - 2024-10-29 08:55:18 --> Output Class Initialized
INFO - 2024-10-29 08:55:18 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:18 --> Input Class Initialized
INFO - 2024-10-29 08:55:18 --> Language Class Initialized
INFO - 2024-10-29 08:55:18 --> Loader Class Initialized
INFO - 2024-10-29 08:55:18 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:18 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:18 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:18 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:18 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:18 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:18 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:20 --> Upload Class Initialized
INFO - 2024-10-29 08:55:20 --> Email Class Initialized
INFO - 2024-10-29 08:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:20 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:20 --> Controller Class Initialized
INFO - 2024-10-29 14:25:20 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:21 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:21 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:21 --> Config Class Initialized
INFO - 2024-10-29 08:55:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:21 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:21 --> URI Class Initialized
INFO - 2024-10-29 08:55:21 --> Router Class Initialized
INFO - 2024-10-29 08:55:21 --> Output Class Initialized
INFO - 2024-10-29 08:55:21 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:21 --> Input Class Initialized
INFO - 2024-10-29 08:55:21 --> Language Class Initialized
INFO - 2024-10-29 08:55:21 --> Loader Class Initialized
INFO - 2024-10-29 08:55:21 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:21 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:21 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:21 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:21 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:21 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:21 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:23 --> Upload Class Initialized
INFO - 2024-10-29 08:55:23 --> Email Class Initialized
INFO - 2024-10-29 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:23 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:23 --> Controller Class Initialized
INFO - 2024-10-29 14:25:23 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:23 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:23 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:25 --> Config Class Initialized
INFO - 2024-10-29 08:55:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:25 --> URI Class Initialized
INFO - 2024-10-29 08:55:25 --> Router Class Initialized
INFO - 2024-10-29 08:55:25 --> Output Class Initialized
INFO - 2024-10-29 08:55:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:25 --> Input Class Initialized
INFO - 2024-10-29 08:55:25 --> Language Class Initialized
INFO - 2024-10-29 08:55:25 --> Loader Class Initialized
INFO - 2024-10-29 08:55:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:27 --> Upload Class Initialized
INFO - 2024-10-29 08:55:27 --> Email Class Initialized
INFO - 2024-10-29 08:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:27 --> Controller Class Initialized
INFO - 2024-10-29 14:25:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:30 --> Config Class Initialized
INFO - 2024-10-29 08:55:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:30 --> URI Class Initialized
INFO - 2024-10-29 08:55:30 --> Router Class Initialized
INFO - 2024-10-29 08:55:30 --> Output Class Initialized
INFO - 2024-10-29 08:55:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:30 --> Input Class Initialized
INFO - 2024-10-29 08:55:30 --> Language Class Initialized
INFO - 2024-10-29 08:55:30 --> Loader Class Initialized
INFO - 2024-10-29 08:55:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:32 --> Upload Class Initialized
INFO - 2024-10-29 08:55:32 --> Email Class Initialized
INFO - 2024-10-29 08:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:32 --> Controller Class Initialized
INFO - 2024-10-29 14:25:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:33 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:35 --> Config Class Initialized
INFO - 2024-10-29 08:55:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:35 --> URI Class Initialized
INFO - 2024-10-29 08:55:35 --> Router Class Initialized
INFO - 2024-10-29 08:55:35 --> Output Class Initialized
INFO - 2024-10-29 08:55:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:35 --> Input Class Initialized
INFO - 2024-10-29 08:55:35 --> Language Class Initialized
INFO - 2024-10-29 08:55:35 --> Loader Class Initialized
INFO - 2024-10-29 08:55:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:37 --> Upload Class Initialized
INFO - 2024-10-29 08:55:37 --> Email Class Initialized
INFO - 2024-10-29 08:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:37 --> Controller Class Initialized
INFO - 2024-10-29 14:25:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:40 --> Config Class Initialized
INFO - 2024-10-29 08:55:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:40 --> URI Class Initialized
INFO - 2024-10-29 08:55:40 --> Router Class Initialized
INFO - 2024-10-29 08:55:40 --> Output Class Initialized
INFO - 2024-10-29 08:55:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:40 --> Input Class Initialized
INFO - 2024-10-29 08:55:40 --> Language Class Initialized
INFO - 2024-10-29 08:55:40 --> Loader Class Initialized
INFO - 2024-10-29 08:55:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:42 --> Upload Class Initialized
INFO - 2024-10-29 08:55:42 --> Email Class Initialized
INFO - 2024-10-29 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:42 --> Controller Class Initialized
INFO - 2024-10-29 14:25:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:43 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:45 --> Config Class Initialized
INFO - 2024-10-29 08:55:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:45 --> URI Class Initialized
INFO - 2024-10-29 08:55:45 --> Router Class Initialized
INFO - 2024-10-29 08:55:45 --> Output Class Initialized
INFO - 2024-10-29 08:55:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:45 --> Input Class Initialized
INFO - 2024-10-29 08:55:45 --> Language Class Initialized
INFO - 2024-10-29 08:55:45 --> Loader Class Initialized
INFO - 2024-10-29 08:55:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:47 --> Upload Class Initialized
INFO - 2024-10-29 08:55:47 --> Email Class Initialized
INFO - 2024-10-29 08:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:47 --> Controller Class Initialized
INFO - 2024-10-29 14:25:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:50 --> Config Class Initialized
INFO - 2024-10-29 08:55:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:50 --> URI Class Initialized
INFO - 2024-10-29 08:55:50 --> Router Class Initialized
INFO - 2024-10-29 08:55:50 --> Output Class Initialized
INFO - 2024-10-29 08:55:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:50 --> Input Class Initialized
INFO - 2024-10-29 08:55:50 --> Language Class Initialized
INFO - 2024-10-29 08:55:50 --> Loader Class Initialized
INFO - 2024-10-29 08:55:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:52 --> Upload Class Initialized
INFO - 2024-10-29 08:55:52 --> Email Class Initialized
INFO - 2024-10-29 08:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:52 --> Controller Class Initialized
INFO - 2024-10-29 14:25:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:55:55 --> Config Class Initialized
INFO - 2024-10-29 08:55:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:55:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:55:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:55:55 --> URI Class Initialized
INFO - 2024-10-29 08:55:55 --> Router Class Initialized
INFO - 2024-10-29 08:55:55 --> Output Class Initialized
INFO - 2024-10-29 08:55:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:55:55 --> Input Class Initialized
INFO - 2024-10-29 08:55:55 --> Language Class Initialized
INFO - 2024-10-29 08:55:55 --> Loader Class Initialized
INFO - 2024-10-29 08:55:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:55:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:55:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:55:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:55:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:55:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:55:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:55:57 --> Upload Class Initialized
INFO - 2024-10-29 08:55:57 --> Email Class Initialized
INFO - 2024-10-29 08:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:55:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:55:57 --> Controller Class Initialized
INFO - 2024-10-29 14:25:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:25:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:25:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:00 --> Config Class Initialized
INFO - 2024-10-29 08:56:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:00 --> URI Class Initialized
INFO - 2024-10-29 08:56:00 --> Router Class Initialized
INFO - 2024-10-29 08:56:00 --> Output Class Initialized
INFO - 2024-10-29 08:56:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:00 --> Input Class Initialized
INFO - 2024-10-29 08:56:00 --> Language Class Initialized
INFO - 2024-10-29 08:56:00 --> Loader Class Initialized
INFO - 2024-10-29 08:56:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:02 --> Upload Class Initialized
INFO - 2024-10-29 08:56:02 --> Email Class Initialized
INFO - 2024-10-29 08:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:02 --> Controller Class Initialized
INFO - 2024-10-29 14:26:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:05 --> Config Class Initialized
INFO - 2024-10-29 08:56:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:05 --> URI Class Initialized
INFO - 2024-10-29 08:56:05 --> Router Class Initialized
INFO - 2024-10-29 08:56:05 --> Output Class Initialized
INFO - 2024-10-29 08:56:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:05 --> Input Class Initialized
INFO - 2024-10-29 08:56:05 --> Language Class Initialized
INFO - 2024-10-29 08:56:05 --> Loader Class Initialized
INFO - 2024-10-29 08:56:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:07 --> Upload Class Initialized
INFO - 2024-10-29 08:56:07 --> Email Class Initialized
INFO - 2024-10-29 08:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:07 --> Controller Class Initialized
INFO - 2024-10-29 14:26:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:10 --> Config Class Initialized
INFO - 2024-10-29 08:56:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:10 --> URI Class Initialized
INFO - 2024-10-29 08:56:10 --> Router Class Initialized
INFO - 2024-10-29 08:56:10 --> Output Class Initialized
INFO - 2024-10-29 08:56:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:10 --> Input Class Initialized
INFO - 2024-10-29 08:56:10 --> Language Class Initialized
INFO - 2024-10-29 08:56:10 --> Loader Class Initialized
INFO - 2024-10-29 08:56:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:12 --> Upload Class Initialized
INFO - 2024-10-29 08:56:12 --> Email Class Initialized
INFO - 2024-10-29 08:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:12 --> Controller Class Initialized
INFO - 2024-10-29 14:26:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:13 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:15 --> Config Class Initialized
INFO - 2024-10-29 08:56:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:15 --> URI Class Initialized
INFO - 2024-10-29 08:56:15 --> Router Class Initialized
INFO - 2024-10-29 08:56:15 --> Output Class Initialized
INFO - 2024-10-29 08:56:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:15 --> Input Class Initialized
INFO - 2024-10-29 08:56:15 --> Language Class Initialized
INFO - 2024-10-29 08:56:15 --> Loader Class Initialized
INFO - 2024-10-29 08:56:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:16 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:18 --> Upload Class Initialized
INFO - 2024-10-29 08:56:18 --> Email Class Initialized
INFO - 2024-10-29 08:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:18 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:18 --> Controller Class Initialized
INFO - 2024-10-29 14:26:18 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:18 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:18 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:20 --> Config Class Initialized
INFO - 2024-10-29 08:56:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:20 --> URI Class Initialized
INFO - 2024-10-29 08:56:20 --> Router Class Initialized
INFO - 2024-10-29 08:56:20 --> Output Class Initialized
INFO - 2024-10-29 08:56:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:20 --> Input Class Initialized
INFO - 2024-10-29 08:56:20 --> Language Class Initialized
INFO - 2024-10-29 08:56:20 --> Loader Class Initialized
INFO - 2024-10-29 08:56:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:23 --> Upload Class Initialized
INFO - 2024-10-29 08:56:23 --> Email Class Initialized
INFO - 2024-10-29 08:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:23 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:23 --> Controller Class Initialized
INFO - 2024-10-29 14:26:23 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:23 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:23 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:25 --> Config Class Initialized
INFO - 2024-10-29 08:56:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:25 --> URI Class Initialized
INFO - 2024-10-29 08:56:25 --> Router Class Initialized
INFO - 2024-10-29 08:56:25 --> Output Class Initialized
INFO - 2024-10-29 08:56:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:25 --> Input Class Initialized
INFO - 2024-10-29 08:56:25 --> Language Class Initialized
INFO - 2024-10-29 08:56:25 --> Loader Class Initialized
INFO - 2024-10-29 08:56:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:26 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:26 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:26 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:26 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:26 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:26 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:28 --> Upload Class Initialized
INFO - 2024-10-29 08:56:28 --> Email Class Initialized
INFO - 2024-10-29 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:28 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:28 --> Controller Class Initialized
INFO - 2024-10-29 14:26:28 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:28 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:28 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:30 --> Config Class Initialized
INFO - 2024-10-29 08:56:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:30 --> URI Class Initialized
INFO - 2024-10-29 08:56:30 --> Router Class Initialized
INFO - 2024-10-29 08:56:30 --> Output Class Initialized
INFO - 2024-10-29 08:56:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:30 --> Input Class Initialized
INFO - 2024-10-29 08:56:30 --> Language Class Initialized
INFO - 2024-10-29 08:56:30 --> Loader Class Initialized
INFO - 2024-10-29 08:56:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:32 --> Upload Class Initialized
INFO - 2024-10-29 08:56:32 --> Email Class Initialized
INFO - 2024-10-29 08:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:32 --> Controller Class Initialized
INFO - 2024-10-29 14:26:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:35 --> Config Class Initialized
INFO - 2024-10-29 08:56:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:35 --> URI Class Initialized
INFO - 2024-10-29 08:56:35 --> Router Class Initialized
INFO - 2024-10-29 08:56:35 --> Output Class Initialized
INFO - 2024-10-29 08:56:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:35 --> Input Class Initialized
INFO - 2024-10-29 08:56:35 --> Language Class Initialized
INFO - 2024-10-29 08:56:35 --> Loader Class Initialized
INFO - 2024-10-29 08:56:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:37 --> Upload Class Initialized
INFO - 2024-10-29 08:56:37 --> Email Class Initialized
INFO - 2024-10-29 08:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:37 --> Controller Class Initialized
INFO - 2024-10-29 14:26:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:40 --> Config Class Initialized
INFO - 2024-10-29 08:56:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:40 --> URI Class Initialized
INFO - 2024-10-29 08:56:40 --> Router Class Initialized
INFO - 2024-10-29 08:56:40 --> Output Class Initialized
INFO - 2024-10-29 08:56:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:40 --> Input Class Initialized
INFO - 2024-10-29 08:56:40 --> Language Class Initialized
INFO - 2024-10-29 08:56:40 --> Loader Class Initialized
INFO - 2024-10-29 08:56:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:42 --> Upload Class Initialized
INFO - 2024-10-29 08:56:42 --> Email Class Initialized
INFO - 2024-10-29 08:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:42 --> Controller Class Initialized
INFO - 2024-10-29 14:26:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:45 --> Config Class Initialized
INFO - 2024-10-29 08:56:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:45 --> URI Class Initialized
INFO - 2024-10-29 08:56:45 --> Router Class Initialized
INFO - 2024-10-29 08:56:45 --> Output Class Initialized
INFO - 2024-10-29 08:56:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:45 --> Input Class Initialized
INFO - 2024-10-29 08:56:45 --> Language Class Initialized
INFO - 2024-10-29 08:56:45 --> Loader Class Initialized
INFO - 2024-10-29 08:56:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:47 --> Upload Class Initialized
INFO - 2024-10-29 08:56:47 --> Email Class Initialized
INFO - 2024-10-29 08:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:47 --> Controller Class Initialized
INFO - 2024-10-29 14:26:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:50 --> Config Class Initialized
INFO - 2024-10-29 08:56:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:50 --> URI Class Initialized
INFO - 2024-10-29 08:56:50 --> Router Class Initialized
INFO - 2024-10-29 08:56:50 --> Output Class Initialized
INFO - 2024-10-29 08:56:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:50 --> Input Class Initialized
INFO - 2024-10-29 08:56:50 --> Language Class Initialized
INFO - 2024-10-29 08:56:50 --> Loader Class Initialized
INFO - 2024-10-29 08:56:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:52 --> Upload Class Initialized
INFO - 2024-10-29 08:56:52 --> Email Class Initialized
INFO - 2024-10-29 08:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:52 --> Controller Class Initialized
INFO - 2024-10-29 14:26:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:56:55 --> Config Class Initialized
INFO - 2024-10-29 08:56:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:56:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:56:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:56:55 --> URI Class Initialized
INFO - 2024-10-29 08:56:55 --> Router Class Initialized
INFO - 2024-10-29 08:56:55 --> Output Class Initialized
INFO - 2024-10-29 08:56:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:56:55 --> Input Class Initialized
INFO - 2024-10-29 08:56:55 --> Language Class Initialized
INFO - 2024-10-29 08:56:55 --> Loader Class Initialized
INFO - 2024-10-29 08:56:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:56:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:56:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:56:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:56:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:56:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:56:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:56:57 --> Upload Class Initialized
INFO - 2024-10-29 08:56:57 --> Email Class Initialized
INFO - 2024-10-29 08:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:56:58 --> Form Validation Class Initialized
INFO - 2024-10-29 08:56:58 --> Controller Class Initialized
INFO - 2024-10-29 14:26:58 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:26:58 --> Model "MainModel" initialized
INFO - 2024-10-29 14:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:26:58 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:00 --> Config Class Initialized
INFO - 2024-10-29 08:57:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:00 --> URI Class Initialized
INFO - 2024-10-29 08:57:00 --> Router Class Initialized
INFO - 2024-10-29 08:57:00 --> Output Class Initialized
INFO - 2024-10-29 08:57:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:00 --> Input Class Initialized
INFO - 2024-10-29 08:57:00 --> Language Class Initialized
INFO - 2024-10-29 08:57:00 --> Loader Class Initialized
INFO - 2024-10-29 08:57:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:02 --> Upload Class Initialized
INFO - 2024-10-29 08:57:02 --> Email Class Initialized
INFO - 2024-10-29 08:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:02 --> Controller Class Initialized
INFO - 2024-10-29 14:27:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:05 --> Config Class Initialized
INFO - 2024-10-29 08:57:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:05 --> URI Class Initialized
INFO - 2024-10-29 08:57:05 --> Router Class Initialized
INFO - 2024-10-29 08:57:05 --> Output Class Initialized
INFO - 2024-10-29 08:57:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:05 --> Input Class Initialized
INFO - 2024-10-29 08:57:05 --> Language Class Initialized
INFO - 2024-10-29 08:57:05 --> Loader Class Initialized
INFO - 2024-10-29 08:57:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:07 --> Upload Class Initialized
INFO - 2024-10-29 08:57:07 --> Email Class Initialized
INFO - 2024-10-29 08:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:07 --> Controller Class Initialized
INFO - 2024-10-29 14:27:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:10 --> Config Class Initialized
INFO - 2024-10-29 08:57:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:10 --> URI Class Initialized
INFO - 2024-10-29 08:57:10 --> Router Class Initialized
INFO - 2024-10-29 08:57:10 --> Output Class Initialized
INFO - 2024-10-29 08:57:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:10 --> Input Class Initialized
INFO - 2024-10-29 08:57:10 --> Language Class Initialized
INFO - 2024-10-29 08:57:10 --> Loader Class Initialized
INFO - 2024-10-29 08:57:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:12 --> Upload Class Initialized
INFO - 2024-10-29 08:57:12 --> Email Class Initialized
INFO - 2024-10-29 08:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:12 --> Controller Class Initialized
INFO - 2024-10-29 14:27:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:15 --> Config Class Initialized
INFO - 2024-10-29 08:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:15 --> URI Class Initialized
INFO - 2024-10-29 08:57:15 --> Router Class Initialized
INFO - 2024-10-29 08:57:15 --> Output Class Initialized
INFO - 2024-10-29 08:57:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:15 --> Input Class Initialized
INFO - 2024-10-29 08:57:15 --> Language Class Initialized
INFO - 2024-10-29 08:57:15 --> Loader Class Initialized
INFO - 2024-10-29 08:57:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:17 --> Upload Class Initialized
INFO - 2024-10-29 08:57:17 --> Email Class Initialized
INFO - 2024-10-29 08:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:17 --> Controller Class Initialized
INFO - 2024-10-29 14:27:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:17 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:20 --> Config Class Initialized
INFO - 2024-10-29 08:57:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:20 --> URI Class Initialized
INFO - 2024-10-29 08:57:20 --> Router Class Initialized
INFO - 2024-10-29 08:57:20 --> Output Class Initialized
INFO - 2024-10-29 08:57:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:20 --> Input Class Initialized
INFO - 2024-10-29 08:57:20 --> Language Class Initialized
INFO - 2024-10-29 08:57:20 --> Loader Class Initialized
INFO - 2024-10-29 08:57:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:22 --> Upload Class Initialized
INFO - 2024-10-29 08:57:22 --> Email Class Initialized
INFO - 2024-10-29 08:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:22 --> Controller Class Initialized
INFO - 2024-10-29 14:27:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:25 --> Config Class Initialized
INFO - 2024-10-29 08:57:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:25 --> URI Class Initialized
INFO - 2024-10-29 08:57:25 --> Router Class Initialized
INFO - 2024-10-29 08:57:25 --> Output Class Initialized
INFO - 2024-10-29 08:57:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:25 --> Input Class Initialized
INFO - 2024-10-29 08:57:25 --> Language Class Initialized
INFO - 2024-10-29 08:57:25 --> Loader Class Initialized
INFO - 2024-10-29 08:57:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:27 --> Upload Class Initialized
INFO - 2024-10-29 08:57:27 --> Email Class Initialized
INFO - 2024-10-29 08:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:27 --> Controller Class Initialized
INFO - 2024-10-29 14:27:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:28 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:28 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:30 --> Config Class Initialized
INFO - 2024-10-29 08:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:30 --> URI Class Initialized
INFO - 2024-10-29 08:57:30 --> Router Class Initialized
INFO - 2024-10-29 08:57:30 --> Output Class Initialized
INFO - 2024-10-29 08:57:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:30 --> Input Class Initialized
INFO - 2024-10-29 08:57:30 --> Language Class Initialized
INFO - 2024-10-29 08:57:30 --> Loader Class Initialized
INFO - 2024-10-29 08:57:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:32 --> Upload Class Initialized
INFO - 2024-10-29 08:57:32 --> Email Class Initialized
INFO - 2024-10-29 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:32 --> Controller Class Initialized
INFO - 2024-10-29 14:27:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:35 --> Config Class Initialized
INFO - 2024-10-29 08:57:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:35 --> URI Class Initialized
INFO - 2024-10-29 08:57:35 --> Router Class Initialized
INFO - 2024-10-29 08:57:35 --> Output Class Initialized
INFO - 2024-10-29 08:57:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:35 --> Input Class Initialized
INFO - 2024-10-29 08:57:35 --> Language Class Initialized
INFO - 2024-10-29 08:57:35 --> Loader Class Initialized
INFO - 2024-10-29 08:57:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:37 --> Upload Class Initialized
INFO - 2024-10-29 08:57:37 --> Email Class Initialized
INFO - 2024-10-29 08:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:37 --> Controller Class Initialized
INFO - 2024-10-29 14:27:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:40 --> Config Class Initialized
INFO - 2024-10-29 08:57:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:40 --> URI Class Initialized
INFO - 2024-10-29 08:57:40 --> Router Class Initialized
INFO - 2024-10-29 08:57:40 --> Output Class Initialized
INFO - 2024-10-29 08:57:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:40 --> Input Class Initialized
INFO - 2024-10-29 08:57:40 --> Language Class Initialized
INFO - 2024-10-29 08:57:40 --> Loader Class Initialized
INFO - 2024-10-29 08:57:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:42 --> Upload Class Initialized
INFO - 2024-10-29 08:57:42 --> Email Class Initialized
INFO - 2024-10-29 08:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:42 --> Controller Class Initialized
INFO - 2024-10-29 14:27:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:45 --> Config Class Initialized
INFO - 2024-10-29 08:57:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:45 --> URI Class Initialized
INFO - 2024-10-29 08:57:45 --> Router Class Initialized
INFO - 2024-10-29 08:57:45 --> Output Class Initialized
INFO - 2024-10-29 08:57:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:45 --> Input Class Initialized
INFO - 2024-10-29 08:57:45 --> Language Class Initialized
INFO - 2024-10-29 08:57:45 --> Loader Class Initialized
INFO - 2024-10-29 08:57:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:47 --> Upload Class Initialized
INFO - 2024-10-29 08:57:47 --> Email Class Initialized
INFO - 2024-10-29 08:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:48 --> Controller Class Initialized
INFO - 2024-10-29 14:27:48 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:48 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:48 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:50 --> Config Class Initialized
INFO - 2024-10-29 08:57:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:50 --> URI Class Initialized
INFO - 2024-10-29 08:57:50 --> Router Class Initialized
INFO - 2024-10-29 08:57:50 --> Output Class Initialized
INFO - 2024-10-29 08:57:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:50 --> Input Class Initialized
INFO - 2024-10-29 08:57:50 --> Language Class Initialized
INFO - 2024-10-29 08:57:50 --> Loader Class Initialized
INFO - 2024-10-29 08:57:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:52 --> Upload Class Initialized
INFO - 2024-10-29 08:57:52 --> Email Class Initialized
INFO - 2024-10-29 08:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:52 --> Controller Class Initialized
INFO - 2024-10-29 14:27:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:57:55 --> Config Class Initialized
INFO - 2024-10-29 08:57:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:57:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:57:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:57:55 --> URI Class Initialized
INFO - 2024-10-29 08:57:55 --> Router Class Initialized
INFO - 2024-10-29 08:57:55 --> Output Class Initialized
INFO - 2024-10-29 08:57:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:57:55 --> Input Class Initialized
INFO - 2024-10-29 08:57:55 --> Language Class Initialized
INFO - 2024-10-29 08:57:55 --> Loader Class Initialized
INFO - 2024-10-29 08:57:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:57:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:57:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:57:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:57:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:57:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:57:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:57:57 --> Upload Class Initialized
INFO - 2024-10-29 08:57:57 --> Email Class Initialized
INFO - 2024-10-29 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:57:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:57:57 --> Controller Class Initialized
INFO - 2024-10-29 14:27:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:27:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:27:57 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:00 --> Config Class Initialized
INFO - 2024-10-29 08:58:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:00 --> URI Class Initialized
INFO - 2024-10-29 08:58:00 --> Router Class Initialized
INFO - 2024-10-29 08:58:00 --> Output Class Initialized
INFO - 2024-10-29 08:58:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:00 --> Input Class Initialized
INFO - 2024-10-29 08:58:00 --> Language Class Initialized
INFO - 2024-10-29 08:58:00 --> Loader Class Initialized
INFO - 2024-10-29 08:58:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:00 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:00 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:00 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:00 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:00 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:00 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:02 --> Upload Class Initialized
INFO - 2024-10-29 08:58:02 --> Email Class Initialized
INFO - 2024-10-29 08:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:02 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:02 --> Controller Class Initialized
INFO - 2024-10-29 14:28:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:02 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:05 --> Config Class Initialized
INFO - 2024-10-29 08:58:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:05 --> URI Class Initialized
INFO - 2024-10-29 08:58:05 --> Router Class Initialized
INFO - 2024-10-29 08:58:05 --> Output Class Initialized
INFO - 2024-10-29 08:58:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:05 --> Input Class Initialized
INFO - 2024-10-29 08:58:05 --> Language Class Initialized
INFO - 2024-10-29 08:58:05 --> Loader Class Initialized
INFO - 2024-10-29 08:58:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:07 --> Upload Class Initialized
INFO - 2024-10-29 08:58:07 --> Email Class Initialized
INFO - 2024-10-29 08:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:07 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:07 --> Controller Class Initialized
INFO - 2024-10-29 14:28:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:07 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:10 --> Config Class Initialized
INFO - 2024-10-29 08:58:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:10 --> URI Class Initialized
INFO - 2024-10-29 08:58:10 --> Router Class Initialized
INFO - 2024-10-29 08:58:10 --> Output Class Initialized
INFO - 2024-10-29 08:58:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:10 --> Input Class Initialized
INFO - 2024-10-29 08:58:10 --> Language Class Initialized
INFO - 2024-10-29 08:58:10 --> Loader Class Initialized
INFO - 2024-10-29 08:58:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:12 --> Upload Class Initialized
INFO - 2024-10-29 08:58:12 --> Email Class Initialized
INFO - 2024-10-29 08:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:12 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:12 --> Controller Class Initialized
INFO - 2024-10-29 14:28:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:12 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:15 --> Config Class Initialized
INFO - 2024-10-29 08:58:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:15 --> URI Class Initialized
INFO - 2024-10-29 08:58:15 --> Router Class Initialized
INFO - 2024-10-29 08:58:15 --> Output Class Initialized
INFO - 2024-10-29 08:58:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:15 --> Input Class Initialized
INFO - 2024-10-29 08:58:15 --> Language Class Initialized
INFO - 2024-10-29 08:58:15 --> Loader Class Initialized
INFO - 2024-10-29 08:58:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:17 --> Upload Class Initialized
INFO - 2024-10-29 08:58:17 --> Email Class Initialized
INFO - 2024-10-29 08:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:17 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:17 --> Controller Class Initialized
INFO - 2024-10-29 14:28:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:17 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:17 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:20 --> Config Class Initialized
INFO - 2024-10-29 08:58:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:20 --> URI Class Initialized
INFO - 2024-10-29 08:58:20 --> Router Class Initialized
INFO - 2024-10-29 08:58:20 --> Output Class Initialized
INFO - 2024-10-29 08:58:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:20 --> Input Class Initialized
INFO - 2024-10-29 08:58:20 --> Language Class Initialized
INFO - 2024-10-29 08:58:20 --> Loader Class Initialized
INFO - 2024-10-29 08:58:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:20 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:20 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:20 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:20 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:20 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:22 --> Upload Class Initialized
INFO - 2024-10-29 08:58:22 --> Email Class Initialized
INFO - 2024-10-29 08:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:22 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:22 --> Controller Class Initialized
INFO - 2024-10-29 14:28:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:22 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:25 --> Config Class Initialized
INFO - 2024-10-29 08:58:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:25 --> URI Class Initialized
INFO - 2024-10-29 08:58:25 --> Router Class Initialized
INFO - 2024-10-29 08:58:25 --> Output Class Initialized
INFO - 2024-10-29 08:58:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:25 --> Input Class Initialized
INFO - 2024-10-29 08:58:25 --> Language Class Initialized
INFO - 2024-10-29 08:58:25 --> Loader Class Initialized
INFO - 2024-10-29 08:58:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:27 --> Upload Class Initialized
INFO - 2024-10-29 08:58:27 --> Email Class Initialized
INFO - 2024-10-29 08:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:27 --> Controller Class Initialized
INFO - 2024-10-29 14:28:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:30 --> Config Class Initialized
INFO - 2024-10-29 08:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:30 --> URI Class Initialized
INFO - 2024-10-29 08:58:30 --> Router Class Initialized
INFO - 2024-10-29 08:58:30 --> Output Class Initialized
INFO - 2024-10-29 08:58:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:30 --> Input Class Initialized
INFO - 2024-10-29 08:58:30 --> Language Class Initialized
INFO - 2024-10-29 08:58:30 --> Loader Class Initialized
INFO - 2024-10-29 08:58:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:32 --> Upload Class Initialized
INFO - 2024-10-29 08:58:32 --> Email Class Initialized
INFO - 2024-10-29 08:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:32 --> Controller Class Initialized
INFO - 2024-10-29 14:28:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:35 --> Config Class Initialized
INFO - 2024-10-29 08:58:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:35 --> URI Class Initialized
INFO - 2024-10-29 08:58:35 --> Router Class Initialized
INFO - 2024-10-29 08:58:35 --> Output Class Initialized
INFO - 2024-10-29 08:58:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:35 --> Input Class Initialized
INFO - 2024-10-29 08:58:35 --> Language Class Initialized
INFO - 2024-10-29 08:58:35 --> Loader Class Initialized
INFO - 2024-10-29 08:58:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:37 --> Upload Class Initialized
INFO - 2024-10-29 08:58:37 --> Email Class Initialized
INFO - 2024-10-29 08:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:37 --> Controller Class Initialized
INFO - 2024-10-29 14:28:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:40 --> Config Class Initialized
INFO - 2024-10-29 08:58:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:40 --> URI Class Initialized
INFO - 2024-10-29 08:58:40 --> Router Class Initialized
INFO - 2024-10-29 08:58:40 --> Output Class Initialized
INFO - 2024-10-29 08:58:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:40 --> Input Class Initialized
INFO - 2024-10-29 08:58:40 --> Language Class Initialized
INFO - 2024-10-29 08:58:40 --> Loader Class Initialized
INFO - 2024-10-29 08:58:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:42 --> Upload Class Initialized
INFO - 2024-10-29 08:58:42 --> Email Class Initialized
INFO - 2024-10-29 08:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:42 --> Controller Class Initialized
INFO - 2024-10-29 14:28:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:45 --> Config Class Initialized
INFO - 2024-10-29 08:58:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:45 --> URI Class Initialized
INFO - 2024-10-29 08:58:45 --> Router Class Initialized
INFO - 2024-10-29 08:58:45 --> Output Class Initialized
INFO - 2024-10-29 08:58:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:45 --> Input Class Initialized
INFO - 2024-10-29 08:58:45 --> Language Class Initialized
INFO - 2024-10-29 08:58:45 --> Loader Class Initialized
INFO - 2024-10-29 08:58:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:47 --> Upload Class Initialized
INFO - 2024-10-29 08:58:47 --> Email Class Initialized
INFO - 2024-10-29 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:47 --> Controller Class Initialized
INFO - 2024-10-29 14:28:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:50 --> Config Class Initialized
INFO - 2024-10-29 08:58:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:50 --> URI Class Initialized
INFO - 2024-10-29 08:58:50 --> Router Class Initialized
INFO - 2024-10-29 08:58:50 --> Output Class Initialized
INFO - 2024-10-29 08:58:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:50 --> Input Class Initialized
INFO - 2024-10-29 08:58:50 --> Language Class Initialized
INFO - 2024-10-29 08:58:50 --> Loader Class Initialized
INFO - 2024-10-29 08:58:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:52 --> Upload Class Initialized
INFO - 2024-10-29 08:58:52 --> Email Class Initialized
INFO - 2024-10-29 08:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:53 --> Controller Class Initialized
INFO - 2024-10-29 14:28:53 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:53 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:53 --> Pagination Class Initialized
INFO - 2024-10-29 08:58:55 --> Config Class Initialized
INFO - 2024-10-29 08:58:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:58:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:58:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:58:55 --> URI Class Initialized
INFO - 2024-10-29 08:58:55 --> Router Class Initialized
INFO - 2024-10-29 08:58:55 --> Output Class Initialized
INFO - 2024-10-29 08:58:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:58:55 --> Input Class Initialized
INFO - 2024-10-29 08:58:55 --> Language Class Initialized
INFO - 2024-10-29 08:58:55 --> Loader Class Initialized
INFO - 2024-10-29 08:58:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:58:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:58:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:58:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:58:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:58:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:58:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:58:57 --> Upload Class Initialized
INFO - 2024-10-29 08:58:58 --> Email Class Initialized
INFO - 2024-10-29 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:58:58 --> Form Validation Class Initialized
INFO - 2024-10-29 08:58:58 --> Controller Class Initialized
INFO - 2024-10-29 14:28:58 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:28:58 --> Model "MainModel" initialized
INFO - 2024-10-29 14:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:28:58 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:00 --> Config Class Initialized
INFO - 2024-10-29 08:59:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:00 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:00 --> URI Class Initialized
INFO - 2024-10-29 08:59:00 --> Router Class Initialized
INFO - 2024-10-29 08:59:00 --> Output Class Initialized
INFO - 2024-10-29 08:59:00 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:00 --> Input Class Initialized
INFO - 2024-10-29 08:59:00 --> Language Class Initialized
INFO - 2024-10-29 08:59:00 --> Loader Class Initialized
INFO - 2024-10-29 08:59:00 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:01 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:01 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:01 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:01 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:01 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:01 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:03 --> Upload Class Initialized
INFO - 2024-10-29 08:59:03 --> Email Class Initialized
INFO - 2024-10-29 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:03 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:03 --> Controller Class Initialized
INFO - 2024-10-29 14:29:03 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:03 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:03 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:05 --> Config Class Initialized
INFO - 2024-10-29 08:59:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:05 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:05 --> URI Class Initialized
INFO - 2024-10-29 08:59:05 --> Router Class Initialized
INFO - 2024-10-29 08:59:05 --> Output Class Initialized
INFO - 2024-10-29 08:59:05 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:05 --> Input Class Initialized
INFO - 2024-10-29 08:59:05 --> Language Class Initialized
INFO - 2024-10-29 08:59:05 --> Loader Class Initialized
INFO - 2024-10-29 08:59:05 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:05 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:05 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:05 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:05 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:05 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:05 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:07 --> Upload Class Initialized
INFO - 2024-10-29 08:59:08 --> Email Class Initialized
INFO - 2024-10-29 08:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:08 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:08 --> Controller Class Initialized
INFO - 2024-10-29 14:29:08 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:08 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:08 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:10 --> Config Class Initialized
INFO - 2024-10-29 08:59:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:10 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:10 --> URI Class Initialized
INFO - 2024-10-29 08:59:10 --> Router Class Initialized
INFO - 2024-10-29 08:59:10 --> Output Class Initialized
INFO - 2024-10-29 08:59:10 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:10 --> Input Class Initialized
INFO - 2024-10-29 08:59:10 --> Language Class Initialized
INFO - 2024-10-29 08:59:10 --> Loader Class Initialized
INFO - 2024-10-29 08:59:10 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:10 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:10 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:10 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:10 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:10 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:10 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:12 --> Upload Class Initialized
INFO - 2024-10-29 08:59:12 --> Email Class Initialized
INFO - 2024-10-29 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:13 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:13 --> Controller Class Initialized
INFO - 2024-10-29 14:29:13 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:13 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:13 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:15 --> Config Class Initialized
INFO - 2024-10-29 08:59:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:15 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:15 --> URI Class Initialized
INFO - 2024-10-29 08:59:15 --> Router Class Initialized
INFO - 2024-10-29 08:59:15 --> Output Class Initialized
INFO - 2024-10-29 08:59:15 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:15 --> Input Class Initialized
INFO - 2024-10-29 08:59:15 --> Language Class Initialized
INFO - 2024-10-29 08:59:15 --> Loader Class Initialized
INFO - 2024-10-29 08:59:15 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:15 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:15 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:15 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:15 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:15 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:15 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:17 --> Upload Class Initialized
INFO - 2024-10-29 08:59:17 --> Email Class Initialized
INFO - 2024-10-29 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:18 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:18 --> Controller Class Initialized
INFO - 2024-10-29 14:29:18 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:18 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:18 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:20 --> Config Class Initialized
INFO - 2024-10-29 08:59:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:20 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:20 --> URI Class Initialized
INFO - 2024-10-29 08:59:20 --> Router Class Initialized
INFO - 2024-10-29 08:59:20 --> Output Class Initialized
INFO - 2024-10-29 08:59:20 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:20 --> Input Class Initialized
INFO - 2024-10-29 08:59:20 --> Language Class Initialized
INFO - 2024-10-29 08:59:20 --> Loader Class Initialized
INFO - 2024-10-29 08:59:20 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:20 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:21 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:21 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:21 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:21 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:21 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:23 --> Upload Class Initialized
INFO - 2024-10-29 08:59:23 --> Email Class Initialized
INFO - 2024-10-29 08:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:23 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:23 --> Controller Class Initialized
INFO - 2024-10-29 14:29:23 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:23 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:23 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:25 --> Config Class Initialized
INFO - 2024-10-29 08:59:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:25 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:25 --> URI Class Initialized
INFO - 2024-10-29 08:59:25 --> Router Class Initialized
INFO - 2024-10-29 08:59:25 --> Output Class Initialized
INFO - 2024-10-29 08:59:25 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:25 --> Input Class Initialized
INFO - 2024-10-29 08:59:25 --> Language Class Initialized
INFO - 2024-10-29 08:59:25 --> Loader Class Initialized
INFO - 2024-10-29 08:59:25 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:25 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:25 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:25 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:25 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:25 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:25 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:27 --> Upload Class Initialized
INFO - 2024-10-29 08:59:27 --> Email Class Initialized
INFO - 2024-10-29 08:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:27 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:27 --> Controller Class Initialized
INFO - 2024-10-29 14:29:27 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:27 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:27 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:30 --> Config Class Initialized
INFO - 2024-10-29 08:59:30 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:30 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:30 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:30 --> URI Class Initialized
INFO - 2024-10-29 08:59:30 --> Router Class Initialized
INFO - 2024-10-29 08:59:30 --> Output Class Initialized
INFO - 2024-10-29 08:59:30 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:30 --> Input Class Initialized
INFO - 2024-10-29 08:59:30 --> Language Class Initialized
INFO - 2024-10-29 08:59:30 --> Loader Class Initialized
INFO - 2024-10-29 08:59:30 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:30 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:30 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:30 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:30 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:30 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:30 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:32 --> Upload Class Initialized
INFO - 2024-10-29 08:59:32 --> Email Class Initialized
INFO - 2024-10-29 08:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:32 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:32 --> Controller Class Initialized
INFO - 2024-10-29 14:29:32 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:32 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:32 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:35 --> Config Class Initialized
INFO - 2024-10-29 08:59:35 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:35 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:35 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:35 --> URI Class Initialized
INFO - 2024-10-29 08:59:35 --> Router Class Initialized
INFO - 2024-10-29 08:59:35 --> Output Class Initialized
INFO - 2024-10-29 08:59:35 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:35 --> Input Class Initialized
INFO - 2024-10-29 08:59:35 --> Language Class Initialized
INFO - 2024-10-29 08:59:35 --> Loader Class Initialized
INFO - 2024-10-29 08:59:35 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:35 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:35 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:35 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:35 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:35 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:35 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:37 --> Upload Class Initialized
INFO - 2024-10-29 08:59:37 --> Email Class Initialized
INFO - 2024-10-29 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:37 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:37 --> Controller Class Initialized
INFO - 2024-10-29 14:29:37 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:37 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:37 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:40 --> Config Class Initialized
INFO - 2024-10-29 08:59:40 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:40 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:40 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:40 --> URI Class Initialized
INFO - 2024-10-29 08:59:40 --> Router Class Initialized
INFO - 2024-10-29 08:59:40 --> Output Class Initialized
INFO - 2024-10-29 08:59:40 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:40 --> Input Class Initialized
INFO - 2024-10-29 08:59:40 --> Language Class Initialized
INFO - 2024-10-29 08:59:40 --> Loader Class Initialized
INFO - 2024-10-29 08:59:40 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:40 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:40 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:40 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:40 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:40 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:40 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:42 --> Upload Class Initialized
INFO - 2024-10-29 08:59:42 --> Email Class Initialized
INFO - 2024-10-29 08:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:42 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:42 --> Controller Class Initialized
INFO - 2024-10-29 14:29:42 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:42 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:42 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:45 --> Config Class Initialized
INFO - 2024-10-29 08:59:45 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:45 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:45 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:45 --> URI Class Initialized
INFO - 2024-10-29 08:59:45 --> Router Class Initialized
INFO - 2024-10-29 08:59:45 --> Output Class Initialized
INFO - 2024-10-29 08:59:45 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:45 --> Input Class Initialized
INFO - 2024-10-29 08:59:45 --> Language Class Initialized
INFO - 2024-10-29 08:59:45 --> Loader Class Initialized
INFO - 2024-10-29 08:59:45 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:45 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:45 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:45 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:45 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:45 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:45 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:47 --> Upload Class Initialized
INFO - 2024-10-29 08:59:47 --> Email Class Initialized
INFO - 2024-10-29 08:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:47 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:47 --> Controller Class Initialized
INFO - 2024-10-29 14:29:47 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:47 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:47 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:50 --> Config Class Initialized
INFO - 2024-10-29 08:59:50 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:50 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:50 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:50 --> URI Class Initialized
INFO - 2024-10-29 08:59:50 --> Router Class Initialized
INFO - 2024-10-29 08:59:50 --> Output Class Initialized
INFO - 2024-10-29 08:59:50 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:50 --> Input Class Initialized
INFO - 2024-10-29 08:59:50 --> Language Class Initialized
INFO - 2024-10-29 08:59:50 --> Loader Class Initialized
INFO - 2024-10-29 08:59:50 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:50 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:50 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:50 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:50 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:50 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:50 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:52 --> Upload Class Initialized
INFO - 2024-10-29 08:59:52 --> Email Class Initialized
INFO - 2024-10-29 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:52 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:52 --> Controller Class Initialized
INFO - 2024-10-29 14:29:52 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:52 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:52 --> Pagination Class Initialized
INFO - 2024-10-29 08:59:55 --> Config Class Initialized
INFO - 2024-10-29 08:59:55 --> Hooks Class Initialized
DEBUG - 2024-10-29 08:59:55 --> UTF-8 Support Enabled
INFO - 2024-10-29 08:59:55 --> Utf8 Class Initialized
INFO - 2024-10-29 08:59:55 --> URI Class Initialized
INFO - 2024-10-29 08:59:55 --> Router Class Initialized
INFO - 2024-10-29 08:59:55 --> Output Class Initialized
INFO - 2024-10-29 08:59:55 --> Security Class Initialized
DEBUG - 2024-10-29 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 08:59:55 --> Input Class Initialized
INFO - 2024-10-29 08:59:55 --> Language Class Initialized
INFO - 2024-10-29 08:59:55 --> Loader Class Initialized
INFO - 2024-10-29 08:59:55 --> Helper loaded: url_helper
INFO - 2024-10-29 08:59:55 --> Helper loaded: html_helper
INFO - 2024-10-29 08:59:55 --> Helper loaded: file_helper
INFO - 2024-10-29 08:59:55 --> Helper loaded: string_helper
INFO - 2024-10-29 08:59:55 --> Helper loaded: form_helper
INFO - 2024-10-29 08:59:55 --> Helper loaded: my_helper
INFO - 2024-10-29 08:59:55 --> Database Driver Class Initialized
INFO - 2024-10-29 08:59:57 --> Upload Class Initialized
INFO - 2024-10-29 08:59:57 --> Email Class Initialized
INFO - 2024-10-29 08:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 08:59:57 --> Form Validation Class Initialized
INFO - 2024-10-29 08:59:57 --> Controller Class Initialized
INFO - 2024-10-29 14:29:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:29:57 --> Model "MainModel" initialized
INFO - 2024-10-29 14:29:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:29:57 --> Pagination Class Initialized
INFO - 2024-10-29 09:00:00 --> Config Class Initialized
INFO - 2024-10-29 09:00:00 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:00:00 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:00:00 --> Utf8 Class Initialized
INFO - 2024-10-29 09:00:00 --> URI Class Initialized
INFO - 2024-10-29 09:00:00 --> Router Class Initialized
INFO - 2024-10-29 09:00:00 --> Output Class Initialized
INFO - 2024-10-29 09:00:00 --> Security Class Initialized
DEBUG - 2024-10-29 09:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:00:00 --> Input Class Initialized
INFO - 2024-10-29 09:00:00 --> Language Class Initialized
INFO - 2024-10-29 09:00:00 --> Loader Class Initialized
INFO - 2024-10-29 09:00:00 --> Helper loaded: url_helper
INFO - 2024-10-29 09:00:00 --> Helper loaded: html_helper
INFO - 2024-10-29 09:00:00 --> Helper loaded: file_helper
INFO - 2024-10-29 09:00:00 --> Helper loaded: string_helper
INFO - 2024-10-29 09:00:00 --> Helper loaded: form_helper
INFO - 2024-10-29 09:00:00 --> Helper loaded: my_helper
INFO - 2024-10-29 09:00:00 --> Database Driver Class Initialized
INFO - 2024-10-29 09:00:02 --> Upload Class Initialized
INFO - 2024-10-29 09:00:02 --> Email Class Initialized
INFO - 2024-10-29 09:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:00:02 --> Form Validation Class Initialized
INFO - 2024-10-29 09:00:02 --> Controller Class Initialized
INFO - 2024-10-29 14:30:02 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:30:02 --> Model "MainModel" initialized
INFO - 2024-10-29 14:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:30:02 --> Pagination Class Initialized
INFO - 2024-10-29 09:00:05 --> Config Class Initialized
INFO - 2024-10-29 09:00:05 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:00:05 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:00:05 --> Utf8 Class Initialized
INFO - 2024-10-29 09:00:05 --> URI Class Initialized
INFO - 2024-10-29 09:00:05 --> Router Class Initialized
INFO - 2024-10-29 09:00:05 --> Output Class Initialized
INFO - 2024-10-29 09:00:05 --> Security Class Initialized
DEBUG - 2024-10-29 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:00:05 --> Input Class Initialized
INFO - 2024-10-29 09:00:05 --> Language Class Initialized
INFO - 2024-10-29 09:00:05 --> Loader Class Initialized
INFO - 2024-10-29 09:00:05 --> Helper loaded: url_helper
INFO - 2024-10-29 09:00:05 --> Helper loaded: html_helper
INFO - 2024-10-29 09:00:05 --> Helper loaded: file_helper
INFO - 2024-10-29 09:00:05 --> Helper loaded: string_helper
INFO - 2024-10-29 09:00:05 --> Helper loaded: form_helper
INFO - 2024-10-29 09:00:05 --> Helper loaded: my_helper
INFO - 2024-10-29 09:00:05 --> Database Driver Class Initialized
INFO - 2024-10-29 09:00:07 --> Upload Class Initialized
INFO - 2024-10-29 09:00:07 --> Email Class Initialized
INFO - 2024-10-29 09:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:00:07 --> Form Validation Class Initialized
INFO - 2024-10-29 09:00:07 --> Controller Class Initialized
INFO - 2024-10-29 14:30:07 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:30:07 --> Model "MainModel" initialized
INFO - 2024-10-29 14:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:30:07 --> Pagination Class Initialized
INFO - 2024-10-29 09:00:10 --> Config Class Initialized
INFO - 2024-10-29 09:00:10 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:00:10 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:00:10 --> Utf8 Class Initialized
INFO - 2024-10-29 09:00:10 --> URI Class Initialized
INFO - 2024-10-29 09:00:10 --> Router Class Initialized
INFO - 2024-10-29 09:00:10 --> Output Class Initialized
INFO - 2024-10-29 09:00:10 --> Security Class Initialized
DEBUG - 2024-10-29 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:00:10 --> Input Class Initialized
INFO - 2024-10-29 09:00:10 --> Language Class Initialized
INFO - 2024-10-29 09:00:10 --> Loader Class Initialized
INFO - 2024-10-29 09:00:10 --> Helper loaded: url_helper
INFO - 2024-10-29 09:00:10 --> Helper loaded: html_helper
INFO - 2024-10-29 09:00:10 --> Helper loaded: file_helper
INFO - 2024-10-29 09:00:10 --> Helper loaded: string_helper
INFO - 2024-10-29 09:00:10 --> Helper loaded: form_helper
INFO - 2024-10-29 09:00:10 --> Helper loaded: my_helper
INFO - 2024-10-29 09:00:10 --> Database Driver Class Initialized
INFO - 2024-10-29 09:00:12 --> Upload Class Initialized
INFO - 2024-10-29 09:00:12 --> Email Class Initialized
INFO - 2024-10-29 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:00:12 --> Form Validation Class Initialized
INFO - 2024-10-29 09:00:12 --> Controller Class Initialized
INFO - 2024-10-29 14:30:12 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:30:12 --> Model "MainModel" initialized
INFO - 2024-10-29 14:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:30:12 --> Pagination Class Initialized
INFO - 2024-10-29 09:00:15 --> Config Class Initialized
INFO - 2024-10-29 09:00:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:00:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:00:15 --> Utf8 Class Initialized
INFO - 2024-10-29 09:00:15 --> URI Class Initialized
INFO - 2024-10-29 09:00:15 --> Router Class Initialized
INFO - 2024-10-29 09:00:15 --> Output Class Initialized
INFO - 2024-10-29 09:00:15 --> Security Class Initialized
DEBUG - 2024-10-29 09:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:00:15 --> Input Class Initialized
INFO - 2024-10-29 09:00:15 --> Language Class Initialized
INFO - 2024-10-29 09:00:15 --> Loader Class Initialized
INFO - 2024-10-29 09:00:15 --> Helper loaded: url_helper
INFO - 2024-10-29 09:00:15 --> Helper loaded: html_helper
INFO - 2024-10-29 09:00:15 --> Helper loaded: file_helper
INFO - 2024-10-29 09:00:15 --> Helper loaded: string_helper
INFO - 2024-10-29 09:00:15 --> Helper loaded: form_helper
INFO - 2024-10-29 09:00:15 --> Helper loaded: my_helper
INFO - 2024-10-29 09:00:15 --> Database Driver Class Initialized
INFO - 2024-10-29 09:00:17 --> Upload Class Initialized
INFO - 2024-10-29 09:00:17 --> Email Class Initialized
INFO - 2024-10-29 09:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:00:17 --> Form Validation Class Initialized
INFO - 2024-10-29 09:00:17 --> Controller Class Initialized
INFO - 2024-10-29 14:30:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:30:17 --> Model "MainModel" initialized
INFO - 2024-10-29 14:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:30:17 --> Pagination Class Initialized
INFO - 2024-10-29 09:00:20 --> Config Class Initialized
INFO - 2024-10-29 09:00:20 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:00:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:00:20 --> Utf8 Class Initialized
INFO - 2024-10-29 09:00:20 --> URI Class Initialized
INFO - 2024-10-29 09:00:20 --> Router Class Initialized
INFO - 2024-10-29 09:00:20 --> Output Class Initialized
INFO - 2024-10-29 09:00:20 --> Security Class Initialized
DEBUG - 2024-10-29 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:00:20 --> Input Class Initialized
INFO - 2024-10-29 09:00:20 --> Language Class Initialized
INFO - 2024-10-29 09:00:20 --> Loader Class Initialized
INFO - 2024-10-29 09:00:20 --> Helper loaded: url_helper
INFO - 2024-10-29 09:00:20 --> Helper loaded: html_helper
INFO - 2024-10-29 09:00:20 --> Helper loaded: file_helper
INFO - 2024-10-29 09:00:20 --> Helper loaded: string_helper
INFO - 2024-10-29 09:00:20 --> Helper loaded: form_helper
INFO - 2024-10-29 09:00:20 --> Helper loaded: my_helper
INFO - 2024-10-29 09:00:20 --> Database Driver Class Initialized
INFO - 2024-10-29 09:00:22 --> Upload Class Initialized
INFO - 2024-10-29 09:00:22 --> Email Class Initialized
INFO - 2024-10-29 09:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:00:22 --> Form Validation Class Initialized
INFO - 2024-10-29 09:00:22 --> Controller Class Initialized
INFO - 2024-10-29 14:30:22 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:30:22 --> Model "MainModel" initialized
INFO - 2024-10-29 14:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:30:22 --> Pagination Class Initialized
INFO - 2024-10-29 09:00:32 --> Config Class Initialized
INFO - 2024-10-29 09:00:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:00:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:00:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:00:32 --> URI Class Initialized
INFO - 2024-10-29 09:00:32 --> Router Class Initialized
INFO - 2024-10-29 09:00:32 --> Output Class Initialized
INFO - 2024-10-29 09:00:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:00:32 --> Input Class Initialized
INFO - 2024-10-29 09:00:32 --> Language Class Initialized
INFO - 2024-10-29 09:00:32 --> Loader Class Initialized
INFO - 2024-10-29 09:00:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:00:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:00:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:00:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:00:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:00:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:00:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:00:34 --> Upload Class Initialized
INFO - 2024-10-29 09:00:34 --> Email Class Initialized
INFO - 2024-10-29 09:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:00:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:00:34 --> Controller Class Initialized
INFO - 2024-10-29 14:30:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:30:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:30:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:01:32 --> Config Class Initialized
INFO - 2024-10-29 09:01:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:01:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:01:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:01:32 --> URI Class Initialized
INFO - 2024-10-29 09:01:32 --> Router Class Initialized
INFO - 2024-10-29 09:01:32 --> Output Class Initialized
INFO - 2024-10-29 09:01:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:01:32 --> Input Class Initialized
INFO - 2024-10-29 09:01:32 --> Language Class Initialized
INFO - 2024-10-29 09:01:32 --> Loader Class Initialized
INFO - 2024-10-29 09:01:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:01:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:01:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:01:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:01:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:01:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:01:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:01:35 --> Upload Class Initialized
INFO - 2024-10-29 09:01:35 --> Email Class Initialized
INFO - 2024-10-29 09:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:01:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:01:35 --> Controller Class Initialized
INFO - 2024-10-29 14:31:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:31:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:31:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:02:32 --> Config Class Initialized
INFO - 2024-10-29 09:02:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:02:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:02:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:02:32 --> URI Class Initialized
INFO - 2024-10-29 09:02:32 --> Router Class Initialized
INFO - 2024-10-29 09:02:32 --> Output Class Initialized
INFO - 2024-10-29 09:02:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:02:32 --> Input Class Initialized
INFO - 2024-10-29 09:02:32 --> Language Class Initialized
INFO - 2024-10-29 09:02:32 --> Loader Class Initialized
INFO - 2024-10-29 09:02:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:02:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:02:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:02:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:02:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:02:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:02:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:02:34 --> Upload Class Initialized
INFO - 2024-10-29 09:02:34 --> Email Class Initialized
INFO - 2024-10-29 09:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:02:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:02:34 --> Controller Class Initialized
INFO - 2024-10-29 14:32:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:32:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:32:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:03:32 --> Config Class Initialized
INFO - 2024-10-29 09:03:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:03:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:03:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:03:32 --> URI Class Initialized
INFO - 2024-10-29 09:03:32 --> Router Class Initialized
INFO - 2024-10-29 09:03:32 --> Output Class Initialized
INFO - 2024-10-29 09:03:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:03:32 --> Input Class Initialized
INFO - 2024-10-29 09:03:32 --> Language Class Initialized
INFO - 2024-10-29 09:03:32 --> Loader Class Initialized
INFO - 2024-10-29 09:03:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:03:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:03:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:03:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:03:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:03:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:03:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:03:34 --> Upload Class Initialized
INFO - 2024-10-29 09:03:34 --> Email Class Initialized
INFO - 2024-10-29 09:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:03:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:03:34 --> Controller Class Initialized
INFO - 2024-10-29 14:33:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:33:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:33:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:04:32 --> Config Class Initialized
INFO - 2024-10-29 09:04:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:04:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:04:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:04:32 --> URI Class Initialized
INFO - 2024-10-29 09:04:32 --> Router Class Initialized
INFO - 2024-10-29 09:04:32 --> Output Class Initialized
INFO - 2024-10-29 09:04:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:04:32 --> Input Class Initialized
INFO - 2024-10-29 09:04:32 --> Language Class Initialized
INFO - 2024-10-29 09:04:32 --> Loader Class Initialized
INFO - 2024-10-29 09:04:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:04:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:04:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:04:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:04:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:04:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:04:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:04:34 --> Upload Class Initialized
INFO - 2024-10-29 09:04:34 --> Email Class Initialized
INFO - 2024-10-29 09:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:04:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:04:34 --> Controller Class Initialized
INFO - 2024-10-29 14:34:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:34:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:34:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:34:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:05:32 --> Config Class Initialized
INFO - 2024-10-29 09:05:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:05:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:05:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:05:32 --> URI Class Initialized
INFO - 2024-10-29 09:05:32 --> Router Class Initialized
INFO - 2024-10-29 09:05:32 --> Output Class Initialized
INFO - 2024-10-29 09:05:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:05:32 --> Input Class Initialized
INFO - 2024-10-29 09:05:32 --> Language Class Initialized
INFO - 2024-10-29 09:05:32 --> Loader Class Initialized
INFO - 2024-10-29 09:05:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:05:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:05:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:05:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:05:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:05:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:05:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:05:34 --> Upload Class Initialized
INFO - 2024-10-29 09:05:34 --> Email Class Initialized
INFO - 2024-10-29 09:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:05:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:05:34 --> Controller Class Initialized
INFO - 2024-10-29 14:35:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:35:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:35:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:06:32 --> Config Class Initialized
INFO - 2024-10-29 09:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:06:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:06:32 --> URI Class Initialized
INFO - 2024-10-29 09:06:32 --> Router Class Initialized
INFO - 2024-10-29 09:06:32 --> Output Class Initialized
INFO - 2024-10-29 09:06:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:06:32 --> Input Class Initialized
INFO - 2024-10-29 09:06:32 --> Language Class Initialized
INFO - 2024-10-29 09:06:32 --> Loader Class Initialized
INFO - 2024-10-29 09:06:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:06:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:06:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:06:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:06:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:06:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:06:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:06:34 --> Upload Class Initialized
INFO - 2024-10-29 09:06:34 --> Email Class Initialized
INFO - 2024-10-29 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:06:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:06:34 --> Controller Class Initialized
INFO - 2024-10-29 14:36:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:36:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:36:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:07:32 --> Config Class Initialized
INFO - 2024-10-29 09:07:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:07:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:07:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:07:32 --> URI Class Initialized
INFO - 2024-10-29 09:07:32 --> Router Class Initialized
INFO - 2024-10-29 09:07:32 --> Output Class Initialized
INFO - 2024-10-29 09:07:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:07:32 --> Input Class Initialized
INFO - 2024-10-29 09:07:32 --> Language Class Initialized
INFO - 2024-10-29 09:07:32 --> Loader Class Initialized
INFO - 2024-10-29 09:07:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:07:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:07:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:07:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:07:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:07:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:07:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:07:34 --> Upload Class Initialized
INFO - 2024-10-29 09:07:34 --> Email Class Initialized
INFO - 2024-10-29 09:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:07:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:07:34 --> Controller Class Initialized
INFO - 2024-10-29 14:37:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:37:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:37:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:08:32 --> Config Class Initialized
INFO - 2024-10-29 09:08:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:08:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:08:32 --> URI Class Initialized
INFO - 2024-10-29 09:08:32 --> Router Class Initialized
INFO - 2024-10-29 09:08:32 --> Output Class Initialized
INFO - 2024-10-29 09:08:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:08:32 --> Input Class Initialized
INFO - 2024-10-29 09:08:32 --> Language Class Initialized
INFO - 2024-10-29 09:08:32 --> Loader Class Initialized
INFO - 2024-10-29 09:08:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:08:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:08:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:08:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:08:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:08:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:08:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:08:34 --> Upload Class Initialized
INFO - 2024-10-29 09:08:34 --> Email Class Initialized
INFO - 2024-10-29 09:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:08:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:08:34 --> Controller Class Initialized
INFO - 2024-10-29 14:38:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:38:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:38:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:09:32 --> Config Class Initialized
INFO - 2024-10-29 09:09:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:09:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:09:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:09:32 --> URI Class Initialized
INFO - 2024-10-29 09:09:32 --> Router Class Initialized
INFO - 2024-10-29 09:09:32 --> Output Class Initialized
INFO - 2024-10-29 09:09:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:09:32 --> Input Class Initialized
INFO - 2024-10-29 09:09:32 --> Language Class Initialized
INFO - 2024-10-29 09:09:32 --> Loader Class Initialized
INFO - 2024-10-29 09:09:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:09:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:09:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:09:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:09:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:09:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:09:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:09:34 --> Upload Class Initialized
INFO - 2024-10-29 09:09:34 --> Email Class Initialized
INFO - 2024-10-29 09:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:09:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:09:34 --> Controller Class Initialized
INFO - 2024-10-29 14:39:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:39:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:39:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:10:32 --> Config Class Initialized
INFO - 2024-10-29 09:10:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:10:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:10:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:10:32 --> URI Class Initialized
INFO - 2024-10-29 09:10:32 --> Router Class Initialized
INFO - 2024-10-29 09:10:32 --> Output Class Initialized
INFO - 2024-10-29 09:10:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:10:32 --> Input Class Initialized
INFO - 2024-10-29 09:10:32 --> Language Class Initialized
INFO - 2024-10-29 09:10:32 --> Loader Class Initialized
INFO - 2024-10-29 09:10:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:10:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:10:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:10:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:10:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:10:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:10:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:10:35 --> Upload Class Initialized
INFO - 2024-10-29 09:10:35 --> Email Class Initialized
INFO - 2024-10-29 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:10:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:10:35 --> Controller Class Initialized
INFO - 2024-10-29 14:40:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:40:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:40:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:11:32 --> Config Class Initialized
INFO - 2024-10-29 09:11:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:11:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:11:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:11:32 --> URI Class Initialized
INFO - 2024-10-29 09:11:32 --> Router Class Initialized
INFO - 2024-10-29 09:11:32 --> Output Class Initialized
INFO - 2024-10-29 09:11:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:11:32 --> Input Class Initialized
INFO - 2024-10-29 09:11:32 --> Language Class Initialized
INFO - 2024-10-29 09:11:32 --> Loader Class Initialized
INFO - 2024-10-29 09:11:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:11:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:11:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:11:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:11:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:11:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:11:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:11:34 --> Upload Class Initialized
INFO - 2024-10-29 09:11:34 --> Email Class Initialized
INFO - 2024-10-29 09:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:11:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:11:34 --> Controller Class Initialized
INFO - 2024-10-29 14:41:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:41:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:41:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:12:32 --> Config Class Initialized
INFO - 2024-10-29 09:12:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:12:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:12:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:12:32 --> URI Class Initialized
INFO - 2024-10-29 09:12:32 --> Router Class Initialized
INFO - 2024-10-29 09:12:32 --> Output Class Initialized
INFO - 2024-10-29 09:12:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:12:32 --> Input Class Initialized
INFO - 2024-10-29 09:12:32 --> Language Class Initialized
INFO - 2024-10-29 09:12:32 --> Loader Class Initialized
INFO - 2024-10-29 09:12:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:12:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:12:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:12:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:12:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:12:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:12:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:12:34 --> Upload Class Initialized
INFO - 2024-10-29 09:12:34 --> Email Class Initialized
INFO - 2024-10-29 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:12:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:12:34 --> Controller Class Initialized
INFO - 2024-10-29 14:42:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:42:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:42:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:13:32 --> Config Class Initialized
INFO - 2024-10-29 09:13:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:13:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:13:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:13:32 --> URI Class Initialized
INFO - 2024-10-29 09:13:32 --> Router Class Initialized
INFO - 2024-10-29 09:13:32 --> Output Class Initialized
INFO - 2024-10-29 09:13:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:13:33 --> Input Class Initialized
INFO - 2024-10-29 09:13:33 --> Language Class Initialized
INFO - 2024-10-29 09:13:33 --> Loader Class Initialized
INFO - 2024-10-29 09:13:33 --> Helper loaded: url_helper
INFO - 2024-10-29 09:13:33 --> Helper loaded: html_helper
INFO - 2024-10-29 09:13:33 --> Helper loaded: file_helper
INFO - 2024-10-29 09:13:33 --> Helper loaded: string_helper
INFO - 2024-10-29 09:13:33 --> Helper loaded: form_helper
INFO - 2024-10-29 09:13:33 --> Helper loaded: my_helper
INFO - 2024-10-29 09:13:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:13:35 --> Upload Class Initialized
INFO - 2024-10-29 09:13:35 --> Email Class Initialized
INFO - 2024-10-29 09:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:13:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:13:35 --> Controller Class Initialized
INFO - 2024-10-29 14:43:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:43:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:43:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:14:32 --> Config Class Initialized
INFO - 2024-10-29 09:14:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:14:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:14:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:14:32 --> URI Class Initialized
INFO - 2024-10-29 09:14:32 --> Router Class Initialized
INFO - 2024-10-29 09:14:32 --> Output Class Initialized
INFO - 2024-10-29 09:14:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:14:32 --> Input Class Initialized
INFO - 2024-10-29 09:14:32 --> Language Class Initialized
INFO - 2024-10-29 09:14:32 --> Loader Class Initialized
INFO - 2024-10-29 09:14:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:14:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:14:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:14:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:14:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:14:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:14:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:14:35 --> Upload Class Initialized
INFO - 2024-10-29 09:14:35 --> Email Class Initialized
INFO - 2024-10-29 09:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:14:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:14:35 --> Controller Class Initialized
INFO - 2024-10-29 14:44:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:44:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:44:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:15:32 --> Config Class Initialized
INFO - 2024-10-29 09:15:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:15:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:15:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:15:32 --> URI Class Initialized
INFO - 2024-10-29 09:15:32 --> Router Class Initialized
INFO - 2024-10-29 09:15:32 --> Output Class Initialized
INFO - 2024-10-29 09:15:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:15:32 --> Input Class Initialized
INFO - 2024-10-29 09:15:32 --> Language Class Initialized
INFO - 2024-10-29 09:15:32 --> Loader Class Initialized
INFO - 2024-10-29 09:15:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:15:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:15:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:15:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:15:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:15:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:15:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:15:34 --> Upload Class Initialized
INFO - 2024-10-29 09:15:34 --> Email Class Initialized
INFO - 2024-10-29 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:15:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:15:34 --> Controller Class Initialized
INFO - 2024-10-29 14:45:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:45:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:45:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:16:32 --> Config Class Initialized
INFO - 2024-10-29 09:16:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:16:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:16:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:16:32 --> URI Class Initialized
INFO - 2024-10-29 09:16:32 --> Router Class Initialized
INFO - 2024-10-29 09:16:32 --> Output Class Initialized
INFO - 2024-10-29 09:16:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:16:32 --> Input Class Initialized
INFO - 2024-10-29 09:16:32 --> Language Class Initialized
INFO - 2024-10-29 09:16:32 --> Loader Class Initialized
INFO - 2024-10-29 09:16:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:16:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:16:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:16:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:16:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:16:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:16:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:16:34 --> Upload Class Initialized
INFO - 2024-10-29 09:16:34 --> Email Class Initialized
INFO - 2024-10-29 09:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:16:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:16:34 --> Controller Class Initialized
INFO - 2024-10-29 14:46:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:46:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:46:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:46:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:17:32 --> Config Class Initialized
INFO - 2024-10-29 09:17:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:17:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:17:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:17:32 --> URI Class Initialized
INFO - 2024-10-29 09:17:32 --> Router Class Initialized
INFO - 2024-10-29 09:17:32 --> Output Class Initialized
INFO - 2024-10-29 09:17:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:17:32 --> Input Class Initialized
INFO - 2024-10-29 09:17:32 --> Language Class Initialized
INFO - 2024-10-29 09:17:32 --> Loader Class Initialized
INFO - 2024-10-29 09:17:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:17:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:17:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:17:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:17:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:17:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:17:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:17:34 --> Upload Class Initialized
INFO - 2024-10-29 09:17:34 --> Email Class Initialized
INFO - 2024-10-29 09:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:17:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:17:34 --> Controller Class Initialized
INFO - 2024-10-29 14:47:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:47:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:47:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:18:32 --> Config Class Initialized
INFO - 2024-10-29 09:18:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:18:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:18:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:18:32 --> URI Class Initialized
INFO - 2024-10-29 09:18:32 --> Router Class Initialized
INFO - 2024-10-29 09:18:32 --> Output Class Initialized
INFO - 2024-10-29 09:18:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:18:32 --> Input Class Initialized
INFO - 2024-10-29 09:18:32 --> Language Class Initialized
INFO - 2024-10-29 09:18:32 --> Loader Class Initialized
INFO - 2024-10-29 09:18:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:18:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:18:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:18:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:18:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:18:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:18:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:18:34 --> Upload Class Initialized
INFO - 2024-10-29 09:18:34 --> Email Class Initialized
INFO - 2024-10-29 09:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:18:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:18:34 --> Controller Class Initialized
INFO - 2024-10-29 14:48:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:48:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:48:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:19:32 --> Config Class Initialized
INFO - 2024-10-29 09:19:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:19:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:19:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:19:32 --> URI Class Initialized
INFO - 2024-10-29 09:19:32 --> Router Class Initialized
INFO - 2024-10-29 09:19:32 --> Output Class Initialized
INFO - 2024-10-29 09:19:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:19:32 --> Input Class Initialized
INFO - 2024-10-29 09:19:32 --> Language Class Initialized
INFO - 2024-10-29 09:19:32 --> Loader Class Initialized
INFO - 2024-10-29 09:19:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:19:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:19:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:19:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:19:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:19:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:19:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:19:34 --> Upload Class Initialized
INFO - 2024-10-29 09:19:34 --> Email Class Initialized
INFO - 2024-10-29 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:19:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:19:34 --> Controller Class Initialized
INFO - 2024-10-29 14:49:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:49:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:49:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:20:32 --> Config Class Initialized
INFO - 2024-10-29 09:20:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:20:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:20:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:20:32 --> URI Class Initialized
INFO - 2024-10-29 09:20:32 --> Router Class Initialized
INFO - 2024-10-29 09:20:32 --> Output Class Initialized
INFO - 2024-10-29 09:20:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:20:32 --> Input Class Initialized
INFO - 2024-10-29 09:20:32 --> Language Class Initialized
INFO - 2024-10-29 09:20:32 --> Loader Class Initialized
INFO - 2024-10-29 09:20:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:20:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:20:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:20:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:20:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:20:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:20:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:20:34 --> Upload Class Initialized
INFO - 2024-10-29 09:20:34 --> Email Class Initialized
INFO - 2024-10-29 09:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:20:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:20:35 --> Controller Class Initialized
INFO - 2024-10-29 14:50:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:50:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:50:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:21:32 --> Config Class Initialized
INFO - 2024-10-29 09:21:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:21:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:21:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:21:32 --> URI Class Initialized
INFO - 2024-10-29 09:21:32 --> Router Class Initialized
INFO - 2024-10-29 09:21:32 --> Output Class Initialized
INFO - 2024-10-29 09:21:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:21:32 --> Input Class Initialized
INFO - 2024-10-29 09:21:32 --> Language Class Initialized
INFO - 2024-10-29 09:21:32 --> Loader Class Initialized
INFO - 2024-10-29 09:21:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:21:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:21:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:21:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:21:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:21:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:21:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:21:34 --> Upload Class Initialized
INFO - 2024-10-29 09:21:34 --> Email Class Initialized
INFO - 2024-10-29 09:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:21:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:21:34 --> Controller Class Initialized
INFO - 2024-10-29 14:51:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:51:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:51:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:22:32 --> Config Class Initialized
INFO - 2024-10-29 09:22:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:22:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:22:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:22:32 --> URI Class Initialized
INFO - 2024-10-29 09:22:32 --> Router Class Initialized
INFO - 2024-10-29 09:22:32 --> Output Class Initialized
INFO - 2024-10-29 09:22:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:22:32 --> Input Class Initialized
INFO - 2024-10-29 09:22:32 --> Language Class Initialized
INFO - 2024-10-29 09:22:32 --> Loader Class Initialized
INFO - 2024-10-29 09:22:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:22:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:22:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:22:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:22:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:22:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:22:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:22:34 --> Upload Class Initialized
INFO - 2024-10-29 09:22:34 --> Email Class Initialized
INFO - 2024-10-29 09:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:22:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:22:34 --> Controller Class Initialized
INFO - 2024-10-29 14:52:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:52:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:52:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:23:32 --> Config Class Initialized
INFO - 2024-10-29 09:23:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:23:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:23:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:23:32 --> URI Class Initialized
INFO - 2024-10-29 09:23:32 --> Router Class Initialized
INFO - 2024-10-29 09:23:32 --> Output Class Initialized
INFO - 2024-10-29 09:23:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:23:32 --> Input Class Initialized
INFO - 2024-10-29 09:23:32 --> Language Class Initialized
INFO - 2024-10-29 09:23:32 --> Loader Class Initialized
INFO - 2024-10-29 09:23:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:23:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:23:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:23:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:23:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:23:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:23:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:23:34 --> Upload Class Initialized
INFO - 2024-10-29 09:23:34 --> Email Class Initialized
INFO - 2024-10-29 09:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:23:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:23:34 --> Controller Class Initialized
INFO - 2024-10-29 14:53:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:53:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:53:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:24:32 --> Config Class Initialized
INFO - 2024-10-29 09:24:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:24:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:24:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:24:32 --> URI Class Initialized
INFO - 2024-10-29 09:24:32 --> Router Class Initialized
INFO - 2024-10-29 09:24:32 --> Output Class Initialized
INFO - 2024-10-29 09:24:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:24:32 --> Input Class Initialized
INFO - 2024-10-29 09:24:32 --> Language Class Initialized
INFO - 2024-10-29 09:24:32 --> Loader Class Initialized
INFO - 2024-10-29 09:24:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:24:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:24:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:24:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:24:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:24:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:24:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:24:34 --> Upload Class Initialized
INFO - 2024-10-29 09:24:34 --> Email Class Initialized
INFO - 2024-10-29 09:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:24:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:24:34 --> Controller Class Initialized
INFO - 2024-10-29 14:54:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:54:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:54:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:54:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:25:32 --> Config Class Initialized
INFO - 2024-10-29 09:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:25:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:25:32 --> URI Class Initialized
INFO - 2024-10-29 09:25:32 --> Router Class Initialized
INFO - 2024-10-29 09:25:32 --> Output Class Initialized
INFO - 2024-10-29 09:25:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:25:32 --> Input Class Initialized
INFO - 2024-10-29 09:25:32 --> Language Class Initialized
INFO - 2024-10-29 09:25:33 --> Loader Class Initialized
INFO - 2024-10-29 09:25:33 --> Helper loaded: url_helper
INFO - 2024-10-29 09:25:33 --> Helper loaded: html_helper
INFO - 2024-10-29 09:25:33 --> Helper loaded: file_helper
INFO - 2024-10-29 09:25:33 --> Helper loaded: string_helper
INFO - 2024-10-29 09:25:33 --> Helper loaded: form_helper
INFO - 2024-10-29 09:25:33 --> Helper loaded: my_helper
INFO - 2024-10-29 09:25:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:25:35 --> Upload Class Initialized
INFO - 2024-10-29 09:25:35 --> Email Class Initialized
INFO - 2024-10-29 09:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:25:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:25:35 --> Controller Class Initialized
INFO - 2024-10-29 14:55:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:55:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:55:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:26:32 --> Config Class Initialized
INFO - 2024-10-29 09:26:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:26:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:26:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:26:32 --> URI Class Initialized
INFO - 2024-10-29 09:26:32 --> Router Class Initialized
INFO - 2024-10-29 09:26:32 --> Output Class Initialized
INFO - 2024-10-29 09:26:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:26:32 --> Input Class Initialized
INFO - 2024-10-29 09:26:32 --> Language Class Initialized
INFO - 2024-10-29 09:26:32 --> Loader Class Initialized
INFO - 2024-10-29 09:26:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:26:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:26:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:26:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:26:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:26:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:26:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:26:34 --> Upload Class Initialized
INFO - 2024-10-29 09:26:34 --> Email Class Initialized
INFO - 2024-10-29 09:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:26:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:26:35 --> Controller Class Initialized
INFO - 2024-10-29 14:56:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:56:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:56:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:27:32 --> Config Class Initialized
INFO - 2024-10-29 09:27:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:27:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:27:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:27:32 --> URI Class Initialized
INFO - 2024-10-29 09:27:32 --> Router Class Initialized
INFO - 2024-10-29 09:27:32 --> Output Class Initialized
INFO - 2024-10-29 09:27:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:27:32 --> Input Class Initialized
INFO - 2024-10-29 09:27:32 --> Language Class Initialized
INFO - 2024-10-29 09:27:32 --> Loader Class Initialized
INFO - 2024-10-29 09:27:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:27:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:27:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:27:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:27:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:27:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:27:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:27:34 --> Upload Class Initialized
INFO - 2024-10-29 09:27:34 --> Email Class Initialized
INFO - 2024-10-29 09:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:27:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:27:34 --> Controller Class Initialized
INFO - 2024-10-29 14:57:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:57:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:57:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:28:32 --> Config Class Initialized
INFO - 2024-10-29 09:28:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:28:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:28:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:28:32 --> URI Class Initialized
INFO - 2024-10-29 09:28:32 --> Router Class Initialized
INFO - 2024-10-29 09:28:32 --> Output Class Initialized
INFO - 2024-10-29 09:28:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:28:32 --> Input Class Initialized
INFO - 2024-10-29 09:28:32 --> Language Class Initialized
INFO - 2024-10-29 09:28:32 --> Loader Class Initialized
INFO - 2024-10-29 09:28:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:28:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:28:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:28:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:28:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:28:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:28:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:28:34 --> Upload Class Initialized
INFO - 2024-10-29 09:28:34 --> Email Class Initialized
INFO - 2024-10-29 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:28:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:28:34 --> Controller Class Initialized
INFO - 2024-10-29 14:58:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:58:35 --> Model "MainModel" initialized
INFO - 2024-10-29 14:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:58:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:29:32 --> Config Class Initialized
INFO - 2024-10-29 09:29:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:29:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:29:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:29:32 --> URI Class Initialized
INFO - 2024-10-29 09:29:32 --> Router Class Initialized
INFO - 2024-10-29 09:29:32 --> Output Class Initialized
INFO - 2024-10-29 09:29:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:29:32 --> Input Class Initialized
INFO - 2024-10-29 09:29:32 --> Language Class Initialized
INFO - 2024-10-29 09:29:32 --> Loader Class Initialized
INFO - 2024-10-29 09:29:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:29:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:29:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:29:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:29:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:29:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:29:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:29:34 --> Upload Class Initialized
INFO - 2024-10-29 09:29:34 --> Email Class Initialized
INFO - 2024-10-29 09:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:29:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:29:34 --> Controller Class Initialized
INFO - 2024-10-29 14:59:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 14:59:34 --> Model "MainModel" initialized
INFO - 2024-10-29 14:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 14:59:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:30:32 --> Config Class Initialized
INFO - 2024-10-29 09:30:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:30:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:30:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:30:32 --> URI Class Initialized
INFO - 2024-10-29 09:30:32 --> Router Class Initialized
INFO - 2024-10-29 09:30:32 --> Output Class Initialized
INFO - 2024-10-29 09:30:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:30:32 --> Input Class Initialized
INFO - 2024-10-29 09:30:32 --> Language Class Initialized
INFO - 2024-10-29 09:30:32 --> Loader Class Initialized
INFO - 2024-10-29 09:30:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:30:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:30:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:30:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:30:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:30:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:30:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:30:35 --> Upload Class Initialized
INFO - 2024-10-29 09:30:35 --> Email Class Initialized
INFO - 2024-10-29 09:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:30:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:30:35 --> Controller Class Initialized
INFO - 2024-10-29 15:00:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:00:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:00:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:31:32 --> Config Class Initialized
INFO - 2024-10-29 09:31:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:31:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:31:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:31:32 --> URI Class Initialized
INFO - 2024-10-29 09:31:32 --> Router Class Initialized
INFO - 2024-10-29 09:31:32 --> Output Class Initialized
INFO - 2024-10-29 09:31:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:31:32 --> Input Class Initialized
INFO - 2024-10-29 09:31:32 --> Language Class Initialized
INFO - 2024-10-29 09:31:32 --> Loader Class Initialized
INFO - 2024-10-29 09:31:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:31:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:31:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:31:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:31:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:31:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:31:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:31:34 --> Upload Class Initialized
INFO - 2024-10-29 09:31:34 --> Email Class Initialized
INFO - 2024-10-29 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:31:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:31:34 --> Controller Class Initialized
INFO - 2024-10-29 15:01:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:01:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:01:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:32:32 --> Config Class Initialized
INFO - 2024-10-29 09:32:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:32:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:32:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:32:32 --> URI Class Initialized
INFO - 2024-10-29 09:32:32 --> Router Class Initialized
INFO - 2024-10-29 09:32:32 --> Output Class Initialized
INFO - 2024-10-29 09:32:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:32:32 --> Input Class Initialized
INFO - 2024-10-29 09:32:32 --> Language Class Initialized
INFO - 2024-10-29 09:32:32 --> Loader Class Initialized
INFO - 2024-10-29 09:32:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:32:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:32:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:32:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:32:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:32:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:32:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:32:34 --> Upload Class Initialized
INFO - 2024-10-29 09:32:34 --> Email Class Initialized
INFO - 2024-10-29 09:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:32:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:32:34 --> Controller Class Initialized
INFO - 2024-10-29 15:02:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:02:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:02:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:33:32 --> Config Class Initialized
INFO - 2024-10-29 09:33:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:33:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:33:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:33:32 --> URI Class Initialized
INFO - 2024-10-29 09:33:32 --> Router Class Initialized
INFO - 2024-10-29 09:33:32 --> Output Class Initialized
INFO - 2024-10-29 09:33:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:33:32 --> Input Class Initialized
INFO - 2024-10-29 09:33:32 --> Language Class Initialized
INFO - 2024-10-29 09:33:32 --> Loader Class Initialized
INFO - 2024-10-29 09:33:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:33:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:33:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:33:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:33:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:33:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:33:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:33:34 --> Upload Class Initialized
INFO - 2024-10-29 09:33:34 --> Email Class Initialized
INFO - 2024-10-29 09:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:33:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:33:34 --> Controller Class Initialized
INFO - 2024-10-29 15:03:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:03:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:03:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:34:32 --> Config Class Initialized
INFO - 2024-10-29 09:34:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:34:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:34:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:34:32 --> URI Class Initialized
INFO - 2024-10-29 09:34:32 --> Router Class Initialized
INFO - 2024-10-29 09:34:32 --> Output Class Initialized
INFO - 2024-10-29 09:34:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:34:32 --> Input Class Initialized
INFO - 2024-10-29 09:34:32 --> Language Class Initialized
INFO - 2024-10-29 09:34:32 --> Loader Class Initialized
INFO - 2024-10-29 09:34:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:34:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:34:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:34:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:34:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:34:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:34:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:34:35 --> Upload Class Initialized
INFO - 2024-10-29 09:34:35 --> Email Class Initialized
INFO - 2024-10-29 09:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:34:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:34:35 --> Controller Class Initialized
INFO - 2024-10-29 15:04:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:04:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:04:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:35:32 --> Config Class Initialized
INFO - 2024-10-29 09:35:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:35:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:35:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:35:32 --> URI Class Initialized
INFO - 2024-10-29 09:35:32 --> Router Class Initialized
INFO - 2024-10-29 09:35:32 --> Output Class Initialized
INFO - 2024-10-29 09:35:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:35:32 --> Input Class Initialized
INFO - 2024-10-29 09:35:32 --> Language Class Initialized
INFO - 2024-10-29 09:35:32 --> Loader Class Initialized
INFO - 2024-10-29 09:35:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:35:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:35:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:35:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:35:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:35:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:35:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:35:34 --> Upload Class Initialized
INFO - 2024-10-29 09:35:34 --> Email Class Initialized
INFO - 2024-10-29 09:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:35:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:35:34 --> Controller Class Initialized
INFO - 2024-10-29 15:05:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:05:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:05:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:05:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:36:32 --> Config Class Initialized
INFO - 2024-10-29 09:36:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:36:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:36:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:36:32 --> URI Class Initialized
INFO - 2024-10-29 09:36:32 --> Router Class Initialized
INFO - 2024-10-29 09:36:32 --> Output Class Initialized
INFO - 2024-10-29 09:36:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:36:32 --> Input Class Initialized
INFO - 2024-10-29 09:36:32 --> Language Class Initialized
INFO - 2024-10-29 09:36:32 --> Loader Class Initialized
INFO - 2024-10-29 09:36:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:36:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:36:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:36:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:36:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:36:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:36:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:36:34 --> Upload Class Initialized
INFO - 2024-10-29 09:36:34 --> Email Class Initialized
INFO - 2024-10-29 09:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:36:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:36:34 --> Controller Class Initialized
INFO - 2024-10-29 15:06:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:06:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:06:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:37:32 --> Config Class Initialized
INFO - 2024-10-29 09:37:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:37:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:37:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:37:32 --> URI Class Initialized
INFO - 2024-10-29 09:37:32 --> Router Class Initialized
INFO - 2024-10-29 09:37:32 --> Output Class Initialized
INFO - 2024-10-29 09:37:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:37:32 --> Input Class Initialized
INFO - 2024-10-29 09:37:32 --> Language Class Initialized
INFO - 2024-10-29 09:37:32 --> Loader Class Initialized
INFO - 2024-10-29 09:37:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:37:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:37:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:37:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:37:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:37:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:37:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:37:34 --> Upload Class Initialized
INFO - 2024-10-29 09:37:35 --> Email Class Initialized
INFO - 2024-10-29 09:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:37:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:37:35 --> Controller Class Initialized
INFO - 2024-10-29 15:07:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:07:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:07:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:38:32 --> Config Class Initialized
INFO - 2024-10-29 09:38:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:38:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:38:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:38:32 --> URI Class Initialized
INFO - 2024-10-29 09:38:32 --> Router Class Initialized
INFO - 2024-10-29 09:38:32 --> Output Class Initialized
INFO - 2024-10-29 09:38:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:38:32 --> Input Class Initialized
INFO - 2024-10-29 09:38:32 --> Language Class Initialized
INFO - 2024-10-29 09:38:32 --> Loader Class Initialized
INFO - 2024-10-29 09:38:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:38:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:38:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:38:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:38:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:38:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:38:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:38:35 --> Upload Class Initialized
INFO - 2024-10-29 09:38:35 --> Email Class Initialized
INFO - 2024-10-29 09:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:38:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:38:35 --> Controller Class Initialized
INFO - 2024-10-29 15:08:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:08:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:08:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:39:32 --> Config Class Initialized
INFO - 2024-10-29 09:39:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:39:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:39:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:39:32 --> URI Class Initialized
INFO - 2024-10-29 09:39:32 --> Router Class Initialized
INFO - 2024-10-29 09:39:32 --> Output Class Initialized
INFO - 2024-10-29 09:39:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:39:32 --> Input Class Initialized
INFO - 2024-10-29 09:39:32 --> Language Class Initialized
INFO - 2024-10-29 09:39:32 --> Loader Class Initialized
INFO - 2024-10-29 09:39:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:39:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:39:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:39:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:39:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:39:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:39:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:39:34 --> Upload Class Initialized
INFO - 2024-10-29 09:39:34 --> Email Class Initialized
INFO - 2024-10-29 09:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:39:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:39:35 --> Controller Class Initialized
INFO - 2024-10-29 15:09:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:09:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:09:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:40:32 --> Config Class Initialized
INFO - 2024-10-29 09:40:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:40:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:40:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:40:32 --> URI Class Initialized
INFO - 2024-10-29 09:40:32 --> Router Class Initialized
INFO - 2024-10-29 09:40:32 --> Output Class Initialized
INFO - 2024-10-29 09:40:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:40:32 --> Input Class Initialized
INFO - 2024-10-29 09:40:32 --> Language Class Initialized
INFO - 2024-10-29 09:40:32 --> Loader Class Initialized
INFO - 2024-10-29 09:40:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:40:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:40:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:40:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:40:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:40:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:40:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:40:35 --> Upload Class Initialized
INFO - 2024-10-29 09:40:35 --> Email Class Initialized
INFO - 2024-10-29 09:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:40:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:40:35 --> Controller Class Initialized
INFO - 2024-10-29 15:10:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:10:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:10:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:41:32 --> Config Class Initialized
INFO - 2024-10-29 09:41:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:41:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:41:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:41:32 --> URI Class Initialized
INFO - 2024-10-29 09:41:32 --> Router Class Initialized
INFO - 2024-10-29 09:41:32 --> Output Class Initialized
INFO - 2024-10-29 09:41:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:41:32 --> Input Class Initialized
INFO - 2024-10-29 09:41:32 --> Language Class Initialized
INFO - 2024-10-29 09:41:32 --> Loader Class Initialized
INFO - 2024-10-29 09:41:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:41:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:41:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:41:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:41:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:41:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:41:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:41:34 --> Upload Class Initialized
INFO - 2024-10-29 09:41:34 --> Email Class Initialized
INFO - 2024-10-29 09:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:41:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:41:34 --> Controller Class Initialized
INFO - 2024-10-29 15:11:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:11:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:11:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:42:32 --> Config Class Initialized
INFO - 2024-10-29 09:42:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:42:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:42:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:42:32 --> URI Class Initialized
INFO - 2024-10-29 09:42:32 --> Router Class Initialized
INFO - 2024-10-29 09:42:32 --> Output Class Initialized
INFO - 2024-10-29 09:42:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:42:32 --> Input Class Initialized
INFO - 2024-10-29 09:42:32 --> Language Class Initialized
INFO - 2024-10-29 09:42:32 --> Loader Class Initialized
INFO - 2024-10-29 09:42:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:42:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:42:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:42:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:42:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:42:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:42:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:42:34 --> Upload Class Initialized
INFO - 2024-10-29 09:42:34 --> Email Class Initialized
INFO - 2024-10-29 09:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:42:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:42:34 --> Controller Class Initialized
INFO - 2024-10-29 15:12:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:12:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:12:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:43:32 --> Config Class Initialized
INFO - 2024-10-29 09:43:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:43:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:43:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:43:32 --> URI Class Initialized
INFO - 2024-10-29 09:43:32 --> Router Class Initialized
INFO - 2024-10-29 09:43:32 --> Output Class Initialized
INFO - 2024-10-29 09:43:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:43:32 --> Input Class Initialized
INFO - 2024-10-29 09:43:32 --> Language Class Initialized
INFO - 2024-10-29 09:43:32 --> Loader Class Initialized
INFO - 2024-10-29 09:43:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:43:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:43:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:43:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:43:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:43:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:43:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:43:34 --> Upload Class Initialized
INFO - 2024-10-29 09:43:34 --> Email Class Initialized
INFO - 2024-10-29 09:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:43:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:43:34 --> Controller Class Initialized
INFO - 2024-10-29 15:13:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:13:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:13:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:44:32 --> Config Class Initialized
INFO - 2024-10-29 09:44:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:44:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:44:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:44:32 --> URI Class Initialized
INFO - 2024-10-29 09:44:32 --> Router Class Initialized
INFO - 2024-10-29 09:44:32 --> Output Class Initialized
INFO - 2024-10-29 09:44:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:44:32 --> Input Class Initialized
INFO - 2024-10-29 09:44:33 --> Language Class Initialized
INFO - 2024-10-29 09:44:33 --> Loader Class Initialized
INFO - 2024-10-29 09:44:33 --> Helper loaded: url_helper
INFO - 2024-10-29 09:44:33 --> Helper loaded: html_helper
INFO - 2024-10-29 09:44:33 --> Helper loaded: file_helper
INFO - 2024-10-29 09:44:33 --> Helper loaded: string_helper
INFO - 2024-10-29 09:44:33 --> Helper loaded: form_helper
INFO - 2024-10-29 09:44:33 --> Helper loaded: my_helper
INFO - 2024-10-29 09:44:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:44:35 --> Upload Class Initialized
INFO - 2024-10-29 09:44:35 --> Email Class Initialized
INFO - 2024-10-29 09:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:44:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:44:35 --> Controller Class Initialized
INFO - 2024-10-29 15:14:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:14:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:14:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:45:32 --> Config Class Initialized
INFO - 2024-10-29 09:45:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:45:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:45:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:45:32 --> URI Class Initialized
INFO - 2024-10-29 09:45:32 --> Router Class Initialized
INFO - 2024-10-29 09:45:32 --> Output Class Initialized
INFO - 2024-10-29 09:45:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:45:32 --> Input Class Initialized
INFO - 2024-10-29 09:45:32 --> Language Class Initialized
INFO - 2024-10-29 09:45:32 --> Loader Class Initialized
INFO - 2024-10-29 09:45:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:45:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:45:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:45:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:45:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:45:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:45:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:45:34 --> Upload Class Initialized
INFO - 2024-10-29 09:45:34 --> Email Class Initialized
INFO - 2024-10-29 09:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:45:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:45:34 --> Controller Class Initialized
INFO - 2024-10-29 15:15:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:15:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:15:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:46:32 --> Config Class Initialized
INFO - 2024-10-29 09:46:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:46:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:46:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:46:32 --> URI Class Initialized
INFO - 2024-10-29 09:46:32 --> Router Class Initialized
INFO - 2024-10-29 09:46:32 --> Output Class Initialized
INFO - 2024-10-29 09:46:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:46:32 --> Input Class Initialized
INFO - 2024-10-29 09:46:32 --> Language Class Initialized
INFO - 2024-10-29 09:46:32 --> Loader Class Initialized
INFO - 2024-10-29 09:46:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:46:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:46:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:46:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:46:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:46:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:46:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:46:35 --> Upload Class Initialized
INFO - 2024-10-29 09:46:35 --> Email Class Initialized
INFO - 2024-10-29 09:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:46:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:46:35 --> Controller Class Initialized
INFO - 2024-10-29 15:16:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:16:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:16:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:47:32 --> Config Class Initialized
INFO - 2024-10-29 09:47:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:47:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:47:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:47:32 --> URI Class Initialized
INFO - 2024-10-29 09:47:32 --> Router Class Initialized
INFO - 2024-10-29 09:47:32 --> Output Class Initialized
INFO - 2024-10-29 09:47:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:47:32 --> Input Class Initialized
INFO - 2024-10-29 09:47:32 --> Language Class Initialized
INFO - 2024-10-29 09:47:32 --> Loader Class Initialized
INFO - 2024-10-29 09:47:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:47:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:47:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:47:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:47:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:47:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:47:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:47:34 --> Upload Class Initialized
INFO - 2024-10-29 09:47:34 --> Email Class Initialized
INFO - 2024-10-29 09:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:47:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:47:34 --> Controller Class Initialized
INFO - 2024-10-29 15:17:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:17:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:17:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:48:32 --> Config Class Initialized
INFO - 2024-10-29 09:48:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:48:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:48:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:48:32 --> URI Class Initialized
INFO - 2024-10-29 09:48:32 --> Router Class Initialized
INFO - 2024-10-29 09:48:32 --> Output Class Initialized
INFO - 2024-10-29 09:48:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:48:32 --> Input Class Initialized
INFO - 2024-10-29 09:48:32 --> Language Class Initialized
INFO - 2024-10-29 09:48:32 --> Loader Class Initialized
INFO - 2024-10-29 09:48:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:48:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:48:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:48:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:48:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:48:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:48:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:48:34 --> Upload Class Initialized
INFO - 2024-10-29 09:48:34 --> Email Class Initialized
INFO - 2024-10-29 09:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:48:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:48:34 --> Controller Class Initialized
INFO - 2024-10-29 15:18:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:18:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:18:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:49:32 --> Config Class Initialized
INFO - 2024-10-29 09:49:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:49:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:49:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:49:32 --> URI Class Initialized
INFO - 2024-10-29 09:49:32 --> Router Class Initialized
INFO - 2024-10-29 09:49:32 --> Output Class Initialized
INFO - 2024-10-29 09:49:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:49:32 --> Input Class Initialized
INFO - 2024-10-29 09:49:32 --> Language Class Initialized
INFO - 2024-10-29 09:49:32 --> Loader Class Initialized
INFO - 2024-10-29 09:49:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:49:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:49:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:49:33 --> Helper loaded: string_helper
INFO - 2024-10-29 09:49:33 --> Helper loaded: form_helper
INFO - 2024-10-29 09:49:33 --> Helper loaded: my_helper
INFO - 2024-10-29 09:49:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:49:35 --> Upload Class Initialized
INFO - 2024-10-29 09:49:35 --> Email Class Initialized
INFO - 2024-10-29 09:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:49:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:49:35 --> Controller Class Initialized
INFO - 2024-10-29 15:19:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:19:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:19:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:50:32 --> Config Class Initialized
INFO - 2024-10-29 09:50:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:50:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:50:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:50:32 --> URI Class Initialized
INFO - 2024-10-29 09:50:32 --> Router Class Initialized
INFO - 2024-10-29 09:50:32 --> Output Class Initialized
INFO - 2024-10-29 09:50:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:50:32 --> Input Class Initialized
INFO - 2024-10-29 09:50:32 --> Language Class Initialized
INFO - 2024-10-29 09:50:32 --> Loader Class Initialized
INFO - 2024-10-29 09:50:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:50:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:50:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:50:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:50:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:50:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:50:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:50:34 --> Upload Class Initialized
INFO - 2024-10-29 09:50:34 --> Email Class Initialized
INFO - 2024-10-29 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:50:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:50:34 --> Controller Class Initialized
INFO - 2024-10-29 15:20:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:20:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:20:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:51:32 --> Config Class Initialized
INFO - 2024-10-29 09:51:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:51:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:51:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:51:32 --> URI Class Initialized
INFO - 2024-10-29 09:51:32 --> Router Class Initialized
INFO - 2024-10-29 09:51:32 --> Output Class Initialized
INFO - 2024-10-29 09:51:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:51:32 --> Input Class Initialized
INFO - 2024-10-29 09:51:32 --> Language Class Initialized
INFO - 2024-10-29 09:51:32 --> Loader Class Initialized
INFO - 2024-10-29 09:51:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:51:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:51:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:51:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:51:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:51:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:51:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:51:34 --> Upload Class Initialized
INFO - 2024-10-29 09:51:34 --> Email Class Initialized
INFO - 2024-10-29 09:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:51:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:51:35 --> Controller Class Initialized
INFO - 2024-10-29 15:21:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:21:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:21:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:52:32 --> Config Class Initialized
INFO - 2024-10-29 09:52:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:52:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:52:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:52:32 --> URI Class Initialized
INFO - 2024-10-29 09:52:32 --> Router Class Initialized
INFO - 2024-10-29 09:52:32 --> Output Class Initialized
INFO - 2024-10-29 09:52:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:52:32 --> Input Class Initialized
INFO - 2024-10-29 09:52:32 --> Language Class Initialized
INFO - 2024-10-29 09:52:32 --> Loader Class Initialized
INFO - 2024-10-29 09:52:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:52:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:52:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:52:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:52:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:52:33 --> Helper loaded: my_helper
INFO - 2024-10-29 09:52:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:52:35 --> Upload Class Initialized
INFO - 2024-10-29 09:52:35 --> Email Class Initialized
INFO - 2024-10-29 09:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:52:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:52:35 --> Controller Class Initialized
INFO - 2024-10-29 15:22:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:22:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:22:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:53:32 --> Config Class Initialized
INFO - 2024-10-29 09:53:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:53:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:53:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:53:32 --> URI Class Initialized
INFO - 2024-10-29 09:53:32 --> Router Class Initialized
INFO - 2024-10-29 09:53:32 --> Output Class Initialized
INFO - 2024-10-29 09:53:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:53:32 --> Input Class Initialized
INFO - 2024-10-29 09:53:32 --> Language Class Initialized
INFO - 2024-10-29 09:53:32 --> Loader Class Initialized
INFO - 2024-10-29 09:53:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:53:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:53:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:53:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:53:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:53:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:53:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:53:34 --> Upload Class Initialized
INFO - 2024-10-29 09:53:34 --> Email Class Initialized
INFO - 2024-10-29 09:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:53:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:53:34 --> Controller Class Initialized
INFO - 2024-10-29 15:23:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:23:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:23:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:54:32 --> Config Class Initialized
INFO - 2024-10-29 09:54:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:54:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:54:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:54:32 --> URI Class Initialized
INFO - 2024-10-29 09:54:32 --> Router Class Initialized
INFO - 2024-10-29 09:54:32 --> Output Class Initialized
INFO - 2024-10-29 09:54:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:54:32 --> Input Class Initialized
INFO - 2024-10-29 09:54:32 --> Language Class Initialized
INFO - 2024-10-29 09:54:32 --> Loader Class Initialized
INFO - 2024-10-29 09:54:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:54:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:54:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:54:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:54:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:54:33 --> Helper loaded: my_helper
INFO - 2024-10-29 09:54:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:54:35 --> Upload Class Initialized
INFO - 2024-10-29 09:54:35 --> Email Class Initialized
INFO - 2024-10-29 09:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:54:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:54:35 --> Controller Class Initialized
INFO - 2024-10-29 15:24:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:24:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:24:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:55:32 --> Config Class Initialized
INFO - 2024-10-29 09:55:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:55:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:55:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:55:32 --> URI Class Initialized
INFO - 2024-10-29 09:55:32 --> Router Class Initialized
INFO - 2024-10-29 09:55:32 --> Output Class Initialized
INFO - 2024-10-29 09:55:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:55:32 --> Input Class Initialized
INFO - 2024-10-29 09:55:32 --> Language Class Initialized
INFO - 2024-10-29 09:55:32 --> Loader Class Initialized
INFO - 2024-10-29 09:55:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:55:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:55:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:55:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:55:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:55:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:55:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:55:34 --> Upload Class Initialized
INFO - 2024-10-29 09:55:34 --> Email Class Initialized
INFO - 2024-10-29 09:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:55:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:55:34 --> Controller Class Initialized
INFO - 2024-10-29 15:25:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:25:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:25:34 --> Pagination Class Initialized
INFO - 2024-10-29 09:56:32 --> Config Class Initialized
INFO - 2024-10-29 09:56:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:56:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:56:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:56:32 --> URI Class Initialized
INFO - 2024-10-29 09:56:32 --> Router Class Initialized
INFO - 2024-10-29 09:56:32 --> Output Class Initialized
INFO - 2024-10-29 09:56:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:56:32 --> Input Class Initialized
INFO - 2024-10-29 09:56:32 --> Language Class Initialized
INFO - 2024-10-29 09:56:32 --> Loader Class Initialized
INFO - 2024-10-29 09:56:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:56:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:56:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:56:33 --> Helper loaded: string_helper
INFO - 2024-10-29 09:56:33 --> Helper loaded: form_helper
INFO - 2024-10-29 09:56:33 --> Helper loaded: my_helper
INFO - 2024-10-29 09:56:33 --> Database Driver Class Initialized
INFO - 2024-10-29 09:56:35 --> Upload Class Initialized
INFO - 2024-10-29 09:56:35 --> Email Class Initialized
INFO - 2024-10-29 09:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:56:35 --> Form Validation Class Initialized
INFO - 2024-10-29 09:56:35 --> Controller Class Initialized
INFO - 2024-10-29 15:26:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:26:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:26:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:26:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:57:32 --> Config Class Initialized
INFO - 2024-10-29 09:57:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:57:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:57:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:57:32 --> URI Class Initialized
INFO - 2024-10-29 09:57:32 --> Router Class Initialized
INFO - 2024-10-29 09:57:32 --> Output Class Initialized
INFO - 2024-10-29 09:57:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:57:32 --> Input Class Initialized
INFO - 2024-10-29 09:57:32 --> Language Class Initialized
INFO - 2024-10-29 09:57:32 --> Loader Class Initialized
INFO - 2024-10-29 09:57:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:57:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:57:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:57:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:57:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:57:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:57:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:57:34 --> Upload Class Initialized
INFO - 2024-10-29 09:57:34 --> Email Class Initialized
INFO - 2024-10-29 09:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:57:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:57:34 --> Controller Class Initialized
INFO - 2024-10-29 15:27:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:27:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:27:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:58:32 --> Config Class Initialized
INFO - 2024-10-29 09:58:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:58:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:58:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:58:32 --> URI Class Initialized
INFO - 2024-10-29 09:58:32 --> Router Class Initialized
INFO - 2024-10-29 09:58:32 --> Output Class Initialized
INFO - 2024-10-29 09:58:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:58:32 --> Input Class Initialized
INFO - 2024-10-29 09:58:32 --> Language Class Initialized
INFO - 2024-10-29 09:58:32 --> Loader Class Initialized
INFO - 2024-10-29 09:58:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:58:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:58:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:58:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:58:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:58:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:58:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:58:34 --> Upload Class Initialized
INFO - 2024-10-29 09:58:34 --> Email Class Initialized
INFO - 2024-10-29 09:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:58:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:58:34 --> Controller Class Initialized
INFO - 2024-10-29 15:28:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:28:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:28:35 --> Pagination Class Initialized
INFO - 2024-10-29 09:59:32 --> Config Class Initialized
INFO - 2024-10-29 09:59:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 09:59:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 09:59:32 --> Utf8 Class Initialized
INFO - 2024-10-29 09:59:32 --> URI Class Initialized
INFO - 2024-10-29 09:59:32 --> Router Class Initialized
INFO - 2024-10-29 09:59:32 --> Output Class Initialized
INFO - 2024-10-29 09:59:32 --> Security Class Initialized
DEBUG - 2024-10-29 09:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 09:59:32 --> Input Class Initialized
INFO - 2024-10-29 09:59:32 --> Language Class Initialized
INFO - 2024-10-29 09:59:32 --> Loader Class Initialized
INFO - 2024-10-29 09:59:32 --> Helper loaded: url_helper
INFO - 2024-10-29 09:59:32 --> Helper loaded: html_helper
INFO - 2024-10-29 09:59:32 --> Helper loaded: file_helper
INFO - 2024-10-29 09:59:32 --> Helper loaded: string_helper
INFO - 2024-10-29 09:59:32 --> Helper loaded: form_helper
INFO - 2024-10-29 09:59:32 --> Helper loaded: my_helper
INFO - 2024-10-29 09:59:32 --> Database Driver Class Initialized
INFO - 2024-10-29 09:59:34 --> Upload Class Initialized
INFO - 2024-10-29 09:59:34 --> Email Class Initialized
INFO - 2024-10-29 09:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 09:59:34 --> Form Validation Class Initialized
INFO - 2024-10-29 09:59:34 --> Controller Class Initialized
INFO - 2024-10-29 15:29:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:29:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:29:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:00:32 --> Config Class Initialized
INFO - 2024-10-29 10:00:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:00:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:00:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:00:32 --> URI Class Initialized
INFO - 2024-10-29 10:00:32 --> Router Class Initialized
INFO - 2024-10-29 10:00:32 --> Output Class Initialized
INFO - 2024-10-29 10:00:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:00:32 --> Input Class Initialized
INFO - 2024-10-29 10:00:32 --> Language Class Initialized
INFO - 2024-10-29 10:00:32 --> Loader Class Initialized
INFO - 2024-10-29 10:00:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:00:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:00:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:00:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:00:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:00:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:00:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:00:34 --> Upload Class Initialized
INFO - 2024-10-29 10:00:34 --> Email Class Initialized
INFO - 2024-10-29 10:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:00:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:00:34 --> Controller Class Initialized
INFO - 2024-10-29 15:30:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:30:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:30:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:01:32 --> Config Class Initialized
INFO - 2024-10-29 10:01:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:01:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:01:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:01:32 --> URI Class Initialized
INFO - 2024-10-29 10:01:32 --> Router Class Initialized
INFO - 2024-10-29 10:01:32 --> Output Class Initialized
INFO - 2024-10-29 10:01:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:01:32 --> Input Class Initialized
INFO - 2024-10-29 10:01:32 --> Language Class Initialized
INFO - 2024-10-29 10:01:32 --> Loader Class Initialized
INFO - 2024-10-29 10:01:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:01:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:01:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:01:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:01:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:01:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:01:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:01:35 --> Upload Class Initialized
INFO - 2024-10-29 10:01:35 --> Email Class Initialized
INFO - 2024-10-29 10:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:01:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:01:35 --> Controller Class Initialized
INFO - 2024-10-29 15:31:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:31:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:31:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:31:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:02:32 --> Config Class Initialized
INFO - 2024-10-29 10:02:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:02:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:02:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:02:32 --> URI Class Initialized
INFO - 2024-10-29 10:02:32 --> Router Class Initialized
INFO - 2024-10-29 10:02:32 --> Output Class Initialized
INFO - 2024-10-29 10:02:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:02:32 --> Input Class Initialized
INFO - 2024-10-29 10:02:32 --> Language Class Initialized
INFO - 2024-10-29 10:02:32 --> Loader Class Initialized
INFO - 2024-10-29 10:02:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:02:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:02:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:02:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:02:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:02:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:02:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:02:34 --> Upload Class Initialized
INFO - 2024-10-29 10:02:34 --> Email Class Initialized
INFO - 2024-10-29 10:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:02:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:02:34 --> Controller Class Initialized
INFO - 2024-10-29 15:32:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:32:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:32:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:03:32 --> Config Class Initialized
INFO - 2024-10-29 10:03:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:03:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:03:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:03:32 --> URI Class Initialized
INFO - 2024-10-29 10:03:32 --> Router Class Initialized
INFO - 2024-10-29 10:03:32 --> Output Class Initialized
INFO - 2024-10-29 10:03:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:03:32 --> Input Class Initialized
INFO - 2024-10-29 10:03:32 --> Language Class Initialized
INFO - 2024-10-29 10:03:32 --> Loader Class Initialized
INFO - 2024-10-29 10:03:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:03:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:03:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:03:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:03:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:03:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:03:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:03:34 --> Upload Class Initialized
INFO - 2024-10-29 10:03:34 --> Email Class Initialized
INFO - 2024-10-29 10:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:03:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:03:34 --> Controller Class Initialized
INFO - 2024-10-29 15:33:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:33:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:33:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:04:32 --> Config Class Initialized
INFO - 2024-10-29 10:04:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:04:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:04:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:04:32 --> URI Class Initialized
INFO - 2024-10-29 10:04:32 --> Router Class Initialized
INFO - 2024-10-29 10:04:32 --> Output Class Initialized
INFO - 2024-10-29 10:04:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:04:32 --> Input Class Initialized
INFO - 2024-10-29 10:04:32 --> Language Class Initialized
INFO - 2024-10-29 10:04:32 --> Loader Class Initialized
INFO - 2024-10-29 10:04:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:04:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:04:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:04:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:04:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:04:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:04:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:04:34 --> Upload Class Initialized
INFO - 2024-10-29 10:04:34 --> Email Class Initialized
INFO - 2024-10-29 10:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:04:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:04:34 --> Controller Class Initialized
INFO - 2024-10-29 15:34:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:34:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:34:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:34:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:05:32 --> Config Class Initialized
INFO - 2024-10-29 10:05:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:05:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:05:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:05:32 --> URI Class Initialized
INFO - 2024-10-29 10:05:32 --> Router Class Initialized
INFO - 2024-10-29 10:05:32 --> Output Class Initialized
INFO - 2024-10-29 10:05:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:05:32 --> Input Class Initialized
INFO - 2024-10-29 10:05:32 --> Language Class Initialized
INFO - 2024-10-29 10:05:32 --> Loader Class Initialized
INFO - 2024-10-29 10:05:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:05:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:05:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:05:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:05:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:05:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:05:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:05:34 --> Upload Class Initialized
INFO - 2024-10-29 10:05:34 --> Email Class Initialized
INFO - 2024-10-29 10:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:05:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:05:34 --> Controller Class Initialized
INFO - 2024-10-29 15:35:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:35:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:35:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:06:32 --> Config Class Initialized
INFO - 2024-10-29 10:06:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:06:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:06:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:06:32 --> URI Class Initialized
INFO - 2024-10-29 10:06:32 --> Router Class Initialized
INFO - 2024-10-29 10:06:32 --> Output Class Initialized
INFO - 2024-10-29 10:06:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:06:32 --> Input Class Initialized
INFO - 2024-10-29 10:06:32 --> Language Class Initialized
INFO - 2024-10-29 10:06:32 --> Loader Class Initialized
INFO - 2024-10-29 10:06:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:06:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:06:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:06:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:06:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:06:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:06:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:06:34 --> Upload Class Initialized
INFO - 2024-10-29 10:06:34 --> Email Class Initialized
INFO - 2024-10-29 10:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:06:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:06:34 --> Controller Class Initialized
INFO - 2024-10-29 15:36:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:36:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:36:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:07:32 --> Config Class Initialized
INFO - 2024-10-29 10:07:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:07:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:07:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:07:32 --> URI Class Initialized
INFO - 2024-10-29 10:07:32 --> Router Class Initialized
INFO - 2024-10-29 10:07:32 --> Output Class Initialized
INFO - 2024-10-29 10:07:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:07:32 --> Input Class Initialized
INFO - 2024-10-29 10:07:32 --> Language Class Initialized
INFO - 2024-10-29 10:07:32 --> Loader Class Initialized
INFO - 2024-10-29 10:07:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:07:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:07:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:07:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:07:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:07:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:07:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:07:35 --> Upload Class Initialized
INFO - 2024-10-29 10:07:35 --> Email Class Initialized
INFO - 2024-10-29 10:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:07:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:07:35 --> Controller Class Initialized
INFO - 2024-10-29 15:37:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:37:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:37:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:08:32 --> Config Class Initialized
INFO - 2024-10-29 10:08:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:08:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:08:32 --> URI Class Initialized
INFO - 2024-10-29 10:08:32 --> Router Class Initialized
INFO - 2024-10-29 10:08:32 --> Output Class Initialized
INFO - 2024-10-29 10:08:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:08:32 --> Input Class Initialized
INFO - 2024-10-29 10:08:32 --> Language Class Initialized
INFO - 2024-10-29 10:08:32 --> Loader Class Initialized
INFO - 2024-10-29 10:08:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:08:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:08:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:08:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:08:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:08:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:08:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:08:34 --> Upload Class Initialized
INFO - 2024-10-29 10:08:34 --> Email Class Initialized
INFO - 2024-10-29 10:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:08:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:08:34 --> Controller Class Initialized
INFO - 2024-10-29 15:38:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:38:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:38:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:09:32 --> Config Class Initialized
INFO - 2024-10-29 10:09:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:09:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:09:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:09:32 --> URI Class Initialized
INFO - 2024-10-29 10:09:32 --> Router Class Initialized
INFO - 2024-10-29 10:09:32 --> Output Class Initialized
INFO - 2024-10-29 10:09:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:09:32 --> Input Class Initialized
INFO - 2024-10-29 10:09:32 --> Language Class Initialized
INFO - 2024-10-29 10:09:32 --> Loader Class Initialized
INFO - 2024-10-29 10:09:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:09:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:09:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:09:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:09:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:09:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:09:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:09:34 --> Upload Class Initialized
INFO - 2024-10-29 10:09:34 --> Email Class Initialized
INFO - 2024-10-29 10:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:09:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:09:35 --> Controller Class Initialized
INFO - 2024-10-29 15:39:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:39:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:39:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:10:32 --> Config Class Initialized
INFO - 2024-10-29 10:10:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:10:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:10:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:10:32 --> URI Class Initialized
INFO - 2024-10-29 10:10:32 --> Router Class Initialized
INFO - 2024-10-29 10:10:32 --> Output Class Initialized
INFO - 2024-10-29 10:10:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:10:32 --> Input Class Initialized
INFO - 2024-10-29 10:10:32 --> Language Class Initialized
INFO - 2024-10-29 10:10:32 --> Loader Class Initialized
INFO - 2024-10-29 10:10:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:10:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:10:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:10:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:10:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:10:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:10:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:10:34 --> Upload Class Initialized
INFO - 2024-10-29 10:10:34 --> Email Class Initialized
INFO - 2024-10-29 10:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:10:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:10:34 --> Controller Class Initialized
INFO - 2024-10-29 15:40:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:40:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:40:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:11:32 --> Config Class Initialized
INFO - 2024-10-29 10:11:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:11:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:11:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:11:32 --> URI Class Initialized
INFO - 2024-10-29 10:11:32 --> Router Class Initialized
INFO - 2024-10-29 10:11:32 --> Output Class Initialized
INFO - 2024-10-29 10:11:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:11:32 --> Input Class Initialized
INFO - 2024-10-29 10:11:32 --> Language Class Initialized
INFO - 2024-10-29 10:11:32 --> Loader Class Initialized
INFO - 2024-10-29 10:11:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:11:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:11:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:11:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:11:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:11:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:11:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:11:34 --> Upload Class Initialized
INFO - 2024-10-29 10:11:34 --> Email Class Initialized
INFO - 2024-10-29 10:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:11:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:11:34 --> Controller Class Initialized
INFO - 2024-10-29 15:41:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:41:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:41:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:41:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:12:32 --> Config Class Initialized
INFO - 2024-10-29 10:12:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:12:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:12:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:12:32 --> URI Class Initialized
INFO - 2024-10-29 10:12:32 --> Router Class Initialized
INFO - 2024-10-29 10:12:32 --> Output Class Initialized
INFO - 2024-10-29 10:12:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:12:32 --> Input Class Initialized
INFO - 2024-10-29 10:12:32 --> Language Class Initialized
INFO - 2024-10-29 10:12:32 --> Loader Class Initialized
INFO - 2024-10-29 10:12:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:12:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:12:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:12:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:12:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:12:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:12:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:12:34 --> Upload Class Initialized
INFO - 2024-10-29 10:12:34 --> Email Class Initialized
INFO - 2024-10-29 10:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:12:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:12:34 --> Controller Class Initialized
INFO - 2024-10-29 15:42:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:42:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:42:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:13:32 --> Config Class Initialized
INFO - 2024-10-29 10:13:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:13:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:13:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:13:32 --> URI Class Initialized
INFO - 2024-10-29 10:13:32 --> Router Class Initialized
INFO - 2024-10-29 10:13:32 --> Output Class Initialized
INFO - 2024-10-29 10:13:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:13:32 --> Input Class Initialized
INFO - 2024-10-29 10:13:32 --> Language Class Initialized
INFO - 2024-10-29 10:13:32 --> Loader Class Initialized
INFO - 2024-10-29 10:13:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:13:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:13:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:13:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:13:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:13:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:13:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:13:34 --> Upload Class Initialized
INFO - 2024-10-29 10:13:34 --> Email Class Initialized
INFO - 2024-10-29 10:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:13:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:13:35 --> Controller Class Initialized
INFO - 2024-10-29 15:43:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:43:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:43:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:14:32 --> Config Class Initialized
INFO - 2024-10-29 10:14:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:14:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:14:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:14:32 --> URI Class Initialized
INFO - 2024-10-29 10:14:32 --> Router Class Initialized
INFO - 2024-10-29 10:14:32 --> Output Class Initialized
INFO - 2024-10-29 10:14:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:14:32 --> Input Class Initialized
INFO - 2024-10-29 10:14:32 --> Language Class Initialized
INFO - 2024-10-29 10:14:32 --> Loader Class Initialized
INFO - 2024-10-29 10:14:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:14:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:14:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:14:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:14:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:14:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:14:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:14:34 --> Upload Class Initialized
INFO - 2024-10-29 10:14:34 --> Email Class Initialized
INFO - 2024-10-29 10:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:14:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:14:34 --> Controller Class Initialized
INFO - 2024-10-29 15:44:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:44:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:44:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:44:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:15:32 --> Config Class Initialized
INFO - 2024-10-29 10:15:33 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:15:33 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:15:33 --> Utf8 Class Initialized
INFO - 2024-10-29 10:15:33 --> URI Class Initialized
INFO - 2024-10-29 10:15:33 --> Router Class Initialized
INFO - 2024-10-29 10:15:33 --> Output Class Initialized
INFO - 2024-10-29 10:15:33 --> Security Class Initialized
DEBUG - 2024-10-29 10:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:15:33 --> Input Class Initialized
INFO - 2024-10-29 10:15:33 --> Language Class Initialized
INFO - 2024-10-29 10:15:33 --> Loader Class Initialized
INFO - 2024-10-29 10:15:33 --> Helper loaded: url_helper
INFO - 2024-10-29 10:15:33 --> Helper loaded: html_helper
INFO - 2024-10-29 10:15:33 --> Helper loaded: file_helper
INFO - 2024-10-29 10:15:33 --> Helper loaded: string_helper
INFO - 2024-10-29 10:15:33 --> Helper loaded: form_helper
INFO - 2024-10-29 10:15:33 --> Helper loaded: my_helper
INFO - 2024-10-29 10:15:33 --> Database Driver Class Initialized
INFO - 2024-10-29 10:15:35 --> Upload Class Initialized
INFO - 2024-10-29 10:15:35 --> Email Class Initialized
INFO - 2024-10-29 10:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:15:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:15:35 --> Controller Class Initialized
INFO - 2024-10-29 15:45:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:45:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:45:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:16:32 --> Config Class Initialized
INFO - 2024-10-29 10:16:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:16:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:16:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:16:32 --> URI Class Initialized
INFO - 2024-10-29 10:16:32 --> Router Class Initialized
INFO - 2024-10-29 10:16:32 --> Output Class Initialized
INFO - 2024-10-29 10:16:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:16:32 --> Input Class Initialized
INFO - 2024-10-29 10:16:32 --> Language Class Initialized
INFO - 2024-10-29 10:16:32 --> Loader Class Initialized
INFO - 2024-10-29 10:16:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:16:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:16:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:16:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:16:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:16:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:16:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:16:34 --> Upload Class Initialized
INFO - 2024-10-29 10:16:34 --> Email Class Initialized
INFO - 2024-10-29 10:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:16:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:16:35 --> Controller Class Initialized
INFO - 2024-10-29 15:46:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:46:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:46:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:46:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:17:32 --> Config Class Initialized
INFO - 2024-10-29 10:17:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:17:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:17:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:17:32 --> URI Class Initialized
INFO - 2024-10-29 10:17:32 --> Router Class Initialized
INFO - 2024-10-29 10:17:32 --> Output Class Initialized
INFO - 2024-10-29 10:17:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:17:32 --> Input Class Initialized
INFO - 2024-10-29 10:17:32 --> Language Class Initialized
INFO - 2024-10-29 10:17:32 --> Loader Class Initialized
INFO - 2024-10-29 10:17:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:17:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:17:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:17:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:17:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:17:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:17:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:17:34 --> Upload Class Initialized
INFO - 2024-10-29 10:17:34 --> Email Class Initialized
INFO - 2024-10-29 10:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:17:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:17:34 --> Controller Class Initialized
INFO - 2024-10-29 15:47:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:47:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:47:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:18:32 --> Config Class Initialized
INFO - 2024-10-29 10:18:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:18:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:18:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:18:32 --> URI Class Initialized
INFO - 2024-10-29 10:18:32 --> Router Class Initialized
INFO - 2024-10-29 10:18:32 --> Output Class Initialized
INFO - 2024-10-29 10:18:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:18:32 --> Input Class Initialized
INFO - 2024-10-29 10:18:32 --> Language Class Initialized
INFO - 2024-10-29 10:18:32 --> Loader Class Initialized
INFO - 2024-10-29 10:18:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:18:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:18:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:18:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:18:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:18:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:18:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:18:34 --> Upload Class Initialized
INFO - 2024-10-29 10:18:34 --> Email Class Initialized
INFO - 2024-10-29 10:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:18:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:18:34 --> Controller Class Initialized
INFO - 2024-10-29 15:48:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:48:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:48:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:19:32 --> Config Class Initialized
INFO - 2024-10-29 10:19:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:19:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:19:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:19:32 --> URI Class Initialized
INFO - 2024-10-29 10:19:32 --> Router Class Initialized
INFO - 2024-10-29 10:19:32 --> Output Class Initialized
INFO - 2024-10-29 10:19:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:19:32 --> Input Class Initialized
INFO - 2024-10-29 10:19:32 --> Language Class Initialized
INFO - 2024-10-29 10:19:32 --> Loader Class Initialized
INFO - 2024-10-29 10:19:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:19:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:19:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:19:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:19:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:19:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:19:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:19:34 --> Upload Class Initialized
INFO - 2024-10-29 10:19:34 --> Email Class Initialized
INFO - 2024-10-29 10:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:19:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:19:34 --> Controller Class Initialized
INFO - 2024-10-29 15:49:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:49:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:49:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:20:32 --> Config Class Initialized
INFO - 2024-10-29 10:20:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:20:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:20:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:20:32 --> URI Class Initialized
INFO - 2024-10-29 10:20:32 --> Router Class Initialized
INFO - 2024-10-29 10:20:32 --> Output Class Initialized
INFO - 2024-10-29 10:20:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:20:32 --> Input Class Initialized
INFO - 2024-10-29 10:20:32 --> Language Class Initialized
INFO - 2024-10-29 10:20:32 --> Loader Class Initialized
INFO - 2024-10-29 10:20:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:20:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:20:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:20:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:20:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:20:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:20:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:20:34 --> Upload Class Initialized
INFO - 2024-10-29 10:20:34 --> Email Class Initialized
INFO - 2024-10-29 10:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:20:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:20:35 --> Controller Class Initialized
INFO - 2024-10-29 15:50:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:50:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:50:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:21:32 --> Config Class Initialized
INFO - 2024-10-29 10:21:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:21:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:21:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:21:32 --> URI Class Initialized
INFO - 2024-10-29 10:21:32 --> Router Class Initialized
INFO - 2024-10-29 10:21:32 --> Output Class Initialized
INFO - 2024-10-29 10:21:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:21:32 --> Input Class Initialized
INFO - 2024-10-29 10:21:32 --> Language Class Initialized
INFO - 2024-10-29 10:21:32 --> Loader Class Initialized
INFO - 2024-10-29 10:21:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:21:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:21:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:21:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:21:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:21:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:21:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:21:34 --> Upload Class Initialized
INFO - 2024-10-29 10:21:34 --> Email Class Initialized
INFO - 2024-10-29 10:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:21:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:21:34 --> Controller Class Initialized
INFO - 2024-10-29 15:51:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:51:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:51:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:22:32 --> Config Class Initialized
INFO - 2024-10-29 10:22:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:22:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:22:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:22:32 --> URI Class Initialized
INFO - 2024-10-29 10:22:32 --> Router Class Initialized
INFO - 2024-10-29 10:22:32 --> Output Class Initialized
INFO - 2024-10-29 10:22:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:22:32 --> Input Class Initialized
INFO - 2024-10-29 10:22:32 --> Language Class Initialized
INFO - 2024-10-29 10:22:32 --> Loader Class Initialized
INFO - 2024-10-29 10:22:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:22:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:22:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:22:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:22:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:22:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:22:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:22:35 --> Upload Class Initialized
INFO - 2024-10-29 10:22:35 --> Email Class Initialized
INFO - 2024-10-29 10:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:22:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:22:35 --> Controller Class Initialized
INFO - 2024-10-29 15:52:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:52:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:52:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:23:32 --> Config Class Initialized
INFO - 2024-10-29 10:23:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:23:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:23:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:23:32 --> URI Class Initialized
INFO - 2024-10-29 10:23:32 --> Router Class Initialized
INFO - 2024-10-29 10:23:32 --> Output Class Initialized
INFO - 2024-10-29 10:23:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:23:32 --> Input Class Initialized
INFO - 2024-10-29 10:23:32 --> Language Class Initialized
INFO - 2024-10-29 10:23:32 --> Loader Class Initialized
INFO - 2024-10-29 10:23:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:23:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:23:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:23:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:23:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:23:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:23:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:23:34 --> Upload Class Initialized
INFO - 2024-10-29 10:23:34 --> Email Class Initialized
INFO - 2024-10-29 10:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:23:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:23:35 --> Controller Class Initialized
INFO - 2024-10-29 15:53:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:53:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:53:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:53:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:24:32 --> Config Class Initialized
INFO - 2024-10-29 10:24:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:24:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:24:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:24:32 --> URI Class Initialized
INFO - 2024-10-29 10:24:32 --> Router Class Initialized
INFO - 2024-10-29 10:24:32 --> Output Class Initialized
INFO - 2024-10-29 10:24:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:24:32 --> Input Class Initialized
INFO - 2024-10-29 10:24:32 --> Language Class Initialized
INFO - 2024-10-29 10:24:32 --> Loader Class Initialized
INFO - 2024-10-29 10:24:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:24:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:24:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:24:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:24:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:24:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:24:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:24:34 --> Upload Class Initialized
INFO - 2024-10-29 10:24:34 --> Email Class Initialized
INFO - 2024-10-29 10:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:24:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:24:34 --> Controller Class Initialized
INFO - 2024-10-29 15:54:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:54:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:54:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:54:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:25:32 --> Config Class Initialized
INFO - 2024-10-29 10:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:25:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:25:32 --> URI Class Initialized
INFO - 2024-10-29 10:25:32 --> Router Class Initialized
INFO - 2024-10-29 10:25:32 --> Output Class Initialized
INFO - 2024-10-29 10:25:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:25:32 --> Input Class Initialized
INFO - 2024-10-29 10:25:32 --> Language Class Initialized
INFO - 2024-10-29 10:25:32 --> Loader Class Initialized
INFO - 2024-10-29 10:25:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:25:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:25:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:25:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:25:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:25:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:25:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:25:34 --> Upload Class Initialized
INFO - 2024-10-29 10:25:34 --> Email Class Initialized
INFO - 2024-10-29 10:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:25:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:25:34 --> Controller Class Initialized
INFO - 2024-10-29 15:55:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:55:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:55:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:55:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:26:32 --> Config Class Initialized
INFO - 2024-10-29 10:26:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:26:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:26:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:26:33 --> URI Class Initialized
INFO - 2024-10-29 10:26:33 --> Router Class Initialized
INFO - 2024-10-29 10:26:33 --> Output Class Initialized
INFO - 2024-10-29 10:26:33 --> Security Class Initialized
DEBUG - 2024-10-29 10:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:26:33 --> Input Class Initialized
INFO - 2024-10-29 10:26:33 --> Language Class Initialized
INFO - 2024-10-29 10:26:33 --> Loader Class Initialized
INFO - 2024-10-29 10:26:33 --> Helper loaded: url_helper
INFO - 2024-10-29 10:26:33 --> Helper loaded: html_helper
INFO - 2024-10-29 10:26:33 --> Helper loaded: file_helper
INFO - 2024-10-29 10:26:33 --> Helper loaded: string_helper
INFO - 2024-10-29 10:26:33 --> Helper loaded: form_helper
INFO - 2024-10-29 10:26:33 --> Helper loaded: my_helper
INFO - 2024-10-29 10:26:33 --> Database Driver Class Initialized
INFO - 2024-10-29 10:26:35 --> Upload Class Initialized
INFO - 2024-10-29 10:26:35 --> Email Class Initialized
INFO - 2024-10-29 10:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:26:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:26:35 --> Controller Class Initialized
INFO - 2024-10-29 15:56:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:56:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:56:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:27:32 --> Config Class Initialized
INFO - 2024-10-29 10:27:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:27:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:27:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:27:32 --> URI Class Initialized
INFO - 2024-10-29 10:27:32 --> Router Class Initialized
INFO - 2024-10-29 10:27:32 --> Output Class Initialized
INFO - 2024-10-29 10:27:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:27:32 --> Input Class Initialized
INFO - 2024-10-29 10:27:32 --> Language Class Initialized
INFO - 2024-10-29 10:27:32 --> Loader Class Initialized
INFO - 2024-10-29 10:27:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:27:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:27:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:27:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:27:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:27:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:27:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:27:34 --> Upload Class Initialized
INFO - 2024-10-29 10:27:34 --> Email Class Initialized
INFO - 2024-10-29 10:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:27:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:27:34 --> Controller Class Initialized
INFO - 2024-10-29 15:57:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:57:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:57:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:28:32 --> Config Class Initialized
INFO - 2024-10-29 10:28:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:28:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:28:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:28:32 --> URI Class Initialized
INFO - 2024-10-29 10:28:32 --> Router Class Initialized
INFO - 2024-10-29 10:28:32 --> Output Class Initialized
INFO - 2024-10-29 10:28:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:28:32 --> Input Class Initialized
INFO - 2024-10-29 10:28:32 --> Language Class Initialized
INFO - 2024-10-29 10:28:32 --> Loader Class Initialized
INFO - 2024-10-29 10:28:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:28:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:28:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:28:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:28:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:28:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:28:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:28:34 --> Upload Class Initialized
INFO - 2024-10-29 10:28:34 --> Email Class Initialized
INFO - 2024-10-29 10:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:28:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:28:35 --> Controller Class Initialized
INFO - 2024-10-29 15:58:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:58:35 --> Model "MainModel" initialized
INFO - 2024-10-29 15:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:58:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:29:32 --> Config Class Initialized
INFO - 2024-10-29 10:29:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:29:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:29:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:29:32 --> URI Class Initialized
INFO - 2024-10-29 10:29:32 --> Router Class Initialized
INFO - 2024-10-29 10:29:32 --> Output Class Initialized
INFO - 2024-10-29 10:29:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:29:32 --> Input Class Initialized
INFO - 2024-10-29 10:29:32 --> Language Class Initialized
INFO - 2024-10-29 10:29:32 --> Loader Class Initialized
INFO - 2024-10-29 10:29:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:29:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:29:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:29:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:29:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:29:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:29:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:29:34 --> Upload Class Initialized
INFO - 2024-10-29 10:29:34 --> Email Class Initialized
INFO - 2024-10-29 10:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:29:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:29:34 --> Controller Class Initialized
INFO - 2024-10-29 15:59:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 15:59:34 --> Model "MainModel" initialized
INFO - 2024-10-29 15:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 15:59:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:30:32 --> Config Class Initialized
INFO - 2024-10-29 10:30:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:30:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:30:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:30:32 --> URI Class Initialized
INFO - 2024-10-29 10:30:32 --> Router Class Initialized
INFO - 2024-10-29 10:30:32 --> Output Class Initialized
INFO - 2024-10-29 10:30:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:30:32 --> Input Class Initialized
INFO - 2024-10-29 10:30:32 --> Language Class Initialized
INFO - 2024-10-29 10:30:32 --> Loader Class Initialized
INFO - 2024-10-29 10:30:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:30:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:30:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:30:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:30:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:30:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:30:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:30:34 --> Upload Class Initialized
INFO - 2024-10-29 10:30:34 --> Email Class Initialized
INFO - 2024-10-29 10:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:30:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:30:34 --> Controller Class Initialized
INFO - 2024-10-29 16:00:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:00:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:00:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:31:32 --> Config Class Initialized
INFO - 2024-10-29 10:31:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:31:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:31:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:31:32 --> URI Class Initialized
INFO - 2024-10-29 10:31:32 --> Router Class Initialized
INFO - 2024-10-29 10:31:32 --> Output Class Initialized
INFO - 2024-10-29 10:31:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:31:32 --> Input Class Initialized
INFO - 2024-10-29 10:31:32 --> Language Class Initialized
INFO - 2024-10-29 10:31:32 --> Loader Class Initialized
INFO - 2024-10-29 10:31:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:31:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:31:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:31:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:31:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:31:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:31:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:31:34 --> Upload Class Initialized
INFO - 2024-10-29 10:31:34 --> Email Class Initialized
INFO - 2024-10-29 10:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:31:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:31:34 --> Controller Class Initialized
INFO - 2024-10-29 16:01:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:01:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:01:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:32:32 --> Config Class Initialized
INFO - 2024-10-29 10:32:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:32:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:32:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:32:32 --> URI Class Initialized
INFO - 2024-10-29 10:32:32 --> Router Class Initialized
INFO - 2024-10-29 10:32:32 --> Output Class Initialized
INFO - 2024-10-29 10:32:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:32:32 --> Input Class Initialized
INFO - 2024-10-29 10:32:32 --> Language Class Initialized
INFO - 2024-10-29 10:32:32 --> Loader Class Initialized
INFO - 2024-10-29 10:32:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:32:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:32:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:32:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:32:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:32:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:32:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:32:34 --> Upload Class Initialized
INFO - 2024-10-29 10:32:34 --> Email Class Initialized
INFO - 2024-10-29 10:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:32:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:32:35 --> Controller Class Initialized
INFO - 2024-10-29 16:02:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:02:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:02:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:02:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:33:32 --> Config Class Initialized
INFO - 2024-10-29 10:33:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:33:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:33:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:33:32 --> URI Class Initialized
INFO - 2024-10-29 10:33:32 --> Router Class Initialized
INFO - 2024-10-29 10:33:32 --> Output Class Initialized
INFO - 2024-10-29 10:33:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:33:32 --> Input Class Initialized
INFO - 2024-10-29 10:33:32 --> Language Class Initialized
INFO - 2024-10-29 10:33:32 --> Loader Class Initialized
INFO - 2024-10-29 10:33:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:33:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:33:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:33:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:33:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:33:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:33:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:33:34 --> Upload Class Initialized
INFO - 2024-10-29 10:33:34 --> Email Class Initialized
INFO - 2024-10-29 10:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:33:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:33:34 --> Controller Class Initialized
INFO - 2024-10-29 16:03:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:03:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:03:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:34:32 --> Config Class Initialized
INFO - 2024-10-29 10:34:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:34:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:34:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:34:32 --> URI Class Initialized
INFO - 2024-10-29 10:34:32 --> Router Class Initialized
INFO - 2024-10-29 10:34:32 --> Output Class Initialized
INFO - 2024-10-29 10:34:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:34:32 --> Input Class Initialized
INFO - 2024-10-29 10:34:32 --> Language Class Initialized
INFO - 2024-10-29 10:34:32 --> Loader Class Initialized
INFO - 2024-10-29 10:34:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:34:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:34:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:34:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:34:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:34:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:34:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:34:34 --> Upload Class Initialized
INFO - 2024-10-29 10:34:34 --> Email Class Initialized
INFO - 2024-10-29 10:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:34:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:34:35 --> Controller Class Initialized
INFO - 2024-10-29 16:04:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:04:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:04:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:35:32 --> Config Class Initialized
INFO - 2024-10-29 10:35:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:35:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:35:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:35:32 --> URI Class Initialized
INFO - 2024-10-29 10:35:32 --> Router Class Initialized
INFO - 2024-10-29 10:35:32 --> Output Class Initialized
INFO - 2024-10-29 10:35:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:35:32 --> Input Class Initialized
INFO - 2024-10-29 10:35:32 --> Language Class Initialized
INFO - 2024-10-29 10:35:32 --> Loader Class Initialized
INFO - 2024-10-29 10:35:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:35:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:35:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:35:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:35:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:35:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:35:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:35:34 --> Upload Class Initialized
INFO - 2024-10-29 10:35:34 --> Email Class Initialized
INFO - 2024-10-29 10:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:35:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:35:34 --> Controller Class Initialized
INFO - 2024-10-29 16:05:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:05:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:05:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:36:32 --> Config Class Initialized
INFO - 2024-10-29 10:36:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:36:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:36:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:36:32 --> URI Class Initialized
INFO - 2024-10-29 10:36:32 --> Router Class Initialized
INFO - 2024-10-29 10:36:32 --> Output Class Initialized
INFO - 2024-10-29 10:36:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:36:32 --> Input Class Initialized
INFO - 2024-10-29 10:36:32 --> Language Class Initialized
INFO - 2024-10-29 10:36:32 --> Loader Class Initialized
INFO - 2024-10-29 10:36:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:36:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:36:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:36:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:36:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:36:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:36:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:36:34 --> Upload Class Initialized
INFO - 2024-10-29 10:36:34 --> Email Class Initialized
INFO - 2024-10-29 10:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:36:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:36:34 --> Controller Class Initialized
INFO - 2024-10-29 16:06:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:06:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:06:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:06:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:37:32 --> Config Class Initialized
INFO - 2024-10-29 10:37:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:37:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:37:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:37:32 --> URI Class Initialized
INFO - 2024-10-29 10:37:32 --> Router Class Initialized
INFO - 2024-10-29 10:37:32 --> Output Class Initialized
INFO - 2024-10-29 10:37:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:37:32 --> Input Class Initialized
INFO - 2024-10-29 10:37:32 --> Language Class Initialized
INFO - 2024-10-29 10:37:32 --> Loader Class Initialized
INFO - 2024-10-29 10:37:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:37:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:37:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:37:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:37:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:37:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:37:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:37:34 --> Upload Class Initialized
INFO - 2024-10-29 10:37:35 --> Email Class Initialized
INFO - 2024-10-29 10:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:37:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:37:35 --> Controller Class Initialized
INFO - 2024-10-29 16:07:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:07:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:07:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:38:32 --> Config Class Initialized
INFO - 2024-10-29 10:38:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:38:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:38:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:38:32 --> URI Class Initialized
INFO - 2024-10-29 10:38:32 --> Router Class Initialized
INFO - 2024-10-29 10:38:32 --> Output Class Initialized
INFO - 2024-10-29 10:38:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:38:32 --> Input Class Initialized
INFO - 2024-10-29 10:38:32 --> Language Class Initialized
INFO - 2024-10-29 10:38:32 --> Loader Class Initialized
INFO - 2024-10-29 10:38:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:38:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:38:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:38:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:38:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:38:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:38:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:38:34 --> Upload Class Initialized
INFO - 2024-10-29 10:38:34 --> Email Class Initialized
INFO - 2024-10-29 10:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:38:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:38:34 --> Controller Class Initialized
INFO - 2024-10-29 16:08:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:08:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:08:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:39:32 --> Config Class Initialized
INFO - 2024-10-29 10:39:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:39:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:39:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:39:32 --> URI Class Initialized
INFO - 2024-10-29 10:39:32 --> Router Class Initialized
INFO - 2024-10-29 10:39:32 --> Output Class Initialized
INFO - 2024-10-29 10:39:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:39:32 --> Input Class Initialized
INFO - 2024-10-29 10:39:32 --> Language Class Initialized
INFO - 2024-10-29 10:39:32 --> Loader Class Initialized
INFO - 2024-10-29 10:39:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:39:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:39:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:39:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:39:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:39:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:39:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:39:34 --> Upload Class Initialized
INFO - 2024-10-29 10:39:34 --> Email Class Initialized
INFO - 2024-10-29 10:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:39:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:39:34 --> Controller Class Initialized
INFO - 2024-10-29 16:09:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:09:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:09:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:40:32 --> Config Class Initialized
INFO - 2024-10-29 10:40:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:40:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:40:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:40:32 --> URI Class Initialized
INFO - 2024-10-29 10:40:32 --> Router Class Initialized
INFO - 2024-10-29 10:40:32 --> Output Class Initialized
INFO - 2024-10-29 10:40:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:40:32 --> Input Class Initialized
INFO - 2024-10-29 10:40:32 --> Language Class Initialized
INFO - 2024-10-29 10:40:32 --> Loader Class Initialized
INFO - 2024-10-29 10:40:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:40:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:40:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:40:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:40:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:40:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:40:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:40:35 --> Upload Class Initialized
INFO - 2024-10-29 10:40:35 --> Email Class Initialized
INFO - 2024-10-29 10:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:40:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:40:35 --> Controller Class Initialized
INFO - 2024-10-29 16:10:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:10:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:10:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:41:11 --> Config Class Initialized
INFO - 2024-10-29 10:41:11 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:11 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:11 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:11 --> URI Class Initialized
DEBUG - 2024-10-29 10:41:11 --> No URI present. Default controller set.
INFO - 2024-10-29 10:41:11 --> Router Class Initialized
INFO - 2024-10-29 10:41:11 --> Output Class Initialized
INFO - 2024-10-29 10:41:11 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:11 --> Input Class Initialized
INFO - 2024-10-29 10:41:11 --> Language Class Initialized
INFO - 2024-10-29 10:41:12 --> Loader Class Initialized
INFO - 2024-10-29 10:41:12 --> Helper loaded: url_helper
INFO - 2024-10-29 10:41:12 --> Helper loaded: html_helper
INFO - 2024-10-29 10:41:12 --> Helper loaded: file_helper
INFO - 2024-10-29 10:41:12 --> Helper loaded: string_helper
INFO - 2024-10-29 10:41:12 --> Helper loaded: form_helper
INFO - 2024-10-29 10:41:12 --> Helper loaded: my_helper
INFO - 2024-10-29 10:41:12 --> Database Driver Class Initialized
INFO - 2024-10-29 10:41:14 --> Config Class Initialized
INFO - 2024-10-29 10:41:14 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:14 --> Upload Class Initialized
DEBUG - 2024-10-29 10:41:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:14 --> Email Class Initialized
INFO - 2024-10-29 10:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:41:14 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:14 --> Form Validation Class Initialized
INFO - 2024-10-29 10:41:14 --> URI Class Initialized
INFO - 2024-10-29 10:41:14 --> Controller Class Initialized
DEBUG - 2024-10-29 10:41:14 --> No URI present. Default controller set.
INFO - 2024-10-29 16:11:14 --> Model "MainModel" initialized
INFO - 2024-10-29 10:41:14 --> Router Class Initialized
INFO - 2024-10-29 10:41:14 --> Output Class Initialized
INFO - 2024-10-29 16:11:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 10:41:14 --> Security Class Initialized
INFO - 2024-10-29 16:11:14 --> Final output sent to browser
DEBUG - 2024-10-29 10:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:14 --> Input Class Initialized
DEBUG - 2024-10-29 16:11:14 --> Total execution time: 2.6163
INFO - 2024-10-29 10:41:14 --> Language Class Initialized
INFO - 2024-10-29 10:41:14 --> Loader Class Initialized
INFO - 2024-10-29 10:41:14 --> Helper loaded: url_helper
INFO - 2024-10-29 10:41:14 --> Helper loaded: html_helper
INFO - 2024-10-29 10:41:14 --> Config Class Initialized
INFO - 2024-10-29 10:41:14 --> Helper loaded: file_helper
INFO - 2024-10-29 10:41:14 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:14 --> Helper loaded: string_helper
INFO - 2024-10-29 10:41:14 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:14 --> URI Class Initialized
INFO - 2024-10-29 10:41:14 --> Helper loaded: form_helper
INFO - 2024-10-29 10:41:14 --> Helper loaded: my_helper
INFO - 2024-10-29 10:41:14 --> Router Class Initialized
INFO - 2024-10-29 10:41:14 --> Database Driver Class Initialized
INFO - 2024-10-29 10:41:14 --> Output Class Initialized
INFO - 2024-10-29 10:41:14 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:14 --> Input Class Initialized
INFO - 2024-10-29 10:41:14 --> Language Class Initialized
ERROR - 2024-10-29 10:41:14 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-29 10:41:14 --> Config Class Initialized
INFO - 2024-10-29 10:41:14 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:14 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:14 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:14 --> URI Class Initialized
INFO - 2024-10-29 10:41:14 --> Router Class Initialized
INFO - 2024-10-29 10:41:14 --> Output Class Initialized
INFO - 2024-10-29 10:41:14 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:15 --> Input Class Initialized
INFO - 2024-10-29 10:41:15 --> Language Class Initialized
ERROR - 2024-10-29 10:41:15 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-29 10:41:15 --> Config Class Initialized
INFO - 2024-10-29 10:41:15 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:15 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:15 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:15 --> URI Class Initialized
DEBUG - 2024-10-29 10:41:15 --> No URI present. Default controller set.
INFO - 2024-10-29 10:41:15 --> Router Class Initialized
INFO - 2024-10-29 10:41:15 --> Output Class Initialized
INFO - 2024-10-29 10:41:15 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:15 --> Input Class Initialized
INFO - 2024-10-29 10:41:15 --> Language Class Initialized
INFO - 2024-10-29 10:41:15 --> Loader Class Initialized
INFO - 2024-10-29 10:41:15 --> Helper loaded: url_helper
INFO - 2024-10-29 10:41:15 --> Helper loaded: html_helper
INFO - 2024-10-29 10:41:15 --> Helper loaded: file_helper
INFO - 2024-10-29 10:41:15 --> Helper loaded: string_helper
INFO - 2024-10-29 10:41:15 --> Helper loaded: form_helper
INFO - 2024-10-29 10:41:15 --> Helper loaded: my_helper
INFO - 2024-10-29 10:41:15 --> Database Driver Class Initialized
INFO - 2024-10-29 10:41:16 --> Upload Class Initialized
INFO - 2024-10-29 10:41:16 --> Email Class Initialized
INFO - 2024-10-29 10:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:41:16 --> Form Validation Class Initialized
INFO - 2024-10-29 10:41:16 --> Controller Class Initialized
INFO - 2024-10-29 16:11:16 --> Model "MainModel" initialized
INFO - 2024-10-29 16:11:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 16:11:16 --> Final output sent to browser
DEBUG - 2024-10-29 16:11:16 --> Total execution time: 2.6999
INFO - 2024-10-29 10:41:16 --> Config Class Initialized
INFO - 2024-10-29 10:41:16 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:16 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:16 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:16 --> URI Class Initialized
INFO - 2024-10-29 10:41:16 --> Router Class Initialized
INFO - 2024-10-29 10:41:16 --> Output Class Initialized
INFO - 2024-10-29 10:41:16 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:17 --> Input Class Initialized
INFO - 2024-10-29 10:41:17 --> Language Class Initialized
ERROR - 2024-10-29 10:41:17 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-29 10:41:17 --> Config Class Initialized
INFO - 2024-10-29 10:41:17 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:17 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:17 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:17 --> URI Class Initialized
INFO - 2024-10-29 10:41:17 --> Router Class Initialized
INFO - 2024-10-29 10:41:17 --> Output Class Initialized
INFO - 2024-10-29 10:41:17 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:17 --> Input Class Initialized
INFO - 2024-10-29 10:41:17 --> Language Class Initialized
ERROR - 2024-10-29 10:41:17 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-29 10:41:17 --> Config Class Initialized
INFO - 2024-10-29 10:41:17 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:17 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:17 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:17 --> URI Class Initialized
DEBUG - 2024-10-29 10:41:17 --> No URI present. Default controller set.
INFO - 2024-10-29 10:41:17 --> Router Class Initialized
INFO - 2024-10-29 10:41:17 --> Output Class Initialized
INFO - 2024-10-29 10:41:17 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:17 --> Input Class Initialized
INFO - 2024-10-29 10:41:17 --> Language Class Initialized
INFO - 2024-10-29 10:41:17 --> Loader Class Initialized
INFO - 2024-10-29 10:41:17 --> Helper loaded: url_helper
INFO - 2024-10-29 10:41:17 --> Helper loaded: html_helper
INFO - 2024-10-29 10:41:17 --> Helper loaded: file_helper
INFO - 2024-10-29 10:41:17 --> Helper loaded: string_helper
INFO - 2024-10-29 10:41:17 --> Helper loaded: form_helper
INFO - 2024-10-29 10:41:17 --> Helper loaded: my_helper
INFO - 2024-10-29 10:41:17 --> Database Driver Class Initialized
INFO - 2024-10-29 10:41:17 --> Upload Class Initialized
INFO - 2024-10-29 10:41:17 --> Email Class Initialized
INFO - 2024-10-29 10:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:41:17 --> Form Validation Class Initialized
INFO - 2024-10-29 10:41:17 --> Controller Class Initialized
INFO - 2024-10-29 16:11:17 --> Model "MainModel" initialized
INFO - 2024-10-29 16:11:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 16:11:18 --> Final output sent to browser
DEBUG - 2024-10-29 16:11:18 --> Total execution time: 2.8826
INFO - 2024-10-29 10:41:18 --> Config Class Initialized
INFO - 2024-10-29 10:41:18 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:18 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:18 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:18 --> URI Class Initialized
INFO - 2024-10-29 10:41:18 --> Router Class Initialized
INFO - 2024-10-29 10:41:18 --> Output Class Initialized
INFO - 2024-10-29 10:41:18 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:18 --> Input Class Initialized
INFO - 2024-10-29 10:41:18 --> Language Class Initialized
ERROR - 2024-10-29 10:41:18 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-29 10:41:18 --> Config Class Initialized
INFO - 2024-10-29 10:41:18 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:18 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:18 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:18 --> URI Class Initialized
INFO - 2024-10-29 10:41:18 --> Router Class Initialized
INFO - 2024-10-29 10:41:18 --> Output Class Initialized
INFO - 2024-10-29 10:41:18 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:18 --> Input Class Initialized
INFO - 2024-10-29 10:41:18 --> Language Class Initialized
ERROR - 2024-10-29 10:41:18 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-29 10:41:18 --> Config Class Initialized
INFO - 2024-10-29 10:41:18 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:18 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:18 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:18 --> URI Class Initialized
INFO - 2024-10-29 10:41:18 --> Router Class Initialized
INFO - 2024-10-29 10:41:18 --> Output Class Initialized
INFO - 2024-10-29 10:41:18 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:18 --> Input Class Initialized
INFO - 2024-10-29 10:41:18 --> Language Class Initialized
ERROR - 2024-10-29 10:41:18 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-29 10:41:18 --> Config Class Initialized
INFO - 2024-10-29 10:41:18 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:18 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:18 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:18 --> URI Class Initialized
INFO - 2024-10-29 10:41:18 --> Router Class Initialized
INFO - 2024-10-29 10:41:18 --> Output Class Initialized
INFO - 2024-10-29 10:41:18 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:18 --> Input Class Initialized
INFO - 2024-10-29 10:41:18 --> Language Class Initialized
ERROR - 2024-10-29 10:41:19 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-29 10:41:19 --> Config Class Initialized
INFO - 2024-10-29 10:41:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:19 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:19 --> URI Class Initialized
INFO - 2024-10-29 10:41:19 --> Router Class Initialized
INFO - 2024-10-29 10:41:19 --> Output Class Initialized
INFO - 2024-10-29 10:41:19 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:19 --> Input Class Initialized
INFO - 2024-10-29 10:41:19 --> Language Class Initialized
ERROR - 2024-10-29 10:41:19 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-29 10:41:19 --> Config Class Initialized
INFO - 2024-10-29 10:41:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:19 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:19 --> URI Class Initialized
INFO - 2024-10-29 10:41:19 --> Router Class Initialized
INFO - 2024-10-29 10:41:19 --> Output Class Initialized
INFO - 2024-10-29 10:41:19 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:19 --> Input Class Initialized
INFO - 2024-10-29 10:41:19 --> Language Class Initialized
ERROR - 2024-10-29 10:41:19 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-29 10:41:19 --> Config Class Initialized
INFO - 2024-10-29 10:41:19 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:19 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:19 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:19 --> Upload Class Initialized
INFO - 2024-10-29 10:41:19 --> URI Class Initialized
INFO - 2024-10-29 10:41:19 --> Email Class Initialized
INFO - 2024-10-29 10:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:41:19 --> Form Validation Class Initialized
INFO - 2024-10-29 10:41:19 --> Router Class Initialized
INFO - 2024-10-29 10:41:19 --> Output Class Initialized
INFO - 2024-10-29 10:41:19 --> Controller Class Initialized
INFO - 2024-10-29 10:41:19 --> Security Class Initialized
INFO - 2024-10-29 16:11:19 --> Model "MainModel" initialized
DEBUG - 2024-10-29 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 16:11:19 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 10:41:20 --> Input Class Initialized
INFO - 2024-10-29 16:11:20 --> Final output sent to browser
INFO - 2024-10-29 10:41:20 --> Language Class Initialized
DEBUG - 2024-10-29 16:11:20 --> Total execution time: 2.6158
ERROR - 2024-10-29 10:41:20 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-29 10:41:20 --> Config Class Initialized
INFO - 2024-10-29 10:41:20 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:20 --> Config Class Initialized
DEBUG - 2024-10-29 10:41:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:20 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:20 --> Utf8 Class Initialized
DEBUG - 2024-10-29 10:41:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:20 --> URI Class Initialized
INFO - 2024-10-29 10:41:20 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:20 --> Router Class Initialized
INFO - 2024-10-29 10:41:20 --> URI Class Initialized
INFO - 2024-10-29 10:41:20 --> Output Class Initialized
INFO - 2024-10-29 10:41:20 --> Router Class Initialized
INFO - 2024-10-29 10:41:20 --> Output Class Initialized
INFO - 2024-10-29 10:41:20 --> Security Class Initialized
INFO - 2024-10-29 10:41:20 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-29 10:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:20 --> Input Class Initialized
INFO - 2024-10-29 10:41:20 --> Input Class Initialized
INFO - 2024-10-29 10:41:20 --> Language Class Initialized
INFO - 2024-10-29 10:41:20 --> Language Class Initialized
ERROR - 2024-10-29 10:41:20 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2024-10-29 10:41:20 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-29 10:41:20 --> Config Class Initialized
INFO - 2024-10-29 10:41:20 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:20 --> Config Class Initialized
DEBUG - 2024-10-29 10:41:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:20 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:20 --> Utf8 Class Initialized
DEBUG - 2024-10-29 10:41:20 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:21 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:21 --> URI Class Initialized
INFO - 2024-10-29 10:41:21 --> Router Class Initialized
INFO - 2024-10-29 10:41:21 --> URI Class Initialized
INFO - 2024-10-29 10:41:21 --> Output Class Initialized
INFO - 2024-10-29 10:41:21 --> Router Class Initialized
INFO - 2024-10-29 10:41:21 --> Output Class Initialized
INFO - 2024-10-29 10:41:21 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:21 --> Security Class Initialized
INFO - 2024-10-29 10:41:21 --> Input Class Initialized
DEBUG - 2024-10-29 10:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:21 --> Language Class Initialized
INFO - 2024-10-29 10:41:21 --> Input Class Initialized
ERROR - 2024-10-29 10:41:21 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-29 10:41:21 --> Language Class Initialized
ERROR - 2024-10-29 10:41:21 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-29 10:41:21 --> Config Class Initialized
INFO - 2024-10-29 10:41:21 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:21 --> Config Class Initialized
INFO - 2024-10-29 10:41:21 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:21 --> Utf8 Class Initialized
DEBUG - 2024-10-29 10:41:21 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:21 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:21 --> URI Class Initialized
INFO - 2024-10-29 10:41:21 --> URI Class Initialized
INFO - 2024-10-29 10:41:21 --> Router Class Initialized
INFO - 2024-10-29 10:41:21 --> Router Class Initialized
INFO - 2024-10-29 10:41:21 --> Output Class Initialized
INFO - 2024-10-29 10:41:22 --> Output Class Initialized
INFO - 2024-10-29 10:41:22 --> Security Class Initialized
INFO - 2024-10-29 10:41:22 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-29 10:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:22 --> Input Class Initialized
INFO - 2024-10-29 10:41:22 --> Input Class Initialized
INFO - 2024-10-29 10:41:22 --> Language Class Initialized
ERROR - 2024-10-29 10:41:22 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-29 10:41:22 --> Language Class Initialized
ERROR - 2024-10-29 10:41:22 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-29 10:41:22 --> Config Class Initialized
INFO - 2024-10-29 10:41:22 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:22 --> Config Class Initialized
DEBUG - 2024-10-29 10:41:22 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:22 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:22 --> Utf8 Class Initialized
DEBUG - 2024-10-29 10:41:23 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:23 --> URI Class Initialized
INFO - 2024-10-29 10:41:23 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:23 --> Router Class Initialized
INFO - 2024-10-29 10:41:23 --> URI Class Initialized
INFO - 2024-10-29 10:41:23 --> Output Class Initialized
INFO - 2024-10-29 10:41:23 --> Router Class Initialized
INFO - 2024-10-29 10:41:23 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:23 --> Output Class Initialized
INFO - 2024-10-29 10:41:24 --> Input Class Initialized
INFO - 2024-10-29 10:41:24 --> Security Class Initialized
INFO - 2024-10-29 10:41:24 --> Language Class Initialized
DEBUG - 2024-10-29 10:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-29 10:41:24 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-29 10:41:24 --> Input Class Initialized
INFO - 2024-10-29 10:41:24 --> Config Class Initialized
INFO - 2024-10-29 10:41:24 --> Language Class Initialized
INFO - 2024-10-29 10:41:24 --> Hooks Class Initialized
ERROR - 2024-10-29 10:41:24 --> 404 Page Not Found: Website/wp-includes
DEBUG - 2024-10-29 10:41:24 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:24 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:24 --> URI Class Initialized
INFO - 2024-10-29 10:41:24 --> Router Class Initialized
INFO - 2024-10-29 10:41:24 --> Config Class Initialized
INFO - 2024-10-29 10:41:24 --> Output Class Initialized
INFO - 2024-10-29 10:41:24 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:24 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:24 --> UTF-8 Support Enabled
DEBUG - 2024-10-29 10:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:24 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:24 --> Input Class Initialized
INFO - 2024-10-29 10:41:24 --> URI Class Initialized
INFO - 2024-10-29 10:41:24 --> Language Class Initialized
INFO - 2024-10-29 10:41:24 --> Router Class Initialized
ERROR - 2024-10-29 10:41:24 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-29 10:41:24 --> Config Class Initialized
INFO - 2024-10-29 10:41:24 --> Output Class Initialized
INFO - 2024-10-29 10:41:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:25 --> Security Class Initialized
INFO - 2024-10-29 10:41:25 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:25 --> URI Class Initialized
DEBUG - 2024-10-29 10:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:25 --> Router Class Initialized
INFO - 2024-10-29 10:41:25 --> Input Class Initialized
INFO - 2024-10-29 10:41:25 --> Output Class Initialized
INFO - 2024-10-29 10:41:25 --> Language Class Initialized
INFO - 2024-10-29 10:41:25 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2024-10-29 10:41:25 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-29 10:41:25 --> Input Class Initialized
INFO - 2024-10-29 10:41:25 --> Language Class Initialized
ERROR - 2024-10-29 10:41:25 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-29 10:41:25 --> Config Class Initialized
INFO - 2024-10-29 10:41:25 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:25 --> Config Class Initialized
INFO - 2024-10-29 10:41:25 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2024-10-29 10:41:25 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:25 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:25 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:26 --> URI Class Initialized
INFO - 2024-10-29 10:41:26 --> URI Class Initialized
INFO - 2024-10-29 10:41:27 --> Router Class Initialized
INFO - 2024-10-29 10:41:27 --> Router Class Initialized
INFO - 2024-10-29 10:41:27 --> Output Class Initialized
INFO - 2024-10-29 10:41:27 --> Output Class Initialized
INFO - 2024-10-29 10:41:27 --> Security Class Initialized
INFO - 2024-10-29 10:41:27 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-29 10:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:27 --> Input Class Initialized
INFO - 2024-10-29 10:41:27 --> Input Class Initialized
INFO - 2024-10-29 10:41:27 --> Language Class Initialized
INFO - 2024-10-29 10:41:27 --> Language Class Initialized
ERROR - 2024-10-29 10:41:28 --> 404 Page Not Found: News/wp-includes
ERROR - 2024-10-29 10:41:28 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-29 10:41:31 --> Config Class Initialized
INFO - 2024-10-29 10:41:31 --> Config Class Initialized
INFO - 2024-10-29 10:41:31 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:31 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:31 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:31 --> Utf8 Class Initialized
DEBUG - 2024-10-29 10:41:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:32 --> URI Class Initialized
INFO - 2024-10-29 10:41:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:32 --> Router Class Initialized
INFO - 2024-10-29 10:41:32 --> URI Class Initialized
INFO - 2024-10-29 10:41:32 --> Output Class Initialized
INFO - 2024-10-29 10:41:33 --> Router Class Initialized
INFO - 2024-10-29 10:41:33 --> Config Class Initialized
INFO - 2024-10-29 10:41:33 --> Security Class Initialized
INFO - 2024-10-29 10:41:33 --> Output Class Initialized
INFO - 2024-10-29 10:41:33 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:34 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:34 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:34 --> Input Class Initialized
DEBUG - 2024-10-29 10:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:35 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:35 --> Language Class Initialized
INFO - 2024-10-29 10:41:36 --> Input Class Initialized
INFO - 2024-10-29 10:41:36 --> URI Class Initialized
ERROR - 2024-10-29 10:41:37 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-29 10:41:37 --> Language Class Initialized
INFO - 2024-10-29 10:41:37 --> Router Class Initialized
ERROR - 2024-10-29 10:41:37 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-29 10:41:37 --> Output Class Initialized
INFO - 2024-10-29 10:41:37 --> Config Class Initialized
INFO - 2024-10-29 10:41:37 --> Config Class Initialized
INFO - 2024-10-29 10:41:37 --> Security Class Initialized
INFO - 2024-10-29 10:41:38 --> Hooks Class Initialized
INFO - 2024-10-29 10:41:38 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-29 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2024-10-29 10:41:39 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:39 --> Input Class Initialized
INFO - 2024-10-29 10:41:40 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:40 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:40 --> Language Class Initialized
INFO - 2024-10-29 10:41:40 --> URI Class Initialized
INFO - 2024-10-29 10:41:40 --> URI Class Initialized
INFO - 2024-10-29 10:41:40 --> Loader Class Initialized
INFO - 2024-10-29 10:41:40 --> Router Class Initialized
INFO - 2024-10-29 10:41:40 --> Router Class Initialized
INFO - 2024-10-29 10:41:40 --> Helper loaded: url_helper
INFO - 2024-10-29 10:41:41 --> Output Class Initialized
INFO - 2024-10-29 10:41:41 --> Output Class Initialized
INFO - 2024-10-29 10:41:41 --> Helper loaded: html_helper
INFO - 2024-10-29 10:41:41 --> Security Class Initialized
INFO - 2024-10-29 10:41:41 --> Security Class Initialized
INFO - 2024-10-29 10:41:41 --> Helper loaded: file_helper
DEBUG - 2024-10-29 10:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-29 10:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:41 --> Helper loaded: string_helper
INFO - 2024-10-29 10:41:41 --> Input Class Initialized
INFO - 2024-10-29 10:41:41 --> Helper loaded: form_helper
INFO - 2024-10-29 10:41:41 --> Input Class Initialized
INFO - 2024-10-29 10:41:41 --> Language Class Initialized
INFO - 2024-10-29 10:41:42 --> Language Class Initialized
INFO - 2024-10-29 10:41:42 --> Helper loaded: my_helper
ERROR - 2024-10-29 10:41:42 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2024-10-29 10:41:42 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-29 10:41:43 --> Database Driver Class Initialized
INFO - 2024-10-29 10:41:43 --> Config Class Initialized
INFO - 2024-10-29 10:41:43 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:43 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:43 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:43 --> URI Class Initialized
INFO - 2024-10-29 10:41:43 --> Router Class Initialized
INFO - 2024-10-29 10:41:43 --> Output Class Initialized
INFO - 2024-10-29 10:41:43 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:43 --> Input Class Initialized
INFO - 2024-10-29 10:41:43 --> Language Class Initialized
ERROR - 2024-10-29 10:41:43 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-29 10:41:43 --> Config Class Initialized
INFO - 2024-10-29 10:41:43 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:43 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:44 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:44 --> URI Class Initialized
INFO - 2024-10-29 10:41:44 --> Router Class Initialized
INFO - 2024-10-29 10:41:44 --> Output Class Initialized
INFO - 2024-10-29 10:41:44 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:44 --> Input Class Initialized
INFO - 2024-10-29 10:41:44 --> Language Class Initialized
ERROR - 2024-10-29 10:41:44 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-29 10:41:44 --> Config Class Initialized
INFO - 2024-10-29 10:41:44 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:44 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:44 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:44 --> URI Class Initialized
INFO - 2024-10-29 10:41:44 --> Router Class Initialized
INFO - 2024-10-29 10:41:44 --> Output Class Initialized
INFO - 2024-10-29 10:41:44 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:44 --> Input Class Initialized
INFO - 2024-10-29 10:41:44 --> Language Class Initialized
ERROR - 2024-10-29 10:41:44 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-29 10:41:44 --> Config Class Initialized
INFO - 2024-10-29 10:41:44 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:44 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:45 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:45 --> URI Class Initialized
INFO - 2024-10-29 10:41:45 --> Router Class Initialized
INFO - 2024-10-29 10:41:45 --> Output Class Initialized
INFO - 2024-10-29 10:41:45 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:45 --> Upload Class Initialized
INFO - 2024-10-29 10:41:45 --> Input Class Initialized
INFO - 2024-10-29 10:41:45 --> Email Class Initialized
INFO - 2024-10-29 10:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:41:45 --> Form Validation Class Initialized
INFO - 2024-10-29 10:41:45 --> Language Class Initialized
INFO - 2024-10-29 10:41:45 --> Controller Class Initialized
ERROR - 2024-10-29 10:41:45 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-29 16:11:45 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:11:45 --> Model "MainModel" initialized
INFO - 2024-10-29 10:41:46 --> Config Class Initialized
INFO - 2024-10-29 16:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 10:41:46 --> Hooks Class Initialized
INFO - 2024-10-29 16:11:46 --> Pagination Class Initialized
DEBUG - 2024-10-29 10:41:46 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:46 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:46 --> URI Class Initialized
INFO - 2024-10-29 10:41:46 --> Router Class Initialized
INFO - 2024-10-29 10:41:46 --> Output Class Initialized
INFO - 2024-10-29 10:41:46 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:46 --> Input Class Initialized
INFO - 2024-10-29 10:41:46 --> Language Class Initialized
ERROR - 2024-10-29 10:41:46 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-29 10:41:47 --> Config Class Initialized
INFO - 2024-10-29 10:41:47 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:47 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:47 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:47 --> URI Class Initialized
INFO - 2024-10-29 10:41:47 --> Router Class Initialized
INFO - 2024-10-29 10:41:47 --> Output Class Initialized
INFO - 2024-10-29 10:41:47 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:47 --> Input Class Initialized
INFO - 2024-10-29 10:41:47 --> Language Class Initialized
ERROR - 2024-10-29 10:41:48 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-29 10:41:48 --> Config Class Initialized
INFO - 2024-10-29 10:41:48 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:48 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:48 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:48 --> URI Class Initialized
INFO - 2024-10-29 10:41:48 --> Router Class Initialized
INFO - 2024-10-29 10:41:48 --> Output Class Initialized
INFO - 2024-10-29 10:41:48 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:48 --> Input Class Initialized
INFO - 2024-10-29 10:41:48 --> Language Class Initialized
ERROR - 2024-10-29 10:41:48 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-29 10:41:48 --> Config Class Initialized
INFO - 2024-10-29 10:41:48 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:41:48 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:41:48 --> Utf8 Class Initialized
INFO - 2024-10-29 10:41:48 --> URI Class Initialized
INFO - 2024-10-29 10:41:48 --> Router Class Initialized
INFO - 2024-10-29 10:41:48 --> Output Class Initialized
INFO - 2024-10-29 10:41:48 --> Security Class Initialized
DEBUG - 2024-10-29 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:41:48 --> Input Class Initialized
INFO - 2024-10-29 10:41:48 --> Language Class Initialized
ERROR - 2024-10-29 10:41:48 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-29 10:42:32 --> Config Class Initialized
INFO - 2024-10-29 10:42:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:42:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:42:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:42:32 --> URI Class Initialized
INFO - 2024-10-29 10:42:32 --> Router Class Initialized
INFO - 2024-10-29 10:42:32 --> Output Class Initialized
INFO - 2024-10-29 10:42:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:42:32 --> Input Class Initialized
INFO - 2024-10-29 10:42:32 --> Language Class Initialized
INFO - 2024-10-29 10:42:32 --> Loader Class Initialized
INFO - 2024-10-29 10:42:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:42:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:42:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:42:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:42:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:42:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:42:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:42:34 --> Upload Class Initialized
INFO - 2024-10-29 10:42:34 --> Email Class Initialized
INFO - 2024-10-29 10:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:42:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:42:35 --> Controller Class Initialized
INFO - 2024-10-29 16:12:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:12:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:12:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:43:32 --> Config Class Initialized
INFO - 2024-10-29 10:43:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:43:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:43:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:43:32 --> URI Class Initialized
INFO - 2024-10-29 10:43:32 --> Router Class Initialized
INFO - 2024-10-29 10:43:32 --> Output Class Initialized
INFO - 2024-10-29 10:43:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:43:32 --> Input Class Initialized
INFO - 2024-10-29 10:43:32 --> Language Class Initialized
INFO - 2024-10-29 10:43:32 --> Loader Class Initialized
INFO - 2024-10-29 10:43:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:43:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:43:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:43:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:43:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:43:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:43:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:43:34 --> Upload Class Initialized
INFO - 2024-10-29 10:43:34 --> Email Class Initialized
INFO - 2024-10-29 10:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:43:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:43:34 --> Controller Class Initialized
INFO - 2024-10-29 16:13:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:13:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:13:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:44:32 --> Config Class Initialized
INFO - 2024-10-29 10:44:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:44:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:44:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:44:32 --> URI Class Initialized
INFO - 2024-10-29 10:44:32 --> Router Class Initialized
INFO - 2024-10-29 10:44:32 --> Output Class Initialized
INFO - 2024-10-29 10:44:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:44:32 --> Input Class Initialized
INFO - 2024-10-29 10:44:32 --> Language Class Initialized
INFO - 2024-10-29 10:44:32 --> Loader Class Initialized
INFO - 2024-10-29 10:44:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:44:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:44:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:44:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:44:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:44:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:44:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:44:34 --> Upload Class Initialized
INFO - 2024-10-29 10:44:34 --> Email Class Initialized
INFO - 2024-10-29 10:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:44:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:44:34 --> Controller Class Initialized
INFO - 2024-10-29 16:14:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:14:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:14:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:45:32 --> Config Class Initialized
INFO - 2024-10-29 10:45:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:45:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:45:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:45:32 --> URI Class Initialized
INFO - 2024-10-29 10:45:32 --> Router Class Initialized
INFO - 2024-10-29 10:45:32 --> Output Class Initialized
INFO - 2024-10-29 10:45:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:45:32 --> Input Class Initialized
INFO - 2024-10-29 10:45:32 --> Language Class Initialized
INFO - 2024-10-29 10:45:32 --> Loader Class Initialized
INFO - 2024-10-29 10:45:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:45:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:45:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:45:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:45:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:45:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:45:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:45:34 --> Upload Class Initialized
INFO - 2024-10-29 10:45:34 --> Email Class Initialized
INFO - 2024-10-29 10:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:45:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:45:34 --> Controller Class Initialized
INFO - 2024-10-29 16:15:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:15:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:15:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:46:32 --> Config Class Initialized
INFO - 2024-10-29 10:46:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:46:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:46:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:46:32 --> URI Class Initialized
INFO - 2024-10-29 10:46:32 --> Router Class Initialized
INFO - 2024-10-29 10:46:32 --> Output Class Initialized
INFO - 2024-10-29 10:46:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:46:33 --> Input Class Initialized
INFO - 2024-10-29 10:46:33 --> Language Class Initialized
INFO - 2024-10-29 10:46:33 --> Loader Class Initialized
INFO - 2024-10-29 10:46:33 --> Helper loaded: url_helper
INFO - 2024-10-29 10:46:33 --> Helper loaded: html_helper
INFO - 2024-10-29 10:46:33 --> Helper loaded: file_helper
INFO - 2024-10-29 10:46:33 --> Helper loaded: string_helper
INFO - 2024-10-29 10:46:33 --> Helper loaded: form_helper
INFO - 2024-10-29 10:46:33 --> Helper loaded: my_helper
INFO - 2024-10-29 10:46:33 --> Database Driver Class Initialized
INFO - 2024-10-29 10:46:35 --> Upload Class Initialized
INFO - 2024-10-29 10:46:35 --> Email Class Initialized
INFO - 2024-10-29 10:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:46:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:46:35 --> Controller Class Initialized
INFO - 2024-10-29 16:16:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:16:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:16:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:47:32 --> Config Class Initialized
INFO - 2024-10-29 10:47:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:47:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:47:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:47:32 --> URI Class Initialized
INFO - 2024-10-29 10:47:32 --> Router Class Initialized
INFO - 2024-10-29 10:47:32 --> Output Class Initialized
INFO - 2024-10-29 10:47:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:47:32 --> Input Class Initialized
INFO - 2024-10-29 10:47:32 --> Language Class Initialized
INFO - 2024-10-29 10:47:32 --> Loader Class Initialized
INFO - 2024-10-29 10:47:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:47:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:47:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:47:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:47:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:47:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:47:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:47:34 --> Upload Class Initialized
INFO - 2024-10-29 10:47:34 --> Email Class Initialized
INFO - 2024-10-29 10:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:47:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:47:34 --> Controller Class Initialized
INFO - 2024-10-29 16:17:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:17:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:17:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:17:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:48:32 --> Config Class Initialized
INFO - 2024-10-29 10:48:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:48:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:48:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:48:32 --> URI Class Initialized
INFO - 2024-10-29 10:48:32 --> Router Class Initialized
INFO - 2024-10-29 10:48:32 --> Output Class Initialized
INFO - 2024-10-29 10:48:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:48:32 --> Input Class Initialized
INFO - 2024-10-29 10:48:32 --> Language Class Initialized
INFO - 2024-10-29 10:48:32 --> Loader Class Initialized
INFO - 2024-10-29 10:48:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:48:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:48:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:48:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:48:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:48:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:48:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:48:34 --> Upload Class Initialized
INFO - 2024-10-29 10:48:34 --> Email Class Initialized
INFO - 2024-10-29 10:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:48:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:48:34 --> Controller Class Initialized
INFO - 2024-10-29 16:18:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:18:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:18:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:49:32 --> Config Class Initialized
INFO - 2024-10-29 10:49:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:49:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:49:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:49:32 --> URI Class Initialized
INFO - 2024-10-29 10:49:32 --> Router Class Initialized
INFO - 2024-10-29 10:49:32 --> Output Class Initialized
INFO - 2024-10-29 10:49:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:49:32 --> Input Class Initialized
INFO - 2024-10-29 10:49:32 --> Language Class Initialized
INFO - 2024-10-29 10:49:32 --> Loader Class Initialized
INFO - 2024-10-29 10:49:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:49:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:49:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:49:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:49:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:49:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:49:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:49:34 --> Upload Class Initialized
INFO - 2024-10-29 10:49:34 --> Email Class Initialized
INFO - 2024-10-29 10:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:49:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:49:34 --> Controller Class Initialized
INFO - 2024-10-29 16:19:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:19:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:19:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:50:32 --> Config Class Initialized
INFO - 2024-10-29 10:50:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:50:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:50:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:50:32 --> URI Class Initialized
INFO - 2024-10-29 10:50:32 --> Router Class Initialized
INFO - 2024-10-29 10:50:32 --> Output Class Initialized
INFO - 2024-10-29 10:50:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:50:32 --> Input Class Initialized
INFO - 2024-10-29 10:50:32 --> Language Class Initialized
INFO - 2024-10-29 10:50:32 --> Loader Class Initialized
INFO - 2024-10-29 10:50:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:50:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:50:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:50:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:50:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:50:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:50:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:50:34 --> Upload Class Initialized
INFO - 2024-10-29 10:50:34 --> Email Class Initialized
INFO - 2024-10-29 10:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:50:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:50:34 --> Controller Class Initialized
INFO - 2024-10-29 16:20:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:20:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:20:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:51:32 --> Config Class Initialized
INFO - 2024-10-29 10:51:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:51:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:51:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:51:32 --> URI Class Initialized
INFO - 2024-10-29 10:51:32 --> Router Class Initialized
INFO - 2024-10-29 10:51:32 --> Output Class Initialized
INFO - 2024-10-29 10:51:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:51:32 --> Input Class Initialized
INFO - 2024-10-29 10:51:32 --> Language Class Initialized
INFO - 2024-10-29 10:51:32 --> Loader Class Initialized
INFO - 2024-10-29 10:51:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:51:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:51:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:51:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:51:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:51:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:51:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:51:34 --> Upload Class Initialized
INFO - 2024-10-29 10:51:34 --> Email Class Initialized
INFO - 2024-10-29 10:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:51:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:51:34 --> Controller Class Initialized
INFO - 2024-10-29 16:21:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:21:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:21:34 --> Pagination Class Initialized
INFO - 2024-10-29 10:52:32 --> Config Class Initialized
INFO - 2024-10-29 10:52:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:52:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:52:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:52:32 --> URI Class Initialized
INFO - 2024-10-29 10:52:32 --> Router Class Initialized
INFO - 2024-10-29 10:52:32 --> Output Class Initialized
INFO - 2024-10-29 10:52:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:52:32 --> Input Class Initialized
INFO - 2024-10-29 10:52:32 --> Language Class Initialized
INFO - 2024-10-29 10:52:32 --> Loader Class Initialized
INFO - 2024-10-29 10:52:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:52:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:52:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:52:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:52:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:52:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:52:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:52:34 --> Upload Class Initialized
INFO - 2024-10-29 10:52:34 --> Email Class Initialized
INFO - 2024-10-29 10:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:52:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:52:34 --> Controller Class Initialized
INFO - 2024-10-29 16:22:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:22:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:22:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:22:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:53:32 --> Config Class Initialized
INFO - 2024-10-29 10:53:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:53:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:53:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:53:32 --> URI Class Initialized
INFO - 2024-10-29 10:53:32 --> Router Class Initialized
INFO - 2024-10-29 10:53:32 --> Output Class Initialized
INFO - 2024-10-29 10:53:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:53:32 --> Input Class Initialized
INFO - 2024-10-29 10:53:32 --> Language Class Initialized
INFO - 2024-10-29 10:53:32 --> Loader Class Initialized
INFO - 2024-10-29 10:53:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:53:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:53:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:53:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:53:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:53:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:53:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:53:34 --> Upload Class Initialized
INFO - 2024-10-29 10:53:34 --> Email Class Initialized
INFO - 2024-10-29 10:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:53:35 --> Form Validation Class Initialized
INFO - 2024-10-29 10:53:35 --> Controller Class Initialized
INFO - 2024-10-29 16:23:35 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:23:35 --> Model "MainModel" initialized
INFO - 2024-10-29 16:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:23:35 --> Pagination Class Initialized
INFO - 2024-10-29 10:54:32 --> Config Class Initialized
INFO - 2024-10-29 10:54:32 --> Hooks Class Initialized
DEBUG - 2024-10-29 10:54:32 --> UTF-8 Support Enabled
INFO - 2024-10-29 10:54:32 --> Utf8 Class Initialized
INFO - 2024-10-29 10:54:32 --> URI Class Initialized
INFO - 2024-10-29 10:54:32 --> Router Class Initialized
INFO - 2024-10-29 10:54:32 --> Output Class Initialized
INFO - 2024-10-29 10:54:32 --> Security Class Initialized
DEBUG - 2024-10-29 10:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 10:54:32 --> Input Class Initialized
INFO - 2024-10-29 10:54:32 --> Language Class Initialized
INFO - 2024-10-29 10:54:32 --> Loader Class Initialized
INFO - 2024-10-29 10:54:32 --> Helper loaded: url_helper
INFO - 2024-10-29 10:54:32 --> Helper loaded: html_helper
INFO - 2024-10-29 10:54:32 --> Helper loaded: file_helper
INFO - 2024-10-29 10:54:32 --> Helper loaded: string_helper
INFO - 2024-10-29 10:54:32 --> Helper loaded: form_helper
INFO - 2024-10-29 10:54:32 --> Helper loaded: my_helper
INFO - 2024-10-29 10:54:32 --> Database Driver Class Initialized
INFO - 2024-10-29 10:54:34 --> Upload Class Initialized
INFO - 2024-10-29 10:54:34 --> Email Class Initialized
INFO - 2024-10-29 10:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 10:54:34 --> Form Validation Class Initialized
INFO - 2024-10-29 10:54:34 --> Controller Class Initialized
INFO - 2024-10-29 16:24:34 --> Model "RoomserviceModel" initialized
INFO - 2024-10-29 16:24:34 --> Model "MainModel" initialized
INFO - 2024-10-29 16:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-29 16:24:35 --> Pagination Class Initialized
INFO - 2024-10-29 16:57:51 --> Config Class Initialized
INFO - 2024-10-29 16:57:51 --> Hooks Class Initialized
DEBUG - 2024-10-29 16:57:51 --> UTF-8 Support Enabled
INFO - 2024-10-29 16:57:51 --> Utf8 Class Initialized
INFO - 2024-10-29 16:57:51 --> URI Class Initialized
DEBUG - 2024-10-29 16:57:52 --> No URI present. Default controller set.
INFO - 2024-10-29 16:57:52 --> Router Class Initialized
INFO - 2024-10-29 16:57:52 --> Output Class Initialized
INFO - 2024-10-29 16:57:52 --> Security Class Initialized
DEBUG - 2024-10-29 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-29 16:57:52 --> Input Class Initialized
INFO - 2024-10-29 16:57:52 --> Language Class Initialized
INFO - 2024-10-29 16:57:52 --> Loader Class Initialized
INFO - 2024-10-29 16:57:52 --> Helper loaded: url_helper
INFO - 2024-10-29 16:57:52 --> Helper loaded: html_helper
INFO - 2024-10-29 16:57:52 --> Helper loaded: file_helper
INFO - 2024-10-29 16:57:52 --> Helper loaded: string_helper
INFO - 2024-10-29 16:57:52 --> Helper loaded: form_helper
INFO - 2024-10-29 16:57:52 --> Helper loaded: my_helper
INFO - 2024-10-29 16:57:52 --> Database Driver Class Initialized
INFO - 2024-10-29 16:57:54 --> Upload Class Initialized
INFO - 2024-10-29 16:57:54 --> Email Class Initialized
INFO - 2024-10-29 16:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-29 16:57:54 --> Form Validation Class Initialized
INFO - 2024-10-29 16:57:54 --> Controller Class Initialized
INFO - 2024-10-29 22:27:54 --> Model "MainModel" initialized
INFO - 2024-10-29 22:27:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-29 22:27:54 --> Final output sent to browser
DEBUG - 2024-10-29 22:27:54 --> Total execution time: 2.4812
