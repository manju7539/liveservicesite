<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-06 06:19:01 --> Config Class Initialized
INFO - 2024-12-06 06:19:01 --> Hooks Class Initialized
DEBUG - 2024-12-06 06:19:01 --> UTF-8 Support Enabled
INFO - 2024-12-06 06:19:01 --> Utf8 Class Initialized
INFO - 2024-12-06 06:19:01 --> URI Class Initialized
DEBUG - 2024-12-06 06:19:01 --> No URI present. Default controller set.
INFO - 2024-12-06 06:19:01 --> Router Class Initialized
INFO - 2024-12-06 06:19:01 --> Output Class Initialized
INFO - 2024-12-06 06:19:01 --> Security Class Initialized
DEBUG - 2024-12-06 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 06:19:02 --> Input Class Initialized
INFO - 2024-12-06 06:19:02 --> Language Class Initialized
INFO - 2024-12-06 06:19:02 --> Loader Class Initialized
INFO - 2024-12-06 06:19:02 --> Helper loaded: url_helper
INFO - 2024-12-06 06:19:02 --> Helper loaded: html_helper
INFO - 2024-12-06 06:19:02 --> Helper loaded: file_helper
INFO - 2024-12-06 06:19:02 --> Helper loaded: string_helper
INFO - 2024-12-06 06:19:02 --> Helper loaded: form_helper
INFO - 2024-12-06 06:19:02 --> Helper loaded: my_helper
INFO - 2024-12-06 06:19:02 --> Database Driver Class Initialized
INFO - 2024-12-06 06:19:05 --> Upload Class Initialized
INFO - 2024-12-06 06:19:05 --> Email Class Initialized
INFO - 2024-12-06 06:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 06:19:05 --> Form Validation Class Initialized
INFO - 2024-12-06 06:19:05 --> Controller Class Initialized
INFO - 2024-12-06 11:49:05 --> Model "MainModel" initialized
INFO - 2024-12-06 11:49:05 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-06 11:49:05 --> Final output sent to browser
DEBUG - 2024-12-06 11:49:05 --> Total execution time: 4.1849
INFO - 2024-12-06 06:19:09 --> Config Class Initialized
INFO - 2024-12-06 06:19:09 --> Hooks Class Initialized
DEBUG - 2024-12-06 06:19:09 --> UTF-8 Support Enabled
INFO - 2024-12-06 06:19:09 --> Utf8 Class Initialized
INFO - 2024-12-06 06:19:09 --> URI Class Initialized
INFO - 2024-12-06 06:19:09 --> Router Class Initialized
INFO - 2024-12-06 06:19:09 --> Output Class Initialized
INFO - 2024-12-06 06:19:09 --> Security Class Initialized
DEBUG - 2024-12-06 06:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 06:19:09 --> Input Class Initialized
INFO - 2024-12-06 06:19:09 --> Language Class Initialized
ERROR - 2024-12-06 06:19:09 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-06 06:25:00 --> Config Class Initialized
INFO - 2024-12-06 06:25:00 --> Hooks Class Initialized
DEBUG - 2024-12-06 06:25:00 --> UTF-8 Support Enabled
INFO - 2024-12-06 06:25:00 --> Utf8 Class Initialized
INFO - 2024-12-06 06:25:00 --> URI Class Initialized
DEBUG - 2024-12-06 06:25:00 --> No URI present. Default controller set.
INFO - 2024-12-06 06:25:00 --> Router Class Initialized
INFO - 2024-12-06 06:25:00 --> Output Class Initialized
INFO - 2024-12-06 06:25:00 --> Security Class Initialized
DEBUG - 2024-12-06 06:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 06:25:00 --> Input Class Initialized
INFO - 2024-12-06 06:25:00 --> Language Class Initialized
INFO - 2024-12-06 06:25:00 --> Loader Class Initialized
INFO - 2024-12-06 06:25:00 --> Helper loaded: url_helper
INFO - 2024-12-06 06:25:00 --> Helper loaded: html_helper
INFO - 2024-12-06 06:25:00 --> Helper loaded: file_helper
INFO - 2024-12-06 06:25:00 --> Helper loaded: string_helper
INFO - 2024-12-06 06:25:00 --> Helper loaded: form_helper
INFO - 2024-12-06 06:25:00 --> Helper loaded: my_helper
INFO - 2024-12-06 06:25:00 --> Database Driver Class Initialized
INFO - 2024-12-06 06:25:02 --> Upload Class Initialized
INFO - 2024-12-06 06:25:02 --> Email Class Initialized
INFO - 2024-12-06 06:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 06:25:02 --> Form Validation Class Initialized
INFO - 2024-12-06 06:25:02 --> Controller Class Initialized
INFO - 2024-12-06 11:55:02 --> Model "MainModel" initialized
INFO - 2024-12-06 11:55:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-06 11:55:02 --> Final output sent to browser
DEBUG - 2024-12-06 11:55:02 --> Total execution time: 2.5279
INFO - 2024-12-06 06:25:07 --> Config Class Initialized
INFO - 2024-12-06 06:25:07 --> Hooks Class Initialized
DEBUG - 2024-12-06 06:25:07 --> UTF-8 Support Enabled
INFO - 2024-12-06 06:25:07 --> Utf8 Class Initialized
INFO - 2024-12-06 06:25:07 --> URI Class Initialized
INFO - 2024-12-06 06:25:07 --> Router Class Initialized
INFO - 2024-12-06 06:25:07 --> Output Class Initialized
INFO - 2024-12-06 06:25:07 --> Security Class Initialized
DEBUG - 2024-12-06 06:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 06:25:07 --> Input Class Initialized
INFO - 2024-12-06 06:25:07 --> Language Class Initialized
ERROR - 2024-12-06 06:25:07 --> 404 Page Not Found: Faviconico/index
INFO - 2024-12-06 08:56:57 --> Config Class Initialized
INFO - 2024-12-06 08:56:57 --> Hooks Class Initialized
DEBUG - 2024-12-06 08:56:57 --> UTF-8 Support Enabled
INFO - 2024-12-06 08:56:57 --> Utf8 Class Initialized
INFO - 2024-12-06 08:56:57 --> URI Class Initialized
DEBUG - 2024-12-06 08:56:58 --> No URI present. Default controller set.
INFO - 2024-12-06 08:56:58 --> Router Class Initialized
INFO - 2024-12-06 08:56:58 --> Output Class Initialized
INFO - 2024-12-06 08:56:58 --> Security Class Initialized
DEBUG - 2024-12-06 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 08:56:58 --> Input Class Initialized
INFO - 2024-12-06 08:56:58 --> Language Class Initialized
INFO - 2024-12-06 08:56:58 --> Loader Class Initialized
INFO - 2024-12-06 08:56:58 --> Helper loaded: url_helper
INFO - 2024-12-06 08:56:58 --> Helper loaded: html_helper
INFO - 2024-12-06 08:56:58 --> Helper loaded: file_helper
INFO - 2024-12-06 08:56:58 --> Helper loaded: string_helper
INFO - 2024-12-06 08:56:58 --> Helper loaded: form_helper
INFO - 2024-12-06 08:56:58 --> Helper loaded: my_helper
INFO - 2024-12-06 08:56:58 --> Database Driver Class Initialized
INFO - 2024-12-06 08:57:00 --> Upload Class Initialized
INFO - 2024-12-06 08:57:00 --> Email Class Initialized
INFO - 2024-12-06 08:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 08:57:00 --> Form Validation Class Initialized
INFO - 2024-12-06 08:57:00 --> Controller Class Initialized
INFO - 2024-12-06 14:27:00 --> Model "MainModel" initialized
INFO - 2024-12-06 14:27:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-06 14:27:00 --> Final output sent to browser
DEBUG - 2024-12-06 14:27:00 --> Total execution time: 2.2673
INFO - 2024-12-06 11:05:02 --> Config Class Initialized
INFO - 2024-12-06 11:05:02 --> Hooks Class Initialized
DEBUG - 2024-12-06 11:05:02 --> UTF-8 Support Enabled
INFO - 2024-12-06 11:05:02 --> Utf8 Class Initialized
INFO - 2024-12-06 11:05:02 --> URI Class Initialized
DEBUG - 2024-12-06 11:05:02 --> No URI present. Default controller set.
INFO - 2024-12-06 11:05:02 --> Router Class Initialized
INFO - 2024-12-06 11:05:02 --> Output Class Initialized
INFO - 2024-12-06 11:05:02 --> Security Class Initialized
DEBUG - 2024-12-06 11:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-06 11:05:02 --> Input Class Initialized
INFO - 2024-12-06 11:05:02 --> Language Class Initialized
INFO - 2024-12-06 11:05:02 --> Loader Class Initialized
INFO - 2024-12-06 11:05:02 --> Helper loaded: url_helper
INFO - 2024-12-06 11:05:02 --> Helper loaded: html_helper
INFO - 2024-12-06 11:05:02 --> Helper loaded: file_helper
INFO - 2024-12-06 11:05:02 --> Helper loaded: string_helper
INFO - 2024-12-06 11:05:02 --> Helper loaded: form_helper
INFO - 2024-12-06 11:05:02 --> Helper loaded: my_helper
INFO - 2024-12-06 11:05:02 --> Database Driver Class Initialized
INFO - 2024-12-06 11:05:04 --> Upload Class Initialized
INFO - 2024-12-06 11:05:04 --> Email Class Initialized
INFO - 2024-12-06 11:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-06 11:05:04 --> Form Validation Class Initialized
INFO - 2024-12-06 11:05:04 --> Controller Class Initialized
INFO - 2024-12-06 16:35:04 --> Model "MainModel" initialized
INFO - 2024-12-06 16:35:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-06 16:35:04 --> Final output sent to browser
DEBUG - 2024-12-06 16:35:04 --> Total execution time: 2.3576
