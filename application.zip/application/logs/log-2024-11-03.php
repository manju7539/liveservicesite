<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-03 07:52:39 --> Config Class Initialized
INFO - 2024-11-03 07:52:39 --> Hooks Class Initialized
DEBUG - 2024-11-03 07:52:39 --> UTF-8 Support Enabled
INFO - 2024-11-03 07:52:39 --> Utf8 Class Initialized
INFO - 2024-11-03 07:52:39 --> URI Class Initialized
DEBUG - 2024-11-03 07:52:39 --> No URI present. Default controller set.
INFO - 2024-11-03 07:52:39 --> Router Class Initialized
INFO - 2024-11-03 07:52:39 --> Output Class Initialized
INFO - 2024-11-03 07:52:39 --> Security Class Initialized
DEBUG - 2024-11-03 07:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 07:52:39 --> Input Class Initialized
INFO - 2024-11-03 07:52:39 --> Language Class Initialized
INFO - 2024-11-03 07:52:39 --> Loader Class Initialized
INFO - 2024-11-03 07:52:39 --> Helper loaded: url_helper
INFO - 2024-11-03 07:52:39 --> Helper loaded: html_helper
INFO - 2024-11-03 07:52:39 --> Helper loaded: file_helper
INFO - 2024-11-03 07:52:39 --> Helper loaded: string_helper
INFO - 2024-11-03 07:52:39 --> Helper loaded: form_helper
INFO - 2024-11-03 07:52:39 --> Helper loaded: my_helper
INFO - 2024-11-03 07:52:39 --> Database Driver Class Initialized
INFO - 2024-11-03 07:52:42 --> Upload Class Initialized
INFO - 2024-11-03 07:52:42 --> Email Class Initialized
INFO - 2024-11-03 07:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 07:52:42 --> Form Validation Class Initialized
INFO - 2024-11-03 07:52:42 --> Controller Class Initialized
INFO - 2024-11-03 13:22:42 --> Model "MainModel" initialized
INFO - 2024-11-03 13:22:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-03 13:22:42 --> Final output sent to browser
DEBUG - 2024-11-03 13:22:42 --> Total execution time: 3.0812
INFO - 2024-11-03 07:52:45 --> Config Class Initialized
INFO - 2024-11-03 07:52:45 --> Hooks Class Initialized
DEBUG - 2024-11-03 07:52:45 --> UTF-8 Support Enabled
INFO - 2024-11-03 07:52:45 --> Utf8 Class Initialized
INFO - 2024-11-03 07:52:45 --> URI Class Initialized
DEBUG - 2024-11-03 07:52:45 --> No URI present. Default controller set.
INFO - 2024-11-03 07:52:45 --> Router Class Initialized
INFO - 2024-11-03 07:52:45 --> Output Class Initialized
INFO - 2024-11-03 07:52:45 --> Security Class Initialized
DEBUG - 2024-11-03 07:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-03 07:52:45 --> Input Class Initialized
INFO - 2024-11-03 07:52:45 --> Language Class Initialized
INFO - 2024-11-03 07:52:45 --> Loader Class Initialized
INFO - 2024-11-03 07:52:45 --> Helper loaded: url_helper
INFO - 2024-11-03 07:52:45 --> Helper loaded: html_helper
INFO - 2024-11-03 07:52:45 --> Helper loaded: file_helper
INFO - 2024-11-03 07:52:45 --> Helper loaded: string_helper
INFO - 2024-11-03 07:52:45 --> Helper loaded: form_helper
INFO - 2024-11-03 07:52:45 --> Helper loaded: my_helper
INFO - 2024-11-03 07:52:45 --> Database Driver Class Initialized
INFO - 2024-11-03 07:52:47 --> Upload Class Initialized
INFO - 2024-11-03 07:52:47 --> Email Class Initialized
INFO - 2024-11-03 07:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-03 07:52:47 --> Form Validation Class Initialized
INFO - 2024-11-03 07:52:47 --> Controller Class Initialized
INFO - 2024-11-03 13:22:47 --> Model "MainModel" initialized
INFO - 2024-11-03 13:22:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-03 13:22:47 --> Final output sent to browser
DEBUG - 2024-11-03 13:22:47 --> Total execution time: 2.1311
