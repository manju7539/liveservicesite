<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-18 00:38:56 --> Config Class Initialized
INFO - 2024-12-18 00:38:56 --> Hooks Class Initialized
DEBUG - 2024-12-18 00:38:56 --> UTF-8 Support Enabled
INFO - 2024-12-18 00:38:56 --> Utf8 Class Initialized
INFO - 2024-12-18 00:38:56 --> URI Class Initialized
DEBUG - 2024-12-18 00:38:57 --> No URI present. Default controller set.
INFO - 2024-12-18 00:38:57 --> Router Class Initialized
INFO - 2024-12-18 00:38:57 --> Output Class Initialized
INFO - 2024-12-18 00:38:57 --> Security Class Initialized
DEBUG - 2024-12-18 00:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 00:38:57 --> Input Class Initialized
INFO - 2024-12-18 00:38:57 --> Language Class Initialized
INFO - 2024-12-18 00:38:57 --> Loader Class Initialized
INFO - 2024-12-18 00:38:57 --> Helper loaded: url_helper
INFO - 2024-12-18 00:38:57 --> Helper loaded: html_helper
INFO - 2024-12-18 00:38:57 --> Helper loaded: file_helper
INFO - 2024-12-18 00:38:57 --> Helper loaded: string_helper
INFO - 2024-12-18 00:38:57 --> Helper loaded: form_helper
INFO - 2024-12-18 00:38:57 --> Helper loaded: my_helper
INFO - 2024-12-18 00:38:57 --> Database Driver Class Initialized
INFO - 2024-12-18 00:38:58 --> Config Class Initialized
INFO - 2024-12-18 00:38:58 --> Hooks Class Initialized
DEBUG - 2024-12-18 00:38:58 --> UTF-8 Support Enabled
INFO - 2024-12-18 00:38:58 --> Utf8 Class Initialized
INFO - 2024-12-18 00:38:58 --> URI Class Initialized
DEBUG - 2024-12-18 00:38:58 --> No URI present. Default controller set.
INFO - 2024-12-18 00:38:58 --> Router Class Initialized
INFO - 2024-12-18 00:38:58 --> Output Class Initialized
INFO - 2024-12-18 00:38:58 --> Security Class Initialized
DEBUG - 2024-12-18 00:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 00:38:58 --> Input Class Initialized
INFO - 2024-12-18 00:38:58 --> Language Class Initialized
INFO - 2024-12-18 00:38:58 --> Loader Class Initialized
INFO - 2024-12-18 00:38:58 --> Helper loaded: url_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: html_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: file_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: string_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: form_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: my_helper
INFO - 2024-12-18 00:38:58 --> Database Driver Class Initialized
INFO - 2024-12-18 00:38:58 --> Config Class Initialized
INFO - 2024-12-18 00:38:58 --> Hooks Class Initialized
DEBUG - 2024-12-18 00:38:58 --> UTF-8 Support Enabled
INFO - 2024-12-18 00:38:58 --> Utf8 Class Initialized
INFO - 2024-12-18 00:38:58 --> URI Class Initialized
DEBUG - 2024-12-18 00:38:58 --> No URI present. Default controller set.
INFO - 2024-12-18 00:38:58 --> Router Class Initialized
INFO - 2024-12-18 00:38:58 --> Output Class Initialized
INFO - 2024-12-18 00:38:58 --> Security Class Initialized
DEBUG - 2024-12-18 00:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 00:38:58 --> Input Class Initialized
INFO - 2024-12-18 00:38:58 --> Language Class Initialized
INFO - 2024-12-18 00:38:58 --> Loader Class Initialized
INFO - 2024-12-18 00:38:58 --> Helper loaded: url_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: html_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: file_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: string_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: form_helper
INFO - 2024-12-18 00:38:58 --> Helper loaded: my_helper
INFO - 2024-12-18 00:38:58 --> Database Driver Class Initialized
INFO - 2024-12-18 00:38:58 --> Config Class Initialized
INFO - 2024-12-18 00:38:58 --> Hooks Class Initialized
DEBUG - 2024-12-18 00:38:58 --> UTF-8 Support Enabled
INFO - 2024-12-18 00:38:59 --> Utf8 Class Initialized
INFO - 2024-12-18 00:38:59 --> URI Class Initialized
DEBUG - 2024-12-18 00:38:59 --> No URI present. Default controller set.
INFO - 2024-12-18 00:38:59 --> Router Class Initialized
INFO - 2024-12-18 00:38:59 --> Output Class Initialized
INFO - 2024-12-18 00:38:59 --> Security Class Initialized
DEBUG - 2024-12-18 00:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 00:38:59 --> Input Class Initialized
INFO - 2024-12-18 00:38:59 --> Language Class Initialized
INFO - 2024-12-18 00:38:59 --> Loader Class Initialized
INFO - 2024-12-18 00:38:59 --> Helper loaded: url_helper
INFO - 2024-12-18 00:38:59 --> Helper loaded: html_helper
INFO - 2024-12-18 00:38:59 --> Helper loaded: file_helper
INFO - 2024-12-18 00:38:59 --> Helper loaded: string_helper
INFO - 2024-12-18 00:38:59 --> Helper loaded: form_helper
INFO - 2024-12-18 00:38:59 --> Helper loaded: my_helper
INFO - 2024-12-18 00:38:59 --> Database Driver Class Initialized
INFO - 2024-12-18 00:38:59 --> Upload Class Initialized
INFO - 2024-12-18 00:38:59 --> Email Class Initialized
INFO - 2024-12-18 00:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 00:38:59 --> Form Validation Class Initialized
INFO - 2024-12-18 00:38:59 --> Controller Class Initialized
INFO - 2024-12-18 06:08:59 --> Model "MainModel" initialized
INFO - 2024-12-18 06:08:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 06:08:59 --> Final output sent to browser
DEBUG - 2024-12-18 06:08:59 --> Total execution time: 2.7178
INFO - 2024-12-18 00:39:00 --> Upload Class Initialized
INFO - 2024-12-18 00:39:00 --> Email Class Initialized
INFO - 2024-12-18 00:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 00:39:00 --> Form Validation Class Initialized
INFO - 2024-12-18 00:39:00 --> Controller Class Initialized
INFO - 2024-12-18 06:09:00 --> Model "MainModel" initialized
INFO - 2024-12-18 06:09:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 06:09:00 --> Final output sent to browser
DEBUG - 2024-12-18 06:09:00 --> Total execution time: 2.1360
INFO - 2024-12-18 00:39:00 --> Config Class Initialized
INFO - 2024-12-18 00:39:00 --> Hooks Class Initialized
DEBUG - 2024-12-18 00:39:00 --> UTF-8 Support Enabled
INFO - 2024-12-18 00:39:00 --> Utf8 Class Initialized
INFO - 2024-12-18 00:39:00 --> URI Class Initialized
DEBUG - 2024-12-18 00:39:00 --> No URI present. Default controller set.
INFO - 2024-12-18 00:39:00 --> Router Class Initialized
INFO - 2024-12-18 00:39:00 --> Output Class Initialized
INFO - 2024-12-18 00:39:00 --> Security Class Initialized
DEBUG - 2024-12-18 00:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 00:39:00 --> Input Class Initialized
INFO - 2024-12-18 00:39:00 --> Language Class Initialized
INFO - 2024-12-18 00:39:00 --> Loader Class Initialized
INFO - 2024-12-18 00:39:00 --> Helper loaded: url_helper
INFO - 2024-12-18 00:39:00 --> Helper loaded: html_helper
INFO - 2024-12-18 00:39:00 --> Helper loaded: file_helper
INFO - 2024-12-18 00:39:00 --> Helper loaded: string_helper
INFO - 2024-12-18 00:39:00 --> Helper loaded: form_helper
INFO - 2024-12-18 00:39:00 --> Helper loaded: my_helper
INFO - 2024-12-18 00:39:00 --> Database Driver Class Initialized
INFO - 2024-12-18 00:39:00 --> Upload Class Initialized
INFO - 2024-12-18 00:39:00 --> Email Class Initialized
INFO - 2024-12-18 00:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 00:39:00 --> Form Validation Class Initialized
INFO - 2024-12-18 00:39:00 --> Controller Class Initialized
INFO - 2024-12-18 06:09:00 --> Model "MainModel" initialized
INFO - 2024-12-18 06:09:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 06:09:00 --> Final output sent to browser
DEBUG - 2024-12-18 06:09:00 --> Total execution time: 2.1503
INFO - 2024-12-18 00:39:01 --> Upload Class Initialized
INFO - 2024-12-18 00:39:01 --> Email Class Initialized
INFO - 2024-12-18 00:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 00:39:01 --> Form Validation Class Initialized
INFO - 2024-12-18 00:39:01 --> Controller Class Initialized
INFO - 2024-12-18 06:09:01 --> Model "MainModel" initialized
INFO - 2024-12-18 06:09:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 06:09:01 --> Final output sent to browser
DEBUG - 2024-12-18 06:09:01 --> Total execution time: 2.1211
INFO - 2024-12-18 00:39:02 --> Upload Class Initialized
INFO - 2024-12-18 00:39:02 --> Email Class Initialized
INFO - 2024-12-18 00:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 00:39:02 --> Form Validation Class Initialized
INFO - 2024-12-18 00:39:02 --> Controller Class Initialized
INFO - 2024-12-18 06:09:02 --> Model "MainModel" initialized
INFO - 2024-12-18 06:09:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 06:09:02 --> Final output sent to browser
DEBUG - 2024-12-18 06:09:02 --> Total execution time: 2.1280
INFO - 2024-12-18 01:01:02 --> Config Class Initialized
INFO - 2024-12-18 01:01:02 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:01:02 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:01:02 --> Utf8 Class Initialized
INFO - 2024-12-18 01:01:02 --> URI Class Initialized
DEBUG - 2024-12-18 01:01:02 --> No URI present. Default controller set.
INFO - 2024-12-18 01:01:02 --> Router Class Initialized
INFO - 2024-12-18 01:01:02 --> Output Class Initialized
INFO - 2024-12-18 01:01:02 --> Security Class Initialized
DEBUG - 2024-12-18 01:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:01:02 --> Input Class Initialized
INFO - 2024-12-18 01:01:02 --> Language Class Initialized
INFO - 2024-12-18 01:01:02 --> Loader Class Initialized
INFO - 2024-12-18 01:01:02 --> Helper loaded: url_helper
INFO - 2024-12-18 01:01:02 --> Helper loaded: html_helper
INFO - 2024-12-18 01:01:02 --> Helper loaded: file_helper
INFO - 2024-12-18 01:01:02 --> Helper loaded: string_helper
INFO - 2024-12-18 01:01:02 --> Helper loaded: form_helper
INFO - 2024-12-18 01:01:02 --> Helper loaded: my_helper
INFO - 2024-12-18 01:01:02 --> Database Driver Class Initialized
INFO - 2024-12-18 01:01:04 --> Upload Class Initialized
INFO - 2024-12-18 01:01:04 --> Email Class Initialized
INFO - 2024-12-18 01:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:01:04 --> Form Validation Class Initialized
INFO - 2024-12-18 01:01:04 --> Controller Class Initialized
INFO - 2024-12-18 06:31:04 --> Model "MainModel" initialized
INFO - 2024-12-18 06:31:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 06:31:04 --> Final output sent to browser
DEBUG - 2024-12-18 06:31:04 --> Total execution time: 2.2220
INFO - 2024-12-18 01:07:27 --> Config Class Initialized
INFO - 2024-12-18 01:07:27 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:07:27 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:07:27 --> Utf8 Class Initialized
INFO - 2024-12-18 01:07:27 --> URI Class Initialized
DEBUG - 2024-12-18 01:07:27 --> No URI present. Default controller set.
INFO - 2024-12-18 01:07:27 --> Router Class Initialized
INFO - 2024-12-18 01:07:27 --> Output Class Initialized
INFO - 2024-12-18 01:07:27 --> Security Class Initialized
DEBUG - 2024-12-18 01:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:07:27 --> Input Class Initialized
INFO - 2024-12-18 01:07:27 --> Language Class Initialized
INFO - 2024-12-18 01:07:27 --> Loader Class Initialized
INFO - 2024-12-18 01:07:27 --> Helper loaded: url_helper
INFO - 2024-12-18 01:07:27 --> Helper loaded: html_helper
INFO - 2024-12-18 01:07:27 --> Helper loaded: file_helper
INFO - 2024-12-18 01:07:27 --> Helper loaded: string_helper
INFO - 2024-12-18 01:07:27 --> Helper loaded: form_helper
INFO - 2024-12-18 01:07:27 --> Helper loaded: my_helper
INFO - 2024-12-18 01:07:27 --> Database Driver Class Initialized
INFO - 2024-12-18 01:07:29 --> Upload Class Initialized
INFO - 2024-12-18 01:07:29 --> Email Class Initialized
INFO - 2024-12-18 01:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:07:29 --> Form Validation Class Initialized
INFO - 2024-12-18 01:07:29 --> Controller Class Initialized
INFO - 2024-12-18 06:37:29 --> Model "MainModel" initialized
INFO - 2024-12-18 06:37:29 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 06:37:29 --> Final output sent to browser
DEBUG - 2024-12-18 06:37:29 --> Total execution time: 2.2311
INFO - 2024-12-18 01:41:03 --> Config Class Initialized
INFO - 2024-12-18 01:41:03 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:41:03 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:41:03 --> Utf8 Class Initialized
INFO - 2024-12-18 01:41:03 --> URI Class Initialized
DEBUG - 2024-12-18 01:41:03 --> No URI present. Default controller set.
INFO - 2024-12-18 01:41:03 --> Router Class Initialized
INFO - 2024-12-18 01:41:03 --> Output Class Initialized
INFO - 2024-12-18 01:41:03 --> Security Class Initialized
DEBUG - 2024-12-18 01:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:41:03 --> Input Class Initialized
INFO - 2024-12-18 01:41:03 --> Language Class Initialized
INFO - 2024-12-18 01:41:03 --> Loader Class Initialized
INFO - 2024-12-18 01:41:03 --> Helper loaded: url_helper
INFO - 2024-12-18 01:41:03 --> Helper loaded: html_helper
INFO - 2024-12-18 01:41:03 --> Helper loaded: file_helper
INFO - 2024-12-18 01:41:03 --> Helper loaded: string_helper
INFO - 2024-12-18 01:41:03 --> Helper loaded: form_helper
INFO - 2024-12-18 01:41:03 --> Helper loaded: my_helper
INFO - 2024-12-18 01:41:03 --> Database Driver Class Initialized
INFO - 2024-12-18 01:41:06 --> Upload Class Initialized
INFO - 2024-12-18 01:41:06 --> Email Class Initialized
INFO - 2024-12-18 01:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:41:06 --> Form Validation Class Initialized
INFO - 2024-12-18 01:41:06 --> Controller Class Initialized
INFO - 2024-12-18 07:11:06 --> Model "MainModel" initialized
INFO - 2024-12-18 07:11:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 07:11:06 --> Final output sent to browser
DEBUG - 2024-12-18 07:11:06 --> Total execution time: 2.1775
INFO - 2024-12-18 01:41:13 --> Config Class Initialized
INFO - 2024-12-18 01:41:13 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:41:13 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:41:13 --> Utf8 Class Initialized
INFO - 2024-12-18 01:41:13 --> URI Class Initialized
DEBUG - 2024-12-18 01:41:13 --> No URI present. Default controller set.
INFO - 2024-12-18 01:41:13 --> Router Class Initialized
INFO - 2024-12-18 01:41:13 --> Output Class Initialized
INFO - 2024-12-18 01:41:13 --> Security Class Initialized
DEBUG - 2024-12-18 01:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:41:13 --> Input Class Initialized
INFO - 2024-12-18 01:41:13 --> Language Class Initialized
INFO - 2024-12-18 01:41:13 --> Loader Class Initialized
INFO - 2024-12-18 01:41:13 --> Helper loaded: url_helper
INFO - 2024-12-18 01:41:13 --> Helper loaded: html_helper
INFO - 2024-12-18 01:41:13 --> Helper loaded: file_helper
INFO - 2024-12-18 01:41:13 --> Helper loaded: string_helper
INFO - 2024-12-18 01:41:13 --> Helper loaded: form_helper
INFO - 2024-12-18 01:41:13 --> Helper loaded: my_helper
INFO - 2024-12-18 01:41:13 --> Database Driver Class Initialized
INFO - 2024-12-18 01:41:15 --> Upload Class Initialized
INFO - 2024-12-18 01:41:15 --> Email Class Initialized
INFO - 2024-12-18 01:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:41:15 --> Form Validation Class Initialized
INFO - 2024-12-18 01:41:15 --> Controller Class Initialized
INFO - 2024-12-18 07:11:15 --> Model "MainModel" initialized
INFO - 2024-12-18 07:11:15 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 07:11:15 --> Final output sent to browser
DEBUG - 2024-12-18 07:11:15 --> Total execution time: 2.1650
INFO - 2024-12-18 01:41:51 --> Config Class Initialized
INFO - 2024-12-18 01:41:51 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:41:51 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:41:51 --> Utf8 Class Initialized
INFO - 2024-12-18 01:41:51 --> URI Class Initialized
DEBUG - 2024-12-18 01:41:51 --> No URI present. Default controller set.
INFO - 2024-12-18 01:41:51 --> Router Class Initialized
INFO - 2024-12-18 01:41:51 --> Output Class Initialized
INFO - 2024-12-18 01:41:51 --> Security Class Initialized
DEBUG - 2024-12-18 01:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:41:51 --> Input Class Initialized
INFO - 2024-12-18 01:41:51 --> Language Class Initialized
INFO - 2024-12-18 01:41:51 --> Loader Class Initialized
INFO - 2024-12-18 01:41:51 --> Helper loaded: url_helper
INFO - 2024-12-18 01:41:51 --> Helper loaded: html_helper
INFO - 2024-12-18 01:41:51 --> Helper loaded: file_helper
INFO - 2024-12-18 01:41:51 --> Helper loaded: string_helper
INFO - 2024-12-18 01:41:51 --> Helper loaded: form_helper
INFO - 2024-12-18 01:41:51 --> Helper loaded: my_helper
INFO - 2024-12-18 01:41:51 --> Database Driver Class Initialized
INFO - 2024-12-18 01:41:53 --> Upload Class Initialized
INFO - 2024-12-18 01:41:53 --> Email Class Initialized
INFO - 2024-12-18 01:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:41:53 --> Form Validation Class Initialized
INFO - 2024-12-18 01:41:53 --> Controller Class Initialized
INFO - 2024-12-18 07:11:53 --> Model "MainModel" initialized
INFO - 2024-12-18 07:11:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 07:11:53 --> Final output sent to browser
DEBUG - 2024-12-18 07:11:53 --> Total execution time: 2.1957
INFO - 2024-12-18 01:47:09 --> Config Class Initialized
INFO - 2024-12-18 01:47:09 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:47:09 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:47:09 --> Utf8 Class Initialized
INFO - 2024-12-18 01:47:09 --> URI Class Initialized
DEBUG - 2024-12-18 01:47:09 --> No URI present. Default controller set.
INFO - 2024-12-18 01:47:09 --> Router Class Initialized
INFO - 2024-12-18 01:47:09 --> Output Class Initialized
INFO - 2024-12-18 01:47:09 --> Security Class Initialized
DEBUG - 2024-12-18 01:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:47:09 --> Input Class Initialized
INFO - 2024-12-18 01:47:09 --> Language Class Initialized
INFO - 2024-12-18 01:47:09 --> Loader Class Initialized
INFO - 2024-12-18 01:47:09 --> Helper loaded: url_helper
INFO - 2024-12-18 01:47:09 --> Helper loaded: html_helper
INFO - 2024-12-18 01:47:09 --> Helper loaded: file_helper
INFO - 2024-12-18 01:47:09 --> Helper loaded: string_helper
INFO - 2024-12-18 01:47:09 --> Helper loaded: form_helper
INFO - 2024-12-18 01:47:09 --> Helper loaded: my_helper
INFO - 2024-12-18 01:47:09 --> Database Driver Class Initialized
INFO - 2024-12-18 01:47:11 --> Upload Class Initialized
INFO - 2024-12-18 01:47:11 --> Email Class Initialized
INFO - 2024-12-18 01:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:47:11 --> Form Validation Class Initialized
INFO - 2024-12-18 01:47:11 --> Controller Class Initialized
INFO - 2024-12-18 07:17:11 --> Model "MainModel" initialized
INFO - 2024-12-18 07:17:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 07:17:11 --> Final output sent to browser
DEBUG - 2024-12-18 07:17:11 --> Total execution time: 2.3135
INFO - 2024-12-18 01:55:04 --> Config Class Initialized
INFO - 2024-12-18 01:55:04 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:55:04 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:55:04 --> Utf8 Class Initialized
INFO - 2024-12-18 01:55:04 --> URI Class Initialized
DEBUG - 2024-12-18 01:55:04 --> No URI present. Default controller set.
INFO - 2024-12-18 01:55:04 --> Router Class Initialized
INFO - 2024-12-18 01:55:04 --> Output Class Initialized
INFO - 2024-12-18 01:55:04 --> Security Class Initialized
DEBUG - 2024-12-18 01:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:55:04 --> Input Class Initialized
INFO - 2024-12-18 01:55:04 --> Language Class Initialized
INFO - 2024-12-18 01:55:04 --> Loader Class Initialized
INFO - 2024-12-18 01:55:04 --> Helper loaded: url_helper
INFO - 2024-12-18 01:55:04 --> Helper loaded: html_helper
INFO - 2024-12-18 01:55:04 --> Helper loaded: file_helper
INFO - 2024-12-18 01:55:04 --> Helper loaded: string_helper
INFO - 2024-12-18 01:55:04 --> Helper loaded: form_helper
INFO - 2024-12-18 01:55:04 --> Helper loaded: my_helper
INFO - 2024-12-18 01:55:04 --> Database Driver Class Initialized
INFO - 2024-12-18 01:55:06 --> Config Class Initialized
INFO - 2024-12-18 01:55:06 --> Hooks Class Initialized
DEBUG - 2024-12-18 01:55:06 --> UTF-8 Support Enabled
INFO - 2024-12-18 01:55:06 --> Utf8 Class Initialized
INFO - 2024-12-18 01:55:06 --> URI Class Initialized
DEBUG - 2024-12-18 01:55:06 --> No URI present. Default controller set.
INFO - 2024-12-18 01:55:06 --> Router Class Initialized
INFO - 2024-12-18 01:55:06 --> Output Class Initialized
INFO - 2024-12-18 01:55:06 --> Security Class Initialized
DEBUG - 2024-12-18 01:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 01:55:06 --> Input Class Initialized
INFO - 2024-12-18 01:55:06 --> Language Class Initialized
INFO - 2024-12-18 01:55:06 --> Loader Class Initialized
INFO - 2024-12-18 01:55:06 --> Helper loaded: url_helper
INFO - 2024-12-18 01:55:06 --> Helper loaded: html_helper
INFO - 2024-12-18 01:55:06 --> Helper loaded: file_helper
INFO - 2024-12-18 01:55:06 --> Helper loaded: string_helper
INFO - 2024-12-18 01:55:06 --> Helper loaded: form_helper
INFO - 2024-12-18 01:55:06 --> Helper loaded: my_helper
INFO - 2024-12-18 01:55:06 --> Database Driver Class Initialized
INFO - 2024-12-18 01:55:06 --> Upload Class Initialized
INFO - 2024-12-18 01:55:06 --> Email Class Initialized
INFO - 2024-12-18 01:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:55:06 --> Form Validation Class Initialized
INFO - 2024-12-18 01:55:06 --> Controller Class Initialized
INFO - 2024-12-18 07:25:06 --> Model "MainModel" initialized
INFO - 2024-12-18 07:25:06 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 07:25:06 --> Final output sent to browser
DEBUG - 2024-12-18 07:25:06 --> Total execution time: 2.2378
INFO - 2024-12-18 01:55:08 --> Upload Class Initialized
INFO - 2024-12-18 01:55:08 --> Email Class Initialized
INFO - 2024-12-18 01:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 01:55:08 --> Form Validation Class Initialized
INFO - 2024-12-18 01:55:08 --> Controller Class Initialized
INFO - 2024-12-18 07:25:08 --> Model "MainModel" initialized
INFO - 2024-12-18 07:25:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 07:25:08 --> Final output sent to browser
DEBUG - 2024-12-18 07:25:08 --> Total execution time: 2.1357
INFO - 2024-12-18 03:53:01 --> Config Class Initialized
INFO - 2024-12-18 03:53:01 --> Hooks Class Initialized
DEBUG - 2024-12-18 03:53:01 --> UTF-8 Support Enabled
INFO - 2024-12-18 03:53:01 --> Utf8 Class Initialized
INFO - 2024-12-18 03:53:01 --> URI Class Initialized
DEBUG - 2024-12-18 03:53:01 --> No URI present. Default controller set.
INFO - 2024-12-18 03:53:01 --> Router Class Initialized
INFO - 2024-12-18 03:53:01 --> Output Class Initialized
INFO - 2024-12-18 03:53:01 --> Security Class Initialized
DEBUG - 2024-12-18 03:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 03:53:01 --> Input Class Initialized
INFO - 2024-12-18 03:53:01 --> Language Class Initialized
INFO - 2024-12-18 03:53:01 --> Loader Class Initialized
INFO - 2024-12-18 03:53:01 --> Helper loaded: url_helper
INFO - 2024-12-18 03:53:01 --> Helper loaded: html_helper
INFO - 2024-12-18 03:53:01 --> Helper loaded: file_helper
INFO - 2024-12-18 03:53:01 --> Helper loaded: string_helper
INFO - 2024-12-18 03:53:01 --> Helper loaded: form_helper
INFO - 2024-12-18 03:53:01 --> Helper loaded: my_helper
INFO - 2024-12-18 03:53:01 --> Database Driver Class Initialized
INFO - 2024-12-18 03:53:03 --> Upload Class Initialized
INFO - 2024-12-18 03:53:03 --> Email Class Initialized
INFO - 2024-12-18 03:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 03:53:03 --> Form Validation Class Initialized
INFO - 2024-12-18 03:53:03 --> Controller Class Initialized
INFO - 2024-12-18 09:23:03 --> Model "MainModel" initialized
INFO - 2024-12-18 09:23:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 09:23:03 --> Final output sent to browser
DEBUG - 2024-12-18 09:23:03 --> Total execution time: 2.2942
INFO - 2024-12-18 13:49:37 --> Config Class Initialized
INFO - 2024-12-18 13:49:37 --> Hooks Class Initialized
DEBUG - 2024-12-18 13:49:37 --> UTF-8 Support Enabled
INFO - 2024-12-18 13:49:37 --> Utf8 Class Initialized
INFO - 2024-12-18 13:49:37 --> URI Class Initialized
DEBUG - 2024-12-18 13:49:37 --> No URI present. Default controller set.
INFO - 2024-12-18 13:49:37 --> Router Class Initialized
INFO - 2024-12-18 13:49:37 --> Output Class Initialized
INFO - 2024-12-18 13:49:37 --> Security Class Initialized
DEBUG - 2024-12-18 13:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 13:49:37 --> Input Class Initialized
INFO - 2024-12-18 13:49:38 --> Language Class Initialized
INFO - 2024-12-18 13:49:38 --> Loader Class Initialized
INFO - 2024-12-18 13:49:38 --> Helper loaded: url_helper
INFO - 2024-12-18 13:49:38 --> Helper loaded: html_helper
INFO - 2024-12-18 13:49:38 --> Helper loaded: file_helper
INFO - 2024-12-18 13:49:38 --> Helper loaded: string_helper
INFO - 2024-12-18 13:49:38 --> Helper loaded: form_helper
INFO - 2024-12-18 13:49:38 --> Helper loaded: my_helper
INFO - 2024-12-18 13:49:38 --> Database Driver Class Initialized
INFO - 2024-12-18 13:49:41 --> Upload Class Initialized
INFO - 2024-12-18 13:49:41 --> Email Class Initialized
INFO - 2024-12-18 13:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 13:49:41 --> Form Validation Class Initialized
INFO - 2024-12-18 13:49:41 --> Controller Class Initialized
INFO - 2024-12-18 19:19:42 --> Model "MainModel" initialized
INFO - 2024-12-18 19:19:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-18 19:19:42 --> Final output sent to browser
DEBUG - 2024-12-18 19:19:42 --> Total execution time: 5.3737
INFO - 2024-12-18 18:47:53 --> Config Class Initialized
INFO - 2024-12-18 18:47:53 --> Hooks Class Initialized
DEBUG - 2024-12-18 18:47:53 --> UTF-8 Support Enabled
INFO - 2024-12-18 18:47:53 --> Utf8 Class Initialized
INFO - 2024-12-18 18:47:53 --> URI Class Initialized
DEBUG - 2024-12-18 18:47:53 --> No URI present. Default controller set.
INFO - 2024-12-18 18:47:53 --> Router Class Initialized
INFO - 2024-12-18 18:47:53 --> Output Class Initialized
INFO - 2024-12-18 18:47:53 --> Security Class Initialized
DEBUG - 2024-12-18 18:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-18 18:47:53 --> Input Class Initialized
INFO - 2024-12-18 18:47:53 --> Language Class Initialized
INFO - 2024-12-18 18:47:54 --> Loader Class Initialized
INFO - 2024-12-18 18:47:54 --> Helper loaded: url_helper
INFO - 2024-12-18 18:47:54 --> Helper loaded: html_helper
INFO - 2024-12-18 18:47:54 --> Helper loaded: file_helper
INFO - 2024-12-18 18:47:54 --> Helper loaded: string_helper
INFO - 2024-12-18 18:47:54 --> Helper loaded: form_helper
INFO - 2024-12-18 18:47:54 --> Helper loaded: my_helper
INFO - 2024-12-18 18:47:54 --> Database Driver Class Initialized
INFO - 2024-12-18 18:47:56 --> Upload Class Initialized
INFO - 2024-12-18 18:47:56 --> Email Class Initialized
INFO - 2024-12-18 18:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-18 18:47:56 --> Form Validation Class Initialized
INFO - 2024-12-18 18:47:56 --> Controller Class Initialized
