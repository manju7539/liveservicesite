<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-12 00:21:46 --> Model "MainModel" initialized
INFO - 2024-12-12 00:21:46 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-12 00:21:46 --> Final output sent to browser
DEBUG - 2024-12-12 00:21:46 --> Total execution time: 3.4708
INFO - 2024-12-12 06:56:20 --> Config Class Initialized
INFO - 2024-12-12 06:56:20 --> Hooks Class Initialized
DEBUG - 2024-12-12 06:56:20 --> UTF-8 Support Enabled
INFO - 2024-12-12 06:56:20 --> Utf8 Class Initialized
INFO - 2024-12-12 06:56:20 --> URI Class Initialized
DEBUG - 2024-12-12 06:56:20 --> No URI present. Default controller set.
INFO - 2024-12-12 06:56:20 --> Router Class Initialized
INFO - 2024-12-12 06:56:20 --> Output Class Initialized
INFO - 2024-12-12 06:56:20 --> Security Class Initialized
DEBUG - 2024-12-12 06:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 06:56:20 --> Input Class Initialized
INFO - 2024-12-12 06:56:20 --> Language Class Initialized
INFO - 2024-12-12 06:56:20 --> Loader Class Initialized
INFO - 2024-12-12 06:56:20 --> Helper loaded: url_helper
INFO - 2024-12-12 06:56:20 --> Helper loaded: html_helper
INFO - 2024-12-12 06:56:20 --> Helper loaded: file_helper
INFO - 2024-12-12 06:56:20 --> Helper loaded: string_helper
INFO - 2024-12-12 06:56:20 --> Helper loaded: form_helper
INFO - 2024-12-12 06:56:20 --> Helper loaded: my_helper
INFO - 2024-12-12 06:56:20 --> Database Driver Class Initialized
INFO - 2024-12-12 06:56:22 --> Upload Class Initialized
INFO - 2024-12-12 06:56:22 --> Email Class Initialized
INFO - 2024-12-12 06:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-12 06:56:23 --> Form Validation Class Initialized
INFO - 2024-12-12 06:56:23 --> Controller Class Initialized
INFO - 2024-12-12 12:26:23 --> Model "MainModel" initialized
INFO - 2024-12-12 12:26:23 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-12 12:26:23 --> Final output sent to browser
DEBUG - 2024-12-12 12:26:23 --> Total execution time: 3.3109
INFO - 2024-12-12 07:07:40 --> Config Class Initialized
INFO - 2024-12-12 07:07:40 --> Hooks Class Initialized
DEBUG - 2024-12-12 07:07:40 --> UTF-8 Support Enabled
INFO - 2024-12-12 07:07:40 --> Utf8 Class Initialized
INFO - 2024-12-12 07:07:40 --> URI Class Initialized
INFO - 2024-12-12 07:07:40 --> Router Class Initialized
INFO - 2024-12-12 07:07:40 --> Output Class Initialized
INFO - 2024-12-12 07:07:40 --> Security Class Initialized
DEBUG - 2024-12-12 07:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 07:07:40 --> Input Class Initialized
INFO - 2024-12-12 07:07:40 --> Language Class Initialized
ERROR - 2024-12-12 07:07:40 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-12 16:06:24 --> Config Class Initialized
INFO - 2024-12-12 16:06:24 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:24 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:24 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:24 --> URI Class Initialized
DEBUG - 2024-12-12 16:06:25 --> No URI present. Default controller set.
INFO - 2024-12-12 16:06:25 --> Router Class Initialized
INFO - 2024-12-12 16:06:25 --> Output Class Initialized
INFO - 2024-12-12 16:06:25 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:25 --> Input Class Initialized
INFO - 2024-12-12 16:06:25 --> Language Class Initialized
INFO - 2024-12-12 16:06:25 --> Loader Class Initialized
INFO - 2024-12-12 16:06:25 --> Helper loaded: url_helper
INFO - 2024-12-12 16:06:25 --> Helper loaded: html_helper
INFO - 2024-12-12 16:06:25 --> Helper loaded: file_helper
INFO - 2024-12-12 16:06:25 --> Helper loaded: string_helper
INFO - 2024-12-12 16:06:25 --> Helper loaded: form_helper
INFO - 2024-12-12 16:06:25 --> Helper loaded: my_helper
INFO - 2024-12-12 16:06:25 --> Database Driver Class Initialized
INFO - 2024-12-12 16:06:27 --> Upload Class Initialized
INFO - 2024-12-12 16:06:27 --> Email Class Initialized
INFO - 2024-12-12 16:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-12 16:06:27 --> Form Validation Class Initialized
INFO - 2024-12-12 16:06:27 --> Controller Class Initialized
INFO - 2024-12-12 21:36:28 --> Model "MainModel" initialized
INFO - 2024-12-12 21:36:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-12 21:36:28 --> Final output sent to browser
DEBUG - 2024-12-12 21:36:28 --> Total execution time: 3.4199
INFO - 2024-12-12 16:06:28 --> Config Class Initialized
INFO - 2024-12-12 16:06:28 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:28 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:28 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:28 --> URI Class Initialized
INFO - 2024-12-12 16:06:28 --> Router Class Initialized
INFO - 2024-12-12 16:06:28 --> Output Class Initialized
INFO - 2024-12-12 16:06:28 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:28 --> Input Class Initialized
INFO - 2024-12-12 16:06:28 --> Language Class Initialized
ERROR - 2024-12-12 16:06:28 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-12 16:06:28 --> Config Class Initialized
INFO - 2024-12-12 16:06:28 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:28 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:28 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:28 --> URI Class Initialized
INFO - 2024-12-12 16:06:28 --> Router Class Initialized
INFO - 2024-12-12 16:06:28 --> Output Class Initialized
INFO - 2024-12-12 16:06:28 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:28 --> Input Class Initialized
INFO - 2024-12-12 16:06:28 --> Language Class Initialized
ERROR - 2024-12-12 16:06:28 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-12 16:06:29 --> Config Class Initialized
INFO - 2024-12-12 16:06:29 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:29 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:29 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:29 --> URI Class Initialized
DEBUG - 2024-12-12 16:06:29 --> No URI present. Default controller set.
INFO - 2024-12-12 16:06:29 --> Router Class Initialized
INFO - 2024-12-12 16:06:29 --> Output Class Initialized
INFO - 2024-12-12 16:06:29 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:29 --> Input Class Initialized
INFO - 2024-12-12 16:06:29 --> Language Class Initialized
INFO - 2024-12-12 16:06:29 --> Loader Class Initialized
INFO - 2024-12-12 16:06:29 --> Helper loaded: url_helper
INFO - 2024-12-12 16:06:29 --> Helper loaded: html_helper
INFO - 2024-12-12 16:06:29 --> Helper loaded: file_helper
INFO - 2024-12-12 16:06:29 --> Helper loaded: string_helper
INFO - 2024-12-12 16:06:29 --> Helper loaded: form_helper
INFO - 2024-12-12 16:06:29 --> Helper loaded: my_helper
INFO - 2024-12-12 16:06:29 --> Database Driver Class Initialized
INFO - 2024-12-12 16:06:31 --> Upload Class Initialized
INFO - 2024-12-12 16:06:31 --> Email Class Initialized
INFO - 2024-12-12 16:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-12 16:06:31 --> Form Validation Class Initialized
INFO - 2024-12-12 16:06:31 --> Controller Class Initialized
INFO - 2024-12-12 21:36:31 --> Model "MainModel" initialized
INFO - 2024-12-12 21:36:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-12 21:36:31 --> Final output sent to browser
DEBUG - 2024-12-12 21:36:31 --> Total execution time: 2.2458
INFO - 2024-12-12 16:06:31 --> Config Class Initialized
INFO - 2024-12-12 16:06:31 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:31 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:31 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:31 --> URI Class Initialized
INFO - 2024-12-12 16:06:31 --> Router Class Initialized
INFO - 2024-12-12 16:06:31 --> Output Class Initialized
INFO - 2024-12-12 16:06:31 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:31 --> Input Class Initialized
INFO - 2024-12-12 16:06:31 --> Language Class Initialized
ERROR - 2024-12-12 16:06:31 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-12 16:06:32 --> Config Class Initialized
INFO - 2024-12-12 16:06:32 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:32 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:32 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:32 --> URI Class Initialized
INFO - 2024-12-12 16:06:32 --> Router Class Initialized
INFO - 2024-12-12 16:06:32 --> Output Class Initialized
INFO - 2024-12-12 16:06:32 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:32 --> Input Class Initialized
INFO - 2024-12-12 16:06:32 --> Language Class Initialized
ERROR - 2024-12-12 16:06:32 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-12 16:06:32 --> Config Class Initialized
INFO - 2024-12-12 16:06:32 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:32 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:32 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:32 --> URI Class Initialized
INFO - 2024-12-12 16:06:32 --> Router Class Initialized
INFO - 2024-12-12 16:06:32 --> Output Class Initialized
INFO - 2024-12-12 16:06:32 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:32 --> Input Class Initialized
INFO - 2024-12-12 16:06:32 --> Language Class Initialized
ERROR - 2024-12-12 16:06:32 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-12 16:06:32 --> Config Class Initialized
INFO - 2024-12-12 16:06:32 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:32 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:32 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:32 --> URI Class Initialized
INFO - 2024-12-12 16:06:32 --> Router Class Initialized
INFO - 2024-12-12 16:06:32 --> Output Class Initialized
INFO - 2024-12-12 16:06:32 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:32 --> Input Class Initialized
INFO - 2024-12-12 16:06:32 --> Language Class Initialized
ERROR - 2024-12-12 16:06:32 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-12 16:06:33 --> Config Class Initialized
INFO - 2024-12-12 16:06:33 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:33 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:33 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:33 --> URI Class Initialized
INFO - 2024-12-12 16:06:33 --> Router Class Initialized
INFO - 2024-12-12 16:06:33 --> Output Class Initialized
INFO - 2024-12-12 16:06:33 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:33 --> Input Class Initialized
INFO - 2024-12-12 16:06:33 --> Language Class Initialized
ERROR - 2024-12-12 16:06:33 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-12 16:06:33 --> Config Class Initialized
INFO - 2024-12-12 16:06:33 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:33 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:33 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:33 --> URI Class Initialized
INFO - 2024-12-12 16:06:33 --> Router Class Initialized
INFO - 2024-12-12 16:06:33 --> Output Class Initialized
INFO - 2024-12-12 16:06:33 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:33 --> Input Class Initialized
INFO - 2024-12-12 16:06:33 --> Language Class Initialized
ERROR - 2024-12-12 16:06:33 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-12 16:06:33 --> Config Class Initialized
INFO - 2024-12-12 16:06:33 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:33 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:33 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:33 --> URI Class Initialized
INFO - 2024-12-12 16:06:33 --> Router Class Initialized
INFO - 2024-12-12 16:06:33 --> Output Class Initialized
INFO - 2024-12-12 16:06:33 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:33 --> Input Class Initialized
INFO - 2024-12-12 16:06:33 --> Language Class Initialized
ERROR - 2024-12-12 16:06:33 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-12 16:06:34 --> Config Class Initialized
INFO - 2024-12-12 16:06:34 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:34 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:34 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:34 --> URI Class Initialized
INFO - 2024-12-12 16:06:34 --> Router Class Initialized
INFO - 2024-12-12 16:06:34 --> Output Class Initialized
INFO - 2024-12-12 16:06:34 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:34 --> Input Class Initialized
INFO - 2024-12-12 16:06:34 --> Language Class Initialized
ERROR - 2024-12-12 16:06:34 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-12 16:06:34 --> Config Class Initialized
INFO - 2024-12-12 16:06:34 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:34 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:34 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:34 --> URI Class Initialized
INFO - 2024-12-12 16:06:34 --> Router Class Initialized
INFO - 2024-12-12 16:06:34 --> Output Class Initialized
INFO - 2024-12-12 16:06:34 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:34 --> Input Class Initialized
INFO - 2024-12-12 16:06:34 --> Language Class Initialized
ERROR - 2024-12-12 16:06:34 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-12 16:06:34 --> Config Class Initialized
INFO - 2024-12-12 16:06:34 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:34 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:34 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:34 --> URI Class Initialized
INFO - 2024-12-12 16:06:34 --> Router Class Initialized
INFO - 2024-12-12 16:06:34 --> Output Class Initialized
INFO - 2024-12-12 16:06:34 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:34 --> Input Class Initialized
INFO - 2024-12-12 16:06:34 --> Language Class Initialized
ERROR - 2024-12-12 16:06:34 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-12 16:06:35 --> Config Class Initialized
INFO - 2024-12-12 16:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:35 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:35 --> URI Class Initialized
INFO - 2024-12-12 16:06:35 --> Router Class Initialized
INFO - 2024-12-12 16:06:35 --> Output Class Initialized
INFO - 2024-12-12 16:06:35 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:35 --> Input Class Initialized
INFO - 2024-12-12 16:06:35 --> Language Class Initialized
ERROR - 2024-12-12 16:06:35 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-12 16:06:35 --> Config Class Initialized
INFO - 2024-12-12 16:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:35 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:35 --> URI Class Initialized
INFO - 2024-12-12 16:06:35 --> Router Class Initialized
INFO - 2024-12-12 16:06:35 --> Output Class Initialized
INFO - 2024-12-12 16:06:35 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:35 --> Input Class Initialized
INFO - 2024-12-12 16:06:35 --> Language Class Initialized
ERROR - 2024-12-12 16:06:35 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-12 16:06:35 --> Config Class Initialized
INFO - 2024-12-12 16:06:35 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:35 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:35 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:35 --> URI Class Initialized
INFO - 2024-12-12 16:06:35 --> Router Class Initialized
INFO - 2024-12-12 16:06:35 --> Output Class Initialized
INFO - 2024-12-12 16:06:35 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:35 --> Input Class Initialized
INFO - 2024-12-12 16:06:35 --> Language Class Initialized
ERROR - 2024-12-12 16:06:35 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-12 16:06:36 --> Config Class Initialized
INFO - 2024-12-12 16:06:36 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:36 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:36 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:36 --> URI Class Initialized
INFO - 2024-12-12 16:06:36 --> Router Class Initialized
INFO - 2024-12-12 16:06:36 --> Output Class Initialized
INFO - 2024-12-12 16:06:36 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:36 --> Input Class Initialized
INFO - 2024-12-12 16:06:36 --> Language Class Initialized
ERROR - 2024-12-12 16:06:36 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-12 16:06:36 --> Config Class Initialized
INFO - 2024-12-12 16:06:36 --> Hooks Class Initialized
DEBUG - 2024-12-12 16:06:36 --> UTF-8 Support Enabled
INFO - 2024-12-12 16:06:36 --> Utf8 Class Initialized
INFO - 2024-12-12 16:06:36 --> URI Class Initialized
INFO - 2024-12-12 16:06:36 --> Router Class Initialized
INFO - 2024-12-12 16:06:36 --> Output Class Initialized
INFO - 2024-12-12 16:06:36 --> Security Class Initialized
DEBUG - 2024-12-12 16:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-12 16:06:36 --> Input Class Initialized
INFO - 2024-12-12 16:06:36 --> Language Class Initialized
ERROR - 2024-12-12 16:06:36 --> 404 Page Not Found: Sito/wp-includes
