<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-01-24 05:19:15 --> Config Class Initialized
INFO - 2025-01-24 05:19:15 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:15 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:15 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:15 --> URI Class Initialized
INFO - 2025-01-24 05:19:15 --> Router Class Initialized
INFO - 2025-01-24 05:19:15 --> Output Class Initialized
INFO - 2025-01-24 05:19:15 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:15 --> Input Class Initialized
INFO - 2025-01-24 05:19:15 --> Language Class Initialized
INFO - 2025-01-24 05:19:16 --> Loader Class Initialized
INFO - 2025-01-24 05:19:16 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:16 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:16 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:16 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:16 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:16 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:16 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:16 --> Upload Class Initialized
INFO - 2025-01-24 05:19:16 --> Email Class Initialized
INFO - 2025-01-24 05:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:17 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:17 --> Controller Class Initialized
INFO - 2025-01-24 10:49:17 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:17 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:17 --> Model "MainModel" initialized
INFO - 2025-01-24 05:19:17 --> Config Class Initialized
INFO - 2025-01-24 05:19:17 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:17 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:17 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:17 --> URI Class Initialized
DEBUG - 2025-01-24 05:19:17 --> No URI present. Default controller set.
INFO - 2025-01-24 05:19:17 --> Router Class Initialized
INFO - 2025-01-24 05:19:17 --> Output Class Initialized
INFO - 2025-01-24 05:19:17 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:17 --> Input Class Initialized
INFO - 2025-01-24 05:19:17 --> Language Class Initialized
INFO - 2025-01-24 05:19:17 --> Loader Class Initialized
INFO - 2025-01-24 05:19:17 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:17 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:17 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:17 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:17 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:17 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:17 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:17 --> Upload Class Initialized
INFO - 2025-01-24 05:19:17 --> Email Class Initialized
INFO - 2025-01-24 05:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:17 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:17 --> Controller Class Initialized
INFO - 2025-01-24 10:49:17 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:17 --> File loaded: C:\wamp64\www\liveservicesite\application\views\auth/login.php
INFO - 2025-01-24 10:49:17 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:17 --> Total execution time: 0.1517
INFO - 2025-01-24 05:19:28 --> Config Class Initialized
INFO - 2025-01-24 05:19:28 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:28 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:28 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:28 --> URI Class Initialized
INFO - 2025-01-24 05:19:28 --> Router Class Initialized
INFO - 2025-01-24 05:19:28 --> Output Class Initialized
INFO - 2025-01-24 05:19:28 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:28 --> Input Class Initialized
INFO - 2025-01-24 05:19:28 --> Language Class Initialized
INFO - 2025-01-24 05:19:28 --> Loader Class Initialized
INFO - 2025-01-24 05:19:28 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:28 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:28 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:28 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:28 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:28 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:28 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:28 --> Upload Class Initialized
INFO - 2025-01-24 05:19:28 --> Email Class Initialized
INFO - 2025-01-24 05:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:28 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:28 --> Controller Class Initialized
INFO - 2025-01-24 10:49:28 --> Model "MainModel" initialized
INFO - 2025-01-24 05:19:29 --> Config Class Initialized
INFO - 2025-01-24 05:19:29 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:29 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:29 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:29 --> URI Class Initialized
INFO - 2025-01-24 05:19:29 --> Router Class Initialized
INFO - 2025-01-24 05:19:29 --> Output Class Initialized
INFO - 2025-01-24 05:19:29 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:29 --> Input Class Initialized
INFO - 2025-01-24 05:19:29 --> Language Class Initialized
INFO - 2025-01-24 05:19:29 --> Loader Class Initialized
INFO - 2025-01-24 05:19:29 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:29 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:29 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:29 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:29 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:29 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:29 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:29 --> Upload Class Initialized
INFO - 2025-01-24 05:19:29 --> Email Class Initialized
INFO - 2025-01-24 05:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:29 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:29 --> Controller Class Initialized
INFO - 2025-01-24 10:49:29 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:29 --> Model "FrontofficeModel" initialized
INFO - 2025-01-24 10:49:29 --> Model "HotelAdminModel" initialized
INFO - 2025-01-24 10:49:29 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-24 10:49:29 --> Model "FoodAdminModel" initialized
INFO - 2025-01-24 10:49:29 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:29 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:29 --> Helper loaded: array_helper
INFO - 2025-01-24 10:49:31 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-24 10:49:31 --> File loaded: C:\wamp64\www\liveservicesite\application\views\page/superadmindashboard.php
INFO - 2025-01-24 10:49:31 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-24 10:49:31 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:31 --> Total execution time: 2.2655
INFO - 2025-01-24 05:19:31 --> Config Class Initialized
INFO - 2025-01-24 05:19:31 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:31 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:31 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:31 --> URI Class Initialized
INFO - 2025-01-24 05:19:31 --> Router Class Initialized
INFO - 2025-01-24 05:19:31 --> Output Class Initialized
INFO - 2025-01-24 05:19:31 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:31 --> Input Class Initialized
INFO - 2025-01-24 05:19:31 --> Language Class Initialized
ERROR - 2025-01-24 05:19:31 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:31 --> Config Class Initialized
INFO - 2025-01-24 05:19:31 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:31 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:31 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:31 --> URI Class Initialized
INFO - 2025-01-24 05:19:31 --> Router Class Initialized
INFO - 2025-01-24 05:19:31 --> Output Class Initialized
INFO - 2025-01-24 05:19:31 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:31 --> Input Class Initialized
INFO - 2025-01-24 05:19:31 --> Language Class Initialized
ERROR - 2025-01-24 05:19:31 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:31 --> Config Class Initialized
INFO - 2025-01-24 05:19:31 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:31 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:31 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:31 --> URI Class Initialized
INFO - 2025-01-24 05:19:31 --> Router Class Initialized
INFO - 2025-01-24 05:19:31 --> Output Class Initialized
INFO - 2025-01-24 05:19:31 --> Security Class Initialized
INFO - 2025-01-24 05:19:31 --> Config Class Initialized
INFO - 2025-01-24 05:19:31 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:31 --> Input Class Initialized
DEBUG - 2025-01-24 05:19:31 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:31 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:31 --> Language Class Initialized
INFO - 2025-01-24 05:19:31 --> URI Class Initialized
INFO - 2025-01-24 05:19:31 --> Loader Class Initialized
INFO - 2025-01-24 05:19:31 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:31 --> Router Class Initialized
INFO - 2025-01-24 05:19:31 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:31 --> Output Class Initialized
INFO - 2025-01-24 05:19:31 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:31 --> Security Class Initialized
INFO - 2025-01-24 05:19:31 --> Helper loaded: string_helper
DEBUG - 2025-01-24 05:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:31 --> Input Class Initialized
INFO - 2025-01-24 05:19:31 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:31 --> Language Class Initialized
INFO - 2025-01-24 05:19:31 --> Helper loaded: my_helper
ERROR - 2025-01-24 05:19:31 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:31 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:31 --> Upload Class Initialized
INFO - 2025-01-24 05:19:31 --> Email Class Initialized
INFO - 2025-01-24 05:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:31 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:31 --> Controller Class Initialized
INFO - 2025-01-24 10:49:31 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:31 --> Model "FrontofficeModel" initialized
INFO - 2025-01-24 10:49:31 --> Model "HotelAdminModel" initialized
INFO - 2025-01-24 10:49:31 --> Model "HouseKeepingModel" initialized
INFO - 2025-01-24 10:49:31 --> Model "FoodAdminModel" initialized
INFO - 2025-01-24 10:49:31 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:31 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:31 --> Helper loaded: array_helper
INFO - 2025-01-24 10:49:31 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:31 --> Total execution time: 0.0348
INFO - 2025-01-24 05:19:36 --> Config Class Initialized
INFO - 2025-01-24 05:19:36 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:36 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:36 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:36 --> URI Class Initialized
INFO - 2025-01-24 05:19:36 --> Router Class Initialized
INFO - 2025-01-24 05:19:36 --> Output Class Initialized
INFO - 2025-01-24 05:19:36 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:36 --> Input Class Initialized
INFO - 2025-01-24 05:19:36 --> Language Class Initialized
INFO - 2025-01-24 05:19:37 --> Loader Class Initialized
INFO - 2025-01-24 05:19:37 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:37 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:37 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:37 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:37 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:37 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:37 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:37 --> Upload Class Initialized
INFO - 2025-01-24 05:19:37 --> Email Class Initialized
INFO - 2025-01-24 05:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:37 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:37 --> Controller Class Initialized
INFO - 2025-01-24 10:49:37 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:49:37 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:49:37 --> Pagination Class Initialized
INFO - 2025-01-24 05:19:38 --> Config Class Initialized
INFO - 2025-01-24 05:19:38 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:38 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:38 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:38 --> URI Class Initialized
INFO - 2025-01-24 05:19:38 --> Router Class Initialized
INFO - 2025-01-24 05:19:38 --> Output Class Initialized
INFO - 2025-01-24 05:19:39 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:39 --> Input Class Initialized
INFO - 2025-01-24 05:19:39 --> Language Class Initialized
INFO - 2025-01-24 05:19:39 --> Loader Class Initialized
INFO - 2025-01-24 05:19:39 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:39 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:39 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:39 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:39 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:39 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:39 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:39 --> Upload Class Initialized
INFO - 2025-01-24 05:19:39 --> Email Class Initialized
INFO - 2025-01-24 05:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:39 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:39 --> Controller Class Initialized
INFO - 2025-01-24 10:49:39 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:39 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:39 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:39 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
ERROR - 2025-01-24 10:49:39 --> Severity: Warning --> Undefined array key "u_id" C:\wamp64\www\liveservicesite\application\views\superadmin\hotelLists.php 369
INFO - 2025-01-24 10:49:39 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/hotelLists.php
INFO - 2025-01-24 10:49:39 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-24 10:49:39 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:39 --> Total execution time: 0.4362
INFO - 2025-01-24 05:19:39 --> Config Class Initialized
INFO - 2025-01-24 05:19:39 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:39 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:39 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:39 --> URI Class Initialized
INFO - 2025-01-24 05:19:39 --> Router Class Initialized
INFO - 2025-01-24 05:19:39 --> Output Class Initialized
INFO - 2025-01-24 05:19:39 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:39 --> Input Class Initialized
INFO - 2025-01-24 05:19:39 --> Language Class Initialized
ERROR - 2025-01-24 05:19:39 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:39 --> Config Class Initialized
INFO - 2025-01-24 05:19:39 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:39 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:39 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:39 --> URI Class Initialized
INFO - 2025-01-24 05:19:39 --> Router Class Initialized
INFO - 2025-01-24 05:19:39 --> Output Class Initialized
INFO - 2025-01-24 05:19:39 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:39 --> Input Class Initialized
INFO - 2025-01-24 05:19:39 --> Language Class Initialized
ERROR - 2025-01-24 05:19:39 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:39 --> Config Class Initialized
INFO - 2025-01-24 05:19:39 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:39 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:39 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:39 --> URI Class Initialized
INFO - 2025-01-24 05:19:39 --> Router Class Initialized
INFO - 2025-01-24 05:19:39 --> Output Class Initialized
INFO - 2025-01-24 05:19:39 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:39 --> Input Class Initialized
INFO - 2025-01-24 05:19:39 --> Language Class Initialized
ERROR - 2025-01-24 05:19:39 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:41 --> Config Class Initialized
INFO - 2025-01-24 05:19:41 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:41 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:41 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:41 --> URI Class Initialized
INFO - 2025-01-24 05:19:41 --> Router Class Initialized
INFO - 2025-01-24 05:19:41 --> Output Class Initialized
INFO - 2025-01-24 05:19:41 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:41 --> Input Class Initialized
INFO - 2025-01-24 05:19:41 --> Language Class Initialized
INFO - 2025-01-24 05:19:41 --> Loader Class Initialized
INFO - 2025-01-24 05:19:41 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:41 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:41 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:41 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:41 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:41 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:41 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:41 --> Upload Class Initialized
INFO - 2025-01-24 05:19:41 --> Email Class Initialized
INFO - 2025-01-24 05:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:41 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:41 --> Controller Class Initialized
INFO - 2025-01-24 10:49:41 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:41 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:41 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:41 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-24 10:49:42 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/leadsPlan.php
INFO - 2025-01-24 10:49:42 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-24 10:49:42 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:42 --> Total execution time: 0.1902
INFO - 2025-01-24 05:19:42 --> Config Class Initialized
INFO - 2025-01-24 05:19:42 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:42 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:42 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:42 --> URI Class Initialized
INFO - 2025-01-24 05:19:42 --> Router Class Initialized
INFO - 2025-01-24 05:19:42 --> Output Class Initialized
INFO - 2025-01-24 05:19:42 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:42 --> Input Class Initialized
INFO - 2025-01-24 05:19:42 --> Language Class Initialized
ERROR - 2025-01-24 05:19:42 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:42 --> Config Class Initialized
INFO - 2025-01-24 05:19:42 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:42 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:42 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:42 --> URI Class Initialized
INFO - 2025-01-24 05:19:42 --> Router Class Initialized
INFO - 2025-01-24 05:19:42 --> Output Class Initialized
INFO - 2025-01-24 05:19:42 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:42 --> Input Class Initialized
INFO - 2025-01-24 05:19:42 --> Language Class Initialized
ERROR - 2025-01-24 05:19:42 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:42 --> Config Class Initialized
INFO - 2025-01-24 05:19:42 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:42 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:42 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:42 --> URI Class Initialized
INFO - 2025-01-24 05:19:42 --> Router Class Initialized
INFO - 2025-01-24 05:19:42 --> Output Class Initialized
INFO - 2025-01-24 05:19:42 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:42 --> Input Class Initialized
INFO - 2025-01-24 05:19:42 --> Language Class Initialized
ERROR - 2025-01-24 05:19:42 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:43 --> Config Class Initialized
INFO - 2025-01-24 05:19:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:43 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:43 --> URI Class Initialized
INFO - 2025-01-24 05:19:43 --> Router Class Initialized
INFO - 2025-01-24 05:19:43 --> Output Class Initialized
INFO - 2025-01-24 05:19:43 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:43 --> Input Class Initialized
INFO - 2025-01-24 05:19:43 --> Language Class Initialized
INFO - 2025-01-24 05:19:43 --> Loader Class Initialized
INFO - 2025-01-24 05:19:43 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:43 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:43 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:43 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:43 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:43 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:43 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:43 --> Upload Class Initialized
INFO - 2025-01-24 05:19:43 --> Email Class Initialized
INFO - 2025-01-24 05:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:43 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:43 --> Controller Class Initialized
INFO - 2025-01-24 10:49:43 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:43 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:43 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:43 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 193
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
ERROR - 2025-01-24 10:49:43 --> Severity: Warning --> Undefined variable $city C:\wamp64\www\liveservicesite\application\views\superadmin\leadRecharge.php 203
INFO - 2025-01-24 10:49:43 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/leadRecharge.php
INFO - 2025-01-24 10:49:43 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-24 10:49:43 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:43 --> Total execution time: 0.1267
INFO - 2025-01-24 05:19:43 --> Config Class Initialized
INFO - 2025-01-24 05:19:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:43 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:43 --> URI Class Initialized
INFO - 2025-01-24 05:19:43 --> Router Class Initialized
INFO - 2025-01-24 05:19:43 --> Output Class Initialized
INFO - 2025-01-24 05:19:43 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:43 --> Input Class Initialized
INFO - 2025-01-24 05:19:43 --> Language Class Initialized
ERROR - 2025-01-24 05:19:43 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:43 --> Config Class Initialized
INFO - 2025-01-24 05:19:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:43 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:43 --> URI Class Initialized
INFO - 2025-01-24 05:19:43 --> Router Class Initialized
INFO - 2025-01-24 05:19:43 --> Output Class Initialized
INFO - 2025-01-24 05:19:43 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:43 --> Input Class Initialized
INFO - 2025-01-24 05:19:43 --> Language Class Initialized
ERROR - 2025-01-24 05:19:43 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:43 --> Config Class Initialized
INFO - 2025-01-24 05:19:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:43 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:43 --> URI Class Initialized
INFO - 2025-01-24 05:19:43 --> Router Class Initialized
INFO - 2025-01-24 05:19:43 --> Output Class Initialized
INFO - 2025-01-24 05:19:43 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:43 --> Input Class Initialized
INFO - 2025-01-24 05:19:43 --> Language Class Initialized
ERROR - 2025-01-24 05:19:43 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:46 --> Config Class Initialized
INFO - 2025-01-24 05:19:46 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:46 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:46 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:46 --> URI Class Initialized
INFO - 2025-01-24 05:19:46 --> Router Class Initialized
INFO - 2025-01-24 05:19:46 --> Output Class Initialized
INFO - 2025-01-24 05:19:46 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:46 --> Input Class Initialized
INFO - 2025-01-24 05:19:46 --> Language Class Initialized
INFO - 2025-01-24 05:19:46 --> Loader Class Initialized
INFO - 2025-01-24 05:19:46 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:46 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:46 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:46 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:46 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:46 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:46 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:46 --> Upload Class Initialized
INFO - 2025-01-24 05:19:46 --> Email Class Initialized
INFO - 2025-01-24 05:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:46 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:46 --> Controller Class Initialized
INFO - 2025-01-24 10:49:46 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:46 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:46 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:46 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-24 10:49:46 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/mng_credits.php
INFO - 2025-01-24 10:49:46 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-24 10:49:46 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:46 --> Total execution time: 0.1999
INFO - 2025-01-24 05:19:46 --> Config Class Initialized
INFO - 2025-01-24 05:19:46 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:46 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:46 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:46 --> URI Class Initialized
INFO - 2025-01-24 05:19:46 --> Router Class Initialized
INFO - 2025-01-24 05:19:46 --> Output Class Initialized
INFO - 2025-01-24 05:19:46 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:46 --> Input Class Initialized
INFO - 2025-01-24 05:19:46 --> Language Class Initialized
ERROR - 2025-01-24 05:19:46 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:46 --> Config Class Initialized
INFO - 2025-01-24 05:19:46 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:46 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:46 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:46 --> URI Class Initialized
INFO - 2025-01-24 05:19:46 --> Router Class Initialized
INFO - 2025-01-24 05:19:46 --> Output Class Initialized
INFO - 2025-01-24 05:19:46 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:46 --> Input Class Initialized
INFO - 2025-01-24 05:19:46 --> Language Class Initialized
ERROR - 2025-01-24 05:19:46 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:46 --> Config Class Initialized
INFO - 2025-01-24 05:19:46 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:46 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:46 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:46 --> URI Class Initialized
INFO - 2025-01-24 05:19:46 --> Router Class Initialized
INFO - 2025-01-24 05:19:46 --> Output Class Initialized
INFO - 2025-01-24 05:19:46 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:46 --> Input Class Initialized
INFO - 2025-01-24 05:19:46 --> Language Class Initialized
ERROR - 2025-01-24 05:19:46 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:47 --> Config Class Initialized
INFO - 2025-01-24 05:19:47 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:47 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:47 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:47 --> URI Class Initialized
INFO - 2025-01-24 05:19:47 --> Router Class Initialized
INFO - 2025-01-24 05:19:47 --> Output Class Initialized
INFO - 2025-01-24 05:19:47 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:47 --> Input Class Initialized
INFO - 2025-01-24 05:19:47 --> Language Class Initialized
INFO - 2025-01-24 05:19:47 --> Loader Class Initialized
INFO - 2025-01-24 05:19:47 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:47 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:47 --> Upload Class Initialized
INFO - 2025-01-24 05:19:47 --> Email Class Initialized
INFO - 2025-01-24 05:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:47 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:47 --> Controller Class Initialized
INFO - 2025-01-24 10:49:47 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:47 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:47 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:47 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
ERROR - 2025-01-24 10:49:47 --> Severity: Warning --> Undefined array key "hotel_id" C:\wamp64\www\liveservicesite\application\views\superadmin\leads.php 214
INFO - 2025-01-24 05:19:47 --> Config Class Initialized
INFO - 2025-01-24 05:19:47 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:47 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:47 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:47 --> URI Class Initialized
INFO - 2025-01-24 05:19:47 --> Router Class Initialized
INFO - 2025-01-24 05:19:47 --> Output Class Initialized
INFO - 2025-01-24 05:19:47 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:47 --> Input Class Initialized
INFO - 2025-01-24 05:19:47 --> Language Class Initialized
INFO - 2025-01-24 05:19:47 --> Loader Class Initialized
INFO - 2025-01-24 05:19:47 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:47 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:47 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:47 --> Upload Class Initialized
INFO - 2025-01-24 05:19:47 --> Email Class Initialized
INFO - 2025-01-24 10:49:48 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/leads.php
INFO - 2025-01-24 10:49:48 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-24 10:49:48 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:48 --> Total execution time: 0.6484
INFO - 2025-01-24 05:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:48 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:48 --> Controller Class Initialized
INFO - 2025-01-24 10:49:48 --> Model "SuperAdminModel" initialized
INFO - 2025-01-24 10:49:48 --> Helper loaded: notification_helper
INFO - 2025-01-24 10:49:48 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:48 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/header.php
INFO - 2025-01-24 10:49:48 --> File loaded: C:\wamp64\www\liveservicesite\application\views\superadmin/plan_purchase_hotels.php
INFO - 2025-01-24 10:49:48 --> File loaded: C:\wamp64\www\liveservicesite\application\views\include/footer.php
INFO - 2025-01-24 10:49:48 --> Final output sent to browser
DEBUG - 2025-01-24 10:49:48 --> Total execution time: 0.2170
INFO - 2025-01-24 05:19:48 --> Config Class Initialized
INFO - 2025-01-24 05:19:48 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:48 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:48 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:48 --> URI Class Initialized
INFO - 2025-01-24 05:19:48 --> Router Class Initialized
INFO - 2025-01-24 05:19:48 --> Output Class Initialized
INFO - 2025-01-24 05:19:48 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:48 --> Input Class Initialized
INFO - 2025-01-24 05:19:48 --> Language Class Initialized
ERROR - 2025-01-24 05:19:48 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:48 --> Config Class Initialized
INFO - 2025-01-24 05:19:48 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:48 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:48 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:48 --> URI Class Initialized
INFO - 2025-01-24 05:19:48 --> Router Class Initialized
INFO - 2025-01-24 05:19:48 --> Output Class Initialized
INFO - 2025-01-24 05:19:48 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:48 --> Input Class Initialized
INFO - 2025-01-24 05:19:48 --> Language Class Initialized
ERROR - 2025-01-24 05:19:48 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:48 --> Config Class Initialized
INFO - 2025-01-24 05:19:48 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:48 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:48 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:48 --> URI Class Initialized
INFO - 2025-01-24 05:19:48 --> Router Class Initialized
INFO - 2025-01-24 05:19:48 --> Output Class Initialized
INFO - 2025-01-24 05:19:48 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:48 --> Input Class Initialized
INFO - 2025-01-24 05:19:48 --> Language Class Initialized
ERROR - 2025-01-24 05:19:48 --> 404 Page Not Found: Fonts/poppins
INFO - 2025-01-24 05:19:53 --> Config Class Initialized
INFO - 2025-01-24 05:19:53 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:53 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:53 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:53 --> URI Class Initialized
INFO - 2025-01-24 05:19:53 --> Router Class Initialized
INFO - 2025-01-24 05:19:53 --> Output Class Initialized
INFO - 2025-01-24 05:19:53 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:53 --> Input Class Initialized
INFO - 2025-01-24 05:19:53 --> Language Class Initialized
INFO - 2025-01-24 05:19:53 --> Loader Class Initialized
INFO - 2025-01-24 05:19:53 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:53 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:53 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:53 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:53 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:53 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:53 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:53 --> Upload Class Initialized
INFO - 2025-01-24 05:19:53 --> Email Class Initialized
INFO - 2025-01-24 05:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:53 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:53 --> Controller Class Initialized
INFO - 2025-01-24 10:49:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:49:53 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:49:53 --> Pagination Class Initialized
INFO - 2025-01-24 05:19:58 --> Config Class Initialized
INFO - 2025-01-24 05:19:58 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:19:58 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:19:58 --> Utf8 Class Initialized
INFO - 2025-01-24 05:19:58 --> URI Class Initialized
INFO - 2025-01-24 05:19:58 --> Router Class Initialized
INFO - 2025-01-24 05:19:58 --> Output Class Initialized
INFO - 2025-01-24 05:19:58 --> Security Class Initialized
DEBUG - 2025-01-24 05:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:19:58 --> Input Class Initialized
INFO - 2025-01-24 05:19:58 --> Language Class Initialized
INFO - 2025-01-24 05:19:58 --> Loader Class Initialized
INFO - 2025-01-24 05:19:58 --> Helper loaded: url_helper
INFO - 2025-01-24 05:19:58 --> Helper loaded: html_helper
INFO - 2025-01-24 05:19:58 --> Helper loaded: file_helper
INFO - 2025-01-24 05:19:58 --> Helper loaded: string_helper
INFO - 2025-01-24 05:19:58 --> Helper loaded: form_helper
INFO - 2025-01-24 05:19:58 --> Helper loaded: my_helper
INFO - 2025-01-24 05:19:58 --> Database Driver Class Initialized
INFO - 2025-01-24 05:19:58 --> Upload Class Initialized
INFO - 2025-01-24 05:19:58 --> Email Class Initialized
INFO - 2025-01-24 05:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:19:58 --> Form Validation Class Initialized
INFO - 2025-01-24 05:19:58 --> Controller Class Initialized
INFO - 2025-01-24 10:49:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:49:58 --> Model "MainModel" initialized
INFO - 2025-01-24 10:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:49:58 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:03 --> Config Class Initialized
INFO - 2025-01-24 05:20:03 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:03 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:03 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:03 --> URI Class Initialized
INFO - 2025-01-24 05:20:03 --> Router Class Initialized
INFO - 2025-01-24 05:20:03 --> Output Class Initialized
INFO - 2025-01-24 05:20:03 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:03 --> Input Class Initialized
INFO - 2025-01-24 05:20:03 --> Language Class Initialized
INFO - 2025-01-24 05:20:03 --> Loader Class Initialized
INFO - 2025-01-24 05:20:03 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:03 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:03 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:03 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:03 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:03 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:03 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:03 --> Upload Class Initialized
INFO - 2025-01-24 05:20:03 --> Email Class Initialized
INFO - 2025-01-24 05:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:03 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:03 --> Controller Class Initialized
INFO - 2025-01-24 10:50:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:03 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:03 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:08 --> Config Class Initialized
INFO - 2025-01-24 05:20:08 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:08 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:08 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:08 --> URI Class Initialized
INFO - 2025-01-24 05:20:08 --> Router Class Initialized
INFO - 2025-01-24 05:20:08 --> Output Class Initialized
INFO - 2025-01-24 05:20:08 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:08 --> Input Class Initialized
INFO - 2025-01-24 05:20:08 --> Language Class Initialized
INFO - 2025-01-24 05:20:08 --> Loader Class Initialized
INFO - 2025-01-24 05:20:08 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:08 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:08 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:08 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:08 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:08 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:08 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:08 --> Upload Class Initialized
INFO - 2025-01-24 05:20:08 --> Email Class Initialized
INFO - 2025-01-24 05:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:08 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:08 --> Controller Class Initialized
INFO - 2025-01-24 10:50:08 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:08 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:08 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:13 --> Config Class Initialized
INFO - 2025-01-24 05:20:13 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:13 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:13 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:13 --> URI Class Initialized
INFO - 2025-01-24 05:20:13 --> Router Class Initialized
INFO - 2025-01-24 05:20:13 --> Output Class Initialized
INFO - 2025-01-24 05:20:13 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:13 --> Input Class Initialized
INFO - 2025-01-24 05:20:13 --> Language Class Initialized
INFO - 2025-01-24 05:20:13 --> Loader Class Initialized
INFO - 2025-01-24 05:20:13 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:13 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:13 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:13 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:13 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:13 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:13 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:13 --> Upload Class Initialized
INFO - 2025-01-24 05:20:13 --> Email Class Initialized
INFO - 2025-01-24 05:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:13 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:13 --> Controller Class Initialized
INFO - 2025-01-24 10:50:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:13 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:13 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:18 --> Config Class Initialized
INFO - 2025-01-24 05:20:18 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:18 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:18 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:18 --> URI Class Initialized
INFO - 2025-01-24 05:20:18 --> Router Class Initialized
INFO - 2025-01-24 05:20:18 --> Output Class Initialized
INFO - 2025-01-24 05:20:18 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:18 --> Input Class Initialized
INFO - 2025-01-24 05:20:18 --> Language Class Initialized
INFO - 2025-01-24 05:20:18 --> Loader Class Initialized
INFO - 2025-01-24 05:20:18 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:18 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:18 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:18 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:18 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:18 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:18 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:18 --> Upload Class Initialized
INFO - 2025-01-24 05:20:18 --> Email Class Initialized
INFO - 2025-01-24 05:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:18 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:18 --> Controller Class Initialized
INFO - 2025-01-24 10:50:18 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:18 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:18 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:23 --> Config Class Initialized
INFO - 2025-01-24 05:20:23 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:23 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:23 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:23 --> URI Class Initialized
INFO - 2025-01-24 05:20:23 --> Router Class Initialized
INFO - 2025-01-24 05:20:23 --> Output Class Initialized
INFO - 2025-01-24 05:20:23 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:23 --> Input Class Initialized
INFO - 2025-01-24 05:20:23 --> Language Class Initialized
INFO - 2025-01-24 05:20:23 --> Loader Class Initialized
INFO - 2025-01-24 05:20:23 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:23 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:23 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:23 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:23 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:23 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:23 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:23 --> Upload Class Initialized
INFO - 2025-01-24 05:20:23 --> Email Class Initialized
INFO - 2025-01-24 05:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:23 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:23 --> Controller Class Initialized
INFO - 2025-01-24 10:50:23 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:23 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:23 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:28 --> Config Class Initialized
INFO - 2025-01-24 05:20:28 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:28 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:28 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:28 --> URI Class Initialized
INFO - 2025-01-24 05:20:28 --> Router Class Initialized
INFO - 2025-01-24 05:20:28 --> Output Class Initialized
INFO - 2025-01-24 05:20:28 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:28 --> Input Class Initialized
INFO - 2025-01-24 05:20:28 --> Language Class Initialized
INFO - 2025-01-24 05:20:28 --> Loader Class Initialized
INFO - 2025-01-24 05:20:28 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:28 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:28 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:28 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:28 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:28 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:28 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:28 --> Upload Class Initialized
INFO - 2025-01-24 05:20:28 --> Email Class Initialized
INFO - 2025-01-24 05:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:28 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:28 --> Controller Class Initialized
INFO - 2025-01-24 10:50:28 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:28 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:28 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:33 --> Config Class Initialized
INFO - 2025-01-24 05:20:33 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:33 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:33 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:33 --> URI Class Initialized
INFO - 2025-01-24 05:20:33 --> Router Class Initialized
INFO - 2025-01-24 05:20:33 --> Output Class Initialized
INFO - 2025-01-24 05:20:33 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:33 --> Input Class Initialized
INFO - 2025-01-24 05:20:33 --> Language Class Initialized
INFO - 2025-01-24 05:20:33 --> Loader Class Initialized
INFO - 2025-01-24 05:20:33 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:33 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:33 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:33 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:33 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:33 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:33 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:33 --> Upload Class Initialized
INFO - 2025-01-24 05:20:33 --> Email Class Initialized
INFO - 2025-01-24 05:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:33 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:33 --> Controller Class Initialized
INFO - 2025-01-24 10:50:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:33 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:33 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:38 --> Config Class Initialized
INFO - 2025-01-24 05:20:38 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:38 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:38 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:38 --> URI Class Initialized
INFO - 2025-01-24 05:20:38 --> Router Class Initialized
INFO - 2025-01-24 05:20:38 --> Output Class Initialized
INFO - 2025-01-24 05:20:38 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:38 --> Input Class Initialized
INFO - 2025-01-24 05:20:38 --> Language Class Initialized
INFO - 2025-01-24 05:20:38 --> Loader Class Initialized
INFO - 2025-01-24 05:20:38 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:38 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:38 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:38 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:38 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:38 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:38 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:38 --> Upload Class Initialized
INFO - 2025-01-24 05:20:38 --> Email Class Initialized
INFO - 2025-01-24 05:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:38 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:38 --> Controller Class Initialized
INFO - 2025-01-24 10:50:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:38 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:38 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:43 --> Config Class Initialized
INFO - 2025-01-24 05:20:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:43 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:43 --> URI Class Initialized
INFO - 2025-01-24 05:20:43 --> Router Class Initialized
INFO - 2025-01-24 05:20:43 --> Output Class Initialized
INFO - 2025-01-24 05:20:43 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:43 --> Input Class Initialized
INFO - 2025-01-24 05:20:43 --> Language Class Initialized
INFO - 2025-01-24 05:20:43 --> Loader Class Initialized
INFO - 2025-01-24 05:20:43 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:43 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:43 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:43 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:43 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:43 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:43 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:43 --> Upload Class Initialized
INFO - 2025-01-24 05:20:43 --> Email Class Initialized
INFO - 2025-01-24 05:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:43 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:43 --> Controller Class Initialized
INFO - 2025-01-24 10:50:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:43 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:43 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:48 --> Config Class Initialized
INFO - 2025-01-24 05:20:48 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:48 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:48 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:48 --> URI Class Initialized
INFO - 2025-01-24 05:20:48 --> Router Class Initialized
INFO - 2025-01-24 05:20:48 --> Output Class Initialized
INFO - 2025-01-24 05:20:48 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:48 --> Input Class Initialized
INFO - 2025-01-24 05:20:48 --> Language Class Initialized
INFO - 2025-01-24 05:20:48 --> Loader Class Initialized
INFO - 2025-01-24 05:20:48 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:48 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:48 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:48 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:48 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:48 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:48 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:48 --> Upload Class Initialized
INFO - 2025-01-24 05:20:48 --> Email Class Initialized
INFO - 2025-01-24 05:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:48 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:48 --> Controller Class Initialized
INFO - 2025-01-24 10:50:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:48 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:48 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:53 --> Config Class Initialized
INFO - 2025-01-24 05:20:53 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:53 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:53 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:53 --> URI Class Initialized
INFO - 2025-01-24 05:20:53 --> Router Class Initialized
INFO - 2025-01-24 05:20:53 --> Output Class Initialized
INFO - 2025-01-24 05:20:53 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:53 --> Input Class Initialized
INFO - 2025-01-24 05:20:53 --> Language Class Initialized
INFO - 2025-01-24 05:20:53 --> Loader Class Initialized
INFO - 2025-01-24 05:20:53 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:53 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:53 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:53 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:53 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:53 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:53 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:53 --> Upload Class Initialized
INFO - 2025-01-24 05:20:53 --> Email Class Initialized
INFO - 2025-01-24 05:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:53 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:53 --> Controller Class Initialized
INFO - 2025-01-24 10:50:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:53 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:53 --> Pagination Class Initialized
INFO - 2025-01-24 05:20:58 --> Config Class Initialized
INFO - 2025-01-24 05:20:58 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:20:58 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:20:58 --> Utf8 Class Initialized
INFO - 2025-01-24 05:20:58 --> URI Class Initialized
INFO - 2025-01-24 05:20:58 --> Router Class Initialized
INFO - 2025-01-24 05:20:58 --> Output Class Initialized
INFO - 2025-01-24 05:20:58 --> Security Class Initialized
DEBUG - 2025-01-24 05:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:20:58 --> Input Class Initialized
INFO - 2025-01-24 05:20:58 --> Language Class Initialized
INFO - 2025-01-24 05:20:58 --> Loader Class Initialized
INFO - 2025-01-24 05:20:58 --> Helper loaded: url_helper
INFO - 2025-01-24 05:20:58 --> Helper loaded: html_helper
INFO - 2025-01-24 05:20:58 --> Helper loaded: file_helper
INFO - 2025-01-24 05:20:58 --> Helper loaded: string_helper
INFO - 2025-01-24 05:20:58 --> Helper loaded: form_helper
INFO - 2025-01-24 05:20:58 --> Helper loaded: my_helper
INFO - 2025-01-24 05:20:58 --> Database Driver Class Initialized
INFO - 2025-01-24 05:20:58 --> Upload Class Initialized
INFO - 2025-01-24 05:20:58 --> Email Class Initialized
INFO - 2025-01-24 05:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:20:58 --> Form Validation Class Initialized
INFO - 2025-01-24 05:20:58 --> Controller Class Initialized
INFO - 2025-01-24 10:50:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:50:58 --> Model "MainModel" initialized
INFO - 2025-01-24 10:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:50:58 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:03 --> Config Class Initialized
INFO - 2025-01-24 05:21:03 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:03 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:03 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:03 --> URI Class Initialized
INFO - 2025-01-24 05:21:03 --> Router Class Initialized
INFO - 2025-01-24 05:21:03 --> Output Class Initialized
INFO - 2025-01-24 05:21:03 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:03 --> Input Class Initialized
INFO - 2025-01-24 05:21:03 --> Language Class Initialized
INFO - 2025-01-24 05:21:03 --> Loader Class Initialized
INFO - 2025-01-24 05:21:03 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:03 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:03 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:03 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:03 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:03 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:03 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:03 --> Upload Class Initialized
INFO - 2025-01-24 05:21:03 --> Email Class Initialized
INFO - 2025-01-24 05:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:03 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:03 --> Controller Class Initialized
INFO - 2025-01-24 10:51:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:03 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:03 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:08 --> Config Class Initialized
INFO - 2025-01-24 05:21:08 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:08 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:08 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:08 --> URI Class Initialized
INFO - 2025-01-24 05:21:08 --> Router Class Initialized
INFO - 2025-01-24 05:21:08 --> Output Class Initialized
INFO - 2025-01-24 05:21:08 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:08 --> Input Class Initialized
INFO - 2025-01-24 05:21:08 --> Language Class Initialized
INFO - 2025-01-24 05:21:08 --> Loader Class Initialized
INFO - 2025-01-24 05:21:08 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:08 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:08 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:08 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:08 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:08 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:08 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:08 --> Upload Class Initialized
INFO - 2025-01-24 05:21:08 --> Email Class Initialized
INFO - 2025-01-24 05:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:08 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:08 --> Controller Class Initialized
INFO - 2025-01-24 10:51:08 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:08 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:08 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:13 --> Config Class Initialized
INFO - 2025-01-24 05:21:13 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:13 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:13 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:13 --> URI Class Initialized
INFO - 2025-01-24 05:21:13 --> Router Class Initialized
INFO - 2025-01-24 05:21:13 --> Output Class Initialized
INFO - 2025-01-24 05:21:13 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:13 --> Input Class Initialized
INFO - 2025-01-24 05:21:13 --> Language Class Initialized
INFO - 2025-01-24 05:21:13 --> Loader Class Initialized
INFO - 2025-01-24 05:21:13 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:13 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:13 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:13 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:13 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:13 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:13 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:13 --> Upload Class Initialized
INFO - 2025-01-24 05:21:13 --> Email Class Initialized
INFO - 2025-01-24 05:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:13 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:13 --> Controller Class Initialized
INFO - 2025-01-24 10:51:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:13 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:13 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:18 --> Config Class Initialized
INFO - 2025-01-24 05:21:18 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:18 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:18 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:18 --> URI Class Initialized
INFO - 2025-01-24 05:21:18 --> Router Class Initialized
INFO - 2025-01-24 05:21:18 --> Output Class Initialized
INFO - 2025-01-24 05:21:18 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:18 --> Input Class Initialized
INFO - 2025-01-24 05:21:18 --> Language Class Initialized
INFO - 2025-01-24 05:21:18 --> Loader Class Initialized
INFO - 2025-01-24 05:21:18 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:18 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:18 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:18 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:18 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:18 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:18 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:18 --> Upload Class Initialized
INFO - 2025-01-24 05:21:18 --> Email Class Initialized
INFO - 2025-01-24 05:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:18 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:18 --> Controller Class Initialized
INFO - 2025-01-24 10:51:18 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:18 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:18 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:23 --> Config Class Initialized
INFO - 2025-01-24 05:21:23 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:23 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:23 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:23 --> URI Class Initialized
INFO - 2025-01-24 05:21:23 --> Router Class Initialized
INFO - 2025-01-24 05:21:23 --> Output Class Initialized
INFO - 2025-01-24 05:21:23 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:23 --> Input Class Initialized
INFO - 2025-01-24 05:21:23 --> Language Class Initialized
INFO - 2025-01-24 05:21:23 --> Loader Class Initialized
INFO - 2025-01-24 05:21:23 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:23 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:23 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:23 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:23 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:23 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:23 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:23 --> Upload Class Initialized
INFO - 2025-01-24 05:21:23 --> Email Class Initialized
INFO - 2025-01-24 05:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:23 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:23 --> Controller Class Initialized
INFO - 2025-01-24 10:51:23 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:23 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:23 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:28 --> Config Class Initialized
INFO - 2025-01-24 05:21:28 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:28 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:28 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:28 --> URI Class Initialized
INFO - 2025-01-24 05:21:28 --> Router Class Initialized
INFO - 2025-01-24 05:21:28 --> Output Class Initialized
INFO - 2025-01-24 05:21:28 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:28 --> Input Class Initialized
INFO - 2025-01-24 05:21:28 --> Language Class Initialized
INFO - 2025-01-24 05:21:28 --> Loader Class Initialized
INFO - 2025-01-24 05:21:28 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:28 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:28 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:28 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:28 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:28 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:28 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:28 --> Upload Class Initialized
INFO - 2025-01-24 05:21:28 --> Email Class Initialized
INFO - 2025-01-24 05:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:28 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:28 --> Controller Class Initialized
INFO - 2025-01-24 10:51:28 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:28 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:28 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:33 --> Config Class Initialized
INFO - 2025-01-24 05:21:33 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:33 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:33 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:33 --> URI Class Initialized
INFO - 2025-01-24 05:21:33 --> Router Class Initialized
INFO - 2025-01-24 05:21:33 --> Output Class Initialized
INFO - 2025-01-24 05:21:33 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:33 --> Input Class Initialized
INFO - 2025-01-24 05:21:33 --> Language Class Initialized
INFO - 2025-01-24 05:21:33 --> Loader Class Initialized
INFO - 2025-01-24 05:21:33 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:33 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:33 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:33 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:33 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:33 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:33 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:33 --> Upload Class Initialized
INFO - 2025-01-24 05:21:33 --> Email Class Initialized
INFO - 2025-01-24 05:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:33 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:33 --> Controller Class Initialized
INFO - 2025-01-24 10:51:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:33 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:33 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:38 --> Config Class Initialized
INFO - 2025-01-24 05:21:38 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:38 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:38 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:38 --> URI Class Initialized
INFO - 2025-01-24 05:21:38 --> Router Class Initialized
INFO - 2025-01-24 05:21:38 --> Output Class Initialized
INFO - 2025-01-24 05:21:38 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:38 --> Input Class Initialized
INFO - 2025-01-24 05:21:38 --> Language Class Initialized
INFO - 2025-01-24 05:21:38 --> Loader Class Initialized
INFO - 2025-01-24 05:21:38 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:38 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:38 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:38 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:38 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:38 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:38 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:38 --> Upload Class Initialized
INFO - 2025-01-24 05:21:38 --> Email Class Initialized
INFO - 2025-01-24 05:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:38 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:38 --> Controller Class Initialized
INFO - 2025-01-24 10:51:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:38 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:38 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:43 --> Config Class Initialized
INFO - 2025-01-24 05:21:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:43 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:43 --> URI Class Initialized
INFO - 2025-01-24 05:21:43 --> Router Class Initialized
INFO - 2025-01-24 05:21:43 --> Output Class Initialized
INFO - 2025-01-24 05:21:43 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:43 --> Input Class Initialized
INFO - 2025-01-24 05:21:43 --> Language Class Initialized
INFO - 2025-01-24 05:21:43 --> Loader Class Initialized
INFO - 2025-01-24 05:21:43 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:43 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:43 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:43 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:43 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:43 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:43 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:43 --> Upload Class Initialized
INFO - 2025-01-24 05:21:43 --> Email Class Initialized
INFO - 2025-01-24 05:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:43 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:43 --> Controller Class Initialized
INFO - 2025-01-24 10:51:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:43 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:43 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:48 --> Config Class Initialized
INFO - 2025-01-24 05:21:48 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:48 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:48 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:48 --> URI Class Initialized
INFO - 2025-01-24 05:21:48 --> Router Class Initialized
INFO - 2025-01-24 05:21:48 --> Output Class Initialized
INFO - 2025-01-24 05:21:48 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:48 --> Input Class Initialized
INFO - 2025-01-24 05:21:48 --> Language Class Initialized
INFO - 2025-01-24 05:21:48 --> Loader Class Initialized
INFO - 2025-01-24 05:21:48 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:48 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:48 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:48 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:48 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:48 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:48 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:48 --> Upload Class Initialized
INFO - 2025-01-24 05:21:48 --> Email Class Initialized
INFO - 2025-01-24 05:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:48 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:48 --> Controller Class Initialized
INFO - 2025-01-24 10:51:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:48 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:48 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:53 --> Config Class Initialized
INFO - 2025-01-24 05:21:53 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:53 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:53 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:53 --> URI Class Initialized
INFO - 2025-01-24 05:21:53 --> Router Class Initialized
INFO - 2025-01-24 05:21:53 --> Output Class Initialized
INFO - 2025-01-24 05:21:53 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:53 --> Input Class Initialized
INFO - 2025-01-24 05:21:53 --> Language Class Initialized
INFO - 2025-01-24 05:21:53 --> Loader Class Initialized
INFO - 2025-01-24 05:21:53 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:53 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:53 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:53 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:53 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:53 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:53 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:53 --> Upload Class Initialized
INFO - 2025-01-24 05:21:53 --> Email Class Initialized
INFO - 2025-01-24 05:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:53 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:53 --> Controller Class Initialized
INFO - 2025-01-24 10:51:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:53 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:53 --> Pagination Class Initialized
INFO - 2025-01-24 05:21:58 --> Config Class Initialized
INFO - 2025-01-24 05:21:58 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:21:58 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:21:58 --> Utf8 Class Initialized
INFO - 2025-01-24 05:21:58 --> URI Class Initialized
INFO - 2025-01-24 05:21:58 --> Router Class Initialized
INFO - 2025-01-24 05:21:58 --> Output Class Initialized
INFO - 2025-01-24 05:21:58 --> Security Class Initialized
DEBUG - 2025-01-24 05:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:21:58 --> Input Class Initialized
INFO - 2025-01-24 05:21:58 --> Language Class Initialized
INFO - 2025-01-24 05:21:58 --> Loader Class Initialized
INFO - 2025-01-24 05:21:58 --> Helper loaded: url_helper
INFO - 2025-01-24 05:21:58 --> Helper loaded: html_helper
INFO - 2025-01-24 05:21:58 --> Helper loaded: file_helper
INFO - 2025-01-24 05:21:58 --> Helper loaded: string_helper
INFO - 2025-01-24 05:21:58 --> Helper loaded: form_helper
INFO - 2025-01-24 05:21:58 --> Helper loaded: my_helper
INFO - 2025-01-24 05:21:58 --> Database Driver Class Initialized
INFO - 2025-01-24 05:21:58 --> Upload Class Initialized
INFO - 2025-01-24 05:21:58 --> Email Class Initialized
INFO - 2025-01-24 05:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:21:58 --> Form Validation Class Initialized
INFO - 2025-01-24 05:21:58 --> Controller Class Initialized
INFO - 2025-01-24 10:51:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:51:58 --> Model "MainModel" initialized
INFO - 2025-01-24 10:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:51:58 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:03 --> Config Class Initialized
INFO - 2025-01-24 05:22:03 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:03 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:03 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:03 --> URI Class Initialized
INFO - 2025-01-24 05:22:03 --> Router Class Initialized
INFO - 2025-01-24 05:22:03 --> Output Class Initialized
INFO - 2025-01-24 05:22:03 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:03 --> Input Class Initialized
INFO - 2025-01-24 05:22:03 --> Language Class Initialized
INFO - 2025-01-24 05:22:03 --> Loader Class Initialized
INFO - 2025-01-24 05:22:03 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:03 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:03 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:03 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:03 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:03 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:03 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:03 --> Upload Class Initialized
INFO - 2025-01-24 05:22:03 --> Email Class Initialized
INFO - 2025-01-24 05:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:03 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:03 --> Controller Class Initialized
INFO - 2025-01-24 10:52:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:03 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:03 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:08 --> Config Class Initialized
INFO - 2025-01-24 05:22:08 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:08 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:08 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:08 --> URI Class Initialized
INFO - 2025-01-24 05:22:08 --> Router Class Initialized
INFO - 2025-01-24 05:22:08 --> Output Class Initialized
INFO - 2025-01-24 05:22:08 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:08 --> Input Class Initialized
INFO - 2025-01-24 05:22:08 --> Language Class Initialized
INFO - 2025-01-24 05:22:08 --> Loader Class Initialized
INFO - 2025-01-24 05:22:08 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:08 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:08 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:08 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:08 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:08 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:08 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:08 --> Upload Class Initialized
INFO - 2025-01-24 05:22:08 --> Email Class Initialized
INFO - 2025-01-24 05:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:08 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:08 --> Controller Class Initialized
INFO - 2025-01-24 10:52:08 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:08 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:08 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:13 --> Config Class Initialized
INFO - 2025-01-24 05:22:13 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:13 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:13 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:13 --> URI Class Initialized
INFO - 2025-01-24 05:22:13 --> Router Class Initialized
INFO - 2025-01-24 05:22:13 --> Output Class Initialized
INFO - 2025-01-24 05:22:13 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:13 --> Input Class Initialized
INFO - 2025-01-24 05:22:13 --> Language Class Initialized
INFO - 2025-01-24 05:22:13 --> Loader Class Initialized
INFO - 2025-01-24 05:22:13 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:13 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:13 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:13 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:13 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:13 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:13 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:13 --> Upload Class Initialized
INFO - 2025-01-24 05:22:13 --> Email Class Initialized
INFO - 2025-01-24 05:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:13 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:13 --> Controller Class Initialized
INFO - 2025-01-24 10:52:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:13 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:13 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:18 --> Config Class Initialized
INFO - 2025-01-24 05:22:18 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:18 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:18 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:18 --> URI Class Initialized
INFO - 2025-01-24 05:22:18 --> Router Class Initialized
INFO - 2025-01-24 05:22:18 --> Output Class Initialized
INFO - 2025-01-24 05:22:18 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:18 --> Input Class Initialized
INFO - 2025-01-24 05:22:18 --> Language Class Initialized
INFO - 2025-01-24 05:22:18 --> Loader Class Initialized
INFO - 2025-01-24 05:22:18 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:18 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:18 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:18 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:18 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:18 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:18 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:18 --> Upload Class Initialized
INFO - 2025-01-24 05:22:18 --> Email Class Initialized
INFO - 2025-01-24 05:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:18 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:18 --> Controller Class Initialized
INFO - 2025-01-24 10:52:18 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:18 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:18 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:23 --> Config Class Initialized
INFO - 2025-01-24 05:22:23 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:23 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:23 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:23 --> URI Class Initialized
INFO - 2025-01-24 05:22:23 --> Router Class Initialized
INFO - 2025-01-24 05:22:23 --> Output Class Initialized
INFO - 2025-01-24 05:22:23 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:23 --> Input Class Initialized
INFO - 2025-01-24 05:22:23 --> Language Class Initialized
INFO - 2025-01-24 05:22:23 --> Loader Class Initialized
INFO - 2025-01-24 05:22:23 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:23 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:23 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:23 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:23 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:23 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:23 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:23 --> Upload Class Initialized
INFO - 2025-01-24 05:22:23 --> Email Class Initialized
INFO - 2025-01-24 05:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:23 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:23 --> Controller Class Initialized
INFO - 2025-01-24 10:52:23 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:23 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:23 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:28 --> Config Class Initialized
INFO - 2025-01-24 05:22:28 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:28 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:28 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:28 --> URI Class Initialized
INFO - 2025-01-24 05:22:28 --> Router Class Initialized
INFO - 2025-01-24 05:22:28 --> Output Class Initialized
INFO - 2025-01-24 05:22:28 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:28 --> Input Class Initialized
INFO - 2025-01-24 05:22:28 --> Language Class Initialized
INFO - 2025-01-24 05:22:28 --> Loader Class Initialized
INFO - 2025-01-24 05:22:28 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:28 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:28 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:28 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:28 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:28 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:28 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:28 --> Upload Class Initialized
INFO - 2025-01-24 05:22:28 --> Email Class Initialized
INFO - 2025-01-24 05:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:28 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:28 --> Controller Class Initialized
INFO - 2025-01-24 10:52:28 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:28 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:28 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:33 --> Config Class Initialized
INFO - 2025-01-24 05:22:33 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:33 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:33 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:33 --> URI Class Initialized
INFO - 2025-01-24 05:22:33 --> Router Class Initialized
INFO - 2025-01-24 05:22:33 --> Output Class Initialized
INFO - 2025-01-24 05:22:33 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:33 --> Input Class Initialized
INFO - 2025-01-24 05:22:33 --> Language Class Initialized
INFO - 2025-01-24 05:22:33 --> Loader Class Initialized
INFO - 2025-01-24 05:22:33 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:33 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:33 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:33 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:33 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:33 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:33 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:33 --> Upload Class Initialized
INFO - 2025-01-24 05:22:33 --> Email Class Initialized
INFO - 2025-01-24 05:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:33 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:33 --> Controller Class Initialized
INFO - 2025-01-24 10:52:33 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:33 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:33 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:38 --> Config Class Initialized
INFO - 2025-01-24 05:22:38 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:38 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:38 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:38 --> URI Class Initialized
INFO - 2025-01-24 05:22:38 --> Router Class Initialized
INFO - 2025-01-24 05:22:38 --> Output Class Initialized
INFO - 2025-01-24 05:22:38 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:38 --> Input Class Initialized
INFO - 2025-01-24 05:22:38 --> Language Class Initialized
INFO - 2025-01-24 05:22:38 --> Loader Class Initialized
INFO - 2025-01-24 05:22:38 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:38 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:38 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:38 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:38 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:38 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:38 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:38 --> Upload Class Initialized
INFO - 2025-01-24 05:22:38 --> Email Class Initialized
INFO - 2025-01-24 05:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:38 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:38 --> Controller Class Initialized
INFO - 2025-01-24 10:52:38 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:38 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:38 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:43 --> Config Class Initialized
INFO - 2025-01-24 05:22:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:43 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:43 --> URI Class Initialized
INFO - 2025-01-24 05:22:43 --> Router Class Initialized
INFO - 2025-01-24 05:22:43 --> Output Class Initialized
INFO - 2025-01-24 05:22:43 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:43 --> Input Class Initialized
INFO - 2025-01-24 05:22:43 --> Language Class Initialized
INFO - 2025-01-24 05:22:43 --> Loader Class Initialized
INFO - 2025-01-24 05:22:43 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:43 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:43 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:43 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:43 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:43 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:43 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:43 --> Upload Class Initialized
INFO - 2025-01-24 05:22:43 --> Email Class Initialized
INFO - 2025-01-24 05:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:43 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:43 --> Controller Class Initialized
INFO - 2025-01-24 10:52:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:43 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:43 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:48 --> Config Class Initialized
INFO - 2025-01-24 05:22:48 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:48 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:48 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:48 --> URI Class Initialized
INFO - 2025-01-24 05:22:48 --> Router Class Initialized
INFO - 2025-01-24 05:22:48 --> Output Class Initialized
INFO - 2025-01-24 05:22:48 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:48 --> Input Class Initialized
INFO - 2025-01-24 05:22:48 --> Language Class Initialized
INFO - 2025-01-24 05:22:48 --> Loader Class Initialized
INFO - 2025-01-24 05:22:48 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:48 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:48 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:48 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:48 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:48 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:48 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:48 --> Upload Class Initialized
INFO - 2025-01-24 05:22:48 --> Email Class Initialized
INFO - 2025-01-24 05:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:48 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:48 --> Controller Class Initialized
INFO - 2025-01-24 10:52:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:48 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:48 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:53 --> Config Class Initialized
INFO - 2025-01-24 05:22:53 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:53 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:53 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:53 --> URI Class Initialized
INFO - 2025-01-24 05:22:53 --> Router Class Initialized
INFO - 2025-01-24 05:22:53 --> Output Class Initialized
INFO - 2025-01-24 05:22:53 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:53 --> Input Class Initialized
INFO - 2025-01-24 05:22:53 --> Language Class Initialized
INFO - 2025-01-24 05:22:53 --> Loader Class Initialized
INFO - 2025-01-24 05:22:53 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:53 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:53 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:53 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:53 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:53 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:53 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:53 --> Upload Class Initialized
INFO - 2025-01-24 05:22:53 --> Email Class Initialized
INFO - 2025-01-24 05:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:53 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:53 --> Controller Class Initialized
INFO - 2025-01-24 10:52:53 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:53 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:53 --> Pagination Class Initialized
INFO - 2025-01-24 05:22:58 --> Config Class Initialized
INFO - 2025-01-24 05:22:58 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:22:58 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:22:58 --> Utf8 Class Initialized
INFO - 2025-01-24 05:22:58 --> URI Class Initialized
INFO - 2025-01-24 05:22:58 --> Router Class Initialized
INFO - 2025-01-24 05:22:58 --> Output Class Initialized
INFO - 2025-01-24 05:22:58 --> Security Class Initialized
DEBUG - 2025-01-24 05:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:22:58 --> Input Class Initialized
INFO - 2025-01-24 05:22:58 --> Language Class Initialized
INFO - 2025-01-24 05:22:58 --> Loader Class Initialized
INFO - 2025-01-24 05:22:58 --> Helper loaded: url_helper
INFO - 2025-01-24 05:22:58 --> Helper loaded: html_helper
INFO - 2025-01-24 05:22:58 --> Helper loaded: file_helper
INFO - 2025-01-24 05:22:58 --> Helper loaded: string_helper
INFO - 2025-01-24 05:22:58 --> Helper loaded: form_helper
INFO - 2025-01-24 05:22:58 --> Helper loaded: my_helper
INFO - 2025-01-24 05:22:58 --> Database Driver Class Initialized
INFO - 2025-01-24 05:22:58 --> Upload Class Initialized
INFO - 2025-01-24 05:22:58 --> Email Class Initialized
INFO - 2025-01-24 05:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:22:58 --> Form Validation Class Initialized
INFO - 2025-01-24 05:22:58 --> Controller Class Initialized
INFO - 2025-01-24 10:52:58 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:52:58 --> Model "MainModel" initialized
INFO - 2025-01-24 10:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:52:58 --> Pagination Class Initialized
INFO - 2025-01-24 05:23:03 --> Config Class Initialized
INFO - 2025-01-24 05:23:03 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:23:03 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:23:03 --> Utf8 Class Initialized
INFO - 2025-01-24 05:23:03 --> URI Class Initialized
INFO - 2025-01-24 05:23:03 --> Router Class Initialized
INFO - 2025-01-24 05:23:03 --> Output Class Initialized
INFO - 2025-01-24 05:23:03 --> Security Class Initialized
DEBUG - 2025-01-24 05:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:23:03 --> Input Class Initialized
INFO - 2025-01-24 05:23:03 --> Language Class Initialized
INFO - 2025-01-24 05:23:03 --> Loader Class Initialized
INFO - 2025-01-24 05:23:03 --> Helper loaded: url_helper
INFO - 2025-01-24 05:23:03 --> Helper loaded: html_helper
INFO - 2025-01-24 05:23:03 --> Helper loaded: file_helper
INFO - 2025-01-24 05:23:03 --> Helper loaded: string_helper
INFO - 2025-01-24 05:23:03 --> Helper loaded: form_helper
INFO - 2025-01-24 05:23:03 --> Helper loaded: my_helper
INFO - 2025-01-24 05:23:03 --> Database Driver Class Initialized
INFO - 2025-01-24 05:23:03 --> Upload Class Initialized
INFO - 2025-01-24 05:23:03 --> Email Class Initialized
INFO - 2025-01-24 05:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:23:03 --> Form Validation Class Initialized
INFO - 2025-01-24 05:23:03 --> Controller Class Initialized
INFO - 2025-01-24 10:53:03 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:53:03 --> Model "MainModel" initialized
INFO - 2025-01-24 10:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:53:03 --> Pagination Class Initialized
INFO - 2025-01-24 05:23:08 --> Config Class Initialized
INFO - 2025-01-24 05:23:08 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:23:08 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:23:08 --> Utf8 Class Initialized
INFO - 2025-01-24 05:23:08 --> URI Class Initialized
INFO - 2025-01-24 05:23:08 --> Router Class Initialized
INFO - 2025-01-24 05:23:08 --> Output Class Initialized
INFO - 2025-01-24 05:23:08 --> Security Class Initialized
DEBUG - 2025-01-24 05:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:23:08 --> Input Class Initialized
INFO - 2025-01-24 05:23:08 --> Language Class Initialized
INFO - 2025-01-24 05:23:08 --> Loader Class Initialized
INFO - 2025-01-24 05:23:08 --> Helper loaded: url_helper
INFO - 2025-01-24 05:23:08 --> Helper loaded: html_helper
INFO - 2025-01-24 05:23:08 --> Helper loaded: file_helper
INFO - 2025-01-24 05:23:08 --> Helper loaded: string_helper
INFO - 2025-01-24 05:23:08 --> Helper loaded: form_helper
INFO - 2025-01-24 05:23:08 --> Helper loaded: my_helper
INFO - 2025-01-24 05:23:08 --> Database Driver Class Initialized
INFO - 2025-01-24 05:23:08 --> Upload Class Initialized
INFO - 2025-01-24 05:23:08 --> Email Class Initialized
INFO - 2025-01-24 05:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:23:08 --> Form Validation Class Initialized
INFO - 2025-01-24 05:23:08 --> Controller Class Initialized
INFO - 2025-01-24 10:53:08 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:53:08 --> Model "MainModel" initialized
INFO - 2025-01-24 10:53:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:53:08 --> Pagination Class Initialized
INFO - 2025-01-24 05:23:13 --> Config Class Initialized
INFO - 2025-01-24 05:23:13 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:23:13 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:23:13 --> Utf8 Class Initialized
INFO - 2025-01-24 05:23:13 --> URI Class Initialized
INFO - 2025-01-24 05:23:13 --> Router Class Initialized
INFO - 2025-01-24 05:23:13 --> Output Class Initialized
INFO - 2025-01-24 05:23:13 --> Security Class Initialized
DEBUG - 2025-01-24 05:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:23:13 --> Input Class Initialized
INFO - 2025-01-24 05:23:13 --> Language Class Initialized
INFO - 2025-01-24 05:23:13 --> Loader Class Initialized
INFO - 2025-01-24 05:23:13 --> Helper loaded: url_helper
INFO - 2025-01-24 05:23:13 --> Helper loaded: html_helper
INFO - 2025-01-24 05:23:13 --> Helper loaded: file_helper
INFO - 2025-01-24 05:23:13 --> Helper loaded: string_helper
INFO - 2025-01-24 05:23:13 --> Helper loaded: form_helper
INFO - 2025-01-24 05:23:13 --> Helper loaded: my_helper
INFO - 2025-01-24 05:23:13 --> Database Driver Class Initialized
INFO - 2025-01-24 05:23:13 --> Upload Class Initialized
INFO - 2025-01-24 05:23:13 --> Email Class Initialized
INFO - 2025-01-24 05:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:23:13 --> Form Validation Class Initialized
INFO - 2025-01-24 05:23:13 --> Controller Class Initialized
INFO - 2025-01-24 10:53:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:53:13 --> Model "MainModel" initialized
INFO - 2025-01-24 10:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:53:13 --> Pagination Class Initialized
INFO - 2025-01-24 05:23:18 --> Config Class Initialized
INFO - 2025-01-24 05:23:18 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:23:18 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:23:18 --> Utf8 Class Initialized
INFO - 2025-01-24 05:23:18 --> URI Class Initialized
INFO - 2025-01-24 05:23:18 --> Router Class Initialized
INFO - 2025-01-24 05:23:18 --> Output Class Initialized
INFO - 2025-01-24 05:23:18 --> Security Class Initialized
DEBUG - 2025-01-24 05:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:23:18 --> Input Class Initialized
INFO - 2025-01-24 05:23:18 --> Language Class Initialized
INFO - 2025-01-24 05:23:18 --> Loader Class Initialized
INFO - 2025-01-24 05:23:18 --> Helper loaded: url_helper
INFO - 2025-01-24 05:23:18 --> Helper loaded: html_helper
INFO - 2025-01-24 05:23:18 --> Helper loaded: file_helper
INFO - 2025-01-24 05:23:18 --> Helper loaded: string_helper
INFO - 2025-01-24 05:23:18 --> Helper loaded: form_helper
INFO - 2025-01-24 05:23:18 --> Helper loaded: my_helper
INFO - 2025-01-24 05:23:18 --> Database Driver Class Initialized
INFO - 2025-01-24 05:23:18 --> Upload Class Initialized
INFO - 2025-01-24 05:23:18 --> Email Class Initialized
INFO - 2025-01-24 05:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:23:18 --> Form Validation Class Initialized
INFO - 2025-01-24 05:23:18 --> Controller Class Initialized
INFO - 2025-01-24 10:53:18 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:53:18 --> Model "MainModel" initialized
INFO - 2025-01-24 10:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:53:18 --> Pagination Class Initialized
INFO - 2025-01-24 05:23:23 --> Config Class Initialized
INFO - 2025-01-24 05:23:23 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:23:23 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:23:23 --> Utf8 Class Initialized
INFO - 2025-01-24 05:23:23 --> URI Class Initialized
INFO - 2025-01-24 05:23:23 --> Router Class Initialized
INFO - 2025-01-24 05:23:23 --> Output Class Initialized
INFO - 2025-01-24 05:23:23 --> Security Class Initialized
DEBUG - 2025-01-24 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:23:23 --> Input Class Initialized
INFO - 2025-01-24 05:23:23 --> Language Class Initialized
INFO - 2025-01-24 05:23:23 --> Loader Class Initialized
INFO - 2025-01-24 05:23:23 --> Helper loaded: url_helper
INFO - 2025-01-24 05:23:23 --> Helper loaded: html_helper
INFO - 2025-01-24 05:23:23 --> Helper loaded: file_helper
INFO - 2025-01-24 05:23:23 --> Helper loaded: string_helper
INFO - 2025-01-24 05:23:23 --> Helper loaded: form_helper
INFO - 2025-01-24 05:23:23 --> Helper loaded: my_helper
INFO - 2025-01-24 05:23:23 --> Database Driver Class Initialized
INFO - 2025-01-24 05:23:23 --> Upload Class Initialized
INFO - 2025-01-24 05:23:23 --> Email Class Initialized
INFO - 2025-01-24 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:23:23 --> Form Validation Class Initialized
INFO - 2025-01-24 05:23:23 --> Controller Class Initialized
INFO - 2025-01-24 10:53:23 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:53:23 --> Model "MainModel" initialized
INFO - 2025-01-24 10:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:53:23 --> Pagination Class Initialized
INFO - 2025-01-24 05:23:28 --> Config Class Initialized
INFO - 2025-01-24 05:23:28 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:23:28 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:23:28 --> Utf8 Class Initialized
INFO - 2025-01-24 05:23:28 --> URI Class Initialized
INFO - 2025-01-24 05:23:28 --> Router Class Initialized
INFO - 2025-01-24 05:23:28 --> Output Class Initialized
INFO - 2025-01-24 05:23:28 --> Security Class Initialized
DEBUG - 2025-01-24 05:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:23:28 --> Input Class Initialized
INFO - 2025-01-24 05:23:28 --> Language Class Initialized
INFO - 2025-01-24 05:23:28 --> Loader Class Initialized
INFO - 2025-01-24 05:23:28 --> Helper loaded: url_helper
INFO - 2025-01-24 05:23:28 --> Helper loaded: html_helper
INFO - 2025-01-24 05:23:28 --> Helper loaded: file_helper
INFO - 2025-01-24 05:23:28 --> Helper loaded: string_helper
INFO - 2025-01-24 05:23:28 --> Helper loaded: form_helper
INFO - 2025-01-24 05:23:28 --> Helper loaded: my_helper
INFO - 2025-01-24 05:23:28 --> Database Driver Class Initialized
INFO - 2025-01-24 05:23:28 --> Upload Class Initialized
INFO - 2025-01-24 05:23:28 --> Email Class Initialized
INFO - 2025-01-24 05:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:23:28 --> Form Validation Class Initialized
INFO - 2025-01-24 05:23:28 --> Controller Class Initialized
INFO - 2025-01-24 10:53:28 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:53:28 --> Model "MainModel" initialized
INFO - 2025-01-24 10:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:53:28 --> Pagination Class Initialized
INFO - 2025-01-24 05:24:12 --> Config Class Initialized
INFO - 2025-01-24 05:24:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:24:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:24:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:24:12 --> URI Class Initialized
INFO - 2025-01-24 05:24:12 --> Router Class Initialized
INFO - 2025-01-24 05:24:12 --> Output Class Initialized
INFO - 2025-01-24 05:24:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:24:12 --> Input Class Initialized
INFO - 2025-01-24 05:24:12 --> Language Class Initialized
INFO - 2025-01-24 05:24:12 --> Loader Class Initialized
INFO - 2025-01-24 05:24:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:24:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:24:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:24:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:24:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:24:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:24:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:24:12 --> Upload Class Initialized
INFO - 2025-01-24 05:24:12 --> Email Class Initialized
INFO - 2025-01-24 05:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:24:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:24:12 --> Controller Class Initialized
INFO - 2025-01-24 10:54:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:54:12 --> Model "MainModel" initialized
INFO - 2025-01-24 10:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:54:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:25:12 --> Config Class Initialized
INFO - 2025-01-24 05:25:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:25:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:25:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:25:12 --> URI Class Initialized
INFO - 2025-01-24 05:25:12 --> Router Class Initialized
INFO - 2025-01-24 05:25:12 --> Output Class Initialized
INFO - 2025-01-24 05:25:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:25:12 --> Input Class Initialized
INFO - 2025-01-24 05:25:12 --> Language Class Initialized
INFO - 2025-01-24 05:25:12 --> Loader Class Initialized
INFO - 2025-01-24 05:25:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:25:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:25:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:25:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:25:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:25:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:25:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:25:12 --> Upload Class Initialized
INFO - 2025-01-24 05:25:12 --> Email Class Initialized
INFO - 2025-01-24 05:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:25:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:25:12 --> Controller Class Initialized
INFO - 2025-01-24 10:55:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:55:12 --> Model "MainModel" initialized
INFO - 2025-01-24 10:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:55:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:26:12 --> Config Class Initialized
INFO - 2025-01-24 05:26:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:26:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:26:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:26:12 --> URI Class Initialized
INFO - 2025-01-24 05:26:12 --> Router Class Initialized
INFO - 2025-01-24 05:26:12 --> Output Class Initialized
INFO - 2025-01-24 05:26:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:26:12 --> Input Class Initialized
INFO - 2025-01-24 05:26:12 --> Language Class Initialized
INFO - 2025-01-24 05:26:12 --> Loader Class Initialized
INFO - 2025-01-24 05:26:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:26:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:26:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:26:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:26:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:26:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:26:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:26:12 --> Upload Class Initialized
INFO - 2025-01-24 05:26:12 --> Email Class Initialized
INFO - 2025-01-24 05:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:26:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:26:12 --> Controller Class Initialized
INFO - 2025-01-24 10:56:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:56:12 --> Model "MainModel" initialized
INFO - 2025-01-24 10:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:56:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:27:12 --> Config Class Initialized
INFO - 2025-01-24 05:27:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:27:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:27:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:27:12 --> URI Class Initialized
INFO - 2025-01-24 05:27:12 --> Router Class Initialized
INFO - 2025-01-24 05:27:12 --> Output Class Initialized
INFO - 2025-01-24 05:27:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:27:12 --> Input Class Initialized
INFO - 2025-01-24 05:27:12 --> Language Class Initialized
INFO - 2025-01-24 05:27:12 --> Loader Class Initialized
INFO - 2025-01-24 05:27:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:27:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:27:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:27:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:27:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:27:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:27:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:27:12 --> Upload Class Initialized
INFO - 2025-01-24 05:27:12 --> Email Class Initialized
INFO - 2025-01-24 05:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:27:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:27:12 --> Controller Class Initialized
INFO - 2025-01-24 10:57:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:57:12 --> Model "MainModel" initialized
INFO - 2025-01-24 10:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:57:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:28:12 --> Config Class Initialized
INFO - 2025-01-24 05:28:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:28:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:28:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:28:12 --> URI Class Initialized
INFO - 2025-01-24 05:28:12 --> Router Class Initialized
INFO - 2025-01-24 05:28:12 --> Output Class Initialized
INFO - 2025-01-24 05:28:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:28:12 --> Input Class Initialized
INFO - 2025-01-24 05:28:12 --> Language Class Initialized
INFO - 2025-01-24 05:28:12 --> Loader Class Initialized
INFO - 2025-01-24 05:28:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:28:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:28:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:28:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:28:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:28:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:28:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:28:12 --> Upload Class Initialized
INFO - 2025-01-24 05:28:12 --> Email Class Initialized
INFO - 2025-01-24 05:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:28:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:28:12 --> Controller Class Initialized
INFO - 2025-01-24 10:58:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:58:12 --> Model "MainModel" initialized
INFO - 2025-01-24 10:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:58:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:29:12 --> Config Class Initialized
INFO - 2025-01-24 05:29:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:29:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:29:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:29:12 --> URI Class Initialized
INFO - 2025-01-24 05:29:12 --> Router Class Initialized
INFO - 2025-01-24 05:29:12 --> Output Class Initialized
INFO - 2025-01-24 05:29:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:29:12 --> Input Class Initialized
INFO - 2025-01-24 05:29:12 --> Language Class Initialized
INFO - 2025-01-24 05:29:12 --> Loader Class Initialized
INFO - 2025-01-24 05:29:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:29:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:29:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:29:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:29:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:29:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:29:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:29:12 --> Upload Class Initialized
INFO - 2025-01-24 05:29:12 --> Email Class Initialized
INFO - 2025-01-24 05:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:29:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:29:12 --> Controller Class Initialized
INFO - 2025-01-24 10:59:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 10:59:12 --> Model "MainModel" initialized
INFO - 2025-01-24 10:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 10:59:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:30:12 --> Config Class Initialized
INFO - 2025-01-24 05:30:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:30:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:30:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:30:12 --> URI Class Initialized
INFO - 2025-01-24 05:30:12 --> Router Class Initialized
INFO - 2025-01-24 05:30:12 --> Output Class Initialized
INFO - 2025-01-24 05:30:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:30:12 --> Input Class Initialized
INFO - 2025-01-24 05:30:12 --> Language Class Initialized
INFO - 2025-01-24 05:30:12 --> Loader Class Initialized
INFO - 2025-01-24 05:30:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:30:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:30:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:30:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:30:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:30:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:30:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:30:12 --> Upload Class Initialized
INFO - 2025-01-24 05:30:12 --> Email Class Initialized
INFO - 2025-01-24 05:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:30:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:30:12 --> Controller Class Initialized
INFO - 2025-01-24 11:00:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:00:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:00:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:31:12 --> Config Class Initialized
INFO - 2025-01-24 05:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:31:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:31:12 --> URI Class Initialized
INFO - 2025-01-24 05:31:12 --> Router Class Initialized
INFO - 2025-01-24 05:31:12 --> Output Class Initialized
INFO - 2025-01-24 05:31:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:31:12 --> Input Class Initialized
INFO - 2025-01-24 05:31:12 --> Language Class Initialized
INFO - 2025-01-24 05:31:12 --> Loader Class Initialized
INFO - 2025-01-24 05:31:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:31:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:31:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:31:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:31:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:31:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:31:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:31:12 --> Upload Class Initialized
INFO - 2025-01-24 05:31:12 --> Email Class Initialized
INFO - 2025-01-24 05:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:31:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:31:12 --> Controller Class Initialized
INFO - 2025-01-24 11:01:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:01:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:01:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:32:12 --> Config Class Initialized
INFO - 2025-01-24 05:32:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:32:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:32:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:32:12 --> URI Class Initialized
INFO - 2025-01-24 05:32:12 --> Router Class Initialized
INFO - 2025-01-24 05:32:12 --> Output Class Initialized
INFO - 2025-01-24 05:32:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:32:12 --> Input Class Initialized
INFO - 2025-01-24 05:32:12 --> Language Class Initialized
INFO - 2025-01-24 05:32:12 --> Loader Class Initialized
INFO - 2025-01-24 05:32:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:32:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:32:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:32:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:32:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:32:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:32:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:32:12 --> Upload Class Initialized
INFO - 2025-01-24 05:32:12 --> Email Class Initialized
INFO - 2025-01-24 05:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:32:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:32:12 --> Controller Class Initialized
INFO - 2025-01-24 11:02:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:02:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:02:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:33:12 --> Config Class Initialized
INFO - 2025-01-24 05:33:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:33:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:33:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:33:12 --> URI Class Initialized
INFO - 2025-01-24 05:33:12 --> Router Class Initialized
INFO - 2025-01-24 05:33:12 --> Output Class Initialized
INFO - 2025-01-24 05:33:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:33:12 --> Input Class Initialized
INFO - 2025-01-24 05:33:12 --> Language Class Initialized
INFO - 2025-01-24 05:33:12 --> Loader Class Initialized
INFO - 2025-01-24 05:33:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:33:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:33:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:33:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:33:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:33:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:33:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:33:12 --> Upload Class Initialized
INFO - 2025-01-24 05:33:12 --> Email Class Initialized
INFO - 2025-01-24 05:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:33:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:33:12 --> Controller Class Initialized
INFO - 2025-01-24 11:03:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:03:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:03:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:34:12 --> Config Class Initialized
INFO - 2025-01-24 05:34:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:34:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:34:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:34:12 --> URI Class Initialized
INFO - 2025-01-24 05:34:12 --> Router Class Initialized
INFO - 2025-01-24 05:34:12 --> Output Class Initialized
INFO - 2025-01-24 05:34:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:34:12 --> Input Class Initialized
INFO - 2025-01-24 05:34:12 --> Language Class Initialized
INFO - 2025-01-24 05:34:12 --> Loader Class Initialized
INFO - 2025-01-24 05:34:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:34:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:34:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:34:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:34:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:34:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:34:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:34:12 --> Upload Class Initialized
INFO - 2025-01-24 05:34:12 --> Email Class Initialized
INFO - 2025-01-24 05:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:34:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:34:12 --> Controller Class Initialized
INFO - 2025-01-24 11:04:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:04:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:04:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:35:12 --> Config Class Initialized
INFO - 2025-01-24 05:35:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:35:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:35:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:35:12 --> URI Class Initialized
INFO - 2025-01-24 05:35:12 --> Router Class Initialized
INFO - 2025-01-24 05:35:12 --> Output Class Initialized
INFO - 2025-01-24 05:35:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:35:12 --> Input Class Initialized
INFO - 2025-01-24 05:35:12 --> Language Class Initialized
INFO - 2025-01-24 05:35:12 --> Loader Class Initialized
INFO - 2025-01-24 05:35:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:35:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:35:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:35:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:35:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:35:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:35:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:35:12 --> Upload Class Initialized
INFO - 2025-01-24 05:35:12 --> Email Class Initialized
INFO - 2025-01-24 05:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:35:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:35:12 --> Controller Class Initialized
INFO - 2025-01-24 11:05:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:05:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:05:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:36:12 --> Config Class Initialized
INFO - 2025-01-24 05:36:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:36:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:36:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:36:12 --> URI Class Initialized
INFO - 2025-01-24 05:36:12 --> Router Class Initialized
INFO - 2025-01-24 05:36:12 --> Output Class Initialized
INFO - 2025-01-24 05:36:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:36:12 --> Input Class Initialized
INFO - 2025-01-24 05:36:12 --> Language Class Initialized
INFO - 2025-01-24 05:36:12 --> Loader Class Initialized
INFO - 2025-01-24 05:36:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:36:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:36:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:36:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:36:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:36:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:36:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:36:12 --> Upload Class Initialized
INFO - 2025-01-24 05:36:12 --> Email Class Initialized
INFO - 2025-01-24 05:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:36:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:36:12 --> Controller Class Initialized
INFO - 2025-01-24 11:06:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:06:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:06:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:37:12 --> Config Class Initialized
INFO - 2025-01-24 05:37:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:37:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:37:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:37:12 --> URI Class Initialized
INFO - 2025-01-24 05:37:12 --> Router Class Initialized
INFO - 2025-01-24 05:37:12 --> Output Class Initialized
INFO - 2025-01-24 05:37:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:37:12 --> Input Class Initialized
INFO - 2025-01-24 05:37:12 --> Language Class Initialized
INFO - 2025-01-24 05:37:12 --> Loader Class Initialized
INFO - 2025-01-24 05:37:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:37:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:37:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:37:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:37:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:37:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:37:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:37:12 --> Upload Class Initialized
INFO - 2025-01-24 05:37:12 --> Email Class Initialized
INFO - 2025-01-24 05:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:37:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:37:12 --> Controller Class Initialized
INFO - 2025-01-24 11:07:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:07:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:07:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:38:12 --> Config Class Initialized
INFO - 2025-01-24 05:38:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:38:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:38:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:38:12 --> URI Class Initialized
INFO - 2025-01-24 05:38:12 --> Router Class Initialized
INFO - 2025-01-24 05:38:12 --> Output Class Initialized
INFO - 2025-01-24 05:38:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:38:12 --> Input Class Initialized
INFO - 2025-01-24 05:38:12 --> Language Class Initialized
INFO - 2025-01-24 05:38:12 --> Loader Class Initialized
INFO - 2025-01-24 05:38:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:38:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:38:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:38:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:38:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:38:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:38:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:38:12 --> Upload Class Initialized
INFO - 2025-01-24 05:38:12 --> Email Class Initialized
INFO - 2025-01-24 05:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:38:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:38:12 --> Controller Class Initialized
INFO - 2025-01-24 11:08:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:08:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:08:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:39:12 --> Config Class Initialized
INFO - 2025-01-24 05:39:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:39:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:39:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:39:12 --> URI Class Initialized
INFO - 2025-01-24 05:39:12 --> Router Class Initialized
INFO - 2025-01-24 05:39:12 --> Output Class Initialized
INFO - 2025-01-24 05:39:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:39:12 --> Input Class Initialized
INFO - 2025-01-24 05:39:12 --> Language Class Initialized
INFO - 2025-01-24 05:39:12 --> Loader Class Initialized
INFO - 2025-01-24 05:39:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:39:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:39:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:39:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:39:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:39:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:39:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:39:12 --> Upload Class Initialized
INFO - 2025-01-24 05:39:12 --> Email Class Initialized
INFO - 2025-01-24 05:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:39:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:39:12 --> Controller Class Initialized
INFO - 2025-01-24 11:09:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:09:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:09:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:40:12 --> Config Class Initialized
INFO - 2025-01-24 05:40:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:40:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:40:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:40:12 --> URI Class Initialized
INFO - 2025-01-24 05:40:12 --> Router Class Initialized
INFO - 2025-01-24 05:40:12 --> Output Class Initialized
INFO - 2025-01-24 05:40:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:40:12 --> Input Class Initialized
INFO - 2025-01-24 05:40:12 --> Language Class Initialized
INFO - 2025-01-24 05:40:12 --> Loader Class Initialized
INFO - 2025-01-24 05:40:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:40:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:40:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:40:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:40:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:40:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:40:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:40:12 --> Upload Class Initialized
INFO - 2025-01-24 05:40:12 --> Email Class Initialized
INFO - 2025-01-24 05:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:40:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:40:12 --> Controller Class Initialized
INFO - 2025-01-24 11:10:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:10:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:10:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:41:12 --> Config Class Initialized
INFO - 2025-01-24 05:41:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:41:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:41:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:41:12 --> URI Class Initialized
INFO - 2025-01-24 05:41:12 --> Router Class Initialized
INFO - 2025-01-24 05:41:12 --> Output Class Initialized
INFO - 2025-01-24 05:41:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:41:12 --> Input Class Initialized
INFO - 2025-01-24 05:41:12 --> Language Class Initialized
INFO - 2025-01-24 05:41:12 --> Loader Class Initialized
INFO - 2025-01-24 05:41:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:41:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:41:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:41:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:41:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:41:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:41:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:41:12 --> Upload Class Initialized
INFO - 2025-01-24 05:41:12 --> Email Class Initialized
INFO - 2025-01-24 05:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:41:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:41:12 --> Controller Class Initialized
INFO - 2025-01-24 11:11:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:11:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:11:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:42:12 --> Config Class Initialized
INFO - 2025-01-24 05:42:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:42:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:42:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:42:12 --> URI Class Initialized
INFO - 2025-01-24 05:42:12 --> Router Class Initialized
INFO - 2025-01-24 05:42:12 --> Output Class Initialized
INFO - 2025-01-24 05:42:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:42:12 --> Input Class Initialized
INFO - 2025-01-24 05:42:12 --> Language Class Initialized
INFO - 2025-01-24 05:42:12 --> Loader Class Initialized
INFO - 2025-01-24 05:42:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:42:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:42:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:42:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:42:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:42:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:42:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:42:12 --> Upload Class Initialized
INFO - 2025-01-24 05:42:12 --> Email Class Initialized
INFO - 2025-01-24 05:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:42:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:42:12 --> Controller Class Initialized
INFO - 2025-01-24 11:12:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:12:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:12:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:43:12 --> Config Class Initialized
INFO - 2025-01-24 05:43:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:43:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:43:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:43:12 --> URI Class Initialized
INFO - 2025-01-24 05:43:12 --> Router Class Initialized
INFO - 2025-01-24 05:43:12 --> Output Class Initialized
INFO - 2025-01-24 05:43:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:43:12 --> Input Class Initialized
INFO - 2025-01-24 05:43:12 --> Language Class Initialized
INFO - 2025-01-24 05:43:12 --> Loader Class Initialized
INFO - 2025-01-24 05:43:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:43:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:43:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:43:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:43:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:43:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:43:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:43:12 --> Upload Class Initialized
INFO - 2025-01-24 05:43:12 --> Email Class Initialized
INFO - 2025-01-24 05:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:43:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:43:12 --> Controller Class Initialized
INFO - 2025-01-24 11:13:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:13:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:13:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:44:12 --> Config Class Initialized
INFO - 2025-01-24 05:44:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:44:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:44:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:44:12 --> URI Class Initialized
INFO - 2025-01-24 05:44:12 --> Router Class Initialized
INFO - 2025-01-24 05:44:12 --> Output Class Initialized
INFO - 2025-01-24 05:44:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:44:12 --> Input Class Initialized
INFO - 2025-01-24 05:44:12 --> Language Class Initialized
INFO - 2025-01-24 05:44:12 --> Loader Class Initialized
INFO - 2025-01-24 05:44:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:44:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:44:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:44:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:44:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:44:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:44:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:44:12 --> Upload Class Initialized
INFO - 2025-01-24 05:44:12 --> Email Class Initialized
INFO - 2025-01-24 05:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:44:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:44:12 --> Controller Class Initialized
INFO - 2025-01-24 11:14:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:14:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:14:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:45:12 --> Config Class Initialized
INFO - 2025-01-24 05:45:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:45:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:45:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:45:12 --> URI Class Initialized
INFO - 2025-01-24 05:45:12 --> Router Class Initialized
INFO - 2025-01-24 05:45:12 --> Output Class Initialized
INFO - 2025-01-24 05:45:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:45:12 --> Input Class Initialized
INFO - 2025-01-24 05:45:12 --> Language Class Initialized
INFO - 2025-01-24 05:45:12 --> Loader Class Initialized
INFO - 2025-01-24 05:45:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:45:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:45:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:45:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:45:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:45:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:45:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:45:12 --> Upload Class Initialized
INFO - 2025-01-24 05:45:12 --> Email Class Initialized
INFO - 2025-01-24 05:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:45:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:45:12 --> Controller Class Initialized
INFO - 2025-01-24 11:15:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:15:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:15:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:46:12 --> Config Class Initialized
INFO - 2025-01-24 05:46:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:46:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:46:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:46:12 --> URI Class Initialized
INFO - 2025-01-24 05:46:12 --> Router Class Initialized
INFO - 2025-01-24 05:46:12 --> Output Class Initialized
INFO - 2025-01-24 05:46:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:46:12 --> Input Class Initialized
INFO - 2025-01-24 05:46:12 --> Language Class Initialized
INFO - 2025-01-24 05:46:12 --> Loader Class Initialized
INFO - 2025-01-24 05:46:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:46:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:46:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:46:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:46:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:46:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:46:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:46:12 --> Upload Class Initialized
INFO - 2025-01-24 05:46:12 --> Email Class Initialized
INFO - 2025-01-24 05:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:46:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:46:12 --> Controller Class Initialized
INFO - 2025-01-24 11:16:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:16:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:16:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:47:12 --> Config Class Initialized
INFO - 2025-01-24 05:47:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:47:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:47:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:47:12 --> URI Class Initialized
INFO - 2025-01-24 05:47:12 --> Router Class Initialized
INFO - 2025-01-24 05:47:12 --> Output Class Initialized
INFO - 2025-01-24 05:47:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:47:12 --> Input Class Initialized
INFO - 2025-01-24 05:47:12 --> Language Class Initialized
INFO - 2025-01-24 05:47:12 --> Loader Class Initialized
INFO - 2025-01-24 05:47:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:47:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:47:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:47:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:47:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:47:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:47:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:47:12 --> Upload Class Initialized
INFO - 2025-01-24 05:47:12 --> Email Class Initialized
INFO - 2025-01-24 05:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:47:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:47:12 --> Controller Class Initialized
INFO - 2025-01-24 11:17:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:17:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:17:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:48:12 --> Config Class Initialized
INFO - 2025-01-24 05:48:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:48:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:48:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:48:12 --> URI Class Initialized
INFO - 2025-01-24 05:48:12 --> Router Class Initialized
INFO - 2025-01-24 05:48:12 --> Output Class Initialized
INFO - 2025-01-24 05:48:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:48:12 --> Input Class Initialized
INFO - 2025-01-24 05:48:12 --> Language Class Initialized
INFO - 2025-01-24 05:48:12 --> Loader Class Initialized
INFO - 2025-01-24 05:48:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:48:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:48:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:48:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:48:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:48:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:48:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:48:12 --> Upload Class Initialized
INFO - 2025-01-24 05:48:12 --> Email Class Initialized
INFO - 2025-01-24 05:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:48:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:48:12 --> Controller Class Initialized
INFO - 2025-01-24 11:18:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:18:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:18:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:49:12 --> Config Class Initialized
INFO - 2025-01-24 05:49:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:49:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:49:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:49:12 --> URI Class Initialized
INFO - 2025-01-24 05:49:12 --> Router Class Initialized
INFO - 2025-01-24 05:49:12 --> Output Class Initialized
INFO - 2025-01-24 05:49:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:49:12 --> Input Class Initialized
INFO - 2025-01-24 05:49:12 --> Language Class Initialized
INFO - 2025-01-24 05:49:12 --> Loader Class Initialized
INFO - 2025-01-24 05:49:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:49:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:49:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:49:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:49:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:49:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:49:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:49:12 --> Upload Class Initialized
INFO - 2025-01-24 05:49:12 --> Email Class Initialized
INFO - 2025-01-24 05:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:49:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:49:12 --> Controller Class Initialized
INFO - 2025-01-24 11:19:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:19:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:19:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:50:12 --> Config Class Initialized
INFO - 2025-01-24 05:50:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:50:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:50:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:50:12 --> URI Class Initialized
INFO - 2025-01-24 05:50:12 --> Router Class Initialized
INFO - 2025-01-24 05:50:12 --> Output Class Initialized
INFO - 2025-01-24 05:50:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:50:12 --> Input Class Initialized
INFO - 2025-01-24 05:50:12 --> Language Class Initialized
INFO - 2025-01-24 05:50:12 --> Loader Class Initialized
INFO - 2025-01-24 05:50:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:50:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:50:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:50:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:50:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:50:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:50:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:50:12 --> Upload Class Initialized
INFO - 2025-01-24 05:50:12 --> Email Class Initialized
INFO - 2025-01-24 05:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:50:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:50:12 --> Controller Class Initialized
INFO - 2025-01-24 11:20:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:20:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:20:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:51:12 --> Config Class Initialized
INFO - 2025-01-24 05:51:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:51:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:51:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:51:12 --> URI Class Initialized
INFO - 2025-01-24 05:51:12 --> Router Class Initialized
INFO - 2025-01-24 05:51:12 --> Output Class Initialized
INFO - 2025-01-24 05:51:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:51:12 --> Input Class Initialized
INFO - 2025-01-24 05:51:12 --> Language Class Initialized
INFO - 2025-01-24 05:51:12 --> Loader Class Initialized
INFO - 2025-01-24 05:51:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:51:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:51:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:51:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:51:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:51:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:51:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:51:12 --> Upload Class Initialized
INFO - 2025-01-24 05:51:12 --> Email Class Initialized
INFO - 2025-01-24 05:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:51:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:51:12 --> Controller Class Initialized
INFO - 2025-01-24 11:21:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:21:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:21:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:52:12 --> Config Class Initialized
INFO - 2025-01-24 05:52:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:52:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:52:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:52:12 --> URI Class Initialized
INFO - 2025-01-24 05:52:12 --> Router Class Initialized
INFO - 2025-01-24 05:52:12 --> Output Class Initialized
INFO - 2025-01-24 05:52:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:52:12 --> Input Class Initialized
INFO - 2025-01-24 05:52:12 --> Language Class Initialized
INFO - 2025-01-24 05:52:12 --> Loader Class Initialized
INFO - 2025-01-24 05:52:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:52:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:52:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:52:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:52:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:52:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:52:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:52:12 --> Upload Class Initialized
INFO - 2025-01-24 05:52:12 --> Email Class Initialized
INFO - 2025-01-24 05:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:52:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:52:12 --> Controller Class Initialized
INFO - 2025-01-24 11:22:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:22:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:22:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:53:12 --> Config Class Initialized
INFO - 2025-01-24 05:53:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:53:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:53:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:53:12 --> URI Class Initialized
INFO - 2025-01-24 05:53:12 --> Router Class Initialized
INFO - 2025-01-24 05:53:12 --> Output Class Initialized
INFO - 2025-01-24 05:53:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:53:12 --> Input Class Initialized
INFO - 2025-01-24 05:53:12 --> Language Class Initialized
INFO - 2025-01-24 05:53:12 --> Loader Class Initialized
INFO - 2025-01-24 05:53:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:53:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:53:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:53:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:53:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:53:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:53:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:53:12 --> Upload Class Initialized
INFO - 2025-01-24 05:53:12 --> Email Class Initialized
INFO - 2025-01-24 05:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:53:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:53:12 --> Controller Class Initialized
INFO - 2025-01-24 11:23:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:23:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:23:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:54:12 --> Config Class Initialized
INFO - 2025-01-24 05:54:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:54:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:54:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:54:12 --> URI Class Initialized
INFO - 2025-01-24 05:54:12 --> Router Class Initialized
INFO - 2025-01-24 05:54:12 --> Output Class Initialized
INFO - 2025-01-24 05:54:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:54:12 --> Input Class Initialized
INFO - 2025-01-24 05:54:12 --> Language Class Initialized
INFO - 2025-01-24 05:54:12 --> Loader Class Initialized
INFO - 2025-01-24 05:54:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:54:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:54:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:54:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:54:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:54:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:54:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:54:12 --> Upload Class Initialized
INFO - 2025-01-24 05:54:12 --> Email Class Initialized
INFO - 2025-01-24 05:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:54:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:54:12 --> Controller Class Initialized
INFO - 2025-01-24 11:24:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:24:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:24:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:55:12 --> Config Class Initialized
INFO - 2025-01-24 05:55:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:55:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:55:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:55:12 --> URI Class Initialized
INFO - 2025-01-24 05:55:12 --> Router Class Initialized
INFO - 2025-01-24 05:55:12 --> Output Class Initialized
INFO - 2025-01-24 05:55:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:55:12 --> Input Class Initialized
INFO - 2025-01-24 05:55:12 --> Language Class Initialized
INFO - 2025-01-24 05:55:12 --> Loader Class Initialized
INFO - 2025-01-24 05:55:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:55:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:55:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:55:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:55:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:55:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:55:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:55:12 --> Upload Class Initialized
INFO - 2025-01-24 05:55:12 --> Email Class Initialized
INFO - 2025-01-24 05:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:55:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:55:12 --> Controller Class Initialized
INFO - 2025-01-24 11:25:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:25:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:25:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:56:12 --> Config Class Initialized
INFO - 2025-01-24 05:56:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:56:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:56:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:56:12 --> URI Class Initialized
INFO - 2025-01-24 05:56:12 --> Router Class Initialized
INFO - 2025-01-24 05:56:12 --> Output Class Initialized
INFO - 2025-01-24 05:56:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:56:12 --> Input Class Initialized
INFO - 2025-01-24 05:56:12 --> Language Class Initialized
INFO - 2025-01-24 05:56:12 --> Loader Class Initialized
INFO - 2025-01-24 05:56:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:56:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:56:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:56:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:56:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:56:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:56:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:56:12 --> Upload Class Initialized
INFO - 2025-01-24 05:56:12 --> Email Class Initialized
INFO - 2025-01-24 05:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:56:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:56:12 --> Controller Class Initialized
INFO - 2025-01-24 11:26:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:26:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:26:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:57:12 --> Config Class Initialized
INFO - 2025-01-24 05:57:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:57:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:57:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:57:12 --> URI Class Initialized
INFO - 2025-01-24 05:57:12 --> Router Class Initialized
INFO - 2025-01-24 05:57:12 --> Output Class Initialized
INFO - 2025-01-24 05:57:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:57:12 --> Input Class Initialized
INFO - 2025-01-24 05:57:12 --> Language Class Initialized
INFO - 2025-01-24 05:57:12 --> Loader Class Initialized
INFO - 2025-01-24 05:57:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:57:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:57:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:57:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:57:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:57:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:57:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:57:12 --> Upload Class Initialized
INFO - 2025-01-24 05:57:12 --> Email Class Initialized
INFO - 2025-01-24 05:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:57:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:57:12 --> Controller Class Initialized
INFO - 2025-01-24 11:27:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:27:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:27:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:58:12 --> Config Class Initialized
INFO - 2025-01-24 05:58:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:58:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:58:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:58:12 --> URI Class Initialized
INFO - 2025-01-24 05:58:12 --> Router Class Initialized
INFO - 2025-01-24 05:58:12 --> Output Class Initialized
INFO - 2025-01-24 05:58:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:58:12 --> Input Class Initialized
INFO - 2025-01-24 05:58:12 --> Language Class Initialized
INFO - 2025-01-24 05:58:12 --> Loader Class Initialized
INFO - 2025-01-24 05:58:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:58:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:58:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:58:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:58:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:58:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:58:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:58:12 --> Upload Class Initialized
INFO - 2025-01-24 05:58:12 --> Email Class Initialized
INFO - 2025-01-24 05:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:58:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:58:12 --> Controller Class Initialized
INFO - 2025-01-24 11:28:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:28:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:28:12 --> Pagination Class Initialized
INFO - 2025-01-24 05:59:12 --> Config Class Initialized
INFO - 2025-01-24 05:59:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 05:59:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 05:59:12 --> Utf8 Class Initialized
INFO - 2025-01-24 05:59:12 --> URI Class Initialized
INFO - 2025-01-24 05:59:12 --> Router Class Initialized
INFO - 2025-01-24 05:59:12 --> Output Class Initialized
INFO - 2025-01-24 05:59:12 --> Security Class Initialized
DEBUG - 2025-01-24 05:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 05:59:12 --> Input Class Initialized
INFO - 2025-01-24 05:59:12 --> Language Class Initialized
INFO - 2025-01-24 05:59:12 --> Loader Class Initialized
INFO - 2025-01-24 05:59:12 --> Helper loaded: url_helper
INFO - 2025-01-24 05:59:12 --> Helper loaded: html_helper
INFO - 2025-01-24 05:59:12 --> Helper loaded: file_helper
INFO - 2025-01-24 05:59:12 --> Helper loaded: string_helper
INFO - 2025-01-24 05:59:12 --> Helper loaded: form_helper
INFO - 2025-01-24 05:59:12 --> Helper loaded: my_helper
INFO - 2025-01-24 05:59:12 --> Database Driver Class Initialized
INFO - 2025-01-24 05:59:12 --> Upload Class Initialized
INFO - 2025-01-24 05:59:12 --> Email Class Initialized
INFO - 2025-01-24 05:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 05:59:12 --> Form Validation Class Initialized
INFO - 2025-01-24 05:59:12 --> Controller Class Initialized
INFO - 2025-01-24 11:29:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:29:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:29:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:00:12 --> Config Class Initialized
INFO - 2025-01-24 06:00:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:00:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:00:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:00:12 --> URI Class Initialized
INFO - 2025-01-24 06:00:12 --> Router Class Initialized
INFO - 2025-01-24 06:00:12 --> Output Class Initialized
INFO - 2025-01-24 06:00:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:00:12 --> Input Class Initialized
INFO - 2025-01-24 06:00:12 --> Language Class Initialized
INFO - 2025-01-24 06:00:12 --> Loader Class Initialized
INFO - 2025-01-24 06:00:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:00:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:00:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:00:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:00:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:00:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:00:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:00:12 --> Upload Class Initialized
INFO - 2025-01-24 06:00:12 --> Email Class Initialized
INFO - 2025-01-24 06:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:00:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:00:12 --> Controller Class Initialized
INFO - 2025-01-24 11:30:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:30:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:30:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:01:12 --> Config Class Initialized
INFO - 2025-01-24 06:01:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:01:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:01:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:01:12 --> URI Class Initialized
INFO - 2025-01-24 06:01:12 --> Router Class Initialized
INFO - 2025-01-24 06:01:12 --> Output Class Initialized
INFO - 2025-01-24 06:01:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:01:12 --> Input Class Initialized
INFO - 2025-01-24 06:01:12 --> Language Class Initialized
INFO - 2025-01-24 06:01:12 --> Loader Class Initialized
INFO - 2025-01-24 06:01:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:01:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:01:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:01:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:01:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:01:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:01:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:01:12 --> Upload Class Initialized
INFO - 2025-01-24 06:01:12 --> Email Class Initialized
INFO - 2025-01-24 06:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:01:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:01:12 --> Controller Class Initialized
INFO - 2025-01-24 11:31:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:31:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:31:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:02:12 --> Config Class Initialized
INFO - 2025-01-24 06:02:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:02:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:02:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:02:12 --> URI Class Initialized
INFO - 2025-01-24 06:02:12 --> Router Class Initialized
INFO - 2025-01-24 06:02:12 --> Output Class Initialized
INFO - 2025-01-24 06:02:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:02:12 --> Input Class Initialized
INFO - 2025-01-24 06:02:12 --> Language Class Initialized
INFO - 2025-01-24 06:02:12 --> Loader Class Initialized
INFO - 2025-01-24 06:02:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:02:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:02:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:02:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:02:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:02:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:02:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:02:12 --> Upload Class Initialized
INFO - 2025-01-24 06:02:12 --> Email Class Initialized
INFO - 2025-01-24 06:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:02:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:02:12 --> Controller Class Initialized
INFO - 2025-01-24 11:32:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:32:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:32:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:03:12 --> Config Class Initialized
INFO - 2025-01-24 06:03:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:03:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:03:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:03:12 --> URI Class Initialized
INFO - 2025-01-24 06:03:12 --> Router Class Initialized
INFO - 2025-01-24 06:03:12 --> Output Class Initialized
INFO - 2025-01-24 06:03:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:03:12 --> Input Class Initialized
INFO - 2025-01-24 06:03:12 --> Language Class Initialized
INFO - 2025-01-24 06:03:12 --> Loader Class Initialized
INFO - 2025-01-24 06:03:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:03:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:03:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:03:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:03:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:03:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:03:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:03:12 --> Upload Class Initialized
INFO - 2025-01-24 06:03:12 --> Email Class Initialized
INFO - 2025-01-24 06:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:03:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:03:12 --> Controller Class Initialized
INFO - 2025-01-24 11:33:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:33:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:33:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:04:12 --> Config Class Initialized
INFO - 2025-01-24 06:04:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:04:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:04:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:04:12 --> URI Class Initialized
INFO - 2025-01-24 06:04:12 --> Router Class Initialized
INFO - 2025-01-24 06:04:12 --> Output Class Initialized
INFO - 2025-01-24 06:04:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:04:12 --> Input Class Initialized
INFO - 2025-01-24 06:04:12 --> Language Class Initialized
INFO - 2025-01-24 06:04:12 --> Loader Class Initialized
INFO - 2025-01-24 06:04:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:04:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:04:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:04:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:04:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:04:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:04:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:04:12 --> Upload Class Initialized
INFO - 2025-01-24 06:04:12 --> Email Class Initialized
INFO - 2025-01-24 06:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:04:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:04:12 --> Controller Class Initialized
INFO - 2025-01-24 11:34:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:34:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:34:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:05:12 --> Config Class Initialized
INFO - 2025-01-24 06:05:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:05:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:05:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:05:12 --> URI Class Initialized
INFO - 2025-01-24 06:05:12 --> Router Class Initialized
INFO - 2025-01-24 06:05:12 --> Output Class Initialized
INFO - 2025-01-24 06:05:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:05:12 --> Input Class Initialized
INFO - 2025-01-24 06:05:12 --> Language Class Initialized
INFO - 2025-01-24 06:05:12 --> Loader Class Initialized
INFO - 2025-01-24 06:05:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:05:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:05:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:05:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:05:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:05:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:05:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:05:12 --> Upload Class Initialized
INFO - 2025-01-24 06:05:12 --> Email Class Initialized
INFO - 2025-01-24 06:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:05:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:05:12 --> Controller Class Initialized
INFO - 2025-01-24 11:35:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:35:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:35:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:06:12 --> Config Class Initialized
INFO - 2025-01-24 06:06:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:06:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:06:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:06:12 --> URI Class Initialized
INFO - 2025-01-24 06:06:12 --> Router Class Initialized
INFO - 2025-01-24 06:06:12 --> Output Class Initialized
INFO - 2025-01-24 06:06:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:06:12 --> Input Class Initialized
INFO - 2025-01-24 06:06:12 --> Language Class Initialized
INFO - 2025-01-24 06:06:12 --> Loader Class Initialized
INFO - 2025-01-24 06:06:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:06:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:06:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:06:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:06:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:06:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:06:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:06:12 --> Upload Class Initialized
INFO - 2025-01-24 06:06:12 --> Email Class Initialized
INFO - 2025-01-24 06:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:06:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:06:12 --> Controller Class Initialized
INFO - 2025-01-24 11:36:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:36:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:36:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:25:13 --> Config Class Initialized
INFO - 2025-01-24 06:25:13 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:25:13 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:25:13 --> Utf8 Class Initialized
INFO - 2025-01-24 06:25:13 --> URI Class Initialized
INFO - 2025-01-24 06:25:13 --> Router Class Initialized
INFO - 2025-01-24 06:25:13 --> Output Class Initialized
INFO - 2025-01-24 06:25:13 --> Security Class Initialized
DEBUG - 2025-01-24 06:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:25:13 --> Input Class Initialized
INFO - 2025-01-24 06:25:13 --> Language Class Initialized
INFO - 2025-01-24 06:25:13 --> Loader Class Initialized
INFO - 2025-01-24 06:25:13 --> Helper loaded: url_helper
INFO - 2025-01-24 06:25:13 --> Helper loaded: html_helper
INFO - 2025-01-24 06:25:13 --> Helper loaded: file_helper
INFO - 2025-01-24 06:25:13 --> Helper loaded: string_helper
INFO - 2025-01-24 06:25:13 --> Helper loaded: form_helper
INFO - 2025-01-24 06:25:13 --> Helper loaded: my_helper
INFO - 2025-01-24 06:25:13 --> Database Driver Class Initialized
INFO - 2025-01-24 06:25:13 --> Upload Class Initialized
INFO - 2025-01-24 06:25:13 --> Email Class Initialized
INFO - 2025-01-24 06:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:25:13 --> Form Validation Class Initialized
INFO - 2025-01-24 06:25:13 --> Controller Class Initialized
INFO - 2025-01-24 11:55:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:55:13 --> Model "MainModel" initialized
INFO - 2025-01-24 11:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:55:13 --> Pagination Class Initialized
INFO - 2025-01-24 06:26:12 --> Config Class Initialized
INFO - 2025-01-24 06:26:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:26:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:26:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:26:12 --> URI Class Initialized
INFO - 2025-01-24 06:26:12 --> Router Class Initialized
INFO - 2025-01-24 06:26:12 --> Output Class Initialized
INFO - 2025-01-24 06:26:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:26:12 --> Input Class Initialized
INFO - 2025-01-24 06:26:12 --> Language Class Initialized
INFO - 2025-01-24 06:26:12 --> Loader Class Initialized
INFO - 2025-01-24 06:26:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:26:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:26:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:26:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:26:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:26:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:26:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:26:12 --> Upload Class Initialized
INFO - 2025-01-24 06:26:12 --> Email Class Initialized
INFO - 2025-01-24 06:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:26:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:26:12 --> Controller Class Initialized
INFO - 2025-01-24 11:56:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:56:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:56:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:27:12 --> Config Class Initialized
INFO - 2025-01-24 06:27:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:27:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:27:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:27:12 --> URI Class Initialized
INFO - 2025-01-24 06:27:12 --> Router Class Initialized
INFO - 2025-01-24 06:27:12 --> Output Class Initialized
INFO - 2025-01-24 06:27:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:27:12 --> Input Class Initialized
INFO - 2025-01-24 06:27:12 --> Language Class Initialized
INFO - 2025-01-24 06:27:12 --> Loader Class Initialized
INFO - 2025-01-24 06:27:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:27:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:27:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:27:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:27:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:27:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:27:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:27:12 --> Upload Class Initialized
INFO - 2025-01-24 06:27:12 --> Email Class Initialized
INFO - 2025-01-24 06:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:27:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:27:12 --> Controller Class Initialized
INFO - 2025-01-24 11:57:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:57:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:57:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:28:12 --> Config Class Initialized
INFO - 2025-01-24 06:28:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:28:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:28:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:28:12 --> URI Class Initialized
INFO - 2025-01-24 06:28:12 --> Router Class Initialized
INFO - 2025-01-24 06:28:12 --> Output Class Initialized
INFO - 2025-01-24 06:28:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:28:12 --> Input Class Initialized
INFO - 2025-01-24 06:28:12 --> Language Class Initialized
INFO - 2025-01-24 06:28:12 --> Loader Class Initialized
INFO - 2025-01-24 06:28:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:28:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:28:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:28:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:28:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:28:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:28:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:28:12 --> Upload Class Initialized
INFO - 2025-01-24 06:28:12 --> Email Class Initialized
INFO - 2025-01-24 06:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:28:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:28:12 --> Controller Class Initialized
INFO - 2025-01-24 11:58:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:58:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:58:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:29:12 --> Config Class Initialized
INFO - 2025-01-24 06:29:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:29:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:29:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:29:12 --> URI Class Initialized
INFO - 2025-01-24 06:29:12 --> Router Class Initialized
INFO - 2025-01-24 06:29:12 --> Output Class Initialized
INFO - 2025-01-24 06:29:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:29:12 --> Input Class Initialized
INFO - 2025-01-24 06:29:12 --> Language Class Initialized
INFO - 2025-01-24 06:29:12 --> Loader Class Initialized
INFO - 2025-01-24 06:29:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:29:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:29:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:29:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:29:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:29:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:29:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:29:12 --> Upload Class Initialized
INFO - 2025-01-24 06:29:12 --> Email Class Initialized
INFO - 2025-01-24 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:29:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:29:12 --> Controller Class Initialized
INFO - 2025-01-24 11:59:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 11:59:12 --> Model "MainModel" initialized
INFO - 2025-01-24 11:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 11:59:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:30:12 --> Config Class Initialized
INFO - 2025-01-24 06:30:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:30:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:30:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:30:12 --> URI Class Initialized
INFO - 2025-01-24 06:30:12 --> Router Class Initialized
INFO - 2025-01-24 06:30:12 --> Output Class Initialized
INFO - 2025-01-24 06:30:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:30:12 --> Input Class Initialized
INFO - 2025-01-24 06:30:12 --> Language Class Initialized
INFO - 2025-01-24 06:30:12 --> Loader Class Initialized
INFO - 2025-01-24 06:30:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:30:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:30:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:30:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:30:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:30:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:30:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:30:12 --> Upload Class Initialized
INFO - 2025-01-24 06:30:12 --> Email Class Initialized
INFO - 2025-01-24 06:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:30:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:30:12 --> Controller Class Initialized
INFO - 2025-01-24 12:00:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:00:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:00:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:31:12 --> Config Class Initialized
INFO - 2025-01-24 06:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:31:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:31:12 --> URI Class Initialized
INFO - 2025-01-24 06:31:12 --> Router Class Initialized
INFO - 2025-01-24 06:31:12 --> Output Class Initialized
INFO - 2025-01-24 06:31:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:31:12 --> Input Class Initialized
INFO - 2025-01-24 06:31:12 --> Language Class Initialized
INFO - 2025-01-24 06:31:12 --> Loader Class Initialized
INFO - 2025-01-24 06:31:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:31:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:31:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:31:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:31:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:31:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:31:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:31:12 --> Upload Class Initialized
INFO - 2025-01-24 06:31:12 --> Email Class Initialized
INFO - 2025-01-24 06:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:31:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:31:12 --> Controller Class Initialized
INFO - 2025-01-24 12:01:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:01:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:01:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:32:12 --> Config Class Initialized
INFO - 2025-01-24 06:32:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:32:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:32:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:32:12 --> URI Class Initialized
INFO - 2025-01-24 06:32:12 --> Router Class Initialized
INFO - 2025-01-24 06:32:12 --> Output Class Initialized
INFO - 2025-01-24 06:32:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:32:12 --> Input Class Initialized
INFO - 2025-01-24 06:32:12 --> Language Class Initialized
INFO - 2025-01-24 06:32:12 --> Loader Class Initialized
INFO - 2025-01-24 06:32:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:32:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:32:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:32:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:32:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:32:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:32:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:32:12 --> Upload Class Initialized
INFO - 2025-01-24 06:32:12 --> Email Class Initialized
INFO - 2025-01-24 06:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:32:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:32:12 --> Controller Class Initialized
INFO - 2025-01-24 12:02:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:02:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:02:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:33:12 --> Config Class Initialized
INFO - 2025-01-24 06:33:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:33:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:33:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:33:12 --> URI Class Initialized
INFO - 2025-01-24 06:33:12 --> Router Class Initialized
INFO - 2025-01-24 06:33:12 --> Output Class Initialized
INFO - 2025-01-24 06:33:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:33:12 --> Input Class Initialized
INFO - 2025-01-24 06:33:12 --> Language Class Initialized
INFO - 2025-01-24 06:33:12 --> Loader Class Initialized
INFO - 2025-01-24 06:33:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:33:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:33:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:33:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:33:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:33:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:33:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:33:12 --> Upload Class Initialized
INFO - 2025-01-24 06:33:12 --> Email Class Initialized
INFO - 2025-01-24 06:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:33:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:33:12 --> Controller Class Initialized
INFO - 2025-01-24 12:03:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:03:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:03:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:34:12 --> Config Class Initialized
INFO - 2025-01-24 06:34:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:34:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:34:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:34:12 --> URI Class Initialized
INFO - 2025-01-24 06:34:12 --> Router Class Initialized
INFO - 2025-01-24 06:34:12 --> Output Class Initialized
INFO - 2025-01-24 06:34:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:34:12 --> Input Class Initialized
INFO - 2025-01-24 06:34:12 --> Language Class Initialized
INFO - 2025-01-24 06:34:12 --> Loader Class Initialized
INFO - 2025-01-24 06:34:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:34:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:34:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:34:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:34:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:34:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:34:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:34:12 --> Upload Class Initialized
INFO - 2025-01-24 06:34:12 --> Email Class Initialized
INFO - 2025-01-24 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:34:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:34:12 --> Controller Class Initialized
INFO - 2025-01-24 12:04:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:04:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:04:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:35:12 --> Config Class Initialized
INFO - 2025-01-24 06:35:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:35:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:35:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:35:12 --> URI Class Initialized
INFO - 2025-01-24 06:35:12 --> Router Class Initialized
INFO - 2025-01-24 06:35:12 --> Output Class Initialized
INFO - 2025-01-24 06:35:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:35:12 --> Input Class Initialized
INFO - 2025-01-24 06:35:12 --> Language Class Initialized
INFO - 2025-01-24 06:35:12 --> Loader Class Initialized
INFO - 2025-01-24 06:35:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:35:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:35:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:35:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:35:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:35:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:35:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:35:12 --> Upload Class Initialized
INFO - 2025-01-24 06:35:12 --> Email Class Initialized
INFO - 2025-01-24 06:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:35:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:35:12 --> Controller Class Initialized
INFO - 2025-01-24 12:05:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:05:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:05:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:36:12 --> Config Class Initialized
INFO - 2025-01-24 06:36:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:36:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:36:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:36:12 --> URI Class Initialized
INFO - 2025-01-24 06:36:12 --> Router Class Initialized
INFO - 2025-01-24 06:36:12 --> Output Class Initialized
INFO - 2025-01-24 06:36:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:36:12 --> Input Class Initialized
INFO - 2025-01-24 06:36:12 --> Language Class Initialized
INFO - 2025-01-24 06:36:12 --> Loader Class Initialized
INFO - 2025-01-24 06:36:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:36:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:36:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:36:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:36:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:36:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:36:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:36:12 --> Upload Class Initialized
INFO - 2025-01-24 06:36:12 --> Email Class Initialized
INFO - 2025-01-24 06:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:36:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:36:12 --> Controller Class Initialized
INFO - 2025-01-24 12:06:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:06:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:06:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:37:12 --> Config Class Initialized
INFO - 2025-01-24 06:37:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:37:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:37:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:37:12 --> URI Class Initialized
INFO - 2025-01-24 06:37:12 --> Router Class Initialized
INFO - 2025-01-24 06:37:12 --> Output Class Initialized
INFO - 2025-01-24 06:37:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:37:12 --> Input Class Initialized
INFO - 2025-01-24 06:37:12 --> Language Class Initialized
INFO - 2025-01-24 06:37:12 --> Loader Class Initialized
INFO - 2025-01-24 06:37:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:37:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:37:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:37:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:37:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:37:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:37:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:37:12 --> Upload Class Initialized
INFO - 2025-01-24 06:37:12 --> Email Class Initialized
INFO - 2025-01-24 06:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:37:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:37:12 --> Controller Class Initialized
INFO - 2025-01-24 12:07:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:07:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:07:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:38:12 --> Config Class Initialized
INFO - 2025-01-24 06:38:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:38:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:38:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:38:12 --> URI Class Initialized
INFO - 2025-01-24 06:38:12 --> Router Class Initialized
INFO - 2025-01-24 06:38:12 --> Output Class Initialized
INFO - 2025-01-24 06:38:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:38:12 --> Input Class Initialized
INFO - 2025-01-24 06:38:12 --> Language Class Initialized
INFO - 2025-01-24 06:38:12 --> Loader Class Initialized
INFO - 2025-01-24 06:38:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:38:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:38:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:38:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:38:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:38:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:38:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:38:12 --> Upload Class Initialized
INFO - 2025-01-24 06:38:12 --> Email Class Initialized
INFO - 2025-01-24 06:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:38:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:38:12 --> Controller Class Initialized
INFO - 2025-01-24 12:08:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:08:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:08:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:39:12 --> Config Class Initialized
INFO - 2025-01-24 06:39:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:39:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:39:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:39:12 --> URI Class Initialized
INFO - 2025-01-24 06:39:12 --> Router Class Initialized
INFO - 2025-01-24 06:39:12 --> Output Class Initialized
INFO - 2025-01-24 06:39:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:39:12 --> Input Class Initialized
INFO - 2025-01-24 06:39:12 --> Language Class Initialized
INFO - 2025-01-24 06:39:12 --> Loader Class Initialized
INFO - 2025-01-24 06:39:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:39:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:39:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:39:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:39:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:39:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:39:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:39:12 --> Upload Class Initialized
INFO - 2025-01-24 06:39:12 --> Email Class Initialized
INFO - 2025-01-24 06:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:39:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:39:12 --> Controller Class Initialized
INFO - 2025-01-24 12:09:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:09:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:09:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:40:12 --> Config Class Initialized
INFO - 2025-01-24 06:40:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:40:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:40:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:40:12 --> URI Class Initialized
INFO - 2025-01-24 06:40:12 --> Router Class Initialized
INFO - 2025-01-24 06:40:12 --> Output Class Initialized
INFO - 2025-01-24 06:40:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:40:12 --> Input Class Initialized
INFO - 2025-01-24 06:40:12 --> Language Class Initialized
INFO - 2025-01-24 06:40:12 --> Loader Class Initialized
INFO - 2025-01-24 06:40:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:40:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:40:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:40:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:40:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:40:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:40:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:40:12 --> Upload Class Initialized
INFO - 2025-01-24 06:40:12 --> Email Class Initialized
INFO - 2025-01-24 06:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:40:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:40:12 --> Controller Class Initialized
INFO - 2025-01-24 12:10:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:10:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:10:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:41:12 --> Config Class Initialized
INFO - 2025-01-24 06:41:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:41:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:41:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:41:12 --> URI Class Initialized
INFO - 2025-01-24 06:41:12 --> Router Class Initialized
INFO - 2025-01-24 06:41:12 --> Output Class Initialized
INFO - 2025-01-24 06:41:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:41:12 --> Input Class Initialized
INFO - 2025-01-24 06:41:12 --> Language Class Initialized
INFO - 2025-01-24 06:41:12 --> Loader Class Initialized
INFO - 2025-01-24 06:41:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:41:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:41:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:41:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:41:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:41:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:41:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:41:12 --> Upload Class Initialized
INFO - 2025-01-24 06:41:12 --> Email Class Initialized
INFO - 2025-01-24 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:41:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:41:12 --> Controller Class Initialized
INFO - 2025-01-24 12:11:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:11:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:11:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:42:12 --> Config Class Initialized
INFO - 2025-01-24 06:42:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:42:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:42:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:42:12 --> URI Class Initialized
INFO - 2025-01-24 06:42:12 --> Router Class Initialized
INFO - 2025-01-24 06:42:12 --> Output Class Initialized
INFO - 2025-01-24 06:42:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:42:12 --> Input Class Initialized
INFO - 2025-01-24 06:42:12 --> Language Class Initialized
INFO - 2025-01-24 06:42:12 --> Loader Class Initialized
INFO - 2025-01-24 06:42:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:42:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:42:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:42:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:42:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:42:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:42:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:42:12 --> Upload Class Initialized
INFO - 2025-01-24 06:42:12 --> Email Class Initialized
INFO - 2025-01-24 06:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:42:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:42:12 --> Controller Class Initialized
INFO - 2025-01-24 12:12:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:12:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:12:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:43:12 --> Config Class Initialized
INFO - 2025-01-24 06:43:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:43:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:43:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:43:12 --> URI Class Initialized
INFO - 2025-01-24 06:43:12 --> Router Class Initialized
INFO - 2025-01-24 06:43:12 --> Output Class Initialized
INFO - 2025-01-24 06:43:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:43:12 --> Input Class Initialized
INFO - 2025-01-24 06:43:12 --> Language Class Initialized
INFO - 2025-01-24 06:43:12 --> Loader Class Initialized
INFO - 2025-01-24 06:43:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:43:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:43:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:43:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:43:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:43:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:43:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:43:12 --> Upload Class Initialized
INFO - 2025-01-24 06:43:12 --> Email Class Initialized
INFO - 2025-01-24 06:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:43:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:43:12 --> Controller Class Initialized
INFO - 2025-01-24 12:13:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:13:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:13:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:44:12 --> Config Class Initialized
INFO - 2025-01-24 06:44:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:44:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:44:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:44:12 --> URI Class Initialized
INFO - 2025-01-24 06:44:12 --> Router Class Initialized
INFO - 2025-01-24 06:44:12 --> Output Class Initialized
INFO - 2025-01-24 06:44:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:44:12 --> Input Class Initialized
INFO - 2025-01-24 06:44:12 --> Language Class Initialized
INFO - 2025-01-24 06:44:12 --> Loader Class Initialized
INFO - 2025-01-24 06:44:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:44:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:44:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:44:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:44:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:44:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:44:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:44:12 --> Upload Class Initialized
INFO - 2025-01-24 06:44:12 --> Email Class Initialized
INFO - 2025-01-24 06:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:44:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:44:12 --> Controller Class Initialized
INFO - 2025-01-24 12:14:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:14:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:14:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:45:21 --> Config Class Initialized
INFO - 2025-01-24 06:45:21 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:45:21 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:45:21 --> Utf8 Class Initialized
INFO - 2025-01-24 06:45:21 --> URI Class Initialized
INFO - 2025-01-24 06:45:21 --> Router Class Initialized
INFO - 2025-01-24 06:45:21 --> Output Class Initialized
INFO - 2025-01-24 06:45:21 --> Security Class Initialized
DEBUG - 2025-01-24 06:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:45:21 --> Input Class Initialized
INFO - 2025-01-24 06:45:21 --> Language Class Initialized
INFO - 2025-01-24 06:45:22 --> Loader Class Initialized
INFO - 2025-01-24 06:45:22 --> Helper loaded: url_helper
INFO - 2025-01-24 06:45:22 --> Helper loaded: html_helper
INFO - 2025-01-24 06:45:22 --> Helper loaded: file_helper
INFO - 2025-01-24 06:45:22 --> Helper loaded: string_helper
INFO - 2025-01-24 06:45:22 --> Helper loaded: form_helper
INFO - 2025-01-24 06:45:22 --> Helper loaded: my_helper
INFO - 2025-01-24 06:45:22 --> Database Driver Class Initialized
INFO - 2025-01-24 06:45:22 --> Upload Class Initialized
INFO - 2025-01-24 06:45:22 --> Email Class Initialized
INFO - 2025-01-24 06:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:45:22 --> Form Validation Class Initialized
INFO - 2025-01-24 06:45:22 --> Controller Class Initialized
INFO - 2025-01-24 12:15:22 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:15:22 --> Model "MainModel" initialized
INFO - 2025-01-24 12:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:15:22 --> Pagination Class Initialized
INFO - 2025-01-24 06:46:12 --> Config Class Initialized
INFO - 2025-01-24 06:46:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:46:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:46:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:46:12 --> URI Class Initialized
INFO - 2025-01-24 06:46:12 --> Router Class Initialized
INFO - 2025-01-24 06:46:12 --> Output Class Initialized
INFO - 2025-01-24 06:46:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:46:12 --> Input Class Initialized
INFO - 2025-01-24 06:46:12 --> Language Class Initialized
INFO - 2025-01-24 06:46:12 --> Loader Class Initialized
INFO - 2025-01-24 06:46:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:46:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:46:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:46:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:46:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:46:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:46:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:46:12 --> Upload Class Initialized
INFO - 2025-01-24 06:46:12 --> Email Class Initialized
INFO - 2025-01-24 06:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:46:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:46:12 --> Controller Class Initialized
INFO - 2025-01-24 12:16:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:16:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:16:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:47:12 --> Config Class Initialized
INFO - 2025-01-24 06:47:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:47:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:47:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:47:12 --> URI Class Initialized
INFO - 2025-01-24 06:47:12 --> Router Class Initialized
INFO - 2025-01-24 06:47:12 --> Output Class Initialized
INFO - 2025-01-24 06:47:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:47:12 --> Input Class Initialized
INFO - 2025-01-24 06:47:12 --> Language Class Initialized
INFO - 2025-01-24 06:47:12 --> Loader Class Initialized
INFO - 2025-01-24 06:47:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:47:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:47:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:47:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:47:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:47:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:47:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:47:12 --> Upload Class Initialized
INFO - 2025-01-24 06:47:12 --> Email Class Initialized
INFO - 2025-01-24 06:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:47:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:47:12 --> Controller Class Initialized
INFO - 2025-01-24 12:17:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:17:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:17:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:48:12 --> Config Class Initialized
INFO - 2025-01-24 06:48:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:48:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:48:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:48:12 --> URI Class Initialized
INFO - 2025-01-24 06:48:12 --> Router Class Initialized
INFO - 2025-01-24 06:48:12 --> Output Class Initialized
INFO - 2025-01-24 06:48:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:48:12 --> Input Class Initialized
INFO - 2025-01-24 06:48:12 --> Language Class Initialized
INFO - 2025-01-24 06:48:12 --> Loader Class Initialized
INFO - 2025-01-24 06:48:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:48:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:48:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:48:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:48:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:48:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:48:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:48:12 --> Upload Class Initialized
INFO - 2025-01-24 06:48:12 --> Email Class Initialized
INFO - 2025-01-24 06:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:48:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:48:12 --> Controller Class Initialized
INFO - 2025-01-24 12:18:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:18:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:18:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:49:12 --> Config Class Initialized
INFO - 2025-01-24 06:49:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:49:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:49:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:49:12 --> URI Class Initialized
INFO - 2025-01-24 06:49:12 --> Router Class Initialized
INFO - 2025-01-24 06:49:12 --> Output Class Initialized
INFO - 2025-01-24 06:49:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:49:12 --> Input Class Initialized
INFO - 2025-01-24 06:49:12 --> Language Class Initialized
INFO - 2025-01-24 06:49:12 --> Loader Class Initialized
INFO - 2025-01-24 06:49:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:49:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:49:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:49:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:49:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:49:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:49:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:49:12 --> Upload Class Initialized
INFO - 2025-01-24 06:49:12 --> Email Class Initialized
INFO - 2025-01-24 06:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:49:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:49:12 --> Controller Class Initialized
INFO - 2025-01-24 12:19:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:19:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:19:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:50:12 --> Config Class Initialized
INFO - 2025-01-24 06:50:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:50:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:50:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:50:12 --> URI Class Initialized
INFO - 2025-01-24 06:50:12 --> Router Class Initialized
INFO - 2025-01-24 06:50:12 --> Output Class Initialized
INFO - 2025-01-24 06:50:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:50:12 --> Input Class Initialized
INFO - 2025-01-24 06:50:12 --> Language Class Initialized
INFO - 2025-01-24 06:50:12 --> Loader Class Initialized
INFO - 2025-01-24 06:50:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:50:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:50:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:50:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:50:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:50:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:50:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:50:12 --> Upload Class Initialized
INFO - 2025-01-24 06:50:12 --> Email Class Initialized
INFO - 2025-01-24 06:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:50:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:50:12 --> Controller Class Initialized
INFO - 2025-01-24 12:20:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:20:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:20:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:51:12 --> Config Class Initialized
INFO - 2025-01-24 06:51:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:51:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:51:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:51:12 --> URI Class Initialized
INFO - 2025-01-24 06:51:12 --> Router Class Initialized
INFO - 2025-01-24 06:51:12 --> Output Class Initialized
INFO - 2025-01-24 06:51:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:51:12 --> Input Class Initialized
INFO - 2025-01-24 06:51:12 --> Language Class Initialized
INFO - 2025-01-24 06:51:12 --> Loader Class Initialized
INFO - 2025-01-24 06:51:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:51:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:51:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:51:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:51:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:51:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:51:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:51:12 --> Upload Class Initialized
INFO - 2025-01-24 06:51:12 --> Email Class Initialized
INFO - 2025-01-24 06:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:51:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:51:12 --> Controller Class Initialized
INFO - 2025-01-24 12:21:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:21:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:21:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:52:12 --> Config Class Initialized
INFO - 2025-01-24 06:52:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:52:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:52:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:52:12 --> URI Class Initialized
INFO - 2025-01-24 06:52:12 --> Router Class Initialized
INFO - 2025-01-24 06:52:12 --> Output Class Initialized
INFO - 2025-01-24 06:52:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:52:12 --> Input Class Initialized
INFO - 2025-01-24 06:52:12 --> Language Class Initialized
INFO - 2025-01-24 06:52:12 --> Loader Class Initialized
INFO - 2025-01-24 06:52:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:52:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:52:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:52:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:52:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:52:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:52:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:52:12 --> Upload Class Initialized
INFO - 2025-01-24 06:52:12 --> Email Class Initialized
INFO - 2025-01-24 06:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:52:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:52:12 --> Controller Class Initialized
INFO - 2025-01-24 12:22:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:22:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:22:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:53:12 --> Config Class Initialized
INFO - 2025-01-24 06:53:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:53:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:53:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:53:12 --> URI Class Initialized
INFO - 2025-01-24 06:53:12 --> Router Class Initialized
INFO - 2025-01-24 06:53:12 --> Output Class Initialized
INFO - 2025-01-24 06:53:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:53:12 --> Input Class Initialized
INFO - 2025-01-24 06:53:12 --> Language Class Initialized
INFO - 2025-01-24 06:53:12 --> Loader Class Initialized
INFO - 2025-01-24 06:53:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:53:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:53:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:53:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:53:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:53:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:53:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:53:12 --> Upload Class Initialized
INFO - 2025-01-24 06:53:12 --> Email Class Initialized
INFO - 2025-01-24 06:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:53:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:53:12 --> Controller Class Initialized
INFO - 2025-01-24 12:23:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:23:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:23:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:54:12 --> Config Class Initialized
INFO - 2025-01-24 06:54:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:54:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:54:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:54:12 --> URI Class Initialized
INFO - 2025-01-24 06:54:12 --> Router Class Initialized
INFO - 2025-01-24 06:54:12 --> Output Class Initialized
INFO - 2025-01-24 06:54:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:54:12 --> Input Class Initialized
INFO - 2025-01-24 06:54:12 --> Language Class Initialized
INFO - 2025-01-24 06:54:12 --> Loader Class Initialized
INFO - 2025-01-24 06:54:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:54:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:54:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:54:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:54:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:54:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:54:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:54:12 --> Upload Class Initialized
INFO - 2025-01-24 06:54:12 --> Email Class Initialized
INFO - 2025-01-24 06:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:54:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:54:12 --> Controller Class Initialized
INFO - 2025-01-24 12:24:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:24:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:24:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:55:12 --> Config Class Initialized
INFO - 2025-01-24 06:55:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:55:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:55:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:55:12 --> URI Class Initialized
INFO - 2025-01-24 06:55:12 --> Router Class Initialized
INFO - 2025-01-24 06:55:12 --> Output Class Initialized
INFO - 2025-01-24 06:55:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:55:12 --> Input Class Initialized
INFO - 2025-01-24 06:55:12 --> Language Class Initialized
INFO - 2025-01-24 06:55:12 --> Loader Class Initialized
INFO - 2025-01-24 06:55:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:55:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:55:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:55:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:55:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:55:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:55:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:55:12 --> Upload Class Initialized
INFO - 2025-01-24 06:55:12 --> Email Class Initialized
INFO - 2025-01-24 06:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:55:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:55:12 --> Controller Class Initialized
INFO - 2025-01-24 12:25:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:25:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:25:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:56:12 --> Config Class Initialized
INFO - 2025-01-24 06:56:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:56:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:56:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:56:12 --> URI Class Initialized
INFO - 2025-01-24 06:56:12 --> Router Class Initialized
INFO - 2025-01-24 06:56:12 --> Output Class Initialized
INFO - 2025-01-24 06:56:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:56:12 --> Input Class Initialized
INFO - 2025-01-24 06:56:12 --> Language Class Initialized
INFO - 2025-01-24 06:56:12 --> Loader Class Initialized
INFO - 2025-01-24 06:56:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:56:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:56:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:56:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:56:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:56:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:56:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:56:12 --> Upload Class Initialized
INFO - 2025-01-24 06:56:12 --> Email Class Initialized
INFO - 2025-01-24 06:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:56:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:56:12 --> Controller Class Initialized
INFO - 2025-01-24 12:26:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:26:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:26:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:57:12 --> Config Class Initialized
INFO - 2025-01-24 06:57:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:57:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:57:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:57:12 --> URI Class Initialized
INFO - 2025-01-24 06:57:12 --> Router Class Initialized
INFO - 2025-01-24 06:57:12 --> Output Class Initialized
INFO - 2025-01-24 06:57:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:57:12 --> Input Class Initialized
INFO - 2025-01-24 06:57:12 --> Language Class Initialized
INFO - 2025-01-24 06:57:12 --> Loader Class Initialized
INFO - 2025-01-24 06:57:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:57:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:57:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:57:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:57:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:57:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:57:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:57:12 --> Upload Class Initialized
INFO - 2025-01-24 06:57:12 --> Email Class Initialized
INFO - 2025-01-24 06:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:57:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:57:12 --> Controller Class Initialized
INFO - 2025-01-24 12:27:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:27:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:27:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:58:12 --> Config Class Initialized
INFO - 2025-01-24 06:58:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:58:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:58:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:58:12 --> URI Class Initialized
INFO - 2025-01-24 06:58:12 --> Router Class Initialized
INFO - 2025-01-24 06:58:12 --> Output Class Initialized
INFO - 2025-01-24 06:58:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:58:12 --> Input Class Initialized
INFO - 2025-01-24 06:58:12 --> Language Class Initialized
INFO - 2025-01-24 06:58:12 --> Loader Class Initialized
INFO - 2025-01-24 06:58:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:58:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:58:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:58:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:58:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:58:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:58:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:58:12 --> Upload Class Initialized
INFO - 2025-01-24 06:58:12 --> Email Class Initialized
INFO - 2025-01-24 06:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:58:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:58:12 --> Controller Class Initialized
INFO - 2025-01-24 12:28:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:28:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:28:12 --> Pagination Class Initialized
INFO - 2025-01-24 06:59:12 --> Config Class Initialized
INFO - 2025-01-24 06:59:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 06:59:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 06:59:12 --> Utf8 Class Initialized
INFO - 2025-01-24 06:59:12 --> URI Class Initialized
INFO - 2025-01-24 06:59:12 --> Router Class Initialized
INFO - 2025-01-24 06:59:12 --> Output Class Initialized
INFO - 2025-01-24 06:59:12 --> Security Class Initialized
DEBUG - 2025-01-24 06:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 06:59:12 --> Input Class Initialized
INFO - 2025-01-24 06:59:12 --> Language Class Initialized
INFO - 2025-01-24 06:59:12 --> Loader Class Initialized
INFO - 2025-01-24 06:59:12 --> Helper loaded: url_helper
INFO - 2025-01-24 06:59:12 --> Helper loaded: html_helper
INFO - 2025-01-24 06:59:12 --> Helper loaded: file_helper
INFO - 2025-01-24 06:59:12 --> Helper loaded: string_helper
INFO - 2025-01-24 06:59:12 --> Helper loaded: form_helper
INFO - 2025-01-24 06:59:12 --> Helper loaded: my_helper
INFO - 2025-01-24 06:59:12 --> Database Driver Class Initialized
INFO - 2025-01-24 06:59:12 --> Upload Class Initialized
INFO - 2025-01-24 06:59:12 --> Email Class Initialized
INFO - 2025-01-24 06:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 06:59:12 --> Form Validation Class Initialized
INFO - 2025-01-24 06:59:12 --> Controller Class Initialized
INFO - 2025-01-24 12:29:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:29:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:29:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:00:12 --> Config Class Initialized
INFO - 2025-01-24 07:00:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:00:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:00:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:00:12 --> URI Class Initialized
INFO - 2025-01-24 07:00:12 --> Router Class Initialized
INFO - 2025-01-24 07:00:12 --> Output Class Initialized
INFO - 2025-01-24 07:00:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:00:12 --> Input Class Initialized
INFO - 2025-01-24 07:00:12 --> Language Class Initialized
INFO - 2025-01-24 07:00:12 --> Loader Class Initialized
INFO - 2025-01-24 07:00:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:00:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:00:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:00:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:00:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:00:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:00:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:00:12 --> Upload Class Initialized
INFO - 2025-01-24 07:00:12 --> Email Class Initialized
INFO - 2025-01-24 07:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:00:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:00:12 --> Controller Class Initialized
INFO - 2025-01-24 12:30:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:30:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:30:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:01:12 --> Config Class Initialized
INFO - 2025-01-24 07:01:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:01:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:01:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:01:12 --> URI Class Initialized
INFO - 2025-01-24 07:01:12 --> Router Class Initialized
INFO - 2025-01-24 07:01:12 --> Output Class Initialized
INFO - 2025-01-24 07:01:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:01:12 --> Input Class Initialized
INFO - 2025-01-24 07:01:12 --> Language Class Initialized
INFO - 2025-01-24 07:01:12 --> Loader Class Initialized
INFO - 2025-01-24 07:01:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:01:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:01:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:01:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:01:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:01:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:01:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:01:12 --> Upload Class Initialized
INFO - 2025-01-24 07:01:12 --> Email Class Initialized
INFO - 2025-01-24 07:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:01:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:01:12 --> Controller Class Initialized
INFO - 2025-01-24 12:31:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:31:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:31:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:02:12 --> Config Class Initialized
INFO - 2025-01-24 07:02:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:02:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:02:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:02:12 --> URI Class Initialized
INFO - 2025-01-24 07:02:12 --> Router Class Initialized
INFO - 2025-01-24 07:02:12 --> Output Class Initialized
INFO - 2025-01-24 07:02:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:02:12 --> Input Class Initialized
INFO - 2025-01-24 07:02:12 --> Language Class Initialized
INFO - 2025-01-24 07:02:12 --> Loader Class Initialized
INFO - 2025-01-24 07:02:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:02:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:02:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:02:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:02:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:02:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:02:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:02:12 --> Upload Class Initialized
INFO - 2025-01-24 07:02:12 --> Email Class Initialized
INFO - 2025-01-24 07:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:02:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:02:12 --> Controller Class Initialized
INFO - 2025-01-24 12:32:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:32:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:32:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:03:12 --> Config Class Initialized
INFO - 2025-01-24 07:03:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:03:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:03:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:03:12 --> URI Class Initialized
INFO - 2025-01-24 07:03:12 --> Router Class Initialized
INFO - 2025-01-24 07:03:12 --> Output Class Initialized
INFO - 2025-01-24 07:03:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:03:12 --> Input Class Initialized
INFO - 2025-01-24 07:03:12 --> Language Class Initialized
INFO - 2025-01-24 07:03:12 --> Loader Class Initialized
INFO - 2025-01-24 07:03:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:03:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:03:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:03:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:03:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:03:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:03:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:03:12 --> Upload Class Initialized
INFO - 2025-01-24 07:03:12 --> Email Class Initialized
INFO - 2025-01-24 07:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:03:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:03:12 --> Controller Class Initialized
INFO - 2025-01-24 12:33:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:33:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:33:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:04:12 --> Config Class Initialized
INFO - 2025-01-24 07:04:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:04:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:04:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:04:12 --> URI Class Initialized
INFO - 2025-01-24 07:04:12 --> Router Class Initialized
INFO - 2025-01-24 07:04:12 --> Output Class Initialized
INFO - 2025-01-24 07:04:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:04:12 --> Input Class Initialized
INFO - 2025-01-24 07:04:12 --> Language Class Initialized
INFO - 2025-01-24 07:04:12 --> Loader Class Initialized
INFO - 2025-01-24 07:04:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:04:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:04:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:04:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:04:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:04:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:04:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:04:12 --> Upload Class Initialized
INFO - 2025-01-24 07:04:12 --> Email Class Initialized
INFO - 2025-01-24 07:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:04:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:04:12 --> Controller Class Initialized
INFO - 2025-01-24 12:34:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:34:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:34:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:05:12 --> Config Class Initialized
INFO - 2025-01-24 07:05:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:05:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:05:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:05:12 --> URI Class Initialized
INFO - 2025-01-24 07:05:12 --> Router Class Initialized
INFO - 2025-01-24 07:05:12 --> Output Class Initialized
INFO - 2025-01-24 07:05:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:05:12 --> Input Class Initialized
INFO - 2025-01-24 07:05:12 --> Language Class Initialized
INFO - 2025-01-24 07:05:12 --> Loader Class Initialized
INFO - 2025-01-24 07:05:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:05:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:05:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:05:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:05:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:05:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:05:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:05:12 --> Upload Class Initialized
INFO - 2025-01-24 07:05:12 --> Email Class Initialized
INFO - 2025-01-24 07:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:05:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:05:12 --> Controller Class Initialized
INFO - 2025-01-24 12:35:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:35:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:35:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:06:12 --> Config Class Initialized
INFO - 2025-01-24 07:06:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:06:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:06:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:06:12 --> URI Class Initialized
INFO - 2025-01-24 07:06:12 --> Router Class Initialized
INFO - 2025-01-24 07:06:12 --> Output Class Initialized
INFO - 2025-01-24 07:06:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:06:12 --> Input Class Initialized
INFO - 2025-01-24 07:06:12 --> Language Class Initialized
INFO - 2025-01-24 07:06:12 --> Loader Class Initialized
INFO - 2025-01-24 07:06:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:06:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:06:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:06:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:06:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:06:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:06:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:06:12 --> Upload Class Initialized
INFO - 2025-01-24 07:06:12 --> Email Class Initialized
INFO - 2025-01-24 07:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:06:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:06:12 --> Controller Class Initialized
INFO - 2025-01-24 12:36:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:36:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:36:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:07:12 --> Config Class Initialized
INFO - 2025-01-24 07:07:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:07:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:07:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:07:12 --> URI Class Initialized
INFO - 2025-01-24 07:07:12 --> Router Class Initialized
INFO - 2025-01-24 07:07:12 --> Output Class Initialized
INFO - 2025-01-24 07:07:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:07:12 --> Input Class Initialized
INFO - 2025-01-24 07:07:12 --> Language Class Initialized
INFO - 2025-01-24 07:07:12 --> Loader Class Initialized
INFO - 2025-01-24 07:07:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:07:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:07:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:07:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:07:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:07:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:07:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:07:12 --> Upload Class Initialized
INFO - 2025-01-24 07:07:12 --> Email Class Initialized
INFO - 2025-01-24 07:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:07:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:07:12 --> Controller Class Initialized
INFO - 2025-01-24 12:37:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:37:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:37:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:08:12 --> Config Class Initialized
INFO - 2025-01-24 07:08:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:08:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:08:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:08:12 --> URI Class Initialized
INFO - 2025-01-24 07:08:12 --> Router Class Initialized
INFO - 2025-01-24 07:08:12 --> Output Class Initialized
INFO - 2025-01-24 07:08:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:08:12 --> Input Class Initialized
INFO - 2025-01-24 07:08:12 --> Language Class Initialized
INFO - 2025-01-24 07:08:12 --> Loader Class Initialized
INFO - 2025-01-24 07:08:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:08:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:08:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:08:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:08:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:08:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:08:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:08:12 --> Upload Class Initialized
INFO - 2025-01-24 07:08:12 --> Email Class Initialized
INFO - 2025-01-24 07:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:08:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:08:12 --> Controller Class Initialized
INFO - 2025-01-24 12:38:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:38:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:38:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:09:12 --> Config Class Initialized
INFO - 2025-01-24 07:09:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:09:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:09:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:09:12 --> URI Class Initialized
INFO - 2025-01-24 07:09:12 --> Router Class Initialized
INFO - 2025-01-24 07:09:12 --> Output Class Initialized
INFO - 2025-01-24 07:09:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:09:12 --> Input Class Initialized
INFO - 2025-01-24 07:09:12 --> Language Class Initialized
INFO - 2025-01-24 07:09:12 --> Loader Class Initialized
INFO - 2025-01-24 07:09:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:09:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:09:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:09:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:09:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:09:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:09:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:09:12 --> Upload Class Initialized
INFO - 2025-01-24 07:09:12 --> Email Class Initialized
INFO - 2025-01-24 07:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:09:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:09:12 --> Controller Class Initialized
INFO - 2025-01-24 12:39:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:39:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:39:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:10:12 --> Config Class Initialized
INFO - 2025-01-24 07:10:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:10:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:10:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:10:12 --> URI Class Initialized
INFO - 2025-01-24 07:10:12 --> Router Class Initialized
INFO - 2025-01-24 07:10:12 --> Output Class Initialized
INFO - 2025-01-24 07:10:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:10:12 --> Input Class Initialized
INFO - 2025-01-24 07:10:12 --> Language Class Initialized
INFO - 2025-01-24 07:10:12 --> Loader Class Initialized
INFO - 2025-01-24 07:10:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:10:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:10:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:10:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:10:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:10:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:10:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:10:12 --> Upload Class Initialized
INFO - 2025-01-24 07:10:12 --> Email Class Initialized
INFO - 2025-01-24 07:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:10:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:10:12 --> Controller Class Initialized
INFO - 2025-01-24 12:40:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:40:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:40:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:11:12 --> Config Class Initialized
INFO - 2025-01-24 07:11:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:11:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:11:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:11:12 --> URI Class Initialized
INFO - 2025-01-24 07:11:12 --> Router Class Initialized
INFO - 2025-01-24 07:11:12 --> Output Class Initialized
INFO - 2025-01-24 07:11:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:11:12 --> Input Class Initialized
INFO - 2025-01-24 07:11:12 --> Language Class Initialized
INFO - 2025-01-24 07:11:12 --> Loader Class Initialized
INFO - 2025-01-24 07:11:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:11:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:11:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:11:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:11:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:11:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:11:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:11:12 --> Upload Class Initialized
INFO - 2025-01-24 07:11:12 --> Email Class Initialized
INFO - 2025-01-24 07:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:11:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:11:12 --> Controller Class Initialized
INFO - 2025-01-24 12:41:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:41:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:41:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:12:12 --> Config Class Initialized
INFO - 2025-01-24 07:12:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:12:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:12:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:12:12 --> URI Class Initialized
INFO - 2025-01-24 07:12:12 --> Router Class Initialized
INFO - 2025-01-24 07:12:12 --> Output Class Initialized
INFO - 2025-01-24 07:12:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:12:12 --> Input Class Initialized
INFO - 2025-01-24 07:12:12 --> Language Class Initialized
INFO - 2025-01-24 07:12:12 --> Loader Class Initialized
INFO - 2025-01-24 07:12:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:12:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:12:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:12:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:12:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:12:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:12:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:12:12 --> Upload Class Initialized
INFO - 2025-01-24 07:12:12 --> Email Class Initialized
INFO - 2025-01-24 07:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:12:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:12:12 --> Controller Class Initialized
INFO - 2025-01-24 12:42:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:42:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:42:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:13:12 --> Config Class Initialized
INFO - 2025-01-24 07:13:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:13:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:13:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:13:12 --> URI Class Initialized
INFO - 2025-01-24 07:13:12 --> Router Class Initialized
INFO - 2025-01-24 07:13:12 --> Output Class Initialized
INFO - 2025-01-24 07:13:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:13:12 --> Input Class Initialized
INFO - 2025-01-24 07:13:12 --> Language Class Initialized
INFO - 2025-01-24 07:13:12 --> Loader Class Initialized
INFO - 2025-01-24 07:13:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:13:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:13:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:13:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:13:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:13:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:13:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:13:12 --> Upload Class Initialized
INFO - 2025-01-24 07:13:12 --> Email Class Initialized
INFO - 2025-01-24 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:13:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:13:12 --> Controller Class Initialized
INFO - 2025-01-24 12:43:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:43:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:43:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:14:12 --> Config Class Initialized
INFO - 2025-01-24 07:14:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:14:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:14:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:14:12 --> URI Class Initialized
INFO - 2025-01-24 07:14:12 --> Router Class Initialized
INFO - 2025-01-24 07:14:12 --> Output Class Initialized
INFO - 2025-01-24 07:14:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:14:12 --> Input Class Initialized
INFO - 2025-01-24 07:14:12 --> Language Class Initialized
INFO - 2025-01-24 07:14:12 --> Loader Class Initialized
INFO - 2025-01-24 07:14:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:14:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:14:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:14:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:14:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:14:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:14:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:14:12 --> Upload Class Initialized
INFO - 2025-01-24 07:14:12 --> Email Class Initialized
INFO - 2025-01-24 07:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:14:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:14:12 --> Controller Class Initialized
INFO - 2025-01-24 12:44:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:44:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:44:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:15:12 --> Config Class Initialized
INFO - 2025-01-24 07:15:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:15:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:15:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:15:12 --> URI Class Initialized
INFO - 2025-01-24 07:15:12 --> Router Class Initialized
INFO - 2025-01-24 07:15:12 --> Output Class Initialized
INFO - 2025-01-24 07:15:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:15:12 --> Input Class Initialized
INFO - 2025-01-24 07:15:12 --> Language Class Initialized
INFO - 2025-01-24 07:15:12 --> Loader Class Initialized
INFO - 2025-01-24 07:15:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:15:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:15:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:15:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:15:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:15:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:15:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:15:12 --> Upload Class Initialized
INFO - 2025-01-24 07:15:12 --> Email Class Initialized
INFO - 2025-01-24 07:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:15:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:15:12 --> Controller Class Initialized
INFO - 2025-01-24 12:45:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:45:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:45:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:16:12 --> Config Class Initialized
INFO - 2025-01-24 07:16:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:16:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:16:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:16:12 --> URI Class Initialized
INFO - 2025-01-24 07:16:12 --> Router Class Initialized
INFO - 2025-01-24 07:16:12 --> Output Class Initialized
INFO - 2025-01-24 07:16:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:16:12 --> Input Class Initialized
INFO - 2025-01-24 07:16:12 --> Language Class Initialized
INFO - 2025-01-24 07:16:12 --> Loader Class Initialized
INFO - 2025-01-24 07:16:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:16:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:16:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:16:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:16:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:16:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:16:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:16:12 --> Upload Class Initialized
INFO - 2025-01-24 07:16:12 --> Email Class Initialized
INFO - 2025-01-24 07:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:16:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:16:12 --> Controller Class Initialized
INFO - 2025-01-24 12:46:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:46:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:46:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:17:12 --> Config Class Initialized
INFO - 2025-01-24 07:17:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:17:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:17:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:17:12 --> URI Class Initialized
INFO - 2025-01-24 07:17:12 --> Router Class Initialized
INFO - 2025-01-24 07:17:12 --> Output Class Initialized
INFO - 2025-01-24 07:17:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:17:12 --> Input Class Initialized
INFO - 2025-01-24 07:17:12 --> Language Class Initialized
INFO - 2025-01-24 07:17:12 --> Loader Class Initialized
INFO - 2025-01-24 07:17:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:17:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:17:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:17:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:17:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:17:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:17:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:17:12 --> Upload Class Initialized
INFO - 2025-01-24 07:17:12 --> Email Class Initialized
INFO - 2025-01-24 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:17:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:17:12 --> Controller Class Initialized
INFO - 2025-01-24 12:47:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:47:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:47:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:18:12 --> Config Class Initialized
INFO - 2025-01-24 07:18:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:18:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:18:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:18:12 --> URI Class Initialized
INFO - 2025-01-24 07:18:12 --> Router Class Initialized
INFO - 2025-01-24 07:18:12 --> Output Class Initialized
INFO - 2025-01-24 07:18:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:18:12 --> Input Class Initialized
INFO - 2025-01-24 07:18:12 --> Language Class Initialized
INFO - 2025-01-24 07:18:12 --> Loader Class Initialized
INFO - 2025-01-24 07:18:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:18:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:18:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:18:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:18:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:18:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:18:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:18:12 --> Upload Class Initialized
INFO - 2025-01-24 07:18:12 --> Email Class Initialized
INFO - 2025-01-24 07:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:18:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:18:12 --> Controller Class Initialized
INFO - 2025-01-24 12:48:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:48:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:48:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:19:12 --> Config Class Initialized
INFO - 2025-01-24 07:19:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:19:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:19:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:19:12 --> URI Class Initialized
INFO - 2025-01-24 07:19:12 --> Router Class Initialized
INFO - 2025-01-24 07:19:12 --> Output Class Initialized
INFO - 2025-01-24 07:19:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:19:12 --> Input Class Initialized
INFO - 2025-01-24 07:19:12 --> Language Class Initialized
INFO - 2025-01-24 07:19:12 --> Loader Class Initialized
INFO - 2025-01-24 07:19:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:19:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:19:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:19:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:19:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:19:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:19:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:19:12 --> Upload Class Initialized
INFO - 2025-01-24 07:19:12 --> Email Class Initialized
INFO - 2025-01-24 07:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:19:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:19:12 --> Controller Class Initialized
INFO - 2025-01-24 12:49:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:49:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:49:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:20:12 --> Config Class Initialized
INFO - 2025-01-24 07:20:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:20:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:20:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:20:12 --> URI Class Initialized
INFO - 2025-01-24 07:20:12 --> Router Class Initialized
INFO - 2025-01-24 07:20:12 --> Output Class Initialized
INFO - 2025-01-24 07:20:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:20:12 --> Input Class Initialized
INFO - 2025-01-24 07:20:12 --> Language Class Initialized
INFO - 2025-01-24 07:20:12 --> Loader Class Initialized
INFO - 2025-01-24 07:20:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:20:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:20:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:20:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:20:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:20:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:20:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:20:12 --> Upload Class Initialized
INFO - 2025-01-24 07:20:12 --> Email Class Initialized
INFO - 2025-01-24 07:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:20:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:20:12 --> Controller Class Initialized
INFO - 2025-01-24 12:50:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:50:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:50:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:21:12 --> Config Class Initialized
INFO - 2025-01-24 07:21:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:21:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:21:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:21:12 --> URI Class Initialized
INFO - 2025-01-24 07:21:12 --> Router Class Initialized
INFO - 2025-01-24 07:21:12 --> Output Class Initialized
INFO - 2025-01-24 07:21:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:21:12 --> Input Class Initialized
INFO - 2025-01-24 07:21:12 --> Language Class Initialized
INFO - 2025-01-24 07:21:12 --> Loader Class Initialized
INFO - 2025-01-24 07:21:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:21:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:21:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:21:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:21:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:21:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:21:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:21:12 --> Upload Class Initialized
INFO - 2025-01-24 07:21:12 --> Email Class Initialized
INFO - 2025-01-24 07:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:21:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:21:12 --> Controller Class Initialized
INFO - 2025-01-24 12:51:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:51:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:51:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:22:12 --> Config Class Initialized
INFO - 2025-01-24 07:22:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:22:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:22:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:22:12 --> URI Class Initialized
INFO - 2025-01-24 07:22:12 --> Router Class Initialized
INFO - 2025-01-24 07:22:12 --> Output Class Initialized
INFO - 2025-01-24 07:22:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:22:12 --> Input Class Initialized
INFO - 2025-01-24 07:22:12 --> Language Class Initialized
INFO - 2025-01-24 07:22:12 --> Loader Class Initialized
INFO - 2025-01-24 07:22:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:22:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:22:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:22:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:22:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:22:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:22:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:22:12 --> Upload Class Initialized
INFO - 2025-01-24 07:22:12 --> Email Class Initialized
INFO - 2025-01-24 07:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:22:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:22:12 --> Controller Class Initialized
INFO - 2025-01-24 12:52:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:52:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:52:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:23:12 --> Config Class Initialized
INFO - 2025-01-24 07:23:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:23:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:23:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:23:12 --> URI Class Initialized
INFO - 2025-01-24 07:23:12 --> Router Class Initialized
INFO - 2025-01-24 07:23:12 --> Output Class Initialized
INFO - 2025-01-24 07:23:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:23:12 --> Input Class Initialized
INFO - 2025-01-24 07:23:12 --> Language Class Initialized
INFO - 2025-01-24 07:23:12 --> Loader Class Initialized
INFO - 2025-01-24 07:23:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:23:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:23:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:23:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:23:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:23:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:23:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:23:12 --> Upload Class Initialized
INFO - 2025-01-24 07:23:12 --> Email Class Initialized
INFO - 2025-01-24 07:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:23:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:23:12 --> Controller Class Initialized
INFO - 2025-01-24 12:53:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:53:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:53:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:24:12 --> Config Class Initialized
INFO - 2025-01-24 07:24:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:24:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:24:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:24:12 --> URI Class Initialized
INFO - 2025-01-24 07:24:12 --> Router Class Initialized
INFO - 2025-01-24 07:24:12 --> Output Class Initialized
INFO - 2025-01-24 07:24:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:24:12 --> Input Class Initialized
INFO - 2025-01-24 07:24:12 --> Language Class Initialized
INFO - 2025-01-24 07:24:12 --> Loader Class Initialized
INFO - 2025-01-24 07:24:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:24:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:24:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:24:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:24:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:24:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:24:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:24:12 --> Upload Class Initialized
INFO - 2025-01-24 07:24:12 --> Email Class Initialized
INFO - 2025-01-24 07:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:24:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:24:12 --> Controller Class Initialized
INFO - 2025-01-24 12:54:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:54:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:54:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:25:12 --> Config Class Initialized
INFO - 2025-01-24 07:25:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:25:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:25:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:25:12 --> URI Class Initialized
INFO - 2025-01-24 07:25:12 --> Router Class Initialized
INFO - 2025-01-24 07:25:12 --> Output Class Initialized
INFO - 2025-01-24 07:25:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:25:12 --> Input Class Initialized
INFO - 2025-01-24 07:25:12 --> Language Class Initialized
INFO - 2025-01-24 07:25:12 --> Loader Class Initialized
INFO - 2025-01-24 07:25:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:25:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:25:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:25:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:25:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:25:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:25:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:25:12 --> Upload Class Initialized
INFO - 2025-01-24 07:25:12 --> Email Class Initialized
INFO - 2025-01-24 07:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:25:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:25:12 --> Controller Class Initialized
INFO - 2025-01-24 12:55:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:55:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:55:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:26:12 --> Config Class Initialized
INFO - 2025-01-24 07:26:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:26:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:26:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:26:12 --> URI Class Initialized
INFO - 2025-01-24 07:26:12 --> Router Class Initialized
INFO - 2025-01-24 07:26:12 --> Output Class Initialized
INFO - 2025-01-24 07:26:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:26:12 --> Input Class Initialized
INFO - 2025-01-24 07:26:12 --> Language Class Initialized
INFO - 2025-01-24 07:26:12 --> Loader Class Initialized
INFO - 2025-01-24 07:26:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:26:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:26:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:26:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:26:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:26:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:26:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:26:12 --> Upload Class Initialized
INFO - 2025-01-24 07:26:12 --> Email Class Initialized
INFO - 2025-01-24 07:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:26:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:26:12 --> Controller Class Initialized
INFO - 2025-01-24 12:56:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:56:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:56:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:27:12 --> Config Class Initialized
INFO - 2025-01-24 07:27:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:27:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:27:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:27:12 --> URI Class Initialized
INFO - 2025-01-24 07:27:12 --> Router Class Initialized
INFO - 2025-01-24 07:27:12 --> Output Class Initialized
INFO - 2025-01-24 07:27:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:27:12 --> Input Class Initialized
INFO - 2025-01-24 07:27:12 --> Language Class Initialized
INFO - 2025-01-24 07:27:12 --> Loader Class Initialized
INFO - 2025-01-24 07:27:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:27:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:27:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:27:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:27:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:27:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:27:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:27:12 --> Upload Class Initialized
INFO - 2025-01-24 07:27:12 --> Email Class Initialized
INFO - 2025-01-24 07:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:27:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:27:12 --> Controller Class Initialized
INFO - 2025-01-24 12:57:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:57:12 --> Model "MainModel" initialized
INFO - 2025-01-24 12:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:57:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:29:15 --> Config Class Initialized
INFO - 2025-01-24 07:29:15 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:29:15 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:29:15 --> Utf8 Class Initialized
INFO - 2025-01-24 07:29:15 --> URI Class Initialized
INFO - 2025-01-24 07:29:15 --> Router Class Initialized
INFO - 2025-01-24 07:29:15 --> Output Class Initialized
INFO - 2025-01-24 07:29:15 --> Security Class Initialized
DEBUG - 2025-01-24 07:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:29:15 --> Input Class Initialized
INFO - 2025-01-24 07:29:15 --> Language Class Initialized
INFO - 2025-01-24 07:29:15 --> Loader Class Initialized
INFO - 2025-01-24 07:29:15 --> Helper loaded: url_helper
INFO - 2025-01-24 07:29:15 --> Helper loaded: html_helper
INFO - 2025-01-24 07:29:15 --> Helper loaded: file_helper
INFO - 2025-01-24 07:29:15 --> Helper loaded: string_helper
INFO - 2025-01-24 07:29:15 --> Helper loaded: form_helper
INFO - 2025-01-24 07:29:15 --> Helper loaded: my_helper
INFO - 2025-01-24 07:29:15 --> Database Driver Class Initialized
INFO - 2025-01-24 07:29:15 --> Upload Class Initialized
INFO - 2025-01-24 07:29:15 --> Email Class Initialized
INFO - 2025-01-24 07:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:29:16 --> Form Validation Class Initialized
INFO - 2025-01-24 07:29:16 --> Controller Class Initialized
INFO - 2025-01-24 12:59:16 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 12:59:16 --> Model "MainModel" initialized
INFO - 2025-01-24 12:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 12:59:16 --> Pagination Class Initialized
INFO - 2025-01-24 07:30:12 --> Config Class Initialized
INFO - 2025-01-24 07:30:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:30:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:30:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:30:12 --> URI Class Initialized
INFO - 2025-01-24 07:30:12 --> Router Class Initialized
INFO - 2025-01-24 07:30:12 --> Output Class Initialized
INFO - 2025-01-24 07:30:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:30:12 --> Input Class Initialized
INFO - 2025-01-24 07:30:12 --> Language Class Initialized
INFO - 2025-01-24 07:30:12 --> Loader Class Initialized
INFO - 2025-01-24 07:30:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:30:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:30:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:30:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:30:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:30:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:30:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:30:12 --> Upload Class Initialized
INFO - 2025-01-24 07:30:12 --> Email Class Initialized
INFO - 2025-01-24 07:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:30:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:30:12 --> Controller Class Initialized
INFO - 2025-01-24 13:00:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:00:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:00:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:31:12 --> Config Class Initialized
INFO - 2025-01-24 07:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:31:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:31:12 --> URI Class Initialized
INFO - 2025-01-24 07:31:12 --> Router Class Initialized
INFO - 2025-01-24 07:31:12 --> Output Class Initialized
INFO - 2025-01-24 07:31:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:31:12 --> Input Class Initialized
INFO - 2025-01-24 07:31:12 --> Language Class Initialized
INFO - 2025-01-24 07:31:12 --> Loader Class Initialized
INFO - 2025-01-24 07:31:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:31:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:31:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:31:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:31:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:31:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:31:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:31:12 --> Upload Class Initialized
INFO - 2025-01-24 07:31:12 --> Email Class Initialized
INFO - 2025-01-24 07:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:31:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:31:12 --> Controller Class Initialized
INFO - 2025-01-24 13:01:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:01:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:01:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:32:12 --> Config Class Initialized
INFO - 2025-01-24 07:32:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:32:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:32:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:32:12 --> URI Class Initialized
INFO - 2025-01-24 07:32:12 --> Router Class Initialized
INFO - 2025-01-24 07:32:12 --> Output Class Initialized
INFO - 2025-01-24 07:32:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:32:12 --> Input Class Initialized
INFO - 2025-01-24 07:32:12 --> Language Class Initialized
INFO - 2025-01-24 07:32:12 --> Loader Class Initialized
INFO - 2025-01-24 07:32:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:32:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:32:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:32:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:32:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:32:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:32:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:32:12 --> Upload Class Initialized
INFO - 2025-01-24 07:32:12 --> Email Class Initialized
INFO - 2025-01-24 07:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:32:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:32:12 --> Controller Class Initialized
INFO - 2025-01-24 13:02:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:02:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:02:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:33:12 --> Config Class Initialized
INFO - 2025-01-24 07:33:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:33:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:33:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:33:12 --> URI Class Initialized
INFO - 2025-01-24 07:33:12 --> Router Class Initialized
INFO - 2025-01-24 07:33:12 --> Output Class Initialized
INFO - 2025-01-24 07:33:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:33:12 --> Input Class Initialized
INFO - 2025-01-24 07:33:12 --> Language Class Initialized
INFO - 2025-01-24 07:33:12 --> Loader Class Initialized
INFO - 2025-01-24 07:33:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:33:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:33:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:33:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:33:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:33:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:33:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:33:12 --> Upload Class Initialized
INFO - 2025-01-24 07:33:12 --> Email Class Initialized
INFO - 2025-01-24 07:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:33:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:33:12 --> Controller Class Initialized
INFO - 2025-01-24 13:03:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:03:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:03:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:34:12 --> Config Class Initialized
INFO - 2025-01-24 07:34:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:34:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:34:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:34:12 --> URI Class Initialized
INFO - 2025-01-24 07:34:12 --> Router Class Initialized
INFO - 2025-01-24 07:34:12 --> Output Class Initialized
INFO - 2025-01-24 07:34:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:34:12 --> Input Class Initialized
INFO - 2025-01-24 07:34:12 --> Language Class Initialized
INFO - 2025-01-24 07:34:12 --> Loader Class Initialized
INFO - 2025-01-24 07:34:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:34:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:34:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:34:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:34:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:34:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:34:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:34:12 --> Upload Class Initialized
INFO - 2025-01-24 07:34:12 --> Email Class Initialized
INFO - 2025-01-24 07:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:34:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:34:12 --> Controller Class Initialized
INFO - 2025-01-24 13:04:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:04:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:04:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:35:12 --> Config Class Initialized
INFO - 2025-01-24 07:35:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:35:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:35:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:35:12 --> URI Class Initialized
INFO - 2025-01-24 07:35:12 --> Router Class Initialized
INFO - 2025-01-24 07:35:12 --> Output Class Initialized
INFO - 2025-01-24 07:35:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:35:12 --> Input Class Initialized
INFO - 2025-01-24 07:35:12 --> Language Class Initialized
INFO - 2025-01-24 07:35:12 --> Loader Class Initialized
INFO - 2025-01-24 07:35:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:35:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:35:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:35:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:35:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:35:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:35:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:35:12 --> Upload Class Initialized
INFO - 2025-01-24 07:35:12 --> Email Class Initialized
INFO - 2025-01-24 07:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:35:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:35:12 --> Controller Class Initialized
INFO - 2025-01-24 13:05:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:05:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:05:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:36:12 --> Config Class Initialized
INFO - 2025-01-24 07:36:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:36:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:36:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:36:12 --> URI Class Initialized
INFO - 2025-01-24 07:36:12 --> Router Class Initialized
INFO - 2025-01-24 07:36:12 --> Output Class Initialized
INFO - 2025-01-24 07:36:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:36:12 --> Input Class Initialized
INFO - 2025-01-24 07:36:12 --> Language Class Initialized
INFO - 2025-01-24 07:36:12 --> Loader Class Initialized
INFO - 2025-01-24 07:36:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:36:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:36:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:36:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:36:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:36:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:36:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:36:12 --> Upload Class Initialized
INFO - 2025-01-24 07:36:12 --> Email Class Initialized
INFO - 2025-01-24 07:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:36:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:36:12 --> Controller Class Initialized
INFO - 2025-01-24 13:06:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:06:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:06:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:37:12 --> Config Class Initialized
INFO - 2025-01-24 07:37:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:37:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:37:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:37:12 --> URI Class Initialized
INFO - 2025-01-24 07:37:12 --> Router Class Initialized
INFO - 2025-01-24 07:37:12 --> Output Class Initialized
INFO - 2025-01-24 07:37:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:37:12 --> Input Class Initialized
INFO - 2025-01-24 07:37:12 --> Language Class Initialized
INFO - 2025-01-24 07:37:12 --> Loader Class Initialized
INFO - 2025-01-24 07:37:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:37:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:37:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:37:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:37:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:37:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:37:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:37:12 --> Upload Class Initialized
INFO - 2025-01-24 07:37:12 --> Email Class Initialized
INFO - 2025-01-24 07:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:37:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:37:12 --> Controller Class Initialized
INFO - 2025-01-24 13:07:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:07:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:07:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:38:12 --> Config Class Initialized
INFO - 2025-01-24 07:38:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:38:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:38:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:38:12 --> URI Class Initialized
INFO - 2025-01-24 07:38:12 --> Router Class Initialized
INFO - 2025-01-24 07:38:12 --> Output Class Initialized
INFO - 2025-01-24 07:38:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:38:12 --> Input Class Initialized
INFO - 2025-01-24 07:38:12 --> Language Class Initialized
INFO - 2025-01-24 07:38:12 --> Loader Class Initialized
INFO - 2025-01-24 07:38:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:38:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:38:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:38:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:38:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:38:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:38:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:38:12 --> Upload Class Initialized
INFO - 2025-01-24 07:38:12 --> Email Class Initialized
INFO - 2025-01-24 07:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:38:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:38:12 --> Controller Class Initialized
INFO - 2025-01-24 13:08:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:08:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:08:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:39:12 --> Config Class Initialized
INFO - 2025-01-24 07:39:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:39:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:39:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:39:12 --> URI Class Initialized
INFO - 2025-01-24 07:39:12 --> Router Class Initialized
INFO - 2025-01-24 07:39:12 --> Output Class Initialized
INFO - 2025-01-24 07:39:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:39:12 --> Input Class Initialized
INFO - 2025-01-24 07:39:12 --> Language Class Initialized
INFO - 2025-01-24 07:39:12 --> Loader Class Initialized
INFO - 2025-01-24 07:39:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:39:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:39:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:39:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:39:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:39:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:39:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:39:12 --> Upload Class Initialized
INFO - 2025-01-24 07:39:12 --> Email Class Initialized
INFO - 2025-01-24 07:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:39:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:39:12 --> Controller Class Initialized
INFO - 2025-01-24 13:09:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:09:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:09:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:40:12 --> Config Class Initialized
INFO - 2025-01-24 07:40:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:40:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:40:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:40:12 --> URI Class Initialized
INFO - 2025-01-24 07:40:12 --> Router Class Initialized
INFO - 2025-01-24 07:40:12 --> Output Class Initialized
INFO - 2025-01-24 07:40:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:40:12 --> Input Class Initialized
INFO - 2025-01-24 07:40:12 --> Language Class Initialized
INFO - 2025-01-24 07:40:12 --> Loader Class Initialized
INFO - 2025-01-24 07:40:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:40:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:40:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:40:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:40:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:40:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:40:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:40:12 --> Upload Class Initialized
INFO - 2025-01-24 07:40:12 --> Email Class Initialized
INFO - 2025-01-24 07:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:40:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:40:12 --> Controller Class Initialized
INFO - 2025-01-24 13:10:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:10:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:10:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:41:12 --> Config Class Initialized
INFO - 2025-01-24 07:41:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:41:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:41:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:41:12 --> URI Class Initialized
INFO - 2025-01-24 07:41:12 --> Router Class Initialized
INFO - 2025-01-24 07:41:12 --> Output Class Initialized
INFO - 2025-01-24 07:41:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:41:12 --> Input Class Initialized
INFO - 2025-01-24 07:41:12 --> Language Class Initialized
INFO - 2025-01-24 07:41:12 --> Loader Class Initialized
INFO - 2025-01-24 07:41:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:41:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:41:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:41:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:41:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:41:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:41:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:41:12 --> Upload Class Initialized
INFO - 2025-01-24 07:41:12 --> Email Class Initialized
INFO - 2025-01-24 07:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:41:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:41:12 --> Controller Class Initialized
INFO - 2025-01-24 13:11:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:11:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:11:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:42:12 --> Config Class Initialized
INFO - 2025-01-24 07:42:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:42:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:42:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:42:12 --> URI Class Initialized
INFO - 2025-01-24 07:42:12 --> Router Class Initialized
INFO - 2025-01-24 07:42:12 --> Output Class Initialized
INFO - 2025-01-24 07:42:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:42:12 --> Input Class Initialized
INFO - 2025-01-24 07:42:12 --> Language Class Initialized
INFO - 2025-01-24 07:42:12 --> Loader Class Initialized
INFO - 2025-01-24 07:42:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:42:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:42:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:42:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:42:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:42:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:42:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:42:12 --> Upload Class Initialized
INFO - 2025-01-24 07:42:12 --> Email Class Initialized
INFO - 2025-01-24 07:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:42:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:42:12 --> Controller Class Initialized
INFO - 2025-01-24 13:12:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:12:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:12:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:43:12 --> Config Class Initialized
INFO - 2025-01-24 07:43:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:43:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:43:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:43:12 --> URI Class Initialized
INFO - 2025-01-24 07:43:12 --> Router Class Initialized
INFO - 2025-01-24 07:43:12 --> Output Class Initialized
INFO - 2025-01-24 07:43:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:43:12 --> Input Class Initialized
INFO - 2025-01-24 07:43:12 --> Language Class Initialized
INFO - 2025-01-24 07:43:12 --> Loader Class Initialized
INFO - 2025-01-24 07:43:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:43:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:43:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:43:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:43:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:43:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:43:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:43:12 --> Upload Class Initialized
INFO - 2025-01-24 07:43:12 --> Email Class Initialized
INFO - 2025-01-24 07:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:43:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:43:12 --> Controller Class Initialized
INFO - 2025-01-24 13:13:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:13:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:13:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:44:12 --> Config Class Initialized
INFO - 2025-01-24 07:44:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:44:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:44:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:44:12 --> URI Class Initialized
INFO - 2025-01-24 07:44:12 --> Router Class Initialized
INFO - 2025-01-24 07:44:12 --> Output Class Initialized
INFO - 2025-01-24 07:44:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:44:12 --> Input Class Initialized
INFO - 2025-01-24 07:44:12 --> Language Class Initialized
INFO - 2025-01-24 07:44:12 --> Loader Class Initialized
INFO - 2025-01-24 07:44:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:44:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:44:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:44:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:44:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:44:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:44:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:44:12 --> Upload Class Initialized
INFO - 2025-01-24 07:44:12 --> Email Class Initialized
INFO - 2025-01-24 07:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:44:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:44:12 --> Controller Class Initialized
INFO - 2025-01-24 13:14:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:14:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:14:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:45:12 --> Config Class Initialized
INFO - 2025-01-24 07:45:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:45:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:45:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:45:12 --> URI Class Initialized
INFO - 2025-01-24 07:45:12 --> Router Class Initialized
INFO - 2025-01-24 07:45:12 --> Output Class Initialized
INFO - 2025-01-24 07:45:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:45:12 --> Input Class Initialized
INFO - 2025-01-24 07:45:12 --> Language Class Initialized
INFO - 2025-01-24 07:45:12 --> Loader Class Initialized
INFO - 2025-01-24 07:45:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:45:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:45:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:45:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:45:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:45:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:45:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:45:12 --> Upload Class Initialized
INFO - 2025-01-24 07:45:12 --> Email Class Initialized
INFO - 2025-01-24 07:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:45:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:45:12 --> Controller Class Initialized
INFO - 2025-01-24 13:15:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:15:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:15:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:46:12 --> Config Class Initialized
INFO - 2025-01-24 07:46:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:46:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:46:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:46:12 --> URI Class Initialized
INFO - 2025-01-24 07:46:12 --> Router Class Initialized
INFO - 2025-01-24 07:46:12 --> Output Class Initialized
INFO - 2025-01-24 07:46:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:46:12 --> Input Class Initialized
INFO - 2025-01-24 07:46:12 --> Language Class Initialized
INFO - 2025-01-24 07:46:12 --> Loader Class Initialized
INFO - 2025-01-24 07:46:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:46:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:46:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:46:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:46:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:46:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:46:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:46:12 --> Upload Class Initialized
INFO - 2025-01-24 07:46:12 --> Email Class Initialized
INFO - 2025-01-24 07:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:46:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:46:12 --> Controller Class Initialized
INFO - 2025-01-24 13:16:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:16:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:16:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:47:12 --> Config Class Initialized
INFO - 2025-01-24 07:47:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:47:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:47:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:47:12 --> URI Class Initialized
INFO - 2025-01-24 07:47:12 --> Router Class Initialized
INFO - 2025-01-24 07:47:12 --> Output Class Initialized
INFO - 2025-01-24 07:47:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:47:12 --> Input Class Initialized
INFO - 2025-01-24 07:47:12 --> Language Class Initialized
INFO - 2025-01-24 07:47:12 --> Loader Class Initialized
INFO - 2025-01-24 07:47:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:47:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:47:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:47:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:47:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:47:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:47:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:47:12 --> Upload Class Initialized
INFO - 2025-01-24 07:47:12 --> Email Class Initialized
INFO - 2025-01-24 07:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:47:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:47:12 --> Controller Class Initialized
INFO - 2025-01-24 13:17:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:17:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:17:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:48:12 --> Config Class Initialized
INFO - 2025-01-24 07:48:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:48:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:48:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:48:12 --> URI Class Initialized
INFO - 2025-01-24 07:48:12 --> Router Class Initialized
INFO - 2025-01-24 07:48:12 --> Output Class Initialized
INFO - 2025-01-24 07:48:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:48:12 --> Input Class Initialized
INFO - 2025-01-24 07:48:12 --> Language Class Initialized
INFO - 2025-01-24 07:48:12 --> Loader Class Initialized
INFO - 2025-01-24 07:48:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:48:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:48:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:48:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:48:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:48:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:48:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:48:12 --> Upload Class Initialized
INFO - 2025-01-24 07:48:12 --> Email Class Initialized
INFO - 2025-01-24 07:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:48:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:48:12 --> Controller Class Initialized
INFO - 2025-01-24 13:18:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:18:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:18:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:49:12 --> Config Class Initialized
INFO - 2025-01-24 07:49:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:49:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:49:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:49:12 --> URI Class Initialized
INFO - 2025-01-24 07:49:12 --> Router Class Initialized
INFO - 2025-01-24 07:49:12 --> Output Class Initialized
INFO - 2025-01-24 07:49:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:49:12 --> Input Class Initialized
INFO - 2025-01-24 07:49:12 --> Language Class Initialized
INFO - 2025-01-24 07:49:12 --> Loader Class Initialized
INFO - 2025-01-24 07:49:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:49:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:49:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:49:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:49:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:49:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:49:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:49:12 --> Upload Class Initialized
INFO - 2025-01-24 07:49:12 --> Email Class Initialized
INFO - 2025-01-24 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:49:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:49:12 --> Controller Class Initialized
INFO - 2025-01-24 13:19:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:19:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:19:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:50:12 --> Config Class Initialized
INFO - 2025-01-24 07:50:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:50:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:50:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:50:12 --> URI Class Initialized
INFO - 2025-01-24 07:50:12 --> Router Class Initialized
INFO - 2025-01-24 07:50:12 --> Output Class Initialized
INFO - 2025-01-24 07:50:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:50:12 --> Input Class Initialized
INFO - 2025-01-24 07:50:12 --> Language Class Initialized
INFO - 2025-01-24 07:50:12 --> Loader Class Initialized
INFO - 2025-01-24 07:50:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:50:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:50:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:50:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:50:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:50:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:50:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:50:12 --> Upload Class Initialized
INFO - 2025-01-24 07:50:12 --> Email Class Initialized
INFO - 2025-01-24 07:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:50:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:50:12 --> Controller Class Initialized
INFO - 2025-01-24 13:20:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:20:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:20:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:51:12 --> Config Class Initialized
INFO - 2025-01-24 07:51:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:51:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:51:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:51:12 --> URI Class Initialized
INFO - 2025-01-24 07:51:12 --> Router Class Initialized
INFO - 2025-01-24 07:51:12 --> Output Class Initialized
INFO - 2025-01-24 07:51:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:51:12 --> Input Class Initialized
INFO - 2025-01-24 07:51:12 --> Language Class Initialized
INFO - 2025-01-24 07:51:12 --> Loader Class Initialized
INFO - 2025-01-24 07:51:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:51:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:51:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:51:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:51:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:51:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:51:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:51:12 --> Upload Class Initialized
INFO - 2025-01-24 07:51:12 --> Email Class Initialized
INFO - 2025-01-24 07:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:51:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:51:12 --> Controller Class Initialized
INFO - 2025-01-24 13:21:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:21:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:21:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:52:12 --> Config Class Initialized
INFO - 2025-01-24 07:52:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:52:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:52:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:52:12 --> URI Class Initialized
INFO - 2025-01-24 07:52:12 --> Router Class Initialized
INFO - 2025-01-24 07:52:12 --> Output Class Initialized
INFO - 2025-01-24 07:52:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:52:12 --> Input Class Initialized
INFO - 2025-01-24 07:52:12 --> Language Class Initialized
INFO - 2025-01-24 07:52:12 --> Loader Class Initialized
INFO - 2025-01-24 07:52:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:52:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:52:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:52:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:52:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:52:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:52:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:52:12 --> Upload Class Initialized
INFO - 2025-01-24 07:52:12 --> Email Class Initialized
INFO - 2025-01-24 07:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:52:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:52:12 --> Controller Class Initialized
INFO - 2025-01-24 13:22:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:22:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:22:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:53:12 --> Config Class Initialized
INFO - 2025-01-24 07:53:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:53:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:53:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:53:12 --> URI Class Initialized
INFO - 2025-01-24 07:53:12 --> Router Class Initialized
INFO - 2025-01-24 07:53:12 --> Output Class Initialized
INFO - 2025-01-24 07:53:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:53:12 --> Input Class Initialized
INFO - 2025-01-24 07:53:12 --> Language Class Initialized
INFO - 2025-01-24 07:53:12 --> Loader Class Initialized
INFO - 2025-01-24 07:53:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:53:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:53:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:53:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:53:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:53:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:53:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:53:12 --> Upload Class Initialized
INFO - 2025-01-24 07:53:12 --> Email Class Initialized
INFO - 2025-01-24 07:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:53:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:53:12 --> Controller Class Initialized
INFO - 2025-01-24 13:23:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:23:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:23:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:54:48 --> Config Class Initialized
INFO - 2025-01-24 07:54:48 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:54:48 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:54:48 --> Utf8 Class Initialized
INFO - 2025-01-24 07:54:48 --> URI Class Initialized
INFO - 2025-01-24 07:54:48 --> Router Class Initialized
INFO - 2025-01-24 07:54:48 --> Output Class Initialized
INFO - 2025-01-24 07:54:48 --> Security Class Initialized
DEBUG - 2025-01-24 07:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:54:48 --> Input Class Initialized
INFO - 2025-01-24 07:54:48 --> Language Class Initialized
INFO - 2025-01-24 07:54:48 --> Loader Class Initialized
INFO - 2025-01-24 07:54:48 --> Helper loaded: url_helper
INFO - 2025-01-24 07:54:48 --> Helper loaded: html_helper
INFO - 2025-01-24 07:54:48 --> Helper loaded: file_helper
INFO - 2025-01-24 07:54:48 --> Helper loaded: string_helper
INFO - 2025-01-24 07:54:48 --> Helper loaded: form_helper
INFO - 2025-01-24 07:54:48 --> Helper loaded: my_helper
INFO - 2025-01-24 07:54:48 --> Database Driver Class Initialized
INFO - 2025-01-24 07:54:48 --> Upload Class Initialized
INFO - 2025-01-24 07:54:48 --> Email Class Initialized
INFO - 2025-01-24 07:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:54:48 --> Form Validation Class Initialized
INFO - 2025-01-24 07:54:48 --> Controller Class Initialized
INFO - 2025-01-24 13:24:48 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:24:48 --> Model "MainModel" initialized
INFO - 2025-01-24 13:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:24:48 --> Pagination Class Initialized
INFO - 2025-01-24 07:55:12 --> Config Class Initialized
INFO - 2025-01-24 07:55:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:55:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:55:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:55:12 --> URI Class Initialized
INFO - 2025-01-24 07:55:12 --> Router Class Initialized
INFO - 2025-01-24 07:55:12 --> Output Class Initialized
INFO - 2025-01-24 07:55:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:55:12 --> Input Class Initialized
INFO - 2025-01-24 07:55:12 --> Language Class Initialized
INFO - 2025-01-24 07:55:12 --> Loader Class Initialized
INFO - 2025-01-24 07:55:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:55:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:55:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:55:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:55:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:55:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:55:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:55:12 --> Upload Class Initialized
INFO - 2025-01-24 07:55:12 --> Email Class Initialized
INFO - 2025-01-24 07:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:55:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:55:12 --> Controller Class Initialized
INFO - 2025-01-24 13:25:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:25:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:25:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:56:12 --> Config Class Initialized
INFO - 2025-01-24 07:56:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:56:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:56:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:56:12 --> URI Class Initialized
INFO - 2025-01-24 07:56:12 --> Router Class Initialized
INFO - 2025-01-24 07:56:12 --> Output Class Initialized
INFO - 2025-01-24 07:56:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:56:12 --> Input Class Initialized
INFO - 2025-01-24 07:56:12 --> Language Class Initialized
INFO - 2025-01-24 07:56:12 --> Loader Class Initialized
INFO - 2025-01-24 07:56:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:56:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:56:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:56:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:56:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:56:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:56:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:56:12 --> Upload Class Initialized
INFO - 2025-01-24 07:56:12 --> Email Class Initialized
INFO - 2025-01-24 07:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:56:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:56:12 --> Controller Class Initialized
INFO - 2025-01-24 13:26:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:26:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:26:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:57:12 --> Config Class Initialized
INFO - 2025-01-24 07:57:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:57:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:57:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:57:12 --> URI Class Initialized
INFO - 2025-01-24 07:57:12 --> Router Class Initialized
INFO - 2025-01-24 07:57:12 --> Output Class Initialized
INFO - 2025-01-24 07:57:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:57:12 --> Input Class Initialized
INFO - 2025-01-24 07:57:12 --> Language Class Initialized
INFO - 2025-01-24 07:57:12 --> Loader Class Initialized
INFO - 2025-01-24 07:57:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:57:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:57:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:57:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:57:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:57:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:57:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:57:12 --> Upload Class Initialized
INFO - 2025-01-24 07:57:12 --> Email Class Initialized
INFO - 2025-01-24 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:57:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:57:12 --> Controller Class Initialized
INFO - 2025-01-24 13:27:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:27:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:27:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:58:12 --> Config Class Initialized
INFO - 2025-01-24 07:58:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:58:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:58:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:58:12 --> URI Class Initialized
INFO - 2025-01-24 07:58:12 --> Router Class Initialized
INFO - 2025-01-24 07:58:12 --> Output Class Initialized
INFO - 2025-01-24 07:58:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:58:12 --> Input Class Initialized
INFO - 2025-01-24 07:58:12 --> Language Class Initialized
INFO - 2025-01-24 07:58:12 --> Loader Class Initialized
INFO - 2025-01-24 07:58:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:58:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:58:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:58:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:58:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:58:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:58:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:58:12 --> Upload Class Initialized
INFO - 2025-01-24 07:58:12 --> Email Class Initialized
INFO - 2025-01-24 07:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:58:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:58:12 --> Controller Class Initialized
INFO - 2025-01-24 13:28:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:28:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:28:12 --> Pagination Class Initialized
INFO - 2025-01-24 07:59:12 --> Config Class Initialized
INFO - 2025-01-24 07:59:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 07:59:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 07:59:12 --> Utf8 Class Initialized
INFO - 2025-01-24 07:59:12 --> URI Class Initialized
INFO - 2025-01-24 07:59:12 --> Router Class Initialized
INFO - 2025-01-24 07:59:12 --> Output Class Initialized
INFO - 2025-01-24 07:59:12 --> Security Class Initialized
DEBUG - 2025-01-24 07:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 07:59:12 --> Input Class Initialized
INFO - 2025-01-24 07:59:12 --> Language Class Initialized
INFO - 2025-01-24 07:59:12 --> Loader Class Initialized
INFO - 2025-01-24 07:59:12 --> Helper loaded: url_helper
INFO - 2025-01-24 07:59:12 --> Helper loaded: html_helper
INFO - 2025-01-24 07:59:12 --> Helper loaded: file_helper
INFO - 2025-01-24 07:59:12 --> Helper loaded: string_helper
INFO - 2025-01-24 07:59:12 --> Helper loaded: form_helper
INFO - 2025-01-24 07:59:12 --> Helper loaded: my_helper
INFO - 2025-01-24 07:59:12 --> Database Driver Class Initialized
INFO - 2025-01-24 07:59:12 --> Upload Class Initialized
INFO - 2025-01-24 07:59:12 --> Email Class Initialized
INFO - 2025-01-24 07:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 07:59:12 --> Form Validation Class Initialized
INFO - 2025-01-24 07:59:12 --> Controller Class Initialized
INFO - 2025-01-24 13:29:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:29:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:29:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:00:12 --> Config Class Initialized
INFO - 2025-01-24 08:00:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:00:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:00:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:00:12 --> URI Class Initialized
INFO - 2025-01-24 08:00:12 --> Router Class Initialized
INFO - 2025-01-24 08:00:12 --> Output Class Initialized
INFO - 2025-01-24 08:00:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:00:12 --> Input Class Initialized
INFO - 2025-01-24 08:00:12 --> Language Class Initialized
INFO - 2025-01-24 08:00:12 --> Loader Class Initialized
INFO - 2025-01-24 08:00:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:00:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:00:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:00:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:00:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:00:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:00:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:00:12 --> Upload Class Initialized
INFO - 2025-01-24 08:00:12 --> Email Class Initialized
INFO - 2025-01-24 08:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:00:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:00:12 --> Controller Class Initialized
INFO - 2025-01-24 13:30:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:30:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:30:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:04:39 --> Config Class Initialized
INFO - 2025-01-24 08:04:39 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:04:39 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:04:39 --> Utf8 Class Initialized
INFO - 2025-01-24 08:04:39 --> URI Class Initialized
INFO - 2025-01-24 08:04:39 --> Router Class Initialized
INFO - 2025-01-24 08:04:39 --> Output Class Initialized
INFO - 2025-01-24 08:04:39 --> Security Class Initialized
DEBUG - 2025-01-24 08:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:04:39 --> Input Class Initialized
INFO - 2025-01-24 08:04:39 --> Language Class Initialized
INFO - 2025-01-24 08:04:39 --> Loader Class Initialized
INFO - 2025-01-24 08:04:39 --> Helper loaded: url_helper
INFO - 2025-01-24 08:04:39 --> Helper loaded: html_helper
INFO - 2025-01-24 08:04:39 --> Helper loaded: file_helper
INFO - 2025-01-24 08:04:39 --> Helper loaded: string_helper
INFO - 2025-01-24 08:04:39 --> Helper loaded: form_helper
INFO - 2025-01-24 08:04:39 --> Helper loaded: my_helper
INFO - 2025-01-24 08:04:39 --> Database Driver Class Initialized
INFO - 2025-01-24 08:04:39 --> Upload Class Initialized
INFO - 2025-01-24 08:04:39 --> Email Class Initialized
INFO - 2025-01-24 08:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:04:39 --> Form Validation Class Initialized
INFO - 2025-01-24 08:04:39 --> Controller Class Initialized
INFO - 2025-01-24 13:34:39 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:34:39 --> Model "MainModel" initialized
INFO - 2025-01-24 13:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:34:39 --> Pagination Class Initialized
INFO - 2025-01-24 08:05:12 --> Config Class Initialized
INFO - 2025-01-24 08:05:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:05:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:05:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:05:12 --> URI Class Initialized
INFO - 2025-01-24 08:05:12 --> Router Class Initialized
INFO - 2025-01-24 08:05:12 --> Output Class Initialized
INFO - 2025-01-24 08:05:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:05:12 --> Input Class Initialized
INFO - 2025-01-24 08:05:12 --> Language Class Initialized
INFO - 2025-01-24 08:05:12 --> Loader Class Initialized
INFO - 2025-01-24 08:05:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:05:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:05:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:05:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:05:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:05:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:05:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:05:12 --> Upload Class Initialized
INFO - 2025-01-24 08:05:12 --> Email Class Initialized
INFO - 2025-01-24 08:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:05:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:05:12 --> Controller Class Initialized
INFO - 2025-01-24 13:35:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:35:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:35:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:06:12 --> Config Class Initialized
INFO - 2025-01-24 08:06:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:06:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:06:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:06:12 --> URI Class Initialized
INFO - 2025-01-24 08:06:12 --> Router Class Initialized
INFO - 2025-01-24 08:06:12 --> Output Class Initialized
INFO - 2025-01-24 08:06:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:06:12 --> Input Class Initialized
INFO - 2025-01-24 08:06:12 --> Language Class Initialized
INFO - 2025-01-24 08:06:12 --> Loader Class Initialized
INFO - 2025-01-24 08:06:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:06:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:06:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:06:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:06:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:06:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:06:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:06:12 --> Upload Class Initialized
INFO - 2025-01-24 08:06:12 --> Email Class Initialized
INFO - 2025-01-24 08:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:06:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:06:12 --> Controller Class Initialized
INFO - 2025-01-24 13:36:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:36:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:36:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:07:12 --> Config Class Initialized
INFO - 2025-01-24 08:07:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:07:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:07:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:07:12 --> URI Class Initialized
INFO - 2025-01-24 08:07:12 --> Router Class Initialized
INFO - 2025-01-24 08:07:12 --> Output Class Initialized
INFO - 2025-01-24 08:07:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:07:12 --> Input Class Initialized
INFO - 2025-01-24 08:07:12 --> Language Class Initialized
INFO - 2025-01-24 08:07:12 --> Loader Class Initialized
INFO - 2025-01-24 08:07:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:07:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:07:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:07:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:07:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:07:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:07:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:07:12 --> Upload Class Initialized
INFO - 2025-01-24 08:07:12 --> Email Class Initialized
INFO - 2025-01-24 08:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:07:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:07:12 --> Controller Class Initialized
INFO - 2025-01-24 13:37:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:37:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:37:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:08:12 --> Config Class Initialized
INFO - 2025-01-24 08:08:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:08:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:08:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:08:12 --> URI Class Initialized
INFO - 2025-01-24 08:08:12 --> Router Class Initialized
INFO - 2025-01-24 08:08:12 --> Output Class Initialized
INFO - 2025-01-24 08:08:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:08:12 --> Input Class Initialized
INFO - 2025-01-24 08:08:12 --> Language Class Initialized
INFO - 2025-01-24 08:08:12 --> Loader Class Initialized
INFO - 2025-01-24 08:08:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:08:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:08:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:08:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:08:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:08:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:08:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:08:12 --> Upload Class Initialized
INFO - 2025-01-24 08:08:12 --> Email Class Initialized
INFO - 2025-01-24 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:08:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:08:12 --> Controller Class Initialized
INFO - 2025-01-24 13:38:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:38:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:38:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:09:12 --> Config Class Initialized
INFO - 2025-01-24 08:09:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:09:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:09:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:09:12 --> URI Class Initialized
INFO - 2025-01-24 08:09:12 --> Router Class Initialized
INFO - 2025-01-24 08:09:12 --> Output Class Initialized
INFO - 2025-01-24 08:09:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:09:12 --> Input Class Initialized
INFO - 2025-01-24 08:09:12 --> Language Class Initialized
INFO - 2025-01-24 08:09:12 --> Loader Class Initialized
INFO - 2025-01-24 08:09:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:09:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:09:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:09:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:09:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:09:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:09:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:09:12 --> Upload Class Initialized
INFO - 2025-01-24 08:09:12 --> Email Class Initialized
INFO - 2025-01-24 08:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:09:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:09:12 --> Controller Class Initialized
INFO - 2025-01-24 13:39:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:39:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:39:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:10:12 --> Config Class Initialized
INFO - 2025-01-24 08:10:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:10:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:10:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:10:12 --> URI Class Initialized
INFO - 2025-01-24 08:10:12 --> Router Class Initialized
INFO - 2025-01-24 08:10:12 --> Output Class Initialized
INFO - 2025-01-24 08:10:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:10:12 --> Input Class Initialized
INFO - 2025-01-24 08:10:12 --> Language Class Initialized
INFO - 2025-01-24 08:10:12 --> Loader Class Initialized
INFO - 2025-01-24 08:10:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:10:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:10:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:10:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:10:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:10:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:10:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:10:12 --> Upload Class Initialized
INFO - 2025-01-24 08:10:12 --> Email Class Initialized
INFO - 2025-01-24 08:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:10:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:10:12 --> Controller Class Initialized
INFO - 2025-01-24 13:40:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:40:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:40:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:11:12 --> Config Class Initialized
INFO - 2025-01-24 08:11:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:11:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:11:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:11:12 --> URI Class Initialized
INFO - 2025-01-24 08:11:12 --> Router Class Initialized
INFO - 2025-01-24 08:11:12 --> Output Class Initialized
INFO - 2025-01-24 08:11:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:11:12 --> Input Class Initialized
INFO - 2025-01-24 08:11:12 --> Language Class Initialized
INFO - 2025-01-24 08:11:12 --> Loader Class Initialized
INFO - 2025-01-24 08:11:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:11:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:11:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:11:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:11:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:11:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:11:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:11:12 --> Upload Class Initialized
INFO - 2025-01-24 08:11:12 --> Email Class Initialized
INFO - 2025-01-24 08:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:11:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:11:12 --> Controller Class Initialized
INFO - 2025-01-24 13:41:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:41:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:41:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:12:12 --> Config Class Initialized
INFO - 2025-01-24 08:12:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:12:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:12:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:12:12 --> URI Class Initialized
INFO - 2025-01-24 08:12:12 --> Router Class Initialized
INFO - 2025-01-24 08:12:12 --> Output Class Initialized
INFO - 2025-01-24 08:12:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:12:12 --> Input Class Initialized
INFO - 2025-01-24 08:12:12 --> Language Class Initialized
INFO - 2025-01-24 08:12:12 --> Loader Class Initialized
INFO - 2025-01-24 08:12:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:12:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:12:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:12:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:12:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:12:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:12:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:12:12 --> Upload Class Initialized
INFO - 2025-01-24 08:12:12 --> Email Class Initialized
INFO - 2025-01-24 08:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:12:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:12:12 --> Controller Class Initialized
INFO - 2025-01-24 13:42:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:42:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:42:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:13:12 --> Config Class Initialized
INFO - 2025-01-24 08:13:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:13:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:13:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:13:12 --> URI Class Initialized
INFO - 2025-01-24 08:13:12 --> Router Class Initialized
INFO - 2025-01-24 08:13:12 --> Output Class Initialized
INFO - 2025-01-24 08:13:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:13:12 --> Input Class Initialized
INFO - 2025-01-24 08:13:12 --> Language Class Initialized
INFO - 2025-01-24 08:13:12 --> Loader Class Initialized
INFO - 2025-01-24 08:13:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:13:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:13:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:13:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:13:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:13:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:13:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:13:12 --> Upload Class Initialized
INFO - 2025-01-24 08:13:12 --> Email Class Initialized
INFO - 2025-01-24 08:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:13:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:13:12 --> Controller Class Initialized
INFO - 2025-01-24 13:43:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:43:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:43:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:14:16 --> Config Class Initialized
INFO - 2025-01-24 08:14:16 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:14:16 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:14:16 --> Utf8 Class Initialized
INFO - 2025-01-24 08:14:16 --> URI Class Initialized
INFO - 2025-01-24 08:14:16 --> Router Class Initialized
INFO - 2025-01-24 08:14:16 --> Output Class Initialized
INFO - 2025-01-24 08:14:16 --> Security Class Initialized
DEBUG - 2025-01-24 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:14:16 --> Input Class Initialized
INFO - 2025-01-24 08:14:16 --> Language Class Initialized
INFO - 2025-01-24 08:14:16 --> Loader Class Initialized
INFO - 2025-01-24 08:14:16 --> Helper loaded: url_helper
INFO - 2025-01-24 08:14:16 --> Helper loaded: html_helper
INFO - 2025-01-24 08:14:16 --> Helper loaded: file_helper
INFO - 2025-01-24 08:14:16 --> Helper loaded: string_helper
INFO - 2025-01-24 08:14:16 --> Helper loaded: form_helper
INFO - 2025-01-24 08:14:16 --> Helper loaded: my_helper
INFO - 2025-01-24 08:14:16 --> Database Driver Class Initialized
INFO - 2025-01-24 08:14:16 --> Upload Class Initialized
INFO - 2025-01-24 08:14:16 --> Email Class Initialized
INFO - 2025-01-24 08:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:14:16 --> Form Validation Class Initialized
INFO - 2025-01-24 08:14:16 --> Controller Class Initialized
INFO - 2025-01-24 13:44:16 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:44:16 --> Model "MainModel" initialized
INFO - 2025-01-24 13:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:44:16 --> Pagination Class Initialized
INFO - 2025-01-24 08:15:12 --> Config Class Initialized
INFO - 2025-01-24 08:15:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:15:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:15:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:15:12 --> URI Class Initialized
INFO - 2025-01-24 08:15:12 --> Router Class Initialized
INFO - 2025-01-24 08:15:12 --> Output Class Initialized
INFO - 2025-01-24 08:15:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:15:12 --> Input Class Initialized
INFO - 2025-01-24 08:15:12 --> Language Class Initialized
INFO - 2025-01-24 08:15:12 --> Loader Class Initialized
INFO - 2025-01-24 08:15:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:15:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:15:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:15:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:15:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:15:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:15:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:15:12 --> Upload Class Initialized
INFO - 2025-01-24 08:15:12 --> Email Class Initialized
INFO - 2025-01-24 08:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:15:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:15:12 --> Controller Class Initialized
INFO - 2025-01-24 13:45:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:45:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:45:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:16:12 --> Config Class Initialized
INFO - 2025-01-24 08:16:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:16:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:16:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:16:12 --> URI Class Initialized
INFO - 2025-01-24 08:16:12 --> Router Class Initialized
INFO - 2025-01-24 08:16:12 --> Output Class Initialized
INFO - 2025-01-24 08:16:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:16:12 --> Input Class Initialized
INFO - 2025-01-24 08:16:12 --> Language Class Initialized
INFO - 2025-01-24 08:16:12 --> Loader Class Initialized
INFO - 2025-01-24 08:16:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:16:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:16:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:16:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:16:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:16:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:16:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:16:12 --> Upload Class Initialized
INFO - 2025-01-24 08:16:12 --> Email Class Initialized
INFO - 2025-01-24 08:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:16:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:16:12 --> Controller Class Initialized
INFO - 2025-01-24 13:46:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:46:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:46:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:17:12 --> Config Class Initialized
INFO - 2025-01-24 08:17:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:17:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:17:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:17:12 --> URI Class Initialized
INFO - 2025-01-24 08:17:12 --> Router Class Initialized
INFO - 2025-01-24 08:17:12 --> Output Class Initialized
INFO - 2025-01-24 08:17:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:17:12 --> Input Class Initialized
INFO - 2025-01-24 08:17:12 --> Language Class Initialized
INFO - 2025-01-24 08:17:12 --> Loader Class Initialized
INFO - 2025-01-24 08:17:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:17:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:17:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:17:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:17:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:17:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:17:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:17:12 --> Upload Class Initialized
INFO - 2025-01-24 08:17:12 --> Email Class Initialized
INFO - 2025-01-24 08:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:17:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:17:12 --> Controller Class Initialized
INFO - 2025-01-24 13:47:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:47:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:47:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:19:21 --> Config Class Initialized
INFO - 2025-01-24 08:19:21 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:19:21 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:19:21 --> Utf8 Class Initialized
INFO - 2025-01-24 08:19:21 --> URI Class Initialized
INFO - 2025-01-24 08:19:21 --> Router Class Initialized
INFO - 2025-01-24 08:19:21 --> Output Class Initialized
INFO - 2025-01-24 08:19:21 --> Security Class Initialized
DEBUG - 2025-01-24 08:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:19:21 --> Input Class Initialized
INFO - 2025-01-24 08:19:21 --> Language Class Initialized
INFO - 2025-01-24 08:19:21 --> Loader Class Initialized
INFO - 2025-01-24 08:19:21 --> Helper loaded: url_helper
INFO - 2025-01-24 08:19:21 --> Helper loaded: html_helper
INFO - 2025-01-24 08:19:21 --> Helper loaded: file_helper
INFO - 2025-01-24 08:19:21 --> Helper loaded: string_helper
INFO - 2025-01-24 08:19:21 --> Helper loaded: form_helper
INFO - 2025-01-24 08:19:21 --> Helper loaded: my_helper
INFO - 2025-01-24 08:19:21 --> Database Driver Class Initialized
INFO - 2025-01-24 08:19:21 --> Upload Class Initialized
INFO - 2025-01-24 08:19:21 --> Email Class Initialized
INFO - 2025-01-24 08:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:19:21 --> Form Validation Class Initialized
INFO - 2025-01-24 08:19:21 --> Controller Class Initialized
INFO - 2025-01-24 13:49:21 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:49:21 --> Model "MainModel" initialized
INFO - 2025-01-24 13:49:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:49:21 --> Pagination Class Initialized
INFO - 2025-01-24 08:20:12 --> Config Class Initialized
INFO - 2025-01-24 08:20:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:20:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:20:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:20:12 --> URI Class Initialized
INFO - 2025-01-24 08:20:12 --> Router Class Initialized
INFO - 2025-01-24 08:20:12 --> Output Class Initialized
INFO - 2025-01-24 08:20:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:20:12 --> Input Class Initialized
INFO - 2025-01-24 08:20:12 --> Language Class Initialized
INFO - 2025-01-24 08:20:12 --> Loader Class Initialized
INFO - 2025-01-24 08:20:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:20:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:20:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:20:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:20:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:20:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:20:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:20:12 --> Upload Class Initialized
INFO - 2025-01-24 08:20:12 --> Email Class Initialized
INFO - 2025-01-24 08:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:20:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:20:12 --> Controller Class Initialized
INFO - 2025-01-24 13:50:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:50:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:50:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:21:12 --> Config Class Initialized
INFO - 2025-01-24 08:21:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:21:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:21:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:21:12 --> URI Class Initialized
INFO - 2025-01-24 08:21:12 --> Router Class Initialized
INFO - 2025-01-24 08:21:12 --> Output Class Initialized
INFO - 2025-01-24 08:21:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:21:12 --> Input Class Initialized
INFO - 2025-01-24 08:21:12 --> Language Class Initialized
INFO - 2025-01-24 08:21:12 --> Loader Class Initialized
INFO - 2025-01-24 08:21:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:21:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:21:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:21:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:21:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:21:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:21:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:21:12 --> Upload Class Initialized
INFO - 2025-01-24 08:21:12 --> Email Class Initialized
INFO - 2025-01-24 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:21:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:21:12 --> Controller Class Initialized
INFO - 2025-01-24 13:51:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:51:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:51:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:22:12 --> Config Class Initialized
INFO - 2025-01-24 08:22:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:22:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:22:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:22:12 --> URI Class Initialized
INFO - 2025-01-24 08:22:12 --> Router Class Initialized
INFO - 2025-01-24 08:22:12 --> Output Class Initialized
INFO - 2025-01-24 08:22:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:22:12 --> Input Class Initialized
INFO - 2025-01-24 08:22:12 --> Language Class Initialized
INFO - 2025-01-24 08:22:12 --> Loader Class Initialized
INFO - 2025-01-24 08:22:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:22:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:22:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:22:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:22:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:22:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:22:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:22:12 --> Upload Class Initialized
INFO - 2025-01-24 08:22:12 --> Email Class Initialized
INFO - 2025-01-24 08:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:22:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:22:12 --> Controller Class Initialized
INFO - 2025-01-24 13:52:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:52:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:52:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:23:12 --> Config Class Initialized
INFO - 2025-01-24 08:23:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:23:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:23:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:23:12 --> URI Class Initialized
INFO - 2025-01-24 08:23:12 --> Router Class Initialized
INFO - 2025-01-24 08:23:12 --> Output Class Initialized
INFO - 2025-01-24 08:23:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:23:12 --> Input Class Initialized
INFO - 2025-01-24 08:23:12 --> Language Class Initialized
INFO - 2025-01-24 08:23:12 --> Loader Class Initialized
INFO - 2025-01-24 08:23:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:23:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:23:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:23:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:23:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:23:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:23:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:23:12 --> Upload Class Initialized
INFO - 2025-01-24 08:23:12 --> Email Class Initialized
INFO - 2025-01-24 08:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:23:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:23:12 --> Controller Class Initialized
INFO - 2025-01-24 13:53:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:53:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:53:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:24:12 --> Config Class Initialized
INFO - 2025-01-24 08:24:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:24:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:24:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:24:12 --> URI Class Initialized
INFO - 2025-01-24 08:24:12 --> Router Class Initialized
INFO - 2025-01-24 08:24:12 --> Output Class Initialized
INFO - 2025-01-24 08:24:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:24:12 --> Input Class Initialized
INFO - 2025-01-24 08:24:12 --> Language Class Initialized
INFO - 2025-01-24 08:24:12 --> Loader Class Initialized
INFO - 2025-01-24 08:24:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:24:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:24:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:24:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:24:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:24:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:24:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:24:12 --> Upload Class Initialized
INFO - 2025-01-24 08:24:12 --> Email Class Initialized
INFO - 2025-01-24 08:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:24:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:24:12 --> Controller Class Initialized
INFO - 2025-01-24 13:54:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:54:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:54:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:25:12 --> Config Class Initialized
INFO - 2025-01-24 08:25:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:25:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:25:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:25:12 --> URI Class Initialized
INFO - 2025-01-24 08:25:12 --> Router Class Initialized
INFO - 2025-01-24 08:25:12 --> Output Class Initialized
INFO - 2025-01-24 08:25:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:25:12 --> Input Class Initialized
INFO - 2025-01-24 08:25:12 --> Language Class Initialized
INFO - 2025-01-24 08:25:12 --> Loader Class Initialized
INFO - 2025-01-24 08:25:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:25:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:25:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:25:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:25:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:25:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:25:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:25:12 --> Upload Class Initialized
INFO - 2025-01-24 08:25:12 --> Email Class Initialized
INFO - 2025-01-24 08:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:25:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:25:12 --> Controller Class Initialized
INFO - 2025-01-24 13:55:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:55:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:55:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:26:12 --> Config Class Initialized
INFO - 2025-01-24 08:26:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:26:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:26:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:26:12 --> URI Class Initialized
INFO - 2025-01-24 08:26:12 --> Router Class Initialized
INFO - 2025-01-24 08:26:12 --> Output Class Initialized
INFO - 2025-01-24 08:26:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:26:12 --> Input Class Initialized
INFO - 2025-01-24 08:26:12 --> Language Class Initialized
INFO - 2025-01-24 08:26:12 --> Loader Class Initialized
INFO - 2025-01-24 08:26:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:26:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:26:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:26:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:26:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:26:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:26:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:26:12 --> Upload Class Initialized
INFO - 2025-01-24 08:26:12 --> Email Class Initialized
INFO - 2025-01-24 08:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:26:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:26:12 --> Controller Class Initialized
INFO - 2025-01-24 13:56:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:56:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:56:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:27:12 --> Config Class Initialized
INFO - 2025-01-24 08:27:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:27:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:27:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:27:12 --> URI Class Initialized
INFO - 2025-01-24 08:27:12 --> Router Class Initialized
INFO - 2025-01-24 08:27:12 --> Output Class Initialized
INFO - 2025-01-24 08:27:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:27:12 --> Input Class Initialized
INFO - 2025-01-24 08:27:12 --> Language Class Initialized
INFO - 2025-01-24 08:27:12 --> Loader Class Initialized
INFO - 2025-01-24 08:27:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:27:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:27:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:27:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:27:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:27:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:27:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:27:12 --> Upload Class Initialized
INFO - 2025-01-24 08:27:12 --> Email Class Initialized
INFO - 2025-01-24 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:27:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:27:12 --> Controller Class Initialized
INFO - 2025-01-24 13:57:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:57:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:57:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:28:12 --> Config Class Initialized
INFO - 2025-01-24 08:28:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:28:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:28:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:28:12 --> URI Class Initialized
INFO - 2025-01-24 08:28:12 --> Router Class Initialized
INFO - 2025-01-24 08:28:12 --> Output Class Initialized
INFO - 2025-01-24 08:28:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:28:12 --> Input Class Initialized
INFO - 2025-01-24 08:28:12 --> Language Class Initialized
INFO - 2025-01-24 08:28:12 --> Loader Class Initialized
INFO - 2025-01-24 08:28:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:28:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:28:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:28:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:28:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:28:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:28:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:28:12 --> Upload Class Initialized
INFO - 2025-01-24 08:28:12 --> Email Class Initialized
INFO - 2025-01-24 08:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:28:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:28:12 --> Controller Class Initialized
INFO - 2025-01-24 13:58:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:58:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:58:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:29:12 --> Config Class Initialized
INFO - 2025-01-24 08:29:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:29:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:29:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:29:12 --> URI Class Initialized
INFO - 2025-01-24 08:29:12 --> Router Class Initialized
INFO - 2025-01-24 08:29:12 --> Output Class Initialized
INFO - 2025-01-24 08:29:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:29:12 --> Input Class Initialized
INFO - 2025-01-24 08:29:12 --> Language Class Initialized
INFO - 2025-01-24 08:29:12 --> Loader Class Initialized
INFO - 2025-01-24 08:29:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:29:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:29:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:29:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:29:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:29:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:29:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:29:12 --> Upload Class Initialized
INFO - 2025-01-24 08:29:12 --> Email Class Initialized
INFO - 2025-01-24 08:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:29:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:29:12 --> Controller Class Initialized
INFO - 2025-01-24 13:59:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 13:59:12 --> Model "MainModel" initialized
INFO - 2025-01-24 13:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 13:59:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:30:12 --> Config Class Initialized
INFO - 2025-01-24 08:30:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:30:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:30:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:30:12 --> URI Class Initialized
INFO - 2025-01-24 08:30:12 --> Router Class Initialized
INFO - 2025-01-24 08:30:12 --> Output Class Initialized
INFO - 2025-01-24 08:30:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:30:12 --> Input Class Initialized
INFO - 2025-01-24 08:30:12 --> Language Class Initialized
INFO - 2025-01-24 08:30:12 --> Loader Class Initialized
INFO - 2025-01-24 08:30:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:30:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:30:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:30:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:30:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:30:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:30:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:30:12 --> Upload Class Initialized
INFO - 2025-01-24 08:30:12 --> Email Class Initialized
INFO - 2025-01-24 08:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:30:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:30:12 --> Controller Class Initialized
INFO - 2025-01-24 14:00:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:00:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:00:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:31:12 --> Config Class Initialized
INFO - 2025-01-24 08:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:31:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:31:12 --> URI Class Initialized
INFO - 2025-01-24 08:31:12 --> Router Class Initialized
INFO - 2025-01-24 08:31:12 --> Output Class Initialized
INFO - 2025-01-24 08:31:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:31:12 --> Input Class Initialized
INFO - 2025-01-24 08:31:12 --> Language Class Initialized
INFO - 2025-01-24 08:31:12 --> Loader Class Initialized
INFO - 2025-01-24 08:31:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:31:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:31:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:31:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:31:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:31:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:31:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:31:12 --> Upload Class Initialized
INFO - 2025-01-24 08:31:12 --> Email Class Initialized
INFO - 2025-01-24 08:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:31:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:31:12 --> Controller Class Initialized
INFO - 2025-01-24 14:01:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:01:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:01:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:32:12 --> Config Class Initialized
INFO - 2025-01-24 08:32:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:32:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:32:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:32:12 --> URI Class Initialized
INFO - 2025-01-24 08:32:12 --> Router Class Initialized
INFO - 2025-01-24 08:32:12 --> Output Class Initialized
INFO - 2025-01-24 08:32:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:32:12 --> Input Class Initialized
INFO - 2025-01-24 08:32:12 --> Language Class Initialized
INFO - 2025-01-24 08:32:12 --> Loader Class Initialized
INFO - 2025-01-24 08:32:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:32:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:32:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:32:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:32:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:32:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:32:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:32:12 --> Upload Class Initialized
INFO - 2025-01-24 08:32:12 --> Email Class Initialized
INFO - 2025-01-24 08:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:32:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:32:12 --> Controller Class Initialized
INFO - 2025-01-24 14:02:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:02:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:02:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:47:43 --> Config Class Initialized
INFO - 2025-01-24 08:47:43 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:47:43 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:47:43 --> Utf8 Class Initialized
INFO - 2025-01-24 08:47:43 --> URI Class Initialized
INFO - 2025-01-24 08:47:43 --> Router Class Initialized
INFO - 2025-01-24 08:47:43 --> Output Class Initialized
INFO - 2025-01-24 08:47:43 --> Security Class Initialized
DEBUG - 2025-01-24 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:47:43 --> Input Class Initialized
INFO - 2025-01-24 08:47:43 --> Language Class Initialized
INFO - 2025-01-24 08:47:43 --> Loader Class Initialized
INFO - 2025-01-24 08:47:43 --> Helper loaded: url_helper
INFO - 2025-01-24 08:47:43 --> Helper loaded: html_helper
INFO - 2025-01-24 08:47:43 --> Helper loaded: file_helper
INFO - 2025-01-24 08:47:43 --> Helper loaded: string_helper
INFO - 2025-01-24 08:47:43 --> Helper loaded: form_helper
INFO - 2025-01-24 08:47:43 --> Helper loaded: my_helper
INFO - 2025-01-24 08:47:43 --> Database Driver Class Initialized
INFO - 2025-01-24 08:47:43 --> Upload Class Initialized
INFO - 2025-01-24 08:47:43 --> Email Class Initialized
INFO - 2025-01-24 08:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:47:43 --> Form Validation Class Initialized
INFO - 2025-01-24 08:47:43 --> Controller Class Initialized
INFO - 2025-01-24 14:17:43 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:17:43 --> Model "MainModel" initialized
INFO - 2025-01-24 14:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:17:43 --> Pagination Class Initialized
INFO - 2025-01-24 08:48:12 --> Config Class Initialized
INFO - 2025-01-24 08:48:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:48:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:48:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:48:12 --> URI Class Initialized
INFO - 2025-01-24 08:48:12 --> Router Class Initialized
INFO - 2025-01-24 08:48:12 --> Output Class Initialized
INFO - 2025-01-24 08:48:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:48:12 --> Input Class Initialized
INFO - 2025-01-24 08:48:12 --> Language Class Initialized
INFO - 2025-01-24 08:48:12 --> Loader Class Initialized
INFO - 2025-01-24 08:48:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:48:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:48:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:48:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:48:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:48:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:48:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:48:12 --> Upload Class Initialized
INFO - 2025-01-24 08:48:12 --> Email Class Initialized
INFO - 2025-01-24 08:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:48:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:48:12 --> Controller Class Initialized
INFO - 2025-01-24 14:18:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:18:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:18:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:49:12 --> Config Class Initialized
INFO - 2025-01-24 08:49:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:49:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:49:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:49:12 --> URI Class Initialized
INFO - 2025-01-24 08:49:12 --> Router Class Initialized
INFO - 2025-01-24 08:49:12 --> Output Class Initialized
INFO - 2025-01-24 08:49:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:49:12 --> Input Class Initialized
INFO - 2025-01-24 08:49:12 --> Language Class Initialized
INFO - 2025-01-24 08:49:12 --> Loader Class Initialized
INFO - 2025-01-24 08:49:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:49:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:49:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:49:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:49:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:49:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:49:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:49:12 --> Upload Class Initialized
INFO - 2025-01-24 08:49:12 --> Email Class Initialized
INFO - 2025-01-24 08:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:49:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:49:12 --> Controller Class Initialized
INFO - 2025-01-24 14:19:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:19:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:19:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:50:12 --> Config Class Initialized
INFO - 2025-01-24 08:50:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:50:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:50:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:50:12 --> URI Class Initialized
INFO - 2025-01-24 08:50:12 --> Router Class Initialized
INFO - 2025-01-24 08:50:12 --> Output Class Initialized
INFO - 2025-01-24 08:50:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:50:12 --> Input Class Initialized
INFO - 2025-01-24 08:50:12 --> Language Class Initialized
INFO - 2025-01-24 08:50:12 --> Loader Class Initialized
INFO - 2025-01-24 08:50:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:50:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:50:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:50:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:50:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:50:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:50:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:50:12 --> Upload Class Initialized
INFO - 2025-01-24 08:50:12 --> Email Class Initialized
INFO - 2025-01-24 08:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:50:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:50:12 --> Controller Class Initialized
INFO - 2025-01-24 14:20:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:20:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:20:12 --> Pagination Class Initialized
INFO - 2025-01-24 08:51:12 --> Config Class Initialized
INFO - 2025-01-24 08:51:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 08:51:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 08:51:12 --> Utf8 Class Initialized
INFO - 2025-01-24 08:51:12 --> URI Class Initialized
INFO - 2025-01-24 08:51:12 --> Router Class Initialized
INFO - 2025-01-24 08:51:12 --> Output Class Initialized
INFO - 2025-01-24 08:51:12 --> Security Class Initialized
DEBUG - 2025-01-24 08:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 08:51:12 --> Input Class Initialized
INFO - 2025-01-24 08:51:12 --> Language Class Initialized
INFO - 2025-01-24 08:51:12 --> Loader Class Initialized
INFO - 2025-01-24 08:51:12 --> Helper loaded: url_helper
INFO - 2025-01-24 08:51:12 --> Helper loaded: html_helper
INFO - 2025-01-24 08:51:12 --> Helper loaded: file_helper
INFO - 2025-01-24 08:51:12 --> Helper loaded: string_helper
INFO - 2025-01-24 08:51:12 --> Helper loaded: form_helper
INFO - 2025-01-24 08:51:12 --> Helper loaded: my_helper
INFO - 2025-01-24 08:51:12 --> Database Driver Class Initialized
INFO - 2025-01-24 08:51:12 --> Upload Class Initialized
INFO - 2025-01-24 08:51:12 --> Email Class Initialized
INFO - 2025-01-24 08:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 08:51:12 --> Form Validation Class Initialized
INFO - 2025-01-24 08:51:12 --> Controller Class Initialized
INFO - 2025-01-24 14:21:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:21:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:21:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:14:47 --> Config Class Initialized
INFO - 2025-01-24 09:14:47 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:14:47 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:14:47 --> Utf8 Class Initialized
INFO - 2025-01-24 09:14:47 --> URI Class Initialized
INFO - 2025-01-24 09:14:47 --> Router Class Initialized
INFO - 2025-01-24 09:14:47 --> Output Class Initialized
INFO - 2025-01-24 09:14:47 --> Security Class Initialized
DEBUG - 2025-01-24 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:14:47 --> Input Class Initialized
INFO - 2025-01-24 09:14:47 --> Language Class Initialized
INFO - 2025-01-24 09:14:47 --> Loader Class Initialized
INFO - 2025-01-24 09:14:47 --> Helper loaded: url_helper
INFO - 2025-01-24 09:14:47 --> Helper loaded: html_helper
INFO - 2025-01-24 09:14:47 --> Helper loaded: file_helper
INFO - 2025-01-24 09:14:47 --> Helper loaded: string_helper
INFO - 2025-01-24 09:14:47 --> Helper loaded: form_helper
INFO - 2025-01-24 09:14:47 --> Helper loaded: my_helper
INFO - 2025-01-24 09:14:47 --> Database Driver Class Initialized
INFO - 2025-01-24 09:14:47 --> Upload Class Initialized
INFO - 2025-01-24 09:14:47 --> Email Class Initialized
INFO - 2025-01-24 09:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:14:47 --> Form Validation Class Initialized
INFO - 2025-01-24 09:14:47 --> Controller Class Initialized
INFO - 2025-01-24 14:44:47 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:44:47 --> Model "MainModel" initialized
INFO - 2025-01-24 14:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:44:47 --> Pagination Class Initialized
INFO - 2025-01-24 09:15:12 --> Config Class Initialized
INFO - 2025-01-24 09:15:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:15:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:15:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:15:12 --> URI Class Initialized
INFO - 2025-01-24 09:15:12 --> Router Class Initialized
INFO - 2025-01-24 09:15:12 --> Output Class Initialized
INFO - 2025-01-24 09:15:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:15:12 --> Input Class Initialized
INFO - 2025-01-24 09:15:12 --> Language Class Initialized
INFO - 2025-01-24 09:15:12 --> Loader Class Initialized
INFO - 2025-01-24 09:15:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:15:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:15:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:15:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:15:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:15:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:15:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:15:12 --> Upload Class Initialized
INFO - 2025-01-24 09:15:12 --> Email Class Initialized
INFO - 2025-01-24 09:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:15:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:15:12 --> Controller Class Initialized
INFO - 2025-01-24 14:45:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:45:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:45:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:16:12 --> Config Class Initialized
INFO - 2025-01-24 09:16:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:16:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:16:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:16:12 --> URI Class Initialized
INFO - 2025-01-24 09:16:12 --> Router Class Initialized
INFO - 2025-01-24 09:16:12 --> Output Class Initialized
INFO - 2025-01-24 09:16:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:16:12 --> Input Class Initialized
INFO - 2025-01-24 09:16:12 --> Language Class Initialized
INFO - 2025-01-24 09:16:12 --> Loader Class Initialized
INFO - 2025-01-24 09:16:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:16:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:16:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:16:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:16:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:16:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:16:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:16:12 --> Upload Class Initialized
INFO - 2025-01-24 09:16:12 --> Email Class Initialized
INFO - 2025-01-24 09:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:16:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:16:12 --> Controller Class Initialized
INFO - 2025-01-24 14:46:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:46:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:46:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:17:12 --> Config Class Initialized
INFO - 2025-01-24 09:17:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:17:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:17:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:17:12 --> URI Class Initialized
INFO - 2025-01-24 09:17:12 --> Router Class Initialized
INFO - 2025-01-24 09:17:12 --> Output Class Initialized
INFO - 2025-01-24 09:17:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:17:12 --> Input Class Initialized
INFO - 2025-01-24 09:17:12 --> Language Class Initialized
INFO - 2025-01-24 09:17:12 --> Loader Class Initialized
INFO - 2025-01-24 09:17:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:17:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:17:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:17:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:17:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:17:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:17:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:17:12 --> Upload Class Initialized
INFO - 2025-01-24 09:17:12 --> Email Class Initialized
INFO - 2025-01-24 09:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:17:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:17:12 --> Controller Class Initialized
INFO - 2025-01-24 14:47:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:47:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:47:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:18:35 --> Config Class Initialized
INFO - 2025-01-24 09:18:35 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:18:35 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:18:35 --> Utf8 Class Initialized
INFO - 2025-01-24 09:18:35 --> URI Class Initialized
INFO - 2025-01-24 09:18:35 --> Router Class Initialized
INFO - 2025-01-24 09:18:35 --> Output Class Initialized
INFO - 2025-01-24 09:18:35 --> Security Class Initialized
DEBUG - 2025-01-24 09:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:18:35 --> Input Class Initialized
INFO - 2025-01-24 09:18:35 --> Language Class Initialized
INFO - 2025-01-24 09:18:35 --> Loader Class Initialized
INFO - 2025-01-24 09:18:35 --> Helper loaded: url_helper
INFO - 2025-01-24 09:18:35 --> Helper loaded: html_helper
INFO - 2025-01-24 09:18:35 --> Helper loaded: file_helper
INFO - 2025-01-24 09:18:35 --> Helper loaded: string_helper
INFO - 2025-01-24 09:18:35 --> Helper loaded: form_helper
INFO - 2025-01-24 09:18:35 --> Helper loaded: my_helper
INFO - 2025-01-24 09:18:35 --> Database Driver Class Initialized
INFO - 2025-01-24 09:18:35 --> Upload Class Initialized
INFO - 2025-01-24 09:18:35 --> Email Class Initialized
INFO - 2025-01-24 09:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:18:35 --> Form Validation Class Initialized
INFO - 2025-01-24 09:18:35 --> Controller Class Initialized
INFO - 2025-01-24 14:48:35 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:48:35 --> Model "MainModel" initialized
INFO - 2025-01-24 14:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:48:35 --> Pagination Class Initialized
INFO - 2025-01-24 09:19:12 --> Config Class Initialized
INFO - 2025-01-24 09:19:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:19:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:19:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:19:12 --> URI Class Initialized
INFO - 2025-01-24 09:19:12 --> Router Class Initialized
INFO - 2025-01-24 09:19:12 --> Output Class Initialized
INFO - 2025-01-24 09:19:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:19:12 --> Input Class Initialized
INFO - 2025-01-24 09:19:12 --> Language Class Initialized
INFO - 2025-01-24 09:19:12 --> Loader Class Initialized
INFO - 2025-01-24 09:19:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:19:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:19:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:19:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:19:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:19:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:19:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:19:12 --> Upload Class Initialized
INFO - 2025-01-24 09:19:12 --> Email Class Initialized
INFO - 2025-01-24 09:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:19:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:19:12 --> Controller Class Initialized
INFO - 2025-01-24 14:49:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:49:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:49:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:20:12 --> Config Class Initialized
INFO - 2025-01-24 09:20:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:20:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:20:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:20:12 --> URI Class Initialized
INFO - 2025-01-24 09:20:12 --> Router Class Initialized
INFO - 2025-01-24 09:20:12 --> Output Class Initialized
INFO - 2025-01-24 09:20:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:20:12 --> Input Class Initialized
INFO - 2025-01-24 09:20:12 --> Language Class Initialized
INFO - 2025-01-24 09:20:12 --> Loader Class Initialized
INFO - 2025-01-24 09:20:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:20:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:20:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:20:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:20:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:20:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:20:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:20:12 --> Upload Class Initialized
INFO - 2025-01-24 09:20:12 --> Email Class Initialized
INFO - 2025-01-24 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:20:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:20:12 --> Controller Class Initialized
INFO - 2025-01-24 14:50:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:50:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:50:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:21:12 --> Config Class Initialized
INFO - 2025-01-24 09:21:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:21:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:21:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:21:12 --> URI Class Initialized
INFO - 2025-01-24 09:21:12 --> Router Class Initialized
INFO - 2025-01-24 09:21:12 --> Output Class Initialized
INFO - 2025-01-24 09:21:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:21:12 --> Input Class Initialized
INFO - 2025-01-24 09:21:12 --> Language Class Initialized
INFO - 2025-01-24 09:21:12 --> Loader Class Initialized
INFO - 2025-01-24 09:21:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:21:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:21:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:21:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:21:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:21:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:21:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:21:12 --> Upload Class Initialized
INFO - 2025-01-24 09:21:12 --> Email Class Initialized
INFO - 2025-01-24 09:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:21:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:21:12 --> Controller Class Initialized
INFO - 2025-01-24 14:51:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:51:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:51:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:22:12 --> Config Class Initialized
INFO - 2025-01-24 09:22:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:22:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:22:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:22:12 --> URI Class Initialized
INFO - 2025-01-24 09:22:12 --> Router Class Initialized
INFO - 2025-01-24 09:22:12 --> Output Class Initialized
INFO - 2025-01-24 09:22:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:22:12 --> Input Class Initialized
INFO - 2025-01-24 09:22:12 --> Language Class Initialized
INFO - 2025-01-24 09:22:12 --> Loader Class Initialized
INFO - 2025-01-24 09:22:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:22:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:22:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:22:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:22:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:22:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:22:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:22:12 --> Upload Class Initialized
INFO - 2025-01-24 09:22:12 --> Email Class Initialized
INFO - 2025-01-24 09:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:22:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:22:12 --> Controller Class Initialized
INFO - 2025-01-24 14:52:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:52:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:52:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:23:12 --> Config Class Initialized
INFO - 2025-01-24 09:23:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:23:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:23:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:23:12 --> URI Class Initialized
INFO - 2025-01-24 09:23:12 --> Router Class Initialized
INFO - 2025-01-24 09:23:12 --> Output Class Initialized
INFO - 2025-01-24 09:23:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:23:12 --> Input Class Initialized
INFO - 2025-01-24 09:23:12 --> Language Class Initialized
INFO - 2025-01-24 09:23:12 --> Loader Class Initialized
INFO - 2025-01-24 09:23:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:23:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:23:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:23:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:23:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:23:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:23:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:23:12 --> Upload Class Initialized
INFO - 2025-01-24 09:23:12 --> Email Class Initialized
INFO - 2025-01-24 09:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:23:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:23:12 --> Controller Class Initialized
INFO - 2025-01-24 14:53:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:53:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:53:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:24:12 --> Config Class Initialized
INFO - 2025-01-24 09:24:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:24:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:24:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:24:12 --> URI Class Initialized
INFO - 2025-01-24 09:24:12 --> Router Class Initialized
INFO - 2025-01-24 09:24:12 --> Output Class Initialized
INFO - 2025-01-24 09:24:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:24:12 --> Input Class Initialized
INFO - 2025-01-24 09:24:12 --> Language Class Initialized
INFO - 2025-01-24 09:24:12 --> Loader Class Initialized
INFO - 2025-01-24 09:24:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:24:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:24:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:24:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:24:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:24:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:24:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:24:12 --> Upload Class Initialized
INFO - 2025-01-24 09:24:12 --> Email Class Initialized
INFO - 2025-01-24 09:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:24:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:24:12 --> Controller Class Initialized
INFO - 2025-01-24 14:54:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:54:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:54:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:28:51 --> Config Class Initialized
INFO - 2025-01-24 09:28:51 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:28:51 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:28:51 --> Utf8 Class Initialized
INFO - 2025-01-24 09:28:51 --> URI Class Initialized
INFO - 2025-01-24 09:28:51 --> Router Class Initialized
INFO - 2025-01-24 09:28:51 --> Output Class Initialized
INFO - 2025-01-24 09:28:51 --> Security Class Initialized
DEBUG - 2025-01-24 09:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:28:51 --> Input Class Initialized
INFO - 2025-01-24 09:28:51 --> Language Class Initialized
INFO - 2025-01-24 09:28:51 --> Loader Class Initialized
INFO - 2025-01-24 09:28:51 --> Helper loaded: url_helper
INFO - 2025-01-24 09:28:51 --> Helper loaded: html_helper
INFO - 2025-01-24 09:28:51 --> Helper loaded: file_helper
INFO - 2025-01-24 09:28:51 --> Helper loaded: string_helper
INFO - 2025-01-24 09:28:51 --> Helper loaded: form_helper
INFO - 2025-01-24 09:28:51 --> Helper loaded: my_helper
INFO - 2025-01-24 09:28:51 --> Database Driver Class Initialized
INFO - 2025-01-24 09:28:51 --> Upload Class Initialized
INFO - 2025-01-24 09:28:51 --> Email Class Initialized
INFO - 2025-01-24 09:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:28:51 --> Form Validation Class Initialized
INFO - 2025-01-24 09:28:51 --> Controller Class Initialized
INFO - 2025-01-24 14:58:51 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:58:51 --> Model "MainModel" initialized
INFO - 2025-01-24 14:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:58:51 --> Pagination Class Initialized
INFO - 2025-01-24 09:29:12 --> Config Class Initialized
INFO - 2025-01-24 09:29:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:29:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:29:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:29:12 --> URI Class Initialized
INFO - 2025-01-24 09:29:12 --> Router Class Initialized
INFO - 2025-01-24 09:29:12 --> Output Class Initialized
INFO - 2025-01-24 09:29:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:29:12 --> Input Class Initialized
INFO - 2025-01-24 09:29:12 --> Language Class Initialized
INFO - 2025-01-24 09:29:12 --> Loader Class Initialized
INFO - 2025-01-24 09:29:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:29:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:29:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:29:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:29:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:29:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:29:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:29:12 --> Upload Class Initialized
INFO - 2025-01-24 09:29:12 --> Email Class Initialized
INFO - 2025-01-24 09:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:29:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:29:12 --> Controller Class Initialized
INFO - 2025-01-24 14:59:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 14:59:12 --> Model "MainModel" initialized
INFO - 2025-01-24 14:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 14:59:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:30:12 --> Config Class Initialized
INFO - 2025-01-24 09:30:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:30:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:30:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:30:12 --> URI Class Initialized
INFO - 2025-01-24 09:30:12 --> Router Class Initialized
INFO - 2025-01-24 09:30:12 --> Output Class Initialized
INFO - 2025-01-24 09:30:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:30:12 --> Input Class Initialized
INFO - 2025-01-24 09:30:12 --> Language Class Initialized
INFO - 2025-01-24 09:30:12 --> Loader Class Initialized
INFO - 2025-01-24 09:30:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:30:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:30:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:30:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:30:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:30:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:30:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:30:12 --> Upload Class Initialized
INFO - 2025-01-24 09:30:12 --> Email Class Initialized
INFO - 2025-01-24 09:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:30:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:30:12 --> Controller Class Initialized
INFO - 2025-01-24 15:00:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:00:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:00:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:31:12 --> Config Class Initialized
INFO - 2025-01-24 09:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:31:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:31:12 --> URI Class Initialized
INFO - 2025-01-24 09:31:12 --> Router Class Initialized
INFO - 2025-01-24 09:31:12 --> Output Class Initialized
INFO - 2025-01-24 09:31:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:31:12 --> Input Class Initialized
INFO - 2025-01-24 09:31:12 --> Language Class Initialized
INFO - 2025-01-24 09:31:12 --> Loader Class Initialized
INFO - 2025-01-24 09:31:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:31:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:31:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:31:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:31:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:31:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:31:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:31:12 --> Upload Class Initialized
INFO - 2025-01-24 09:31:12 --> Email Class Initialized
INFO - 2025-01-24 09:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:31:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:31:12 --> Controller Class Initialized
INFO - 2025-01-24 15:01:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:01:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:01:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:32:12 --> Config Class Initialized
INFO - 2025-01-24 09:32:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:32:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:32:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:32:12 --> URI Class Initialized
INFO - 2025-01-24 09:32:12 --> Router Class Initialized
INFO - 2025-01-24 09:32:12 --> Output Class Initialized
INFO - 2025-01-24 09:32:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:32:12 --> Input Class Initialized
INFO - 2025-01-24 09:32:12 --> Language Class Initialized
INFO - 2025-01-24 09:32:12 --> Loader Class Initialized
INFO - 2025-01-24 09:32:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:32:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:32:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:32:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:32:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:32:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:32:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:32:12 --> Upload Class Initialized
INFO - 2025-01-24 09:32:12 --> Email Class Initialized
INFO - 2025-01-24 09:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:32:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:32:12 --> Controller Class Initialized
INFO - 2025-01-24 15:02:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:02:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:02:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:33:12 --> Config Class Initialized
INFO - 2025-01-24 09:33:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:33:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:33:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:33:12 --> URI Class Initialized
INFO - 2025-01-24 09:33:12 --> Router Class Initialized
INFO - 2025-01-24 09:33:12 --> Output Class Initialized
INFO - 2025-01-24 09:33:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:33:12 --> Input Class Initialized
INFO - 2025-01-24 09:33:12 --> Language Class Initialized
INFO - 2025-01-24 09:33:12 --> Loader Class Initialized
INFO - 2025-01-24 09:33:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:33:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:33:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:33:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:33:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:33:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:33:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:33:12 --> Upload Class Initialized
INFO - 2025-01-24 09:33:12 --> Email Class Initialized
INFO - 2025-01-24 09:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:33:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:33:12 --> Controller Class Initialized
INFO - 2025-01-24 15:03:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:03:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:03:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:34:12 --> Config Class Initialized
INFO - 2025-01-24 09:34:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:34:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:34:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:34:12 --> URI Class Initialized
INFO - 2025-01-24 09:34:12 --> Router Class Initialized
INFO - 2025-01-24 09:34:12 --> Output Class Initialized
INFO - 2025-01-24 09:34:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:34:12 --> Input Class Initialized
INFO - 2025-01-24 09:34:12 --> Language Class Initialized
INFO - 2025-01-24 09:34:12 --> Loader Class Initialized
INFO - 2025-01-24 09:34:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:34:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:34:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:34:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:34:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:34:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:34:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:34:12 --> Upload Class Initialized
INFO - 2025-01-24 09:34:12 --> Email Class Initialized
INFO - 2025-01-24 09:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:34:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:34:12 --> Controller Class Initialized
INFO - 2025-01-24 15:04:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:04:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:04:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:35:12 --> Config Class Initialized
INFO - 2025-01-24 09:35:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:35:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:35:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:35:12 --> URI Class Initialized
INFO - 2025-01-24 09:35:12 --> Router Class Initialized
INFO - 2025-01-24 09:35:12 --> Output Class Initialized
INFO - 2025-01-24 09:35:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:35:12 --> Input Class Initialized
INFO - 2025-01-24 09:35:12 --> Language Class Initialized
INFO - 2025-01-24 09:35:12 --> Loader Class Initialized
INFO - 2025-01-24 09:35:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:35:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:35:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:35:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:35:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:35:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:35:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:35:12 --> Upload Class Initialized
INFO - 2025-01-24 09:35:12 --> Email Class Initialized
INFO - 2025-01-24 09:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:35:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:35:12 --> Controller Class Initialized
INFO - 2025-01-24 15:05:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:05:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:05:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:36:12 --> Config Class Initialized
INFO - 2025-01-24 09:36:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:36:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:36:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:36:12 --> URI Class Initialized
INFO - 2025-01-24 09:36:12 --> Router Class Initialized
INFO - 2025-01-24 09:36:12 --> Output Class Initialized
INFO - 2025-01-24 09:36:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:36:12 --> Input Class Initialized
INFO - 2025-01-24 09:36:12 --> Language Class Initialized
INFO - 2025-01-24 09:36:12 --> Loader Class Initialized
INFO - 2025-01-24 09:36:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:36:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:36:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:36:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:36:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:36:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:36:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:36:12 --> Upload Class Initialized
INFO - 2025-01-24 09:36:12 --> Email Class Initialized
INFO - 2025-01-24 09:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:36:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:36:12 --> Controller Class Initialized
INFO - 2025-01-24 15:06:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:06:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:06:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:37:12 --> Config Class Initialized
INFO - 2025-01-24 09:37:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:37:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:37:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:37:12 --> URI Class Initialized
INFO - 2025-01-24 09:37:12 --> Router Class Initialized
INFO - 2025-01-24 09:37:12 --> Output Class Initialized
INFO - 2025-01-24 09:37:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:37:12 --> Input Class Initialized
INFO - 2025-01-24 09:37:12 --> Language Class Initialized
INFO - 2025-01-24 09:37:12 --> Loader Class Initialized
INFO - 2025-01-24 09:37:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:37:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:37:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:37:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:37:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:37:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:37:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:37:12 --> Upload Class Initialized
INFO - 2025-01-24 09:37:12 --> Email Class Initialized
INFO - 2025-01-24 09:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:37:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:37:12 --> Controller Class Initialized
INFO - 2025-01-24 15:07:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:07:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:07:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:38:12 --> Config Class Initialized
INFO - 2025-01-24 09:38:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:38:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:38:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:38:12 --> URI Class Initialized
INFO - 2025-01-24 09:38:12 --> Router Class Initialized
INFO - 2025-01-24 09:38:12 --> Output Class Initialized
INFO - 2025-01-24 09:38:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:38:12 --> Input Class Initialized
INFO - 2025-01-24 09:38:12 --> Language Class Initialized
INFO - 2025-01-24 09:38:12 --> Loader Class Initialized
INFO - 2025-01-24 09:38:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:38:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:38:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:38:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:38:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:38:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:38:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:38:12 --> Upload Class Initialized
INFO - 2025-01-24 09:38:12 --> Email Class Initialized
INFO - 2025-01-24 09:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:38:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:38:12 --> Controller Class Initialized
INFO - 2025-01-24 15:08:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:08:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:08:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:39:12 --> Config Class Initialized
INFO - 2025-01-24 09:39:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:39:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:39:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:39:12 --> URI Class Initialized
INFO - 2025-01-24 09:39:12 --> Router Class Initialized
INFO - 2025-01-24 09:39:12 --> Output Class Initialized
INFO - 2025-01-24 09:39:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:39:12 --> Input Class Initialized
INFO - 2025-01-24 09:39:12 --> Language Class Initialized
INFO - 2025-01-24 09:39:12 --> Loader Class Initialized
INFO - 2025-01-24 09:39:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:39:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:39:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:39:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:39:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:39:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:39:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:39:12 --> Upload Class Initialized
INFO - 2025-01-24 09:39:12 --> Email Class Initialized
INFO - 2025-01-24 09:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:39:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:39:12 --> Controller Class Initialized
INFO - 2025-01-24 15:09:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:09:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:09:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:40:12 --> Config Class Initialized
INFO - 2025-01-24 09:40:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:40:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:40:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:40:12 --> URI Class Initialized
INFO - 2025-01-24 09:40:12 --> Router Class Initialized
INFO - 2025-01-24 09:40:12 --> Output Class Initialized
INFO - 2025-01-24 09:40:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:40:12 --> Input Class Initialized
INFO - 2025-01-24 09:40:12 --> Language Class Initialized
INFO - 2025-01-24 09:40:12 --> Loader Class Initialized
INFO - 2025-01-24 09:40:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:40:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:40:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:40:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:40:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:40:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:40:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:40:12 --> Upload Class Initialized
INFO - 2025-01-24 09:40:12 --> Email Class Initialized
INFO - 2025-01-24 09:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:40:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:40:12 --> Controller Class Initialized
INFO - 2025-01-24 15:10:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:10:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:10:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:41:12 --> Config Class Initialized
INFO - 2025-01-24 09:41:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:41:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:41:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:41:12 --> URI Class Initialized
INFO - 2025-01-24 09:41:12 --> Router Class Initialized
INFO - 2025-01-24 09:41:12 --> Output Class Initialized
INFO - 2025-01-24 09:41:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:41:12 --> Input Class Initialized
INFO - 2025-01-24 09:41:12 --> Language Class Initialized
INFO - 2025-01-24 09:41:12 --> Loader Class Initialized
INFO - 2025-01-24 09:41:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:41:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:41:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:41:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:41:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:41:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:41:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:41:12 --> Upload Class Initialized
INFO - 2025-01-24 09:41:12 --> Email Class Initialized
INFO - 2025-01-24 09:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:41:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:41:12 --> Controller Class Initialized
INFO - 2025-01-24 15:11:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:11:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:11:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:43:13 --> Config Class Initialized
INFO - 2025-01-24 09:43:13 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:43:13 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:43:13 --> Utf8 Class Initialized
INFO - 2025-01-24 09:43:13 --> URI Class Initialized
INFO - 2025-01-24 09:43:13 --> Router Class Initialized
INFO - 2025-01-24 09:43:13 --> Output Class Initialized
INFO - 2025-01-24 09:43:13 --> Security Class Initialized
DEBUG - 2025-01-24 09:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:43:13 --> Input Class Initialized
INFO - 2025-01-24 09:43:13 --> Language Class Initialized
INFO - 2025-01-24 09:43:13 --> Loader Class Initialized
INFO - 2025-01-24 09:43:13 --> Helper loaded: url_helper
INFO - 2025-01-24 09:43:13 --> Helper loaded: html_helper
INFO - 2025-01-24 09:43:13 --> Helper loaded: file_helper
INFO - 2025-01-24 09:43:13 --> Helper loaded: string_helper
INFO - 2025-01-24 09:43:13 --> Helper loaded: form_helper
INFO - 2025-01-24 09:43:13 --> Helper loaded: my_helper
INFO - 2025-01-24 09:43:13 --> Database Driver Class Initialized
INFO - 2025-01-24 09:43:13 --> Upload Class Initialized
INFO - 2025-01-24 09:43:13 --> Email Class Initialized
INFO - 2025-01-24 09:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:43:13 --> Form Validation Class Initialized
INFO - 2025-01-24 09:43:13 --> Controller Class Initialized
INFO - 2025-01-24 15:13:13 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:13:13 --> Model "MainModel" initialized
INFO - 2025-01-24 15:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:13:13 --> Pagination Class Initialized
INFO - 2025-01-24 09:44:12 --> Config Class Initialized
INFO - 2025-01-24 09:44:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:44:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:44:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:44:12 --> URI Class Initialized
INFO - 2025-01-24 09:44:12 --> Router Class Initialized
INFO - 2025-01-24 09:44:12 --> Output Class Initialized
INFO - 2025-01-24 09:44:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:44:12 --> Input Class Initialized
INFO - 2025-01-24 09:44:12 --> Language Class Initialized
INFO - 2025-01-24 09:44:12 --> Loader Class Initialized
INFO - 2025-01-24 09:44:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:44:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:44:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:44:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:44:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:44:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:44:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:44:12 --> Upload Class Initialized
INFO - 2025-01-24 09:44:12 --> Email Class Initialized
INFO - 2025-01-24 09:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:44:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:44:12 --> Controller Class Initialized
INFO - 2025-01-24 15:14:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:14:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:14:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:14:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:45:12 --> Config Class Initialized
INFO - 2025-01-24 09:45:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:45:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:45:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:45:12 --> URI Class Initialized
INFO - 2025-01-24 09:45:12 --> Router Class Initialized
INFO - 2025-01-24 09:45:12 --> Output Class Initialized
INFO - 2025-01-24 09:45:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:45:12 --> Input Class Initialized
INFO - 2025-01-24 09:45:12 --> Language Class Initialized
INFO - 2025-01-24 09:45:12 --> Loader Class Initialized
INFO - 2025-01-24 09:45:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:45:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:45:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:45:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:45:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:45:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:45:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:45:12 --> Upload Class Initialized
INFO - 2025-01-24 09:45:12 --> Email Class Initialized
INFO - 2025-01-24 09:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:45:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:45:12 --> Controller Class Initialized
INFO - 2025-01-24 15:15:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:15:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:15:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:46:12 --> Config Class Initialized
INFO - 2025-01-24 09:46:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:46:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:46:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:46:12 --> URI Class Initialized
INFO - 2025-01-24 09:46:12 --> Router Class Initialized
INFO - 2025-01-24 09:46:12 --> Output Class Initialized
INFO - 2025-01-24 09:46:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:46:12 --> Input Class Initialized
INFO - 2025-01-24 09:46:12 --> Language Class Initialized
INFO - 2025-01-24 09:46:12 --> Loader Class Initialized
INFO - 2025-01-24 09:46:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:46:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:46:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:46:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:46:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:46:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:46:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:46:12 --> Upload Class Initialized
INFO - 2025-01-24 09:46:12 --> Email Class Initialized
INFO - 2025-01-24 09:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:46:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:46:12 --> Controller Class Initialized
INFO - 2025-01-24 15:16:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:16:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:16:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:47:12 --> Config Class Initialized
INFO - 2025-01-24 09:47:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:47:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:47:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:47:12 --> URI Class Initialized
INFO - 2025-01-24 09:47:12 --> Router Class Initialized
INFO - 2025-01-24 09:47:12 --> Output Class Initialized
INFO - 2025-01-24 09:47:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:47:12 --> Input Class Initialized
INFO - 2025-01-24 09:47:12 --> Language Class Initialized
INFO - 2025-01-24 09:47:12 --> Loader Class Initialized
INFO - 2025-01-24 09:47:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:47:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:47:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:47:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:47:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:47:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:47:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:47:12 --> Upload Class Initialized
INFO - 2025-01-24 09:47:12 --> Email Class Initialized
INFO - 2025-01-24 09:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:47:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:47:12 --> Controller Class Initialized
INFO - 2025-01-24 15:17:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:17:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:17:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:48:12 --> Config Class Initialized
INFO - 2025-01-24 09:48:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:48:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:48:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:48:12 --> URI Class Initialized
INFO - 2025-01-24 09:48:12 --> Router Class Initialized
INFO - 2025-01-24 09:48:12 --> Output Class Initialized
INFO - 2025-01-24 09:48:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:48:12 --> Input Class Initialized
INFO - 2025-01-24 09:48:12 --> Language Class Initialized
INFO - 2025-01-24 09:48:12 --> Loader Class Initialized
INFO - 2025-01-24 09:48:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:48:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:48:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:48:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:48:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:48:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:48:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:48:12 --> Upload Class Initialized
INFO - 2025-01-24 09:48:12 --> Email Class Initialized
INFO - 2025-01-24 09:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:48:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:48:12 --> Controller Class Initialized
INFO - 2025-01-24 15:18:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:18:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:18:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:49:12 --> Config Class Initialized
INFO - 2025-01-24 09:49:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:49:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:49:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:49:12 --> URI Class Initialized
INFO - 2025-01-24 09:49:12 --> Router Class Initialized
INFO - 2025-01-24 09:49:12 --> Output Class Initialized
INFO - 2025-01-24 09:49:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:49:12 --> Input Class Initialized
INFO - 2025-01-24 09:49:12 --> Language Class Initialized
INFO - 2025-01-24 09:49:12 --> Loader Class Initialized
INFO - 2025-01-24 09:49:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:49:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:49:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:49:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:49:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:49:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:49:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:49:12 --> Upload Class Initialized
INFO - 2025-01-24 09:49:12 --> Email Class Initialized
INFO - 2025-01-24 09:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:49:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:49:12 --> Controller Class Initialized
INFO - 2025-01-24 15:19:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:19:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:19:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:50:12 --> Config Class Initialized
INFO - 2025-01-24 09:50:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:50:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:50:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:50:12 --> URI Class Initialized
INFO - 2025-01-24 09:50:12 --> Router Class Initialized
INFO - 2025-01-24 09:50:12 --> Output Class Initialized
INFO - 2025-01-24 09:50:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:50:12 --> Input Class Initialized
INFO - 2025-01-24 09:50:12 --> Language Class Initialized
INFO - 2025-01-24 09:50:12 --> Loader Class Initialized
INFO - 2025-01-24 09:50:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:50:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:50:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:50:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:50:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:50:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:50:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:50:12 --> Upload Class Initialized
INFO - 2025-01-24 09:50:12 --> Email Class Initialized
INFO - 2025-01-24 09:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:50:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:50:12 --> Controller Class Initialized
INFO - 2025-01-24 15:20:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:20:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:20:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:51:12 --> Config Class Initialized
INFO - 2025-01-24 09:51:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:51:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:51:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:51:12 --> URI Class Initialized
INFO - 2025-01-24 09:51:12 --> Router Class Initialized
INFO - 2025-01-24 09:51:12 --> Output Class Initialized
INFO - 2025-01-24 09:51:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:51:12 --> Input Class Initialized
INFO - 2025-01-24 09:51:12 --> Language Class Initialized
INFO - 2025-01-24 09:51:12 --> Loader Class Initialized
INFO - 2025-01-24 09:51:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:51:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:51:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:51:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:51:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:51:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:51:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:51:12 --> Upload Class Initialized
INFO - 2025-01-24 09:51:12 --> Email Class Initialized
INFO - 2025-01-24 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:51:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:51:12 --> Controller Class Initialized
INFO - 2025-01-24 15:21:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:21:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:21:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:52:12 --> Config Class Initialized
INFO - 2025-01-24 09:52:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:52:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:52:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:52:12 --> URI Class Initialized
INFO - 2025-01-24 09:52:12 --> Router Class Initialized
INFO - 2025-01-24 09:52:12 --> Output Class Initialized
INFO - 2025-01-24 09:52:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:52:12 --> Input Class Initialized
INFO - 2025-01-24 09:52:12 --> Language Class Initialized
INFO - 2025-01-24 09:52:12 --> Loader Class Initialized
INFO - 2025-01-24 09:52:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:52:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:52:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:52:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:52:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:52:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:52:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:52:12 --> Upload Class Initialized
INFO - 2025-01-24 09:52:12 --> Email Class Initialized
INFO - 2025-01-24 09:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:52:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:52:12 --> Controller Class Initialized
INFO - 2025-01-24 15:22:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:22:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:22:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:53:12 --> Config Class Initialized
INFO - 2025-01-24 09:53:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:53:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:53:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:53:12 --> URI Class Initialized
INFO - 2025-01-24 09:53:12 --> Router Class Initialized
INFO - 2025-01-24 09:53:12 --> Output Class Initialized
INFO - 2025-01-24 09:53:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:53:12 --> Input Class Initialized
INFO - 2025-01-24 09:53:12 --> Language Class Initialized
INFO - 2025-01-24 09:53:12 --> Loader Class Initialized
INFO - 2025-01-24 09:53:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:53:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:53:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:53:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:53:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:53:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:53:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:53:12 --> Upload Class Initialized
INFO - 2025-01-24 09:53:12 --> Email Class Initialized
INFO - 2025-01-24 09:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:53:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:53:12 --> Controller Class Initialized
INFO - 2025-01-24 15:23:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:23:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:23:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:54:12 --> Config Class Initialized
INFO - 2025-01-24 09:54:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:54:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:54:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:54:12 --> URI Class Initialized
INFO - 2025-01-24 09:54:12 --> Router Class Initialized
INFO - 2025-01-24 09:54:12 --> Output Class Initialized
INFO - 2025-01-24 09:54:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:54:12 --> Input Class Initialized
INFO - 2025-01-24 09:54:12 --> Language Class Initialized
INFO - 2025-01-24 09:54:12 --> Loader Class Initialized
INFO - 2025-01-24 09:54:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:54:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:54:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:54:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:54:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:54:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:54:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:54:12 --> Upload Class Initialized
INFO - 2025-01-24 09:54:12 --> Email Class Initialized
INFO - 2025-01-24 09:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:54:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:54:12 --> Controller Class Initialized
INFO - 2025-01-24 15:24:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:24:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:24:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:55:12 --> Config Class Initialized
INFO - 2025-01-24 09:55:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:55:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:55:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:55:12 --> URI Class Initialized
INFO - 2025-01-24 09:55:12 --> Router Class Initialized
INFO - 2025-01-24 09:55:12 --> Output Class Initialized
INFO - 2025-01-24 09:55:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:55:12 --> Input Class Initialized
INFO - 2025-01-24 09:55:12 --> Language Class Initialized
INFO - 2025-01-24 09:55:12 --> Loader Class Initialized
INFO - 2025-01-24 09:55:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:55:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:55:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:55:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:55:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:55:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:55:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:55:12 --> Upload Class Initialized
INFO - 2025-01-24 09:55:12 --> Email Class Initialized
INFO - 2025-01-24 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:55:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:55:12 --> Controller Class Initialized
INFO - 2025-01-24 15:25:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:25:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:25:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:56:12 --> Config Class Initialized
INFO - 2025-01-24 09:56:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:56:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:56:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:56:12 --> URI Class Initialized
INFO - 2025-01-24 09:56:12 --> Router Class Initialized
INFO - 2025-01-24 09:56:12 --> Output Class Initialized
INFO - 2025-01-24 09:56:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:56:12 --> Input Class Initialized
INFO - 2025-01-24 09:56:12 --> Language Class Initialized
INFO - 2025-01-24 09:56:12 --> Loader Class Initialized
INFO - 2025-01-24 09:56:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:56:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:56:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:56:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:56:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:56:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:56:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:56:12 --> Upload Class Initialized
INFO - 2025-01-24 09:56:12 --> Email Class Initialized
INFO - 2025-01-24 09:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:56:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:56:12 --> Controller Class Initialized
INFO - 2025-01-24 15:26:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:26:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:26:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:57:12 --> Config Class Initialized
INFO - 2025-01-24 09:57:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:57:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:57:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:57:12 --> URI Class Initialized
INFO - 2025-01-24 09:57:12 --> Router Class Initialized
INFO - 2025-01-24 09:57:12 --> Output Class Initialized
INFO - 2025-01-24 09:57:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:57:12 --> Input Class Initialized
INFO - 2025-01-24 09:57:12 --> Language Class Initialized
INFO - 2025-01-24 09:57:12 --> Loader Class Initialized
INFO - 2025-01-24 09:57:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:57:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:57:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:57:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:57:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:57:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:57:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:57:12 --> Upload Class Initialized
INFO - 2025-01-24 09:57:12 --> Email Class Initialized
INFO - 2025-01-24 09:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:57:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:57:12 --> Controller Class Initialized
INFO - 2025-01-24 15:27:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:27:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:27:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:58:12 --> Config Class Initialized
INFO - 2025-01-24 09:58:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:58:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:58:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:58:12 --> URI Class Initialized
INFO - 2025-01-24 09:58:12 --> Router Class Initialized
INFO - 2025-01-24 09:58:12 --> Output Class Initialized
INFO - 2025-01-24 09:58:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:58:12 --> Input Class Initialized
INFO - 2025-01-24 09:58:12 --> Language Class Initialized
INFO - 2025-01-24 09:58:12 --> Loader Class Initialized
INFO - 2025-01-24 09:58:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:58:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:58:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:58:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:58:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:58:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:58:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:58:12 --> Upload Class Initialized
INFO - 2025-01-24 09:58:12 --> Email Class Initialized
INFO - 2025-01-24 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:58:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:58:12 --> Controller Class Initialized
INFO - 2025-01-24 15:28:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:28:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:28:12 --> Pagination Class Initialized
INFO - 2025-01-24 09:59:12 --> Config Class Initialized
INFO - 2025-01-24 09:59:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 09:59:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 09:59:12 --> Utf8 Class Initialized
INFO - 2025-01-24 09:59:12 --> URI Class Initialized
INFO - 2025-01-24 09:59:12 --> Router Class Initialized
INFO - 2025-01-24 09:59:12 --> Output Class Initialized
INFO - 2025-01-24 09:59:12 --> Security Class Initialized
DEBUG - 2025-01-24 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 09:59:12 --> Input Class Initialized
INFO - 2025-01-24 09:59:12 --> Language Class Initialized
INFO - 2025-01-24 09:59:12 --> Loader Class Initialized
INFO - 2025-01-24 09:59:12 --> Helper loaded: url_helper
INFO - 2025-01-24 09:59:12 --> Helper loaded: html_helper
INFO - 2025-01-24 09:59:12 --> Helper loaded: file_helper
INFO - 2025-01-24 09:59:12 --> Helper loaded: string_helper
INFO - 2025-01-24 09:59:12 --> Helper loaded: form_helper
INFO - 2025-01-24 09:59:12 --> Helper loaded: my_helper
INFO - 2025-01-24 09:59:12 --> Database Driver Class Initialized
INFO - 2025-01-24 09:59:12 --> Upload Class Initialized
INFO - 2025-01-24 09:59:12 --> Email Class Initialized
INFO - 2025-01-24 09:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 09:59:12 --> Form Validation Class Initialized
INFO - 2025-01-24 09:59:12 --> Controller Class Initialized
INFO - 2025-01-24 15:29:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:29:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:29:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:00:12 --> Config Class Initialized
INFO - 2025-01-24 10:00:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:00:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:00:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:00:12 --> URI Class Initialized
INFO - 2025-01-24 10:00:12 --> Router Class Initialized
INFO - 2025-01-24 10:00:12 --> Output Class Initialized
INFO - 2025-01-24 10:00:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:00:12 --> Input Class Initialized
INFO - 2025-01-24 10:00:12 --> Language Class Initialized
INFO - 2025-01-24 10:00:12 --> Loader Class Initialized
INFO - 2025-01-24 10:00:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:00:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:00:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:00:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:00:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:00:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:00:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:00:12 --> Upload Class Initialized
INFO - 2025-01-24 10:00:12 --> Email Class Initialized
INFO - 2025-01-24 10:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:00:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:00:12 --> Controller Class Initialized
INFO - 2025-01-24 15:30:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:30:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:30:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:01:12 --> Config Class Initialized
INFO - 2025-01-24 10:01:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:01:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:01:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:01:12 --> URI Class Initialized
INFO - 2025-01-24 10:01:12 --> Router Class Initialized
INFO - 2025-01-24 10:01:12 --> Output Class Initialized
INFO - 2025-01-24 10:01:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:01:12 --> Input Class Initialized
INFO - 2025-01-24 10:01:12 --> Language Class Initialized
INFO - 2025-01-24 10:01:12 --> Loader Class Initialized
INFO - 2025-01-24 10:01:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:01:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:01:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:01:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:01:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:01:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:01:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:01:12 --> Upload Class Initialized
INFO - 2025-01-24 10:01:12 --> Email Class Initialized
INFO - 2025-01-24 10:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:01:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:01:12 --> Controller Class Initialized
INFO - 2025-01-24 15:31:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:31:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:31:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:02:12 --> Config Class Initialized
INFO - 2025-01-24 10:02:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:02:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:02:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:02:12 --> URI Class Initialized
INFO - 2025-01-24 10:02:12 --> Router Class Initialized
INFO - 2025-01-24 10:02:12 --> Output Class Initialized
INFO - 2025-01-24 10:02:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:02:12 --> Input Class Initialized
INFO - 2025-01-24 10:02:12 --> Language Class Initialized
INFO - 2025-01-24 10:02:12 --> Loader Class Initialized
INFO - 2025-01-24 10:02:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:02:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:02:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:02:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:02:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:02:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:02:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:02:12 --> Upload Class Initialized
INFO - 2025-01-24 10:02:12 --> Email Class Initialized
INFO - 2025-01-24 10:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:02:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:02:12 --> Controller Class Initialized
INFO - 2025-01-24 15:32:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:32:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:32:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:03:12 --> Config Class Initialized
INFO - 2025-01-24 10:03:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:03:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:03:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:03:12 --> URI Class Initialized
INFO - 2025-01-24 10:03:12 --> Router Class Initialized
INFO - 2025-01-24 10:03:12 --> Output Class Initialized
INFO - 2025-01-24 10:03:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:03:12 --> Input Class Initialized
INFO - 2025-01-24 10:03:12 --> Language Class Initialized
INFO - 2025-01-24 10:03:12 --> Loader Class Initialized
INFO - 2025-01-24 10:03:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:03:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:03:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:03:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:03:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:03:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:03:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:03:12 --> Upload Class Initialized
INFO - 2025-01-24 10:03:12 --> Email Class Initialized
INFO - 2025-01-24 10:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:03:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:03:12 --> Controller Class Initialized
INFO - 2025-01-24 15:33:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:33:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:33:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:33:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:04:12 --> Config Class Initialized
INFO - 2025-01-24 10:04:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:04:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:04:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:04:12 --> URI Class Initialized
INFO - 2025-01-24 10:04:12 --> Router Class Initialized
INFO - 2025-01-24 10:04:12 --> Output Class Initialized
INFO - 2025-01-24 10:04:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:04:12 --> Input Class Initialized
INFO - 2025-01-24 10:04:12 --> Language Class Initialized
INFO - 2025-01-24 10:04:12 --> Loader Class Initialized
INFO - 2025-01-24 10:04:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:04:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:04:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:04:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:04:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:04:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:04:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:04:12 --> Upload Class Initialized
INFO - 2025-01-24 10:04:12 --> Email Class Initialized
INFO - 2025-01-24 10:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:04:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:04:12 --> Controller Class Initialized
INFO - 2025-01-24 15:34:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:34:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:34:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:05:12 --> Config Class Initialized
INFO - 2025-01-24 10:05:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:05:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:05:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:05:12 --> URI Class Initialized
INFO - 2025-01-24 10:05:12 --> Router Class Initialized
INFO - 2025-01-24 10:05:12 --> Output Class Initialized
INFO - 2025-01-24 10:05:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:05:12 --> Input Class Initialized
INFO - 2025-01-24 10:05:12 --> Language Class Initialized
INFO - 2025-01-24 10:05:12 --> Loader Class Initialized
INFO - 2025-01-24 10:05:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:05:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:05:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:05:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:05:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:05:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:05:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:05:12 --> Upload Class Initialized
INFO - 2025-01-24 10:05:12 --> Email Class Initialized
INFO - 2025-01-24 10:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:05:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:05:12 --> Controller Class Initialized
INFO - 2025-01-24 15:35:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:35:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:35:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:06:12 --> Config Class Initialized
INFO - 2025-01-24 10:06:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:06:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:06:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:06:12 --> URI Class Initialized
INFO - 2025-01-24 10:06:12 --> Router Class Initialized
INFO - 2025-01-24 10:06:12 --> Output Class Initialized
INFO - 2025-01-24 10:06:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:06:12 --> Input Class Initialized
INFO - 2025-01-24 10:06:12 --> Language Class Initialized
INFO - 2025-01-24 10:06:12 --> Loader Class Initialized
INFO - 2025-01-24 10:06:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:06:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:06:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:06:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:06:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:06:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:06:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:06:12 --> Upload Class Initialized
INFO - 2025-01-24 10:06:12 --> Email Class Initialized
INFO - 2025-01-24 10:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:06:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:06:12 --> Controller Class Initialized
INFO - 2025-01-24 15:36:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:36:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:36:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:07:12 --> Config Class Initialized
INFO - 2025-01-24 10:07:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:07:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:07:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:07:12 --> URI Class Initialized
INFO - 2025-01-24 10:07:12 --> Router Class Initialized
INFO - 2025-01-24 10:07:12 --> Output Class Initialized
INFO - 2025-01-24 10:07:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:07:12 --> Input Class Initialized
INFO - 2025-01-24 10:07:12 --> Language Class Initialized
INFO - 2025-01-24 10:07:12 --> Loader Class Initialized
INFO - 2025-01-24 10:07:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:07:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:07:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:07:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:07:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:07:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:07:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:07:12 --> Upload Class Initialized
INFO - 2025-01-24 10:07:12 --> Email Class Initialized
INFO - 2025-01-24 10:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:07:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:07:12 --> Controller Class Initialized
INFO - 2025-01-24 15:37:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:37:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:37:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:08:12 --> Config Class Initialized
INFO - 2025-01-24 10:08:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:08:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:08:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:08:12 --> URI Class Initialized
INFO - 2025-01-24 10:08:12 --> Router Class Initialized
INFO - 2025-01-24 10:08:12 --> Output Class Initialized
INFO - 2025-01-24 10:08:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:08:12 --> Input Class Initialized
INFO - 2025-01-24 10:08:12 --> Language Class Initialized
INFO - 2025-01-24 10:08:12 --> Loader Class Initialized
INFO - 2025-01-24 10:08:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:08:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:08:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:08:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:08:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:08:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:08:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:08:12 --> Upload Class Initialized
INFO - 2025-01-24 10:08:12 --> Email Class Initialized
INFO - 2025-01-24 10:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:08:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:08:12 --> Controller Class Initialized
INFO - 2025-01-24 15:38:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:38:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:38:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:09:12 --> Config Class Initialized
INFO - 2025-01-24 10:09:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:09:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:09:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:09:12 --> URI Class Initialized
INFO - 2025-01-24 10:09:12 --> Router Class Initialized
INFO - 2025-01-24 10:09:12 --> Output Class Initialized
INFO - 2025-01-24 10:09:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:09:12 --> Input Class Initialized
INFO - 2025-01-24 10:09:12 --> Language Class Initialized
INFO - 2025-01-24 10:09:12 --> Loader Class Initialized
INFO - 2025-01-24 10:09:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:09:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:09:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:09:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:09:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:09:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:09:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:09:12 --> Upload Class Initialized
INFO - 2025-01-24 10:09:12 --> Email Class Initialized
INFO - 2025-01-24 10:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:09:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:09:12 --> Controller Class Initialized
INFO - 2025-01-24 15:39:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:39:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:39:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:10:12 --> Config Class Initialized
INFO - 2025-01-24 10:10:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:10:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:10:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:10:12 --> URI Class Initialized
INFO - 2025-01-24 10:10:12 --> Router Class Initialized
INFO - 2025-01-24 10:10:12 --> Output Class Initialized
INFO - 2025-01-24 10:10:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:10:12 --> Input Class Initialized
INFO - 2025-01-24 10:10:12 --> Language Class Initialized
INFO - 2025-01-24 10:10:12 --> Loader Class Initialized
INFO - 2025-01-24 10:10:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:10:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:10:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:10:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:10:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:10:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:10:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:10:12 --> Upload Class Initialized
INFO - 2025-01-24 10:10:12 --> Email Class Initialized
INFO - 2025-01-24 10:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:10:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:10:12 --> Controller Class Initialized
INFO - 2025-01-24 15:40:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:40:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:40:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:11:12 --> Config Class Initialized
INFO - 2025-01-24 10:11:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:11:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:11:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:11:12 --> URI Class Initialized
INFO - 2025-01-24 10:11:12 --> Router Class Initialized
INFO - 2025-01-24 10:11:12 --> Output Class Initialized
INFO - 2025-01-24 10:11:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:11:12 --> Input Class Initialized
INFO - 2025-01-24 10:11:12 --> Language Class Initialized
INFO - 2025-01-24 10:11:12 --> Loader Class Initialized
INFO - 2025-01-24 10:11:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:11:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:11:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:11:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:11:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:11:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:11:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:11:12 --> Upload Class Initialized
INFO - 2025-01-24 10:11:12 --> Email Class Initialized
INFO - 2025-01-24 10:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:11:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:11:12 --> Controller Class Initialized
INFO - 2025-01-24 15:41:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:41:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:41:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:12:12 --> Config Class Initialized
INFO - 2025-01-24 10:12:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:12:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:12:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:12:12 --> URI Class Initialized
INFO - 2025-01-24 10:12:12 --> Router Class Initialized
INFO - 2025-01-24 10:12:12 --> Output Class Initialized
INFO - 2025-01-24 10:12:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:12:12 --> Input Class Initialized
INFO - 2025-01-24 10:12:12 --> Language Class Initialized
INFO - 2025-01-24 10:12:12 --> Loader Class Initialized
INFO - 2025-01-24 10:12:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:12:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:12:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:12:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:12:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:12:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:12:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:12:12 --> Upload Class Initialized
INFO - 2025-01-24 10:12:12 --> Email Class Initialized
INFO - 2025-01-24 10:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:12:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:12:12 --> Controller Class Initialized
INFO - 2025-01-24 15:42:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:42:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:42:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:13:12 --> Config Class Initialized
INFO - 2025-01-24 10:13:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:13:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:13:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:13:12 --> URI Class Initialized
INFO - 2025-01-24 10:13:12 --> Router Class Initialized
INFO - 2025-01-24 10:13:12 --> Output Class Initialized
INFO - 2025-01-24 10:13:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:13:12 --> Input Class Initialized
INFO - 2025-01-24 10:13:12 --> Language Class Initialized
INFO - 2025-01-24 10:13:12 --> Loader Class Initialized
INFO - 2025-01-24 10:13:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:13:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:13:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:13:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:13:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:13:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:13:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:13:12 --> Upload Class Initialized
INFO - 2025-01-24 10:13:12 --> Email Class Initialized
INFO - 2025-01-24 10:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:13:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:13:12 --> Controller Class Initialized
INFO - 2025-01-24 15:43:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:43:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:43:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:14:12 --> Config Class Initialized
INFO - 2025-01-24 10:14:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:14:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:14:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:14:12 --> URI Class Initialized
INFO - 2025-01-24 10:14:12 --> Router Class Initialized
INFO - 2025-01-24 10:14:12 --> Output Class Initialized
INFO - 2025-01-24 10:14:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:14:12 --> Input Class Initialized
INFO - 2025-01-24 10:14:12 --> Language Class Initialized
INFO - 2025-01-24 10:14:12 --> Loader Class Initialized
INFO - 2025-01-24 10:14:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:14:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:14:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:14:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:14:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:14:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:14:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:14:12 --> Upload Class Initialized
INFO - 2025-01-24 10:14:12 --> Email Class Initialized
INFO - 2025-01-24 10:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:14:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:14:12 --> Controller Class Initialized
INFO - 2025-01-24 15:44:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:44:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:44:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:15:12 --> Config Class Initialized
INFO - 2025-01-24 10:15:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:15:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:15:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:15:12 --> URI Class Initialized
INFO - 2025-01-24 10:15:12 --> Router Class Initialized
INFO - 2025-01-24 10:15:12 --> Output Class Initialized
INFO - 2025-01-24 10:15:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:15:12 --> Input Class Initialized
INFO - 2025-01-24 10:15:12 --> Language Class Initialized
INFO - 2025-01-24 10:15:12 --> Loader Class Initialized
INFO - 2025-01-24 10:15:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:15:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:15:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:15:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:15:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:15:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:15:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:15:12 --> Upload Class Initialized
INFO - 2025-01-24 10:15:12 --> Email Class Initialized
INFO - 2025-01-24 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:15:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:15:12 --> Controller Class Initialized
INFO - 2025-01-24 15:45:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:45:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:45:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:16:12 --> Config Class Initialized
INFO - 2025-01-24 10:16:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:16:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:16:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:16:12 --> URI Class Initialized
INFO - 2025-01-24 10:16:12 --> Router Class Initialized
INFO - 2025-01-24 10:16:12 --> Output Class Initialized
INFO - 2025-01-24 10:16:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:16:12 --> Input Class Initialized
INFO - 2025-01-24 10:16:12 --> Language Class Initialized
INFO - 2025-01-24 10:16:12 --> Loader Class Initialized
INFO - 2025-01-24 10:16:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:16:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:16:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:16:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:16:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:16:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:16:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:16:12 --> Upload Class Initialized
INFO - 2025-01-24 10:16:12 --> Email Class Initialized
INFO - 2025-01-24 10:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:16:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:16:12 --> Controller Class Initialized
INFO - 2025-01-24 15:46:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:46:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:46:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:17:12 --> Config Class Initialized
INFO - 2025-01-24 10:17:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:17:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:17:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:17:12 --> URI Class Initialized
INFO - 2025-01-24 10:17:12 --> Router Class Initialized
INFO - 2025-01-24 10:17:12 --> Output Class Initialized
INFO - 2025-01-24 10:17:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:17:12 --> Input Class Initialized
INFO - 2025-01-24 10:17:12 --> Language Class Initialized
INFO - 2025-01-24 10:17:12 --> Loader Class Initialized
INFO - 2025-01-24 10:17:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:17:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:17:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:17:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:17:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:17:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:17:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:17:12 --> Upload Class Initialized
INFO - 2025-01-24 10:17:12 --> Email Class Initialized
INFO - 2025-01-24 10:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:17:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:17:12 --> Controller Class Initialized
INFO - 2025-01-24 15:47:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:47:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:47:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:18:12 --> Config Class Initialized
INFO - 2025-01-24 10:18:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:18:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:18:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:18:12 --> URI Class Initialized
INFO - 2025-01-24 10:18:12 --> Router Class Initialized
INFO - 2025-01-24 10:18:12 --> Output Class Initialized
INFO - 2025-01-24 10:18:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:18:12 --> Input Class Initialized
INFO - 2025-01-24 10:18:12 --> Language Class Initialized
INFO - 2025-01-24 10:18:12 --> Loader Class Initialized
INFO - 2025-01-24 10:18:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:18:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:18:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:18:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:18:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:18:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:18:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:18:12 --> Upload Class Initialized
INFO - 2025-01-24 10:18:12 --> Email Class Initialized
INFO - 2025-01-24 10:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:18:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:18:12 --> Controller Class Initialized
INFO - 2025-01-24 15:48:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:48:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:48:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:19:12 --> Config Class Initialized
INFO - 2025-01-24 10:19:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:19:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:19:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:19:12 --> URI Class Initialized
INFO - 2025-01-24 10:19:12 --> Router Class Initialized
INFO - 2025-01-24 10:19:12 --> Output Class Initialized
INFO - 2025-01-24 10:19:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:19:12 --> Input Class Initialized
INFO - 2025-01-24 10:19:12 --> Language Class Initialized
INFO - 2025-01-24 10:19:12 --> Loader Class Initialized
INFO - 2025-01-24 10:19:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:19:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:19:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:19:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:19:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:19:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:19:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:19:12 --> Upload Class Initialized
INFO - 2025-01-24 10:19:12 --> Email Class Initialized
INFO - 2025-01-24 10:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:19:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:19:12 --> Controller Class Initialized
INFO - 2025-01-24 15:49:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:49:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:49:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:20:12 --> Config Class Initialized
INFO - 2025-01-24 10:20:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:20:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:20:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:20:12 --> URI Class Initialized
INFO - 2025-01-24 10:20:12 --> Router Class Initialized
INFO - 2025-01-24 10:20:12 --> Output Class Initialized
INFO - 2025-01-24 10:20:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:20:12 --> Input Class Initialized
INFO - 2025-01-24 10:20:12 --> Language Class Initialized
INFO - 2025-01-24 10:20:12 --> Loader Class Initialized
INFO - 2025-01-24 10:20:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:20:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:20:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:20:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:20:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:20:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:20:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:20:12 --> Upload Class Initialized
INFO - 2025-01-24 10:20:12 --> Email Class Initialized
INFO - 2025-01-24 10:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:20:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:20:12 --> Controller Class Initialized
INFO - 2025-01-24 15:50:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:50:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:50:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:21:12 --> Config Class Initialized
INFO - 2025-01-24 10:21:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:21:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:21:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:21:12 --> URI Class Initialized
INFO - 2025-01-24 10:21:12 --> Router Class Initialized
INFO - 2025-01-24 10:21:12 --> Output Class Initialized
INFO - 2025-01-24 10:21:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:21:12 --> Input Class Initialized
INFO - 2025-01-24 10:21:12 --> Language Class Initialized
INFO - 2025-01-24 10:21:12 --> Loader Class Initialized
INFO - 2025-01-24 10:21:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:21:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:21:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:21:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:21:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:21:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:21:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:21:12 --> Upload Class Initialized
INFO - 2025-01-24 10:21:12 --> Email Class Initialized
INFO - 2025-01-24 10:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:21:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:21:12 --> Controller Class Initialized
INFO - 2025-01-24 15:51:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:51:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:51:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:51:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:22:12 --> Config Class Initialized
INFO - 2025-01-24 10:22:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:22:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:22:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:22:12 --> URI Class Initialized
INFO - 2025-01-24 10:22:12 --> Router Class Initialized
INFO - 2025-01-24 10:22:12 --> Output Class Initialized
INFO - 2025-01-24 10:22:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:22:12 --> Input Class Initialized
INFO - 2025-01-24 10:22:12 --> Language Class Initialized
INFO - 2025-01-24 10:22:12 --> Loader Class Initialized
INFO - 2025-01-24 10:22:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:22:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:22:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:22:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:22:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:22:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:22:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:22:12 --> Upload Class Initialized
INFO - 2025-01-24 10:22:12 --> Email Class Initialized
INFO - 2025-01-24 10:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:22:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:22:12 --> Controller Class Initialized
INFO - 2025-01-24 15:52:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:52:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:52:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:23:12 --> Config Class Initialized
INFO - 2025-01-24 10:23:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:23:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:23:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:23:12 --> URI Class Initialized
INFO - 2025-01-24 10:23:12 --> Router Class Initialized
INFO - 2025-01-24 10:23:12 --> Output Class Initialized
INFO - 2025-01-24 10:23:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:23:12 --> Input Class Initialized
INFO - 2025-01-24 10:23:12 --> Language Class Initialized
INFO - 2025-01-24 10:23:12 --> Loader Class Initialized
INFO - 2025-01-24 10:23:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:23:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:23:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:23:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:23:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:23:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:23:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:23:12 --> Upload Class Initialized
INFO - 2025-01-24 10:23:12 --> Email Class Initialized
INFO - 2025-01-24 10:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:23:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:23:12 --> Controller Class Initialized
INFO - 2025-01-24 15:53:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:53:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:53:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:24:46 --> Config Class Initialized
INFO - 2025-01-24 10:24:46 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:24:46 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:24:46 --> Utf8 Class Initialized
INFO - 2025-01-24 10:24:46 --> URI Class Initialized
INFO - 2025-01-24 10:24:46 --> Router Class Initialized
INFO - 2025-01-24 10:24:46 --> Output Class Initialized
INFO - 2025-01-24 10:24:46 --> Security Class Initialized
DEBUG - 2025-01-24 10:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:24:46 --> Input Class Initialized
INFO - 2025-01-24 10:24:46 --> Language Class Initialized
INFO - 2025-01-24 10:24:46 --> Loader Class Initialized
INFO - 2025-01-24 10:24:46 --> Helper loaded: url_helper
INFO - 2025-01-24 10:24:46 --> Helper loaded: html_helper
INFO - 2025-01-24 10:24:46 --> Helper loaded: file_helper
INFO - 2025-01-24 10:24:46 --> Helper loaded: string_helper
INFO - 2025-01-24 10:24:46 --> Helper loaded: form_helper
INFO - 2025-01-24 10:24:46 --> Helper loaded: my_helper
INFO - 2025-01-24 10:24:46 --> Database Driver Class Initialized
INFO - 2025-01-24 10:24:46 --> Upload Class Initialized
INFO - 2025-01-24 10:24:46 --> Email Class Initialized
INFO - 2025-01-24 10:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:24:46 --> Form Validation Class Initialized
INFO - 2025-01-24 10:24:46 --> Controller Class Initialized
INFO - 2025-01-24 15:54:46 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:54:46 --> Model "MainModel" initialized
INFO - 2025-01-24 15:54:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:54:46 --> Pagination Class Initialized
INFO - 2025-01-24 10:25:12 --> Config Class Initialized
INFO - 2025-01-24 10:25:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:25:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:25:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:25:12 --> URI Class Initialized
INFO - 2025-01-24 10:25:12 --> Router Class Initialized
INFO - 2025-01-24 10:25:12 --> Output Class Initialized
INFO - 2025-01-24 10:25:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:25:12 --> Input Class Initialized
INFO - 2025-01-24 10:25:12 --> Language Class Initialized
INFO - 2025-01-24 10:25:12 --> Loader Class Initialized
INFO - 2025-01-24 10:25:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:25:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:25:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:25:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:25:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:25:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:25:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:25:12 --> Upload Class Initialized
INFO - 2025-01-24 10:25:12 --> Email Class Initialized
INFO - 2025-01-24 10:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:25:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:25:12 --> Controller Class Initialized
INFO - 2025-01-24 15:55:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:55:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:55:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:26:12 --> Config Class Initialized
INFO - 2025-01-24 10:26:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:26:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:26:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:26:12 --> URI Class Initialized
INFO - 2025-01-24 10:26:12 --> Router Class Initialized
INFO - 2025-01-24 10:26:12 --> Output Class Initialized
INFO - 2025-01-24 10:26:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:26:12 --> Input Class Initialized
INFO - 2025-01-24 10:26:12 --> Language Class Initialized
INFO - 2025-01-24 10:26:12 --> Loader Class Initialized
INFO - 2025-01-24 10:26:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:26:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:26:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:26:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:26:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:26:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:26:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:26:12 --> Upload Class Initialized
INFO - 2025-01-24 10:26:12 --> Email Class Initialized
INFO - 2025-01-24 10:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:26:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:26:12 --> Controller Class Initialized
INFO - 2025-01-24 15:56:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:56:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:56:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:27:12 --> Config Class Initialized
INFO - 2025-01-24 10:27:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:27:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:27:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:27:12 --> URI Class Initialized
INFO - 2025-01-24 10:27:12 --> Router Class Initialized
INFO - 2025-01-24 10:27:12 --> Output Class Initialized
INFO - 2025-01-24 10:27:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:27:12 --> Input Class Initialized
INFO - 2025-01-24 10:27:12 --> Language Class Initialized
INFO - 2025-01-24 10:27:12 --> Loader Class Initialized
INFO - 2025-01-24 10:27:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:27:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:27:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:27:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:27:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:27:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:27:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:27:12 --> Upload Class Initialized
INFO - 2025-01-24 10:27:12 --> Email Class Initialized
INFO - 2025-01-24 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:27:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:27:12 --> Controller Class Initialized
INFO - 2025-01-24 15:57:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:57:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:57:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:57:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:28:12 --> Config Class Initialized
INFO - 2025-01-24 10:28:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:28:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:28:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:28:12 --> URI Class Initialized
INFO - 2025-01-24 10:28:12 --> Router Class Initialized
INFO - 2025-01-24 10:28:12 --> Output Class Initialized
INFO - 2025-01-24 10:28:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:28:12 --> Input Class Initialized
INFO - 2025-01-24 10:28:12 --> Language Class Initialized
INFO - 2025-01-24 10:28:12 --> Loader Class Initialized
INFO - 2025-01-24 10:28:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:28:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:28:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:28:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:28:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:28:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:28:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:28:12 --> Upload Class Initialized
INFO - 2025-01-24 10:28:12 --> Email Class Initialized
INFO - 2025-01-24 10:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:28:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:28:12 --> Controller Class Initialized
INFO - 2025-01-24 15:58:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:58:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:58:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:29:12 --> Config Class Initialized
INFO - 2025-01-24 10:29:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:29:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:29:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:29:12 --> URI Class Initialized
INFO - 2025-01-24 10:29:12 --> Router Class Initialized
INFO - 2025-01-24 10:29:12 --> Output Class Initialized
INFO - 2025-01-24 10:29:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:29:12 --> Input Class Initialized
INFO - 2025-01-24 10:29:12 --> Language Class Initialized
INFO - 2025-01-24 10:29:12 --> Loader Class Initialized
INFO - 2025-01-24 10:29:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:29:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:29:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:29:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:29:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:29:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:29:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:29:12 --> Upload Class Initialized
INFO - 2025-01-24 10:29:12 --> Email Class Initialized
INFO - 2025-01-24 10:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:29:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:29:12 --> Controller Class Initialized
INFO - 2025-01-24 15:59:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 15:59:12 --> Model "MainModel" initialized
INFO - 2025-01-24 15:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 15:59:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:30:12 --> Config Class Initialized
INFO - 2025-01-24 10:30:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:30:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:30:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:30:12 --> URI Class Initialized
INFO - 2025-01-24 10:30:12 --> Router Class Initialized
INFO - 2025-01-24 10:30:12 --> Output Class Initialized
INFO - 2025-01-24 10:30:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:30:12 --> Input Class Initialized
INFO - 2025-01-24 10:30:12 --> Language Class Initialized
INFO - 2025-01-24 10:30:12 --> Loader Class Initialized
INFO - 2025-01-24 10:30:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:30:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:30:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:30:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:30:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:30:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:30:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:30:12 --> Upload Class Initialized
INFO - 2025-01-24 10:30:12 --> Email Class Initialized
INFO - 2025-01-24 10:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:30:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:30:12 --> Controller Class Initialized
INFO - 2025-01-24 16:00:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 16:00:12 --> Model "MainModel" initialized
INFO - 2025-01-24 16:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 16:00:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:31:12 --> Config Class Initialized
INFO - 2025-01-24 10:31:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:31:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:31:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:31:12 --> URI Class Initialized
INFO - 2025-01-24 10:31:12 --> Router Class Initialized
INFO - 2025-01-24 10:31:12 --> Output Class Initialized
INFO - 2025-01-24 10:31:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:31:12 --> Input Class Initialized
INFO - 2025-01-24 10:31:12 --> Language Class Initialized
INFO - 2025-01-24 10:31:12 --> Loader Class Initialized
INFO - 2025-01-24 10:31:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:31:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:31:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:31:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:31:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:31:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:31:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:31:12 --> Upload Class Initialized
INFO - 2025-01-24 10:31:12 --> Email Class Initialized
INFO - 2025-01-24 10:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:31:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:31:12 --> Controller Class Initialized
INFO - 2025-01-24 16:01:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 16:01:12 --> Model "MainModel" initialized
INFO - 2025-01-24 16:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 16:01:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:32:12 --> Config Class Initialized
INFO - 2025-01-24 10:32:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:32:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:32:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:32:12 --> URI Class Initialized
INFO - 2025-01-24 10:32:12 --> Router Class Initialized
INFO - 2025-01-24 10:32:12 --> Output Class Initialized
INFO - 2025-01-24 10:32:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:32:12 --> Input Class Initialized
INFO - 2025-01-24 10:32:12 --> Language Class Initialized
INFO - 2025-01-24 10:32:12 --> Loader Class Initialized
INFO - 2025-01-24 10:32:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:32:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:32:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:32:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:32:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:32:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:32:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:32:12 --> Upload Class Initialized
INFO - 2025-01-24 10:32:12 --> Email Class Initialized
INFO - 2025-01-24 10:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:32:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:32:12 --> Controller Class Initialized
INFO - 2025-01-24 16:02:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 16:02:12 --> Model "MainModel" initialized
INFO - 2025-01-24 16:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 16:02:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:33:12 --> Config Class Initialized
INFO - 2025-01-24 10:33:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:33:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:33:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:33:12 --> URI Class Initialized
INFO - 2025-01-24 10:33:12 --> Router Class Initialized
INFO - 2025-01-24 10:33:12 --> Output Class Initialized
INFO - 2025-01-24 10:33:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:33:12 --> Input Class Initialized
INFO - 2025-01-24 10:33:12 --> Language Class Initialized
INFO - 2025-01-24 10:33:12 --> Loader Class Initialized
INFO - 2025-01-24 10:33:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:33:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:33:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:33:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:33:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:33:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:33:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:33:12 --> Upload Class Initialized
INFO - 2025-01-24 10:33:12 --> Email Class Initialized
INFO - 2025-01-24 10:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:33:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:33:12 --> Controller Class Initialized
INFO - 2025-01-24 16:03:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 16:03:12 --> Model "MainModel" initialized
INFO - 2025-01-24 16:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 16:03:12 --> Pagination Class Initialized
INFO - 2025-01-24 10:37:19 --> Config Class Initialized
INFO - 2025-01-24 10:37:19 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:37:19 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:37:19 --> Utf8 Class Initialized
INFO - 2025-01-24 10:37:19 --> URI Class Initialized
INFO - 2025-01-24 10:37:19 --> Router Class Initialized
INFO - 2025-01-24 10:37:19 --> Output Class Initialized
INFO - 2025-01-24 10:37:19 --> Security Class Initialized
DEBUG - 2025-01-24 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:37:19 --> Input Class Initialized
INFO - 2025-01-24 10:37:19 --> Language Class Initialized
INFO - 2025-01-24 10:37:19 --> Loader Class Initialized
INFO - 2025-01-24 10:37:19 --> Helper loaded: url_helper
INFO - 2025-01-24 10:37:19 --> Helper loaded: html_helper
INFO - 2025-01-24 10:37:19 --> Helper loaded: file_helper
INFO - 2025-01-24 10:37:19 --> Helper loaded: string_helper
INFO - 2025-01-24 10:37:19 --> Helper loaded: form_helper
INFO - 2025-01-24 10:37:19 --> Helper loaded: my_helper
INFO - 2025-01-24 10:37:19 --> Database Driver Class Initialized
INFO - 2025-01-24 10:37:19 --> Upload Class Initialized
INFO - 2025-01-24 10:37:19 --> Email Class Initialized
INFO - 2025-01-24 10:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:37:19 --> Form Validation Class Initialized
INFO - 2025-01-24 10:37:19 --> Controller Class Initialized
INFO - 2025-01-24 16:07:19 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 16:07:19 --> Model "MainModel" initialized
INFO - 2025-01-24 16:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 16:07:19 --> Pagination Class Initialized
INFO - 2025-01-24 10:38:12 --> Config Class Initialized
INFO - 2025-01-24 10:38:12 --> Hooks Class Initialized
DEBUG - 2025-01-24 10:38:12 --> UTF-8 Support Enabled
INFO - 2025-01-24 10:38:12 --> Utf8 Class Initialized
INFO - 2025-01-24 10:38:12 --> URI Class Initialized
INFO - 2025-01-24 10:38:12 --> Router Class Initialized
INFO - 2025-01-24 10:38:12 --> Output Class Initialized
INFO - 2025-01-24 10:38:12 --> Security Class Initialized
DEBUG - 2025-01-24 10:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-01-24 10:38:12 --> Input Class Initialized
INFO - 2025-01-24 10:38:12 --> Language Class Initialized
INFO - 2025-01-24 10:38:12 --> Loader Class Initialized
INFO - 2025-01-24 10:38:12 --> Helper loaded: url_helper
INFO - 2025-01-24 10:38:12 --> Helper loaded: html_helper
INFO - 2025-01-24 10:38:12 --> Helper loaded: file_helper
INFO - 2025-01-24 10:38:12 --> Helper loaded: string_helper
INFO - 2025-01-24 10:38:12 --> Helper loaded: form_helper
INFO - 2025-01-24 10:38:12 --> Helper loaded: my_helper
INFO - 2025-01-24 10:38:12 --> Database Driver Class Initialized
INFO - 2025-01-24 10:38:12 --> Upload Class Initialized
INFO - 2025-01-24 10:38:12 --> Email Class Initialized
INFO - 2025-01-24 10:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-01-24 10:38:12 --> Form Validation Class Initialized
INFO - 2025-01-24 10:38:12 --> Controller Class Initialized
INFO - 2025-01-24 16:08:12 --> Model "RoomserviceModel" initialized
INFO - 2025-01-24 16:08:12 --> Model "MainModel" initialized
INFO - 2025-01-24 16:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-01-24 16:08:12 --> Pagination Class Initialized
