<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-25 00:25:04 --> Model "MainModel" initialized
INFO - 2024-10-25 00:25:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 00:25:04 --> Final output sent to browser
DEBUG - 2024-10-25 00:25:04 --> Total execution time: 2.4977
INFO - 2024-10-25 00:25:07 --> Model "MainModel" initialized
INFO - 2024-10-25 00:25:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 00:25:07 --> Final output sent to browser
DEBUG - 2024-10-25 00:25:07 --> Total execution time: 2.2866
INFO - 2024-10-25 00:50:51 --> Model "MainModel" initialized
INFO - 2024-10-25 00:50:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 00:50:51 --> Final output sent to browser
DEBUG - 2024-10-25 00:50:51 --> Total execution time: 2.3937
INFO - 2024-10-25 00:50:54 --> Model "MainModel" initialized
INFO - 2024-10-25 00:50:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 00:50:54 --> Final output sent to browser
DEBUG - 2024-10-25 00:50:54 --> Total execution time: 2.3475
INFO - 2024-10-25 04:18:18 --> Model "MainModel" initialized
INFO - 2024-10-25 04:18:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 04:18:18 --> Final output sent to browser
DEBUG - 2024-10-25 04:18:18 --> Total execution time: 2.4158
INFO - 2024-10-25 04:18:25 --> Model "MainModel" initialized
INFO - 2024-10-25 04:18:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 04:18:25 --> Final output sent to browser
DEBUG - 2024-10-25 04:18:25 --> Total execution time: 2.2838
INFO - 2024-10-25 04:20:17 --> Model "MainModel" initialized
INFO - 2024-10-25 04:20:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 04:20:17 --> Final output sent to browser
DEBUG - 2024-10-25 04:20:17 --> Total execution time: 2.4122
INFO - 2024-10-25 04:30:52 --> Model "MainModel" initialized
INFO - 2024-10-25 04:30:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 04:30:52 --> Final output sent to browser
DEBUG - 2024-10-25 04:30:52 --> Total execution time: 2.4174
INFO - 2024-10-25 04:31:46 --> Model "MainModel" initialized
INFO - 2024-10-25 04:31:46 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 04:31:46 --> Final output sent to browser
DEBUG - 2024-10-25 04:31:46 --> Total execution time: 2.5025
INFO - 2024-10-25 02:58:57 --> Config Class Initialized
INFO - 2024-10-25 02:58:57 --> Hooks Class Initialized
DEBUG - 2024-10-25 02:58:57 --> UTF-8 Support Enabled
INFO - 2024-10-25 02:58:57 --> Utf8 Class Initialized
INFO - 2024-10-25 02:58:57 --> URI Class Initialized
DEBUG - 2024-10-25 02:58:57 --> No URI present. Default controller set.
INFO - 2024-10-25 02:58:57 --> Router Class Initialized
INFO - 2024-10-25 02:58:57 --> Output Class Initialized
INFO - 2024-10-25 02:58:57 --> Security Class Initialized
DEBUG - 2024-10-25 02:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 02:58:57 --> Input Class Initialized
INFO - 2024-10-25 02:58:57 --> Language Class Initialized
INFO - 2024-10-25 02:58:57 --> Loader Class Initialized
INFO - 2024-10-25 02:58:57 --> Helper loaded: url_helper
INFO - 2024-10-25 02:58:57 --> Helper loaded: html_helper
INFO - 2024-10-25 02:58:57 --> Helper loaded: file_helper
INFO - 2024-10-25 02:58:57 --> Helper loaded: string_helper
INFO - 2024-10-25 02:58:57 --> Helper loaded: form_helper
INFO - 2024-10-25 02:58:57 --> Helper loaded: my_helper
INFO - 2024-10-25 02:58:57 --> Database Driver Class Initialized
INFO - 2024-10-25 02:58:59 --> Upload Class Initialized
INFO - 2024-10-25 02:58:59 --> Email Class Initialized
INFO - 2024-10-25 02:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 02:58:59 --> Form Validation Class Initialized
INFO - 2024-10-25 02:58:59 --> Controller Class Initialized
INFO - 2024-10-25 08:28:59 --> Model "MainModel" initialized
INFO - 2024-10-25 08:28:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 08:28:59 --> Final output sent to browser
DEBUG - 2024-10-25 08:28:59 --> Total execution time: 2.2498
INFO - 2024-10-25 09:58:16 --> Config Class Initialized
INFO - 2024-10-25 09:58:16 --> Hooks Class Initialized
DEBUG - 2024-10-25 09:58:16 --> UTF-8 Support Enabled
INFO - 2024-10-25 09:58:16 --> Utf8 Class Initialized
INFO - 2024-10-25 09:58:16 --> URI Class Initialized
INFO - 2024-10-25 09:58:16 --> Router Class Initialized
INFO - 2024-10-25 09:58:16 --> Output Class Initialized
INFO - 2024-10-25 09:58:16 --> Security Class Initialized
DEBUG - 2024-10-25 09:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 09:58:16 --> Input Class Initialized
INFO - 2024-10-25 09:58:16 --> Language Class Initialized
ERROR - 2024-10-25 09:58:16 --> 404 Page Not Found: Wp-admin/setup-config.php
INFO - 2024-10-25 09:58:16 --> Config Class Initialized
INFO - 2024-10-25 09:58:16 --> Hooks Class Initialized
DEBUG - 2024-10-25 09:58:16 --> UTF-8 Support Enabled
INFO - 2024-10-25 09:58:16 --> Utf8 Class Initialized
INFO - 2024-10-25 09:58:16 --> URI Class Initialized
INFO - 2024-10-25 09:58:16 --> Router Class Initialized
INFO - 2024-10-25 09:58:16 --> Output Class Initialized
INFO - 2024-10-25 09:58:16 --> Security Class Initialized
DEBUG - 2024-10-25 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 09:58:17 --> Input Class Initialized
INFO - 2024-10-25 09:58:17 --> Language Class Initialized
ERROR - 2024-10-25 09:58:17 --> 404 Page Not Found: Wordpress/wp-admin
INFO - 2024-10-25 10:40:19 --> Config Class Initialized
INFO - 2024-10-25 10:40:19 --> Hooks Class Initialized
DEBUG - 2024-10-25 10:40:19 --> UTF-8 Support Enabled
INFO - 2024-10-25 10:40:19 --> Utf8 Class Initialized
INFO - 2024-10-25 10:40:19 --> URI Class Initialized
DEBUG - 2024-10-25 10:40:19 --> No URI present. Default controller set.
INFO - 2024-10-25 10:40:19 --> Router Class Initialized
INFO - 2024-10-25 10:40:19 --> Output Class Initialized
INFO - 2024-10-25 10:40:19 --> Security Class Initialized
DEBUG - 2024-10-25 10:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 10:40:19 --> Input Class Initialized
INFO - 2024-10-25 10:40:19 --> Language Class Initialized
INFO - 2024-10-25 10:40:19 --> Loader Class Initialized
INFO - 2024-10-25 10:40:19 --> Helper loaded: url_helper
INFO - 2024-10-25 10:40:19 --> Helper loaded: html_helper
INFO - 2024-10-25 10:40:19 --> Helper loaded: file_helper
INFO - 2024-10-25 10:40:19 --> Helper loaded: string_helper
INFO - 2024-10-25 10:40:19 --> Helper loaded: form_helper
INFO - 2024-10-25 10:40:19 --> Helper loaded: my_helper
INFO - 2024-10-25 10:40:19 --> Database Driver Class Initialized
INFO - 2024-10-25 10:40:22 --> Upload Class Initialized
INFO - 2024-10-25 10:40:22 --> Email Class Initialized
INFO - 2024-10-25 10:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 10:40:23 --> Form Validation Class Initialized
INFO - 2024-10-25 10:40:23 --> Controller Class Initialized
INFO - 2024-10-25 16:10:23 --> Model "MainModel" initialized
INFO - 2024-10-25 16:10:23 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 16:10:23 --> Final output sent to browser
DEBUG - 2024-10-25 16:10:23 --> Total execution time: 4.5676
INFO - 2024-10-25 14:38:37 --> Config Class Initialized
INFO - 2024-10-25 14:38:37 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:37 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:37 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:37 --> URI Class Initialized
DEBUG - 2024-10-25 14:38:37 --> No URI present. Default controller set.
INFO - 2024-10-25 14:38:37 --> Router Class Initialized
INFO - 2024-10-25 14:38:37 --> Output Class Initialized
INFO - 2024-10-25 14:38:37 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:37 --> Input Class Initialized
INFO - 2024-10-25 14:38:37 --> Language Class Initialized
INFO - 2024-10-25 14:38:37 --> Loader Class Initialized
INFO - 2024-10-25 14:38:37 --> Helper loaded: url_helper
INFO - 2024-10-25 14:38:37 --> Helper loaded: html_helper
INFO - 2024-10-25 14:38:37 --> Helper loaded: file_helper
INFO - 2024-10-25 14:38:37 --> Helper loaded: string_helper
INFO - 2024-10-25 14:38:37 --> Helper loaded: form_helper
INFO - 2024-10-25 14:38:37 --> Helper loaded: my_helper
INFO - 2024-10-25 14:38:37 --> Database Driver Class Initialized
INFO - 2024-10-25 14:38:39 --> Upload Class Initialized
INFO - 2024-10-25 14:38:39 --> Email Class Initialized
INFO - 2024-10-25 14:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 14:38:39 --> Form Validation Class Initialized
INFO - 2024-10-25 14:38:39 --> Controller Class Initialized
INFO - 2024-10-25 20:08:39 --> Model "MainModel" initialized
INFO - 2024-10-25 20:08:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 20:08:39 --> Final output sent to browser
DEBUG - 2024-10-25 20:08:39 --> Total execution time: 2.3834
INFO - 2024-10-25 14:38:39 --> Config Class Initialized
INFO - 2024-10-25 14:38:39 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:39 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:39 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:39 --> URI Class Initialized
INFO - 2024-10-25 14:38:39 --> Router Class Initialized
INFO - 2024-10-25 14:38:39 --> Output Class Initialized
INFO - 2024-10-25 14:38:39 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:39 --> Input Class Initialized
INFO - 2024-10-25 14:38:39 --> Language Class Initialized
ERROR - 2024-10-25 14:38:39 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-25 14:38:40 --> Config Class Initialized
INFO - 2024-10-25 14:38:40 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:40 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:40 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:40 --> URI Class Initialized
INFO - 2024-10-25 14:38:40 --> Router Class Initialized
INFO - 2024-10-25 14:38:40 --> Output Class Initialized
INFO - 2024-10-25 14:38:40 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:40 --> Input Class Initialized
INFO - 2024-10-25 14:38:40 --> Language Class Initialized
ERROR - 2024-10-25 14:38:40 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-25 14:38:40 --> Config Class Initialized
INFO - 2024-10-25 14:38:40 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:40 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:40 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:40 --> URI Class Initialized
DEBUG - 2024-10-25 14:38:40 --> No URI present. Default controller set.
INFO - 2024-10-25 14:38:40 --> Router Class Initialized
INFO - 2024-10-25 14:38:40 --> Output Class Initialized
INFO - 2024-10-25 14:38:40 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:40 --> Input Class Initialized
INFO - 2024-10-25 14:38:40 --> Language Class Initialized
INFO - 2024-10-25 14:38:40 --> Loader Class Initialized
INFO - 2024-10-25 14:38:40 --> Helper loaded: url_helper
INFO - 2024-10-25 14:38:40 --> Helper loaded: html_helper
INFO - 2024-10-25 14:38:40 --> Helper loaded: file_helper
INFO - 2024-10-25 14:38:40 --> Helper loaded: string_helper
INFO - 2024-10-25 14:38:40 --> Helper loaded: form_helper
INFO - 2024-10-25 14:38:40 --> Helper loaded: my_helper
INFO - 2024-10-25 14:38:40 --> Database Driver Class Initialized
INFO - 2024-10-25 14:38:42 --> Upload Class Initialized
INFO - 2024-10-25 14:38:42 --> Email Class Initialized
INFO - 2024-10-25 14:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 14:38:42 --> Form Validation Class Initialized
INFO - 2024-10-25 14:38:42 --> Controller Class Initialized
INFO - 2024-10-25 20:08:42 --> Model "MainModel" initialized
INFO - 2024-10-25 20:08:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 20:08:42 --> Final output sent to browser
DEBUG - 2024-10-25 20:08:42 --> Total execution time: 2.1131
INFO - 2024-10-25 14:38:42 --> Config Class Initialized
INFO - 2024-10-25 14:38:42 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:42 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:42 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:42 --> URI Class Initialized
INFO - 2024-10-25 14:38:42 --> Router Class Initialized
INFO - 2024-10-25 14:38:42 --> Output Class Initialized
INFO - 2024-10-25 14:38:42 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:42 --> Input Class Initialized
INFO - 2024-10-25 14:38:42 --> Language Class Initialized
ERROR - 2024-10-25 14:38:42 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-25 14:38:42 --> Config Class Initialized
INFO - 2024-10-25 14:38:42 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:42 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:42 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:42 --> URI Class Initialized
INFO - 2024-10-25 14:38:42 --> Router Class Initialized
INFO - 2024-10-25 14:38:42 --> Output Class Initialized
INFO - 2024-10-25 14:38:43 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:43 --> Input Class Initialized
INFO - 2024-10-25 14:38:43 --> Language Class Initialized
ERROR - 2024-10-25 14:38:43 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-25 14:38:43 --> Config Class Initialized
INFO - 2024-10-25 14:38:43 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:43 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:43 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:43 --> URI Class Initialized
INFO - 2024-10-25 14:38:43 --> Router Class Initialized
INFO - 2024-10-25 14:38:43 --> Output Class Initialized
INFO - 2024-10-25 14:38:43 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:43 --> Input Class Initialized
INFO - 2024-10-25 14:38:43 --> Language Class Initialized
ERROR - 2024-10-25 14:38:43 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-25 14:38:43 --> Config Class Initialized
INFO - 2024-10-25 14:38:43 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:43 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:43 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:43 --> URI Class Initialized
INFO - 2024-10-25 14:38:43 --> Router Class Initialized
INFO - 2024-10-25 14:38:43 --> Output Class Initialized
INFO - 2024-10-25 14:38:43 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:43 --> Input Class Initialized
INFO - 2024-10-25 14:38:43 --> Language Class Initialized
ERROR - 2024-10-25 14:38:43 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-25 14:38:43 --> Config Class Initialized
INFO - 2024-10-25 14:38:43 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:43 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:43 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:43 --> URI Class Initialized
INFO - 2024-10-25 14:38:43 --> Router Class Initialized
INFO - 2024-10-25 14:38:43 --> Output Class Initialized
INFO - 2024-10-25 14:38:43 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:43 --> Input Class Initialized
INFO - 2024-10-25 14:38:43 --> Language Class Initialized
ERROR - 2024-10-25 14:38:43 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-25 14:38:44 --> Config Class Initialized
INFO - 2024-10-25 14:38:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:44 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:44 --> URI Class Initialized
INFO - 2024-10-25 14:38:44 --> Router Class Initialized
INFO - 2024-10-25 14:38:44 --> Output Class Initialized
INFO - 2024-10-25 14:38:44 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:44 --> Input Class Initialized
INFO - 2024-10-25 14:38:44 --> Language Class Initialized
ERROR - 2024-10-25 14:38:44 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-25 14:38:44 --> Config Class Initialized
INFO - 2024-10-25 14:38:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:44 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:44 --> URI Class Initialized
INFO - 2024-10-25 14:38:44 --> Router Class Initialized
INFO - 2024-10-25 14:38:44 --> Output Class Initialized
INFO - 2024-10-25 14:38:44 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:44 --> Input Class Initialized
INFO - 2024-10-25 14:38:44 --> Language Class Initialized
ERROR - 2024-10-25 14:38:44 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-25 14:38:44 --> Config Class Initialized
INFO - 2024-10-25 14:38:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:44 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:44 --> URI Class Initialized
INFO - 2024-10-25 14:38:44 --> Router Class Initialized
INFO - 2024-10-25 14:38:44 --> Output Class Initialized
INFO - 2024-10-25 14:38:44 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:44 --> Input Class Initialized
INFO - 2024-10-25 14:38:44 --> Language Class Initialized
ERROR - 2024-10-25 14:38:44 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-25 14:38:44 --> Config Class Initialized
INFO - 2024-10-25 14:38:44 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:44 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:44 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:44 --> URI Class Initialized
INFO - 2024-10-25 14:38:44 --> Router Class Initialized
INFO - 2024-10-25 14:38:44 --> Output Class Initialized
INFO - 2024-10-25 14:38:44 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:44 --> Input Class Initialized
INFO - 2024-10-25 14:38:44 --> Language Class Initialized
ERROR - 2024-10-25 14:38:44 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-25 14:38:45 --> Config Class Initialized
INFO - 2024-10-25 14:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:45 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:45 --> URI Class Initialized
INFO - 2024-10-25 14:38:45 --> Router Class Initialized
INFO - 2024-10-25 14:38:45 --> Output Class Initialized
INFO - 2024-10-25 14:38:45 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:45 --> Input Class Initialized
INFO - 2024-10-25 14:38:45 --> Language Class Initialized
ERROR - 2024-10-25 14:38:45 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-25 14:38:45 --> Config Class Initialized
INFO - 2024-10-25 14:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:45 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:45 --> URI Class Initialized
INFO - 2024-10-25 14:38:45 --> Router Class Initialized
INFO - 2024-10-25 14:38:45 --> Output Class Initialized
INFO - 2024-10-25 14:38:45 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:45 --> Input Class Initialized
INFO - 2024-10-25 14:38:45 --> Language Class Initialized
ERROR - 2024-10-25 14:38:45 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-25 14:38:45 --> Config Class Initialized
INFO - 2024-10-25 14:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:45 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:45 --> URI Class Initialized
INFO - 2024-10-25 14:38:45 --> Router Class Initialized
INFO - 2024-10-25 14:38:45 --> Output Class Initialized
INFO - 2024-10-25 14:38:45 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:45 --> Input Class Initialized
INFO - 2024-10-25 14:38:45 --> Language Class Initialized
ERROR - 2024-10-25 14:38:45 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-25 14:38:46 --> Config Class Initialized
INFO - 2024-10-25 14:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:46 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:46 --> URI Class Initialized
INFO - 2024-10-25 14:38:46 --> Router Class Initialized
INFO - 2024-10-25 14:38:46 --> Output Class Initialized
INFO - 2024-10-25 14:38:46 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:46 --> Input Class Initialized
INFO - 2024-10-25 14:38:46 --> Language Class Initialized
ERROR - 2024-10-25 14:38:46 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-25 14:38:46 --> Config Class Initialized
INFO - 2024-10-25 14:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:46 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:46 --> URI Class Initialized
INFO - 2024-10-25 14:38:46 --> Router Class Initialized
INFO - 2024-10-25 14:38:46 --> Output Class Initialized
INFO - 2024-10-25 14:38:46 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:46 --> Input Class Initialized
INFO - 2024-10-25 14:38:46 --> Language Class Initialized
ERROR - 2024-10-25 14:38:46 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-25 14:38:46 --> Config Class Initialized
INFO - 2024-10-25 14:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:46 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:46 --> URI Class Initialized
INFO - 2024-10-25 14:38:46 --> Router Class Initialized
INFO - 2024-10-25 14:38:46 --> Output Class Initialized
INFO - 2024-10-25 14:38:46 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:46 --> Input Class Initialized
INFO - 2024-10-25 14:38:46 --> Language Class Initialized
ERROR - 2024-10-25 14:38:46 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-25 14:38:46 --> Config Class Initialized
INFO - 2024-10-25 14:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-25 14:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-25 14:38:46 --> Utf8 Class Initialized
INFO - 2024-10-25 14:38:46 --> URI Class Initialized
INFO - 2024-10-25 14:38:46 --> Router Class Initialized
INFO - 2024-10-25 14:38:47 --> Output Class Initialized
INFO - 2024-10-25 14:38:47 --> Security Class Initialized
DEBUG - 2024-10-25 14:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 14:38:47 --> Input Class Initialized
INFO - 2024-10-25 14:38:47 --> Language Class Initialized
ERROR - 2024-10-25 14:38:47 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-25 15:39:58 --> Config Class Initialized
INFO - 2024-10-25 15:39:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:39:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:39:58 --> Utf8 Class Initialized
INFO - 2024-10-25 15:39:58 --> URI Class Initialized
DEBUG - 2024-10-25 15:39:58 --> No URI present. Default controller set.
INFO - 2024-10-25 15:39:58 --> Router Class Initialized
INFO - 2024-10-25 15:39:58 --> Output Class Initialized
INFO - 2024-10-25 15:39:58 --> Security Class Initialized
DEBUG - 2024-10-25 15:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:39:58 --> Input Class Initialized
INFO - 2024-10-25 15:39:58 --> Language Class Initialized
INFO - 2024-10-25 15:39:58 --> Loader Class Initialized
INFO - 2024-10-25 15:39:58 --> Helper loaded: url_helper
INFO - 2024-10-25 15:39:58 --> Helper loaded: html_helper
INFO - 2024-10-25 15:39:58 --> Helper loaded: file_helper
INFO - 2024-10-25 15:39:58 --> Helper loaded: string_helper
INFO - 2024-10-25 15:39:58 --> Helper loaded: form_helper
INFO - 2024-10-25 15:39:58 --> Helper loaded: my_helper
INFO - 2024-10-25 15:39:58 --> Database Driver Class Initialized
INFO - 2024-10-25 15:40:00 --> Upload Class Initialized
INFO - 2024-10-25 15:40:00 --> Email Class Initialized
INFO - 2024-10-25 15:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:40:00 --> Form Validation Class Initialized
INFO - 2024-10-25 15:40:00 --> Controller Class Initialized
INFO - 2024-10-25 21:10:00 --> Model "MainModel" initialized
INFO - 2024-10-25 21:10:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:10:00 --> Final output sent to browser
DEBUG - 2024-10-25 21:10:00 --> Total execution time: 2.1777
INFO - 2024-10-25 15:40:00 --> Config Class Initialized
INFO - 2024-10-25 15:40:00 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:00 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:00 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:00 --> URI Class Initialized
INFO - 2024-10-25 15:40:00 --> Router Class Initialized
INFO - 2024-10-25 15:40:00 --> Output Class Initialized
INFO - 2024-10-25 15:40:00 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:00 --> Input Class Initialized
INFO - 2024-10-25 15:40:00 --> Language Class Initialized
ERROR - 2024-10-25 15:40:00 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-25 15:40:01 --> Config Class Initialized
INFO - 2024-10-25 15:40:01 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:01 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:01 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:01 --> URI Class Initialized
INFO - 2024-10-25 15:40:01 --> Router Class Initialized
INFO - 2024-10-25 15:40:01 --> Output Class Initialized
INFO - 2024-10-25 15:40:01 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:01 --> Input Class Initialized
INFO - 2024-10-25 15:40:01 --> Language Class Initialized
ERROR - 2024-10-25 15:40:01 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-25 15:40:01 --> Config Class Initialized
INFO - 2024-10-25 15:40:01 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:01 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:01 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:01 --> URI Class Initialized
DEBUG - 2024-10-25 15:40:01 --> No URI present. Default controller set.
INFO - 2024-10-25 15:40:01 --> Router Class Initialized
INFO - 2024-10-25 15:40:01 --> Output Class Initialized
INFO - 2024-10-25 15:40:01 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:01 --> Input Class Initialized
INFO - 2024-10-25 15:40:01 --> Language Class Initialized
INFO - 2024-10-25 15:40:01 --> Loader Class Initialized
INFO - 2024-10-25 15:40:01 --> Helper loaded: url_helper
INFO - 2024-10-25 15:40:01 --> Helper loaded: html_helper
INFO - 2024-10-25 15:40:01 --> Helper loaded: file_helper
INFO - 2024-10-25 15:40:01 --> Helper loaded: string_helper
INFO - 2024-10-25 15:40:01 --> Helper loaded: form_helper
INFO - 2024-10-25 15:40:01 --> Helper loaded: my_helper
INFO - 2024-10-25 15:40:01 --> Database Driver Class Initialized
INFO - 2024-10-25 15:40:03 --> Upload Class Initialized
INFO - 2024-10-25 15:40:03 --> Email Class Initialized
INFO - 2024-10-25 15:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:40:03 --> Form Validation Class Initialized
INFO - 2024-10-25 15:40:03 --> Controller Class Initialized
INFO - 2024-10-25 21:10:03 --> Model "MainModel" initialized
INFO - 2024-10-25 21:10:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:10:03 --> Final output sent to browser
DEBUG - 2024-10-25 21:10:03 --> Total execution time: 2.1868
INFO - 2024-10-25 15:40:03 --> Config Class Initialized
INFO - 2024-10-25 15:40:03 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:03 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:03 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:03 --> URI Class Initialized
INFO - 2024-10-25 15:40:03 --> Router Class Initialized
INFO - 2024-10-25 15:40:03 --> Output Class Initialized
INFO - 2024-10-25 15:40:03 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:03 --> Input Class Initialized
INFO - 2024-10-25 15:40:03 --> Language Class Initialized
ERROR - 2024-10-25 15:40:03 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-25 15:40:04 --> Config Class Initialized
INFO - 2024-10-25 15:40:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:04 --> URI Class Initialized
INFO - 2024-10-25 15:40:04 --> Router Class Initialized
INFO - 2024-10-25 15:40:04 --> Output Class Initialized
INFO - 2024-10-25 15:40:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:04 --> Input Class Initialized
INFO - 2024-10-25 15:40:04 --> Language Class Initialized
ERROR - 2024-10-25 15:40:04 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-25 15:40:04 --> Config Class Initialized
INFO - 2024-10-25 15:40:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:04 --> URI Class Initialized
INFO - 2024-10-25 15:40:04 --> Router Class Initialized
INFO - 2024-10-25 15:40:04 --> Output Class Initialized
INFO - 2024-10-25 15:40:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:04 --> Input Class Initialized
INFO - 2024-10-25 15:40:04 --> Language Class Initialized
ERROR - 2024-10-25 15:40:04 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-25 15:40:04 --> Config Class Initialized
INFO - 2024-10-25 15:40:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:04 --> URI Class Initialized
INFO - 2024-10-25 15:40:04 --> Router Class Initialized
INFO - 2024-10-25 15:40:04 --> Output Class Initialized
INFO - 2024-10-25 15:40:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:04 --> Input Class Initialized
INFO - 2024-10-25 15:40:04 --> Language Class Initialized
ERROR - 2024-10-25 15:40:04 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-25 15:40:04 --> Config Class Initialized
INFO - 2024-10-25 15:40:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:04 --> URI Class Initialized
INFO - 2024-10-25 15:40:04 --> Router Class Initialized
INFO - 2024-10-25 15:40:04 --> Output Class Initialized
INFO - 2024-10-25 15:40:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:04 --> Input Class Initialized
INFO - 2024-10-25 15:40:04 --> Language Class Initialized
ERROR - 2024-10-25 15:40:04 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-25 15:40:05 --> Config Class Initialized
INFO - 2024-10-25 15:40:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:05 --> URI Class Initialized
INFO - 2024-10-25 15:40:05 --> Router Class Initialized
INFO - 2024-10-25 15:40:05 --> Output Class Initialized
INFO - 2024-10-25 15:40:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:05 --> Input Class Initialized
INFO - 2024-10-25 15:40:05 --> Language Class Initialized
ERROR - 2024-10-25 15:40:05 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-25 15:40:05 --> Config Class Initialized
INFO - 2024-10-25 15:40:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:05 --> URI Class Initialized
INFO - 2024-10-25 15:40:05 --> Router Class Initialized
INFO - 2024-10-25 15:40:05 --> Output Class Initialized
INFO - 2024-10-25 15:40:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:05 --> Input Class Initialized
INFO - 2024-10-25 15:40:05 --> Language Class Initialized
ERROR - 2024-10-25 15:40:05 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-25 15:40:05 --> Config Class Initialized
INFO - 2024-10-25 15:40:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:05 --> URI Class Initialized
INFO - 2024-10-25 15:40:05 --> Router Class Initialized
INFO - 2024-10-25 15:40:05 --> Output Class Initialized
INFO - 2024-10-25 15:40:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:05 --> Input Class Initialized
INFO - 2024-10-25 15:40:05 --> Language Class Initialized
ERROR - 2024-10-25 15:40:05 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-25 15:40:05 --> Config Class Initialized
INFO - 2024-10-25 15:40:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:05 --> URI Class Initialized
INFO - 2024-10-25 15:40:05 --> Router Class Initialized
INFO - 2024-10-25 15:40:05 --> Output Class Initialized
INFO - 2024-10-25 15:40:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:05 --> Input Class Initialized
INFO - 2024-10-25 15:40:05 --> Language Class Initialized
ERROR - 2024-10-25 15:40:05 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-25 15:40:06 --> Config Class Initialized
INFO - 2024-10-25 15:40:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:06 --> URI Class Initialized
INFO - 2024-10-25 15:40:06 --> Router Class Initialized
INFO - 2024-10-25 15:40:06 --> Output Class Initialized
INFO - 2024-10-25 15:40:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:06 --> Input Class Initialized
INFO - 2024-10-25 15:40:06 --> Language Class Initialized
ERROR - 2024-10-25 15:40:06 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-25 15:40:06 --> Config Class Initialized
INFO - 2024-10-25 15:40:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:06 --> URI Class Initialized
INFO - 2024-10-25 15:40:06 --> Router Class Initialized
INFO - 2024-10-25 15:40:06 --> Output Class Initialized
INFO - 2024-10-25 15:40:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:06 --> Input Class Initialized
INFO - 2024-10-25 15:40:06 --> Language Class Initialized
ERROR - 2024-10-25 15:40:06 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-25 15:40:06 --> Config Class Initialized
INFO - 2024-10-25 15:40:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:06 --> URI Class Initialized
INFO - 2024-10-25 15:40:06 --> Router Class Initialized
INFO - 2024-10-25 15:40:06 --> Output Class Initialized
INFO - 2024-10-25 15:40:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:06 --> Input Class Initialized
INFO - 2024-10-25 15:40:06 --> Language Class Initialized
ERROR - 2024-10-25 15:40:06 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-25 15:40:06 --> Config Class Initialized
INFO - 2024-10-25 15:40:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:07 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:07 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:07 --> URI Class Initialized
INFO - 2024-10-25 15:40:07 --> Router Class Initialized
INFO - 2024-10-25 15:40:07 --> Output Class Initialized
INFO - 2024-10-25 15:40:07 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:07 --> Input Class Initialized
INFO - 2024-10-25 15:40:07 --> Language Class Initialized
ERROR - 2024-10-25 15:40:07 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-25 15:40:07 --> Config Class Initialized
INFO - 2024-10-25 15:40:07 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:07 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:07 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:07 --> URI Class Initialized
INFO - 2024-10-25 15:40:07 --> Router Class Initialized
INFO - 2024-10-25 15:40:07 --> Output Class Initialized
INFO - 2024-10-25 15:40:07 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:07 --> Input Class Initialized
INFO - 2024-10-25 15:40:07 --> Language Class Initialized
ERROR - 2024-10-25 15:40:07 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-25 15:40:07 --> Config Class Initialized
INFO - 2024-10-25 15:40:07 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:07 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:07 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:07 --> URI Class Initialized
INFO - 2024-10-25 15:40:07 --> Router Class Initialized
INFO - 2024-10-25 15:40:07 --> Output Class Initialized
INFO - 2024-10-25 15:40:07 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:07 --> Input Class Initialized
INFO - 2024-10-25 15:40:07 --> Language Class Initialized
ERROR - 2024-10-25 15:40:07 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-25 15:40:07 --> Config Class Initialized
INFO - 2024-10-25 15:40:07 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:40:07 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:40:07 --> Utf8 Class Initialized
INFO - 2024-10-25 15:40:07 --> URI Class Initialized
INFO - 2024-10-25 15:40:07 --> Router Class Initialized
INFO - 2024-10-25 15:40:07 --> Output Class Initialized
INFO - 2024-10-25 15:40:07 --> Security Class Initialized
DEBUG - 2024-10-25 15:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:40:07 --> Input Class Initialized
INFO - 2024-10-25 15:40:07 --> Language Class Initialized
ERROR - 2024-10-25 15:40:07 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-25 15:54:55 --> Config Class Initialized
INFO - 2024-10-25 15:54:55 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:54:55 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:54:55 --> Utf8 Class Initialized
INFO - 2024-10-25 15:54:55 --> URI Class Initialized
DEBUG - 2024-10-25 15:54:55 --> No URI present. Default controller set.
INFO - 2024-10-25 15:54:55 --> Router Class Initialized
INFO - 2024-10-25 15:54:55 --> Output Class Initialized
INFO - 2024-10-25 15:54:55 --> Security Class Initialized
DEBUG - 2024-10-25 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:54:55 --> Input Class Initialized
INFO - 2024-10-25 15:54:55 --> Language Class Initialized
INFO - 2024-10-25 15:54:55 --> Loader Class Initialized
INFO - 2024-10-25 15:54:55 --> Helper loaded: url_helper
INFO - 2024-10-25 15:54:55 --> Helper loaded: html_helper
INFO - 2024-10-25 15:54:55 --> Helper loaded: file_helper
INFO - 2024-10-25 15:54:55 --> Helper loaded: string_helper
INFO - 2024-10-25 15:54:55 --> Helper loaded: form_helper
INFO - 2024-10-25 15:54:55 --> Helper loaded: my_helper
INFO - 2024-10-25 15:54:55 --> Database Driver Class Initialized
INFO - 2024-10-25 15:54:57 --> Upload Class Initialized
INFO - 2024-10-25 15:54:57 --> Email Class Initialized
INFO - 2024-10-25 15:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:54:57 --> Form Validation Class Initialized
INFO - 2024-10-25 15:54:57 --> Controller Class Initialized
INFO - 2024-10-25 21:24:57 --> Model "MainModel" initialized
INFO - 2024-10-25 21:24:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:24:57 --> Final output sent to browser
DEBUG - 2024-10-25 21:24:57 --> Total execution time: 2.2108
INFO - 2024-10-25 15:54:58 --> Config Class Initialized
INFO - 2024-10-25 15:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:54:58 --> Utf8 Class Initialized
INFO - 2024-10-25 15:54:58 --> URI Class Initialized
INFO - 2024-10-25 15:54:58 --> Router Class Initialized
INFO - 2024-10-25 15:54:58 --> Output Class Initialized
INFO - 2024-10-25 15:54:58 --> Security Class Initialized
DEBUG - 2024-10-25 15:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:54:58 --> Input Class Initialized
INFO - 2024-10-25 15:54:58 --> Language Class Initialized
ERROR - 2024-10-25 15:54:58 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-25 15:54:58 --> Config Class Initialized
INFO - 2024-10-25 15:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:54:58 --> Utf8 Class Initialized
INFO - 2024-10-25 15:54:58 --> URI Class Initialized
INFO - 2024-10-25 15:54:58 --> Router Class Initialized
INFO - 2024-10-25 15:54:58 --> Output Class Initialized
INFO - 2024-10-25 15:54:58 --> Security Class Initialized
DEBUG - 2024-10-25 15:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:54:58 --> Input Class Initialized
INFO - 2024-10-25 15:54:58 --> Language Class Initialized
ERROR - 2024-10-25 15:54:58 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-25 15:54:58 --> Config Class Initialized
INFO - 2024-10-25 15:54:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:54:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:54:58 --> Utf8 Class Initialized
INFO - 2024-10-25 15:54:58 --> URI Class Initialized
DEBUG - 2024-10-25 15:54:58 --> No URI present. Default controller set.
INFO - 2024-10-25 15:54:58 --> Router Class Initialized
INFO - 2024-10-25 15:54:58 --> Output Class Initialized
INFO - 2024-10-25 15:54:58 --> Security Class Initialized
DEBUG - 2024-10-25 15:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:54:58 --> Input Class Initialized
INFO - 2024-10-25 15:54:58 --> Language Class Initialized
INFO - 2024-10-25 15:54:58 --> Loader Class Initialized
INFO - 2024-10-25 15:54:58 --> Helper loaded: url_helper
INFO - 2024-10-25 15:54:58 --> Helper loaded: html_helper
INFO - 2024-10-25 15:54:58 --> Helper loaded: file_helper
INFO - 2024-10-25 15:54:58 --> Helper loaded: string_helper
INFO - 2024-10-25 15:54:58 --> Helper loaded: form_helper
INFO - 2024-10-25 15:54:58 --> Helper loaded: my_helper
INFO - 2024-10-25 15:54:58 --> Database Driver Class Initialized
INFO - 2024-10-25 15:55:00 --> Upload Class Initialized
INFO - 2024-10-25 15:55:00 --> Email Class Initialized
INFO - 2024-10-25 15:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 15:55:00 --> Form Validation Class Initialized
INFO - 2024-10-25 15:55:00 --> Controller Class Initialized
INFO - 2024-10-25 21:25:00 --> Model "MainModel" initialized
INFO - 2024-10-25 21:25:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:25:00 --> Final output sent to browser
DEBUG - 2024-10-25 21:25:00 --> Total execution time: 2.1914
INFO - 2024-10-25 15:55:01 --> Config Class Initialized
INFO - 2024-10-25 15:55:01 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:01 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:01 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:01 --> URI Class Initialized
INFO - 2024-10-25 15:55:01 --> Router Class Initialized
INFO - 2024-10-25 15:55:01 --> Output Class Initialized
INFO - 2024-10-25 15:55:01 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:01 --> Input Class Initialized
INFO - 2024-10-25 15:55:01 --> Language Class Initialized
ERROR - 2024-10-25 15:55:01 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-25 15:55:01 --> Config Class Initialized
INFO - 2024-10-25 15:55:01 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:01 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:01 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:01 --> URI Class Initialized
INFO - 2024-10-25 15:55:01 --> Router Class Initialized
INFO - 2024-10-25 15:55:01 --> Output Class Initialized
INFO - 2024-10-25 15:55:01 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:01 --> Input Class Initialized
INFO - 2024-10-25 15:55:01 --> Language Class Initialized
ERROR - 2024-10-25 15:55:01 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-25 15:55:01 --> Config Class Initialized
INFO - 2024-10-25 15:55:01 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:01 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:01 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:01 --> URI Class Initialized
INFO - 2024-10-25 15:55:01 --> Router Class Initialized
INFO - 2024-10-25 15:55:01 --> Output Class Initialized
INFO - 2024-10-25 15:55:01 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:01 --> Input Class Initialized
INFO - 2024-10-25 15:55:01 --> Language Class Initialized
ERROR - 2024-10-25 15:55:01 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-25 15:55:02 --> Config Class Initialized
INFO - 2024-10-25 15:55:02 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:02 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:02 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:02 --> URI Class Initialized
INFO - 2024-10-25 15:55:02 --> Router Class Initialized
INFO - 2024-10-25 15:55:02 --> Output Class Initialized
INFO - 2024-10-25 15:55:02 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:02 --> Input Class Initialized
INFO - 2024-10-25 15:55:02 --> Language Class Initialized
ERROR - 2024-10-25 15:55:02 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-25 15:55:02 --> Config Class Initialized
INFO - 2024-10-25 15:55:02 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:02 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:02 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:02 --> URI Class Initialized
INFO - 2024-10-25 15:55:02 --> Router Class Initialized
INFO - 2024-10-25 15:55:02 --> Output Class Initialized
INFO - 2024-10-25 15:55:02 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:02 --> Input Class Initialized
INFO - 2024-10-25 15:55:02 --> Language Class Initialized
ERROR - 2024-10-25 15:55:02 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-25 15:55:02 --> Config Class Initialized
INFO - 2024-10-25 15:55:02 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:02 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:02 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:02 --> URI Class Initialized
INFO - 2024-10-25 15:55:02 --> Router Class Initialized
INFO - 2024-10-25 15:55:02 --> Output Class Initialized
INFO - 2024-10-25 15:55:02 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:02 --> Input Class Initialized
INFO - 2024-10-25 15:55:02 --> Language Class Initialized
ERROR - 2024-10-25 15:55:02 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-25 15:55:03 --> Config Class Initialized
INFO - 2024-10-25 15:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:03 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:03 --> URI Class Initialized
INFO - 2024-10-25 15:55:03 --> Router Class Initialized
INFO - 2024-10-25 15:55:03 --> Output Class Initialized
INFO - 2024-10-25 15:55:03 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:03 --> Input Class Initialized
INFO - 2024-10-25 15:55:03 --> Language Class Initialized
ERROR - 2024-10-25 15:55:03 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-25 15:55:03 --> Config Class Initialized
INFO - 2024-10-25 15:55:03 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:03 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:03 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:03 --> URI Class Initialized
INFO - 2024-10-25 15:55:03 --> Router Class Initialized
INFO - 2024-10-25 15:55:03 --> Output Class Initialized
INFO - 2024-10-25 15:55:03 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:03 --> Input Class Initialized
INFO - 2024-10-25 15:55:03 --> Language Class Initialized
ERROR - 2024-10-25 15:55:03 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-25 15:55:04 --> Config Class Initialized
INFO - 2024-10-25 15:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:04 --> URI Class Initialized
INFO - 2024-10-25 15:55:04 --> Router Class Initialized
INFO - 2024-10-25 15:55:04 --> Output Class Initialized
INFO - 2024-10-25 15:55:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:04 --> Input Class Initialized
INFO - 2024-10-25 15:55:04 --> Language Class Initialized
ERROR - 2024-10-25 15:55:04 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-25 15:55:04 --> Config Class Initialized
INFO - 2024-10-25 15:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:04 --> URI Class Initialized
INFO - 2024-10-25 15:55:04 --> Router Class Initialized
INFO - 2024-10-25 15:55:04 --> Output Class Initialized
INFO - 2024-10-25 15:55:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:04 --> Input Class Initialized
INFO - 2024-10-25 15:55:04 --> Language Class Initialized
ERROR - 2024-10-25 15:55:04 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-25 15:55:04 --> Config Class Initialized
INFO - 2024-10-25 15:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:04 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:04 --> URI Class Initialized
INFO - 2024-10-25 15:55:04 --> Router Class Initialized
INFO - 2024-10-25 15:55:04 --> Output Class Initialized
INFO - 2024-10-25 15:55:04 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:04 --> Input Class Initialized
INFO - 2024-10-25 15:55:04 --> Language Class Initialized
ERROR - 2024-10-25 15:55:04 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-25 15:55:05 --> Config Class Initialized
INFO - 2024-10-25 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:05 --> URI Class Initialized
INFO - 2024-10-25 15:55:05 --> Router Class Initialized
INFO - 2024-10-25 15:55:05 --> Output Class Initialized
INFO - 2024-10-25 15:55:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:05 --> Input Class Initialized
INFO - 2024-10-25 15:55:05 --> Language Class Initialized
ERROR - 2024-10-25 15:55:05 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-25 15:55:05 --> Config Class Initialized
INFO - 2024-10-25 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:05 --> URI Class Initialized
INFO - 2024-10-25 15:55:05 --> Router Class Initialized
INFO - 2024-10-25 15:55:05 --> Output Class Initialized
INFO - 2024-10-25 15:55:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:05 --> Input Class Initialized
INFO - 2024-10-25 15:55:05 --> Language Class Initialized
ERROR - 2024-10-25 15:55:05 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-25 15:55:05 --> Config Class Initialized
INFO - 2024-10-25 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:05 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:05 --> URI Class Initialized
INFO - 2024-10-25 15:55:05 --> Router Class Initialized
INFO - 2024-10-25 15:55:05 --> Output Class Initialized
INFO - 2024-10-25 15:55:05 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:05 --> Input Class Initialized
INFO - 2024-10-25 15:55:05 --> Language Class Initialized
ERROR - 2024-10-25 15:55:05 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-25 15:55:06 --> Config Class Initialized
INFO - 2024-10-25 15:55:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:06 --> URI Class Initialized
INFO - 2024-10-25 15:55:06 --> Router Class Initialized
INFO - 2024-10-25 15:55:06 --> Output Class Initialized
INFO - 2024-10-25 15:55:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:06 --> Input Class Initialized
INFO - 2024-10-25 15:55:06 --> Language Class Initialized
ERROR - 2024-10-25 15:55:06 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-25 15:55:06 --> Config Class Initialized
INFO - 2024-10-25 15:55:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 15:55:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 15:55:06 --> Utf8 Class Initialized
INFO - 2024-10-25 15:55:06 --> URI Class Initialized
INFO - 2024-10-25 15:55:06 --> Router Class Initialized
INFO - 2024-10-25 15:55:06 --> Output Class Initialized
INFO - 2024-10-25 15:55:06 --> Security Class Initialized
DEBUG - 2024-10-25 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 15:55:06 --> Input Class Initialized
INFO - 2024-10-25 15:55:06 --> Language Class Initialized
ERROR - 2024-10-25 15:55:06 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-25 16:18:06 --> Config Class Initialized
INFO - 2024-10-25 16:18:06 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:18:06 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:18:06 --> Utf8 Class Initialized
INFO - 2024-10-25 16:18:06 --> URI Class Initialized
DEBUG - 2024-10-25 16:18:06 --> No URI present. Default controller set.
INFO - 2024-10-25 16:18:06 --> Router Class Initialized
INFO - 2024-10-25 16:18:06 --> Output Class Initialized
INFO - 2024-10-25 16:18:06 --> Security Class Initialized
DEBUG - 2024-10-25 16:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:18:06 --> Input Class Initialized
INFO - 2024-10-25 16:18:06 --> Language Class Initialized
INFO - 2024-10-25 16:18:06 --> Loader Class Initialized
INFO - 2024-10-25 16:18:06 --> Helper loaded: url_helper
INFO - 2024-10-25 16:18:06 --> Helper loaded: html_helper
INFO - 2024-10-25 16:18:06 --> Helper loaded: file_helper
INFO - 2024-10-25 16:18:06 --> Helper loaded: string_helper
INFO - 2024-10-25 16:18:06 --> Helper loaded: form_helper
INFO - 2024-10-25 16:18:06 --> Helper loaded: my_helper
INFO - 2024-10-25 16:18:06 --> Database Driver Class Initialized
INFO - 2024-10-25 16:18:08 --> Upload Class Initialized
INFO - 2024-10-25 16:18:08 --> Email Class Initialized
INFO - 2024-10-25 16:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:18:08 --> Form Validation Class Initialized
INFO - 2024-10-25 16:18:08 --> Controller Class Initialized
INFO - 2024-10-25 21:48:08 --> Model "MainModel" initialized
INFO - 2024-10-25 21:48:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:48:08 --> Final output sent to browser
DEBUG - 2024-10-25 21:48:08 --> Total execution time: 2.3215
INFO - 2024-10-25 16:18:09 --> Config Class Initialized
INFO - 2024-10-25 16:18:09 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:18:09 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:18:09 --> Utf8 Class Initialized
INFO - 2024-10-25 16:18:09 --> URI Class Initialized
INFO - 2024-10-25 16:18:09 --> Router Class Initialized
INFO - 2024-10-25 16:18:09 --> Output Class Initialized
INFO - 2024-10-25 16:18:09 --> Security Class Initialized
DEBUG - 2024-10-25 16:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:18:09 --> Input Class Initialized
INFO - 2024-10-25 16:18:09 --> Language Class Initialized
INFO - 2024-10-25 16:18:09 --> Loader Class Initialized
INFO - 2024-10-25 16:18:09 --> Helper loaded: url_helper
INFO - 2024-10-25 16:18:09 --> Helper loaded: html_helper
INFO - 2024-10-25 16:18:09 --> Helper loaded: file_helper
INFO - 2024-10-25 16:18:09 --> Helper loaded: string_helper
INFO - 2024-10-25 16:18:09 --> Helper loaded: form_helper
INFO - 2024-10-25 16:18:09 --> Helper loaded: my_helper
INFO - 2024-10-25 16:18:09 --> Database Driver Class Initialized
INFO - 2024-10-25 16:18:11 --> Upload Class Initialized
INFO - 2024-10-25 16:18:11 --> Email Class Initialized
INFO - 2024-10-25 16:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:18:11 --> Form Validation Class Initialized
INFO - 2024-10-25 16:18:11 --> Controller Class Initialized
INFO - 2024-10-25 21:48:11 --> Model "MainModel" initialized
DEBUG - 2024-10-25 21:48:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-10-25 21:48:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/forgot_password.php
INFO - 2024-10-25 21:48:11 --> Final output sent to browser
DEBUG - 2024-10-25 21:48:11 --> Total execution time: 2.2361
INFO - 2024-10-25 16:18:12 --> Config Class Initialized
INFO - 2024-10-25 16:18:12 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:18:12 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:18:12 --> Utf8 Class Initialized
INFO - 2024-10-25 16:18:12 --> URI Class Initialized
INFO - 2024-10-25 16:18:12 --> Router Class Initialized
INFO - 2024-10-25 16:18:12 --> Output Class Initialized
INFO - 2024-10-25 16:18:12 --> Security Class Initialized
DEBUG - 2024-10-25 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:18:12 --> Input Class Initialized
INFO - 2024-10-25 16:18:12 --> Language Class Initialized
INFO - 2024-10-25 16:18:12 --> Loader Class Initialized
INFO - 2024-10-25 16:18:12 --> Helper loaded: url_helper
INFO - 2024-10-25 16:18:12 --> Helper loaded: html_helper
INFO - 2024-10-25 16:18:12 --> Helper loaded: file_helper
INFO - 2024-10-25 16:18:12 --> Helper loaded: string_helper
INFO - 2024-10-25 16:18:12 --> Helper loaded: form_helper
INFO - 2024-10-25 16:18:12 --> Helper loaded: my_helper
INFO - 2024-10-25 16:18:12 --> Database Driver Class Initialized
INFO - 2024-10-25 16:18:14 --> Upload Class Initialized
INFO - 2024-10-25 16:18:14 --> Email Class Initialized
INFO - 2024-10-25 16:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:18:14 --> Form Validation Class Initialized
INFO - 2024-10-25 16:18:14 --> Controller Class Initialized
INFO - 2024-10-25 21:48:14 --> Model "MainModel" initialized
INFO - 2024-10-25 16:18:15 --> Config Class Initialized
INFO - 2024-10-25 16:18:15 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:18:15 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:18:15 --> Utf8 Class Initialized
INFO - 2024-10-25 16:18:15 --> URI Class Initialized
DEBUG - 2024-10-25 16:18:15 --> No URI present. Default controller set.
INFO - 2024-10-25 16:18:15 --> Router Class Initialized
INFO - 2024-10-25 16:18:15 --> Output Class Initialized
INFO - 2024-10-25 16:18:15 --> Security Class Initialized
DEBUG - 2024-10-25 16:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:18:15 --> Input Class Initialized
INFO - 2024-10-25 16:18:15 --> Language Class Initialized
INFO - 2024-10-25 16:18:15 --> Loader Class Initialized
INFO - 2024-10-25 16:18:15 --> Helper loaded: url_helper
INFO - 2024-10-25 16:18:15 --> Helper loaded: html_helper
INFO - 2024-10-25 16:18:15 --> Helper loaded: file_helper
INFO - 2024-10-25 16:18:15 --> Helper loaded: string_helper
INFO - 2024-10-25 16:18:15 --> Helper loaded: form_helper
INFO - 2024-10-25 16:18:15 --> Helper loaded: my_helper
INFO - 2024-10-25 16:18:15 --> Database Driver Class Initialized
INFO - 2024-10-25 16:18:17 --> Upload Class Initialized
INFO - 2024-10-25 16:18:17 --> Email Class Initialized
INFO - 2024-10-25 16:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:18:17 --> Form Validation Class Initialized
INFO - 2024-10-25 16:18:17 --> Controller Class Initialized
INFO - 2024-10-25 21:48:17 --> Model "MainModel" initialized
INFO - 2024-10-25 21:48:17 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:48:17 --> Final output sent to browser
DEBUG - 2024-10-25 21:48:17 --> Total execution time: 2.1409
INFO - 2024-10-25 16:18:17 --> Config Class Initialized
INFO - 2024-10-25 16:18:17 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:18:17 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:18:17 --> Utf8 Class Initialized
INFO - 2024-10-25 16:18:17 --> URI Class Initialized
DEBUG - 2024-10-25 16:18:17 --> No URI present. Default controller set.
INFO - 2024-10-25 16:18:17 --> Router Class Initialized
INFO - 2024-10-25 16:18:17 --> Output Class Initialized
INFO - 2024-10-25 16:18:17 --> Security Class Initialized
DEBUG - 2024-10-25 16:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:18:17 --> Input Class Initialized
INFO - 2024-10-25 16:18:17 --> Language Class Initialized
INFO - 2024-10-25 16:18:17 --> Loader Class Initialized
INFO - 2024-10-25 16:18:17 --> Helper loaded: url_helper
INFO - 2024-10-25 16:18:17 --> Helper loaded: html_helper
INFO - 2024-10-25 16:18:17 --> Helper loaded: file_helper
INFO - 2024-10-25 16:18:17 --> Helper loaded: string_helper
INFO - 2024-10-25 16:18:17 --> Helper loaded: form_helper
INFO - 2024-10-25 16:18:17 --> Helper loaded: my_helper
INFO - 2024-10-25 16:18:17 --> Database Driver Class Initialized
INFO - 2024-10-25 16:18:19 --> Upload Class Initialized
INFO - 2024-10-25 16:18:19 --> Email Class Initialized
INFO - 2024-10-25 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:18:19 --> Form Validation Class Initialized
INFO - 2024-10-25 16:18:19 --> Controller Class Initialized
INFO - 2024-10-25 21:48:19 --> Model "MainModel" initialized
INFO - 2024-10-25 21:48:19 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:48:19 --> Final output sent to browser
DEBUG - 2024-10-25 21:48:19 --> Total execution time: 2.1106
INFO - 2024-10-25 16:20:11 --> Config Class Initialized
INFO - 2024-10-25 16:20:11 --> Hooks Class Initialized
DEBUG - 2024-10-25 16:20:11 --> UTF-8 Support Enabled
INFO - 2024-10-25 16:20:11 --> Utf8 Class Initialized
INFO - 2024-10-25 16:20:11 --> URI Class Initialized
DEBUG - 2024-10-25 16:20:11 --> No URI present. Default controller set.
INFO - 2024-10-25 16:20:11 --> Router Class Initialized
INFO - 2024-10-25 16:20:11 --> Output Class Initialized
INFO - 2024-10-25 16:20:11 --> Security Class Initialized
DEBUG - 2024-10-25 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 16:20:11 --> Input Class Initialized
INFO - 2024-10-25 16:20:11 --> Language Class Initialized
INFO - 2024-10-25 16:20:11 --> Loader Class Initialized
INFO - 2024-10-25 16:20:11 --> Helper loaded: url_helper
INFO - 2024-10-25 16:20:11 --> Helper loaded: html_helper
INFO - 2024-10-25 16:20:11 --> Helper loaded: file_helper
INFO - 2024-10-25 16:20:11 --> Helper loaded: string_helper
INFO - 2024-10-25 16:20:11 --> Helper loaded: form_helper
INFO - 2024-10-25 16:20:11 --> Helper loaded: my_helper
INFO - 2024-10-25 16:20:11 --> Database Driver Class Initialized
INFO - 2024-10-25 16:20:13 --> Upload Class Initialized
INFO - 2024-10-25 16:20:13 --> Email Class Initialized
INFO - 2024-10-25 16:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 16:20:13 --> Form Validation Class Initialized
INFO - 2024-10-25 16:20:13 --> Controller Class Initialized
INFO - 2024-10-25 21:50:13 --> Model "MainModel" initialized
INFO - 2024-10-25 21:50:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 21:50:13 --> Final output sent to browser
DEBUG - 2024-10-25 21:50:13 --> Total execution time: 2.1557
INFO - 2024-10-25 18:19:10 --> Config Class Initialized
INFO - 2024-10-25 18:19:10 --> Hooks Class Initialized
DEBUG - 2024-10-25 18:19:10 --> UTF-8 Support Enabled
INFO - 2024-10-25 18:19:10 --> Utf8 Class Initialized
INFO - 2024-10-25 18:19:10 --> URI Class Initialized
DEBUG - 2024-10-25 18:19:10 --> No URI present. Default controller set.
INFO - 2024-10-25 18:19:10 --> Router Class Initialized
INFO - 2024-10-25 18:19:10 --> Output Class Initialized
INFO - 2024-10-25 18:19:10 --> Security Class Initialized
DEBUG - 2024-10-25 18:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 18:19:10 --> Input Class Initialized
INFO - 2024-10-25 18:19:10 --> Language Class Initialized
INFO - 2024-10-25 18:19:10 --> Loader Class Initialized
INFO - 2024-10-25 18:19:10 --> Helper loaded: url_helper
INFO - 2024-10-25 18:19:10 --> Helper loaded: html_helper
INFO - 2024-10-25 18:19:10 --> Helper loaded: file_helper
INFO - 2024-10-25 18:19:10 --> Helper loaded: string_helper
INFO - 2024-10-25 18:19:10 --> Helper loaded: form_helper
INFO - 2024-10-25 18:19:10 --> Helper loaded: my_helper
INFO - 2024-10-25 18:19:10 --> Database Driver Class Initialized
INFO - 2024-10-25 18:19:12 --> Upload Class Initialized
INFO - 2024-10-25 18:19:12 --> Email Class Initialized
INFO - 2024-10-25 18:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 18:19:12 --> Form Validation Class Initialized
INFO - 2024-10-25 18:19:12 --> Controller Class Initialized
INFO - 2024-10-25 23:49:12 --> Model "MainModel" initialized
INFO - 2024-10-25 23:49:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-25 23:49:12 --> Final output sent to browser
DEBUG - 2024-10-25 23:49:12 --> Total execution time: 2.2156
INFO - 2024-10-25 18:19:13 --> Config Class Initialized
INFO - 2024-10-25 18:19:13 --> Hooks Class Initialized
DEBUG - 2024-10-25 18:19:13 --> UTF-8 Support Enabled
INFO - 2024-10-25 18:19:13 --> Utf8 Class Initialized
INFO - 2024-10-25 18:19:13 --> URI Class Initialized
INFO - 2024-10-25 18:19:13 --> Router Class Initialized
INFO - 2024-10-25 18:19:13 --> Output Class Initialized
INFO - 2024-10-25 18:19:13 --> Security Class Initialized
DEBUG - 2024-10-25 18:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 18:19:13 --> Input Class Initialized
INFO - 2024-10-25 18:19:13 --> Language Class Initialized
ERROR - 2024-10-25 18:19:13 --> 404 Page Not Found: Adstxt/index
INFO - 2024-10-25 19:28:26 --> Config Class Initialized
INFO - 2024-10-25 19:28:26 --> Hooks Class Initialized
DEBUG - 2024-10-25 19:28:26 --> UTF-8 Support Enabled
INFO - 2024-10-25 19:28:26 --> Utf8 Class Initialized
INFO - 2024-10-25 19:28:26 --> URI Class Initialized
DEBUG - 2024-10-25 19:28:26 --> No URI present. Default controller set.
INFO - 2024-10-25 19:28:26 --> Router Class Initialized
INFO - 2024-10-25 19:28:26 --> Output Class Initialized
INFO - 2024-10-25 19:28:26 --> Security Class Initialized
DEBUG - 2024-10-25 19:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 19:28:26 --> Input Class Initialized
INFO - 2024-10-25 19:28:26 --> Language Class Initialized
INFO - 2024-10-25 19:28:26 --> Loader Class Initialized
INFO - 2024-10-25 19:28:26 --> Helper loaded: url_helper
INFO - 2024-10-25 19:28:26 --> Helper loaded: html_helper
INFO - 2024-10-25 19:28:26 --> Helper loaded: file_helper
INFO - 2024-10-25 19:28:26 --> Helper loaded: string_helper
INFO - 2024-10-25 19:28:26 --> Helper loaded: form_helper
INFO - 2024-10-25 19:28:26 --> Helper loaded: my_helper
INFO - 2024-10-25 19:28:26 --> Database Driver Class Initialized
INFO - 2024-10-25 19:28:28 --> Upload Class Initialized
INFO - 2024-10-25 19:28:28 --> Email Class Initialized
INFO - 2024-10-25 19:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 19:28:28 --> Form Validation Class Initialized
INFO - 2024-10-25 19:28:28 --> Controller Class Initialized
INFO - 2024-10-25 19:28:31 --> Config Class Initialized
INFO - 2024-10-25 19:28:31 --> Hooks Class Initialized
DEBUG - 2024-10-25 19:28:31 --> UTF-8 Support Enabled
INFO - 2024-10-25 19:28:31 --> Utf8 Class Initialized
INFO - 2024-10-25 19:28:31 --> URI Class Initialized
DEBUG - 2024-10-25 19:28:31 --> No URI present. Default controller set.
INFO - 2024-10-25 19:28:31 --> Router Class Initialized
INFO - 2024-10-25 19:28:31 --> Output Class Initialized
INFO - 2024-10-25 19:28:31 --> Security Class Initialized
DEBUG - 2024-10-25 19:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 19:28:31 --> Input Class Initialized
INFO - 2024-10-25 19:28:31 --> Language Class Initialized
INFO - 2024-10-25 19:28:31 --> Loader Class Initialized
INFO - 2024-10-25 19:28:31 --> Helper loaded: url_helper
INFO - 2024-10-25 19:28:31 --> Helper loaded: html_helper
INFO - 2024-10-25 19:28:31 --> Helper loaded: file_helper
INFO - 2024-10-25 19:28:31 --> Helper loaded: string_helper
INFO - 2024-10-25 19:28:31 --> Helper loaded: form_helper
INFO - 2024-10-25 19:28:31 --> Helper loaded: my_helper
INFO - 2024-10-25 19:28:31 --> Database Driver Class Initialized
INFO - 2024-10-25 19:28:33 --> Upload Class Initialized
INFO - 2024-10-25 19:28:33 --> Email Class Initialized
INFO - 2024-10-25 19:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 19:28:33 --> Form Validation Class Initialized
INFO - 2024-10-25 19:28:33 --> Controller Class Initialized
INFO - 2024-10-25 19:28:45 --> Config Class Initialized
INFO - 2024-10-25 19:28:45 --> Hooks Class Initialized
DEBUG - 2024-10-25 19:28:45 --> UTF-8 Support Enabled
INFO - 2024-10-25 19:28:45 --> Utf8 Class Initialized
INFO - 2024-10-25 19:28:45 --> URI Class Initialized
DEBUG - 2024-10-25 19:28:45 --> No URI present. Default controller set.
INFO - 2024-10-25 19:28:45 --> Router Class Initialized
INFO - 2024-10-25 19:28:45 --> Output Class Initialized
INFO - 2024-10-25 19:28:45 --> Security Class Initialized
DEBUG - 2024-10-25 19:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 19:28:45 --> Input Class Initialized
INFO - 2024-10-25 19:28:45 --> Language Class Initialized
INFO - 2024-10-25 19:28:45 --> Loader Class Initialized
INFO - 2024-10-25 19:28:45 --> Helper loaded: url_helper
INFO - 2024-10-25 19:28:45 --> Helper loaded: html_helper
INFO - 2024-10-25 19:28:45 --> Helper loaded: file_helper
INFO - 2024-10-25 19:28:45 --> Helper loaded: string_helper
INFO - 2024-10-25 19:28:45 --> Helper loaded: form_helper
INFO - 2024-10-25 19:28:45 --> Helper loaded: my_helper
INFO - 2024-10-25 19:28:45 --> Database Driver Class Initialized
INFO - 2024-10-25 19:28:47 --> Upload Class Initialized
INFO - 2024-10-25 19:28:47 --> Email Class Initialized
INFO - 2024-10-25 19:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 19:28:47 --> Form Validation Class Initialized
INFO - 2024-10-25 19:28:47 --> Controller Class Initialized
INFO - 2024-10-25 19:31:58 --> Config Class Initialized
INFO - 2024-10-25 19:31:58 --> Hooks Class Initialized
DEBUG - 2024-10-25 19:31:58 --> UTF-8 Support Enabled
INFO - 2024-10-25 19:31:58 --> Utf8 Class Initialized
INFO - 2024-10-25 19:31:58 --> URI Class Initialized
DEBUG - 2024-10-25 19:31:58 --> No URI present. Default controller set.
INFO - 2024-10-25 19:31:58 --> Router Class Initialized
INFO - 2024-10-25 19:31:58 --> Output Class Initialized
INFO - 2024-10-25 19:31:58 --> Security Class Initialized
DEBUG - 2024-10-25 19:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 19:31:58 --> Input Class Initialized
INFO - 2024-10-25 19:31:58 --> Language Class Initialized
INFO - 2024-10-25 19:31:58 --> Loader Class Initialized
INFO - 2024-10-25 19:31:58 --> Helper loaded: url_helper
INFO - 2024-10-25 19:31:58 --> Helper loaded: html_helper
INFO - 2024-10-25 19:31:58 --> Helper loaded: file_helper
INFO - 2024-10-25 19:31:58 --> Helper loaded: string_helper
INFO - 2024-10-25 19:31:58 --> Helper loaded: form_helper
INFO - 2024-10-25 19:31:58 --> Helper loaded: my_helper
INFO - 2024-10-25 19:31:58 --> Database Driver Class Initialized
INFO - 2024-10-25 19:32:00 --> Upload Class Initialized
INFO - 2024-10-25 19:32:00 --> Email Class Initialized
INFO - 2024-10-25 19:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 19:32:00 --> Form Validation Class Initialized
INFO - 2024-10-25 19:32:00 --> Controller Class Initialized
INFO - 2024-10-25 20:17:36 --> Config Class Initialized
INFO - 2024-10-25 20:17:36 --> Hooks Class Initialized
DEBUG - 2024-10-25 20:17:36 --> UTF-8 Support Enabled
INFO - 2024-10-25 20:17:36 --> Utf8 Class Initialized
INFO - 2024-10-25 20:17:36 --> URI Class Initialized
DEBUG - 2024-10-25 20:17:36 --> No URI present. Default controller set.
INFO - 2024-10-25 20:17:36 --> Router Class Initialized
INFO - 2024-10-25 20:17:36 --> Output Class Initialized
INFO - 2024-10-25 20:17:36 --> Security Class Initialized
DEBUG - 2024-10-25 20:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 20:17:36 --> Input Class Initialized
INFO - 2024-10-25 20:17:36 --> Language Class Initialized
INFO - 2024-10-25 20:17:36 --> Loader Class Initialized
INFO - 2024-10-25 20:17:36 --> Helper loaded: url_helper
INFO - 2024-10-25 20:17:36 --> Helper loaded: html_helper
INFO - 2024-10-25 20:17:36 --> Helper loaded: file_helper
INFO - 2024-10-25 20:17:36 --> Helper loaded: string_helper
INFO - 2024-10-25 20:17:36 --> Helper loaded: form_helper
INFO - 2024-10-25 20:17:36 --> Helper loaded: my_helper
INFO - 2024-10-25 20:17:36 --> Database Driver Class Initialized
INFO - 2024-10-25 20:17:39 --> Upload Class Initialized
INFO - 2024-10-25 20:17:39 --> Email Class Initialized
INFO - 2024-10-25 20:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 20:17:39 --> Form Validation Class Initialized
INFO - 2024-10-25 20:17:39 --> Controller Class Initialized
INFO - 2024-10-25 22:41:43 --> Config Class Initialized
INFO - 2024-10-25 22:41:43 --> Hooks Class Initialized
DEBUG - 2024-10-25 22:41:43 --> UTF-8 Support Enabled
INFO - 2024-10-25 22:41:43 --> Utf8 Class Initialized
INFO - 2024-10-25 22:41:43 --> URI Class Initialized
DEBUG - 2024-10-25 22:41:43 --> No URI present. Default controller set.
INFO - 2024-10-25 22:41:43 --> Router Class Initialized
INFO - 2024-10-25 22:41:43 --> Output Class Initialized
INFO - 2024-10-25 22:41:43 --> Security Class Initialized
DEBUG - 2024-10-25 22:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 22:41:43 --> Input Class Initialized
INFO - 2024-10-25 22:41:43 --> Language Class Initialized
INFO - 2024-10-25 22:41:43 --> Loader Class Initialized
INFO - 2024-10-25 22:41:43 --> Helper loaded: url_helper
INFO - 2024-10-25 22:41:43 --> Helper loaded: html_helper
INFO - 2024-10-25 22:41:43 --> Helper loaded: file_helper
INFO - 2024-10-25 22:41:43 --> Helper loaded: string_helper
INFO - 2024-10-25 22:41:43 --> Helper loaded: form_helper
INFO - 2024-10-25 22:41:43 --> Helper loaded: my_helper
INFO - 2024-10-25 22:41:43 --> Database Driver Class Initialized
INFO - 2024-10-25 22:41:45 --> Upload Class Initialized
INFO - 2024-10-25 22:41:45 --> Email Class Initialized
INFO - 2024-10-25 22:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 22:41:45 --> Form Validation Class Initialized
INFO - 2024-10-25 22:41:45 --> Controller Class Initialized
INFO - 2024-10-25 22:41:49 --> Config Class Initialized
INFO - 2024-10-25 22:41:49 --> Hooks Class Initialized
DEBUG - 2024-10-25 22:41:49 --> UTF-8 Support Enabled
INFO - 2024-10-25 22:41:49 --> Utf8 Class Initialized
INFO - 2024-10-25 22:41:49 --> URI Class Initialized
DEBUG - 2024-10-25 22:41:49 --> No URI present. Default controller set.
INFO - 2024-10-25 22:41:49 --> Router Class Initialized
INFO - 2024-10-25 22:41:49 --> Output Class Initialized
INFO - 2024-10-25 22:41:49 --> Security Class Initialized
DEBUG - 2024-10-25 22:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 22:41:49 --> Input Class Initialized
INFO - 2024-10-25 22:41:49 --> Language Class Initialized
INFO - 2024-10-25 22:41:49 --> Loader Class Initialized
INFO - 2024-10-25 22:41:49 --> Helper loaded: url_helper
INFO - 2024-10-25 22:41:49 --> Helper loaded: html_helper
INFO - 2024-10-25 22:41:49 --> Helper loaded: file_helper
INFO - 2024-10-25 22:41:49 --> Helper loaded: string_helper
INFO - 2024-10-25 22:41:49 --> Helper loaded: form_helper
INFO - 2024-10-25 22:41:49 --> Helper loaded: my_helper
INFO - 2024-10-25 22:41:49 --> Database Driver Class Initialized
INFO - 2024-10-25 22:41:51 --> Upload Class Initialized
INFO - 2024-10-25 22:41:51 --> Email Class Initialized
INFO - 2024-10-25 22:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 22:41:51 --> Form Validation Class Initialized
INFO - 2024-10-25 22:41:51 --> Controller Class Initialized
