<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-28 01:09:18 --> Model "MainModel" initialized
INFO - 2024-12-28 01:09:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-28 01:09:18 --> Final output sent to browser
DEBUG - 2024-12-28 01:09:18 --> Total execution time: 2.2047
INFO - 2024-12-28 11:29:26 --> Config Class Initialized
INFO - 2024-12-28 11:29:26 --> Hooks Class Initialized
DEBUG - 2024-12-28 11:29:26 --> UTF-8 Support Enabled
INFO - 2024-12-28 11:29:26 --> Utf8 Class Initialized
INFO - 2024-12-28 11:29:26 --> URI Class Initialized
INFO - 2024-12-28 11:29:26 --> Router Class Initialized
INFO - 2024-12-28 11:29:26 --> Output Class Initialized
INFO - 2024-12-28 11:29:26 --> Security Class Initialized
DEBUG - 2024-12-28 11:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 11:29:26 --> Input Class Initialized
INFO - 2024-12-28 11:29:26 --> Language Class Initialized
ERROR - 2024-12-28 11:29:26 --> 404 Page Not Found: Wp-includes/js
INFO - 2024-12-28 15:35:04 --> Config Class Initialized
INFO - 2024-12-28 15:35:04 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:04 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:04 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:04 --> URI Class Initialized
DEBUG - 2024-12-28 15:35:04 --> No URI present. Default controller set.
INFO - 2024-12-28 15:35:04 --> Router Class Initialized
INFO - 2024-12-28 15:35:04 --> Output Class Initialized
INFO - 2024-12-28 15:35:04 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:04 --> Input Class Initialized
INFO - 2024-12-28 15:35:04 --> Language Class Initialized
INFO - 2024-12-28 15:35:04 --> Loader Class Initialized
INFO - 2024-12-28 15:35:04 --> Helper loaded: url_helper
INFO - 2024-12-28 15:35:04 --> Helper loaded: html_helper
INFO - 2024-12-28 15:35:04 --> Helper loaded: file_helper
INFO - 2024-12-28 15:35:04 --> Helper loaded: string_helper
INFO - 2024-12-28 15:35:04 --> Helper loaded: form_helper
INFO - 2024-12-28 15:35:04 --> Helper loaded: my_helper
INFO - 2024-12-28 15:35:05 --> Database Driver Class Initialized
INFO - 2024-12-28 15:35:07 --> Upload Class Initialized
INFO - 2024-12-28 15:35:07 --> Email Class Initialized
INFO - 2024-12-28 15:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-28 15:35:07 --> Form Validation Class Initialized
INFO - 2024-12-28 15:35:07 --> Controller Class Initialized
INFO - 2024-12-28 21:05:07 --> Model "MainModel" initialized
INFO - 2024-12-28 21:05:07 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-28 21:05:07 --> Final output sent to browser
DEBUG - 2024-12-28 21:05:07 --> Total execution time: 2.7336
INFO - 2024-12-28 15:35:07 --> Config Class Initialized
INFO - 2024-12-28 15:35:07 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:07 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:07 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:07 --> URI Class Initialized
INFO - 2024-12-28 15:35:07 --> Router Class Initialized
INFO - 2024-12-28 15:35:07 --> Output Class Initialized
INFO - 2024-12-28 15:35:07 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:07 --> Input Class Initialized
INFO - 2024-12-28 15:35:07 --> Language Class Initialized
ERROR - 2024-12-28 15:35:07 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-28 15:35:07 --> Config Class Initialized
INFO - 2024-12-28 15:35:07 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:07 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:07 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:07 --> URI Class Initialized
INFO - 2024-12-28 15:35:07 --> Router Class Initialized
INFO - 2024-12-28 15:35:07 --> Output Class Initialized
INFO - 2024-12-28 15:35:07 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:07 --> Input Class Initialized
INFO - 2024-12-28 15:35:07 --> Language Class Initialized
ERROR - 2024-12-28 15:35:07 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-28 15:35:07 --> Config Class Initialized
INFO - 2024-12-28 15:35:07 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:07 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:07 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:07 --> URI Class Initialized
DEBUG - 2024-12-28 15:35:07 --> No URI present. Default controller set.
INFO - 2024-12-28 15:35:07 --> Router Class Initialized
INFO - 2024-12-28 15:35:07 --> Output Class Initialized
INFO - 2024-12-28 15:35:07 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:07 --> Input Class Initialized
INFO - 2024-12-28 15:35:07 --> Language Class Initialized
INFO - 2024-12-28 15:35:07 --> Loader Class Initialized
INFO - 2024-12-28 15:35:07 --> Helper loaded: url_helper
INFO - 2024-12-28 15:35:07 --> Helper loaded: html_helper
INFO - 2024-12-28 15:35:07 --> Helper loaded: file_helper
INFO - 2024-12-28 15:35:07 --> Helper loaded: string_helper
INFO - 2024-12-28 15:35:07 --> Helper loaded: form_helper
INFO - 2024-12-28 15:35:07 --> Helper loaded: my_helper
INFO - 2024-12-28 15:35:07 --> Database Driver Class Initialized
INFO - 2024-12-28 15:35:09 --> Upload Class Initialized
INFO - 2024-12-28 15:35:09 --> Email Class Initialized
INFO - 2024-12-28 15:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-28 15:35:10 --> Form Validation Class Initialized
INFO - 2024-12-28 15:35:10 --> Controller Class Initialized
INFO - 2024-12-28 21:05:10 --> Model "MainModel" initialized
INFO - 2024-12-28 21:05:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-28 21:05:10 --> Final output sent to browser
DEBUG - 2024-12-28 21:05:10 --> Total execution time: 2.1518
INFO - 2024-12-28 15:35:10 --> Config Class Initialized
INFO - 2024-12-28 15:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:10 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:10 --> URI Class Initialized
INFO - 2024-12-28 15:35:10 --> Router Class Initialized
INFO - 2024-12-28 15:35:10 --> Output Class Initialized
INFO - 2024-12-28 15:35:10 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:10 --> Input Class Initialized
INFO - 2024-12-28 15:35:10 --> Language Class Initialized
ERROR - 2024-12-28 15:35:10 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-28 15:35:10 --> Config Class Initialized
INFO - 2024-12-28 15:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:10 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:10 --> URI Class Initialized
INFO - 2024-12-28 15:35:10 --> Router Class Initialized
INFO - 2024-12-28 15:35:10 --> Output Class Initialized
INFO - 2024-12-28 15:35:10 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:10 --> Input Class Initialized
INFO - 2024-12-28 15:35:10 --> Language Class Initialized
ERROR - 2024-12-28 15:35:10 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-28 15:35:10 --> Config Class Initialized
INFO - 2024-12-28 15:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:10 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:10 --> URI Class Initialized
INFO - 2024-12-28 15:35:10 --> Router Class Initialized
INFO - 2024-12-28 15:35:10 --> Output Class Initialized
INFO - 2024-12-28 15:35:10 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:10 --> Input Class Initialized
INFO - 2024-12-28 15:35:10 --> Language Class Initialized
ERROR - 2024-12-28 15:35:10 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-28 15:35:10 --> Config Class Initialized
INFO - 2024-12-28 15:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:10 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:10 --> URI Class Initialized
INFO - 2024-12-28 15:35:10 --> Router Class Initialized
INFO - 2024-12-28 15:35:10 --> Output Class Initialized
INFO - 2024-12-28 15:35:10 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:10 --> Input Class Initialized
INFO - 2024-12-28 15:35:10 --> Language Class Initialized
ERROR - 2024-12-28 15:35:10 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-28 15:35:10 --> Config Class Initialized
INFO - 2024-12-28 15:35:10 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:10 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:10 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:10 --> URI Class Initialized
INFO - 2024-12-28 15:35:10 --> Router Class Initialized
INFO - 2024-12-28 15:35:10 --> Output Class Initialized
INFO - 2024-12-28 15:35:10 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:10 --> Input Class Initialized
INFO - 2024-12-28 15:35:10 --> Language Class Initialized
ERROR - 2024-12-28 15:35:10 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-28 15:35:11 --> Config Class Initialized
INFO - 2024-12-28 15:35:11 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:11 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:11 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:11 --> URI Class Initialized
INFO - 2024-12-28 15:35:11 --> Router Class Initialized
INFO - 2024-12-28 15:35:11 --> Output Class Initialized
INFO - 2024-12-28 15:35:11 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:11 --> Input Class Initialized
INFO - 2024-12-28 15:35:11 --> Language Class Initialized
ERROR - 2024-12-28 15:35:11 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-28 15:35:11 --> Config Class Initialized
INFO - 2024-12-28 15:35:11 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:11 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:11 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:11 --> URI Class Initialized
INFO - 2024-12-28 15:35:11 --> Router Class Initialized
INFO - 2024-12-28 15:35:11 --> Output Class Initialized
INFO - 2024-12-28 15:35:11 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:11 --> Input Class Initialized
INFO - 2024-12-28 15:35:11 --> Language Class Initialized
ERROR - 2024-12-28 15:35:11 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-28 15:35:11 --> Config Class Initialized
INFO - 2024-12-28 15:35:11 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:11 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:11 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:11 --> URI Class Initialized
INFO - 2024-12-28 15:35:11 --> Router Class Initialized
INFO - 2024-12-28 15:35:11 --> Output Class Initialized
INFO - 2024-12-28 15:35:11 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:11 --> Input Class Initialized
INFO - 2024-12-28 15:35:11 --> Language Class Initialized
ERROR - 2024-12-28 15:35:11 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-28 15:35:11 --> Config Class Initialized
INFO - 2024-12-28 15:35:11 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:11 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:11 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:11 --> URI Class Initialized
INFO - 2024-12-28 15:35:11 --> Router Class Initialized
INFO - 2024-12-28 15:35:11 --> Output Class Initialized
INFO - 2024-12-28 15:35:11 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:11 --> Input Class Initialized
INFO - 2024-12-28 15:35:11 --> Language Class Initialized
ERROR - 2024-12-28 15:35:11 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-28 15:35:11 --> Config Class Initialized
INFO - 2024-12-28 15:35:11 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:11 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:11 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:11 --> URI Class Initialized
INFO - 2024-12-28 15:35:11 --> Router Class Initialized
INFO - 2024-12-28 15:35:11 --> Output Class Initialized
INFO - 2024-12-28 15:35:11 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:11 --> Input Class Initialized
INFO - 2024-12-28 15:35:11 --> Language Class Initialized
ERROR - 2024-12-28 15:35:11 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-28 15:35:12 --> Config Class Initialized
INFO - 2024-12-28 15:35:12 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:12 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:12 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:12 --> URI Class Initialized
INFO - 2024-12-28 15:35:12 --> Router Class Initialized
INFO - 2024-12-28 15:35:12 --> Output Class Initialized
INFO - 2024-12-28 15:35:12 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:12 --> Input Class Initialized
INFO - 2024-12-28 15:35:12 --> Language Class Initialized
ERROR - 2024-12-28 15:35:12 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-28 15:35:12 --> Config Class Initialized
INFO - 2024-12-28 15:35:12 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:12 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:12 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:12 --> URI Class Initialized
INFO - 2024-12-28 15:35:12 --> Router Class Initialized
INFO - 2024-12-28 15:35:12 --> Output Class Initialized
INFO - 2024-12-28 15:35:12 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:12 --> Input Class Initialized
INFO - 2024-12-28 15:35:12 --> Language Class Initialized
ERROR - 2024-12-28 15:35:12 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-28 15:35:12 --> Config Class Initialized
INFO - 2024-12-28 15:35:12 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:12 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:12 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:12 --> URI Class Initialized
INFO - 2024-12-28 15:35:12 --> Router Class Initialized
INFO - 2024-12-28 15:35:12 --> Output Class Initialized
INFO - 2024-12-28 15:35:12 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:12 --> Input Class Initialized
INFO - 2024-12-28 15:35:12 --> Language Class Initialized
ERROR - 2024-12-28 15:35:12 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-28 15:35:12 --> Config Class Initialized
INFO - 2024-12-28 15:35:12 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:12 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:12 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:12 --> URI Class Initialized
INFO - 2024-12-28 15:35:12 --> Router Class Initialized
INFO - 2024-12-28 15:35:12 --> Output Class Initialized
INFO - 2024-12-28 15:35:12 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:12 --> Input Class Initialized
INFO - 2024-12-28 15:35:12 --> Language Class Initialized
ERROR - 2024-12-28 15:35:12 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-28 15:35:12 --> Config Class Initialized
INFO - 2024-12-28 15:35:12 --> Hooks Class Initialized
DEBUG - 2024-12-28 15:35:12 --> UTF-8 Support Enabled
INFO - 2024-12-28 15:35:12 --> Utf8 Class Initialized
INFO - 2024-12-28 15:35:12 --> URI Class Initialized
INFO - 2024-12-28 15:35:12 --> Router Class Initialized
INFO - 2024-12-28 15:35:12 --> Output Class Initialized
INFO - 2024-12-28 15:35:12 --> Security Class Initialized
DEBUG - 2024-12-28 15:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-28 15:35:12 --> Input Class Initialized
INFO - 2024-12-28 15:35:12 --> Language Class Initialized
ERROR - 2024-12-28 15:35:12 --> 404 Page Not Found: Sito/wp-includes
