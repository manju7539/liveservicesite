<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-18 10:04:36 --> Config Class Initialized
INFO - 2024-10-18 10:04:36 --> Hooks Class Initialized
DEBUG - 2024-10-18 10:04:36 --> UTF-8 Support Enabled
INFO - 2024-10-18 10:04:36 --> Utf8 Class Initialized
INFO - 2024-10-18 10:04:36 --> URI Class Initialized
DEBUG - 2024-10-18 10:04:36 --> No URI present. Default controller set.
INFO - 2024-10-18 10:04:36 --> Router Class Initialized
INFO - 2024-10-18 10:04:36 --> Output Class Initialized
INFO - 2024-10-18 10:04:36 --> Security Class Initialized
DEBUG - 2024-10-18 10:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-18 10:04:36 --> Input Class Initialized
INFO - 2024-10-18 10:04:36 --> Language Class Initialized
INFO - 2024-10-18 10:04:37 --> Loader Class Initialized
INFO - 2024-10-18 10:04:37 --> Helper loaded: url_helper
INFO - 2024-10-18 10:04:37 --> Helper loaded: html_helper
INFO - 2024-10-18 10:04:37 --> Helper loaded: file_helper
INFO - 2024-10-18 10:04:37 --> Helper loaded: string_helper
INFO - 2024-10-18 10:04:37 --> Helper loaded: form_helper
INFO - 2024-10-18 10:04:37 --> Helper loaded: my_helper
INFO - 2024-10-18 10:04:37 --> Database Driver Class Initialized
INFO - 2024-10-18 10:04:39 --> Upload Class Initialized
INFO - 2024-10-18 10:04:39 --> Email Class Initialized
INFO - 2024-10-18 10:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-18 10:04:39 --> Form Validation Class Initialized
INFO - 2024-10-18 10:04:39 --> Controller Class Initialized
INFO - 2024-10-18 15:34:39 --> Model "MainModel" initialized
INFO - 2024-10-18 15:34:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-18 15:34:39 --> Final output sent to browser
DEBUG - 2024-10-18 15:34:39 --> Total execution time: 2.6565
INFO - 2024-10-18 14:10:19 --> Config Class Initialized
INFO - 2024-10-18 14:10:19 --> Hooks Class Initialized
DEBUG - 2024-10-18 14:10:19 --> UTF-8 Support Enabled
INFO - 2024-10-18 14:10:19 --> Utf8 Class Initialized
INFO - 2024-10-18 14:10:19 --> URI Class Initialized
DEBUG - 2024-10-18 14:10:19 --> No URI present. Default controller set.
INFO - 2024-10-18 14:10:19 --> Router Class Initialized
INFO - 2024-10-18 14:10:19 --> Output Class Initialized
INFO - 2024-10-18 14:10:19 --> Security Class Initialized
DEBUG - 2024-10-18 14:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-18 14:10:19 --> Input Class Initialized
INFO - 2024-10-18 14:10:19 --> Language Class Initialized
INFO - 2024-10-18 14:10:19 --> Loader Class Initialized
INFO - 2024-10-18 14:10:19 --> Helper loaded: url_helper
INFO - 2024-10-18 14:10:19 --> Helper loaded: html_helper
INFO - 2024-10-18 14:10:19 --> Helper loaded: file_helper
INFO - 2024-10-18 14:10:19 --> Helper loaded: string_helper
INFO - 2024-10-18 14:10:19 --> Helper loaded: form_helper
INFO - 2024-10-18 14:10:19 --> Helper loaded: my_helper
INFO - 2024-10-18 14:10:19 --> Database Driver Class Initialized
INFO - 2024-10-18 14:10:21 --> Upload Class Initialized
INFO - 2024-10-18 14:10:21 --> Email Class Initialized
INFO - 2024-10-18 14:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-18 14:10:21 --> Form Validation Class Initialized
INFO - 2024-10-18 14:10:21 --> Controller Class Initialized
INFO - 2024-10-18 19:40:21 --> Model "MainModel" initialized
INFO - 2024-10-18 19:40:21 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-18 19:40:21 --> Final output sent to browser
DEBUG - 2024-10-18 19:40:21 --> Total execution time: 2.2859
INFO - 2024-10-18 14:10:36 --> Config Class Initialized
INFO - 2024-10-18 14:10:36 --> Hooks Class Initialized
DEBUG - 2024-10-18 14:10:36 --> UTF-8 Support Enabled
INFO - 2024-10-18 14:10:36 --> Utf8 Class Initialized
INFO - 2024-10-18 14:10:36 --> URI Class Initialized
DEBUG - 2024-10-18 14:10:36 --> No URI present. Default controller set.
INFO - 2024-10-18 14:10:36 --> Router Class Initialized
INFO - 2024-10-18 14:10:36 --> Output Class Initialized
INFO - 2024-10-18 14:10:36 --> Security Class Initialized
DEBUG - 2024-10-18 14:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-18 14:10:36 --> Input Class Initialized
INFO - 2024-10-18 14:10:36 --> Language Class Initialized
INFO - 2024-10-18 14:10:36 --> Loader Class Initialized
INFO - 2024-10-18 14:10:36 --> Helper loaded: url_helper
INFO - 2024-10-18 14:10:36 --> Helper loaded: html_helper
INFO - 2024-10-18 14:10:36 --> Helper loaded: file_helper
INFO - 2024-10-18 14:10:36 --> Helper loaded: string_helper
INFO - 2024-10-18 14:10:36 --> Helper loaded: form_helper
INFO - 2024-10-18 14:10:36 --> Helper loaded: my_helper
INFO - 2024-10-18 14:10:36 --> Database Driver Class Initialized
INFO - 2024-10-18 14:10:38 --> Upload Class Initialized
INFO - 2024-10-18 14:10:38 --> Email Class Initialized
INFO - 2024-10-18 14:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-18 14:10:38 --> Form Validation Class Initialized
INFO - 2024-10-18 14:10:38 --> Controller Class Initialized
INFO - 2024-10-18 19:40:38 --> Model "MainModel" initialized
INFO - 2024-10-18 19:40:38 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-18 19:40:38 --> Final output sent to browser
DEBUG - 2024-10-18 19:40:38 --> Total execution time: 2.1595
