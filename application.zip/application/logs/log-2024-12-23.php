<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-23 01:31:43 --> Config Class Initialized
INFO - 2024-12-23 01:31:43 --> Hooks Class Initialized
DEBUG - 2024-12-23 01:31:43 --> UTF-8 Support Enabled
INFO - 2024-12-23 01:31:43 --> Utf8 Class Initialized
INFO - 2024-12-23 01:31:43 --> URI Class Initialized
DEBUG - 2024-12-23 01:31:43 --> No URI present. Default controller set.
INFO - 2024-12-23 01:31:43 --> Router Class Initialized
INFO - 2024-12-23 01:31:43 --> Output Class Initialized
INFO - 2024-12-23 01:31:43 --> Security Class Initialized
DEBUG - 2024-12-23 01:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 01:31:43 --> Input Class Initialized
INFO - 2024-12-23 01:31:43 --> Language Class Initialized
INFO - 2024-12-23 01:31:43 --> Loader Class Initialized
INFO - 2024-12-23 01:31:43 --> Helper loaded: url_helper
INFO - 2024-12-23 01:31:43 --> Helper loaded: html_helper
INFO - 2024-12-23 01:31:43 --> Helper loaded: file_helper
INFO - 2024-12-23 01:31:43 --> Helper loaded: string_helper
INFO - 2024-12-23 01:31:43 --> Helper loaded: form_helper
INFO - 2024-12-23 01:31:43 --> Helper loaded: my_helper
INFO - 2024-12-23 01:31:43 --> Database Driver Class Initialized
INFO - 2024-12-23 01:31:45 --> Upload Class Initialized
INFO - 2024-12-23 01:31:45 --> Email Class Initialized
INFO - 2024-12-23 01:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 01:31:45 --> Form Validation Class Initialized
INFO - 2024-12-23 01:31:45 --> Controller Class Initialized
INFO - 2024-12-23 07:01:45 --> Model "MainModel" initialized
INFO - 2024-12-23 07:01:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 07:01:45 --> Final output sent to browser
DEBUG - 2024-12-23 07:01:45 --> Total execution time: 2.2504
INFO - 2024-12-23 02:14:51 --> Config Class Initialized
INFO - 2024-12-23 02:14:51 --> Hooks Class Initialized
DEBUG - 2024-12-23 02:14:51 --> UTF-8 Support Enabled
INFO - 2024-12-23 02:14:51 --> Utf8 Class Initialized
INFO - 2024-12-23 02:14:51 --> URI Class Initialized
DEBUG - 2024-12-23 02:14:51 --> No URI present. Default controller set.
INFO - 2024-12-23 02:14:51 --> Router Class Initialized
INFO - 2024-12-23 02:14:51 --> Output Class Initialized
INFO - 2024-12-23 02:14:51 --> Security Class Initialized
DEBUG - 2024-12-23 02:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 02:14:51 --> Input Class Initialized
INFO - 2024-12-23 02:14:51 --> Language Class Initialized
INFO - 2024-12-23 02:14:51 --> Loader Class Initialized
INFO - 2024-12-23 02:14:51 --> Helper loaded: url_helper
INFO - 2024-12-23 02:14:51 --> Helper loaded: html_helper
INFO - 2024-12-23 02:14:51 --> Helper loaded: file_helper
INFO - 2024-12-23 02:14:51 --> Helper loaded: string_helper
INFO - 2024-12-23 02:14:51 --> Helper loaded: form_helper
INFO - 2024-12-23 02:14:51 --> Helper loaded: my_helper
INFO - 2024-12-23 02:14:51 --> Database Driver Class Initialized
INFO - 2024-12-23 02:14:53 --> Upload Class Initialized
INFO - 2024-12-23 02:14:53 --> Email Class Initialized
INFO - 2024-12-23 02:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 02:14:53 --> Form Validation Class Initialized
INFO - 2024-12-23 02:14:53 --> Controller Class Initialized
INFO - 2024-12-23 07:44:53 --> Model "MainModel" initialized
INFO - 2024-12-23 07:44:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 07:44:53 --> Final output sent to browser
DEBUG - 2024-12-23 07:44:53 --> Total execution time: 2.1636
INFO - 2024-12-23 03:36:09 --> Config Class Initialized
INFO - 2024-12-23 03:36:09 --> Hooks Class Initialized
DEBUG - 2024-12-23 03:36:09 --> UTF-8 Support Enabled
INFO - 2024-12-23 03:36:09 --> Utf8 Class Initialized
INFO - 2024-12-23 03:36:10 --> URI Class Initialized
INFO - 2024-12-23 03:36:10 --> Router Class Initialized
INFO - 2024-12-23 03:36:10 --> Output Class Initialized
INFO - 2024-12-23 03:36:10 --> Security Class Initialized
DEBUG - 2024-12-23 03:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 03:36:10 --> Input Class Initialized
INFO - 2024-12-23 03:36:11 --> Language Class Initialized
ERROR - 2024-12-23 03:36:11 --> 404 Page Not Found: Media/system
INFO - 2024-12-23 07:34:02 --> Config Class Initialized
INFO - 2024-12-23 07:34:02 --> Hooks Class Initialized
DEBUG - 2024-12-23 07:34:02 --> UTF-8 Support Enabled
INFO - 2024-12-23 07:34:02 --> Utf8 Class Initialized
INFO - 2024-12-23 07:34:02 --> URI Class Initialized
DEBUG - 2024-12-23 07:34:02 --> No URI present. Default controller set.
INFO - 2024-12-23 07:34:02 --> Router Class Initialized
INFO - 2024-12-23 07:34:02 --> Output Class Initialized
INFO - 2024-12-23 07:34:02 --> Security Class Initialized
DEBUG - 2024-12-23 07:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 07:34:02 --> Input Class Initialized
INFO - 2024-12-23 07:34:02 --> Language Class Initialized
INFO - 2024-12-23 07:34:02 --> Loader Class Initialized
INFO - 2024-12-23 07:34:02 --> Helper loaded: url_helper
INFO - 2024-12-23 07:34:02 --> Helper loaded: html_helper
INFO - 2024-12-23 07:34:02 --> Helper loaded: file_helper
INFO - 2024-12-23 07:34:02 --> Helper loaded: string_helper
INFO - 2024-12-23 07:34:02 --> Helper loaded: form_helper
INFO - 2024-12-23 07:34:02 --> Helper loaded: my_helper
INFO - 2024-12-23 07:34:02 --> Database Driver Class Initialized
INFO - 2024-12-23 07:34:04 --> Upload Class Initialized
INFO - 2024-12-23 07:34:04 --> Email Class Initialized
INFO - 2024-12-23 07:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 07:34:05 --> Form Validation Class Initialized
INFO - 2024-12-23 07:34:05 --> Controller Class Initialized
INFO - 2024-12-23 13:04:05 --> Model "MainModel" initialized
INFO - 2024-12-23 13:04:05 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 13:04:05 --> Final output sent to browser
DEBUG - 2024-12-23 13:04:05 --> Total execution time: 3.1366
INFO - 2024-12-23 07:35:01 --> Config Class Initialized
INFO - 2024-12-23 07:35:01 --> Hooks Class Initialized
DEBUG - 2024-12-23 07:35:01 --> UTF-8 Support Enabled
INFO - 2024-12-23 07:35:01 --> Utf8 Class Initialized
INFO - 2024-12-23 07:35:01 --> URI Class Initialized
DEBUG - 2024-12-23 07:35:01 --> No URI present. Default controller set.
INFO - 2024-12-23 07:35:01 --> Router Class Initialized
INFO - 2024-12-23 07:35:01 --> Output Class Initialized
INFO - 2024-12-23 07:35:01 --> Security Class Initialized
DEBUG - 2024-12-23 07:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 07:35:01 --> Input Class Initialized
INFO - 2024-12-23 07:35:01 --> Language Class Initialized
INFO - 2024-12-23 07:35:01 --> Loader Class Initialized
INFO - 2024-12-23 07:35:01 --> Helper loaded: url_helper
INFO - 2024-12-23 07:35:01 --> Helper loaded: html_helper
INFO - 2024-12-23 07:35:01 --> Helper loaded: file_helper
INFO - 2024-12-23 07:35:01 --> Helper loaded: string_helper
INFO - 2024-12-23 07:35:01 --> Helper loaded: form_helper
INFO - 2024-12-23 07:35:01 --> Helper loaded: my_helper
INFO - 2024-12-23 07:35:01 --> Database Driver Class Initialized
INFO - 2024-12-23 07:35:03 --> Upload Class Initialized
INFO - 2024-12-23 07:35:03 --> Email Class Initialized
INFO - 2024-12-23 07:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 07:35:03 --> Form Validation Class Initialized
INFO - 2024-12-23 07:35:03 --> Controller Class Initialized
INFO - 2024-12-23 13:05:03 --> Model "MainModel" initialized
INFO - 2024-12-23 13:05:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 13:05:03 --> Final output sent to browser
DEBUG - 2024-12-23 13:05:03 --> Total execution time: 2.2400
INFO - 2024-12-23 07:35:08 --> Config Class Initialized
INFO - 2024-12-23 07:35:08 --> Hooks Class Initialized
DEBUG - 2024-12-23 07:35:08 --> UTF-8 Support Enabled
INFO - 2024-12-23 07:35:08 --> Utf8 Class Initialized
INFO - 2024-12-23 07:35:08 --> URI Class Initialized
INFO - 2024-12-23 07:35:08 --> Router Class Initialized
INFO - 2024-12-23 07:35:08 --> Output Class Initialized
INFO - 2024-12-23 07:35:08 --> Security Class Initialized
DEBUG - 2024-12-23 07:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 07:35:08 --> Input Class Initialized
INFO - 2024-12-23 07:35:08 --> Language Class Initialized
ERROR - 2024-12-23 07:35:08 --> 404 Page Not Found: Adstxt/index
INFO - 2024-12-23 10:39:11 --> Config Class Initialized
INFO - 2024-12-23 10:39:11 --> Hooks Class Initialized
DEBUG - 2024-12-23 10:39:11 --> UTF-8 Support Enabled
INFO - 2024-12-23 10:39:11 --> Utf8 Class Initialized
INFO - 2024-12-23 10:39:11 --> URI Class Initialized
DEBUG - 2024-12-23 10:39:11 --> No URI present. Default controller set.
INFO - 2024-12-23 10:39:11 --> Router Class Initialized
INFO - 2024-12-23 10:39:11 --> Output Class Initialized
INFO - 2024-12-23 10:39:11 --> Security Class Initialized
DEBUG - 2024-12-23 10:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 10:39:11 --> Input Class Initialized
INFO - 2024-12-23 10:39:11 --> Language Class Initialized
INFO - 2024-12-23 10:39:11 --> Loader Class Initialized
INFO - 2024-12-23 10:39:11 --> Helper loaded: url_helper
INFO - 2024-12-23 10:39:11 --> Helper loaded: html_helper
INFO - 2024-12-23 10:39:11 --> Helper loaded: file_helper
INFO - 2024-12-23 10:39:11 --> Helper loaded: string_helper
INFO - 2024-12-23 10:39:11 --> Helper loaded: form_helper
INFO - 2024-12-23 10:39:11 --> Helper loaded: my_helper
INFO - 2024-12-23 10:39:11 --> Database Driver Class Initialized
INFO - 2024-12-23 10:39:13 --> Upload Class Initialized
INFO - 2024-12-23 10:39:13 --> Email Class Initialized
INFO - 2024-12-23 10:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 10:39:14 --> Form Validation Class Initialized
INFO - 2024-12-23 10:39:14 --> Controller Class Initialized
INFO - 2024-12-23 16:09:14 --> Model "MainModel" initialized
INFO - 2024-12-23 16:09:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 16:09:14 --> Final output sent to browser
DEBUG - 2024-12-23 16:09:14 --> Total execution time: 2.7650
INFO - 2024-12-23 12:44:15 --> Config Class Initialized
INFO - 2024-12-23 12:44:15 --> Config Class Initialized
INFO - 2024-12-23 12:44:15 --> Hooks Class Initialized
INFO - 2024-12-23 12:44:15 --> Hooks Class Initialized
DEBUG - 2024-12-23 12:44:15 --> UTF-8 Support Enabled
DEBUG - 2024-12-23 12:44:15 --> UTF-8 Support Enabled
INFO - 2024-12-23 12:44:15 --> Utf8 Class Initialized
INFO - 2024-12-23 12:44:15 --> Utf8 Class Initialized
INFO - 2024-12-23 12:44:15 --> URI Class Initialized
INFO - 2024-12-23 12:44:15 --> URI Class Initialized
DEBUG - 2024-12-23 12:44:15 --> No URI present. Default controller set.
DEBUG - 2024-12-23 12:44:15 --> No URI present. Default controller set.
INFO - 2024-12-23 12:44:15 --> Router Class Initialized
INFO - 2024-12-23 12:44:15 --> Router Class Initialized
INFO - 2024-12-23 12:44:15 --> Output Class Initialized
INFO - 2024-12-23 12:44:15 --> Output Class Initialized
INFO - 2024-12-23 12:44:15 --> Security Class Initialized
INFO - 2024-12-23 12:44:15 --> Security Class Initialized
DEBUG - 2024-12-23 12:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 12:44:15 --> Input Class Initialized
DEBUG - 2024-12-23 12:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 12:44:15 --> Input Class Initialized
INFO - 2024-12-23 12:44:15 --> Language Class Initialized
INFO - 2024-12-23 12:44:15 --> Language Class Initialized
INFO - 2024-12-23 12:44:15 --> Loader Class Initialized
INFO - 2024-12-23 12:44:15 --> Loader Class Initialized
INFO - 2024-12-23 12:44:15 --> Helper loaded: url_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: url_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: html_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: html_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: file_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: file_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: string_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: string_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: form_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: form_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: my_helper
INFO - 2024-12-23 12:44:15 --> Helper loaded: my_helper
INFO - 2024-12-23 12:44:15 --> Database Driver Class Initialized
INFO - 2024-12-23 12:44:15 --> Database Driver Class Initialized
INFO - 2024-12-23 12:44:17 --> Upload Class Initialized
INFO - 2024-12-23 12:44:17 --> Upload Class Initialized
INFO - 2024-12-23 12:44:17 --> Email Class Initialized
INFO - 2024-12-23 12:44:17 --> Email Class Initialized
INFO - 2024-12-23 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 12:44:18 --> Form Validation Class Initialized
INFO - 2024-12-23 12:44:18 --> Controller Class Initialized
INFO - 2024-12-23 12:44:18 --> Form Validation Class Initialized
INFO - 2024-12-23 12:44:18 --> Controller Class Initialized
INFO - 2024-12-23 18:14:18 --> Model "MainModel" initialized
INFO - 2024-12-23 18:14:18 --> Model "MainModel" initialized
INFO - 2024-12-23 18:14:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 18:14:18 --> Final output sent to browser
INFO - 2024-12-23 18:14:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 18:14:18 --> Final output sent to browser
DEBUG - 2024-12-23 18:14:18 --> Total execution time: 3.0707
DEBUG - 2024-12-23 18:14:18 --> Total execution time: 3.0641
INFO - 2024-12-23 12:45:06 --> Config Class Initialized
INFO - 2024-12-23 12:45:06 --> Hooks Class Initialized
DEBUG - 2024-12-23 12:45:06 --> UTF-8 Support Enabled
INFO - 2024-12-23 12:45:06 --> Utf8 Class Initialized
INFO - 2024-12-23 12:45:06 --> URI Class Initialized
DEBUG - 2024-12-23 12:45:06 --> No URI present. Default controller set.
INFO - 2024-12-23 12:45:06 --> Router Class Initialized
INFO - 2024-12-23 12:45:06 --> Output Class Initialized
INFO - 2024-12-23 12:45:06 --> Security Class Initialized
DEBUG - 2024-12-23 12:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 12:45:06 --> Input Class Initialized
INFO - 2024-12-23 12:45:06 --> Language Class Initialized
INFO - 2024-12-23 12:45:06 --> Loader Class Initialized
INFO - 2024-12-23 12:45:06 --> Helper loaded: url_helper
INFO - 2024-12-23 12:45:06 --> Helper loaded: html_helper
INFO - 2024-12-23 12:45:06 --> Helper loaded: file_helper
INFO - 2024-12-23 12:45:06 --> Helper loaded: string_helper
INFO - 2024-12-23 12:45:06 --> Helper loaded: form_helper
INFO - 2024-12-23 12:45:06 --> Helper loaded: my_helper
INFO - 2024-12-23 12:45:06 --> Database Driver Class Initialized
INFO - 2024-12-23 12:45:08 --> Config Class Initialized
INFO - 2024-12-23 12:45:08 --> Hooks Class Initialized
DEBUG - 2024-12-23 12:45:08 --> UTF-8 Support Enabled
INFO - 2024-12-23 12:45:08 --> Utf8 Class Initialized
INFO - 2024-12-23 12:45:08 --> URI Class Initialized
DEBUG - 2024-12-23 12:45:08 --> No URI present. Default controller set.
INFO - 2024-12-23 12:45:08 --> Router Class Initialized
INFO - 2024-12-23 12:45:08 --> Output Class Initialized
INFO - 2024-12-23 12:45:08 --> Security Class Initialized
DEBUG - 2024-12-23 12:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 12:45:08 --> Input Class Initialized
INFO - 2024-12-23 12:45:08 --> Language Class Initialized
INFO - 2024-12-23 12:45:08 --> Loader Class Initialized
INFO - 2024-12-23 12:45:08 --> Helper loaded: url_helper
INFO - 2024-12-23 12:45:08 --> Helper loaded: html_helper
INFO - 2024-12-23 12:45:08 --> Helper loaded: file_helper
INFO - 2024-12-23 12:45:08 --> Helper loaded: string_helper
INFO - 2024-12-23 12:45:08 --> Helper loaded: form_helper
INFO - 2024-12-23 12:45:08 --> Helper loaded: my_helper
INFO - 2024-12-23 12:45:08 --> Database Driver Class Initialized
INFO - 2024-12-23 12:45:08 --> Upload Class Initialized
INFO - 2024-12-23 12:45:08 --> Email Class Initialized
INFO - 2024-12-23 12:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 12:45:08 --> Form Validation Class Initialized
INFO - 2024-12-23 12:45:08 --> Controller Class Initialized
INFO - 2024-12-23 18:15:08 --> Model "MainModel" initialized
INFO - 2024-12-23 18:15:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 18:15:08 --> Final output sent to browser
DEBUG - 2024-12-23 18:15:08 --> Total execution time: 2.2600
INFO - 2024-12-23 12:45:10 --> Upload Class Initialized
INFO - 2024-12-23 12:45:10 --> Email Class Initialized
INFO - 2024-12-23 12:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 12:45:10 --> Form Validation Class Initialized
INFO - 2024-12-23 12:45:10 --> Controller Class Initialized
INFO - 2024-12-23 18:15:10 --> Model "MainModel" initialized
INFO - 2024-12-23 18:15:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-23 18:15:10 --> Final output sent to browser
DEBUG - 2024-12-23 18:15:10 --> Total execution time: 2.6107
INFO - 2024-12-23 18:42:37 --> Config Class Initialized
INFO - 2024-12-23 18:42:37 --> Hooks Class Initialized
DEBUG - 2024-12-23 18:42:37 --> UTF-8 Support Enabled
INFO - 2024-12-23 18:42:37 --> Utf8 Class Initialized
INFO - 2024-12-23 18:42:37 --> URI Class Initialized
DEBUG - 2024-12-23 18:42:37 --> No URI present. Default controller set.
INFO - 2024-12-23 18:42:37 --> Router Class Initialized
INFO - 2024-12-23 18:42:37 --> Output Class Initialized
INFO - 2024-12-23 18:42:37 --> Security Class Initialized
DEBUG - 2024-12-23 18:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 18:42:37 --> Input Class Initialized
INFO - 2024-12-23 18:42:37 --> Language Class Initialized
INFO - 2024-12-23 18:42:37 --> Loader Class Initialized
INFO - 2024-12-23 18:42:37 --> Helper loaded: url_helper
INFO - 2024-12-23 18:42:37 --> Helper loaded: html_helper
INFO - 2024-12-23 18:42:37 --> Helper loaded: file_helper
INFO - 2024-12-23 18:42:37 --> Helper loaded: string_helper
INFO - 2024-12-23 18:42:37 --> Helper loaded: form_helper
INFO - 2024-12-23 18:42:37 --> Helper loaded: my_helper
INFO - 2024-12-23 18:42:37 --> Database Driver Class Initialized
INFO - 2024-12-23 18:42:39 --> Upload Class Initialized
INFO - 2024-12-23 18:42:39 --> Email Class Initialized
INFO - 2024-12-23 18:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 18:42:39 --> Form Validation Class Initialized
INFO - 2024-12-23 18:42:39 --> Controller Class Initialized
INFO - 2024-12-23 18:42:41 --> Config Class Initialized
INFO - 2024-12-23 18:42:41 --> Hooks Class Initialized
DEBUG - 2024-12-23 18:42:41 --> UTF-8 Support Enabled
INFO - 2024-12-23 18:42:41 --> Utf8 Class Initialized
INFO - 2024-12-23 18:42:41 --> URI Class Initialized
INFO - 2024-12-23 18:42:41 --> Router Class Initialized
INFO - 2024-12-23 18:42:41 --> Output Class Initialized
INFO - 2024-12-23 18:42:41 --> Security Class Initialized
DEBUG - 2024-12-23 18:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 18:42:41 --> Input Class Initialized
INFO - 2024-12-23 18:42:41 --> Language Class Initialized
ERROR - 2024-12-23 18:42:41 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-23 18:42:43 --> Config Class Initialized
INFO - 2024-12-23 18:42:43 --> Hooks Class Initialized
DEBUG - 2024-12-23 18:42:43 --> UTF-8 Support Enabled
INFO - 2024-12-23 18:42:43 --> Utf8 Class Initialized
INFO - 2024-12-23 18:42:43 --> URI Class Initialized
INFO - 2024-12-23 18:42:43 --> Router Class Initialized
INFO - 2024-12-23 18:42:43 --> Output Class Initialized
INFO - 2024-12-23 18:42:43 --> Security Class Initialized
DEBUG - 2024-12-23 18:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 18:42:43 --> Input Class Initialized
INFO - 2024-12-23 18:42:43 --> Language Class Initialized
INFO - 2024-12-23 18:42:43 --> Loader Class Initialized
INFO - 2024-12-23 18:42:43 --> Helper loaded: url_helper
INFO - 2024-12-23 18:42:43 --> Helper loaded: html_helper
INFO - 2024-12-23 18:42:43 --> Helper loaded: file_helper
INFO - 2024-12-23 18:42:43 --> Helper loaded: string_helper
INFO - 2024-12-23 18:42:43 --> Helper loaded: form_helper
INFO - 2024-12-23 18:42:43 --> Helper loaded: my_helper
INFO - 2024-12-23 18:42:43 --> Database Driver Class Initialized
INFO - 2024-12-23 18:42:45 --> Upload Class Initialized
INFO - 2024-12-23 18:42:45 --> Email Class Initialized
INFO - 2024-12-23 18:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-23 18:42:45 --> Form Validation Class Initialized
INFO - 2024-12-23 18:42:45 --> Controller Class Initialized
INFO - 2024-12-23 18:42:47 --> Config Class Initialized
INFO - 2024-12-23 18:42:47 --> Hooks Class Initialized
DEBUG - 2024-12-23 18:42:47 --> UTF-8 Support Enabled
INFO - 2024-12-23 18:42:47 --> Utf8 Class Initialized
INFO - 2024-12-23 18:42:47 --> URI Class Initialized
INFO - 2024-12-23 18:42:47 --> Router Class Initialized
INFO - 2024-12-23 18:42:47 --> Output Class Initialized
INFO - 2024-12-23 18:42:47 --> Security Class Initialized
DEBUG - 2024-12-23 18:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-23 18:42:47 --> Input Class Initialized
INFO - 2024-12-23 18:42:47 --> Language Class Initialized
ERROR - 2024-12-23 18:42:47 --> 404 Page Not Found: Adstxt/index
