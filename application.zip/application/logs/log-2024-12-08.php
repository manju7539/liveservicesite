<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-08 03:43:21 --> Config Class Initialized
INFO - 2024-12-08 03:43:21 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:43:21 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:43:21 --> Utf8 Class Initialized
INFO - 2024-12-08 03:43:21 --> URI Class Initialized
INFO - 2024-12-08 03:43:21 --> Router Class Initialized
INFO - 2024-12-08 03:43:21 --> Output Class Initialized
INFO - 2024-12-08 03:43:21 --> Security Class Initialized
DEBUG - 2024-12-08 03:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:43:21 --> Input Class Initialized
INFO - 2024-12-08 03:43:21 --> Language Class Initialized
ERROR - 2024-12-08 03:43:21 --> 404 Page Not Found: Wp-admin/css
INFO - 2024-12-08 03:43:23 --> Config Class Initialized
INFO - 2024-12-08 03:43:23 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:43:23 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:43:23 --> Utf8 Class Initialized
INFO - 2024-12-08 03:43:23 --> URI Class Initialized
INFO - 2024-12-08 03:43:23 --> Router Class Initialized
INFO - 2024-12-08 03:43:23 --> Output Class Initialized
INFO - 2024-12-08 03:43:23 --> Security Class Initialized
DEBUG - 2024-12-08 03:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:43:23 --> Input Class Initialized
INFO - 2024-12-08 03:43:23 --> Language Class Initialized
ERROR - 2024-12-08 03:43:23 --> 404 Page Not Found: Well-known/index
INFO - 2024-12-08 03:43:25 --> Config Class Initialized
INFO - 2024-12-08 03:43:25 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:43:25 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:43:25 --> Utf8 Class Initialized
INFO - 2024-12-08 03:43:25 --> URI Class Initialized
INFO - 2024-12-08 03:43:25 --> Router Class Initialized
INFO - 2024-12-08 03:43:25 --> Output Class Initialized
INFO - 2024-12-08 03:43:25 --> Security Class Initialized
DEBUG - 2024-12-08 03:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:43:25 --> Input Class Initialized
INFO - 2024-12-08 03:43:25 --> Language Class Initialized
ERROR - 2024-12-08 03:43:25 --> 404 Page Not Found: Sites/default
INFO - 2024-12-08 03:43:26 --> Config Class Initialized
INFO - 2024-12-08 03:43:26 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:43:26 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:43:26 --> Utf8 Class Initialized
INFO - 2024-12-08 03:43:26 --> URI Class Initialized
INFO - 2024-12-08 03:43:26 --> Router Class Initialized
INFO - 2024-12-08 03:43:26 --> Output Class Initialized
INFO - 2024-12-08 03:43:26 --> Security Class Initialized
DEBUG - 2024-12-08 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:43:26 --> Input Class Initialized
INFO - 2024-12-08 03:43:26 --> Language Class Initialized
ERROR - 2024-12-08 03:43:26 --> 404 Page Not Found: Admin/controller
INFO - 2024-12-08 03:43:28 --> Config Class Initialized
INFO - 2024-12-08 03:43:28 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:43:28 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:43:28 --> Utf8 Class Initialized
INFO - 2024-12-08 03:43:28 --> URI Class Initialized
INFO - 2024-12-08 03:43:28 --> Router Class Initialized
INFO - 2024-12-08 03:43:28 --> Output Class Initialized
INFO - 2024-12-08 03:43:28 --> Security Class Initialized
DEBUG - 2024-12-08 03:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:43:28 --> Input Class Initialized
INFO - 2024-12-08 03:43:28 --> Language Class Initialized
ERROR - 2024-12-08 03:43:28 --> 404 Page Not Found: Uploads/index
INFO - 2024-12-08 03:43:29 --> Config Class Initialized
INFO - 2024-12-08 03:43:29 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:43:29 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:43:29 --> Utf8 Class Initialized
INFO - 2024-12-08 03:43:29 --> URI Class Initialized
INFO - 2024-12-08 03:43:29 --> Router Class Initialized
INFO - 2024-12-08 03:43:29 --> Output Class Initialized
INFO - 2024-12-08 03:43:29 --> Security Class Initialized
DEBUG - 2024-12-08 03:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:43:29 --> Input Class Initialized
INFO - 2024-12-08 03:43:29 --> Language Class Initialized
ERROR - 2024-12-08 03:43:29 --> 404 Page Not Found: Images/index
INFO - 2024-12-08 03:43:33 --> Config Class Initialized
INFO - 2024-12-08 03:43:33 --> Hooks Class Initialized
DEBUG - 2024-12-08 03:43:33 --> UTF-8 Support Enabled
INFO - 2024-12-08 03:43:33 --> Utf8 Class Initialized
INFO - 2024-12-08 03:43:33 --> URI Class Initialized
INFO - 2024-12-08 03:43:33 --> Router Class Initialized
INFO - 2024-12-08 03:43:33 --> Output Class Initialized
INFO - 2024-12-08 03:43:33 --> Security Class Initialized
DEBUG - 2024-12-08 03:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 03:43:33 --> Input Class Initialized
INFO - 2024-12-08 03:43:33 --> Language Class Initialized
ERROR - 2024-12-08 03:43:33 --> 404 Page Not Found: Files/index
INFO - 2024-12-08 19:15:33 --> Config Class Initialized
INFO - 2024-12-08 19:15:33 --> Hooks Class Initialized
DEBUG - 2024-12-08 19:15:33 --> UTF-8 Support Enabled
INFO - 2024-12-08 19:15:33 --> Utf8 Class Initialized
INFO - 2024-12-08 19:15:33 --> URI Class Initialized
INFO - 2024-12-08 19:15:33 --> Router Class Initialized
INFO - 2024-12-08 19:15:33 --> Output Class Initialized
INFO - 2024-12-08 19:15:33 --> Security Class Initialized
DEBUG - 2024-12-08 19:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-08 19:15:33 --> Input Class Initialized
INFO - 2024-12-08 19:15:33 --> Language Class Initialized
ERROR - 2024-12-08 19:15:33 --> 404 Page Not Found: Wp-loginphp/index
