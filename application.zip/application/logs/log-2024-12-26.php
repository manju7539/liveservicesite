<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-26 00:40:44 --> Config Class Initialized
INFO - 2024-12-26 00:40:44 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:44 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:44 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:44 --> URI Class Initialized
INFO - 2024-12-26 00:40:44 --> Router Class Initialized
INFO - 2024-12-26 00:40:44 --> Output Class Initialized
INFO - 2024-12-26 00:40:44 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:44 --> Input Class Initialized
INFO - 2024-12-26 00:40:44 --> Language Class Initialized
ERROR - 2024-12-26 00:40:44 --> 404 Page Not Found: Wp-includes/ID3
INFO - 2024-12-26 00:40:44 --> Config Class Initialized
INFO - 2024-12-26 00:40:44 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:44 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:44 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:44 --> URI Class Initialized
INFO - 2024-12-26 00:40:44 --> Router Class Initialized
INFO - 2024-12-26 00:40:44 --> Output Class Initialized
INFO - 2024-12-26 00:40:44 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:44 --> Input Class Initialized
INFO - 2024-12-26 00:40:44 --> Language Class Initialized
ERROR - 2024-12-26 00:40:44 --> 404 Page Not Found: Feed/index
INFO - 2024-12-26 00:40:45 --> Config Class Initialized
INFO - 2024-12-26 00:40:45 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:45 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:45 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:45 --> URI Class Initialized
INFO - 2024-12-26 00:40:45 --> Router Class Initialized
INFO - 2024-12-26 00:40:45 --> Output Class Initialized
INFO - 2024-12-26 00:40:45 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:45 --> Input Class Initialized
INFO - 2024-12-26 00:40:45 --> Language Class Initialized
ERROR - 2024-12-26 00:40:45 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-26 00:40:45 --> Config Class Initialized
INFO - 2024-12-26 00:40:45 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:45 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:45 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:45 --> URI Class Initialized
INFO - 2024-12-26 00:40:45 --> Router Class Initialized
INFO - 2024-12-26 00:40:45 --> Output Class Initialized
INFO - 2024-12-26 00:40:45 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:45 --> Input Class Initialized
INFO - 2024-12-26 00:40:45 --> Language Class Initialized
ERROR - 2024-12-26 00:40:45 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-26 00:40:45 --> Config Class Initialized
INFO - 2024-12-26 00:40:45 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:45 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:45 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:45 --> URI Class Initialized
INFO - 2024-12-26 00:40:45 --> Router Class Initialized
INFO - 2024-12-26 00:40:45 --> Output Class Initialized
INFO - 2024-12-26 00:40:45 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:45 --> Input Class Initialized
INFO - 2024-12-26 00:40:45 --> Language Class Initialized
ERROR - 2024-12-26 00:40:45 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-26 00:40:46 --> Config Class Initialized
INFO - 2024-12-26 00:40:46 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:46 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:46 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:46 --> URI Class Initialized
INFO - 2024-12-26 00:40:46 --> Router Class Initialized
INFO - 2024-12-26 00:40:46 --> Output Class Initialized
INFO - 2024-12-26 00:40:46 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:46 --> Input Class Initialized
INFO - 2024-12-26 00:40:46 --> Language Class Initialized
ERROR - 2024-12-26 00:40:46 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-26 00:40:46 --> Config Class Initialized
INFO - 2024-12-26 00:40:46 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:46 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:46 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:46 --> URI Class Initialized
INFO - 2024-12-26 00:40:46 --> Router Class Initialized
INFO - 2024-12-26 00:40:46 --> Output Class Initialized
INFO - 2024-12-26 00:40:46 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:46 --> Input Class Initialized
INFO - 2024-12-26 00:40:46 --> Language Class Initialized
ERROR - 2024-12-26 00:40:46 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-26 00:40:47 --> Config Class Initialized
INFO - 2024-12-26 00:40:47 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:47 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:47 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:47 --> URI Class Initialized
INFO - 2024-12-26 00:40:47 --> Router Class Initialized
INFO - 2024-12-26 00:40:47 --> Output Class Initialized
INFO - 2024-12-26 00:40:47 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:47 --> Input Class Initialized
INFO - 2024-12-26 00:40:47 --> Language Class Initialized
ERROR - 2024-12-26 00:40:47 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-26 00:40:47 --> Config Class Initialized
INFO - 2024-12-26 00:40:47 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:47 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:47 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:47 --> URI Class Initialized
INFO - 2024-12-26 00:40:47 --> Router Class Initialized
INFO - 2024-12-26 00:40:47 --> Output Class Initialized
INFO - 2024-12-26 00:40:47 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:47 --> Input Class Initialized
INFO - 2024-12-26 00:40:47 --> Language Class Initialized
ERROR - 2024-12-26 00:40:47 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-26 00:40:47 --> Config Class Initialized
INFO - 2024-12-26 00:40:47 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:48 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:48 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:48 --> URI Class Initialized
INFO - 2024-12-26 00:40:48 --> Router Class Initialized
INFO - 2024-12-26 00:40:48 --> Output Class Initialized
INFO - 2024-12-26 00:40:48 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:48 --> Input Class Initialized
INFO - 2024-12-26 00:40:48 --> Language Class Initialized
ERROR - 2024-12-26 00:40:48 --> 404 Page Not Found: 2021/wp-includes
INFO - 2024-12-26 00:40:48 --> Config Class Initialized
INFO - 2024-12-26 00:40:48 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:48 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:48 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:48 --> URI Class Initialized
INFO - 2024-12-26 00:40:48 --> Router Class Initialized
INFO - 2024-12-26 00:40:48 --> Output Class Initialized
INFO - 2024-12-26 00:40:48 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:48 --> Input Class Initialized
INFO - 2024-12-26 00:40:48 --> Language Class Initialized
ERROR - 2024-12-26 00:40:48 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-26 00:40:48 --> Config Class Initialized
INFO - 2024-12-26 00:40:48 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:48 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:48 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:48 --> URI Class Initialized
INFO - 2024-12-26 00:40:48 --> Router Class Initialized
INFO - 2024-12-26 00:40:48 --> Output Class Initialized
INFO - 2024-12-26 00:40:48 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:48 --> Input Class Initialized
INFO - 2024-12-26 00:40:48 --> Language Class Initialized
ERROR - 2024-12-26 00:40:48 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-26 00:40:49 --> Config Class Initialized
INFO - 2024-12-26 00:40:49 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:49 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:49 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:49 --> URI Class Initialized
INFO - 2024-12-26 00:40:49 --> Router Class Initialized
INFO - 2024-12-26 00:40:49 --> Output Class Initialized
INFO - 2024-12-26 00:40:49 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:49 --> Input Class Initialized
INFO - 2024-12-26 00:40:49 --> Language Class Initialized
ERROR - 2024-12-26 00:40:49 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-26 00:40:49 --> Config Class Initialized
INFO - 2024-12-26 00:40:49 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:49 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:49 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:49 --> URI Class Initialized
INFO - 2024-12-26 00:40:49 --> Router Class Initialized
INFO - 2024-12-26 00:40:49 --> Output Class Initialized
INFO - 2024-12-26 00:40:49 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:49 --> Input Class Initialized
INFO - 2024-12-26 00:40:49 --> Language Class Initialized
ERROR - 2024-12-26 00:40:49 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-26 00:40:50 --> Config Class Initialized
INFO - 2024-12-26 00:40:50 --> Hooks Class Initialized
DEBUG - 2024-12-26 00:40:50 --> UTF-8 Support Enabled
INFO - 2024-12-26 00:40:50 --> Utf8 Class Initialized
INFO - 2024-12-26 00:40:50 --> URI Class Initialized
INFO - 2024-12-26 00:40:50 --> Router Class Initialized
INFO - 2024-12-26 00:40:50 --> Output Class Initialized
INFO - 2024-12-26 00:40:50 --> Security Class Initialized
DEBUG - 2024-12-26 00:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 00:40:50 --> Input Class Initialized
INFO - 2024-12-26 00:40:50 --> Language Class Initialized
ERROR - 2024-12-26 00:40:50 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-26 02:21:54 --> Config Class Initialized
INFO - 2024-12-26 02:21:54 --> Hooks Class Initialized
DEBUG - 2024-12-26 02:21:54 --> UTF-8 Support Enabled
INFO - 2024-12-26 02:21:54 --> Utf8 Class Initialized
INFO - 2024-12-26 02:21:54 --> URI Class Initialized
DEBUG - 2024-12-26 02:21:54 --> No URI present. Default controller set.
INFO - 2024-12-26 02:21:54 --> Router Class Initialized
INFO - 2024-12-26 02:21:54 --> Output Class Initialized
INFO - 2024-12-26 02:21:54 --> Security Class Initialized
DEBUG - 2024-12-26 02:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-26 02:21:54 --> Input Class Initialized
INFO - 2024-12-26 02:21:54 --> Language Class Initialized
INFO - 2024-12-26 02:21:54 --> Loader Class Initialized
INFO - 2024-12-26 02:21:54 --> Helper loaded: url_helper
INFO - 2024-12-26 02:21:54 --> Helper loaded: html_helper
INFO - 2024-12-26 02:21:54 --> Helper loaded: file_helper
INFO - 2024-12-26 02:21:54 --> Helper loaded: string_helper
INFO - 2024-12-26 02:21:54 --> Helper loaded: form_helper
INFO - 2024-12-26 02:21:54 --> Helper loaded: my_helper
INFO - 2024-12-26 02:21:54 --> Database Driver Class Initialized
INFO - 2024-12-26 02:21:56 --> Upload Class Initialized
INFO - 2024-12-26 02:21:56 --> Email Class Initialized
INFO - 2024-12-26 02:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-26 02:21:57 --> Form Validation Class Initialized
INFO - 2024-12-26 02:21:57 --> Controller Class Initialized
INFO - 2024-12-26 07:51:57 --> Model "MainModel" initialized
INFO - 2024-12-26 07:51:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-26 07:51:57 --> Final output sent to browser
DEBUG - 2024-12-26 07:51:57 --> Total execution time: 2.2430
