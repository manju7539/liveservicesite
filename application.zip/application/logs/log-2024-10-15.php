<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-15 04:52:07 --> Config Class Initialized
INFO - 2024-10-15 04:52:07 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:07 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:07 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:07 --> URI Class Initialized
DEBUG - 2024-10-15 04:52:07 --> No URI present. Default controller set.
INFO - 2024-10-15 04:52:07 --> Router Class Initialized
INFO - 2024-10-15 04:52:07 --> Output Class Initialized
INFO - 2024-10-15 04:52:07 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:07 --> Input Class Initialized
INFO - 2024-10-15 04:52:07 --> Language Class Initialized
INFO - 2024-10-15 04:52:08 --> Loader Class Initialized
INFO - 2024-10-15 04:52:08 --> Helper loaded: url_helper
INFO - 2024-10-15 04:52:08 --> Helper loaded: html_helper
INFO - 2024-10-15 04:52:08 --> Helper loaded: file_helper
INFO - 2024-10-15 04:52:08 --> Helper loaded: string_helper
INFO - 2024-10-15 04:52:08 --> Helper loaded: form_helper
INFO - 2024-10-15 04:52:08 --> Helper loaded: my_helper
INFO - 2024-10-15 04:52:08 --> Database Driver Class Initialized
INFO - 2024-10-15 04:52:10 --> Upload Class Initialized
INFO - 2024-10-15 04:52:10 --> Email Class Initialized
INFO - 2024-10-15 04:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 04:52:10 --> Form Validation Class Initialized
INFO - 2024-10-15 04:52:10 --> Controller Class Initialized
INFO - 2024-10-15 10:22:10 --> Model "MainModel" initialized
INFO - 2024-10-15 10:22:10 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 10:22:10 --> Final output sent to browser
DEBUG - 2024-10-15 10:22:10 --> Total execution time: 2.5354
INFO - 2024-10-15 04:52:14 --> Config Class Initialized
INFO - 2024-10-15 04:52:14 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:14 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:14 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:14 --> URI Class Initialized
DEBUG - 2024-10-15 04:52:14 --> No URI present. Default controller set.
INFO - 2024-10-15 04:52:14 --> Router Class Initialized
INFO - 2024-10-15 04:52:14 --> Output Class Initialized
INFO - 2024-10-15 04:52:14 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:14 --> Input Class Initialized
INFO - 2024-10-15 04:52:14 --> Language Class Initialized
INFO - 2024-10-15 04:52:14 --> Loader Class Initialized
INFO - 2024-10-15 04:52:14 --> Helper loaded: url_helper
INFO - 2024-10-15 04:52:14 --> Helper loaded: html_helper
INFO - 2024-10-15 04:52:14 --> Helper loaded: file_helper
INFO - 2024-10-15 04:52:14 --> Helper loaded: string_helper
INFO - 2024-10-15 04:52:14 --> Helper loaded: form_helper
INFO - 2024-10-15 04:52:14 --> Helper loaded: my_helper
INFO - 2024-10-15 04:52:14 --> Database Driver Class Initialized
INFO - 2024-10-15 04:52:16 --> Upload Class Initialized
INFO - 2024-10-15 04:52:16 --> Email Class Initialized
INFO - 2024-10-15 04:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 04:52:16 --> Form Validation Class Initialized
INFO - 2024-10-15 04:52:16 --> Controller Class Initialized
INFO - 2024-10-15 10:22:16 --> Model "MainModel" initialized
INFO - 2024-10-15 10:22:16 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 10:22:16 --> Final output sent to browser
DEBUG - 2024-10-15 10:22:16 --> Total execution time: 2.0995
INFO - 2024-10-15 04:52:25 --> Config Class Initialized
INFO - 2024-10-15 04:52:25 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:25 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:25 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:25 --> URI Class Initialized
INFO - 2024-10-15 04:52:25 --> Router Class Initialized
INFO - 2024-10-15 04:52:25 --> Output Class Initialized
INFO - 2024-10-15 04:52:25 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:25 --> Input Class Initialized
INFO - 2024-10-15 04:52:25 --> Language Class Initialized
INFO - 2024-10-15 04:52:25 --> Loader Class Initialized
INFO - 2024-10-15 04:52:25 --> Helper loaded: url_helper
INFO - 2024-10-15 04:52:25 --> Helper loaded: html_helper
INFO - 2024-10-15 04:52:25 --> Helper loaded: file_helper
INFO - 2024-10-15 04:52:25 --> Helper loaded: string_helper
INFO - 2024-10-15 04:52:25 --> Helper loaded: form_helper
INFO - 2024-10-15 04:52:25 --> Helper loaded: my_helper
INFO - 2024-10-15 04:52:25 --> Database Driver Class Initialized
INFO - 2024-10-15 04:52:27 --> Upload Class Initialized
INFO - 2024-10-15 04:52:27 --> Email Class Initialized
INFO - 2024-10-15 04:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 04:52:27 --> Form Validation Class Initialized
INFO - 2024-10-15 04:52:27 --> Controller Class Initialized
INFO - 2024-10-15 10:22:27 --> Model "MainModel" initialized
INFO - 2024-10-15 04:52:27 --> Config Class Initialized
INFO - 2024-10-15 04:52:27 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:27 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:27 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:27 --> URI Class Initialized
INFO - 2024-10-15 04:52:27 --> Router Class Initialized
INFO - 2024-10-15 04:52:27 --> Output Class Initialized
INFO - 2024-10-15 04:52:27 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:27 --> Input Class Initialized
INFO - 2024-10-15 04:52:27 --> Language Class Initialized
INFO - 2024-10-15 04:52:27 --> Loader Class Initialized
INFO - 2024-10-15 04:52:27 --> Helper loaded: url_helper
INFO - 2024-10-15 04:52:27 --> Helper loaded: html_helper
INFO - 2024-10-15 04:52:27 --> Helper loaded: file_helper
INFO - 2024-10-15 04:52:27 --> Helper loaded: string_helper
INFO - 2024-10-15 04:52:27 --> Helper loaded: form_helper
INFO - 2024-10-15 04:52:27 --> Helper loaded: my_helper
INFO - 2024-10-15 04:52:27 --> Database Driver Class Initialized
INFO - 2024-10-15 04:52:29 --> Upload Class Initialized
INFO - 2024-10-15 04:52:29 --> Email Class Initialized
INFO - 2024-10-15 04:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 04:52:29 --> Form Validation Class Initialized
INFO - 2024-10-15 04:52:29 --> Controller Class Initialized
INFO - 2024-10-15 10:22:29 --> Model "MainModel" initialized
INFO - 2024-10-15 10:22:29 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 10:22:29 --> Model "HotelAdminModel" initialized
INFO - 2024-10-15 10:22:29 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-15 10:22:29 --> Model "FoodAdminModel" initialized
INFO - 2024-10-15 10:22:29 --> Model "SuperAdminModel" initialized
INFO - 2024-10-15 10:22:29 --> Helper loaded: notification_helper
INFO - 2024-10-15 10:22:29 --> Helper loaded: array_helper
INFO - 2024-10-15 10:22:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-15 10:22:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-15 10:22:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-15 10:22:30 --> Final output sent to browser
DEBUG - 2024-10-15 10:22:30 --> Total execution time: 2.4158
INFO - 2024-10-15 04:52:30 --> Config Class Initialized
INFO - 2024-10-15 04:52:30 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:30 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:30 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:30 --> URI Class Initialized
INFO - 2024-10-15 04:52:30 --> Router Class Initialized
INFO - 2024-10-15 04:52:30 --> Output Class Initialized
INFO - 2024-10-15 04:52:30 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:30 --> Input Class Initialized
INFO - 2024-10-15 04:52:30 --> Language Class Initialized
ERROR - 2024-10-15 04:52:30 --> 404 Page Not Found: Ajaxgoogleapiscom/ajax
INFO - 2024-10-15 04:52:31 --> Config Class Initialized
INFO - 2024-10-15 04:52:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:31 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:31 --> URI Class Initialized
INFO - 2024-10-15 04:52:31 --> Router Class Initialized
INFO - 2024-10-15 04:52:31 --> Output Class Initialized
INFO - 2024-10-15 04:52:31 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:31 --> Input Class Initialized
INFO - 2024-10-15 04:52:31 --> Language Class Initialized
INFO - 2024-10-15 04:52:31 --> Loader Class Initialized
INFO - 2024-10-15 04:52:31 --> Helper loaded: url_helper
INFO - 2024-10-15 04:52:31 --> Helper loaded: html_helper
INFO - 2024-10-15 04:52:31 --> Helper loaded: file_helper
INFO - 2024-10-15 04:52:31 --> Helper loaded: string_helper
INFO - 2024-10-15 04:52:31 --> Helper loaded: form_helper
INFO - 2024-10-15 04:52:31 --> Helper loaded: my_helper
INFO - 2024-10-15 04:52:31 --> Database Driver Class Initialized
INFO - 2024-10-15 04:52:33 --> Upload Class Initialized
INFO - 2024-10-15 04:52:33 --> Email Class Initialized
INFO - 2024-10-15 04:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 04:52:33 --> Form Validation Class Initialized
INFO - 2024-10-15 04:52:33 --> Controller Class Initialized
INFO - 2024-10-15 10:22:33 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 10:22:33 --> Model "MainModel" initialized
INFO - 2024-10-15 10:22:33 --> Model "ApiModel" initialized
INFO - 2024-10-15 10:22:33 --> Helper loaded: notification_helper
INFO - 2024-10-15 10:22:33 --> Final output sent to browser
DEBUG - 2024-10-15 10:22:33 --> Total execution time: 2.3230
INFO - 2024-10-15 04:52:36 --> Config Class Initialized
INFO - 2024-10-15 04:52:36 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:36 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:36 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:36 --> URI Class Initialized
INFO - 2024-10-15 04:52:36 --> Router Class Initialized
INFO - 2024-10-15 04:52:36 --> Output Class Initialized
INFO - 2024-10-15 04:52:36 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:36 --> Input Class Initialized
INFO - 2024-10-15 04:52:36 --> Language Class Initialized
INFO - 2024-10-15 04:52:36 --> Loader Class Initialized
INFO - 2024-10-15 04:52:36 --> Helper loaded: url_helper
INFO - 2024-10-15 04:52:36 --> Helper loaded: html_helper
INFO - 2024-10-15 04:52:36 --> Helper loaded: file_helper
INFO - 2024-10-15 04:52:36 --> Helper loaded: string_helper
INFO - 2024-10-15 04:52:36 --> Helper loaded: form_helper
INFO - 2024-10-15 04:52:36 --> Helper loaded: my_helper
INFO - 2024-10-15 04:52:36 --> Database Driver Class Initialized
INFO - 2024-10-15 04:52:38 --> Upload Class Initialized
INFO - 2024-10-15 04:52:38 --> Email Class Initialized
INFO - 2024-10-15 04:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 04:52:38 --> Form Validation Class Initialized
INFO - 2024-10-15 04:52:38 --> Controller Class Initialized
INFO - 2024-10-15 10:22:38 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 10:22:38 --> Model "MainModel" initialized
INFO - 2024-10-15 10:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 10:22:38 --> Pagination Class Initialized
INFO - 2024-10-15 04:52:43 --> Config Class Initialized
INFO - 2024-10-15 04:52:43 --> Hooks Class Initialized
DEBUG - 2024-10-15 04:52:43 --> UTF-8 Support Enabled
INFO - 2024-10-15 04:52:43 --> Utf8 Class Initialized
INFO - 2024-10-15 04:52:43 --> URI Class Initialized
DEBUG - 2024-10-15 04:52:43 --> No URI present. Default controller set.
INFO - 2024-10-15 04:52:43 --> Router Class Initialized
INFO - 2024-10-15 04:52:43 --> Output Class Initialized
INFO - 2024-10-15 04:52:43 --> Security Class Initialized
DEBUG - 2024-10-15 04:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 04:52:43 --> Input Class Initialized
INFO - 2024-10-15 04:52:43 --> Language Class Initialized
INFO - 2024-10-15 04:52:43 --> Loader Class Initialized
INFO - 2024-10-15 04:52:43 --> Helper loaded: url_helper
INFO - 2024-10-15 04:52:43 --> Helper loaded: html_helper
INFO - 2024-10-15 04:52:43 --> Helper loaded: file_helper
INFO - 2024-10-15 04:52:43 --> Helper loaded: string_helper
INFO - 2024-10-15 04:52:43 --> Helper loaded: form_helper
INFO - 2024-10-15 04:52:43 --> Helper loaded: my_helper
INFO - 2024-10-15 04:52:43 --> Database Driver Class Initialized
INFO - 2024-10-15 04:52:45 --> Upload Class Initialized
INFO - 2024-10-15 04:52:45 --> Email Class Initialized
INFO - 2024-10-15 04:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 04:52:45 --> Form Validation Class Initialized
INFO - 2024-10-15 04:52:45 --> Controller Class Initialized
INFO - 2024-10-15 10:22:45 --> Model "MainModel" initialized
INFO - 2024-10-15 10:22:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 10:22:45 --> Final output sent to browser
DEBUG - 2024-10-15 10:22:45 --> Total execution time: 2.1913
INFO - 2024-10-15 05:13:26 --> Config Class Initialized
INFO - 2024-10-15 05:13:26 --> Hooks Class Initialized
DEBUG - 2024-10-15 05:13:26 --> UTF-8 Support Enabled
INFO - 2024-10-15 05:13:26 --> Utf8 Class Initialized
INFO - 2024-10-15 05:13:26 --> URI Class Initialized
DEBUG - 2024-10-15 05:13:26 --> No URI present. Default controller set.
INFO - 2024-10-15 05:13:26 --> Router Class Initialized
INFO - 2024-10-15 05:13:26 --> Output Class Initialized
INFO - 2024-10-15 05:13:26 --> Security Class Initialized
DEBUG - 2024-10-15 05:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 05:13:26 --> Input Class Initialized
INFO - 2024-10-15 05:13:26 --> Language Class Initialized
INFO - 2024-10-15 05:13:26 --> Loader Class Initialized
INFO - 2024-10-15 05:13:26 --> Helper loaded: url_helper
INFO - 2024-10-15 05:13:26 --> Helper loaded: html_helper
INFO - 2024-10-15 05:13:26 --> Helper loaded: file_helper
INFO - 2024-10-15 05:13:26 --> Helper loaded: string_helper
INFO - 2024-10-15 05:13:26 --> Helper loaded: form_helper
INFO - 2024-10-15 05:13:26 --> Helper loaded: my_helper
INFO - 2024-10-15 05:13:26 --> Database Driver Class Initialized
INFO - 2024-10-15 05:13:28 --> Upload Class Initialized
INFO - 2024-10-15 05:13:28 --> Email Class Initialized
INFO - 2024-10-15 05:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 05:13:28 --> Form Validation Class Initialized
INFO - 2024-10-15 05:13:28 --> Controller Class Initialized
INFO - 2024-10-15 10:43:28 --> Model "MainModel" initialized
INFO - 2024-10-15 10:43:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 10:43:28 --> Final output sent to browser
DEBUG - 2024-10-15 10:43:28 --> Total execution time: 2.3717
INFO - 2024-10-15 09:57:17 --> Config Class Initialized
INFO - 2024-10-15 09:57:17 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:57:17 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:57:17 --> Utf8 Class Initialized
INFO - 2024-10-15 09:57:17 --> URI Class Initialized
DEBUG - 2024-10-15 09:57:17 --> No URI present. Default controller set.
INFO - 2024-10-15 09:57:17 --> Router Class Initialized
INFO - 2024-10-15 09:57:17 --> Output Class Initialized
INFO - 2024-10-15 09:57:17 --> Security Class Initialized
DEBUG - 2024-10-15 09:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:57:17 --> Input Class Initialized
INFO - 2024-10-15 09:57:17 --> Language Class Initialized
INFO - 2024-10-15 09:57:17 --> Loader Class Initialized
INFO - 2024-10-15 09:57:17 --> Helper loaded: url_helper
INFO - 2024-10-15 09:57:17 --> Helper loaded: html_helper
INFO - 2024-10-15 09:57:17 --> Helper loaded: file_helper
INFO - 2024-10-15 09:57:17 --> Helper loaded: string_helper
INFO - 2024-10-15 09:57:17 --> Helper loaded: form_helper
INFO - 2024-10-15 09:57:17 --> Helper loaded: my_helper
INFO - 2024-10-15 09:57:17 --> Database Driver Class Initialized
INFO - 2024-10-15 09:57:19 --> Upload Class Initialized
INFO - 2024-10-15 09:57:19 --> Email Class Initialized
INFO - 2024-10-15 09:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:57:19 --> Form Validation Class Initialized
INFO - 2024-10-15 09:57:19 --> Controller Class Initialized
INFO - 2024-10-15 15:27:19 --> Model "MainModel" initialized
INFO - 2024-10-15 15:27:19 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:27:19 --> Final output sent to browser
DEBUG - 2024-10-15 15:27:19 --> Total execution time: 2.7753
INFO - 2024-10-15 09:57:22 --> Config Class Initialized
INFO - 2024-10-15 09:57:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:57:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:57:22 --> Utf8 Class Initialized
INFO - 2024-10-15 09:57:22 --> URI Class Initialized
DEBUG - 2024-10-15 09:57:22 --> No URI present. Default controller set.
INFO - 2024-10-15 09:57:22 --> Router Class Initialized
INFO - 2024-10-15 09:57:22 --> Output Class Initialized
INFO - 2024-10-15 09:57:22 --> Security Class Initialized
DEBUG - 2024-10-15 09:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:57:22 --> Input Class Initialized
INFO - 2024-10-15 09:57:22 --> Language Class Initialized
INFO - 2024-10-15 09:57:22 --> Loader Class Initialized
INFO - 2024-10-15 09:57:22 --> Helper loaded: url_helper
INFO - 2024-10-15 09:57:22 --> Helper loaded: html_helper
INFO - 2024-10-15 09:57:22 --> Helper loaded: file_helper
INFO - 2024-10-15 09:57:22 --> Helper loaded: string_helper
INFO - 2024-10-15 09:57:22 --> Helper loaded: form_helper
INFO - 2024-10-15 09:57:22 --> Helper loaded: my_helper
INFO - 2024-10-15 09:57:22 --> Database Driver Class Initialized
INFO - 2024-10-15 09:57:24 --> Upload Class Initialized
INFO - 2024-10-15 09:57:24 --> Email Class Initialized
INFO - 2024-10-15 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:57:24 --> Form Validation Class Initialized
INFO - 2024-10-15 09:57:24 --> Controller Class Initialized
INFO - 2024-10-15 15:27:24 --> Model "MainModel" initialized
INFO - 2024-10-15 15:27:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:27:24 --> Final output sent to browser
DEBUG - 2024-10-15 15:27:24 --> Total execution time: 2.1447
INFO - 2024-10-15 09:57:29 --> Config Class Initialized
INFO - 2024-10-15 09:57:29 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:57:29 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:57:29 --> Utf8 Class Initialized
INFO - 2024-10-15 09:57:29 --> URI Class Initialized
DEBUG - 2024-10-15 09:57:29 --> No URI present. Default controller set.
INFO - 2024-10-15 09:57:29 --> Router Class Initialized
INFO - 2024-10-15 09:57:29 --> Output Class Initialized
INFO - 2024-10-15 09:57:29 --> Security Class Initialized
DEBUG - 2024-10-15 09:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:57:29 --> Input Class Initialized
INFO - 2024-10-15 09:57:29 --> Language Class Initialized
INFO - 2024-10-15 09:57:29 --> Loader Class Initialized
INFO - 2024-10-15 09:57:29 --> Helper loaded: url_helper
INFO - 2024-10-15 09:57:29 --> Helper loaded: html_helper
INFO - 2024-10-15 09:57:29 --> Helper loaded: file_helper
INFO - 2024-10-15 09:57:29 --> Helper loaded: string_helper
INFO - 2024-10-15 09:57:29 --> Helper loaded: form_helper
INFO - 2024-10-15 09:57:29 --> Helper loaded: my_helper
INFO - 2024-10-15 09:57:29 --> Database Driver Class Initialized
INFO - 2024-10-15 09:57:31 --> Upload Class Initialized
INFO - 2024-10-15 09:57:31 --> Email Class Initialized
INFO - 2024-10-15 09:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:57:31 --> Form Validation Class Initialized
INFO - 2024-10-15 09:57:31 --> Controller Class Initialized
INFO - 2024-10-15 15:27:31 --> Model "MainModel" initialized
INFO - 2024-10-15 15:27:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:27:31 --> Final output sent to browser
DEBUG - 2024-10-15 15:27:31 --> Total execution time: 2.1127
INFO - 2024-10-15 09:57:47 --> Config Class Initialized
INFO - 2024-10-15 09:57:47 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:57:47 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:57:47 --> Utf8 Class Initialized
INFO - 2024-10-15 09:57:48 --> URI Class Initialized
INFO - 2024-10-15 09:57:48 --> Router Class Initialized
INFO - 2024-10-15 09:57:48 --> Output Class Initialized
INFO - 2024-10-15 09:57:48 --> Security Class Initialized
DEBUG - 2024-10-15 09:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:57:48 --> Input Class Initialized
INFO - 2024-10-15 09:57:48 --> Language Class Initialized
INFO - 2024-10-15 09:57:48 --> Loader Class Initialized
INFO - 2024-10-15 09:57:48 --> Helper loaded: url_helper
INFO - 2024-10-15 09:57:48 --> Helper loaded: html_helper
INFO - 2024-10-15 09:57:48 --> Helper loaded: file_helper
INFO - 2024-10-15 09:57:48 --> Helper loaded: string_helper
INFO - 2024-10-15 09:57:48 --> Helper loaded: form_helper
INFO - 2024-10-15 09:57:48 --> Helper loaded: my_helper
INFO - 2024-10-15 09:57:48 --> Database Driver Class Initialized
INFO - 2024-10-15 09:57:50 --> Upload Class Initialized
INFO - 2024-10-15 09:57:50 --> Email Class Initialized
INFO - 2024-10-15 09:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:57:50 --> Form Validation Class Initialized
INFO - 2024-10-15 09:57:50 --> Controller Class Initialized
INFO - 2024-10-15 15:27:50 --> Model "MainModel" initialized
INFO - 2024-10-15 09:57:50 --> Config Class Initialized
INFO - 2024-10-15 09:57:50 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:57:50 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:57:50 --> Utf8 Class Initialized
INFO - 2024-10-15 09:57:50 --> URI Class Initialized
DEBUG - 2024-10-15 09:57:50 --> No URI present. Default controller set.
INFO - 2024-10-15 09:57:50 --> Router Class Initialized
INFO - 2024-10-15 09:57:50 --> Output Class Initialized
INFO - 2024-10-15 09:57:50 --> Security Class Initialized
DEBUG - 2024-10-15 09:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:57:50 --> Input Class Initialized
INFO - 2024-10-15 09:57:50 --> Language Class Initialized
INFO - 2024-10-15 09:57:50 --> Loader Class Initialized
INFO - 2024-10-15 09:57:50 --> Helper loaded: url_helper
INFO - 2024-10-15 09:57:50 --> Helper loaded: html_helper
INFO - 2024-10-15 09:57:50 --> Helper loaded: file_helper
INFO - 2024-10-15 09:57:50 --> Helper loaded: string_helper
INFO - 2024-10-15 09:57:50 --> Helper loaded: form_helper
INFO - 2024-10-15 09:57:50 --> Helper loaded: my_helper
INFO - 2024-10-15 09:57:50 --> Database Driver Class Initialized
INFO - 2024-10-15 09:57:52 --> Upload Class Initialized
INFO - 2024-10-15 09:57:52 --> Email Class Initialized
INFO - 2024-10-15 09:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:57:52 --> Form Validation Class Initialized
INFO - 2024-10-15 09:57:52 --> Controller Class Initialized
INFO - 2024-10-15 15:27:52 --> Model "MainModel" initialized
INFO - 2024-10-15 15:27:52 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:27:52 --> Final output sent to browser
DEBUG - 2024-10-15 15:27:52 --> Total execution time: 2.1062
INFO - 2024-10-15 09:57:59 --> Config Class Initialized
INFO - 2024-10-15 09:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:57:59 --> Utf8 Class Initialized
INFO - 2024-10-15 09:57:59 --> URI Class Initialized
INFO - 2024-10-15 09:57:59 --> Router Class Initialized
INFO - 2024-10-15 09:57:59 --> Output Class Initialized
INFO - 2024-10-15 09:57:59 --> Security Class Initialized
DEBUG - 2024-10-15 09:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:57:59 --> Input Class Initialized
INFO - 2024-10-15 09:57:59 --> Language Class Initialized
INFO - 2024-10-15 09:57:59 --> Loader Class Initialized
INFO - 2024-10-15 09:57:59 --> Helper loaded: url_helper
INFO - 2024-10-15 09:57:59 --> Helper loaded: html_helper
INFO - 2024-10-15 09:57:59 --> Helper loaded: file_helper
INFO - 2024-10-15 09:57:59 --> Helper loaded: string_helper
INFO - 2024-10-15 09:57:59 --> Helper loaded: form_helper
INFO - 2024-10-15 09:57:59 --> Helper loaded: my_helper
INFO - 2024-10-15 09:57:59 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:01 --> Upload Class Initialized
INFO - 2024-10-15 09:58:01 --> Email Class Initialized
INFO - 2024-10-15 09:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:01 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:01 --> Controller Class Initialized
INFO - 2024-10-15 15:28:01 --> Model "MainModel" initialized
INFO - 2024-10-15 09:58:01 --> Config Class Initialized
INFO - 2024-10-15 09:58:01 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:01 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:01 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:01 --> URI Class Initialized
DEBUG - 2024-10-15 09:58:01 --> No URI present. Default controller set.
INFO - 2024-10-15 09:58:01 --> Router Class Initialized
INFO - 2024-10-15 09:58:01 --> Output Class Initialized
INFO - 2024-10-15 09:58:01 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:01 --> Input Class Initialized
INFO - 2024-10-15 09:58:01 --> Language Class Initialized
INFO - 2024-10-15 09:58:01 --> Loader Class Initialized
INFO - 2024-10-15 09:58:01 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:01 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:01 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:01 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:01 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:01 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:01 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:03 --> Upload Class Initialized
INFO - 2024-10-15 09:58:03 --> Email Class Initialized
INFO - 2024-10-15 09:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:03 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:03 --> Controller Class Initialized
INFO - 2024-10-15 15:28:03 --> Model "MainModel" initialized
INFO - 2024-10-15 15:28:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:28:03 --> Final output sent to browser
DEBUG - 2024-10-15 15:28:03 --> Total execution time: 2.1242
INFO - 2024-10-15 09:58:08 --> Config Class Initialized
INFO - 2024-10-15 09:58:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:08 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:08 --> URI Class Initialized
INFO - 2024-10-15 09:58:08 --> Router Class Initialized
INFO - 2024-10-15 09:58:08 --> Output Class Initialized
INFO - 2024-10-15 09:58:08 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:08 --> Input Class Initialized
INFO - 2024-10-15 09:58:08 --> Language Class Initialized
INFO - 2024-10-15 09:58:08 --> Loader Class Initialized
INFO - 2024-10-15 09:58:08 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:08 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:08 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:08 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:08 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:08 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:08 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:10 --> Upload Class Initialized
INFO - 2024-10-15 09:58:10 --> Email Class Initialized
INFO - 2024-10-15 09:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:10 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:10 --> Controller Class Initialized
INFO - 2024-10-15 15:28:10 --> Model "MainModel" initialized
INFO - 2024-10-15 09:58:10 --> Config Class Initialized
INFO - 2024-10-15 09:58:10 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:10 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:10 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:10 --> URI Class Initialized
DEBUG - 2024-10-15 09:58:10 --> No URI present. Default controller set.
INFO - 2024-10-15 09:58:10 --> Router Class Initialized
INFO - 2024-10-15 09:58:10 --> Output Class Initialized
INFO - 2024-10-15 09:58:10 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:10 --> Input Class Initialized
INFO - 2024-10-15 09:58:10 --> Language Class Initialized
INFO - 2024-10-15 09:58:10 --> Loader Class Initialized
INFO - 2024-10-15 09:58:10 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:10 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:10 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:10 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:10 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:10 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:10 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:12 --> Upload Class Initialized
INFO - 2024-10-15 09:58:12 --> Email Class Initialized
INFO - 2024-10-15 09:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:12 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:12 --> Controller Class Initialized
INFO - 2024-10-15 15:28:12 --> Model "MainModel" initialized
INFO - 2024-10-15 15:28:12 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:28:12 --> Final output sent to browser
DEBUG - 2024-10-15 15:28:12 --> Total execution time: 2.1129
INFO - 2024-10-15 09:58:19 --> Config Class Initialized
INFO - 2024-10-15 09:58:19 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:19 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:19 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:19 --> URI Class Initialized
INFO - 2024-10-15 09:58:19 --> Router Class Initialized
INFO - 2024-10-15 09:58:19 --> Output Class Initialized
INFO - 2024-10-15 09:58:19 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:19 --> Input Class Initialized
INFO - 2024-10-15 09:58:19 --> Language Class Initialized
INFO - 2024-10-15 09:58:19 --> Loader Class Initialized
INFO - 2024-10-15 09:58:19 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:19 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:19 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:19 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:19 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:19 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:19 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:21 --> Upload Class Initialized
INFO - 2024-10-15 09:58:21 --> Email Class Initialized
INFO - 2024-10-15 09:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:21 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:21 --> Controller Class Initialized
INFO - 2024-10-15 15:28:21 --> Model "MainModel" initialized
INFO - 2024-10-15 09:58:22 --> Config Class Initialized
INFO - 2024-10-15 09:58:22 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:22 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:22 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:22 --> URI Class Initialized
DEBUG - 2024-10-15 09:58:22 --> No URI present. Default controller set.
INFO - 2024-10-15 09:58:22 --> Router Class Initialized
INFO - 2024-10-15 09:58:22 --> Output Class Initialized
INFO - 2024-10-15 09:58:22 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:22 --> Input Class Initialized
INFO - 2024-10-15 09:58:22 --> Language Class Initialized
INFO - 2024-10-15 09:58:22 --> Loader Class Initialized
INFO - 2024-10-15 09:58:22 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:22 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:22 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:22 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:22 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:22 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:22 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:24 --> Upload Class Initialized
INFO - 2024-10-15 09:58:24 --> Email Class Initialized
INFO - 2024-10-15 09:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:24 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:24 --> Controller Class Initialized
INFO - 2024-10-15 15:28:24 --> Model "MainModel" initialized
INFO - 2024-10-15 15:28:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:28:24 --> Final output sent to browser
DEBUG - 2024-10-15 15:28:24 --> Total execution time: 2.1281
INFO - 2024-10-15 09:58:34 --> Config Class Initialized
INFO - 2024-10-15 09:58:34 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:34 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:34 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:34 --> URI Class Initialized
DEBUG - 2024-10-15 09:58:34 --> No URI present. Default controller set.
INFO - 2024-10-15 09:58:34 --> Router Class Initialized
INFO - 2024-10-15 09:58:34 --> Output Class Initialized
INFO - 2024-10-15 09:58:34 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:34 --> Input Class Initialized
INFO - 2024-10-15 09:58:34 --> Language Class Initialized
INFO - 2024-10-15 09:58:34 --> Loader Class Initialized
INFO - 2024-10-15 09:58:34 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:34 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:34 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:34 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:34 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:34 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:34 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:36 --> Upload Class Initialized
INFO - 2024-10-15 09:58:36 --> Email Class Initialized
INFO - 2024-10-15 09:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:36 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:36 --> Controller Class Initialized
INFO - 2024-10-15 15:28:36 --> Model "MainModel" initialized
INFO - 2024-10-15 15:28:36 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:28:36 --> Final output sent to browser
DEBUG - 2024-10-15 15:28:36 --> Total execution time: 2.1225
INFO - 2024-10-15 09:58:44 --> Config Class Initialized
INFO - 2024-10-15 09:58:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:44 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:44 --> URI Class Initialized
INFO - 2024-10-15 09:58:44 --> Router Class Initialized
INFO - 2024-10-15 09:58:44 --> Output Class Initialized
INFO - 2024-10-15 09:58:44 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:44 --> Input Class Initialized
INFO - 2024-10-15 09:58:44 --> Language Class Initialized
INFO - 2024-10-15 09:58:44 --> Loader Class Initialized
INFO - 2024-10-15 09:58:44 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:44 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:44 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:44 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:44 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:44 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:44 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:46 --> Upload Class Initialized
INFO - 2024-10-15 09:58:46 --> Email Class Initialized
INFO - 2024-10-15 09:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:46 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:47 --> Controller Class Initialized
INFO - 2024-10-15 15:28:47 --> Model "MainModel" initialized
INFO - 2024-10-15 09:58:47 --> Config Class Initialized
INFO - 2024-10-15 09:58:47 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:47 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:47 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:47 --> URI Class Initialized
INFO - 2024-10-15 09:58:47 --> Router Class Initialized
INFO - 2024-10-15 09:58:47 --> Output Class Initialized
INFO - 2024-10-15 09:58:47 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:47 --> Input Class Initialized
INFO - 2024-10-15 09:58:47 --> Language Class Initialized
INFO - 2024-10-15 09:58:47 --> Loader Class Initialized
INFO - 2024-10-15 09:58:47 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:47 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:47 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:47 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:47 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:47 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:47 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:49 --> Upload Class Initialized
INFO - 2024-10-15 09:58:49 --> Email Class Initialized
INFO - 2024-10-15 09:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:49 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:49 --> Controller Class Initialized
INFO - 2024-10-15 15:28:49 --> Model "MainModel" initialized
INFO - 2024-10-15 15:28:49 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:28:49 --> Model "HotelAdminModel" initialized
INFO - 2024-10-15 15:28:49 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-15 15:28:49 --> Model "FoodAdminModel" initialized
INFO - 2024-10-15 15:28:49 --> Model "SuperAdminModel" initialized
INFO - 2024-10-15 15:28:49 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:28:49 --> Helper loaded: array_helper
INFO - 2024-10-15 15:28:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-15 15:28:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-15 15:28:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-15 15:28:49 --> Final output sent to browser
DEBUG - 2024-10-15 15:28:49 --> Total execution time: 2.5970
INFO - 2024-10-15 09:58:50 --> Config Class Initialized
INFO - 2024-10-15 09:58:50 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:50 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:50 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:50 --> URI Class Initialized
INFO - 2024-10-15 09:58:50 --> Router Class Initialized
INFO - 2024-10-15 09:58:50 --> Output Class Initialized
INFO - 2024-10-15 09:58:50 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:50 --> Input Class Initialized
INFO - 2024-10-15 09:58:50 --> Language Class Initialized
ERROR - 2024-10-15 09:58:50 --> 404 Page Not Found: Ajaxgoogleapiscom/ajax
INFO - 2024-10-15 09:58:50 --> Config Class Initialized
INFO - 2024-10-15 09:58:50 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:50 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:50 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:50 --> URI Class Initialized
INFO - 2024-10-15 09:58:50 --> Router Class Initialized
INFO - 2024-10-15 09:58:50 --> Output Class Initialized
INFO - 2024-10-15 09:58:50 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:50 --> Input Class Initialized
INFO - 2024-10-15 09:58:50 --> Language Class Initialized
INFO - 2024-10-15 09:58:51 --> Loader Class Initialized
INFO - 2024-10-15 09:58:51 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:51 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:51 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:51 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:51 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:51 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:51 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:53 --> Upload Class Initialized
INFO - 2024-10-15 09:58:53 --> Email Class Initialized
INFO - 2024-10-15 09:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:53 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:53 --> Controller Class Initialized
INFO - 2024-10-15 15:28:53 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:28:53 --> Model "MainModel" initialized
INFO - 2024-10-15 15:28:53 --> Model "ApiModel" initialized
INFO - 2024-10-15 15:28:53 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:28:53 --> Final output sent to browser
DEBUG - 2024-10-15 15:28:53 --> Total execution time: 2.2069
INFO - 2024-10-15 09:58:55 --> Config Class Initialized
INFO - 2024-10-15 09:58:55 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:55 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:55 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:55 --> URI Class Initialized
INFO - 2024-10-15 09:58:55 --> Router Class Initialized
INFO - 2024-10-15 09:58:55 --> Output Class Initialized
INFO - 2024-10-15 09:58:55 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:55 --> Input Class Initialized
INFO - 2024-10-15 09:58:55 --> Language Class Initialized
INFO - 2024-10-15 09:58:55 --> Loader Class Initialized
INFO - 2024-10-15 09:58:55 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:55 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:55 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:55 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:55 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:55 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:55 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:56 --> Config Class Initialized
INFO - 2024-10-15 09:58:56 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:56 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:56 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:56 --> URI Class Initialized
INFO - 2024-10-15 09:58:56 --> Router Class Initialized
INFO - 2024-10-15 09:58:56 --> Output Class Initialized
INFO - 2024-10-15 09:58:56 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:56 --> Input Class Initialized
INFO - 2024-10-15 09:58:56 --> Language Class Initialized
INFO - 2024-10-15 09:58:56 --> Loader Class Initialized
INFO - 2024-10-15 09:58:56 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:56 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:56 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:56 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:56 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:56 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:56 --> Database Driver Class Initialized
INFO - 2024-10-15 09:58:57 --> Upload Class Initialized
INFO - 2024-10-15 09:58:57 --> Email Class Initialized
INFO - 2024-10-15 09:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:57 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:57 --> Controller Class Initialized
INFO - 2024-10-15 15:28:57 --> Model "MainModel" initialized
INFO - 2024-10-15 15:28:57 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:28:57 --> Model "HotelAdminModel" initialized
INFO - 2024-10-15 15:28:57 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-15 15:28:57 --> Model "FoodAdminModel" initialized
INFO - 2024-10-15 15:28:57 --> Model "SuperAdminModel" initialized
INFO - 2024-10-15 15:28:57 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:28:57 --> Helper loaded: array_helper
INFO - 2024-10-15 15:28:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-15 15:28:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-15 15:28:57 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-15 15:28:57 --> Final output sent to browser
DEBUG - 2024-10-15 15:28:57 --> Total execution time: 2.1857
INFO - 2024-10-15 09:58:58 --> Upload Class Initialized
INFO - 2024-10-15 09:58:58 --> Email Class Initialized
INFO - 2024-10-15 09:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:58:58 --> Form Validation Class Initialized
INFO - 2024-10-15 09:58:58 --> Controller Class Initialized
INFO - 2024-10-15 09:58:58 --> Config Class Initialized
INFO - 2024-10-15 09:58:58 --> Hooks Class Initialized
INFO - 2024-10-15 15:28:58 --> Model "RoomserviceModel" initialized
DEBUG - 2024-10-15 09:58:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 15:28:58 --> Model "MainModel" initialized
INFO - 2024-10-15 09:58:58 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:58 --> URI Class Initialized
INFO - 2024-10-15 09:58:58 --> Router Class Initialized
INFO - 2024-10-15 09:58:58 --> Output Class Initialized
INFO - 2024-10-15 15:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 09:58:58 --> Security Class Initialized
INFO - 2024-10-15 15:28:58 --> Pagination Class Initialized
DEBUG - 2024-10-15 09:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:58 --> Input Class Initialized
INFO - 2024-10-15 09:58:58 --> Language Class Initialized
ERROR - 2024-10-15 09:58:58 --> 404 Page Not Found: Ajaxgoogleapiscom/ajax
INFO - 2024-10-15 09:58:59 --> Config Class Initialized
INFO - 2024-10-15 09:58:59 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:58:59 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:58:59 --> Utf8 Class Initialized
INFO - 2024-10-15 09:58:59 --> URI Class Initialized
INFO - 2024-10-15 09:58:59 --> Router Class Initialized
INFO - 2024-10-15 09:58:59 --> Output Class Initialized
INFO - 2024-10-15 09:58:59 --> Security Class Initialized
DEBUG - 2024-10-15 09:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:58:59 --> Input Class Initialized
INFO - 2024-10-15 09:58:59 --> Language Class Initialized
INFO - 2024-10-15 09:58:59 --> Loader Class Initialized
INFO - 2024-10-15 09:58:59 --> Helper loaded: url_helper
INFO - 2024-10-15 09:58:59 --> Helper loaded: html_helper
INFO - 2024-10-15 09:58:59 --> Helper loaded: file_helper
INFO - 2024-10-15 09:58:59 --> Helper loaded: string_helper
INFO - 2024-10-15 09:58:59 --> Helper loaded: form_helper
INFO - 2024-10-15 09:58:59 --> Helper loaded: my_helper
INFO - 2024-10-15 09:58:59 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:01 --> Upload Class Initialized
INFO - 2024-10-15 09:59:01 --> Email Class Initialized
INFO - 2024-10-15 09:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:01 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:01 --> Controller Class Initialized
INFO - 2024-10-15 15:29:01 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:29:01 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:01 --> Model "ApiModel" initialized
INFO - 2024-10-15 15:29:01 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:29:01 --> Final output sent to browser
DEBUG - 2024-10-15 15:29:01 --> Total execution time: 2.1248
INFO - 2024-10-15 09:59:04 --> Config Class Initialized
INFO - 2024-10-15 09:59:04 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:04 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:04 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:04 --> URI Class Initialized
INFO - 2024-10-15 09:59:04 --> Router Class Initialized
INFO - 2024-10-15 09:59:04 --> Output Class Initialized
INFO - 2024-10-15 09:59:04 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:04 --> Input Class Initialized
INFO - 2024-10-15 09:59:04 --> Language Class Initialized
INFO - 2024-10-15 09:59:04 --> Loader Class Initialized
INFO - 2024-10-15 09:59:04 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:04 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:04 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:04 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:04 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:04 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:04 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:06 --> Upload Class Initialized
INFO - 2024-10-15 09:59:06 --> Email Class Initialized
INFO - 2024-10-15 09:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:06 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:06 --> Controller Class Initialized
INFO - 2024-10-15 15:29:06 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:29:06 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:29:06 --> Pagination Class Initialized
INFO - 2024-10-15 09:59:06 --> Config Class Initialized
INFO - 2024-10-15 09:59:06 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:06 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:06 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:06 --> URI Class Initialized
INFO - 2024-10-15 09:59:06 --> Router Class Initialized
INFO - 2024-10-15 09:59:06 --> Output Class Initialized
INFO - 2024-10-15 09:59:06 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:06 --> Input Class Initialized
INFO - 2024-10-15 09:59:06 --> Language Class Initialized
INFO - 2024-10-15 09:59:06 --> Loader Class Initialized
INFO - 2024-10-15 09:59:06 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:06 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:06 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:06 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:06 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:06 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:06 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:08 --> Upload Class Initialized
INFO - 2024-10-15 09:59:08 --> Email Class Initialized
INFO - 2024-10-15 09:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:08 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:08 --> Controller Class Initialized
INFO - 2024-10-15 15:29:08 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:29:08 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:29:08 --> Pagination Class Initialized
INFO - 2024-10-15 09:59:08 --> Config Class Initialized
INFO - 2024-10-15 09:59:08 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:08 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:08 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:08 --> URI Class Initialized
INFO - 2024-10-15 09:59:08 --> Router Class Initialized
INFO - 2024-10-15 09:59:09 --> Output Class Initialized
INFO - 2024-10-15 09:59:09 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:09 --> Input Class Initialized
INFO - 2024-10-15 09:59:09 --> Language Class Initialized
INFO - 2024-10-15 09:59:09 --> Loader Class Initialized
INFO - 2024-10-15 09:59:09 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:09 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:09 --> Config Class Initialized
INFO - 2024-10-15 09:59:09 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:09 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:09 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:09 --> URI Class Initialized
INFO - 2024-10-15 09:59:09 --> Router Class Initialized
INFO - 2024-10-15 09:59:09 --> Output Class Initialized
INFO - 2024-10-15 09:59:09 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:09 --> Input Class Initialized
INFO - 2024-10-15 09:59:09 --> Language Class Initialized
INFO - 2024-10-15 09:59:09 --> Loader Class Initialized
INFO - 2024-10-15 09:59:09 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:09 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:09 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:11 --> Upload Class Initialized
INFO - 2024-10-15 09:59:11 --> Email Class Initialized
INFO - 2024-10-15 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:11 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:11 --> Controller Class Initialized
INFO - 2024-10-15 15:29:11 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:11 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:29:11 --> Model "HotelAdminModel" initialized
INFO - 2024-10-15 15:29:11 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-15 15:29:11 --> Model "FoodAdminModel" initialized
INFO - 2024-10-15 15:29:11 --> Model "SuperAdminModel" initialized
INFO - 2024-10-15 15:29:11 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:29:11 --> Helper loaded: array_helper
INFO - 2024-10-15 15:29:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-15 15:29:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-15 15:29:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-15 15:29:11 --> Final output sent to browser
DEBUG - 2024-10-15 15:29:11 --> Total execution time: 2.1603
INFO - 2024-10-15 09:59:11 --> Upload Class Initialized
INFO - 2024-10-15 09:59:11 --> Email Class Initialized
INFO - 2024-10-15 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:11 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:11 --> Controller Class Initialized
INFO - 2024-10-15 15:29:11 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:29:11 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:29:11 --> Pagination Class Initialized
INFO - 2024-10-15 09:59:11 --> Config Class Initialized
INFO - 2024-10-15 09:59:11 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:11 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:11 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:11 --> URI Class Initialized
INFO - 2024-10-15 09:59:11 --> Router Class Initialized
INFO - 2024-10-15 09:59:11 --> Output Class Initialized
INFO - 2024-10-15 09:59:11 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:11 --> Input Class Initialized
INFO - 2024-10-15 09:59:11 --> Language Class Initialized
ERROR - 2024-10-15 09:59:11 --> 404 Page Not Found: Ajaxgoogleapiscom/ajax
INFO - 2024-10-15 09:59:12 --> Config Class Initialized
INFO - 2024-10-15 09:59:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:12 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:12 --> URI Class Initialized
INFO - 2024-10-15 09:59:12 --> Router Class Initialized
INFO - 2024-10-15 09:59:12 --> Output Class Initialized
INFO - 2024-10-15 09:59:12 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:12 --> Input Class Initialized
INFO - 2024-10-15 09:59:12 --> Language Class Initialized
INFO - 2024-10-15 09:59:12 --> Loader Class Initialized
INFO - 2024-10-15 09:59:12 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:12 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:12 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:12 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:12 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:12 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:12 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:14 --> Upload Class Initialized
INFO - 2024-10-15 09:59:14 --> Email Class Initialized
INFO - 2024-10-15 09:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:14 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:14 --> Controller Class Initialized
INFO - 2024-10-15 15:29:14 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:29:14 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:14 --> Model "ApiModel" initialized
INFO - 2024-10-15 15:29:14 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:29:14 --> Final output sent to browser
DEBUG - 2024-10-15 15:29:14 --> Total execution time: 2.1138
INFO - 2024-10-15 09:59:16 --> Config Class Initialized
INFO - 2024-10-15 09:59:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:16 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:16 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:16 --> URI Class Initialized
INFO - 2024-10-15 09:59:16 --> Router Class Initialized
INFO - 2024-10-15 09:59:16 --> Output Class Initialized
INFO - 2024-10-15 09:59:16 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:16 --> Input Class Initialized
INFO - 2024-10-15 09:59:16 --> Language Class Initialized
INFO - 2024-10-15 09:59:16 --> Loader Class Initialized
INFO - 2024-10-15 09:59:16 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:16 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:16 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:16 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:16 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:16 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:16 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:17 --> Config Class Initialized
INFO - 2024-10-15 09:59:17 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:17 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:17 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:17 --> URI Class Initialized
INFO - 2024-10-15 09:59:17 --> Router Class Initialized
INFO - 2024-10-15 09:59:17 --> Output Class Initialized
INFO - 2024-10-15 09:59:17 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:17 --> Input Class Initialized
INFO - 2024-10-15 09:59:17 --> Language Class Initialized
INFO - 2024-10-15 09:59:17 --> Loader Class Initialized
INFO - 2024-10-15 09:59:17 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:17 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:17 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:17 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:17 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:17 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:17 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:18 --> Upload Class Initialized
INFO - 2024-10-15 09:59:18 --> Email Class Initialized
INFO - 2024-10-15 09:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:18 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:18 --> Controller Class Initialized
INFO - 2024-10-15 15:29:18 --> Model "MainModel" initialized
INFO - 2024-10-15 09:59:19 --> Config Class Initialized
INFO - 2024-10-15 09:59:19 --> Hooks Class Initialized
DEBUG - 2024-10-15 09:59:19 --> UTF-8 Support Enabled
INFO - 2024-10-15 09:59:19 --> Utf8 Class Initialized
INFO - 2024-10-15 09:59:19 --> URI Class Initialized
DEBUG - 2024-10-15 09:59:19 --> No URI present. Default controller set.
INFO - 2024-10-15 09:59:19 --> Router Class Initialized
INFO - 2024-10-15 09:59:19 --> Output Class Initialized
INFO - 2024-10-15 09:59:19 --> Security Class Initialized
DEBUG - 2024-10-15 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 09:59:19 --> Input Class Initialized
INFO - 2024-10-15 09:59:19 --> Language Class Initialized
INFO - 2024-10-15 09:59:19 --> Loader Class Initialized
INFO - 2024-10-15 09:59:19 --> Helper loaded: url_helper
INFO - 2024-10-15 09:59:19 --> Helper loaded: html_helper
INFO - 2024-10-15 09:59:19 --> Helper loaded: file_helper
INFO - 2024-10-15 09:59:19 --> Helper loaded: string_helper
INFO - 2024-10-15 09:59:19 --> Helper loaded: form_helper
INFO - 2024-10-15 09:59:19 --> Helper loaded: my_helper
INFO - 2024-10-15 09:59:19 --> Database Driver Class Initialized
INFO - 2024-10-15 09:59:19 --> Upload Class Initialized
INFO - 2024-10-15 09:59:19 --> Email Class Initialized
INFO - 2024-10-15 09:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:19 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:19 --> Controller Class Initialized
INFO - 2024-10-15 15:29:19 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:29:19 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:29:19 --> Pagination Class Initialized
INFO - 2024-10-15 09:59:21 --> Upload Class Initialized
INFO - 2024-10-15 09:59:21 --> Email Class Initialized
INFO - 2024-10-15 09:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 09:59:21 --> Form Validation Class Initialized
INFO - 2024-10-15 09:59:21 --> Controller Class Initialized
INFO - 2024-10-15 15:29:21 --> Model "MainModel" initialized
INFO - 2024-10-15 15:29:21 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:29:21 --> Final output sent to browser
DEBUG - 2024-10-15 15:29:21 --> Total execution time: 2.1431
INFO - 2024-10-15 10:14:28 --> Config Class Initialized
INFO - 2024-10-15 10:14:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:28 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:28 --> URI Class Initialized
DEBUG - 2024-10-15 10:14:28 --> No URI present. Default controller set.
INFO - 2024-10-15 10:14:28 --> Router Class Initialized
INFO - 2024-10-15 10:14:28 --> Output Class Initialized
INFO - 2024-10-15 10:14:28 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:28 --> Input Class Initialized
INFO - 2024-10-15 10:14:28 --> Language Class Initialized
INFO - 2024-10-15 10:14:28 --> Loader Class Initialized
INFO - 2024-10-15 10:14:28 --> Helper loaded: url_helper
INFO - 2024-10-15 10:14:28 --> Helper loaded: html_helper
INFO - 2024-10-15 10:14:28 --> Helper loaded: file_helper
INFO - 2024-10-15 10:14:28 --> Helper loaded: string_helper
INFO - 2024-10-15 10:14:28 --> Helper loaded: form_helper
INFO - 2024-10-15 10:14:28 --> Helper loaded: my_helper
INFO - 2024-10-15 10:14:28 --> Database Driver Class Initialized
INFO - 2024-10-15 10:14:30 --> Upload Class Initialized
INFO - 2024-10-15 10:14:30 --> Email Class Initialized
INFO - 2024-10-15 10:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:14:30 --> Form Validation Class Initialized
INFO - 2024-10-15 10:14:30 --> Controller Class Initialized
INFO - 2024-10-15 15:44:30 --> Model "MainModel" initialized
INFO - 2024-10-15 15:44:30 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:44:30 --> Final output sent to browser
DEBUG - 2024-10-15 15:44:30 --> Total execution time: 2.2999
INFO - 2024-10-15 10:14:33 --> Config Class Initialized
INFO - 2024-10-15 10:14:33 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:33 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:33 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:33 --> URI Class Initialized
DEBUG - 2024-10-15 10:14:33 --> No URI present. Default controller set.
INFO - 2024-10-15 10:14:33 --> Router Class Initialized
INFO - 2024-10-15 10:14:33 --> Output Class Initialized
INFO - 2024-10-15 10:14:33 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:33 --> Input Class Initialized
INFO - 2024-10-15 10:14:33 --> Language Class Initialized
INFO - 2024-10-15 10:14:33 --> Loader Class Initialized
INFO - 2024-10-15 10:14:33 --> Helper loaded: url_helper
INFO - 2024-10-15 10:14:33 --> Helper loaded: html_helper
INFO - 2024-10-15 10:14:33 --> Helper loaded: file_helper
INFO - 2024-10-15 10:14:33 --> Helper loaded: string_helper
INFO - 2024-10-15 10:14:33 --> Helper loaded: form_helper
INFO - 2024-10-15 10:14:33 --> Helper loaded: my_helper
INFO - 2024-10-15 10:14:33 --> Database Driver Class Initialized
INFO - 2024-10-15 10:14:35 --> Upload Class Initialized
INFO - 2024-10-15 10:14:35 --> Email Class Initialized
INFO - 2024-10-15 10:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:14:35 --> Form Validation Class Initialized
INFO - 2024-10-15 10:14:35 --> Controller Class Initialized
INFO - 2024-10-15 15:44:35 --> Model "MainModel" initialized
INFO - 2024-10-15 15:44:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:44:35 --> Final output sent to browser
DEBUG - 2024-10-15 15:44:35 --> Total execution time: 2.1362
INFO - 2024-10-15 10:14:44 --> Config Class Initialized
INFO - 2024-10-15 10:14:44 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:44 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:44 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:44 --> URI Class Initialized
INFO - 2024-10-15 10:14:44 --> Router Class Initialized
INFO - 2024-10-15 10:14:44 --> Output Class Initialized
INFO - 2024-10-15 10:14:44 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:44 --> Input Class Initialized
INFO - 2024-10-15 10:14:44 --> Language Class Initialized
INFO - 2024-10-15 10:14:44 --> Loader Class Initialized
INFO - 2024-10-15 10:14:44 --> Helper loaded: url_helper
INFO - 2024-10-15 10:14:44 --> Helper loaded: html_helper
INFO - 2024-10-15 10:14:44 --> Helper loaded: file_helper
INFO - 2024-10-15 10:14:44 --> Helper loaded: string_helper
INFO - 2024-10-15 10:14:44 --> Helper loaded: form_helper
INFO - 2024-10-15 10:14:44 --> Helper loaded: my_helper
INFO - 2024-10-15 10:14:44 --> Database Driver Class Initialized
INFO - 2024-10-15 10:14:46 --> Upload Class Initialized
INFO - 2024-10-15 10:14:46 --> Email Class Initialized
INFO - 2024-10-15 10:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:14:46 --> Form Validation Class Initialized
INFO - 2024-10-15 10:14:46 --> Controller Class Initialized
INFO - 2024-10-15 15:44:46 --> Model "MainModel" initialized
INFO - 2024-10-15 10:14:47 --> Config Class Initialized
INFO - 2024-10-15 10:14:47 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:47 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:47 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:47 --> URI Class Initialized
INFO - 2024-10-15 10:14:47 --> Router Class Initialized
INFO - 2024-10-15 10:14:47 --> Output Class Initialized
INFO - 2024-10-15 10:14:47 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:47 --> Input Class Initialized
INFO - 2024-10-15 10:14:47 --> Language Class Initialized
INFO - 2024-10-15 10:14:47 --> Loader Class Initialized
INFO - 2024-10-15 10:14:47 --> Helper loaded: url_helper
INFO - 2024-10-15 10:14:47 --> Helper loaded: html_helper
INFO - 2024-10-15 10:14:47 --> Helper loaded: file_helper
INFO - 2024-10-15 10:14:47 --> Helper loaded: string_helper
INFO - 2024-10-15 10:14:47 --> Helper loaded: form_helper
INFO - 2024-10-15 10:14:47 --> Helper loaded: my_helper
INFO - 2024-10-15 10:14:47 --> Database Driver Class Initialized
INFO - 2024-10-15 10:14:49 --> Upload Class Initialized
INFO - 2024-10-15 10:14:49 --> Email Class Initialized
INFO - 2024-10-15 10:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:14:49 --> Form Validation Class Initialized
INFO - 2024-10-15 10:14:49 --> Controller Class Initialized
INFO - 2024-10-15 15:44:49 --> Model "MainModel" initialized
INFO - 2024-10-15 15:44:49 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:44:49 --> Model "HotelAdminModel" initialized
INFO - 2024-10-15 15:44:49 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-15 15:44:49 --> Model "FoodAdminModel" initialized
INFO - 2024-10-15 15:44:49 --> Model "SuperAdminModel" initialized
INFO - 2024-10-15 15:44:49 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:44:49 --> Helper loaded: array_helper
INFO - 2024-10-15 15:44:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-15 15:44:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-15 15:44:49 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-15 15:44:49 --> Final output sent to browser
DEBUG - 2024-10-15 15:44:49 --> Total execution time: 2.2575
INFO - 2024-10-15 10:14:50 --> Config Class Initialized
INFO - 2024-10-15 10:14:50 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:50 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:50 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:50 --> URI Class Initialized
INFO - 2024-10-15 10:14:50 --> Router Class Initialized
INFO - 2024-10-15 10:14:50 --> Output Class Initialized
INFO - 2024-10-15 10:14:50 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:50 --> Input Class Initialized
INFO - 2024-10-15 10:14:50 --> Language Class Initialized
INFO - 2024-10-15 10:14:50 --> Loader Class Initialized
INFO - 2024-10-15 10:14:50 --> Helper loaded: url_helper
INFO - 2024-10-15 10:14:50 --> Helper loaded: html_helper
INFO - 2024-10-15 10:14:50 --> Helper loaded: file_helper
INFO - 2024-10-15 10:14:50 --> Helper loaded: string_helper
INFO - 2024-10-15 10:14:50 --> Helper loaded: form_helper
INFO - 2024-10-15 10:14:50 --> Helper loaded: my_helper
INFO - 2024-10-15 10:14:50 --> Database Driver Class Initialized
INFO - 2024-10-15 10:14:52 --> Upload Class Initialized
INFO - 2024-10-15 10:14:52 --> Email Class Initialized
INFO - 2024-10-15 10:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:14:52 --> Form Validation Class Initialized
INFO - 2024-10-15 10:14:52 --> Controller Class Initialized
INFO - 2024-10-15 15:44:52 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:44:52 --> Model "MainModel" initialized
INFO - 2024-10-15 15:44:52 --> Model "ApiModel" initialized
INFO - 2024-10-15 15:44:52 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:44:52 --> Final output sent to browser
DEBUG - 2024-10-15 15:44:52 --> Total execution time: 2.1717
INFO - 2024-10-15 10:14:55 --> Config Class Initialized
INFO - 2024-10-15 10:14:55 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:55 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:55 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:55 --> URI Class Initialized
INFO - 2024-10-15 10:14:55 --> Router Class Initialized
INFO - 2024-10-15 10:14:55 --> Output Class Initialized
INFO - 2024-10-15 10:14:55 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:55 --> Input Class Initialized
INFO - 2024-10-15 10:14:55 --> Language Class Initialized
INFO - 2024-10-15 10:14:55 --> Loader Class Initialized
INFO - 2024-10-15 10:14:55 --> Helper loaded: url_helper
INFO - 2024-10-15 10:14:55 --> Helper loaded: html_helper
INFO - 2024-10-15 10:14:55 --> Helper loaded: file_helper
INFO - 2024-10-15 10:14:55 --> Helper loaded: string_helper
INFO - 2024-10-15 10:14:55 --> Helper loaded: form_helper
INFO - 2024-10-15 10:14:55 --> Helper loaded: my_helper
INFO - 2024-10-15 10:14:55 --> Database Driver Class Initialized
INFO - 2024-10-15 10:14:56 --> Config Class Initialized
INFO - 2024-10-15 10:14:56 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:56 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:56 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:56 --> URI Class Initialized
INFO - 2024-10-15 10:14:56 --> Router Class Initialized
INFO - 2024-10-15 10:14:56 --> Output Class Initialized
INFO - 2024-10-15 10:14:56 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:56 --> Input Class Initialized
INFO - 2024-10-15 10:14:56 --> Language Class Initialized
INFO - 2024-10-15 10:14:56 --> Loader Class Initialized
INFO - 2024-10-15 10:14:56 --> Helper loaded: url_helper
INFO - 2024-10-15 10:14:56 --> Helper loaded: html_helper
INFO - 2024-10-15 10:14:56 --> Helper loaded: file_helper
INFO - 2024-10-15 10:14:56 --> Helper loaded: string_helper
INFO - 2024-10-15 10:14:56 --> Helper loaded: form_helper
INFO - 2024-10-15 10:14:56 --> Helper loaded: my_helper
INFO - 2024-10-15 10:14:56 --> Database Driver Class Initialized
INFO - 2024-10-15 10:14:57 --> Upload Class Initialized
INFO - 2024-10-15 10:14:57 --> Email Class Initialized
INFO - 2024-10-15 10:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:14:57 --> Form Validation Class Initialized
INFO - 2024-10-15 10:14:57 --> Controller Class Initialized
INFO - 2024-10-15 15:44:57 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:44:57 --> Model "MainModel" initialized
INFO - 2024-10-15 15:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:44:57 --> Pagination Class Initialized
INFO - 2024-10-15 10:14:58 --> Upload Class Initialized
INFO - 2024-10-15 10:14:58 --> Email Class Initialized
INFO - 2024-10-15 10:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:14:58 --> Form Validation Class Initialized
INFO - 2024-10-15 10:14:58 --> Controller Class Initialized
INFO - 2024-10-15 15:44:58 --> Model "MainModel" initialized
INFO - 2024-10-15 15:44:58 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:44:58 --> Model "HotelAdminModel" initialized
INFO - 2024-10-15 15:44:58 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-15 15:44:58 --> Model "FoodAdminModel" initialized
INFO - 2024-10-15 15:44:58 --> Model "SuperAdminModel" initialized
INFO - 2024-10-15 15:44:58 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:44:58 --> Helper loaded: array_helper
INFO - 2024-10-15 15:44:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-15 15:44:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-15 15:44:58 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-15 15:44:58 --> Final output sent to browser
DEBUG - 2024-10-15 15:44:58 --> Total execution time: 2.2226
INFO - 2024-10-15 10:14:58 --> Config Class Initialized
INFO - 2024-10-15 10:14:58 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:14:58 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:14:58 --> Utf8 Class Initialized
INFO - 2024-10-15 10:14:58 --> URI Class Initialized
INFO - 2024-10-15 10:14:59 --> Router Class Initialized
INFO - 2024-10-15 10:14:59 --> Output Class Initialized
INFO - 2024-10-15 10:14:59 --> Security Class Initialized
DEBUG - 2024-10-15 10:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:14:59 --> Input Class Initialized
INFO - 2024-10-15 10:14:59 --> Language Class Initialized
ERROR - 2024-10-15 10:14:59 --> 404 Page Not Found: Ajaxgoogleapiscom/ajax
INFO - 2024-10-15 10:15:00 --> Config Class Initialized
INFO - 2024-10-15 10:15:00 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:15:00 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:15:00 --> Utf8 Class Initialized
INFO - 2024-10-15 10:15:00 --> URI Class Initialized
INFO - 2024-10-15 10:15:00 --> Router Class Initialized
INFO - 2024-10-15 10:15:00 --> Output Class Initialized
INFO - 2024-10-15 10:15:00 --> Security Class Initialized
DEBUG - 2024-10-15 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:15:00 --> Input Class Initialized
INFO - 2024-10-15 10:15:00 --> Language Class Initialized
INFO - 2024-10-15 10:15:00 --> Loader Class Initialized
INFO - 2024-10-15 10:15:00 --> Helper loaded: url_helper
INFO - 2024-10-15 10:15:00 --> Helper loaded: html_helper
INFO - 2024-10-15 10:15:00 --> Helper loaded: file_helper
INFO - 2024-10-15 10:15:00 --> Helper loaded: string_helper
INFO - 2024-10-15 10:15:00 --> Helper loaded: form_helper
INFO - 2024-10-15 10:15:00 --> Helper loaded: my_helper
INFO - 2024-10-15 10:15:00 --> Database Driver Class Initialized
INFO - 2024-10-15 10:15:02 --> Upload Class Initialized
INFO - 2024-10-15 10:15:02 --> Email Class Initialized
INFO - 2024-10-15 10:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:15:02 --> Form Validation Class Initialized
INFO - 2024-10-15 10:15:02 --> Controller Class Initialized
INFO - 2024-10-15 15:45:02 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 15:45:02 --> Model "MainModel" initialized
INFO - 2024-10-15 15:45:02 --> Model "ApiModel" initialized
INFO - 2024-10-15 15:45:02 --> Helper loaded: notification_helper
INFO - 2024-10-15 15:45:02 --> Final output sent to browser
DEBUG - 2024-10-15 15:45:02 --> Total execution time: 2.1859
INFO - 2024-10-15 10:15:05 --> Config Class Initialized
INFO - 2024-10-15 10:15:05 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:15:06 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:15:06 --> Utf8 Class Initialized
INFO - 2024-10-15 10:15:06 --> URI Class Initialized
INFO - 2024-10-15 10:15:06 --> Router Class Initialized
INFO - 2024-10-15 10:15:06 --> Output Class Initialized
INFO - 2024-10-15 10:15:06 --> Security Class Initialized
DEBUG - 2024-10-15 10:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:15:06 --> Input Class Initialized
INFO - 2024-10-15 10:15:06 --> Language Class Initialized
INFO - 2024-10-15 10:15:06 --> Loader Class Initialized
INFO - 2024-10-15 10:15:06 --> Helper loaded: url_helper
INFO - 2024-10-15 10:15:06 --> Helper loaded: html_helper
INFO - 2024-10-15 10:15:06 --> Helper loaded: file_helper
INFO - 2024-10-15 10:15:06 --> Helper loaded: string_helper
INFO - 2024-10-15 10:15:06 --> Helper loaded: form_helper
INFO - 2024-10-15 10:15:06 --> Helper loaded: my_helper
INFO - 2024-10-15 10:15:06 --> Database Driver Class Initialized
INFO - 2024-10-15 10:15:08 --> Upload Class Initialized
INFO - 2024-10-15 10:15:08 --> Email Class Initialized
INFO - 2024-10-15 10:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:15:08 --> Form Validation Class Initialized
INFO - 2024-10-15 10:15:08 --> Controller Class Initialized
INFO - 2024-10-15 15:45:08 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:45:08 --> Model "MainModel" initialized
INFO - 2024-10-15 15:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:45:08 --> Pagination Class Initialized
INFO - 2024-10-15 10:15:10 --> Config Class Initialized
INFO - 2024-10-15 10:15:10 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:15:10 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:15:10 --> Utf8 Class Initialized
INFO - 2024-10-15 10:15:10 --> URI Class Initialized
INFO - 2024-10-15 10:15:10 --> Router Class Initialized
INFO - 2024-10-15 10:15:10 --> Output Class Initialized
INFO - 2024-10-15 10:15:10 --> Security Class Initialized
DEBUG - 2024-10-15 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:15:11 --> Input Class Initialized
INFO - 2024-10-15 10:15:11 --> Language Class Initialized
INFO - 2024-10-15 10:15:11 --> Loader Class Initialized
INFO - 2024-10-15 10:15:11 --> Helper loaded: url_helper
INFO - 2024-10-15 10:15:11 --> Helper loaded: html_helper
INFO - 2024-10-15 10:15:11 --> Helper loaded: file_helper
INFO - 2024-10-15 10:15:11 --> Helper loaded: string_helper
INFO - 2024-10-15 10:15:11 --> Helper loaded: form_helper
INFO - 2024-10-15 10:15:11 --> Helper loaded: my_helper
INFO - 2024-10-15 10:15:11 --> Database Driver Class Initialized
INFO - 2024-10-15 10:15:13 --> Upload Class Initialized
INFO - 2024-10-15 10:15:13 --> Email Class Initialized
INFO - 2024-10-15 10:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:15:13 --> Form Validation Class Initialized
INFO - 2024-10-15 10:15:13 --> Controller Class Initialized
INFO - 2024-10-15 15:45:13 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:45:13 --> Model "MainModel" initialized
INFO - 2024-10-15 15:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:45:13 --> Pagination Class Initialized
INFO - 2024-10-15 10:15:15 --> Config Class Initialized
INFO - 2024-10-15 10:15:15 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:15:15 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:15:15 --> Utf8 Class Initialized
INFO - 2024-10-15 10:15:15 --> URI Class Initialized
INFO - 2024-10-15 10:15:15 --> Router Class Initialized
INFO - 2024-10-15 10:15:15 --> Output Class Initialized
INFO - 2024-10-15 10:15:15 --> Security Class Initialized
DEBUG - 2024-10-15 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:15:15 --> Input Class Initialized
INFO - 2024-10-15 10:15:15 --> Language Class Initialized
INFO - 2024-10-15 10:15:15 --> Loader Class Initialized
INFO - 2024-10-15 10:15:15 --> Helper loaded: url_helper
INFO - 2024-10-15 10:15:15 --> Helper loaded: html_helper
INFO - 2024-10-15 10:15:15 --> Helper loaded: file_helper
INFO - 2024-10-15 10:15:15 --> Helper loaded: string_helper
INFO - 2024-10-15 10:15:15 --> Helper loaded: form_helper
INFO - 2024-10-15 10:15:15 --> Helper loaded: my_helper
INFO - 2024-10-15 10:15:15 --> Database Driver Class Initialized
INFO - 2024-10-15 10:15:17 --> Config Class Initialized
INFO - 2024-10-15 10:15:17 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:15:17 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:15:17 --> Utf8 Class Initialized
INFO - 2024-10-15 10:15:17 --> URI Class Initialized
DEBUG - 2024-10-15 10:15:17 --> No URI present. Default controller set.
INFO - 2024-10-15 10:15:17 --> Router Class Initialized
INFO - 2024-10-15 10:15:17 --> Output Class Initialized
INFO - 2024-10-15 10:15:17 --> Security Class Initialized
DEBUG - 2024-10-15 10:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:15:17 --> Input Class Initialized
INFO - 2024-10-15 10:15:17 --> Language Class Initialized
INFO - 2024-10-15 10:15:17 --> Loader Class Initialized
INFO - 2024-10-15 10:15:17 --> Helper loaded: url_helper
INFO - 2024-10-15 10:15:17 --> Helper loaded: html_helper
INFO - 2024-10-15 10:15:17 --> Helper loaded: file_helper
INFO - 2024-10-15 10:15:17 --> Helper loaded: string_helper
INFO - 2024-10-15 10:15:17 --> Helper loaded: form_helper
INFO - 2024-10-15 10:15:17 --> Helper loaded: my_helper
INFO - 2024-10-15 10:15:17 --> Database Driver Class Initialized
INFO - 2024-10-15 10:15:17 --> Upload Class Initialized
INFO - 2024-10-15 10:15:17 --> Email Class Initialized
INFO - 2024-10-15 10:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:15:17 --> Form Validation Class Initialized
INFO - 2024-10-15 10:15:17 --> Controller Class Initialized
INFO - 2024-10-15 15:45:17 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 15:45:17 --> Model "MainModel" initialized
INFO - 2024-10-15 15:45:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 15:45:17 --> Pagination Class Initialized
INFO - 2024-10-15 10:15:19 --> Upload Class Initialized
INFO - 2024-10-15 10:15:19 --> Email Class Initialized
INFO - 2024-10-15 10:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:15:19 --> Form Validation Class Initialized
INFO - 2024-10-15 10:15:19 --> Controller Class Initialized
INFO - 2024-10-15 15:45:19 --> Model "MainModel" initialized
INFO - 2024-10-15 15:45:19 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 15:45:19 --> Final output sent to browser
DEBUG - 2024-10-15 15:45:19 --> Total execution time: 2.0976
INFO - 2024-10-15 10:35:12 --> Config Class Initialized
INFO - 2024-10-15 10:35:12 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:12 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:12 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:12 --> URI Class Initialized
DEBUG - 2024-10-15 10:35:12 --> No URI present. Default controller set.
INFO - 2024-10-15 10:35:12 --> Router Class Initialized
INFO - 2024-10-15 10:35:12 --> Output Class Initialized
INFO - 2024-10-15 10:35:12 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:12 --> Input Class Initialized
INFO - 2024-10-15 10:35:12 --> Language Class Initialized
INFO - 2024-10-15 10:35:12 --> Loader Class Initialized
INFO - 2024-10-15 10:35:12 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:12 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:12 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:12 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:12 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:12 --> Helper loaded: my_helper
INFO - 2024-10-15 10:35:12 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:14 --> Upload Class Initialized
INFO - 2024-10-15 10:35:14 --> Email Class Initialized
INFO - 2024-10-15 10:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:14 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:14 --> Controller Class Initialized
INFO - 2024-10-15 16:05:14 --> Model "MainModel" initialized
INFO - 2024-10-15 16:05:14 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 16:05:14 --> Final output sent to browser
DEBUG - 2024-10-15 16:05:14 --> Total execution time: 2.1963
INFO - 2024-10-15 10:35:16 --> Config Class Initialized
INFO - 2024-10-15 10:35:16 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:16 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:16 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:16 --> URI Class Initialized
DEBUG - 2024-10-15 10:35:16 --> No URI present. Default controller set.
INFO - 2024-10-15 10:35:16 --> Router Class Initialized
INFO - 2024-10-15 10:35:16 --> Output Class Initialized
INFO - 2024-10-15 10:35:16 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:16 --> Input Class Initialized
INFO - 2024-10-15 10:35:16 --> Language Class Initialized
INFO - 2024-10-15 10:35:16 --> Loader Class Initialized
INFO - 2024-10-15 10:35:16 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:16 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:16 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:16 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:16 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:16 --> Helper loaded: my_helper
INFO - 2024-10-15 10:35:16 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:18 --> Upload Class Initialized
INFO - 2024-10-15 10:35:18 --> Email Class Initialized
INFO - 2024-10-15 10:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:18 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:18 --> Controller Class Initialized
INFO - 2024-10-15 16:05:18 --> Model "MainModel" initialized
INFO - 2024-10-15 16:05:18 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 16:05:18 --> Final output sent to browser
DEBUG - 2024-10-15 16:05:18 --> Total execution time: 2.1705
INFO - 2024-10-15 10:35:26 --> Config Class Initialized
INFO - 2024-10-15 10:35:26 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:26 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:26 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:26 --> URI Class Initialized
INFO - 2024-10-15 10:35:26 --> Router Class Initialized
INFO - 2024-10-15 10:35:26 --> Output Class Initialized
INFO - 2024-10-15 10:35:26 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:26 --> Input Class Initialized
INFO - 2024-10-15 10:35:26 --> Language Class Initialized
INFO - 2024-10-15 10:35:26 --> Loader Class Initialized
INFO - 2024-10-15 10:35:26 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:26 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:26 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:26 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:26 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:26 --> Helper loaded: my_helper
INFO - 2024-10-15 10:35:26 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:28 --> Upload Class Initialized
INFO - 2024-10-15 10:35:28 --> Email Class Initialized
INFO - 2024-10-15 10:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:28 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:28 --> Controller Class Initialized
INFO - 2024-10-15 16:05:28 --> Model "MainModel" initialized
INFO - 2024-10-15 10:35:28 --> Config Class Initialized
INFO - 2024-10-15 10:35:28 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:28 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:28 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:28 --> URI Class Initialized
INFO - 2024-10-15 10:35:28 --> Router Class Initialized
INFO - 2024-10-15 10:35:28 --> Output Class Initialized
INFO - 2024-10-15 10:35:28 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:28 --> Input Class Initialized
INFO - 2024-10-15 10:35:28 --> Language Class Initialized
INFO - 2024-10-15 10:35:28 --> Loader Class Initialized
INFO - 2024-10-15 10:35:28 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:28 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:28 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:28 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:28 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:28 --> Helper loaded: my_helper
INFO - 2024-10-15 10:35:29 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:31 --> Upload Class Initialized
INFO - 2024-10-15 10:35:31 --> Email Class Initialized
INFO - 2024-10-15 10:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:31 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:31 --> Controller Class Initialized
INFO - 2024-10-15 16:05:31 --> Model "MainModel" initialized
INFO - 2024-10-15 16:05:31 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 16:05:31 --> Model "HotelAdminModel" initialized
INFO - 2024-10-15 16:05:31 --> Model "HouseKeepingModel" initialized
INFO - 2024-10-15 16:05:31 --> Model "FoodAdminModel" initialized
INFO - 2024-10-15 16:05:31 --> Model "SuperAdminModel" initialized
INFO - 2024-10-15 16:05:31 --> Helper loaded: notification_helper
INFO - 2024-10-15 16:05:31 --> Helper loaded: array_helper
INFO - 2024-10-15 16:05:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/header.php
INFO - 2024-10-15 16:05:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\page/admindashboard.php
INFO - 2024-10-15 16:05:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\include/footer.php
INFO - 2024-10-15 16:05:31 --> Final output sent to browser
DEBUG - 2024-10-15 16:05:31 --> Total execution time: 2.3435
INFO - 2024-10-15 10:35:31 --> Config Class Initialized
INFO - 2024-10-15 10:35:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:31 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:31 --> URI Class Initialized
INFO - 2024-10-15 10:35:31 --> Router Class Initialized
INFO - 2024-10-15 10:35:31 --> Output Class Initialized
INFO - 2024-10-15 10:35:31 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:31 --> Input Class Initialized
INFO - 2024-10-15 10:35:31 --> Language Class Initialized
ERROR - 2024-10-15 10:35:31 --> 404 Page Not Found: Ajaxgoogleapiscom/ajax
INFO - 2024-10-15 10:35:31 --> Config Class Initialized
INFO - 2024-10-15 10:35:31 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:31 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:31 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:31 --> URI Class Initialized
INFO - 2024-10-15 10:35:31 --> Router Class Initialized
INFO - 2024-10-15 10:35:31 --> Output Class Initialized
INFO - 2024-10-15 10:35:31 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:31 --> Input Class Initialized
INFO - 2024-10-15 10:35:31 --> Language Class Initialized
INFO - 2024-10-15 10:35:31 --> Loader Class Initialized
INFO - 2024-10-15 10:35:31 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:31 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:31 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:31 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:31 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:31 --> Helper loaded: my_helper
INFO - 2024-10-15 10:35:31 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:33 --> Upload Class Initialized
INFO - 2024-10-15 10:35:33 --> Email Class Initialized
INFO - 2024-10-15 10:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:33 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:33 --> Controller Class Initialized
INFO - 2024-10-15 16:05:33 --> Model "FrontofficeModel" initialized
INFO - 2024-10-15 16:05:33 --> Model "MainModel" initialized
INFO - 2024-10-15 16:05:33 --> Model "ApiModel" initialized
INFO - 2024-10-15 16:05:33 --> Helper loaded: notification_helper
INFO - 2024-10-15 16:05:33 --> Final output sent to browser
DEBUG - 2024-10-15 16:05:33 --> Total execution time: 2.1716
INFO - 2024-10-15 10:35:37 --> Config Class Initialized
INFO - 2024-10-15 10:35:37 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:37 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:37 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:37 --> URI Class Initialized
INFO - 2024-10-15 10:35:37 --> Router Class Initialized
INFO - 2024-10-15 10:35:37 --> Output Class Initialized
INFO - 2024-10-15 10:35:37 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:37 --> Input Class Initialized
INFO - 2024-10-15 10:35:37 --> Language Class Initialized
INFO - 2024-10-15 10:35:37 --> Loader Class Initialized
INFO - 2024-10-15 10:35:37 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:37 --> Config Class Initialized
INFO - 2024-10-15 10:35:37 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:37 --> Hooks Class Initialized
INFO - 2024-10-15 10:35:37 --> Helper loaded: my_helper
DEBUG - 2024-10-15 10:35:37 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:37 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:37 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:37 --> URI Class Initialized
INFO - 2024-10-15 10:35:37 --> Router Class Initialized
INFO - 2024-10-15 10:35:37 --> Output Class Initialized
INFO - 2024-10-15 10:35:37 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:37 --> Input Class Initialized
INFO - 2024-10-15 10:35:37 --> Language Class Initialized
INFO - 2024-10-15 10:35:37 --> Loader Class Initialized
INFO - 2024-10-15 10:35:37 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:37 --> Helper loaded: my_helper
INFO - 2024-10-15 10:35:37 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:39 --> Upload Class Initialized
INFO - 2024-10-15 10:35:39 --> Email Class Initialized
INFO - 2024-10-15 10:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:39 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:39 --> Controller Class Initialized
INFO - 2024-10-15 16:05:39 --> Model "MainModel" initialized
INFO - 2024-10-15 10:35:39 --> Config Class Initialized
INFO - 2024-10-15 10:35:39 --> Hooks Class Initialized
DEBUG - 2024-10-15 10:35:39 --> UTF-8 Support Enabled
INFO - 2024-10-15 10:35:39 --> Utf8 Class Initialized
INFO - 2024-10-15 10:35:39 --> URI Class Initialized
DEBUG - 2024-10-15 10:35:39 --> No URI present. Default controller set.
INFO - 2024-10-15 10:35:39 --> Router Class Initialized
INFO - 2024-10-15 10:35:39 --> Output Class Initialized
INFO - 2024-10-15 10:35:39 --> Security Class Initialized
DEBUG - 2024-10-15 10:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 10:35:39 --> Input Class Initialized
INFO - 2024-10-15 10:35:39 --> Language Class Initialized
INFO - 2024-10-15 10:35:39 --> Loader Class Initialized
INFO - 2024-10-15 10:35:39 --> Helper loaded: url_helper
INFO - 2024-10-15 10:35:39 --> Helper loaded: html_helper
INFO - 2024-10-15 10:35:39 --> Helper loaded: file_helper
INFO - 2024-10-15 10:35:39 --> Helper loaded: string_helper
INFO - 2024-10-15 10:35:39 --> Helper loaded: form_helper
INFO - 2024-10-15 10:35:39 --> Helper loaded: my_helper
INFO - 2024-10-15 10:35:39 --> Database Driver Class Initialized
INFO - 2024-10-15 10:35:40 --> Upload Class Initialized
INFO - 2024-10-15 10:35:40 --> Email Class Initialized
INFO - 2024-10-15 10:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:40 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:40 --> Controller Class Initialized
INFO - 2024-10-15 16:05:40 --> Model "RoomserviceModel" initialized
INFO - 2024-10-15 16:05:40 --> Model "MainModel" initialized
INFO - 2024-10-15 16:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2024-10-15 16:05:40 --> Pagination Class Initialized
INFO - 2024-10-15 10:35:41 --> Upload Class Initialized
INFO - 2024-10-15 10:35:41 --> Email Class Initialized
INFO - 2024-10-15 10:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 10:35:41 --> Form Validation Class Initialized
INFO - 2024-10-15 10:35:41 --> Controller Class Initialized
INFO - 2024-10-15 16:05:41 --> Model "MainModel" initialized
INFO - 2024-10-15 16:05:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 16:05:41 --> Final output sent to browser
DEBUG - 2024-10-15 16:05:41 --> Total execution time: 2.1749
INFO - 2024-10-15 11:03:50 --> Config Class Initialized
INFO - 2024-10-15 11:03:50 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:03:50 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:03:50 --> Utf8 Class Initialized
INFO - 2024-10-15 11:03:50 --> URI Class Initialized
INFO - 2024-10-15 11:03:50 --> Router Class Initialized
INFO - 2024-10-15 11:03:50 --> Output Class Initialized
INFO - 2024-10-15 11:03:50 --> Security Class Initialized
DEBUG - 2024-10-15 11:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:03:50 --> Input Class Initialized
INFO - 2024-10-15 11:03:50 --> Language Class Initialized
INFO - 2024-10-15 11:03:50 --> Loader Class Initialized
INFO - 2024-10-15 11:03:50 --> Helper loaded: url_helper
INFO - 2024-10-15 11:03:50 --> Helper loaded: html_helper
INFO - 2024-10-15 11:03:50 --> Helper loaded: file_helper
INFO - 2024-10-15 11:03:50 --> Helper loaded: string_helper
INFO - 2024-10-15 11:03:50 --> Helper loaded: form_helper
INFO - 2024-10-15 11:03:50 --> Helper loaded: my_helper
INFO - 2024-10-15 11:03:50 --> Database Driver Class Initialized
INFO - 2024-10-15 11:03:52 --> Upload Class Initialized
INFO - 2024-10-15 11:03:52 --> Email Class Initialized
INFO - 2024-10-15 11:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:03:52 --> Form Validation Class Initialized
INFO - 2024-10-15 11:03:52 --> Controller Class Initialized
INFO - 2024-10-15 16:33:52 --> Model "MainModel" initialized
INFO - 2024-10-15 11:03:53 --> Config Class Initialized
INFO - 2024-10-15 11:03:53 --> Hooks Class Initialized
DEBUG - 2024-10-15 11:03:53 --> UTF-8 Support Enabled
INFO - 2024-10-15 11:03:53 --> Utf8 Class Initialized
INFO - 2024-10-15 11:03:53 --> URI Class Initialized
DEBUG - 2024-10-15 11:03:53 --> No URI present. Default controller set.
INFO - 2024-10-15 11:03:53 --> Router Class Initialized
INFO - 2024-10-15 11:03:53 --> Output Class Initialized
INFO - 2024-10-15 11:03:53 --> Security Class Initialized
DEBUG - 2024-10-15 11:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-15 11:03:53 --> Input Class Initialized
INFO - 2024-10-15 11:03:53 --> Language Class Initialized
INFO - 2024-10-15 11:03:53 --> Loader Class Initialized
INFO - 2024-10-15 11:03:53 --> Helper loaded: url_helper
INFO - 2024-10-15 11:03:53 --> Helper loaded: html_helper
INFO - 2024-10-15 11:03:53 --> Helper loaded: file_helper
INFO - 2024-10-15 11:03:53 --> Helper loaded: string_helper
INFO - 2024-10-15 11:03:53 --> Helper loaded: form_helper
INFO - 2024-10-15 11:03:53 --> Helper loaded: my_helper
INFO - 2024-10-15 11:03:53 --> Database Driver Class Initialized
INFO - 2024-10-15 11:03:55 --> Upload Class Initialized
INFO - 2024-10-15 11:03:55 --> Email Class Initialized
INFO - 2024-10-15 11:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-15 11:03:55 --> Form Validation Class Initialized
INFO - 2024-10-15 11:03:55 --> Controller Class Initialized
INFO - 2024-10-15 16:33:55 --> Model "MainModel" initialized
INFO - 2024-10-15 16:33:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-15 16:33:55 --> Final output sent to browser
DEBUG - 2024-10-15 16:33:55 --> Total execution time: 2.1396
