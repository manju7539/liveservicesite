<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-31 05:39:44 --> Config Class Initialized
INFO - 2024-12-31 05:39:44 --> Hooks Class Initialized
DEBUG - 2024-12-31 05:39:44 --> UTF-8 Support Enabled
INFO - 2024-12-31 05:39:44 --> Utf8 Class Initialized
INFO - 2024-12-31 05:39:44 --> URI Class Initialized
DEBUG - 2024-12-31 05:39:44 --> No URI present. Default controller set.
INFO - 2024-12-31 05:39:44 --> Router Class Initialized
INFO - 2024-12-31 05:39:44 --> Output Class Initialized
INFO - 2024-12-31 05:39:44 --> Security Class Initialized
DEBUG - 2024-12-31 05:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 05:39:44 --> Input Class Initialized
INFO - 2024-12-31 05:39:44 --> Language Class Initialized
INFO - 2024-12-31 05:39:45 --> Loader Class Initialized
INFO - 2024-12-31 05:39:45 --> Helper loaded: url_helper
INFO - 2024-12-31 05:39:45 --> Helper loaded: html_helper
INFO - 2024-12-31 05:39:45 --> Helper loaded: file_helper
INFO - 2024-12-31 05:39:45 --> Helper loaded: string_helper
INFO - 2024-12-31 05:39:45 --> Helper loaded: form_helper
INFO - 2024-12-31 05:39:45 --> Helper loaded: my_helper
INFO - 2024-12-31 05:39:45 --> Database Driver Class Initialized
INFO - 2024-12-31 05:39:47 --> Upload Class Initialized
INFO - 2024-12-31 05:39:47 --> Email Class Initialized
INFO - 2024-12-31 05:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-31 05:39:47 --> Form Validation Class Initialized
INFO - 2024-12-31 05:39:47 --> Controller Class Initialized
INFO - 2024-12-31 11:09:47 --> Model "MainModel" initialized
INFO - 2024-12-31 11:09:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-31 11:09:47 --> Final output sent to browser
DEBUG - 2024-12-31 11:09:47 --> Total execution time: 2.7306
INFO - 2024-12-31 08:07:54 --> Config Class Initialized
INFO - 2024-12-31 08:07:54 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:07:54 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:07:54 --> Utf8 Class Initialized
INFO - 2024-12-31 08:07:54 --> URI Class Initialized
DEBUG - 2024-12-31 08:07:54 --> No URI present. Default controller set.
INFO - 2024-12-31 08:07:54 --> Router Class Initialized
INFO - 2024-12-31 08:07:54 --> Output Class Initialized
INFO - 2024-12-31 08:07:54 --> Security Class Initialized
DEBUG - 2024-12-31 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:07:54 --> Input Class Initialized
INFO - 2024-12-31 08:07:54 --> Language Class Initialized
INFO - 2024-12-31 08:07:54 --> Loader Class Initialized
INFO - 2024-12-31 08:07:54 --> Helper loaded: url_helper
INFO - 2024-12-31 08:07:54 --> Helper loaded: html_helper
INFO - 2024-12-31 08:07:54 --> Helper loaded: file_helper
INFO - 2024-12-31 08:07:54 --> Helper loaded: string_helper
INFO - 2024-12-31 08:07:54 --> Helper loaded: form_helper
INFO - 2024-12-31 08:07:54 --> Helper loaded: my_helper
INFO - 2024-12-31 08:07:54 --> Database Driver Class Initialized
INFO - 2024-12-31 08:07:56 --> Upload Class Initialized
INFO - 2024-12-31 08:07:56 --> Email Class Initialized
INFO - 2024-12-31 08:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-31 08:07:56 --> Form Validation Class Initialized
INFO - 2024-12-31 08:07:56 --> Controller Class Initialized
INFO - 2024-12-31 13:37:56 --> Model "MainModel" initialized
INFO - 2024-12-31 13:37:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-31 13:37:56 --> Final output sent to browser
DEBUG - 2024-12-31 13:37:56 --> Total execution time: 2.2732
INFO - 2024-12-31 08:07:56 --> Config Class Initialized
INFO - 2024-12-31 08:07:56 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:07:56 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:07:56 --> Utf8 Class Initialized
INFO - 2024-12-31 08:07:56 --> URI Class Initialized
INFO - 2024-12-31 08:07:56 --> Router Class Initialized
INFO - 2024-12-31 08:07:56 --> Output Class Initialized
INFO - 2024-12-31 08:07:56 --> Security Class Initialized
DEBUG - 2024-12-31 08:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:07:56 --> Input Class Initialized
INFO - 2024-12-31 08:07:56 --> Language Class Initialized
ERROR - 2024-12-31 08:07:56 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-31 08:07:56 --> Config Class Initialized
INFO - 2024-12-31 08:07:56 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:07:56 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:07:56 --> Utf8 Class Initialized
INFO - 2024-12-31 08:07:56 --> URI Class Initialized
INFO - 2024-12-31 08:07:56 --> Router Class Initialized
INFO - 2024-12-31 08:07:56 --> Output Class Initialized
INFO - 2024-12-31 08:07:57 --> Security Class Initialized
DEBUG - 2024-12-31 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:07:57 --> Input Class Initialized
INFO - 2024-12-31 08:07:57 --> Language Class Initialized
ERROR - 2024-12-31 08:07:57 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-31 08:07:57 --> Config Class Initialized
INFO - 2024-12-31 08:07:57 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:07:57 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:07:57 --> Utf8 Class Initialized
INFO - 2024-12-31 08:07:57 --> URI Class Initialized
DEBUG - 2024-12-31 08:07:57 --> No URI present. Default controller set.
INFO - 2024-12-31 08:07:57 --> Router Class Initialized
INFO - 2024-12-31 08:07:57 --> Output Class Initialized
INFO - 2024-12-31 08:07:57 --> Security Class Initialized
DEBUG - 2024-12-31 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:07:57 --> Input Class Initialized
INFO - 2024-12-31 08:07:57 --> Language Class Initialized
INFO - 2024-12-31 08:07:57 --> Loader Class Initialized
INFO - 2024-12-31 08:07:57 --> Helper loaded: url_helper
INFO - 2024-12-31 08:07:57 --> Helper loaded: html_helper
INFO - 2024-12-31 08:07:57 --> Helper loaded: file_helper
INFO - 2024-12-31 08:07:57 --> Helper loaded: string_helper
INFO - 2024-12-31 08:07:57 --> Helper loaded: form_helper
INFO - 2024-12-31 08:07:57 --> Helper loaded: my_helper
INFO - 2024-12-31 08:07:57 --> Database Driver Class Initialized
INFO - 2024-12-31 08:07:59 --> Upload Class Initialized
INFO - 2024-12-31 08:07:59 --> Email Class Initialized
INFO - 2024-12-31 08:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-31 08:07:59 --> Form Validation Class Initialized
INFO - 2024-12-31 08:07:59 --> Controller Class Initialized
INFO - 2024-12-31 13:37:59 --> Model "MainModel" initialized
INFO - 2024-12-31 13:37:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-31 13:37:59 --> Final output sent to browser
DEBUG - 2024-12-31 13:37:59 --> Total execution time: 2.1589
INFO - 2024-12-31 08:07:59 --> Config Class Initialized
INFO - 2024-12-31 08:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:07:59 --> Utf8 Class Initialized
INFO - 2024-12-31 08:07:59 --> URI Class Initialized
INFO - 2024-12-31 08:07:59 --> Router Class Initialized
INFO - 2024-12-31 08:07:59 --> Output Class Initialized
INFO - 2024-12-31 08:07:59 --> Security Class Initialized
DEBUG - 2024-12-31 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:07:59 --> Input Class Initialized
INFO - 2024-12-31 08:07:59 --> Language Class Initialized
ERROR - 2024-12-31 08:07:59 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-31 08:07:59 --> Config Class Initialized
INFO - 2024-12-31 08:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:07:59 --> Utf8 Class Initialized
INFO - 2024-12-31 08:07:59 --> URI Class Initialized
INFO - 2024-12-31 08:07:59 --> Router Class Initialized
INFO - 2024-12-31 08:07:59 --> Output Class Initialized
INFO - 2024-12-31 08:07:59 --> Security Class Initialized
DEBUG - 2024-12-31 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:07:59 --> Input Class Initialized
INFO - 2024-12-31 08:07:59 --> Language Class Initialized
ERROR - 2024-12-31 08:07:59 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-31 08:07:59 --> Config Class Initialized
INFO - 2024-12-31 08:07:59 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:07:59 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:07:59 --> Utf8 Class Initialized
INFO - 2024-12-31 08:07:59 --> URI Class Initialized
INFO - 2024-12-31 08:07:59 --> Router Class Initialized
INFO - 2024-12-31 08:07:59 --> Output Class Initialized
INFO - 2024-12-31 08:07:59 --> Security Class Initialized
DEBUG - 2024-12-31 08:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:07:59 --> Input Class Initialized
INFO - 2024-12-31 08:07:59 --> Language Class Initialized
ERROR - 2024-12-31 08:07:59 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-31 08:08:00 --> Config Class Initialized
INFO - 2024-12-31 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:00 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:00 --> URI Class Initialized
INFO - 2024-12-31 08:08:00 --> Router Class Initialized
INFO - 2024-12-31 08:08:00 --> Output Class Initialized
INFO - 2024-12-31 08:08:00 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:00 --> Input Class Initialized
INFO - 2024-12-31 08:08:00 --> Language Class Initialized
ERROR - 2024-12-31 08:08:00 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-31 08:08:00 --> Config Class Initialized
INFO - 2024-12-31 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:00 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:00 --> URI Class Initialized
INFO - 2024-12-31 08:08:00 --> Router Class Initialized
INFO - 2024-12-31 08:08:00 --> Output Class Initialized
INFO - 2024-12-31 08:08:00 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:00 --> Input Class Initialized
INFO - 2024-12-31 08:08:00 --> Language Class Initialized
ERROR - 2024-12-31 08:08:00 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-31 08:08:00 --> Config Class Initialized
INFO - 2024-12-31 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:00 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:00 --> URI Class Initialized
INFO - 2024-12-31 08:08:00 --> Router Class Initialized
INFO - 2024-12-31 08:08:00 --> Output Class Initialized
INFO - 2024-12-31 08:08:00 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:00 --> Input Class Initialized
INFO - 2024-12-31 08:08:00 --> Language Class Initialized
ERROR - 2024-12-31 08:08:00 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-31 08:08:00 --> Config Class Initialized
INFO - 2024-12-31 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:00 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:00 --> URI Class Initialized
INFO - 2024-12-31 08:08:00 --> Router Class Initialized
INFO - 2024-12-31 08:08:00 --> Output Class Initialized
INFO - 2024-12-31 08:08:00 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:00 --> Input Class Initialized
INFO - 2024-12-31 08:08:00 --> Language Class Initialized
ERROR - 2024-12-31 08:08:00 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-31 08:08:00 --> Config Class Initialized
INFO - 2024-12-31 08:08:00 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:00 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:00 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:00 --> URI Class Initialized
INFO - 2024-12-31 08:08:00 --> Router Class Initialized
INFO - 2024-12-31 08:08:00 --> Output Class Initialized
INFO - 2024-12-31 08:08:00 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:00 --> Input Class Initialized
INFO - 2024-12-31 08:08:00 --> Language Class Initialized
ERROR - 2024-12-31 08:08:00 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-31 08:08:01 --> Config Class Initialized
INFO - 2024-12-31 08:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:01 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:01 --> URI Class Initialized
INFO - 2024-12-31 08:08:01 --> Router Class Initialized
INFO - 2024-12-31 08:08:01 --> Output Class Initialized
INFO - 2024-12-31 08:08:01 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:01 --> Input Class Initialized
INFO - 2024-12-31 08:08:01 --> Language Class Initialized
ERROR - 2024-12-31 08:08:01 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-31 08:08:01 --> Config Class Initialized
INFO - 2024-12-31 08:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:01 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:01 --> URI Class Initialized
INFO - 2024-12-31 08:08:01 --> Router Class Initialized
INFO - 2024-12-31 08:08:01 --> Output Class Initialized
INFO - 2024-12-31 08:08:01 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:01 --> Input Class Initialized
INFO - 2024-12-31 08:08:01 --> Language Class Initialized
ERROR - 2024-12-31 08:08:01 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-31 08:08:01 --> Config Class Initialized
INFO - 2024-12-31 08:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:01 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:01 --> URI Class Initialized
INFO - 2024-12-31 08:08:01 --> Router Class Initialized
INFO - 2024-12-31 08:08:01 --> Output Class Initialized
INFO - 2024-12-31 08:08:01 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:01 --> Input Class Initialized
INFO - 2024-12-31 08:08:01 --> Language Class Initialized
ERROR - 2024-12-31 08:08:01 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-31 08:08:01 --> Config Class Initialized
INFO - 2024-12-31 08:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:01 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:01 --> URI Class Initialized
INFO - 2024-12-31 08:08:01 --> Router Class Initialized
INFO - 2024-12-31 08:08:01 --> Output Class Initialized
INFO - 2024-12-31 08:08:01 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:01 --> Input Class Initialized
INFO - 2024-12-31 08:08:01 --> Language Class Initialized
ERROR - 2024-12-31 08:08:01 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-31 08:08:01 --> Config Class Initialized
INFO - 2024-12-31 08:08:01 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:01 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:01 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:01 --> URI Class Initialized
INFO - 2024-12-31 08:08:01 --> Router Class Initialized
INFO - 2024-12-31 08:08:01 --> Output Class Initialized
INFO - 2024-12-31 08:08:01 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:01 --> Input Class Initialized
INFO - 2024-12-31 08:08:01 --> Language Class Initialized
ERROR - 2024-12-31 08:08:01 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-31 08:08:02 --> Config Class Initialized
INFO - 2024-12-31 08:08:02 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:02 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:02 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:02 --> URI Class Initialized
INFO - 2024-12-31 08:08:02 --> Router Class Initialized
INFO - 2024-12-31 08:08:02 --> Output Class Initialized
INFO - 2024-12-31 08:08:02 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:02 --> Input Class Initialized
INFO - 2024-12-31 08:08:02 --> Language Class Initialized
ERROR - 2024-12-31 08:08:02 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-31 08:08:02 --> Config Class Initialized
INFO - 2024-12-31 08:08:02 --> Hooks Class Initialized
DEBUG - 2024-12-31 08:08:02 --> UTF-8 Support Enabled
INFO - 2024-12-31 08:08:02 --> Utf8 Class Initialized
INFO - 2024-12-31 08:08:02 --> URI Class Initialized
INFO - 2024-12-31 08:08:02 --> Router Class Initialized
INFO - 2024-12-31 08:08:02 --> Output Class Initialized
INFO - 2024-12-31 08:08:02 --> Security Class Initialized
DEBUG - 2024-12-31 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-31 08:08:02 --> Input Class Initialized
INFO - 2024-12-31 08:08:02 --> Language Class Initialized
ERROR - 2024-12-31 08:08:02 --> 404 Page Not Found: Sito/wp-includes
