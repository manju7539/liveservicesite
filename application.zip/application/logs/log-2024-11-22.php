<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-22 00:31:20 --> Model "MainModel" initialized
INFO - 2024-11-22 00:31:20 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-22 00:31:20 --> Final output sent to browser
DEBUG - 2024-11-22 00:31:20 --> Total execution time: 2.3709
INFO - 2024-11-22 04:02:05 --> Config Class Initialized
INFO - 2024-11-22 04:02:05 --> Hooks Class Initialized
DEBUG - 2024-11-22 04:02:05 --> UTF-8 Support Enabled
INFO - 2024-11-22 04:02:05 --> Utf8 Class Initialized
INFO - 2024-11-22 04:02:05 --> URI Class Initialized
DEBUG - 2024-11-22 04:02:05 --> No URI present. Default controller set.
INFO - 2024-11-22 04:02:05 --> Router Class Initialized
INFO - 2024-11-22 04:02:05 --> Output Class Initialized
INFO - 2024-11-22 04:02:05 --> Security Class Initialized
DEBUG - 2024-11-22 04:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 04:02:05 --> Input Class Initialized
INFO - 2024-11-22 04:02:05 --> Language Class Initialized
INFO - 2024-11-22 04:02:05 --> Loader Class Initialized
INFO - 2024-11-22 04:02:05 --> Helper loaded: url_helper
INFO - 2024-11-22 04:02:05 --> Helper loaded: html_helper
INFO - 2024-11-22 04:02:05 --> Helper loaded: file_helper
INFO - 2024-11-22 04:02:05 --> Helper loaded: string_helper
INFO - 2024-11-22 04:02:05 --> Helper loaded: form_helper
INFO - 2024-11-22 04:02:05 --> Helper loaded: my_helper
INFO - 2024-11-22 04:02:05 --> Database Driver Class Initialized
INFO - 2024-11-22 04:02:07 --> Upload Class Initialized
INFO - 2024-11-22 04:02:07 --> Email Class Initialized
INFO - 2024-11-22 04:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 04:02:07 --> Form Validation Class Initialized
INFO - 2024-11-22 04:02:07 --> Controller Class Initialized
INFO - 2024-11-22 09:32:08 --> Model "MainModel" initialized
INFO - 2024-11-22 09:32:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-22 09:32:08 --> Final output sent to browser
DEBUG - 2024-11-22 09:32:08 --> Total execution time: 2.8527
INFO - 2024-11-22 17:14:03 --> Config Class Initialized
INFO - 2024-11-22 17:14:03 --> Hooks Class Initialized
DEBUG - 2024-11-22 17:14:03 --> UTF-8 Support Enabled
INFO - 2024-11-22 17:14:03 --> Utf8 Class Initialized
INFO - 2024-11-22 17:14:03 --> URI Class Initialized
INFO - 2024-11-22 17:14:03 --> Router Class Initialized
INFO - 2024-11-22 17:14:03 --> Output Class Initialized
INFO - 2024-11-22 17:14:03 --> Security Class Initialized
DEBUG - 2024-11-22 17:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 17:14:03 --> Input Class Initialized
INFO - 2024-11-22 17:14:03 --> Language Class Initialized
INFO - 2024-11-22 17:14:04 --> Loader Class Initialized
INFO - 2024-11-22 17:14:04 --> Helper loaded: url_helper
INFO - 2024-11-22 17:14:04 --> Helper loaded: html_helper
INFO - 2024-11-22 17:14:04 --> Helper loaded: file_helper
INFO - 2024-11-22 17:14:04 --> Helper loaded: string_helper
INFO - 2024-11-22 17:14:04 --> Helper loaded: form_helper
INFO - 2024-11-22 17:14:04 --> Helper loaded: my_helper
INFO - 2024-11-22 17:14:04 --> Database Driver Class Initialized
INFO - 2024-11-22 17:14:06 --> Upload Class Initialized
INFO - 2024-11-22 17:14:06 --> Email Class Initialized
INFO - 2024-11-22 17:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 17:14:06 --> Form Validation Class Initialized
INFO - 2024-11-22 17:14:06 --> Controller Class Initialized
INFO - 2024-11-22 22:44:06 --> Model "HotelAdminModel" initialized
INFO - 2024-11-22 22:44:06 --> Model "FrontofficeModel" initialized
INFO - 2024-11-22 22:44:06 --> Model "FoodAdminModel" initialized
INFO - 2024-11-22 22:44:06 --> Model "MainModel" initialized
INFO - 2024-11-22 22:44:06 --> Helper loaded: notification_helper
INFO - 2024-11-22 17:14:06 --> Config Class Initialized
INFO - 2024-11-22 17:14:06 --> Hooks Class Initialized
DEBUG - 2024-11-22 17:14:06 --> UTF-8 Support Enabled
INFO - 2024-11-22 17:14:06 --> Utf8 Class Initialized
INFO - 2024-11-22 17:14:06 --> URI Class Initialized
DEBUG - 2024-11-22 17:14:07 --> No URI present. Default controller set.
INFO - 2024-11-22 17:14:07 --> Router Class Initialized
INFO - 2024-11-22 17:14:07 --> Output Class Initialized
INFO - 2024-11-22 17:14:07 --> Security Class Initialized
DEBUG - 2024-11-22 17:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 17:14:07 --> Input Class Initialized
INFO - 2024-11-22 17:14:07 --> Language Class Initialized
INFO - 2024-11-22 17:14:07 --> Loader Class Initialized
INFO - 2024-11-22 17:14:07 --> Helper loaded: url_helper
INFO - 2024-11-22 17:14:07 --> Helper loaded: html_helper
INFO - 2024-11-22 17:14:07 --> Helper loaded: file_helper
INFO - 2024-11-22 17:14:07 --> Helper loaded: string_helper
INFO - 2024-11-22 17:14:07 --> Helper loaded: form_helper
INFO - 2024-11-22 17:14:07 --> Helper loaded: my_helper
INFO - 2024-11-22 17:14:07 --> Database Driver Class Initialized
INFO - 2024-11-22 17:14:07 --> Config Class Initialized
INFO - 2024-11-22 17:14:07 --> Hooks Class Initialized
DEBUG - 2024-11-22 17:14:07 --> UTF-8 Support Enabled
INFO - 2024-11-22 17:14:07 --> Utf8 Class Initialized
INFO - 2024-11-22 17:14:07 --> URI Class Initialized
INFO - 2024-11-22 17:14:07 --> Router Class Initialized
INFO - 2024-11-22 17:14:07 --> Output Class Initialized
INFO - 2024-11-22 17:14:07 --> Security Class Initialized
DEBUG - 2024-11-22 17:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 17:14:07 --> Input Class Initialized
INFO - 2024-11-22 17:14:07 --> Language Class Initialized
ERROR - 2024-11-22 17:14:07 --> 404 Page Not Found: Faviconico/index
INFO - 2024-11-22 17:14:09 --> Upload Class Initialized
INFO - 2024-11-22 17:14:09 --> Email Class Initialized
INFO - 2024-11-22 17:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 17:14:09 --> Form Validation Class Initialized
INFO - 2024-11-22 17:14:09 --> Controller Class Initialized
INFO - 2024-11-22 22:44:09 --> Model "MainModel" initialized
INFO - 2024-11-22 22:44:09 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-22 22:44:09 --> Final output sent to browser
DEBUG - 2024-11-22 22:44:09 --> Total execution time: 2.2329
INFO - 2024-11-22 17:38:09 --> Config Class Initialized
INFO - 2024-11-22 17:38:09 --> Hooks Class Initialized
DEBUG - 2024-11-22 17:38:09 --> UTF-8 Support Enabled
INFO - 2024-11-22 17:38:09 --> Utf8 Class Initialized
INFO - 2024-11-22 17:38:09 --> URI Class Initialized
DEBUG - 2024-11-22 17:38:09 --> No URI present. Default controller set.
INFO - 2024-11-22 17:38:09 --> Router Class Initialized
INFO - 2024-11-22 17:38:09 --> Output Class Initialized
INFO - 2024-11-22 17:38:09 --> Security Class Initialized
DEBUG - 2024-11-22 17:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 17:38:09 --> Input Class Initialized
INFO - 2024-11-22 17:38:09 --> Language Class Initialized
INFO - 2024-11-22 17:38:09 --> Loader Class Initialized
INFO - 2024-11-22 17:38:09 --> Helper loaded: url_helper
INFO - 2024-11-22 17:38:09 --> Helper loaded: html_helper
INFO - 2024-11-22 17:38:09 --> Helper loaded: file_helper
INFO - 2024-11-22 17:38:09 --> Helper loaded: string_helper
INFO - 2024-11-22 17:38:09 --> Helper loaded: form_helper
INFO - 2024-11-22 17:38:09 --> Helper loaded: my_helper
INFO - 2024-11-22 17:38:09 --> Database Driver Class Initialized
INFO - 2024-11-22 17:38:11 --> Upload Class Initialized
INFO - 2024-11-22 17:38:11 --> Email Class Initialized
INFO - 2024-11-22 17:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 17:38:11 --> Form Validation Class Initialized
INFO - 2024-11-22 17:38:11 --> Controller Class Initialized
INFO - 2024-11-22 23:08:11 --> Model "MainModel" initialized
INFO - 2024-11-22 23:08:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-11-22 23:08:11 --> Final output sent to browser
DEBUG - 2024-11-22 23:08:11 --> Total execution time: 2.1957
