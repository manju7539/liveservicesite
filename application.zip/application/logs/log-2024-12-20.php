<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-20 00:08:30 --> Config Class Initialized
INFO - 2024-12-20 00:08:30 --> Hooks Class Initialized
DEBUG - 2024-12-20 00:08:30 --> UTF-8 Support Enabled
INFO - 2024-12-20 00:08:30 --> Utf8 Class Initialized
INFO - 2024-12-20 00:08:30 --> URI Class Initialized
DEBUG - 2024-12-20 00:08:30 --> No URI present. Default controller set.
INFO - 2024-12-20 00:08:30 --> Router Class Initialized
INFO - 2024-12-20 00:08:30 --> Output Class Initialized
INFO - 2024-12-20 00:08:30 --> Security Class Initialized
DEBUG - 2024-12-20 00:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 00:08:30 --> Input Class Initialized
INFO - 2024-12-20 00:08:30 --> Language Class Initialized
INFO - 2024-12-20 00:08:30 --> Loader Class Initialized
INFO - 2024-12-20 00:08:30 --> Helper loaded: url_helper
INFO - 2024-12-20 00:08:30 --> Helper loaded: html_helper
INFO - 2024-12-20 00:08:30 --> Helper loaded: file_helper
INFO - 2024-12-20 00:08:30 --> Helper loaded: string_helper
INFO - 2024-12-20 00:08:30 --> Helper loaded: form_helper
INFO - 2024-12-20 00:08:30 --> Helper loaded: my_helper
INFO - 2024-12-20 00:08:30 --> Database Driver Class Initialized
INFO - 2024-12-20 00:08:32 --> Upload Class Initialized
INFO - 2024-12-20 00:08:32 --> Email Class Initialized
INFO - 2024-12-20 00:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 00:08:32 --> Form Validation Class Initialized
INFO - 2024-12-20 00:08:32 --> Controller Class Initialized
INFO - 2024-12-20 05:38:32 --> Model "MainModel" initialized
INFO - 2024-12-20 05:38:32 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-20 05:38:32 --> Final output sent to browser
DEBUG - 2024-12-20 05:38:32 --> Total execution time: 2.8287
INFO - 2024-12-20 00:08:33 --> Config Class Initialized
INFO - 2024-12-20 00:08:33 --> Hooks Class Initialized
DEBUG - 2024-12-20 00:08:33 --> UTF-8 Support Enabled
INFO - 2024-12-20 00:08:33 --> Utf8 Class Initialized
INFO - 2024-12-20 00:08:33 --> URI Class Initialized
DEBUG - 2024-12-20 00:08:33 --> No URI present. Default controller set.
INFO - 2024-12-20 00:08:33 --> Router Class Initialized
INFO - 2024-12-20 00:08:33 --> Output Class Initialized
INFO - 2024-12-20 00:08:33 --> Security Class Initialized
DEBUG - 2024-12-20 00:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 00:08:33 --> Input Class Initialized
INFO - 2024-12-20 00:08:33 --> Language Class Initialized
INFO - 2024-12-20 00:08:33 --> Loader Class Initialized
INFO - 2024-12-20 00:08:33 --> Helper loaded: url_helper
INFO - 2024-12-20 00:08:33 --> Helper loaded: html_helper
INFO - 2024-12-20 00:08:33 --> Helper loaded: file_helper
INFO - 2024-12-20 00:08:33 --> Helper loaded: string_helper
INFO - 2024-12-20 00:08:33 --> Helper loaded: form_helper
INFO - 2024-12-20 00:08:33 --> Helper loaded: my_helper
INFO - 2024-12-20 00:08:33 --> Database Driver Class Initialized
INFO - 2024-12-20 00:08:35 --> Upload Class Initialized
INFO - 2024-12-20 00:08:35 --> Email Class Initialized
INFO - 2024-12-20 00:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 00:08:35 --> Form Validation Class Initialized
INFO - 2024-12-20 00:08:35 --> Controller Class Initialized
INFO - 2024-12-20 05:38:35 --> Model "MainModel" initialized
INFO - 2024-12-20 05:38:35 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-20 05:38:35 --> Final output sent to browser
DEBUG - 2024-12-20 05:38:35 --> Total execution time: 2.1699
INFO - 2024-12-20 06:59:38 --> Config Class Initialized
INFO - 2024-12-20 06:59:38 --> Config Class Initialized
INFO - 2024-12-20 06:59:38 --> Hooks Class Initialized
INFO - 2024-12-20 06:59:38 --> Hooks Class Initialized
DEBUG - 2024-12-20 06:59:38 --> UTF-8 Support Enabled
DEBUG - 2024-12-20 06:59:38 --> UTF-8 Support Enabled
INFO - 2024-12-20 06:59:38 --> Utf8 Class Initialized
INFO - 2024-12-20 06:59:38 --> Utf8 Class Initialized
INFO - 2024-12-20 06:59:38 --> URI Class Initialized
INFO - 2024-12-20 06:59:38 --> URI Class Initialized
DEBUG - 2024-12-20 06:59:38 --> No URI present. Default controller set.
INFO - 2024-12-20 06:59:38 --> Router Class Initialized
DEBUG - 2024-12-20 06:59:38 --> No URI present. Default controller set.
INFO - 2024-12-20 06:59:38 --> Router Class Initialized
INFO - 2024-12-20 06:59:38 --> Output Class Initialized
INFO - 2024-12-20 06:59:38 --> Output Class Initialized
INFO - 2024-12-20 06:59:38 --> Security Class Initialized
INFO - 2024-12-20 06:59:38 --> Security Class Initialized
DEBUG - 2024-12-20 06:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-12-20 06:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 06:59:38 --> Input Class Initialized
INFO - 2024-12-20 06:59:38 --> Input Class Initialized
INFO - 2024-12-20 06:59:38 --> Language Class Initialized
INFO - 2024-12-20 06:59:38 --> Language Class Initialized
INFO - 2024-12-20 06:59:38 --> Loader Class Initialized
INFO - 2024-12-20 06:59:38 --> Loader Class Initialized
INFO - 2024-12-20 06:59:38 --> Helper loaded: url_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: url_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: html_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: html_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: file_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: file_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: string_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: string_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: form_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: form_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: my_helper
INFO - 2024-12-20 06:59:38 --> Helper loaded: my_helper
INFO - 2024-12-20 06:59:38 --> Database Driver Class Initialized
INFO - 2024-12-20 06:59:38 --> Database Driver Class Initialized
INFO - 2024-12-20 06:59:40 --> Upload Class Initialized
INFO - 2024-12-20 06:59:40 --> Upload Class Initialized
INFO - 2024-12-20 06:59:40 --> Email Class Initialized
INFO - 2024-12-20 06:59:40 --> Email Class Initialized
INFO - 2024-12-20 06:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 06:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 06:59:41 --> Form Validation Class Initialized
INFO - 2024-12-20 06:59:41 --> Form Validation Class Initialized
INFO - 2024-12-20 06:59:41 --> Controller Class Initialized
INFO - 2024-12-20 06:59:41 --> Controller Class Initialized
INFO - 2024-12-20 12:29:41 --> Model "MainModel" initialized
INFO - 2024-12-20 12:29:41 --> Model "MainModel" initialized
INFO - 2024-12-20 12:29:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-20 12:29:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-20 12:29:41 --> Final output sent to browser
INFO - 2024-12-20 12:29:41 --> Final output sent to browser
DEBUG - 2024-12-20 12:29:41 --> Total execution time: 3.0264
DEBUG - 2024-12-20 12:29:41 --> Total execution time: 3.0265
INFO - 2024-12-20 07:34:49 --> Config Class Initialized
INFO - 2024-12-20 07:34:49 --> Hooks Class Initialized
DEBUG - 2024-12-20 07:34:50 --> UTF-8 Support Enabled
INFO - 2024-12-20 07:34:50 --> Utf8 Class Initialized
INFO - 2024-12-20 07:34:50 --> URI Class Initialized
INFO - 2024-12-20 07:34:50 --> Router Class Initialized
INFO - 2024-12-20 07:34:50 --> Output Class Initialized
INFO - 2024-12-20 07:34:50 --> Security Class Initialized
DEBUG - 2024-12-20 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 07:34:50 --> Input Class Initialized
INFO - 2024-12-20 07:34:50 --> Language Class Initialized
ERROR - 2024-12-20 07:34:50 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-12-20 08:30:15 --> Config Class Initialized
INFO - 2024-12-20 08:30:15 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:30:16 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:30:16 --> Utf8 Class Initialized
INFO - 2024-12-20 08:30:16 --> URI Class Initialized
DEBUG - 2024-12-20 08:30:16 --> No URI present. Default controller set.
INFO - 2024-12-20 08:30:17 --> Router Class Initialized
INFO - 2024-12-20 08:30:17 --> Output Class Initialized
INFO - 2024-12-20 08:30:18 --> Security Class Initialized
DEBUG - 2024-12-20 08:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:30:28 --> Input Class Initialized
INFO - 2024-12-20 08:30:29 --> Language Class Initialized
INFO - 2024-12-20 08:30:35 --> Loader Class Initialized
INFO - 2024-12-20 08:30:37 --> Helper loaded: url_helper
INFO - 2024-12-20 08:30:41 --> Helper loaded: html_helper
INFO - 2024-12-20 08:30:51 --> Helper loaded: file_helper
INFO - 2024-12-20 08:30:53 --> Helper loaded: string_helper
INFO - 2024-12-20 08:30:55 --> Helper loaded: form_helper
INFO - 2024-12-20 08:30:56 --> Helper loaded: my_helper
INFO - 2024-12-20 08:30:58 --> Database Driver Class Initialized
INFO - 2024-12-20 08:31:00 --> Upload Class Initialized
INFO - 2024-12-20 08:31:05 --> Email Class Initialized
INFO - 2024-12-20 08:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 08:31:08 --> Form Validation Class Initialized
INFO - 2024-12-20 08:31:08 --> Controller Class Initialized
INFO - 2024-12-20 14:01:08 --> Model "MainModel" initialized
INFO - 2024-12-20 14:01:08 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-20 14:01:09 --> Final output sent to browser
DEBUG - 2024-12-20 14:01:09 --> Total execution time: 53.5226
INFO - 2024-12-20 08:31:09 --> Config Class Initialized
INFO - 2024-12-20 08:31:09 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:09 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:09 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:09 --> URI Class Initialized
INFO - 2024-12-20 08:31:09 --> Router Class Initialized
INFO - 2024-12-20 08:31:09 --> Output Class Initialized
INFO - 2024-12-20 08:31:09 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:09 --> Input Class Initialized
INFO - 2024-12-20 08:31:09 --> Language Class Initialized
ERROR - 2024-12-20 08:31:09 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-12-20 08:31:10 --> Config Class Initialized
INFO - 2024-12-20 08:31:10 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:10 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:10 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:10 --> URI Class Initialized
INFO - 2024-12-20 08:31:10 --> Router Class Initialized
INFO - 2024-12-20 08:31:10 --> Output Class Initialized
INFO - 2024-12-20 08:31:10 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:10 --> Input Class Initialized
INFO - 2024-12-20 08:31:10 --> Language Class Initialized
ERROR - 2024-12-20 08:31:10 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-12-20 08:31:10 --> Config Class Initialized
INFO - 2024-12-20 08:31:10 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:10 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:10 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:10 --> URI Class Initialized
DEBUG - 2024-12-20 08:31:10 --> No URI present. Default controller set.
INFO - 2024-12-20 08:31:10 --> Router Class Initialized
INFO - 2024-12-20 08:31:10 --> Output Class Initialized
INFO - 2024-12-20 08:31:10 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:10 --> Input Class Initialized
INFO - 2024-12-20 08:31:10 --> Language Class Initialized
INFO - 2024-12-20 08:31:10 --> Loader Class Initialized
INFO - 2024-12-20 08:31:10 --> Helper loaded: url_helper
INFO - 2024-12-20 08:31:10 --> Helper loaded: html_helper
INFO - 2024-12-20 08:31:10 --> Helper loaded: file_helper
INFO - 2024-12-20 08:31:10 --> Helper loaded: string_helper
INFO - 2024-12-20 08:31:10 --> Helper loaded: form_helper
INFO - 2024-12-20 08:31:10 --> Helper loaded: my_helper
INFO - 2024-12-20 08:31:10 --> Database Driver Class Initialized
INFO - 2024-12-20 08:31:12 --> Upload Class Initialized
INFO - 2024-12-20 08:31:12 --> Email Class Initialized
INFO - 2024-12-20 08:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-20 08:31:13 --> Form Validation Class Initialized
INFO - 2024-12-20 08:31:13 --> Controller Class Initialized
INFO - 2024-12-20 14:01:13 --> Model "MainModel" initialized
INFO - 2024-12-20 14:01:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-12-20 14:01:13 --> Final output sent to browser
DEBUG - 2024-12-20 14:01:13 --> Total execution time: 3.1768
INFO - 2024-12-20 08:31:16 --> Config Class Initialized
INFO - 2024-12-20 08:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:16 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:16 --> URI Class Initialized
INFO - 2024-12-20 08:31:16 --> Router Class Initialized
INFO - 2024-12-20 08:31:16 --> Output Class Initialized
INFO - 2024-12-20 08:31:16 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:16 --> Input Class Initialized
INFO - 2024-12-20 08:31:16 --> Language Class Initialized
ERROR - 2024-12-20 08:31:16 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-12-20 08:31:16 --> Config Class Initialized
INFO - 2024-12-20 08:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:17 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:17 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:17 --> URI Class Initialized
INFO - 2024-12-20 08:31:17 --> Router Class Initialized
INFO - 2024-12-20 08:31:17 --> Output Class Initialized
INFO - 2024-12-20 08:31:17 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:17 --> Input Class Initialized
INFO - 2024-12-20 08:31:17 --> Language Class Initialized
ERROR - 2024-12-20 08:31:17 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-12-20 08:31:18 --> Config Class Initialized
INFO - 2024-12-20 08:31:18 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:18 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:18 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:18 --> URI Class Initialized
INFO - 2024-12-20 08:31:18 --> Router Class Initialized
INFO - 2024-12-20 08:31:18 --> Output Class Initialized
INFO - 2024-12-20 08:31:18 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:18 --> Input Class Initialized
INFO - 2024-12-20 08:31:18 --> Language Class Initialized
ERROR - 2024-12-20 08:31:18 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-12-20 08:31:19 --> Config Class Initialized
INFO - 2024-12-20 08:31:19 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:19 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:19 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:19 --> URI Class Initialized
INFO - 2024-12-20 08:31:19 --> Router Class Initialized
INFO - 2024-12-20 08:31:19 --> Output Class Initialized
INFO - 2024-12-20 08:31:19 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:19 --> Input Class Initialized
INFO - 2024-12-20 08:31:19 --> Language Class Initialized
ERROR - 2024-12-20 08:31:19 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-12-20 08:31:20 --> Config Class Initialized
INFO - 2024-12-20 08:31:20 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:20 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:20 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:20 --> URI Class Initialized
INFO - 2024-12-20 08:31:20 --> Router Class Initialized
INFO - 2024-12-20 08:31:20 --> Output Class Initialized
INFO - 2024-12-20 08:31:20 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:20 --> Input Class Initialized
INFO - 2024-12-20 08:31:20 --> Language Class Initialized
ERROR - 2024-12-20 08:31:20 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-12-20 08:31:20 --> Config Class Initialized
INFO - 2024-12-20 08:31:20 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:20 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:20 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:20 --> URI Class Initialized
INFO - 2024-12-20 08:31:20 --> Router Class Initialized
INFO - 2024-12-20 08:31:20 --> Output Class Initialized
INFO - 2024-12-20 08:31:20 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:20 --> Input Class Initialized
INFO - 2024-12-20 08:31:20 --> Language Class Initialized
ERROR - 2024-12-20 08:31:20 --> 404 Page Not Found: News/wp-includes
INFO - 2024-12-20 08:31:21 --> Config Class Initialized
INFO - 2024-12-20 08:31:21 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:21 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:21 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:21 --> URI Class Initialized
INFO - 2024-12-20 08:31:21 --> Router Class Initialized
INFO - 2024-12-20 08:31:21 --> Output Class Initialized
INFO - 2024-12-20 08:31:21 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:21 --> Input Class Initialized
INFO - 2024-12-20 08:31:21 --> Language Class Initialized
ERROR - 2024-12-20 08:31:21 --> 404 Page Not Found: 2020/wp-includes
INFO - 2024-12-20 08:31:21 --> Config Class Initialized
INFO - 2024-12-20 08:31:21 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:21 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:21 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:21 --> URI Class Initialized
INFO - 2024-12-20 08:31:21 --> Router Class Initialized
INFO - 2024-12-20 08:31:21 --> Output Class Initialized
INFO - 2024-12-20 08:31:21 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:21 --> Input Class Initialized
INFO - 2024-12-20 08:31:21 --> Language Class Initialized
ERROR - 2024-12-20 08:31:21 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-12-20 08:31:21 --> Config Class Initialized
INFO - 2024-12-20 08:31:21 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:21 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:21 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:21 --> URI Class Initialized
INFO - 2024-12-20 08:31:22 --> Router Class Initialized
INFO - 2024-12-20 08:31:22 --> Output Class Initialized
INFO - 2024-12-20 08:31:22 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:22 --> Input Class Initialized
INFO - 2024-12-20 08:31:22 --> Language Class Initialized
ERROR - 2024-12-20 08:31:22 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-12-20 08:31:23 --> Config Class Initialized
INFO - 2024-12-20 08:31:23 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:23 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:23 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:23 --> URI Class Initialized
INFO - 2024-12-20 08:31:23 --> Router Class Initialized
INFO - 2024-12-20 08:31:23 --> Output Class Initialized
INFO - 2024-12-20 08:31:23 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:23 --> Input Class Initialized
INFO - 2024-12-20 08:31:23 --> Language Class Initialized
ERROR - 2024-12-20 08:31:23 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-12-20 08:31:23 --> Config Class Initialized
INFO - 2024-12-20 08:31:23 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:23 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:23 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:23 --> URI Class Initialized
INFO - 2024-12-20 08:31:23 --> Router Class Initialized
INFO - 2024-12-20 08:31:23 --> Output Class Initialized
INFO - 2024-12-20 08:31:23 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:23 --> Input Class Initialized
INFO - 2024-12-20 08:31:23 --> Language Class Initialized
ERROR - 2024-12-20 08:31:23 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-12-20 08:31:24 --> Config Class Initialized
INFO - 2024-12-20 08:31:24 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:24 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:24 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:24 --> URI Class Initialized
INFO - 2024-12-20 08:31:24 --> Router Class Initialized
INFO - 2024-12-20 08:31:24 --> Output Class Initialized
INFO - 2024-12-20 08:31:24 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:24 --> Input Class Initialized
INFO - 2024-12-20 08:31:24 --> Language Class Initialized
ERROR - 2024-12-20 08:31:24 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-12-20 08:31:24 --> Config Class Initialized
INFO - 2024-12-20 08:31:24 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:24 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:24 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:24 --> URI Class Initialized
INFO - 2024-12-20 08:31:24 --> Router Class Initialized
INFO - 2024-12-20 08:31:24 --> Output Class Initialized
INFO - 2024-12-20 08:31:24 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:24 --> Input Class Initialized
INFO - 2024-12-20 08:31:24 --> Language Class Initialized
ERROR - 2024-12-20 08:31:24 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-12-20 08:31:24 --> Config Class Initialized
INFO - 2024-12-20 08:31:24 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:24 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:24 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:24 --> URI Class Initialized
INFO - 2024-12-20 08:31:25 --> Router Class Initialized
INFO - 2024-12-20 08:31:25 --> Output Class Initialized
INFO - 2024-12-20 08:31:25 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:25 --> Input Class Initialized
INFO - 2024-12-20 08:31:25 --> Language Class Initialized
ERROR - 2024-12-20 08:31:25 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-12-20 08:31:25 --> Config Class Initialized
INFO - 2024-12-20 08:31:25 --> Hooks Class Initialized
DEBUG - 2024-12-20 08:31:25 --> UTF-8 Support Enabled
INFO - 2024-12-20 08:31:25 --> Utf8 Class Initialized
INFO - 2024-12-20 08:31:25 --> URI Class Initialized
INFO - 2024-12-20 08:31:25 --> Router Class Initialized
INFO - 2024-12-20 08:31:25 --> Output Class Initialized
INFO - 2024-12-20 08:31:25 --> Security Class Initialized
DEBUG - 2024-12-20 08:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-20 08:31:25 --> Input Class Initialized
INFO - 2024-12-20 08:31:25 --> Language Class Initialized
ERROR - 2024-12-20 08:31:25 --> 404 Page Not Found: Sito/wp-includes
