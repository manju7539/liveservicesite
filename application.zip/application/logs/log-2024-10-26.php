<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-26 00:58:28 --> Model "MainModel" initialized
INFO - 2024-10-26 00:58:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 00:58:28 --> Final output sent to browser
DEBUG - 2024-10-26 00:58:28 --> Total execution time: 2.2849
INFO - 2024-10-26 00:58:33 --> Model "MainModel" initialized
INFO - 2024-10-26 00:58:33 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 00:58:33 --> Final output sent to browser
DEBUG - 2024-10-26 00:58:33 --> Total execution time: 2.1350
INFO - 2024-10-26 00:58:47 --> Model "MainModel" initialized
INFO - 2024-10-26 00:58:47 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 00:58:47 --> Final output sent to browser
DEBUG - 2024-10-26 00:58:47 --> Total execution time: 2.1583
INFO - 2024-10-26 01:02:00 --> Model "MainModel" initialized
INFO - 2024-10-26 01:02:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 01:02:00 --> Final output sent to browser
DEBUG - 2024-10-26 01:02:00 --> Total execution time: 2.2066
INFO - 2024-10-26 01:47:39 --> Model "MainModel" initialized
INFO - 2024-10-26 01:47:39 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 01:47:39 --> Final output sent to browser
DEBUG - 2024-10-26 01:47:39 --> Total execution time: 2.4141
INFO - 2024-10-26 04:11:45 --> Model "MainModel" initialized
INFO - 2024-10-26 04:11:45 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 04:11:45 --> Final output sent to browser
DEBUG - 2024-10-26 04:11:45 --> Total execution time: 2.2025
INFO - 2024-10-26 04:11:51 --> Model "MainModel" initialized
INFO - 2024-10-26 04:11:51 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 04:11:51 --> Final output sent to browser
DEBUG - 2024-10-26 04:11:51 --> Total execution time: 2.1249
INFO - 2024-10-26 01:54:21 --> Config Class Initialized
INFO - 2024-10-26 01:54:21 --> Hooks Class Initialized
DEBUG - 2024-10-26 01:54:21 --> UTF-8 Support Enabled
INFO - 2024-10-26 01:54:21 --> Utf8 Class Initialized
INFO - 2024-10-26 01:54:21 --> URI Class Initialized
DEBUG - 2024-10-26 01:54:21 --> No URI present. Default controller set.
INFO - 2024-10-26 01:54:21 --> Router Class Initialized
INFO - 2024-10-26 01:54:21 --> Output Class Initialized
INFO - 2024-10-26 01:54:21 --> Security Class Initialized
DEBUG - 2024-10-26 01:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 01:54:21 --> Input Class Initialized
INFO - 2024-10-26 01:54:21 --> Language Class Initialized
INFO - 2024-10-26 01:54:21 --> Loader Class Initialized
INFO - 2024-10-26 01:54:21 --> Helper loaded: url_helper
INFO - 2024-10-26 01:54:21 --> Helper loaded: html_helper
INFO - 2024-10-26 01:54:21 --> Helper loaded: file_helper
INFO - 2024-10-26 01:54:21 --> Helper loaded: string_helper
INFO - 2024-10-26 01:54:21 --> Helper loaded: form_helper
INFO - 2024-10-26 01:54:21 --> Helper loaded: my_helper
INFO - 2024-10-26 01:54:21 --> Database Driver Class Initialized
ERROR - 2024-10-26 01:54:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): An attempt was made to access a socket in a way forbidden by its access permissions C:\inetpub\vhosts\livservice.in\httpdocs\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-26 01:54:23 --> Unable to connect to the database
INFO - 2024-10-26 01:54:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-26 03:07:52 --> Config Class Initialized
INFO - 2024-10-26 03:07:52 --> Hooks Class Initialized
DEBUG - 2024-10-26 03:07:52 --> UTF-8 Support Enabled
INFO - 2024-10-26 03:07:52 --> Utf8 Class Initialized
INFO - 2024-10-26 03:07:52 --> URI Class Initialized
DEBUG - 2024-10-26 03:07:52 --> No URI present. Default controller set.
INFO - 2024-10-26 03:07:52 --> Router Class Initialized
INFO - 2024-10-26 03:07:52 --> Output Class Initialized
INFO - 2024-10-26 03:07:52 --> Security Class Initialized
DEBUG - 2024-10-26 03:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 03:07:52 --> Input Class Initialized
INFO - 2024-10-26 03:07:52 --> Language Class Initialized
INFO - 2024-10-26 03:07:52 --> Loader Class Initialized
INFO - 2024-10-26 03:07:52 --> Helper loaded: url_helper
INFO - 2024-10-26 03:07:52 --> Helper loaded: html_helper
INFO - 2024-10-26 03:07:52 --> Helper loaded: file_helper
INFO - 2024-10-26 03:07:52 --> Helper loaded: string_helper
INFO - 2024-10-26 03:07:52 --> Helper loaded: form_helper
INFO - 2024-10-26 03:07:52 --> Helper loaded: my_helper
INFO - 2024-10-26 03:07:52 --> Database Driver Class Initialized
INFO - 2024-10-26 03:07:54 --> Upload Class Initialized
INFO - 2024-10-26 03:07:54 --> Email Class Initialized
INFO - 2024-10-26 03:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 03:07:54 --> Form Validation Class Initialized
INFO - 2024-10-26 03:07:54 --> Controller Class Initialized
INFO - 2024-10-26 08:37:54 --> Model "MainModel" initialized
INFO - 2024-10-26 08:37:54 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 08:37:54 --> Final output sent to browser
DEBUG - 2024-10-26 08:37:54 --> Total execution time: 2.2154
INFO - 2024-10-26 07:20:59 --> Config Class Initialized
INFO - 2024-10-26 07:20:59 --> Hooks Class Initialized
DEBUG - 2024-10-26 07:20:59 --> UTF-8 Support Enabled
INFO - 2024-10-26 07:20:59 --> Utf8 Class Initialized
INFO - 2024-10-26 07:20:59 --> URI Class Initialized
DEBUG - 2024-10-26 07:20:59 --> No URI present. Default controller set.
INFO - 2024-10-26 07:20:59 --> Router Class Initialized
INFO - 2024-10-26 07:20:59 --> Output Class Initialized
INFO - 2024-10-26 07:20:59 --> Security Class Initialized
DEBUG - 2024-10-26 07:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 07:20:59 --> Input Class Initialized
INFO - 2024-10-26 07:20:59 --> Language Class Initialized
INFO - 2024-10-26 07:20:59 --> Loader Class Initialized
INFO - 2024-10-26 07:21:00 --> Helper loaded: url_helper
INFO - 2024-10-26 07:21:00 --> Helper loaded: html_helper
INFO - 2024-10-26 07:21:00 --> Helper loaded: file_helper
INFO - 2024-10-26 07:21:00 --> Helper loaded: string_helper
INFO - 2024-10-26 07:21:00 --> Helper loaded: form_helper
INFO - 2024-10-26 07:21:00 --> Helper loaded: my_helper
INFO - 2024-10-26 07:21:00 --> Database Driver Class Initialized
INFO - 2024-10-26 07:21:02 --> Upload Class Initialized
INFO - 2024-10-26 07:21:02 --> Email Class Initialized
INFO - 2024-10-26 07:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 07:21:02 --> Form Validation Class Initialized
INFO - 2024-10-26 07:21:02 --> Controller Class Initialized
INFO - 2024-10-26 12:51:02 --> Model "MainModel" initialized
INFO - 2024-10-26 12:51:02 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 12:51:02 --> Final output sent to browser
DEBUG - 2024-10-26 12:51:02 --> Total execution time: 2.7165
INFO - 2024-10-26 08:11:58 --> Config Class Initialized
INFO - 2024-10-26 08:11:58 --> Hooks Class Initialized
DEBUG - 2024-10-26 08:11:58 --> UTF-8 Support Enabled
INFO - 2024-10-26 08:11:58 --> Utf8 Class Initialized
INFO - 2024-10-26 08:11:58 --> URI Class Initialized
DEBUG - 2024-10-26 08:11:58 --> No URI present. Default controller set.
INFO - 2024-10-26 08:11:58 --> Router Class Initialized
INFO - 2024-10-26 08:11:58 --> Output Class Initialized
INFO - 2024-10-26 08:11:58 --> Security Class Initialized
DEBUG - 2024-10-26 08:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 08:11:58 --> Input Class Initialized
INFO - 2024-10-26 08:11:58 --> Language Class Initialized
INFO - 2024-10-26 08:11:58 --> Loader Class Initialized
INFO - 2024-10-26 08:11:58 --> Helper loaded: url_helper
INFO - 2024-10-26 08:11:58 --> Helper loaded: html_helper
INFO - 2024-10-26 08:11:58 --> Helper loaded: file_helper
INFO - 2024-10-26 08:11:58 --> Helper loaded: string_helper
INFO - 2024-10-26 08:11:58 --> Helper loaded: form_helper
INFO - 2024-10-26 08:11:58 --> Helper loaded: my_helper
INFO - 2024-10-26 08:11:58 --> Database Driver Class Initialized
INFO - 2024-10-26 08:12:00 --> Upload Class Initialized
INFO - 2024-10-26 08:12:00 --> Email Class Initialized
INFO - 2024-10-26 08:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 08:12:00 --> Form Validation Class Initialized
INFO - 2024-10-26 08:12:00 --> Controller Class Initialized
INFO - 2024-10-26 13:42:00 --> Model "MainModel" initialized
INFO - 2024-10-26 13:42:00 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 13:42:00 --> Final output sent to browser
DEBUG - 2024-10-26 13:42:00 --> Total execution time: 2.3152
INFO - 2024-10-26 09:09:39 --> Config Class Initialized
INFO - 2024-10-26 09:09:39 --> Hooks Class Initialized
DEBUG - 2024-10-26 09:09:39 --> UTF-8 Support Enabled
INFO - 2024-10-26 09:09:39 --> Utf8 Class Initialized
INFO - 2024-10-26 09:09:39 --> URI Class Initialized
DEBUG - 2024-10-26 09:09:39 --> No URI present. Default controller set.
INFO - 2024-10-26 09:09:39 --> Router Class Initialized
INFO - 2024-10-26 09:09:39 --> Output Class Initialized
INFO - 2024-10-26 09:09:39 --> Security Class Initialized
DEBUG - 2024-10-26 09:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 09:09:39 --> Input Class Initialized
INFO - 2024-10-26 09:09:39 --> Language Class Initialized
INFO - 2024-10-26 09:09:39 --> Loader Class Initialized
INFO - 2024-10-26 09:09:39 --> Helper loaded: url_helper
INFO - 2024-10-26 09:09:39 --> Helper loaded: html_helper
INFO - 2024-10-26 09:09:39 --> Helper loaded: file_helper
INFO - 2024-10-26 09:09:39 --> Helper loaded: string_helper
INFO - 2024-10-26 09:09:39 --> Helper loaded: form_helper
INFO - 2024-10-26 09:09:39 --> Helper loaded: my_helper
INFO - 2024-10-26 09:09:39 --> Database Driver Class Initialized
INFO - 2024-10-26 09:09:41 --> Upload Class Initialized
INFO - 2024-10-26 09:09:41 --> Email Class Initialized
INFO - 2024-10-26 09:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 09:09:41 --> Form Validation Class Initialized
INFO - 2024-10-26 09:09:41 --> Controller Class Initialized
INFO - 2024-10-26 14:39:41 --> Model "MainModel" initialized
INFO - 2024-10-26 14:39:41 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 14:39:41 --> Final output sent to browser
DEBUG - 2024-10-26 14:39:41 --> Total execution time: 2.2236
INFO - 2024-10-26 09:31:54 --> Config Class Initialized
INFO - 2024-10-26 09:31:54 --> Hooks Class Initialized
DEBUG - 2024-10-26 09:31:54 --> UTF-8 Support Enabled
INFO - 2024-10-26 09:31:54 --> Utf8 Class Initialized
INFO - 2024-10-26 09:31:54 --> URI Class Initialized
DEBUG - 2024-10-26 09:31:54 --> No URI present. Default controller set.
INFO - 2024-10-26 09:31:54 --> Router Class Initialized
INFO - 2024-10-26 09:31:54 --> Output Class Initialized
INFO - 2024-10-26 09:31:54 --> Security Class Initialized
DEBUG - 2024-10-26 09:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 09:31:54 --> Input Class Initialized
INFO - 2024-10-26 09:31:54 --> Language Class Initialized
INFO - 2024-10-26 09:31:54 --> Loader Class Initialized
INFO - 2024-10-26 09:31:54 --> Helper loaded: url_helper
INFO - 2024-10-26 09:31:54 --> Helper loaded: html_helper
INFO - 2024-10-26 09:31:54 --> Helper loaded: file_helper
INFO - 2024-10-26 09:31:54 --> Helper loaded: string_helper
INFO - 2024-10-26 09:31:54 --> Helper loaded: form_helper
INFO - 2024-10-26 09:31:54 --> Helper loaded: my_helper
INFO - 2024-10-26 09:31:54 --> Database Driver Class Initialized
INFO - 2024-10-26 09:31:56 --> Upload Class Initialized
INFO - 2024-10-26 09:31:56 --> Email Class Initialized
INFO - 2024-10-26 09:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 09:31:56 --> Form Validation Class Initialized
INFO - 2024-10-26 09:31:56 --> Controller Class Initialized
INFO - 2024-10-26 15:01:56 --> Model "MainModel" initialized
INFO - 2024-10-26 15:01:56 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 15:01:56 --> Final output sent to browser
DEBUG - 2024-10-26 15:01:56 --> Total execution time: 2.3871
INFO - 2024-10-26 09:31:57 --> Config Class Initialized
INFO - 2024-10-26 09:31:57 --> Hooks Class Initialized
DEBUG - 2024-10-26 09:31:57 --> UTF-8 Support Enabled
INFO - 2024-10-26 09:31:57 --> Utf8 Class Initialized
INFO - 2024-10-26 09:31:57 --> URI Class Initialized
DEBUG - 2024-10-26 09:31:57 --> No URI present. Default controller set.
INFO - 2024-10-26 09:31:57 --> Router Class Initialized
INFO - 2024-10-26 09:31:57 --> Output Class Initialized
INFO - 2024-10-26 09:31:57 --> Security Class Initialized
DEBUG - 2024-10-26 09:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 09:31:57 --> Input Class Initialized
INFO - 2024-10-26 09:31:57 --> Language Class Initialized
INFO - 2024-10-26 09:31:57 --> Loader Class Initialized
INFO - 2024-10-26 09:31:57 --> Helper loaded: url_helper
INFO - 2024-10-26 09:31:57 --> Helper loaded: html_helper
INFO - 2024-10-26 09:31:57 --> Helper loaded: file_helper
INFO - 2024-10-26 09:31:57 --> Helper loaded: string_helper
INFO - 2024-10-26 09:31:57 --> Helper loaded: form_helper
INFO - 2024-10-26 09:31:57 --> Helper loaded: my_helper
INFO - 2024-10-26 09:31:57 --> Database Driver Class Initialized
INFO - 2024-10-26 09:31:59 --> Upload Class Initialized
INFO - 2024-10-26 09:31:59 --> Email Class Initialized
INFO - 2024-10-26 09:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 09:31:59 --> Form Validation Class Initialized
INFO - 2024-10-26 09:31:59 --> Controller Class Initialized
INFO - 2024-10-26 15:01:59 --> Model "MainModel" initialized
INFO - 2024-10-26 15:01:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 15:01:59 --> Final output sent to browser
DEBUG - 2024-10-26 15:01:59 --> Total execution time: 2.1449
INFO - 2024-10-26 11:24:25 --> Config Class Initialized
INFO - 2024-10-26 11:24:25 --> Hooks Class Initialized
DEBUG - 2024-10-26 11:24:25 --> UTF-8 Support Enabled
INFO - 2024-10-26 11:24:25 --> Utf8 Class Initialized
INFO - 2024-10-26 11:24:25 --> URI Class Initialized
DEBUG - 2024-10-26 11:24:25 --> No URI present. Default controller set.
INFO - 2024-10-26 11:24:25 --> Router Class Initialized
INFO - 2024-10-26 11:24:25 --> Output Class Initialized
INFO - 2024-10-26 11:24:25 --> Security Class Initialized
DEBUG - 2024-10-26 11:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 11:24:25 --> Input Class Initialized
INFO - 2024-10-26 11:24:25 --> Language Class Initialized
INFO - 2024-10-26 11:24:25 --> Loader Class Initialized
INFO - 2024-10-26 11:24:25 --> Helper loaded: url_helper
INFO - 2024-10-26 11:24:25 --> Helper loaded: html_helper
INFO - 2024-10-26 11:24:25 --> Helper loaded: file_helper
INFO - 2024-10-26 11:24:25 --> Helper loaded: string_helper
INFO - 2024-10-26 11:24:25 --> Helper loaded: form_helper
INFO - 2024-10-26 11:24:25 --> Helper loaded: my_helper
INFO - 2024-10-26 11:24:26 --> Database Driver Class Initialized
INFO - 2024-10-26 11:24:28 --> Upload Class Initialized
INFO - 2024-10-26 11:24:28 --> Email Class Initialized
INFO - 2024-10-26 11:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 11:24:28 --> Form Validation Class Initialized
INFO - 2024-10-26 11:24:28 --> Controller Class Initialized
INFO - 2024-10-26 16:54:28 --> Model "MainModel" initialized
INFO - 2024-10-26 16:54:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 16:54:28 --> Final output sent to browser
DEBUG - 2024-10-26 16:54:28 --> Total execution time: 2.2098
INFO - 2024-10-26 12:54:35 --> Config Class Initialized
INFO - 2024-10-26 12:54:35 --> Hooks Class Initialized
DEBUG - 2024-10-26 12:54:35 --> UTF-8 Support Enabled
INFO - 2024-10-26 12:54:35 --> Utf8 Class Initialized
INFO - 2024-10-26 12:54:35 --> URI Class Initialized
DEBUG - 2024-10-26 12:54:35 --> No URI present. Default controller set.
INFO - 2024-10-26 12:54:35 --> Router Class Initialized
INFO - 2024-10-26 12:54:35 --> Output Class Initialized
INFO - 2024-10-26 12:54:35 --> Security Class Initialized
DEBUG - 2024-10-26 12:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 12:54:35 --> Input Class Initialized
INFO - 2024-10-26 12:54:35 --> Language Class Initialized
INFO - 2024-10-26 12:54:35 --> Loader Class Initialized
INFO - 2024-10-26 12:54:35 --> Helper loaded: url_helper
INFO - 2024-10-26 12:54:35 --> Helper loaded: html_helper
INFO - 2024-10-26 12:54:35 --> Helper loaded: file_helper
INFO - 2024-10-26 12:54:35 --> Helper loaded: string_helper
INFO - 2024-10-26 12:54:35 --> Helper loaded: form_helper
INFO - 2024-10-26 12:54:35 --> Helper loaded: my_helper
INFO - 2024-10-26 12:54:35 --> Database Driver Class Initialized
INFO - 2024-10-26 12:54:37 --> Upload Class Initialized
INFO - 2024-10-26 12:54:37 --> Email Class Initialized
INFO - 2024-10-26 12:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 12:54:37 --> Form Validation Class Initialized
INFO - 2024-10-26 12:54:37 --> Controller Class Initialized
INFO - 2024-10-26 18:24:37 --> Model "MainModel" initialized
INFO - 2024-10-26 18:24:37 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 18:24:37 --> Final output sent to browser
DEBUG - 2024-10-26 18:24:37 --> Total execution time: 2.5581
INFO - 2024-10-26 14:03:29 --> Config Class Initialized
INFO - 2024-10-26 14:03:29 --> Hooks Class Initialized
DEBUG - 2024-10-26 14:03:29 --> UTF-8 Support Enabled
INFO - 2024-10-26 14:03:29 --> Utf8 Class Initialized
INFO - 2024-10-26 14:03:29 --> URI Class Initialized
DEBUG - 2024-10-26 14:03:29 --> No URI present. Default controller set.
INFO - 2024-10-26 14:03:29 --> Router Class Initialized
INFO - 2024-10-26 14:03:29 --> Output Class Initialized
INFO - 2024-10-26 14:03:29 --> Security Class Initialized
DEBUG - 2024-10-26 14:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 14:03:29 --> Input Class Initialized
INFO - 2024-10-26 14:03:29 --> Language Class Initialized
INFO - 2024-10-26 14:03:29 --> Loader Class Initialized
INFO - 2024-10-26 14:03:29 --> Helper loaded: url_helper
INFO - 2024-10-26 14:03:30 --> Helper loaded: html_helper
INFO - 2024-10-26 14:03:30 --> Helper loaded: file_helper
INFO - 2024-10-26 14:03:30 --> Helper loaded: string_helper
INFO - 2024-10-26 14:03:30 --> Helper loaded: form_helper
INFO - 2024-10-26 14:03:30 --> Helper loaded: my_helper
INFO - 2024-10-26 14:03:30 --> Database Driver Class Initialized
INFO - 2024-10-26 14:03:32 --> Upload Class Initialized
INFO - 2024-10-26 14:03:32 --> Email Class Initialized
INFO - 2024-10-26 14:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 14:03:32 --> Form Validation Class Initialized
INFO - 2024-10-26 14:03:32 --> Controller Class Initialized
INFO - 2024-10-26 19:33:32 --> Model "MainModel" initialized
INFO - 2024-10-26 19:33:32 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 19:33:32 --> Final output sent to browser
DEBUG - 2024-10-26 19:33:32 --> Total execution time: 2.3583
INFO - 2024-10-26 16:34:11 --> Config Class Initialized
INFO - 2024-10-26 16:34:11 --> Hooks Class Initialized
DEBUG - 2024-10-26 16:34:11 --> UTF-8 Support Enabled
INFO - 2024-10-26 16:34:11 --> Utf8 Class Initialized
INFO - 2024-10-26 16:34:11 --> URI Class Initialized
DEBUG - 2024-10-26 16:34:11 --> No URI present. Default controller set.
INFO - 2024-10-26 16:34:11 --> Router Class Initialized
INFO - 2024-10-26 16:34:11 --> Output Class Initialized
INFO - 2024-10-26 16:34:11 --> Security Class Initialized
DEBUG - 2024-10-26 16:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 16:34:11 --> Input Class Initialized
INFO - 2024-10-26 16:34:11 --> Language Class Initialized
INFO - 2024-10-26 16:34:11 --> Loader Class Initialized
INFO - 2024-10-26 16:34:11 --> Helper loaded: url_helper
INFO - 2024-10-26 16:34:11 --> Helper loaded: html_helper
INFO - 2024-10-26 16:34:11 --> Helper loaded: file_helper
INFO - 2024-10-26 16:34:11 --> Helper loaded: string_helper
INFO - 2024-10-26 16:34:11 --> Helper loaded: form_helper
INFO - 2024-10-26 16:34:11 --> Helper loaded: my_helper
INFO - 2024-10-26 16:34:11 --> Database Driver Class Initialized
INFO - 2024-10-26 16:34:13 --> Upload Class Initialized
INFO - 2024-10-26 16:34:13 --> Email Class Initialized
INFO - 2024-10-26 16:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 16:34:13 --> Form Validation Class Initialized
INFO - 2024-10-26 16:34:13 --> Controller Class Initialized
INFO - 2024-10-26 22:04:13 --> Model "MainModel" initialized
INFO - 2024-10-26 22:04:13 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-26 22:04:13 --> Final output sent to browser
DEBUG - 2024-10-26 22:04:13 --> Total execution time: 2.2049
INFO - 2024-10-26 19:46:38 --> Config Class Initialized
INFO - 2024-10-26 19:46:38 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:38 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:38 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:38 --> URI Class Initialized
DEBUG - 2024-10-26 19:46:38 --> No URI present. Default controller set.
INFO - 2024-10-26 19:46:38 --> Router Class Initialized
INFO - 2024-10-26 19:46:38 --> Output Class Initialized
INFO - 2024-10-26 19:46:38 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:38 --> Input Class Initialized
INFO - 2024-10-26 19:46:38 --> Language Class Initialized
INFO - 2024-10-26 19:46:38 --> Loader Class Initialized
INFO - 2024-10-26 19:46:38 --> Helper loaded: url_helper
INFO - 2024-10-26 19:46:38 --> Helper loaded: html_helper
INFO - 2024-10-26 19:46:38 --> Helper loaded: file_helper
INFO - 2024-10-26 19:46:38 --> Helper loaded: string_helper
INFO - 2024-10-26 19:46:38 --> Helper loaded: form_helper
INFO - 2024-10-26 19:46:38 --> Helper loaded: my_helper
INFO - 2024-10-26 19:46:38 --> Database Driver Class Initialized
INFO - 2024-10-26 19:46:40 --> Upload Class Initialized
INFO - 2024-10-26 19:46:40 --> Email Class Initialized
INFO - 2024-10-26 19:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 19:46:40 --> Form Validation Class Initialized
INFO - 2024-10-26 19:46:40 --> Controller Class Initialized
INFO - 2024-10-26 19:46:41 --> Config Class Initialized
INFO - 2024-10-26 19:46:41 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:41 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:41 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:41 --> URI Class Initialized
INFO - 2024-10-26 19:46:41 --> Router Class Initialized
INFO - 2024-10-26 19:46:41 --> Output Class Initialized
INFO - 2024-10-26 19:46:41 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:41 --> Input Class Initialized
INFO - 2024-10-26 19:46:41 --> Language Class Initialized
ERROR - 2024-10-26 19:46:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-26 19:46:41 --> Config Class Initialized
INFO - 2024-10-26 19:46:41 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:41 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:41 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:41 --> URI Class Initialized
INFO - 2024-10-26 19:46:41 --> Router Class Initialized
INFO - 2024-10-26 19:46:41 --> Output Class Initialized
INFO - 2024-10-26 19:46:41 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:41 --> Input Class Initialized
INFO - 2024-10-26 19:46:41 --> Language Class Initialized
ERROR - 2024-10-26 19:46:41 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-26 19:46:42 --> Config Class Initialized
INFO - 2024-10-26 19:46:42 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:42 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:42 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:42 --> URI Class Initialized
DEBUG - 2024-10-26 19:46:42 --> No URI present. Default controller set.
INFO - 2024-10-26 19:46:42 --> Router Class Initialized
INFO - 2024-10-26 19:46:42 --> Output Class Initialized
INFO - 2024-10-26 19:46:42 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:42 --> Input Class Initialized
INFO - 2024-10-26 19:46:42 --> Language Class Initialized
INFO - 2024-10-26 19:46:42 --> Loader Class Initialized
INFO - 2024-10-26 19:46:42 --> Helper loaded: url_helper
INFO - 2024-10-26 19:46:42 --> Helper loaded: html_helper
INFO - 2024-10-26 19:46:42 --> Helper loaded: file_helper
INFO - 2024-10-26 19:46:42 --> Helper loaded: string_helper
INFO - 2024-10-26 19:46:42 --> Helper loaded: form_helper
INFO - 2024-10-26 19:46:42 --> Helper loaded: my_helper
INFO - 2024-10-26 19:46:42 --> Database Driver Class Initialized
INFO - 2024-10-26 19:46:44 --> Upload Class Initialized
INFO - 2024-10-26 19:46:44 --> Email Class Initialized
INFO - 2024-10-26 19:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 19:46:44 --> Form Validation Class Initialized
INFO - 2024-10-26 19:46:44 --> Controller Class Initialized
INFO - 2024-10-26 19:46:44 --> Config Class Initialized
INFO - 2024-10-26 19:46:44 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:44 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:44 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:44 --> URI Class Initialized
INFO - 2024-10-26 19:46:45 --> Router Class Initialized
INFO - 2024-10-26 19:46:45 --> Output Class Initialized
INFO - 2024-10-26 19:46:45 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:45 --> Input Class Initialized
INFO - 2024-10-26 19:46:45 --> Language Class Initialized
ERROR - 2024-10-26 19:46:45 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-26 19:46:45 --> Config Class Initialized
INFO - 2024-10-26 19:46:45 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:45 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:45 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:45 --> URI Class Initialized
INFO - 2024-10-26 19:46:45 --> Router Class Initialized
INFO - 2024-10-26 19:46:45 --> Output Class Initialized
INFO - 2024-10-26 19:46:45 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:45 --> Input Class Initialized
INFO - 2024-10-26 19:46:45 --> Language Class Initialized
ERROR - 2024-10-26 19:46:45 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-26 19:46:45 --> Config Class Initialized
INFO - 2024-10-26 19:46:45 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:45 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:45 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:45 --> URI Class Initialized
INFO - 2024-10-26 19:46:45 --> Router Class Initialized
INFO - 2024-10-26 19:46:45 --> Output Class Initialized
INFO - 2024-10-26 19:46:45 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:45 --> Input Class Initialized
INFO - 2024-10-26 19:46:45 --> Language Class Initialized
ERROR - 2024-10-26 19:46:45 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-26 19:46:45 --> Config Class Initialized
INFO - 2024-10-26 19:46:45 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:45 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:45 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:45 --> URI Class Initialized
INFO - 2024-10-26 19:46:45 --> Router Class Initialized
INFO - 2024-10-26 19:46:46 --> Output Class Initialized
INFO - 2024-10-26 19:46:46 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:46 --> Input Class Initialized
INFO - 2024-10-26 19:46:46 --> Language Class Initialized
ERROR - 2024-10-26 19:46:46 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-26 19:46:46 --> Config Class Initialized
INFO - 2024-10-26 19:46:46 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:46 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:46 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:46 --> URI Class Initialized
INFO - 2024-10-26 19:46:46 --> Router Class Initialized
INFO - 2024-10-26 19:46:46 --> Output Class Initialized
INFO - 2024-10-26 19:46:46 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:46 --> Input Class Initialized
INFO - 2024-10-26 19:46:46 --> Language Class Initialized
ERROR - 2024-10-26 19:46:46 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-26 19:46:46 --> Config Class Initialized
INFO - 2024-10-26 19:46:46 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:46 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:46 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:46 --> URI Class Initialized
INFO - 2024-10-26 19:46:46 --> Router Class Initialized
INFO - 2024-10-26 19:46:46 --> Output Class Initialized
INFO - 2024-10-26 19:46:46 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:46 --> Input Class Initialized
INFO - 2024-10-26 19:46:46 --> Language Class Initialized
ERROR - 2024-10-26 19:46:46 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-26 19:46:46 --> Config Class Initialized
INFO - 2024-10-26 19:46:46 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:46 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:46 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:46 --> URI Class Initialized
INFO - 2024-10-26 19:46:46 --> Router Class Initialized
INFO - 2024-10-26 19:46:46 --> Output Class Initialized
INFO - 2024-10-26 19:46:46 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:46 --> Input Class Initialized
INFO - 2024-10-26 19:46:46 --> Language Class Initialized
ERROR - 2024-10-26 19:46:46 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-26 19:46:47 --> Config Class Initialized
INFO - 2024-10-26 19:46:47 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:47 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:47 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:47 --> URI Class Initialized
INFO - 2024-10-26 19:46:47 --> Router Class Initialized
INFO - 2024-10-26 19:46:47 --> Output Class Initialized
INFO - 2024-10-26 19:46:47 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:47 --> Input Class Initialized
INFO - 2024-10-26 19:46:47 --> Language Class Initialized
ERROR - 2024-10-26 19:46:47 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-26 19:46:47 --> Config Class Initialized
INFO - 2024-10-26 19:46:47 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:47 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:47 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:47 --> URI Class Initialized
INFO - 2024-10-26 19:46:47 --> Router Class Initialized
INFO - 2024-10-26 19:46:47 --> Output Class Initialized
INFO - 2024-10-26 19:46:47 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:47 --> Input Class Initialized
INFO - 2024-10-26 19:46:47 --> Language Class Initialized
ERROR - 2024-10-26 19:46:47 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-26 19:46:47 --> Config Class Initialized
INFO - 2024-10-26 19:46:47 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:47 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:47 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:47 --> URI Class Initialized
INFO - 2024-10-26 19:46:47 --> Router Class Initialized
INFO - 2024-10-26 19:46:47 --> Output Class Initialized
INFO - 2024-10-26 19:46:47 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:47 --> Input Class Initialized
INFO - 2024-10-26 19:46:47 --> Language Class Initialized
ERROR - 2024-10-26 19:46:47 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-26 19:46:47 --> Config Class Initialized
INFO - 2024-10-26 19:46:47 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:47 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:47 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:47 --> URI Class Initialized
INFO - 2024-10-26 19:46:47 --> Router Class Initialized
INFO - 2024-10-26 19:46:47 --> Output Class Initialized
INFO - 2024-10-26 19:46:47 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:47 --> Input Class Initialized
INFO - 2024-10-26 19:46:47 --> Language Class Initialized
ERROR - 2024-10-26 19:46:47 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-26 19:46:48 --> Config Class Initialized
INFO - 2024-10-26 19:46:48 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:48 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:48 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:48 --> URI Class Initialized
INFO - 2024-10-26 19:46:48 --> Router Class Initialized
INFO - 2024-10-26 19:46:48 --> Output Class Initialized
INFO - 2024-10-26 19:46:48 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:48 --> Input Class Initialized
INFO - 2024-10-26 19:46:48 --> Language Class Initialized
ERROR - 2024-10-26 19:46:48 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-26 19:46:48 --> Config Class Initialized
INFO - 2024-10-26 19:46:48 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:48 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:48 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:48 --> URI Class Initialized
INFO - 2024-10-26 19:46:48 --> Router Class Initialized
INFO - 2024-10-26 19:46:48 --> Output Class Initialized
INFO - 2024-10-26 19:46:48 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:48 --> Input Class Initialized
INFO - 2024-10-26 19:46:48 --> Language Class Initialized
ERROR - 2024-10-26 19:46:48 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-26 19:46:48 --> Config Class Initialized
INFO - 2024-10-26 19:46:48 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:48 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:48 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:48 --> URI Class Initialized
INFO - 2024-10-26 19:46:48 --> Router Class Initialized
INFO - 2024-10-26 19:46:48 --> Output Class Initialized
INFO - 2024-10-26 19:46:48 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:48 --> Input Class Initialized
INFO - 2024-10-26 19:46:48 --> Language Class Initialized
ERROR - 2024-10-26 19:46:48 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-26 19:46:48 --> Config Class Initialized
INFO - 2024-10-26 19:46:48 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:48 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:48 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:48 --> URI Class Initialized
INFO - 2024-10-26 19:46:48 --> Router Class Initialized
INFO - 2024-10-26 19:46:48 --> Output Class Initialized
INFO - 2024-10-26 19:46:48 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:48 --> Input Class Initialized
INFO - 2024-10-26 19:46:49 --> Language Class Initialized
ERROR - 2024-10-26 19:46:49 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-26 19:46:49 --> Config Class Initialized
INFO - 2024-10-26 19:46:49 --> Hooks Class Initialized
DEBUG - 2024-10-26 19:46:49 --> UTF-8 Support Enabled
INFO - 2024-10-26 19:46:49 --> Utf8 Class Initialized
INFO - 2024-10-26 19:46:49 --> URI Class Initialized
INFO - 2024-10-26 19:46:49 --> Router Class Initialized
INFO - 2024-10-26 19:46:49 --> Output Class Initialized
INFO - 2024-10-26 19:46:49 --> Security Class Initialized
DEBUG - 2024-10-26 19:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 19:46:49 --> Input Class Initialized
INFO - 2024-10-26 19:46:49 --> Language Class Initialized
ERROR - 2024-10-26 19:46:49 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-26 21:56:12 --> Config Class Initialized
INFO - 2024-10-26 21:56:13 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:14 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:14 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:14 --> URI Class Initialized
DEBUG - 2024-10-26 21:56:15 --> No URI present. Default controller set.
INFO - 2024-10-26 21:56:15 --> Router Class Initialized
INFO - 2024-10-26 21:56:15 --> Output Class Initialized
INFO - 2024-10-26 21:56:15 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:15 --> Input Class Initialized
INFO - 2024-10-26 21:56:16 --> Language Class Initialized
INFO - 2024-10-26 21:56:17 --> Loader Class Initialized
INFO - 2024-10-26 21:56:17 --> Helper loaded: url_helper
INFO - 2024-10-26 21:56:17 --> Helper loaded: html_helper
INFO - 2024-10-26 21:56:17 --> Helper loaded: file_helper
INFO - 2024-10-26 21:56:17 --> Helper loaded: string_helper
INFO - 2024-10-26 21:56:17 --> Helper loaded: form_helper
INFO - 2024-10-26 21:56:18 --> Helper loaded: my_helper
INFO - 2024-10-26 21:56:19 --> Database Driver Class Initialized
INFO - 2024-10-26 21:56:22 --> Upload Class Initialized
INFO - 2024-10-26 21:56:25 --> Email Class Initialized
INFO - 2024-10-26 21:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 21:56:28 --> Form Validation Class Initialized
INFO - 2024-10-26 21:56:28 --> Controller Class Initialized
INFO - 2024-10-26 21:56:30 --> Config Class Initialized
INFO - 2024-10-26 21:56:30 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:30 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:30 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:30 --> URI Class Initialized
INFO - 2024-10-26 21:56:30 --> Router Class Initialized
INFO - 2024-10-26 21:56:30 --> Output Class Initialized
INFO - 2024-10-26 21:56:30 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:30 --> Input Class Initialized
INFO - 2024-10-26 21:56:30 --> Language Class Initialized
ERROR - 2024-10-26 21:56:30 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-26 21:56:31 --> Config Class Initialized
INFO - 2024-10-26 21:56:31 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:31 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:31 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:31 --> URI Class Initialized
INFO - 2024-10-26 21:56:31 --> Router Class Initialized
INFO - 2024-10-26 21:56:31 --> Output Class Initialized
INFO - 2024-10-26 21:56:31 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:31 --> Input Class Initialized
INFO - 2024-10-26 21:56:31 --> Language Class Initialized
ERROR - 2024-10-26 21:56:31 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-26 21:56:31 --> Config Class Initialized
INFO - 2024-10-26 21:56:31 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:31 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:31 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:31 --> URI Class Initialized
DEBUG - 2024-10-26 21:56:31 --> No URI present. Default controller set.
INFO - 2024-10-26 21:56:31 --> Router Class Initialized
INFO - 2024-10-26 21:56:31 --> Output Class Initialized
INFO - 2024-10-26 21:56:31 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:31 --> Input Class Initialized
INFO - 2024-10-26 21:56:31 --> Language Class Initialized
INFO - 2024-10-26 21:56:31 --> Loader Class Initialized
INFO - 2024-10-26 21:56:31 --> Helper loaded: url_helper
INFO - 2024-10-26 21:56:31 --> Helper loaded: html_helper
INFO - 2024-10-26 21:56:31 --> Helper loaded: file_helper
INFO - 2024-10-26 21:56:31 --> Helper loaded: string_helper
INFO - 2024-10-26 21:56:31 --> Helper loaded: form_helper
INFO - 2024-10-26 21:56:31 --> Helper loaded: my_helper
INFO - 2024-10-26 21:56:31 --> Database Driver Class Initialized
INFO - 2024-10-26 21:56:33 --> Upload Class Initialized
INFO - 2024-10-26 21:56:33 --> Email Class Initialized
INFO - 2024-10-26 21:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 21:56:34 --> Form Validation Class Initialized
INFO - 2024-10-26 21:56:34 --> Controller Class Initialized
INFO - 2024-10-26 21:56:34 --> Config Class Initialized
INFO - 2024-10-26 21:56:34 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:34 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:34 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:34 --> URI Class Initialized
INFO - 2024-10-26 21:56:34 --> Router Class Initialized
INFO - 2024-10-26 21:56:34 --> Output Class Initialized
INFO - 2024-10-26 21:56:34 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:34 --> Input Class Initialized
INFO - 2024-10-26 21:56:34 --> Language Class Initialized
ERROR - 2024-10-26 21:56:34 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-26 21:56:34 --> Config Class Initialized
INFO - 2024-10-26 21:56:34 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:34 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:34 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:34 --> URI Class Initialized
INFO - 2024-10-26 21:56:34 --> Router Class Initialized
INFO - 2024-10-26 21:56:34 --> Output Class Initialized
INFO - 2024-10-26 21:56:34 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:34 --> Input Class Initialized
INFO - 2024-10-26 21:56:34 --> Language Class Initialized
ERROR - 2024-10-26 21:56:34 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-26 21:56:35 --> Config Class Initialized
INFO - 2024-10-26 21:56:35 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:35 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:35 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:35 --> URI Class Initialized
INFO - 2024-10-26 21:56:35 --> Router Class Initialized
INFO - 2024-10-26 21:56:35 --> Output Class Initialized
INFO - 2024-10-26 21:56:35 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:35 --> Input Class Initialized
INFO - 2024-10-26 21:56:35 --> Language Class Initialized
ERROR - 2024-10-26 21:56:35 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-26 21:56:35 --> Config Class Initialized
INFO - 2024-10-26 21:56:35 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:35 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:35 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:35 --> URI Class Initialized
INFO - 2024-10-26 21:56:35 --> Router Class Initialized
INFO - 2024-10-26 21:56:35 --> Output Class Initialized
INFO - 2024-10-26 21:56:35 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:35 --> Input Class Initialized
INFO - 2024-10-26 21:56:35 --> Language Class Initialized
ERROR - 2024-10-26 21:56:35 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-26 21:56:35 --> Config Class Initialized
INFO - 2024-10-26 21:56:35 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:35 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:35 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:35 --> URI Class Initialized
INFO - 2024-10-26 21:56:35 --> Router Class Initialized
INFO - 2024-10-26 21:56:35 --> Output Class Initialized
INFO - 2024-10-26 21:56:35 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:35 --> Input Class Initialized
INFO - 2024-10-26 21:56:35 --> Language Class Initialized
ERROR - 2024-10-26 21:56:35 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-26 21:56:36 --> Config Class Initialized
INFO - 2024-10-26 21:56:36 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:36 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:36 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:36 --> URI Class Initialized
INFO - 2024-10-26 21:56:36 --> Router Class Initialized
INFO - 2024-10-26 21:56:36 --> Output Class Initialized
INFO - 2024-10-26 21:56:36 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:36 --> Input Class Initialized
INFO - 2024-10-26 21:56:36 --> Language Class Initialized
ERROR - 2024-10-26 21:56:36 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-26 21:56:36 --> Config Class Initialized
INFO - 2024-10-26 21:56:36 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:36 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:36 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:36 --> URI Class Initialized
INFO - 2024-10-26 21:56:36 --> Router Class Initialized
INFO - 2024-10-26 21:56:36 --> Output Class Initialized
INFO - 2024-10-26 21:56:36 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:36 --> Input Class Initialized
INFO - 2024-10-26 21:56:36 --> Language Class Initialized
ERROR - 2024-10-26 21:56:36 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-26 21:56:36 --> Config Class Initialized
INFO - 2024-10-26 21:56:36 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:36 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:36 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:36 --> URI Class Initialized
INFO - 2024-10-26 21:56:36 --> Router Class Initialized
INFO - 2024-10-26 21:56:36 --> Output Class Initialized
INFO - 2024-10-26 21:56:36 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:36 --> Input Class Initialized
INFO - 2024-10-26 21:56:36 --> Language Class Initialized
ERROR - 2024-10-26 21:56:36 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-26 21:56:36 --> Config Class Initialized
INFO - 2024-10-26 21:56:36 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:36 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:36 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:36 --> URI Class Initialized
INFO - 2024-10-26 21:56:36 --> Router Class Initialized
INFO - 2024-10-26 21:56:36 --> Output Class Initialized
INFO - 2024-10-26 21:56:36 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:36 --> Input Class Initialized
INFO - 2024-10-26 21:56:36 --> Language Class Initialized
ERROR - 2024-10-26 21:56:36 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-26 21:56:37 --> Config Class Initialized
INFO - 2024-10-26 21:56:37 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:37 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:37 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:37 --> URI Class Initialized
INFO - 2024-10-26 21:56:37 --> Router Class Initialized
INFO - 2024-10-26 21:56:37 --> Output Class Initialized
INFO - 2024-10-26 21:56:37 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:37 --> Input Class Initialized
INFO - 2024-10-26 21:56:37 --> Language Class Initialized
ERROR - 2024-10-26 21:56:37 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-26 21:56:37 --> Config Class Initialized
INFO - 2024-10-26 21:56:37 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:37 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:37 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:37 --> URI Class Initialized
INFO - 2024-10-26 21:56:37 --> Router Class Initialized
INFO - 2024-10-26 21:56:37 --> Output Class Initialized
INFO - 2024-10-26 21:56:37 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:37 --> Input Class Initialized
INFO - 2024-10-26 21:56:37 --> Language Class Initialized
ERROR - 2024-10-26 21:56:37 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-26 21:56:37 --> Config Class Initialized
INFO - 2024-10-26 21:56:37 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:37 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:37 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:37 --> URI Class Initialized
INFO - 2024-10-26 21:56:37 --> Router Class Initialized
INFO - 2024-10-26 21:56:37 --> Output Class Initialized
INFO - 2024-10-26 21:56:37 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:37 --> Input Class Initialized
INFO - 2024-10-26 21:56:37 --> Language Class Initialized
ERROR - 2024-10-26 21:56:37 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-26 21:56:37 --> Config Class Initialized
INFO - 2024-10-26 21:56:37 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:37 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:37 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:37 --> URI Class Initialized
INFO - 2024-10-26 21:56:38 --> Router Class Initialized
INFO - 2024-10-26 21:56:38 --> Output Class Initialized
INFO - 2024-10-26 21:56:38 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:38 --> Input Class Initialized
INFO - 2024-10-26 21:56:38 --> Language Class Initialized
ERROR - 2024-10-26 21:56:38 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-26 21:56:38 --> Config Class Initialized
INFO - 2024-10-26 21:56:38 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:38 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:38 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:38 --> URI Class Initialized
INFO - 2024-10-26 21:56:38 --> Router Class Initialized
INFO - 2024-10-26 21:56:38 --> Output Class Initialized
INFO - 2024-10-26 21:56:38 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:38 --> Input Class Initialized
INFO - 2024-10-26 21:56:38 --> Language Class Initialized
ERROR - 2024-10-26 21:56:38 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-26 21:56:38 --> Config Class Initialized
INFO - 2024-10-26 21:56:38 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:38 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:38 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:38 --> URI Class Initialized
INFO - 2024-10-26 21:56:38 --> Router Class Initialized
INFO - 2024-10-26 21:56:38 --> Output Class Initialized
INFO - 2024-10-26 21:56:38 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:38 --> Input Class Initialized
INFO - 2024-10-26 21:56:38 --> Language Class Initialized
ERROR - 2024-10-26 21:56:38 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-26 21:56:38 --> Config Class Initialized
INFO - 2024-10-26 21:56:38 --> Hooks Class Initialized
DEBUG - 2024-10-26 21:56:38 --> UTF-8 Support Enabled
INFO - 2024-10-26 21:56:38 --> Utf8 Class Initialized
INFO - 2024-10-26 21:56:38 --> URI Class Initialized
INFO - 2024-10-26 21:56:38 --> Router Class Initialized
INFO - 2024-10-26 21:56:38 --> Output Class Initialized
INFO - 2024-10-26 21:56:38 --> Security Class Initialized
DEBUG - 2024-10-26 21:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 21:56:38 --> Input Class Initialized
INFO - 2024-10-26 21:56:38 --> Language Class Initialized
ERROR - 2024-10-26 21:56:38 --> 404 Page Not Found: Sito/wp-includes
INFO - 2024-10-26 22:18:32 --> Config Class Initialized
INFO - 2024-10-26 22:18:32 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:32 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:32 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:32 --> URI Class Initialized
DEBUG - 2024-10-26 22:18:32 --> No URI present. Default controller set.
INFO - 2024-10-26 22:18:32 --> Router Class Initialized
INFO - 2024-10-26 22:18:32 --> Output Class Initialized
INFO - 2024-10-26 22:18:33 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:33 --> Input Class Initialized
INFO - 2024-10-26 22:18:33 --> Language Class Initialized
INFO - 2024-10-26 22:18:33 --> Loader Class Initialized
INFO - 2024-10-26 22:18:33 --> Helper loaded: url_helper
INFO - 2024-10-26 22:18:33 --> Helper loaded: html_helper
INFO - 2024-10-26 22:18:33 --> Helper loaded: file_helper
INFO - 2024-10-26 22:18:33 --> Helper loaded: string_helper
INFO - 2024-10-26 22:18:33 --> Helper loaded: form_helper
INFO - 2024-10-26 22:18:33 --> Helper loaded: my_helper
INFO - 2024-10-26 22:18:34 --> Database Driver Class Initialized
INFO - 2024-10-26 22:18:36 --> Upload Class Initialized
INFO - 2024-10-26 22:18:36 --> Email Class Initialized
INFO - 2024-10-26 22:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 22:18:36 --> Form Validation Class Initialized
INFO - 2024-10-26 22:18:36 --> Controller Class Initialized
INFO - 2024-10-26 22:18:37 --> Config Class Initialized
INFO - 2024-10-26 22:18:37 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:37 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:37 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:37 --> URI Class Initialized
INFO - 2024-10-26 22:18:37 --> Router Class Initialized
INFO - 2024-10-26 22:18:37 --> Output Class Initialized
INFO - 2024-10-26 22:18:37 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:37 --> Input Class Initialized
INFO - 2024-10-26 22:18:37 --> Language Class Initialized
ERROR - 2024-10-26 22:18:37 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
INFO - 2024-10-26 22:18:37 --> Config Class Initialized
INFO - 2024-10-26 22:18:37 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:37 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:37 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:37 --> URI Class Initialized
INFO - 2024-10-26 22:18:37 --> Router Class Initialized
INFO - 2024-10-26 22:18:37 --> Output Class Initialized
INFO - 2024-10-26 22:18:37 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:37 --> Input Class Initialized
INFO - 2024-10-26 22:18:37 --> Language Class Initialized
ERROR - 2024-10-26 22:18:37 --> 404 Page Not Found: Xmlrpcphp/index
INFO - 2024-10-26 22:18:38 --> Config Class Initialized
INFO - 2024-10-26 22:18:38 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:38 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:38 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:38 --> URI Class Initialized
DEBUG - 2024-10-26 22:18:38 --> No URI present. Default controller set.
INFO - 2024-10-26 22:18:38 --> Router Class Initialized
INFO - 2024-10-26 22:18:38 --> Output Class Initialized
INFO - 2024-10-26 22:18:38 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:38 --> Input Class Initialized
INFO - 2024-10-26 22:18:38 --> Language Class Initialized
INFO - 2024-10-26 22:18:38 --> Loader Class Initialized
INFO - 2024-10-26 22:18:38 --> Helper loaded: url_helper
INFO - 2024-10-26 22:18:38 --> Helper loaded: html_helper
INFO - 2024-10-26 22:18:38 --> Helper loaded: file_helper
INFO - 2024-10-26 22:18:38 --> Helper loaded: string_helper
INFO - 2024-10-26 22:18:38 --> Helper loaded: form_helper
INFO - 2024-10-26 22:18:38 --> Helper loaded: my_helper
INFO - 2024-10-26 22:18:38 --> Database Driver Class Initialized
INFO - 2024-10-26 22:18:40 --> Upload Class Initialized
INFO - 2024-10-26 22:18:40 --> Email Class Initialized
INFO - 2024-10-26 22:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 22:18:40 --> Form Validation Class Initialized
INFO - 2024-10-26 22:18:40 --> Controller Class Initialized
INFO - 2024-10-26 22:18:40 --> Config Class Initialized
INFO - 2024-10-26 22:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:40 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:40 --> URI Class Initialized
INFO - 2024-10-26 22:18:40 --> Router Class Initialized
INFO - 2024-10-26 22:18:40 --> Output Class Initialized
INFO - 2024-10-26 22:18:40 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:40 --> Input Class Initialized
INFO - 2024-10-26 22:18:40 --> Language Class Initialized
ERROR - 2024-10-26 22:18:40 --> 404 Page Not Found: Blog/wp-includes
INFO - 2024-10-26 22:18:40 --> Config Class Initialized
INFO - 2024-10-26 22:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:40 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:40 --> URI Class Initialized
INFO - 2024-10-26 22:18:40 --> Router Class Initialized
INFO - 2024-10-26 22:18:40 --> Output Class Initialized
INFO - 2024-10-26 22:18:40 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:40 --> Input Class Initialized
INFO - 2024-10-26 22:18:40 --> Language Class Initialized
ERROR - 2024-10-26 22:18:40 --> 404 Page Not Found: Web/wp-includes
INFO - 2024-10-26 22:18:40 --> Config Class Initialized
INFO - 2024-10-26 22:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:40 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:40 --> URI Class Initialized
INFO - 2024-10-26 22:18:40 --> Router Class Initialized
INFO - 2024-10-26 22:18:40 --> Output Class Initialized
INFO - 2024-10-26 22:18:40 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:40 --> Input Class Initialized
INFO - 2024-10-26 22:18:40 --> Language Class Initialized
ERROR - 2024-10-26 22:18:40 --> 404 Page Not Found: Wordpress/wp-includes
INFO - 2024-10-26 22:18:41 --> Config Class Initialized
INFO - 2024-10-26 22:18:41 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:41 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:41 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:41 --> URI Class Initialized
INFO - 2024-10-26 22:18:41 --> Router Class Initialized
INFO - 2024-10-26 22:18:41 --> Output Class Initialized
INFO - 2024-10-26 22:18:41 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:41 --> Input Class Initialized
INFO - 2024-10-26 22:18:41 --> Language Class Initialized
ERROR - 2024-10-26 22:18:41 --> 404 Page Not Found: Website/wp-includes
INFO - 2024-10-26 22:18:41 --> Config Class Initialized
INFO - 2024-10-26 22:18:41 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:41 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:41 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:41 --> URI Class Initialized
INFO - 2024-10-26 22:18:41 --> Router Class Initialized
INFO - 2024-10-26 22:18:41 --> Output Class Initialized
INFO - 2024-10-26 22:18:41 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:41 --> Input Class Initialized
INFO - 2024-10-26 22:18:41 --> Language Class Initialized
ERROR - 2024-10-26 22:18:41 --> 404 Page Not Found: Wp/wp-includes
INFO - 2024-10-26 22:18:41 --> Config Class Initialized
INFO - 2024-10-26 22:18:41 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:41 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:41 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:41 --> URI Class Initialized
INFO - 2024-10-26 22:18:41 --> Router Class Initialized
INFO - 2024-10-26 22:18:41 --> Output Class Initialized
INFO - 2024-10-26 22:18:41 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:41 --> Input Class Initialized
INFO - 2024-10-26 22:18:41 --> Language Class Initialized
ERROR - 2024-10-26 22:18:41 --> 404 Page Not Found: News/wp-includes
INFO - 2024-10-26 22:18:42 --> Config Class Initialized
INFO - 2024-10-26 22:18:42 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:42 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:42 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:42 --> URI Class Initialized
INFO - 2024-10-26 22:18:42 --> Router Class Initialized
INFO - 2024-10-26 22:18:42 --> Output Class Initialized
INFO - 2024-10-26 22:18:42 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:42 --> Input Class Initialized
INFO - 2024-10-26 22:18:42 --> Language Class Initialized
ERROR - 2024-10-26 22:18:42 --> 404 Page Not Found: 2018/wp-includes
INFO - 2024-10-26 22:18:42 --> Config Class Initialized
INFO - 2024-10-26 22:18:42 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:42 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:42 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:42 --> URI Class Initialized
INFO - 2024-10-26 22:18:42 --> Router Class Initialized
INFO - 2024-10-26 22:18:42 --> Output Class Initialized
INFO - 2024-10-26 22:18:42 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:42 --> Input Class Initialized
INFO - 2024-10-26 22:18:42 --> Language Class Initialized
ERROR - 2024-10-26 22:18:42 --> 404 Page Not Found: 2019/wp-includes
INFO - 2024-10-26 22:18:42 --> Config Class Initialized
INFO - 2024-10-26 22:18:42 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:42 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:42 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:42 --> URI Class Initialized
INFO - 2024-10-26 22:18:42 --> Router Class Initialized
INFO - 2024-10-26 22:18:42 --> Output Class Initialized
INFO - 2024-10-26 22:18:42 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:42 --> Input Class Initialized
INFO - 2024-10-26 22:18:42 --> Language Class Initialized
ERROR - 2024-10-26 22:18:42 --> 404 Page Not Found: Shop/wp-includes
INFO - 2024-10-26 22:18:42 --> Config Class Initialized
INFO - 2024-10-26 22:18:42 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:42 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:42 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:42 --> URI Class Initialized
INFO - 2024-10-26 22:18:42 --> Router Class Initialized
INFO - 2024-10-26 22:18:42 --> Output Class Initialized
INFO - 2024-10-26 22:18:42 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:42 --> Input Class Initialized
INFO - 2024-10-26 22:18:42 --> Language Class Initialized
ERROR - 2024-10-26 22:18:42 --> 404 Page Not Found: Wp1/wp-includes
INFO - 2024-10-26 22:18:43 --> Config Class Initialized
INFO - 2024-10-26 22:18:43 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:43 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:43 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:43 --> URI Class Initialized
INFO - 2024-10-26 22:18:43 --> Router Class Initialized
INFO - 2024-10-26 22:18:43 --> Output Class Initialized
INFO - 2024-10-26 22:18:43 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:43 --> Input Class Initialized
INFO - 2024-10-26 22:18:43 --> Language Class Initialized
ERROR - 2024-10-26 22:18:43 --> 404 Page Not Found: Test/wp-includes
INFO - 2024-10-26 22:18:43 --> Config Class Initialized
INFO - 2024-10-26 22:18:43 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:43 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:43 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:43 --> URI Class Initialized
INFO - 2024-10-26 22:18:43 --> Router Class Initialized
INFO - 2024-10-26 22:18:43 --> Output Class Initialized
INFO - 2024-10-26 22:18:43 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:43 --> Input Class Initialized
INFO - 2024-10-26 22:18:43 --> Language Class Initialized
ERROR - 2024-10-26 22:18:43 --> 404 Page Not Found: Media/wp-includes
INFO - 2024-10-26 22:18:43 --> Config Class Initialized
INFO - 2024-10-26 22:18:43 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:43 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:43 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:43 --> URI Class Initialized
INFO - 2024-10-26 22:18:43 --> Router Class Initialized
INFO - 2024-10-26 22:18:43 --> Output Class Initialized
INFO - 2024-10-26 22:18:43 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:43 --> Input Class Initialized
INFO - 2024-10-26 22:18:43 --> Language Class Initialized
ERROR - 2024-10-26 22:18:43 --> 404 Page Not Found: Wp2/wp-includes
INFO - 2024-10-26 22:18:44 --> Config Class Initialized
INFO - 2024-10-26 22:18:44 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:44 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:44 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:44 --> URI Class Initialized
INFO - 2024-10-26 22:18:44 --> Router Class Initialized
INFO - 2024-10-26 22:18:44 --> Output Class Initialized
INFO - 2024-10-26 22:18:44 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:44 --> Input Class Initialized
INFO - 2024-10-26 22:18:44 --> Language Class Initialized
ERROR - 2024-10-26 22:18:44 --> 404 Page Not Found: Site/wp-includes
INFO - 2024-10-26 22:18:44 --> Config Class Initialized
INFO - 2024-10-26 22:18:44 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:44 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:44 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:44 --> URI Class Initialized
INFO - 2024-10-26 22:18:44 --> Router Class Initialized
INFO - 2024-10-26 22:18:44 --> Output Class Initialized
INFO - 2024-10-26 22:18:44 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:44 --> Input Class Initialized
INFO - 2024-10-26 22:18:44 --> Language Class Initialized
ERROR - 2024-10-26 22:18:44 --> 404 Page Not Found: Cms/wp-includes
INFO - 2024-10-26 22:18:44 --> Config Class Initialized
INFO - 2024-10-26 22:18:44 --> Hooks Class Initialized
DEBUG - 2024-10-26 22:18:44 --> UTF-8 Support Enabled
INFO - 2024-10-26 22:18:44 --> Utf8 Class Initialized
INFO - 2024-10-26 22:18:44 --> URI Class Initialized
INFO - 2024-10-26 22:18:44 --> Router Class Initialized
INFO - 2024-10-26 22:18:44 --> Output Class Initialized
INFO - 2024-10-26 22:18:44 --> Security Class Initialized
DEBUG - 2024-10-26 22:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 22:18:44 --> Input Class Initialized
INFO - 2024-10-26 22:18:44 --> Language Class Initialized
ERROR - 2024-10-26 22:18:44 --> 404 Page Not Found: Sito/wp-includes
