<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-19 09:01:00 --> Config Class Initialized
INFO - 2024-10-19 09:01:00 --> Hooks Class Initialized
DEBUG - 2024-10-19 09:01:00 --> UTF-8 Support Enabled
INFO - 2024-10-19 09:01:00 --> Utf8 Class Initialized
INFO - 2024-10-19 09:01:00 --> URI Class Initialized
DEBUG - 2024-10-19 09:01:00 --> No URI present. Default controller set.
INFO - 2024-10-19 09:01:00 --> Router Class Initialized
INFO - 2024-10-19 09:01:00 --> Output Class Initialized
INFO - 2024-10-19 09:01:00 --> Security Class Initialized
DEBUG - 2024-10-19 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 09:01:01 --> Input Class Initialized
INFO - 2024-10-19 09:01:01 --> Language Class Initialized
INFO - 2024-10-19 09:01:01 --> Loader Class Initialized
INFO - 2024-10-19 09:01:01 --> Helper loaded: url_helper
INFO - 2024-10-19 09:01:01 --> Helper loaded: html_helper
INFO - 2024-10-19 09:01:01 --> Helper loaded: file_helper
INFO - 2024-10-19 09:01:01 --> Helper loaded: string_helper
INFO - 2024-10-19 09:01:01 --> Helper loaded: form_helper
INFO - 2024-10-19 09:01:01 --> Helper loaded: my_helper
INFO - 2024-10-19 09:01:01 --> Database Driver Class Initialized
INFO - 2024-10-19 09:01:03 --> Upload Class Initialized
INFO - 2024-10-19 09:01:03 --> Email Class Initialized
INFO - 2024-10-19 09:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 09:01:03 --> Form Validation Class Initialized
INFO - 2024-10-19 09:01:03 --> Controller Class Initialized
INFO - 2024-10-19 14:31:03 --> Model "MainModel" initialized
INFO - 2024-10-19 14:31:03 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 14:31:03 --> Final output sent to browser
DEBUG - 2024-10-19 14:31:03 --> Total execution time: 2.6355
INFO - 2024-10-19 11:07:24 --> Config Class Initialized
INFO - 2024-10-19 11:07:24 --> Hooks Class Initialized
DEBUG - 2024-10-19 11:07:24 --> UTF-8 Support Enabled
INFO - 2024-10-19 11:07:24 --> Utf8 Class Initialized
INFO - 2024-10-19 11:07:24 --> URI Class Initialized
INFO - 2024-10-19 11:07:24 --> Router Class Initialized
INFO - 2024-10-19 11:07:24 --> Output Class Initialized
INFO - 2024-10-19 11:07:24 --> Security Class Initialized
DEBUG - 2024-10-19 11:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 11:07:24 --> Input Class Initialized
INFO - 2024-10-19 11:07:24 --> Language Class Initialized
ERROR - 2024-10-19 11:07:24 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-19 11:07:25 --> Config Class Initialized
INFO - 2024-10-19 11:07:25 --> Hooks Class Initialized
DEBUG - 2024-10-19 11:07:25 --> UTF-8 Support Enabled
INFO - 2024-10-19 11:07:25 --> Utf8 Class Initialized
INFO - 2024-10-19 11:07:25 --> URI Class Initialized
DEBUG - 2024-10-19 11:07:25 --> No URI present. Default controller set.
INFO - 2024-10-19 11:07:25 --> Router Class Initialized
INFO - 2024-10-19 11:07:25 --> Output Class Initialized
INFO - 2024-10-19 11:07:25 --> Security Class Initialized
DEBUG - 2024-10-19 11:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 11:07:25 --> Input Class Initialized
INFO - 2024-10-19 11:07:25 --> Language Class Initialized
INFO - 2024-10-19 11:07:25 --> Loader Class Initialized
INFO - 2024-10-19 11:07:25 --> Helper loaded: url_helper
INFO - 2024-10-19 11:07:25 --> Helper loaded: html_helper
INFO - 2024-10-19 11:07:25 --> Helper loaded: file_helper
INFO - 2024-10-19 11:07:25 --> Helper loaded: string_helper
INFO - 2024-10-19 11:07:25 --> Helper loaded: form_helper
INFO - 2024-10-19 11:07:25 --> Helper loaded: my_helper
INFO - 2024-10-19 11:07:25 --> Database Driver Class Initialized
INFO - 2024-10-19 11:07:27 --> Upload Class Initialized
INFO - 2024-10-19 11:07:27 --> Email Class Initialized
INFO - 2024-10-19 11:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 11:07:27 --> Form Validation Class Initialized
INFO - 2024-10-19 11:07:27 --> Controller Class Initialized
INFO - 2024-10-19 16:37:27 --> Model "MainModel" initialized
INFO - 2024-10-19 16:37:27 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 16:37:27 --> Final output sent to browser
DEBUG - 2024-10-19 16:37:27 --> Total execution time: 2.1842
INFO - 2024-10-19 11:24:25 --> Config Class Initialized
INFO - 2024-10-19 11:24:25 --> Hooks Class Initialized
DEBUG - 2024-10-19 11:24:25 --> UTF-8 Support Enabled
INFO - 2024-10-19 11:24:25 --> Utf8 Class Initialized
INFO - 2024-10-19 11:24:25 --> URI Class Initialized
INFO - 2024-10-19 11:24:25 --> Router Class Initialized
INFO - 2024-10-19 11:24:25 --> Output Class Initialized
INFO - 2024-10-19 11:24:25 --> Security Class Initialized
DEBUG - 2024-10-19 11:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 11:24:25 --> Input Class Initialized
INFO - 2024-10-19 11:24:25 --> Language Class Initialized
ERROR - 2024-10-19 11:24:25 --> 404 Page Not Found: Robotstxt/index
INFO - 2024-10-19 11:24:26 --> Config Class Initialized
INFO - 2024-10-19 11:24:26 --> Hooks Class Initialized
DEBUG - 2024-10-19 11:24:26 --> UTF-8 Support Enabled
INFO - 2024-10-19 11:24:26 --> Utf8 Class Initialized
INFO - 2024-10-19 11:24:26 --> URI Class Initialized
DEBUG - 2024-10-19 11:24:26 --> No URI present. Default controller set.
INFO - 2024-10-19 11:24:26 --> Router Class Initialized
INFO - 2024-10-19 11:24:26 --> Output Class Initialized
INFO - 2024-10-19 11:24:26 --> Security Class Initialized
DEBUG - 2024-10-19 11:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 11:24:26 --> Input Class Initialized
INFO - 2024-10-19 11:24:26 --> Language Class Initialized
INFO - 2024-10-19 11:24:26 --> Loader Class Initialized
INFO - 2024-10-19 11:24:26 --> Helper loaded: url_helper
INFO - 2024-10-19 11:24:26 --> Helper loaded: html_helper
INFO - 2024-10-19 11:24:26 --> Helper loaded: file_helper
INFO - 2024-10-19 11:24:26 --> Helper loaded: string_helper
INFO - 2024-10-19 11:24:26 --> Helper loaded: form_helper
INFO - 2024-10-19 11:24:26 --> Helper loaded: my_helper
INFO - 2024-10-19 11:24:26 --> Database Driver Class Initialized
INFO - 2024-10-19 11:24:28 --> Upload Class Initialized
INFO - 2024-10-19 11:24:28 --> Email Class Initialized
INFO - 2024-10-19 11:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 11:24:28 --> Form Validation Class Initialized
INFO - 2024-10-19 11:24:28 --> Controller Class Initialized
INFO - 2024-10-19 16:54:28 --> Model "MainModel" initialized
INFO - 2024-10-19 16:54:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 16:54:28 --> Final output sent to browser
DEBUG - 2024-10-19 16:54:28 --> Total execution time: 2.1793
INFO - 2024-10-19 12:24:51 --> Config Class Initialized
INFO - 2024-10-19 12:24:51 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:24:51 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:24:51 --> Utf8 Class Initialized
INFO - 2024-10-19 12:24:51 --> URI Class Initialized
DEBUG - 2024-10-19 12:24:51 --> No URI present. Default controller set.
INFO - 2024-10-19 12:24:51 --> Router Class Initialized
INFO - 2024-10-19 12:24:51 --> Output Class Initialized
INFO - 2024-10-19 12:24:51 --> Security Class Initialized
DEBUG - 2024-10-19 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:24:51 --> Input Class Initialized
INFO - 2024-10-19 12:24:51 --> Language Class Initialized
INFO - 2024-10-19 12:24:51 --> Loader Class Initialized
INFO - 2024-10-19 12:24:51 --> Helper loaded: url_helper
INFO - 2024-10-19 12:24:51 --> Helper loaded: html_helper
INFO - 2024-10-19 12:24:51 --> Helper loaded: file_helper
INFO - 2024-10-19 12:24:51 --> Helper loaded: string_helper
INFO - 2024-10-19 12:24:51 --> Helper loaded: form_helper
INFO - 2024-10-19 12:24:51 --> Helper loaded: my_helper
INFO - 2024-10-19 12:24:51 --> Database Driver Class Initialized
INFO - 2024-10-19 12:24:53 --> Config Class Initialized
INFO - 2024-10-19 12:24:53 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:24:53 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:24:53 --> Utf8 Class Initialized
INFO - 2024-10-19 12:24:53 --> URI Class Initialized
DEBUG - 2024-10-19 12:24:53 --> No URI present. Default controller set.
INFO - 2024-10-19 12:24:53 --> Router Class Initialized
INFO - 2024-10-19 12:24:53 --> Output Class Initialized
INFO - 2024-10-19 12:24:53 --> Security Class Initialized
DEBUG - 2024-10-19 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:24:53 --> Input Class Initialized
INFO - 2024-10-19 12:24:53 --> Language Class Initialized
INFO - 2024-10-19 12:24:53 --> Loader Class Initialized
INFO - 2024-10-19 12:24:53 --> Helper loaded: url_helper
INFO - 2024-10-19 12:24:53 --> Helper loaded: html_helper
INFO - 2024-10-19 12:24:53 --> Helper loaded: file_helper
INFO - 2024-10-19 12:24:53 --> Helper loaded: string_helper
INFO - 2024-10-19 12:24:53 --> Helper loaded: form_helper
INFO - 2024-10-19 12:24:53 --> Helper loaded: my_helper
INFO - 2024-10-19 12:24:53 --> Database Driver Class Initialized
INFO - 2024-10-19 12:24:53 --> Upload Class Initialized
INFO - 2024-10-19 12:24:53 --> Email Class Initialized
INFO - 2024-10-19 12:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:24:53 --> Form Validation Class Initialized
INFO - 2024-10-19 12:24:53 --> Controller Class Initialized
INFO - 2024-10-19 17:54:53 --> Model "MainModel" initialized
INFO - 2024-10-19 17:54:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 17:54:53 --> Final output sent to browser
DEBUG - 2024-10-19 17:54:53 --> Total execution time: 2.2408
INFO - 2024-10-19 12:24:55 --> Upload Class Initialized
INFO - 2024-10-19 12:24:55 --> Email Class Initialized
INFO - 2024-10-19 12:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:24:55 --> Form Validation Class Initialized
INFO - 2024-10-19 12:24:55 --> Controller Class Initialized
INFO - 2024-10-19 17:54:55 --> Model "MainModel" initialized
INFO - 2024-10-19 17:54:55 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 17:54:55 --> Final output sent to browser
DEBUG - 2024-10-19 17:54:55 --> Total execution time: 2.1107
INFO - 2024-10-19 12:25:40 --> Config Class Initialized
INFO - 2024-10-19 12:25:40 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:25:40 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:25:40 --> Utf8 Class Initialized
INFO - 2024-10-19 12:25:40 --> URI Class Initialized
DEBUG - 2024-10-19 12:25:40 --> No URI present. Default controller set.
INFO - 2024-10-19 12:25:40 --> Router Class Initialized
INFO - 2024-10-19 12:25:40 --> Output Class Initialized
INFO - 2024-10-19 12:25:40 --> Security Class Initialized
DEBUG - 2024-10-19 12:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:25:40 --> Input Class Initialized
INFO - 2024-10-19 12:25:40 --> Language Class Initialized
INFO - 2024-10-19 12:25:40 --> Loader Class Initialized
INFO - 2024-10-19 12:25:40 --> Helper loaded: url_helper
INFO - 2024-10-19 12:25:40 --> Helper loaded: html_helper
INFO - 2024-10-19 12:25:40 --> Helper loaded: file_helper
INFO - 2024-10-19 12:25:40 --> Helper loaded: string_helper
INFO - 2024-10-19 12:25:40 --> Helper loaded: form_helper
INFO - 2024-10-19 12:25:40 --> Helper loaded: my_helper
INFO - 2024-10-19 12:25:40 --> Database Driver Class Initialized
INFO - 2024-10-19 12:25:42 --> Upload Class Initialized
INFO - 2024-10-19 12:25:42 --> Email Class Initialized
INFO - 2024-10-19 12:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:25:42 --> Form Validation Class Initialized
INFO - 2024-10-19 12:25:42 --> Controller Class Initialized
INFO - 2024-10-19 17:55:42 --> Model "MainModel" initialized
INFO - 2024-10-19 17:55:42 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 17:55:42 --> Final output sent to browser
DEBUG - 2024-10-19 17:55:42 --> Total execution time: 2.1433
INFO - 2024-10-19 12:35:21 --> Config Class Initialized
INFO - 2024-10-19 12:35:21 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:35:21 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:35:21 --> Utf8 Class Initialized
INFO - 2024-10-19 12:35:21 --> URI Class Initialized
DEBUG - 2024-10-19 12:35:21 --> No URI present. Default controller set.
INFO - 2024-10-19 12:35:21 --> Router Class Initialized
INFO - 2024-10-19 12:35:21 --> Output Class Initialized
INFO - 2024-10-19 12:35:21 --> Security Class Initialized
DEBUG - 2024-10-19 12:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:35:21 --> Input Class Initialized
INFO - 2024-10-19 12:35:21 --> Language Class Initialized
INFO - 2024-10-19 12:35:21 --> Loader Class Initialized
INFO - 2024-10-19 12:35:21 --> Helper loaded: url_helper
INFO - 2024-10-19 12:35:21 --> Helper loaded: html_helper
INFO - 2024-10-19 12:35:21 --> Helper loaded: file_helper
INFO - 2024-10-19 12:35:21 --> Helper loaded: string_helper
INFO - 2024-10-19 12:35:21 --> Helper loaded: form_helper
INFO - 2024-10-19 12:35:21 --> Helper loaded: my_helper
INFO - 2024-10-19 12:35:21 --> Database Driver Class Initialized
INFO - 2024-10-19 12:35:23 --> Upload Class Initialized
INFO - 2024-10-19 12:35:23 --> Email Class Initialized
INFO - 2024-10-19 12:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:35:24 --> Form Validation Class Initialized
INFO - 2024-10-19 12:35:24 --> Controller Class Initialized
INFO - 2024-10-19 18:05:24 --> Model "MainModel" initialized
INFO - 2024-10-19 18:05:24 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 18:05:24 --> Final output sent to browser
DEBUG - 2024-10-19 18:05:24 --> Total execution time: 2.1542
INFO - 2024-10-19 12:35:32 --> Config Class Initialized
INFO - 2024-10-19 12:35:32 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:35:32 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:35:32 --> Utf8 Class Initialized
INFO - 2024-10-19 12:35:32 --> URI Class Initialized
DEBUG - 2024-10-19 12:35:32 --> No URI present. Default controller set.
INFO - 2024-10-19 12:35:32 --> Router Class Initialized
INFO - 2024-10-19 12:35:32 --> Output Class Initialized
INFO - 2024-10-19 12:35:32 --> Security Class Initialized
DEBUG - 2024-10-19 12:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:35:32 --> Input Class Initialized
INFO - 2024-10-19 12:35:32 --> Language Class Initialized
INFO - 2024-10-19 12:35:32 --> Loader Class Initialized
INFO - 2024-10-19 12:35:32 --> Helper loaded: url_helper
INFO - 2024-10-19 12:35:32 --> Helper loaded: html_helper
INFO - 2024-10-19 12:35:32 --> Helper loaded: file_helper
INFO - 2024-10-19 12:35:32 --> Helper loaded: string_helper
INFO - 2024-10-19 12:35:32 --> Helper loaded: form_helper
INFO - 2024-10-19 12:35:32 --> Helper loaded: my_helper
INFO - 2024-10-19 12:35:32 --> Database Driver Class Initialized
INFO - 2024-10-19 12:35:34 --> Upload Class Initialized
INFO - 2024-10-19 12:35:34 --> Email Class Initialized
INFO - 2024-10-19 12:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:35:34 --> Form Validation Class Initialized
INFO - 2024-10-19 12:35:34 --> Controller Class Initialized
INFO - 2024-10-19 18:05:34 --> Model "MainModel" initialized
INFO - 2024-10-19 18:05:34 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 18:05:34 --> Final output sent to browser
DEBUG - 2024-10-19 18:05:34 --> Total execution time: 2.1525
INFO - 2024-10-19 12:41:09 --> Config Class Initialized
INFO - 2024-10-19 12:41:09 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:41:09 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:41:09 --> Utf8 Class Initialized
INFO - 2024-10-19 12:41:09 --> URI Class Initialized
DEBUG - 2024-10-19 12:41:09 --> No URI present. Default controller set.
INFO - 2024-10-19 12:41:09 --> Router Class Initialized
INFO - 2024-10-19 12:41:09 --> Output Class Initialized
INFO - 2024-10-19 12:41:09 --> Security Class Initialized
DEBUG - 2024-10-19 12:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:41:09 --> Input Class Initialized
INFO - 2024-10-19 12:41:09 --> Language Class Initialized
INFO - 2024-10-19 12:41:09 --> Loader Class Initialized
INFO - 2024-10-19 12:41:09 --> Helper loaded: url_helper
INFO - 2024-10-19 12:41:09 --> Helper loaded: html_helper
INFO - 2024-10-19 12:41:09 --> Helper loaded: file_helper
INFO - 2024-10-19 12:41:09 --> Helper loaded: string_helper
INFO - 2024-10-19 12:41:09 --> Helper loaded: form_helper
INFO - 2024-10-19 12:41:09 --> Helper loaded: my_helper
INFO - 2024-10-19 12:41:09 --> Database Driver Class Initialized
INFO - 2024-10-19 12:41:11 --> Upload Class Initialized
INFO - 2024-10-19 12:41:11 --> Email Class Initialized
INFO - 2024-10-19 12:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:41:11 --> Form Validation Class Initialized
INFO - 2024-10-19 12:41:11 --> Controller Class Initialized
INFO - 2024-10-19 18:11:11 --> Model "MainModel" initialized
INFO - 2024-10-19 18:11:11 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 18:11:11 --> Final output sent to browser
DEBUG - 2024-10-19 18:11:11 --> Total execution time: 2.2069
INFO - 2024-10-19 12:41:59 --> Config Class Initialized
INFO - 2024-10-19 12:41:59 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:41:59 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:41:59 --> Utf8 Class Initialized
INFO - 2024-10-19 12:41:59 --> URI Class Initialized
DEBUG - 2024-10-19 12:41:59 --> No URI present. Default controller set.
INFO - 2024-10-19 12:41:59 --> Router Class Initialized
INFO - 2024-10-19 12:41:59 --> Output Class Initialized
INFO - 2024-10-19 12:41:59 --> Security Class Initialized
DEBUG - 2024-10-19 12:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:41:59 --> Input Class Initialized
INFO - 2024-10-19 12:41:59 --> Language Class Initialized
INFO - 2024-10-19 12:41:59 --> Loader Class Initialized
INFO - 2024-10-19 12:41:59 --> Helper loaded: url_helper
INFO - 2024-10-19 12:41:59 --> Helper loaded: html_helper
INFO - 2024-10-19 12:41:59 --> Helper loaded: file_helper
INFO - 2024-10-19 12:41:59 --> Helper loaded: string_helper
INFO - 2024-10-19 12:41:59 --> Helper loaded: form_helper
INFO - 2024-10-19 12:41:59 --> Helper loaded: my_helper
INFO - 2024-10-19 12:41:59 --> Database Driver Class Initialized
INFO - 2024-10-19 12:42:01 --> Upload Class Initialized
INFO - 2024-10-19 12:42:01 --> Email Class Initialized
INFO - 2024-10-19 12:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:42:01 --> Form Validation Class Initialized
INFO - 2024-10-19 12:42:01 --> Controller Class Initialized
INFO - 2024-10-19 18:12:01 --> Model "MainModel" initialized
INFO - 2024-10-19 18:12:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 18:12:01 --> Final output sent to browser
DEBUG - 2024-10-19 18:12:01 --> Total execution time: 2.5134
INFO - 2024-10-19 12:42:02 --> Config Class Initialized
INFO - 2024-10-19 12:42:02 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:42:02 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:42:02 --> Utf8 Class Initialized
INFO - 2024-10-19 12:42:02 --> URI Class Initialized
DEBUG - 2024-10-19 12:42:02 --> No URI present. Default controller set.
INFO - 2024-10-19 12:42:02 --> Router Class Initialized
INFO - 2024-10-19 12:42:02 --> Output Class Initialized
INFO - 2024-10-19 12:42:02 --> Security Class Initialized
DEBUG - 2024-10-19 12:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:42:02 --> Input Class Initialized
INFO - 2024-10-19 12:42:02 --> Language Class Initialized
INFO - 2024-10-19 12:42:02 --> Loader Class Initialized
INFO - 2024-10-19 12:42:02 --> Helper loaded: url_helper
INFO - 2024-10-19 12:42:02 --> Helper loaded: html_helper
INFO - 2024-10-19 12:42:02 --> Helper loaded: file_helper
INFO - 2024-10-19 12:42:02 --> Helper loaded: string_helper
INFO - 2024-10-19 12:42:02 --> Helper loaded: form_helper
INFO - 2024-10-19 12:42:02 --> Helper loaded: my_helper
INFO - 2024-10-19 12:42:02 --> Database Driver Class Initialized
INFO - 2024-10-19 12:42:04 --> Upload Class Initialized
INFO - 2024-10-19 12:42:04 --> Email Class Initialized
INFO - 2024-10-19 12:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:42:04 --> Form Validation Class Initialized
INFO - 2024-10-19 12:42:04 --> Controller Class Initialized
INFO - 2024-10-19 18:12:04 --> Model "MainModel" initialized
INFO - 2024-10-19 18:12:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 18:12:04 --> Final output sent to browser
DEBUG - 2024-10-19 18:12:04 --> Total execution time: 2.1276
INFO - 2024-10-19 15:00:43 --> Config Class Initialized
INFO - 2024-10-19 15:00:43 --> Hooks Class Initialized
DEBUG - 2024-10-19 15:00:43 --> UTF-8 Support Enabled
INFO - 2024-10-19 15:00:43 --> Utf8 Class Initialized
INFO - 2024-10-19 15:00:43 --> URI Class Initialized
DEBUG - 2024-10-19 15:00:43 --> No URI present. Default controller set.
INFO - 2024-10-19 15:00:43 --> Router Class Initialized
INFO - 2024-10-19 15:00:43 --> Output Class Initialized
INFO - 2024-10-19 15:00:43 --> Security Class Initialized
DEBUG - 2024-10-19 15:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 15:00:43 --> Input Class Initialized
INFO - 2024-10-19 15:00:43 --> Language Class Initialized
INFO - 2024-10-19 15:00:43 --> Loader Class Initialized
INFO - 2024-10-19 15:00:43 --> Helper loaded: url_helper
INFO - 2024-10-19 15:00:43 --> Helper loaded: html_helper
INFO - 2024-10-19 15:00:43 --> Helper loaded: file_helper
INFO - 2024-10-19 15:00:43 --> Helper loaded: string_helper
INFO - 2024-10-19 15:00:43 --> Helper loaded: form_helper
INFO - 2024-10-19 15:00:43 --> Helper loaded: my_helper
INFO - 2024-10-19 15:00:43 --> Database Driver Class Initialized
INFO - 2024-10-19 15:00:46 --> Upload Class Initialized
INFO - 2024-10-19 15:00:46 --> Email Class Initialized
INFO - 2024-10-19 15:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 15:00:46 --> Form Validation Class Initialized
INFO - 2024-10-19 15:00:46 --> Controller Class Initialized
INFO - 2024-10-19 20:30:46 --> Model "MainModel" initialized
INFO - 2024-10-19 20:30:46 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 20:30:46 --> Final output sent to browser
DEBUG - 2024-10-19 20:30:46 --> Total execution time: 2.2206
INFO - 2024-10-19 15:00:57 --> Config Class Initialized
INFO - 2024-10-19 15:00:57 --> Hooks Class Initialized
DEBUG - 2024-10-19 15:00:57 --> UTF-8 Support Enabled
INFO - 2024-10-19 15:00:57 --> Utf8 Class Initialized
INFO - 2024-10-19 15:00:57 --> URI Class Initialized
DEBUG - 2024-10-19 15:00:57 --> No URI present. Default controller set.
INFO - 2024-10-19 15:00:57 --> Router Class Initialized
INFO - 2024-10-19 15:00:57 --> Output Class Initialized
INFO - 2024-10-19 15:00:57 --> Security Class Initialized
DEBUG - 2024-10-19 15:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 15:00:57 --> Input Class Initialized
INFO - 2024-10-19 15:00:57 --> Language Class Initialized
INFO - 2024-10-19 15:00:57 --> Loader Class Initialized
INFO - 2024-10-19 15:00:57 --> Helper loaded: url_helper
INFO - 2024-10-19 15:00:57 --> Helper loaded: html_helper
INFO - 2024-10-19 15:00:57 --> Helper loaded: file_helper
INFO - 2024-10-19 15:00:57 --> Helper loaded: string_helper
INFO - 2024-10-19 15:00:57 --> Helper loaded: form_helper
INFO - 2024-10-19 15:00:57 --> Helper loaded: my_helper
INFO - 2024-10-19 15:00:57 --> Database Driver Class Initialized
INFO - 2024-10-19 15:00:59 --> Upload Class Initialized
INFO - 2024-10-19 15:00:59 --> Email Class Initialized
INFO - 2024-10-19 15:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 15:00:59 --> Form Validation Class Initialized
INFO - 2024-10-19 15:00:59 --> Controller Class Initialized
INFO - 2024-10-19 20:30:59 --> Model "MainModel" initialized
INFO - 2024-10-19 20:30:59 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 20:30:59 --> Final output sent to browser
DEBUG - 2024-10-19 20:30:59 --> Total execution time: 2.1571
INFO - 2024-10-19 15:57:59 --> Config Class Initialized
INFO - 2024-10-19 15:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-19 15:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-19 15:57:59 --> Utf8 Class Initialized
INFO - 2024-10-19 15:57:59 --> URI Class Initialized
DEBUG - 2024-10-19 15:57:59 --> No URI present. Default controller set.
INFO - 2024-10-19 15:57:59 --> Router Class Initialized
INFO - 2024-10-19 15:57:59 --> Output Class Initialized
INFO - 2024-10-19 15:57:59 --> Security Class Initialized
DEBUG - 2024-10-19 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 15:57:59 --> Input Class Initialized
INFO - 2024-10-19 15:57:59 --> Language Class Initialized
INFO - 2024-10-19 15:57:59 --> Loader Class Initialized
INFO - 2024-10-19 15:57:59 --> Helper loaded: url_helper
INFO - 2024-10-19 15:57:59 --> Helper loaded: html_helper
INFO - 2024-10-19 15:57:59 --> Helper loaded: file_helper
INFO - 2024-10-19 15:57:59 --> Helper loaded: string_helper
INFO - 2024-10-19 15:57:59 --> Helper loaded: form_helper
INFO - 2024-10-19 15:57:59 --> Helper loaded: my_helper
INFO - 2024-10-19 15:57:59 --> Database Driver Class Initialized
INFO - 2024-10-19 15:58:01 --> Upload Class Initialized
INFO - 2024-10-19 15:58:01 --> Email Class Initialized
INFO - 2024-10-19 15:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 15:58:01 --> Form Validation Class Initialized
INFO - 2024-10-19 15:58:01 --> Controller Class Initialized
INFO - 2024-10-19 21:28:01 --> Model "MainModel" initialized
INFO - 2024-10-19 21:28:01 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 21:28:01 --> Final output sent to browser
DEBUG - 2024-10-19 21:28:01 --> Total execution time: 2.1881
INFO - 2024-10-19 15:58:51 --> Config Class Initialized
INFO - 2024-10-19 15:58:51 --> Hooks Class Initialized
DEBUG - 2024-10-19 15:58:51 --> UTF-8 Support Enabled
INFO - 2024-10-19 15:58:51 --> Utf8 Class Initialized
INFO - 2024-10-19 15:58:51 --> URI Class Initialized
DEBUG - 2024-10-19 15:58:51 --> No URI present. Default controller set.
INFO - 2024-10-19 15:58:51 --> Router Class Initialized
INFO - 2024-10-19 15:58:51 --> Output Class Initialized
INFO - 2024-10-19 15:58:51 --> Security Class Initialized
DEBUG - 2024-10-19 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 15:58:51 --> Input Class Initialized
INFO - 2024-10-19 15:58:51 --> Language Class Initialized
INFO - 2024-10-19 15:58:51 --> Loader Class Initialized
INFO - 2024-10-19 15:58:51 --> Helper loaded: url_helper
INFO - 2024-10-19 15:58:51 --> Helper loaded: html_helper
INFO - 2024-10-19 15:58:51 --> Helper loaded: file_helper
INFO - 2024-10-19 15:58:51 --> Helper loaded: string_helper
INFO - 2024-10-19 15:58:51 --> Helper loaded: form_helper
INFO - 2024-10-19 15:58:51 --> Helper loaded: my_helper
INFO - 2024-10-19 15:58:51 --> Database Driver Class Initialized
INFO - 2024-10-19 15:58:53 --> Upload Class Initialized
INFO - 2024-10-19 15:58:53 --> Email Class Initialized
INFO - 2024-10-19 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 15:58:53 --> Form Validation Class Initialized
INFO - 2024-10-19 15:58:53 --> Controller Class Initialized
INFO - 2024-10-19 21:28:53 --> Model "MainModel" initialized
INFO - 2024-10-19 21:28:53 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 21:28:53 --> Final output sent to browser
DEBUG - 2024-10-19 21:28:53 --> Total execution time: 2.1284
INFO - 2024-10-19 16:26:23 --> Config Class Initialized
INFO - 2024-10-19 16:26:23 --> Hooks Class Initialized
DEBUG - 2024-10-19 16:26:23 --> UTF-8 Support Enabled
INFO - 2024-10-19 16:26:23 --> Utf8 Class Initialized
INFO - 2024-10-19 16:26:23 --> URI Class Initialized
DEBUG - 2024-10-19 16:26:23 --> No URI present. Default controller set.
INFO - 2024-10-19 16:26:23 --> Router Class Initialized
INFO - 2024-10-19 16:26:23 --> Output Class Initialized
INFO - 2024-10-19 16:26:23 --> Security Class Initialized
DEBUG - 2024-10-19 16:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 16:26:23 --> Input Class Initialized
INFO - 2024-10-19 16:26:23 --> Language Class Initialized
INFO - 2024-10-19 16:26:23 --> Loader Class Initialized
INFO - 2024-10-19 16:26:23 --> Helper loaded: url_helper
INFO - 2024-10-19 16:26:23 --> Helper loaded: html_helper
INFO - 2024-10-19 16:26:23 --> Helper loaded: file_helper
INFO - 2024-10-19 16:26:23 --> Helper loaded: string_helper
INFO - 2024-10-19 16:26:23 --> Helper loaded: form_helper
INFO - 2024-10-19 16:26:23 --> Helper loaded: my_helper
INFO - 2024-10-19 16:26:23 --> Database Driver Class Initialized
INFO - 2024-10-19 16:26:25 --> Upload Class Initialized
INFO - 2024-10-19 16:26:25 --> Email Class Initialized
INFO - 2024-10-19 16:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 16:26:25 --> Form Validation Class Initialized
INFO - 2024-10-19 16:26:25 --> Controller Class Initialized
INFO - 2024-10-19 21:56:25 --> Model "MainModel" initialized
INFO - 2024-10-19 21:56:25 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 21:56:25 --> Final output sent to browser
DEBUG - 2024-10-19 21:56:25 --> Total execution time: 2.1972
INFO - 2024-10-19 16:57:02 --> Config Class Initialized
INFO - 2024-10-19 16:57:02 --> Hooks Class Initialized
DEBUG - 2024-10-19 16:57:02 --> UTF-8 Support Enabled
INFO - 2024-10-19 16:57:02 --> Utf8 Class Initialized
INFO - 2024-10-19 16:57:02 --> URI Class Initialized
DEBUG - 2024-10-19 16:57:02 --> No URI present. Default controller set.
INFO - 2024-10-19 16:57:02 --> Router Class Initialized
INFO - 2024-10-19 16:57:02 --> Output Class Initialized
INFO - 2024-10-19 16:57:02 --> Security Class Initialized
DEBUG - 2024-10-19 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 16:57:02 --> Input Class Initialized
INFO - 2024-10-19 16:57:02 --> Language Class Initialized
INFO - 2024-10-19 16:57:02 --> Loader Class Initialized
INFO - 2024-10-19 16:57:02 --> Helper loaded: url_helper
INFO - 2024-10-19 16:57:02 --> Helper loaded: html_helper
INFO - 2024-10-19 16:57:02 --> Helper loaded: file_helper
INFO - 2024-10-19 16:57:02 --> Helper loaded: string_helper
INFO - 2024-10-19 16:57:02 --> Helper loaded: form_helper
INFO - 2024-10-19 16:57:02 --> Helper loaded: my_helper
INFO - 2024-10-19 16:57:02 --> Database Driver Class Initialized
INFO - 2024-10-19 16:57:04 --> Upload Class Initialized
INFO - 2024-10-19 16:57:04 --> Email Class Initialized
INFO - 2024-10-19 16:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 16:57:04 --> Form Validation Class Initialized
INFO - 2024-10-19 16:57:04 --> Controller Class Initialized
INFO - 2024-10-19 22:27:04 --> Model "MainModel" initialized
INFO - 2024-10-19 22:27:04 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 22:27:04 --> Final output sent to browser
DEBUG - 2024-10-19 22:27:04 --> Total execution time: 2.2128
INFO - 2024-10-19 17:01:28 --> Config Class Initialized
INFO - 2024-10-19 17:01:28 --> Hooks Class Initialized
DEBUG - 2024-10-19 17:01:29 --> UTF-8 Support Enabled
INFO - 2024-10-19 17:01:29 --> Utf8 Class Initialized
INFO - 2024-10-19 17:01:29 --> URI Class Initialized
DEBUG - 2024-10-19 17:01:29 --> No URI present. Default controller set.
INFO - 2024-10-19 17:01:29 --> Router Class Initialized
INFO - 2024-10-19 17:01:29 --> Output Class Initialized
INFO - 2024-10-19 17:01:29 --> Security Class Initialized
DEBUG - 2024-10-19 17:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 17:01:29 --> Input Class Initialized
INFO - 2024-10-19 17:01:29 --> Language Class Initialized
INFO - 2024-10-19 17:01:29 --> Loader Class Initialized
INFO - 2024-10-19 17:01:29 --> Helper loaded: url_helper
INFO - 2024-10-19 17:01:29 --> Helper loaded: html_helper
INFO - 2024-10-19 17:01:29 --> Helper loaded: file_helper
INFO - 2024-10-19 17:01:29 --> Helper loaded: string_helper
INFO - 2024-10-19 17:01:29 --> Helper loaded: form_helper
INFO - 2024-10-19 17:01:29 --> Helper loaded: my_helper
INFO - 2024-10-19 17:01:29 --> Database Driver Class Initialized
INFO - 2024-10-19 17:01:31 --> Upload Class Initialized
INFO - 2024-10-19 17:01:31 --> Email Class Initialized
INFO - 2024-10-19 17:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 17:01:31 --> Form Validation Class Initialized
INFO - 2024-10-19 17:01:31 --> Controller Class Initialized
INFO - 2024-10-19 22:31:31 --> Model "MainModel" initialized
INFO - 2024-10-19 22:31:31 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 22:31:31 --> Final output sent to browser
DEBUG - 2024-10-19 22:31:31 --> Total execution time: 2.1309
INFO - 2024-10-19 17:53:25 --> Config Class Initialized
INFO - 2024-10-19 17:53:25 --> Hooks Class Initialized
DEBUG - 2024-10-19 17:53:25 --> UTF-8 Support Enabled
INFO - 2024-10-19 17:53:25 --> Utf8 Class Initialized
INFO - 2024-10-19 17:53:25 --> URI Class Initialized
DEBUG - 2024-10-19 17:53:25 --> No URI present. Default controller set.
INFO - 2024-10-19 17:53:25 --> Router Class Initialized
INFO - 2024-10-19 17:53:25 --> Output Class Initialized
INFO - 2024-10-19 17:53:25 --> Security Class Initialized
DEBUG - 2024-10-19 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 17:53:25 --> Input Class Initialized
INFO - 2024-10-19 17:53:25 --> Language Class Initialized
INFO - 2024-10-19 17:53:25 --> Loader Class Initialized
INFO - 2024-10-19 17:53:25 --> Helper loaded: url_helper
INFO - 2024-10-19 17:53:25 --> Helper loaded: html_helper
INFO - 2024-10-19 17:53:25 --> Helper loaded: file_helper
INFO - 2024-10-19 17:53:25 --> Helper loaded: string_helper
INFO - 2024-10-19 17:53:25 --> Helper loaded: form_helper
INFO - 2024-10-19 17:53:25 --> Helper loaded: my_helper
INFO - 2024-10-19 17:53:26 --> Database Driver Class Initialized
INFO - 2024-10-19 17:53:28 --> Upload Class Initialized
INFO - 2024-10-19 17:53:28 --> Email Class Initialized
INFO - 2024-10-19 17:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 17:53:28 --> Form Validation Class Initialized
INFO - 2024-10-19 17:53:28 --> Controller Class Initialized
INFO - 2024-10-19 23:23:28 --> Model "MainModel" initialized
INFO - 2024-10-19 23:23:28 --> File loaded: C:\inetpub\vhosts\livservice.in\httpdocs\application\views\auth/login.php
INFO - 2024-10-19 23:23:28 --> Final output sent to browser
DEBUG - 2024-10-19 23:23:28 --> Total execution time: 2.2909
INFO - 2024-10-19 18:37:54 --> Config Class Initialized
INFO - 2024-10-19 18:37:54 --> Hooks Class Initialized
DEBUG - 2024-10-19 18:37:54 --> UTF-8 Support Enabled
INFO - 2024-10-19 18:37:54 --> Utf8 Class Initialized
INFO - 2024-10-19 18:37:54 --> URI Class Initialized
DEBUG - 2024-10-19 18:37:54 --> No URI present. Default controller set.
INFO - 2024-10-19 18:37:54 --> Router Class Initialized
INFO - 2024-10-19 18:37:54 --> Output Class Initialized
INFO - 2024-10-19 18:37:54 --> Security Class Initialized
DEBUG - 2024-10-19 18:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 18:37:54 --> Input Class Initialized
INFO - 2024-10-19 18:37:54 --> Language Class Initialized
INFO - 2024-10-19 18:37:54 --> Loader Class Initialized
INFO - 2024-10-19 18:37:54 --> Helper loaded: url_helper
INFO - 2024-10-19 18:37:54 --> Helper loaded: html_helper
INFO - 2024-10-19 18:37:54 --> Helper loaded: file_helper
INFO - 2024-10-19 18:37:54 --> Helper loaded: string_helper
INFO - 2024-10-19 18:37:54 --> Helper loaded: form_helper
INFO - 2024-10-19 18:37:54 --> Helper loaded: my_helper
INFO - 2024-10-19 18:37:54 --> Database Driver Class Initialized
INFO - 2024-10-19 18:37:56 --> Upload Class Initialized
INFO - 2024-10-19 18:37:56 --> Email Class Initialized
INFO - 2024-10-19 18:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 18:37:56 --> Form Validation Class Initialized
INFO - 2024-10-19 18:37:56 --> Controller Class Initialized
INFO - 2024-10-19 21:30:33 --> Config Class Initialized
INFO - 2024-10-19 21:30:35 --> Hooks Class Initialized
DEBUG - 2024-10-19 21:30:36 --> UTF-8 Support Enabled
INFO - 2024-10-19 21:30:36 --> Utf8 Class Initialized
INFO - 2024-10-19 21:30:36 --> URI Class Initialized
DEBUG - 2024-10-19 21:30:36 --> No URI present. Default controller set.
INFO - 2024-10-19 21:30:36 --> Router Class Initialized
INFO - 2024-10-19 21:30:36 --> Output Class Initialized
INFO - 2024-10-19 21:30:37 --> Security Class Initialized
DEBUG - 2024-10-19 21:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 21:30:37 --> Input Class Initialized
INFO - 2024-10-19 21:30:37 --> Language Class Initialized
INFO - 2024-10-19 21:30:37 --> Loader Class Initialized
INFO - 2024-10-19 21:30:37 --> Helper loaded: url_helper
INFO - 2024-10-19 21:30:37 --> Helper loaded: html_helper
INFO - 2024-10-19 21:30:37 --> Helper loaded: file_helper
INFO - 2024-10-19 21:30:37 --> Helper loaded: string_helper
INFO - 2024-10-19 21:30:37 --> Helper loaded: form_helper
INFO - 2024-10-19 21:30:37 --> Helper loaded: my_helper
INFO - 2024-10-19 21:30:38 --> Database Driver Class Initialized
INFO - 2024-10-19 21:30:40 --> Upload Class Initialized
INFO - 2024-10-19 21:30:41 --> Email Class Initialized
INFO - 2024-10-19 21:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 21:30:42 --> Form Validation Class Initialized
INFO - 2024-10-19 21:30:42 --> Controller Class Initialized
INFO - 2024-10-19 22:13:48 --> Config Class Initialized
INFO - 2024-10-19 22:14:54 --> Config Class Initialized
INFO - 2024-10-19 22:14:54 --> Hooks Class Initialized
INFO - 2024-10-19 22:14:54 --> Config Class Initialized
INFO - 2024-10-19 22:14:54 --> Hooks Class Initialized
ERROR - 2024-10-19 22:14:55 --> Severity: Error --> Maximum execution time of 60 seconds exceeded C:\inetpub\vhosts\livservice.in\httpdocs\system\core\Log.php 199
DEBUG - 2024-10-19 22:14:55 --> UTF-8 Support Enabled
INFO - 2024-10-19 22:14:55 --> Utf8 Class Initialized
DEBUG - 2024-10-19 22:14:55 --> UTF-8 Support Enabled
INFO - 2024-10-19 22:14:55 --> Utf8 Class Initialized
INFO - 2024-10-19 22:14:55 --> URI Class Initialized
INFO - 2024-10-19 22:14:55 --> URI Class Initialized
DEBUG - 2024-10-19 22:14:55 --> No URI present. Default controller set.
DEBUG - 2024-10-19 22:14:55 --> No URI present. Default controller set.
INFO - 2024-10-19 22:14:55 --> Router Class Initialized
INFO - 2024-10-19 22:14:55 --> Router Class Initialized
INFO - 2024-10-19 22:14:55 --> Output Class Initialized
INFO - 2024-10-19 22:14:55 --> Output Class Initialized
INFO - 2024-10-19 22:14:55 --> Security Class Initialized
INFO - 2024-10-19 22:14:55 --> Security Class Initialized
DEBUG - 2024-10-19 22:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-10-19 22:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 22:14:55 --> Input Class Initialized
INFO - 2024-10-19 22:14:55 --> Input Class Initialized
INFO - 2024-10-19 22:14:55 --> Language Class Initialized
INFO - 2024-10-19 22:14:55 --> Language Class Initialized
INFO - 2024-10-19 22:14:55 --> Loader Class Initialized
INFO - 2024-10-19 22:14:55 --> Loader Class Initialized
INFO - 2024-10-19 22:14:55 --> Helper loaded: url_helper
INFO - 2024-10-19 22:14:55 --> Helper loaded: url_helper
INFO - 2024-10-19 22:14:55 --> Helper loaded: html_helper
INFO - 2024-10-19 22:14:55 --> Helper loaded: html_helper
INFO - 2024-10-19 22:14:55 --> Helper loaded: file_helper
INFO - 2024-10-19 22:14:55 --> Helper loaded: file_helper
INFO - 2024-10-19 22:14:55 --> Helper loaded: string_helper
INFO - 2024-10-19 22:14:55 --> Helper loaded: string_helper
INFO - 2024-10-19 22:14:56 --> Helper loaded: form_helper
INFO - 2024-10-19 22:14:56 --> Helper loaded: form_helper
INFO - 2024-10-19 22:14:56 --> Helper loaded: my_helper
INFO - 2024-10-19 22:14:56 --> Helper loaded: my_helper
INFO - 2024-10-19 22:14:56 --> Database Driver Class Initialized
INFO - 2024-10-19 22:14:56 --> Database Driver Class Initialized
INFO - 2024-10-19 22:14:58 --> Upload Class Initialized
INFO - 2024-10-19 22:14:58 --> Upload Class Initialized
INFO - 2024-10-19 22:14:58 --> Email Class Initialized
INFO - 2024-10-19 22:14:58 --> Email Class Initialized
INFO - 2024-10-19 22:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 22:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 22:14:58 --> Form Validation Class Initialized
INFO - 2024-10-19 22:14:58 --> Controller Class Initialized
INFO - 2024-10-19 22:14:58 --> Form Validation Class Initialized
INFO - 2024-10-19 22:14:58 --> Controller Class Initialized
