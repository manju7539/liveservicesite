<?php
                     $j = 1;
                     
                     if($luggage_request)
                     {
                         foreach($luggage_request as $lug_r)
                         {
                             $wh = '(u_id = "'.$lug_r['u_id'].'")';
                     
                             $user_data = $this->HotelAdminModel->getData('register',$wh);
                     
                             if($user_data)
                             { 
                                 
                     
                     ?>
                  <tr>
                     <td><strong><?php echo $j++?></strong></td>
                     <td><?php echo $user_data['full_name'] ?></td>
                     <td><?php echo $user_data['mobile_no'] ?></td>
                     <td><?php echo $lug_r['select_date'] ?></td>
                     <td><?php echo date('h:i a',strtotime($lug_r['select_time'])) ?></td>
                     <td><?php echo $lug_r['luggage_type'] ?></td>
                     <td><?php echo $lug_r['quantity'] ?></td>
                     <!-- <td>
                        <button
                            class="btn btn-secondary_<?php echo $lug_r['luggage_request_id'] ?> shadow btn-xs sharp me-1"><i
                                class="fas fa-eye"></i></button>
                        </td> -->
                     <td>
                        <a style="margin:auto" data-bs-toggle="modal"
                           data-bs-target=".bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>"
                           class="btn btn-secondary shadow btn-xs sharp"><i
                           class="fa fa-eye"></i></a>
                     </td>
                     <td>

                     <?php
                                 if($lug_r['request_status'] == 1)	
                                 {
                                 ?>
                              <span class="badge badge-danger">Accepted</span>
                             
                              <?php
                        }
                        else
                        {
                        ?>
                     

                     <a onclick="return confirm('Are you sure you want to accept this request?')" href="<?php echo base_url('HoteladminController/accept_cloakroom_service_request/'.$lug_r['luggage_request_id'])?>" class="submit"><span class="badge badge-success">Accept</span></a>
                        <a onclick="return confirm('Are you sure you want to reject this request?')" href="<?php echo base_url('HoteladminController/reject_cloakroom_service_request/'.$lug_r['luggage_request_id'])?>" class="submit"><span class="badge badge-warning">Reject</span></a>
                              <?php
                                 }
                                 ?>
                       
                     </td>
                  </tr>
                  <div class="modal fade bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-header">
                              <h5 class="modal-title">Description</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal">
                              </button>
                           </div>
                           <div class="modal-body">
                              <div class="col-lg-12">
                                 <span><?php echo $lug_r['note'] ?></span>
                              </div>
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php
                     }
                     }
                     }
                     ?>