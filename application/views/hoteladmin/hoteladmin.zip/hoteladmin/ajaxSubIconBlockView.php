<div class="alert alert-success successmessage11" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Spa Data Added Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success successmessage12" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Carwash Data Added Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success successmessage13" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Luggage Data Added Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success successmessage14" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Cab Data Added Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success successmessage15" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Cab Status Change Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success status_completed" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Spa Status Changed Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success status_completed2" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Car wash Status Changed Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success status_completed3" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">luggage Status Changed Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success status_completed4" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Cab Status Changed Successfully..!</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<div class="alert alert-success updatemessage" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
   <strong style="color:#fff ;margin-top:10px;">Status Changed Sucessfully !..</strong>
   <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
</div>
<style>
   .toggle.btn-xs {
      min-width: 35px;
      min-height: 35px;
   }

   .box {
      color: #fff;
      padding: 20px;
      display: none;
      margin-top: 20px;
   }

   .red {
      background: #fff;
   }

   .green {
      background: #e23428;
   }

   .form-control:disabled,
   .form-control[readonly] {
      background-color: white;
   }

   label {
      margin-right: 15px;
      color: black;
   }
</style>
<style>
   input[value="Green"]:checked~.colored-div {
      background-color: #7cc142;
      color: white;
   }

   .alfabetBox {
      display: none;
   }

   .room_card {
      border-bottom: 1px solid #242426;
      border-radius: 5px;
      box-shadow: 0 3px 5px rgba(0, 0, 0, .16), 0 1px 3px rgba(0, 0, 0, .23) !important;
      margin: 7px;
      height: 40px;
      width: 54px;
   }

   .room_no {
      font-weight: 800;
      color: #202020;
      text-align: center;
      padding-top: 14px;
   }

   .red {
      background-color: #c8c8c8;
   }

   .radio {
      font-size: inherit;
      margin: 0;
      position: absolute;
      right: 0;
      top: calc(var(--card-padding) + var(--radio-border-width));
      width: 11px;
      height: 11px;
   }

   .checkbox_css {
      width: 20px;
      height: 20px;
   }
</style>
<style>
   .invoice-container {
      margin: 15px auto;
      padding: 70px;
      max-width: 650px;
      background-color: #fff;
      border: 1px solid #ccc;
      -moz-border-radius: 6px;
      -webkit-border-radius: 6px;
      -o-border-radius: 6px;
      border-radius: 6px;
   }

   .invoice-container .card1 {
      position: relative;
      display: flex;
      flex-direction: column;
      min-width: 0;
      word-wrap: break-word;
      background-color: #fff;
      background-clip: border-box;
      border: 1pxsolidrgba(0, 0, 0, .125);
      border-radius: 0.25rem;
   }

   @media (max-width: 767px) {
      .invoice-container {
         padding: 35px 20px 70px 20px;
         margin-top: 0px;
         border: none;
         border-radius: 0px;
      }
   }

   #example1_wrapper,
   #acceptedOrder_tb_wrapper,
   #acceptedOrder_tb1_wrapper,
   #completedOrder_tb_wrapper,
   #acceptedOrder_tb2_wrapper,
   #rejectedOrder_tb_wrapper,
   #rejectedOrder_tb1_wrapper,
   #arrival_tbl_wrapper {
      padding: 0px;
   }
</style>
<script src="<?php echo base_url('assets/plugins/summernote/summernote.min.js') ?>"></script>
<script src="<?php echo base_url('assets/js/pages/summernote/summernote-data.js') ?>"></script>
<?php if ($sub_icon_id == 1) { ?>
   <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
   <div class="col-md-12">
      <div class="card card-topline-aqua">
         <div class="card-head">
            <header>Gym Information</header>
         </div>
         <div class="table-scrollable" id="gym_data">
            <table id="example1" class="display full-width">
               <thead>
                  <tr>
                     <th><strong>Sr. No.</strong></th>
                     <th><strong>Staff Name</strong></th>
                     <th><strong>Contact No.</strong></th>
                     <th><strong>Open Time </strong></th>
                     <th><strong>Break Time</strong></th>
                     <th><strong>Description</strong></th>
                     <th><strong>Terms & Condition</strong></th>
                     <th><strong>Pictures</strong></th>
                     <th><strong>Action</strong></th>
                  </tr>
               </thead>
               <tbody class="gym_new_data">
                  <?php
                  $i = 1;
                  if ($list) {
                     foreach ($list as $g_f_s) {
                        $wh = '(front_ofs_service_id = "' . $g_f_s['front_ofs_service_id'] . '")';

                        $services_img = $this->HotelAdminModel->getData('front_ofs_services_images', $wh);
                  ?>
                        <tr>
                           <td><?php echo $i++ ?></td>
                           <td><?php echo $g_f_s['staff_name'] ?></td>
                           <td><?php echo $g_f_s['contact_no'] ?></td>
                           <td><?php echo date('h:i a', strtotime($g_f_s['open_time'])) . "-" . date('h:i a', strtotime($g_f_s['close_time'])) ?></td>
                           <td><?php echo date('h:i a', strtotime($g_f_s['break_start_time'])) . "-" . date('h:i a', strtotime($g_f_s['break_close_time'])) ?></td>
                        
                           <td>
                              

                              <a href="#" class="btn btn-secondary btn-xs edit_model_click"   data-unic-id="<?php echo $g_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                           </td>
                           <td>
                           <a href="#" class="btn btn-secondary btn-xs edit_model_click_gym"   data-unic-id1="<?php echo $g_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                             
                           </td>
                        
                           <td>
                           <div class="lightgallery" class="room-list-bx d-flex align-items-center">
                                          <a href="<?php echo $services_img['image'] ?>" target="_blank" data-exthumbimage="<?php echo $services_img['image'] ?>" data-src="<?php echo $services_img['image'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                             <img class="me-3 " src="<?php echo $services_img['image'] ?>" alt="" style="width:50px; height:40px;">
                                          </a>
                                       </div>
                           </td>
                          
                           <td>
                              <a href="#" class="btn btn-warning shadow btn-xs sharp me-1" id="edit_gym_data" data-bs-toggle="modal" data-idgym="<?= $g_f_s['front_ofs_service_id'] ?>" data-bs-target=".edit_gym_model"><i class="fa fa-pencil"></i></a>
                            
                           </td>
                        </tr>
                        
                       
                  <?php
                     }
                  }

                  ?>
               </tbody>
            </table>
         </div>
      </div>

      <div class="modal fade edit_gym_model" tabindex="-1" style="display: none;" aria-hidden="true">
         <div class="modal-dialog modal-lg">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title">Edit schedule</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal">
                  </button>
               </div>
               <form id="editgymCenterForm" method="post" enctype="multipart/form-data">
                  <div class="modal-body">
                     <div class="col-lg-12">
                        <div class="basic-form">
                           <input type="hidden" name="front_ofs_service_id" id="front_ofs_service_id">
                           <input type="hidden" class="form-control" value="1" name="service_name">
                           <div class="row">
                              <div class="mb-3 col-md-6 form-group">
                                 <label class="form-label">Staff Name</label>
                                 <input type="text" name="staff_name" id="staff_name1" class="form-control"  required="">
                              </div>
                              <div class="mb-3 col-md-6 form-group">
                                 <label class="form-label">Contact Number</label>
                                 <input type="text" name="contact_no" maxlength="10" id="contact_no" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control"  required="">
                              </div>
                           </div>
                           <div class="row">
                              <div class="mb-3 col-md-6 form-group">
                                 <label class="form-label">Open Time</label>
                                 <div class="input-group">
                                    <input type="time" name="open_time" id="open_time" class="form-control">
                                    <input type="time" name="close_time" id="close_time" class="form-control">
                                 </div>
                              </div>
                              <div class="mb-3 col-md-6 form-group">
                                 <label class="form-label">Break Time</label>
                                 <div class="input-group">
                                    <input type="time" name="break_start_time" id="break_start_time" class="form-control">
                                    <input type="time" name="break_close_time" id="break_close_time" class="form-control">
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="mb-3 col-md-6 form-group">
                                 <label class="form-label">Description</label>
                                 <textarea class="summernote" name="description" rows="3" id="comment1" required=""></textarea>
                              </div>
                              <div class="mb-3 col-md-6 form-group">
                                 <label class="form-label">Terms & Conditions</label>
                                 <textarea class="summernote" name="t_nd_c" rows="3" id="comment" required=""></textarea>
                              </div>
                           </div>
                           <?php
                           $wh1 = '(front_ofs_service_id = "' . $g_f_s['front_ofs_service_id'] . '")';

                           $services_imgs = $this->MainModel->getAllData('front_ofs_services_images', $wh1);

                           // $j = 0;

                           if ($services_imgs) {

                           ?>
                              <label class="form-label">Pictures of Gym</label>
                              <div class="row">
                                 <?php
                                 // foreach ($services_imgs as $se_i) {
                                 ?>
                                   <div class="mb-3 col-md-4 ">
                                   <input type="hidden" name="front_ofs_service_img_id" id="front_ofs_service_image1">
                                          <input type="file" name="gym_img" class="form-control" placeholder="">
                                          <img src="" id="img10" alt="Not Found" height="50" width="50">
                                            </div>
                                          <br>
                                          <output id="Filelist"></output>
                                    <!-- <div class="mb-3 col-md-4 ">
                                       <input type="hidden" name="front_ofs_service_image_id[]" id="img">
                                       <input type="file" class="dropify form-control" name="image[<?php echo $j ?>]" id="files" accept="image/jpeg, image/png," data-default-file="<?php echo $se_i['image'] ?>">
                                    </div>
                                    <br> -->
                                    <!--<output id="Filelist"></output>-->
                                 <?php
                                 //    $j++;
                                 // }
                                 ?>
                                 <div>
                                 <?php
                              }
                                 ?>
                                 </div>
                              </div>
                        </div>
                     </div>
                  </div>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-info" data-bs-dismiss="modal">Save changes</button>
                  </div>
               </form>
            </div>
         </div>
      </div>

   </div>
   </div>

   <div class="modal fade" id="notification_names_view_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Description</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model">
       
        </div>
    </div>
    </div>
  </div>
</div>
<div class="modal fade" id="terms_gym_view_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Terms And Conditions</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model_gym">
       
        </div>
    </div>
    </div>
  </div>
</div>



   <script>


$(document).on('click','.edit_model_click', function () {
   
        var id = $(this).attr('data-unic-id');
          
        $('#notification_names_view_model').modal('show');
       
        // $('#set_id_in_model').val($(this).attr('data-unic-id'));
        var base_url = '<?php echo base_url();?>';
        $.ajax({
            // method: "POST",
            // url: base_url+"HoteladminController/get_view_name_data_notification",
            url: '<?= base_url('HoteladminController/get_discri_name_data_gym') ?>',
            type: "post",
            data: {id : id},
            // dataType: "dataType",
            success: function (response) {
            console.log(response);
            $('.get_data_model').html(response);
            }
        });
    });
    
    $(document).on('click','.edit_model_click_gym', function () {
   
   var id = $(this).attr('data-unic-id1');
     
   $('#terms_gym_view_model').modal('show');
  
   // $('#set_id_in_model').val($(this).attr('data-unic-id'));
   var base_url = '<?php echo base_url();?>';
   $.ajax({
       // method: "POST",
       // url: base_url+"HoteladminController/get_view_name_data_notification",
       url: '<?= base_url('HoteladminController/get_terms_name_data_gym') ?>',
       type: "post",
       data: {id : id},
       // dataType: "dataType",
       success: function (response) {
       console.log(response);
       $('.get_data_model_gym').html(response);
       }
   });
});
    
         $(document).on('click', '#edit_gym_data', function() {
            var id = $(this).attr('data-idgym');
            // alert(id);
            $.ajax({
               url: '<?= base_url('HoteladminController/geteditgymData') ?>',
               type: "post",
               data: {
                  id: id
               },
               dataType: "json",
               success: function(data) {

                  console.log(data);
                  $('#front_ofs_service_id').val(data.data.front_ofs_service_id);
                  $('#staff_name1').val(data.data.staff_name);
                  $('#contact_no').val(data.data.contact_no);
                  $('#open_time').val(data.data.open_time);
                  $('#close_time').val(data.data.close_time);
                  $('#break_start_time').val(data.data.break_start_time);
                  $('#break_close_time').val(data.data.break_close_time);
                  // $('#comment1').val(data.comment);
                  $('#comment1').summernote('code', data.data.description);
                  $('#comment').summernote('code', data.data.t_nd_c);
                  $('#front_ofs_service_image1').val(data.images.front_ofs_service_image_id);
                  $("#img10").attr('src',data.images.image);


               }


            });
         })
     

      //  update business center data
      $(document).bind('submit').on('submit', '#editgymCenterForm', function(e) {
         //   alert('hi');die;
         e.preventDefault();
         $(".loader_block").show();
         var form_data = new FormData(this);
         $.ajax({
            url: '<?= base_url('HoteladminController/edit_front_ofs_services') ?>',
            method: 'POST',
            data: form_data,
            processData: false,
            contentType: false,
            cache: false,
            success: function(res) {

               $.get( '<?= base_url('HoteladminController/ajaxgymIconView_v1'); ?>', function( data ) {
                       var resu = $(data).find('#gym_data').html();
                       $('#gym_data').html(resu);
                       setTimeout(function(){
                        $('#example1').DataTable();

                       },2000);
                   });

               setTimeout(function() {
                  $(".loader_block").hide();
                  $(".edit_gym_model").modal('hide');
                  $(".gym_new_data").html(res);
                  $(".updatemessage").show();
               }, 2000);
               setTimeout(function() {
                  $(".updatemessage").hide();
               }, 4000);



            }
         });
      });
   </script>
<?php } elseif ($sub_icon_id == 2) { ?>
   <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
   <div class="col-md-12">
      <div class="card card-topline-aqua">
         <div class="card-head">
            <header class="page_header_title_spa">Spa Information</header>
         </div>
         <div class="card-body ">
            <div class="col-md-12 col-sm-12">
               <div class="panel tab-border card-box">
                  <header class="panel-heading panel-heading-gray custom-tab">
                     <ul class="nav nav-tabs">
                        <li class="nav-item"><a href="#arrival1_div_spa" data-bs-toggle="tab" class="active">Spa Information</a>
                        </li>
                        <li class="nav-item"><a href="#arrival2_div1_spa" data-bs-toggle="tab">Spa Request</a>
                        </li>
                        <li class="nav-item"><a href="#arrival3_div_spa" data-bs-toggle="tab">Accept Spa Request</a>
                        </li>
                        <li class="nav-item"><a href="#arrival5_div_spa" data-bs-toggle="tab">Completed Spa Request</a>
                        </li>
                        <li class="nav-item"><a href="#arrival4_div_spa" data-bs-toggle="tab">Reject Spa Request</a>
                        </li>
                     </ul>
                  </header>
               </div>
            </div>
            <div class="btn-group r-btn add_spa_require" style="display:none;">
               <button style="float:right;" type="button" class="btn btn-primary css_btn added_spa_request" data-bs-toggle="modal">Add Request</button>
            </div>
            <div class="tab-content">
               <!-- upcoming guest -->
               <div class="tab-pane active" style="background-color:white;" id="arrival1_div_spa">
                  <div class="table-scrollable">
                     <table id="example1" class="display full-width">
                        <thead>
                           <tr class="table-heading">
                              <th><strong>Sr. No.</strong></th>
                              <th><strong>Staff Name</strong></th>
                              <th><strong>Contact No.</strong></th>
                              <th><strong>Open Time </strong></th>
                              <th><strong>Break Time</strong></th>
                              <th><strong>Description</strong></th>
                              <th><Strong>Packages</Strong></th>
                              <th><strong>Terms & Condition</strong></th>
                              <!-- <th><strong>Pictures</strong></th> -->
                              <th><strong>Action</strong></th>
                           </tr>
                        </thead>
                        <tbody id="searchTable">
                           <?php
                           $i = 1;
                           if ($list) {
                              foreach ($list as $spa_f_s) {
                                 $wh = '(front_ofs_service_id = "' . $spa_f_s['front_ofs_service_id'] . '")';

                                 $services_img = $this->HotelAdminModel->getData('front_ofs_services_images', $wh);
                           ?>
                                 <tr>
                                    <td><?php echo $i++ ?></td>
                                    <td><?php echo $spa_f_s['staff_name'] ?></td>
                                    <td><?php echo $spa_f_s['contact_no'] ?></td>
                                    <td><?php echo date('h:i a', strtotime($spa_f_s['open_time'])) . "-" . date('h:i a', strtotime($spa_f_s['close_time'])) ?></td>
                                    <td><?php echo date('h:i a', strtotime($spa_f_s['break_start_time'])) . "-" . date('h:i a', strtotime($spa_f_s['break_close_time'])) ?></td>
                                    <!-- <td>
                              <button
                                  class="btn btn-secondary_<?php echo $spa_f_s['front_ofs_service_id'] ?> shadow btn-xs sharp me-1"><i
                                      class="fas fa-eye"></i></button>
                              </td> -->
                                    <td>
                                       <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $spa_f_s['front_ofs_service_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                    </td>
                                    <td>
                                       <a href="" data-bs-toggle="modal" data-bs-target="#exampleModalCenter1_<?php echo $spa_f_s['front_ofs_service_id'] ?>"> <img src="assets/dist/images/spa_logo.png" alt="" style="height: 40px;width:50px;">
                                       </a>
                                    </td>
                                    <!-- packages -->
                                    <div class="modal fade" id="exampleModalCenter1_<?php echo $spa_f_s['front_ofs_service_id'] ?>" style="display: none;" aria-hidden="true">
                                       <div class="modal-dialog modal-dialog-centered" role="document">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title">Modal title</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                </button>
                                             </div>
                                             <div class="modal-body">
                                                <div class="guest-profile">
                                                   <?php
                                                   $admin_id = $this->session->userdata('u_id');

                                                   $front_ofs_service_id = $spa_f_s['front_ofs_service_id'];

                                                   $spa_images = $this->HotelAdminModel->get_spa_services_images($admin_id, $front_ofs_service_id);

                                                   if ($spa_images) {
                                                      foreach ($spa_images as $s_im) {
                                                   ?>
                                                         <div class="d-flex">
                                                            <img src="<?php echo $s_im['spa_photo'] ?>" alt="" style="height: 50px;width:70px;">
                                                            <div>
                                                               <h5 class="font-w600"><?php echo $s_im['spa_type'] ?></h5>
                                                               <span class="text-secondary">Rs.<?php echo $s_im['spa_price'] ?></span>
                                                            </div>
                                                         </div>
                                                         <br>
                                                   <?php
                                                      }
                                                   }
                                                   ?>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!--/. packages -->
                                    <!-- <td>
                              <a href="" data-bs-toggle="modal"
                                  data-bs-target="#exampleModalCenter_<?php echo $spa_f_s['front_ofs_service_id'] ?>">
                                  <img src="<?php echo base_url('assets/dist/images/term.jpg') ?>" alt=""
                                      height="40px" width="90px">
                              </a>
                              </td> -->
                                    <td>
                                       <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm1_<?php echo $spa_f_s['front_ofs_service_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                    </td>
                                    <!-- modal for terms and conditions -->
                                    <div class="modal fade" id="exampleModalCenter_<?php echo $spa_f_s['front_ofs_service_id'] ?>" style="display: none;" aria-hidden="true">
                                       <div class="modal-dialog modal-dialog-centered" role="document">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title">Terms And Conditions</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                </button>
                                             </div>
                                             <div class="modal-body">
                                                <p><?php echo $spa_f_s['t_nd_c'] ?></p>
                                             </div>
                                             <div class="modal-footer">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!--/. modal for terms and conditions -->
                                    <td>
                                       <div class="">
                                          <a href="#" class="btn btn-warning shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg_<?php echo $spa_f_s['front_ofs_service_id'] ?>"><i class="fa fa-pencil"></i></a>
                                          <!-- <a href="#" onclick="delete_data(<?php echo $spa_f_s['front_ofs_service_id'] ?>)"
                                    class="btn btn-danger shadow btn-xs sharp"><i
                                        class="fa fa-trash"></i></a>-->
                                       </div>
                                    </td>
                                 </tr>
                                 <div class="modal fade bd-terms-modal-sm_<?php echo $spa_f_s['front_ofs_service_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                    <div class="modal-dialog modal-md">
                                       <div class="modal-content">
                                          <div class="modal-header">
                                             <h5 class="modal-title">Description</h5>
                                             <button type="button" class="btn-close" data-bs-dismiss="modal">
                                             </button>
                                          </div>
                                          <div class="modal-body">
                                             <div class="col-lg-12">
                                                <span><?php echo $spa_f_s['description'] ?></span>
                                             </div>
                                          </div>
                                          <div class="modal-footer">
                                             <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal fade bd-terms-modal-sm1_<?php echo $spa_f_s['front_ofs_service_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                    <div class="modal-dialog modal-md">
                                       <div class="modal-content">
                                          <div class="modal-header">
                                             <h5 class="modal-title">Terms And Conditions</h5>
                                             <button type="button" class="btn-close" data-bs-dismiss="modal">
                                             </button>
                                          </div>
                                          <div class="modal-body">
                                             <div class="col-lg-12">
                                                <span><?php echo $spa_f_s['t_nd_c'] ?></span>
                                             </div>
                                          </div>
                                          <div class="modal-footer">
                                             <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                           <?php
                              }
                           }

                           ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <div class="tab-pane" style="background-color:white;" id="arrival2_div1_spa">
                  <div class="table-scrollable spa_added">
                     <table id="requestOrder_tb_spa" class="display full-width">
                        <thead>
                           <tr>
                              <th><strong>Sr. No.</strong></th>
                              <th><strong>Guest Name</strong></th>
                              <th><strong>Phone</strong></th>
                              <!-- <th><strong>Email</strong></th> -->
                              <th><strong>Request Date</strong></th>
                              <th><strong>Request Time</strong></th>
                              <th><strong>Spa Type</strong></th>
                              <th><strong>Note</strong></th>
                              <th><strong>Action</strong></th>
                           </tr>
                        </thead>
                        <tbody id="searchTable" class="append_data11">
                           <?php
                           $i = 1; // + $this->uri->segment(2);

                           if (!empty($spa_request)) {
                              foreach ($spa_request as $spa_r_s) {

                                 $wh = '(u_id = "' . $spa_r_s['u_id'] . '")';
                                 // print_r($wh);die;
                                 $user_data = $this->HotelAdminModel->getData('register', $wh);


                                 $wh2 = '(front_ofs_spa_service_images_id="' . $spa_r_s['spa_type'] . '")';
                                 $spa_type1 = $this->HotelAdminModel->getData($tbl = 'front_ofs_spa_service_images', $wh2);
                                 //    print_r($spa_type1);exit;                                                      
                                 if (!empty($spa_type1)) {
                                    $spa_type = $spa_type1['spa_type'];
                                 } else {
                                    $spa_type = '';
                                 }
                                 //    print_r($spa_type);exit;
                           ?>
                                 <tr>
                                    <td>
                                       <h5><?php echo $i++ ?></h5>
                                    </td>
                                    <td><?php echo $user_data['full_name'] ?></td>
                                    <td><?php echo $user_data['mobile_no'] ?></td>
                                    <td><?php echo $spa_r_s['select_date'] ?></td>
                                    <!-- <td>23/12/2022</td> -->
                                    <td><?php echo date('h:i a', strtotime($spa_r_s['select_time'])) ?></td>
                                    <td><?php echo $spa_type; ?></td>
                                    <td>
                                       <a href="#" class="btn btn-secondary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#description_model_<?php echo $spa_r_s['spa_service_request_id'] ?>"><i class="fa fa-eye"></i></a>
                                    </td>
                                    <!-- modal forDescription -->
                                    <div class="modal fade" id="description_model_<?php echo $spa_r_s['spa_service_request_id'] ?>" style="display: none;" aria-hidden="true">
                                       <!-- <?php print_r($spa_r_s['spa_service_request_id']); ?> -->
                                       <div class="modal-dialog modal-dialog-centered" role="document">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title">Description</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                </button>
                                             </div>
                                             <div class="modal-body">
                                                <p><?php echo $spa_r_s['note'] ?></p>
                                             </div>
                                             <div class="modal-footer">
                                                <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!--/. modal for Description-->
                                    <td>
                                       <div>
                                          <a href="#" class="btn btn-warning shadow btn-xs sharp me-1 update_spa_modal_btn" id="edit_spa_data" data-id1="<?= $spa_r_s['spa_service_request_id'] ?>"><i class="fa fa-share"></i></a>
                                       </div>

                                    </td>
                                 </tr>
                           <?php
                              }
                           }
                           ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <div class="tab-pane" style="background-color:white;" id="arrival3_div_spa">
                  <div class="table-scrollable spa_change_record1">
                     <table id="acceptedOrder_tb_spa" class="display full-width">
                        <thead>
                           <tr class="table-heading">
                              <th><strong>Sr. No.</strong></th>
                              <th><strong>Guest Name</strong></th>
                              <th><strong>Phone</strong></th>
                              <!-- <th><strong>Email</strong></th> -->
                              <th><strong>Request Date</strong></th>
                              <th><strong>Request Time</strong></th>
                              <th><strong>Spa Type</strong></th>
                              <th><strong>Note</strong></th>
                              <th><strong>Action</strong></th>
                           </tr>
                        </thead>
                        <tbody id="searchTable">
                           <?php
                           $i = 1; // + $this->uri->segment(2);

                           if (!empty($spa_request1)) {
                              foreach ($spa_request1 as $spa_r_s) {

                                 $wh = '(u_id = "' . $spa_r_s['u_id'] . '")';

                                 $user_data = $this->HotelAdminModel->getData('register', $wh);


                                 $wh2 = '(front_ofs_spa_service_images_id="' . $spa_r_s['spa_type'] . '")';
                                 $spa_type1 = $this->HotelAdminModel->getData($tbl = 'front_ofs_spa_service_images', $wh2);
                                 //   print_r($spa_type1);exit;                                                      
                                 if (!empty($spa_type1)) {
                                    $spa_type = $spa_type1['spa_type'];
                                 } else {
                                    $spa_type = '';
                                 }
                                 //    print_r($spa_type);exit;


                           ?>
                                 <tr>
                                    <td>
                                       <h5><?php echo $i++ ?></h5>
                                    </td>
                                    <td><?php echo $user_data['full_name'] ?></td>
                                    <td><?php echo $user_data['mobile_no'] ?></td>
                                    <td><?php echo $spa_r_s['select_date'] ?></td>
                                    <!-- <td>23/12/2022</td> -->
                                    <td><?php echo date('h:i a', strtotime($spa_r_s['select_time'])) ?></td>
                                    <td><?php echo $spa_type; ?></td>
                                    <td>
                                       <a href="#" class="btn btn-secondary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#description_model_<?php echo $spa_r_s['spa_service_request_id'] ?>"><i class="fa fa-eye"></i></a>
                                    </td>
                                    <!-- modal forDescription -->
                                    <div class="modal fade" id="description_model_<?php echo $spa_r_s['spa_service_request_id'] ?>" style="display: none;" aria-hidden="true">
                                       <div class="modal-dialog modal-dialog-centered" role="document">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title">Description</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                </button>
                                             </div>
                                             <div class="modal-body">
                                                <p><?php echo $spa_r_s['note'] ?></p>
                                             </div>
                                             <div class="modal-footer">
                                                <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!--/. modal for Description-->
                                    <input type="hidden" name="user_id" id="uid<?php echo $spa_r_s['spa_service_request_id']; ?>" value="<?php echo $spa_r_s['spa_service_request_id']; ?>">
                                    <td>
                                       <!-- <a href="#">
                                 <div class="badge badge-warning"
                                     data-bs-toggle="modal"
                                     data-bs-target="#exampleModalCenter">
                                     Assign</div>
                                 </a> -->
                                       <select class="form-control" name="status" id="spastatus<?php echo $spa_r_s['spa_service_request_id']; ?>" onchange="spa_change_status(<?php echo $spa_r_s['spa_service_request_id'] ?>);" style="min-width:85px;text-align:center;">
                                          <?php
                                          if ($spa_r_s['request_status'] == "1") {
                                          ?>
                                             <option value="1" selected>Accepted</option>
                                             <option value="4">Completed</option>
                                          <?php
                                          }
                                          ?>
                                       </select>
                                       <!-- <span class="badge badge-success">Accepted</span> -->
                                    </td>
                                 </tr>
                           <?php
                              }
                           }

                           ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <div class="tab-pane" style="background-color:white;" id="arrival5_div_spa">
                  <div class="table-scrollable spa_change_record2">
                     <table id="completedOrder_tb_spa" class="display full-width">
                        <thead>
                           <tr class="table-heading">
                              <th><strong>Sr. No.</strong></th>
                              <th><strong>Guest Name</strong></th>
                              <th><strong>Phone</strong></th>
                              <!-- <th><strong>Email</strong></th> -->
                              <th><strong>Request Date</strong></th>
                              <th><strong>Request Time</strong></th>
                              <th><strong>Spa Type</strong></th>
                              <th><strong>Note</strong></th>
                              <th><strong>Action</strong></th>
                           </tr>
                        </thead>
                        <tbody id="searchTable" class="append_spa_data2">
                           <?php
                           $i = 1; // + $this->uri->segment(2);

                           if (!empty($spa_request6)) {
                              foreach ($spa_request6 as $spa_c_s) {

                                 $wh = '(u_id = "' . $spa_c_s['u_id'] . '")';

                                 $user_data = $this->HotelAdminModel->getData('register', $wh);


                                 $wh2 = '(front_ofs_spa_service_images_id="' . $spa_c_s['spa_type'] . '")';
                                 $spa_type1 = $this->HotelAdminModel->getData($tbl = 'front_ofs_spa_service_images', $wh2);
                                 //    print_r($spa_type1);exit;                                                      
                                 if (!empty($spa_type1)) {
                                    $spa_type = $spa_type1['spa_type'];
                                 } else {
                                    $spa_type = '';
                                 }
                                 //    print_r($spa_type);exit;
                           ?>
                                 <tr>
                                    <td>
                                       <h5><?php echo $i++ ?></h5>
                                    </td>
                                    <td><?php echo $user_data['full_name'] ?></td>
                                    <td><?php echo $user_data['mobile_no'] ?></td>
                                    <td><?php echo $spa_c_s['select_date'] ?></td>
                                    <!-- <td>23/12/2022</td> -->
                                    <td><?php echo date('h:i a', strtotime($spa_c_s['select_time'])) ?></td>
                                    <td><?php echo $spa_type; ?></td>
                                    <td>
                                       <a href="#" class="btn btn-secondary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#description_model_<?php echo $spa_c_s['spa_service_request_id'] ?>"><i class="fa fa-eye"></i></a>
                                    </td>
                                    <!-- modal forDescription -->
                                    <div class="modal fade" id="description_model_<?php echo $spa_c_s['spa_service_request_id'] ?>" style="display: none;" aria-hidden="true">
                                       <!-- <?php print_r($spa_c_s['spa_service_request_id']); ?> -->
                                       <div class="modal-dialog modal-dialog-centered" role="document">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title">Description</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                </button>
                                             </div>
                                             <div class="modal-body">
                                                <p><?php echo $spa_c_s['note'] ?></p>
                                             </div>
                                             <div class="modal-footer">
                                                <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!--/. modal for Description-->
                                    <!-- <a href="#">
                              <div class="badge badge-warning"
                                  data-bs-toggle="modal"
                                  data-bs-target="#exampleModalCenter">
                                  Assign</div>
                              </a> -->
                                    <td><span class="badge badge-primary">Completed</span></td>
                                 </tr>
                           <?php
                              }
                           }
                           ?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <div class="tab-pane" style="background-color:white;" id="arrival4_div_spa">
                  <div class="table-scrollable spa_change_record3">
                     <table id="rejectedOrder_tb_spa" class="display full-width">
                        <thead>
                           <tr class="table-heading">
                              <th><strong>Sr. No.</strong></th>
                              <th><strong>Guest Name</strong></th>
                              <th><strong>Phone</strong></th>
                              <!-- <th><strong>Email</strong></th> -->
                              <th><strong>Request Date</strong></th>
                              <th><strong>Request Time</strong></th>
                              <th><strong>Spa Type</strong></th>
                              <th><strong>Note</strong></th>
                              <th><strong>Action</strong></th>
                           </tr>
                        </thead>
                        <tbody id="searchTable" class="append_spa_data">
                           <?php
                           $i = 1; // + $this->uri->segment(2);

                           if (!empty($spa_request2)) {
                              foreach ($spa_request2 as $spa_r_s) {

                                 $wh = '(u_id = "' . $spa_r_s['u_id'] . '")';

                                 $user_data = $this->HotelAdminModel->getData('register', $wh);


                                 $wh2 = '(front_ofs_spa_service_images_id="' . $spa_r_s['spa_type'] . '")';
                                 $spa_type1 = $this->HotelAdminModel->getData($tbl = 'front_ofs_spa_service_images', $wh2);
                                 //    print_r($spa_type1);exit;                                                      
                                 if (!empty($spa_type1)) {
                                    $spa_type = $spa_type1['spa_type'];
                                 } else {
                                    $spa_type = '';
                                 }
                                 //    print_r($spa_type);exit;
                           ?>
                                 <tr>
                                    <td>
                                       <h5><?php echo $i++ ?></h5>
                                    </td>
                                    <td><?php echo $user_data['full_name'] ?></td>
                                    <td><?php echo $user_data['mobile_no'] ?></td>
                                    <td><?php echo $spa_r_s['select_date'] ?></td>
                                    <!-- <td>23/12/2022</td> -->
                                    <td><?php echo date('h:i a', strtotime($spa_r_s['select_time'])) ?></td>
                                    <td><?php echo $spa_type; ?></td>
                                    <td>
                                       <a href="#" class="btn btn-secondary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#description_model_<?php echo $spa_r_s['spa_service_request_id'] ?>"><i class="fa fa-eye"></i></a>
                                    </td>
                                    <!-- modal forDescription -->
                                    <div class="modal fade" id="description_model_<?php echo $spa_r_s['spa_service_request_id'] ?>" style="display: none;" aria-hidden="true">
                                       <!-- <?php print_r($spa_r_s['spa_service_request_id']); ?> -->
                                       <div class="modal-dialog modal-dialog-centered" role="document">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title">Description</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                </button>
                                             </div>
                                             <div class="modal-body">
                                                <p><?php echo $spa_r_s['note'] ?></p>
                                             </div>
                                             <div class="modal-footer">
                                                <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <!--/. modal for Description-->
                                    <td>
                                       <!-- <a href="#">
                                 <div class="badge badge-warning"
                                     data-bs-toggle="modal"
                                     data-bs-target="#exampleModalCenter">
                                     Assign</div>
                                 </a> -->
                                       <?php
                                       if ($spa_r_s['request_status'] == 1) {
                                       ?>
                                          <span class="badge badge-info">Accepted</span>
                                       <?php
                                       } elseif ($spa_r_s['request_status'] == 2) {
                                       ?>
                                          <span class="badge badge-danger">Rejected</span>
                                       <?php
                                       }
                                       ?>
                                    </td>
                                 </tr>
                           <?php
                              }
                           }
                           ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
         <?php
         if ($list) {
            foreach ($list as $spa_f_s) {
         ?>
               <div class="modal fade bd-example-modal-lg_<?php echo $spa_f_s['front_ofs_service_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                  <div class="modal-dialog modal-xl">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">Edit schedule</h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal">
                           </button>
                        </div>
                        <form action="<?php echo base_url('HoteladminController/edit_front_ofs_services') ?>" method="post" enctype="multipart/form-data">
                           <input type="hidden" name="front_ofs_service_id" value="<?php echo $spa_f_s['front_ofs_service_id'] ?>">
                           <input type="hidden" class="form-control" value="2" name="service_name">
                           <div class="modal-body">
                              <div class="col-lg-12">
                                 <div class="basic-form">
                                    <div class="row">
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Staff Name</label>
                                          <input type="text" name="staff_name" value="<?php echo $spa_f_s['staff_name'] ?>" class="form-control" value="Amit Sahane" required="">
                                       </div>
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Contact Number</label>
                                          <input type="text" name="contact_no" maxlength="10" value="<?php echo $spa_f_s['contact_no'] ?>" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" value="9878675645" required="">
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Open Time</label>
                                          <div class="input-group">
                                             <input type="time" name="open_time" value="<?php echo $spa_f_s['open_time'] ?>" class="form-control">
                                             <input type="time" name="close_time" value="<?php echo $spa_f_s['close_time'] ?>" class="form-control">
                                          </div>
                                       </div>
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Break Time</label>
                                          <div class="input-group">
                                             <input type="time" name="break_start_time" value="<?php echo $spa_f_s['break_start_time'] ?>" class="form-control">
                                             <input type="time" name="break_close_time" value="<?php echo $spa_f_s['break_close_time'] ?>" class="form-control">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Description</label>
                                          <textarea class="summernote" name="description" rows="3" id="comment" required=""><?php echo $spa_f_s['description'] ?></textarea>
                                       </div>
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Terms & Conditions</label>
                                          <textarea class="summernote" name="t_nd_c" rows="3" id="comment" required=""><?php echo $spa_f_s['t_nd_c'] ?></textarea>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <?php
                                       $k = 0;

                                       $admin_id = $this->session->userdata('u_id');

                                       $front_ofs_service_id = $spa_f_s['front_ofs_service_id'];

                                       $spa_images = $this->MainModel->get_spa_services_images($admin_id, $front_ofs_service_id);

                                       if ($spa_images) {
                                          foreach ($spa_images as $s_im) {
                                       ?>
                                             <input type="hidden" name="front_ofs_spa_service_images_id[]" value="<?php echo $s_im['front_ofs_spa_service_images_id'] ?>" class="form-control" placeholder="" required="">
                                             <div class="mb-3 col-md-4 form-group">
                                                <label class="form-label">Spa Photo</label>
                                                <input type="file" name="spa_photo[<?php echo $k ?>]" class=" form-control" accept="image/jpeg, image/png," data-default-file="<?php echo $s_im['spa_photo'] ?>">
                                             </div>
                                             <div class="mb-3 col-md-4 form-group">
                                                <label class="form-label">Spa Type</label>
                                                <input type="text" name="spa_type[<?php echo $k ?>]" value="<?php echo $s_im['spa_type'] ?>" class="form-control" id="files">
                                             </div>
                                             <div class="mb-3 col-md-4 form-group">
                                                <label class="form-label">Price</label>
                                                <div class="input-group">
                                                   <input type="text" class="form-control" name="spa_price[<?php echo $k ?>]" value="<?php echo $s_im['spa_price'] ?>">
                                                   <button type="button" id="btnAdd12_<?php echo $spa_f_s['front_ofs_service_id'] ?>" class="btn btn-sm btn-primary"> <i class="fa fa-plus"></i></button>
                                                </div>
                                             </div>
                                       <?php
                                             $k++;
                                          }
                                       }
                                       ?>
                                       <div class="text-left mb-3">
                                          <!-- <button type="button" id="btnAdd12_<?php echo $spa_f_s['front_ofs_service_id'] ?>" class="btn btn-sm btn-primary"> <i class="fa fa-plus"></i></button>-->
                                       </div>
                                    </div>
                                    <div id="TextBoxContainer12_<?php echo $spa_f_s['front_ofs_service_id'] ?>" class="mb-1"></div>
                                    <?php
                                    $wh1 = '(front_ofs_service_id = "' . $spa_f_s['front_ofs_service_id'] . '")';

                                    $services_imgs = $this->MainModel->getAllData('front_ofs_services_images', $wh1);
                                    // print_r($services_imgs);die;
                                    $j = 0;

                                    if ($services_imgs) {

                                    ?>
                                       <div class="row">
                                          <label class="form-label">Pictures of Spa</label>
                                          <?php
                                          foreach ($services_imgs as $se_i) {
                                          ?>
                                             <div class=" col-md-6 ">
                                                <input type="hidden" name="front_ofs_service_image_id[]" value="<?php echo $se_i['front_ofs_service_image_id'] ?>">
                                                <input type="file" class="dropify form-control" name="image[<?php echo $j ?>]" id="files" accept="image/jpeg, image/png," data-default-file="<?php echo $se_i['image'] ?>">
                                             </div>
                                          <?php
                                             $j++;
                                          }
                                          ?>
                                       </div>
                                    <?php
                                    }
                                    ?>
                                 </div>
                                 <div>
                                 </div>
                              </div>
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-info">Save changes</button>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
         <?php
            }
         }
         ?>
      </div>
   </div>


   <div class="modal fade bd-add-modal add_spa_request_model" tabindex="-1" style="display: none;" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <form id="spa_request" method="post" enctype="multipart/form-data">
               <div class="modal-header">
                  <h5 class="modal-title" style="font-weight: bold;font-size: 15px !important;">Add Spa Request</h5>
                  <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
                 
               </div>
               <div class="modal-body">
                  <div class="row">
                     <!-- <div class="mb-3 col-md-6 form-group">
                     <label class="form-label">Guest Name</label>
                     <input type="text" class="form-control"  name="name" id="name" placeholder="Enter agent name">
                     </div> -->
                     <div class="mb-3 col-md-6 form-group">
                        <label class="form-label">Contact Number</label>
                        <input type="text" maxlength="10" name="mobile_no" id="mobile_no" onkeyup="add_booking_id()" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" placeholder="Contact Number" required="">
                     </div>
                     <div class="mb-3 col-md-6 form-group">
                        <label class="form-label">Booking ID</label>
                        <input type="number" name="booking_id" class="form-control" id="booking_id" placeholder="Booking ID" required="" disable>
                     </div>
                     <div class="mb-3 col-md-6 form-group">
                        <label class="form-label">Request Date</label>
                        <input type="date" class="form-control minDate" name="request_date" placeholder="Date" required>
                     </div>
                     <div class="mb-3 col-md-6 form-group">
                        <label class="form-label">Request Time</label>
                        <input type="time" class="form-control minDate" name="request_time" placeholder="time" required>
                     </div>
                     <div class="mb-3 col-md-6 form-group">
                        <label class="form-label">Spa Type</label>
                        <select id="spa_type" name="spa_type" class="default-select form-control wide  dropdown js-example-disabled-results" required="">
                           <option selected="">Select... </option>
                           <?php
                           $u_id = $this->session->userdata('u_id');
                           $where = '(u_id = "' . $u_id . '")';
                           $admin_details = $this->HotelAdminModel->getData($tbl = 'register', $where);

                           $wh = '(u_id ="' . $admin_details['hotel_id'] . '")';
                           $get_hotel_name = $this->HotelAdminModel->getData($tbl = 'register', $wh);

                           $admin_id = $admin_details['u_id'];

                           $front_ofs_service_id = $spa_f_s['front_ofs_service_id'];

                           $spa_images = $this->HotelAdminModel->get_spa_services_images($admin_id, $front_ofs_service_id);
                           foreach ($spa_images as $s_im) {
                           ?>
                              <option value="<?php echo $s_im['front_ofs_spa_service_images_id'] ?>"><?php echo $s_im['spa_type'] ?></option>
                           <?php
                           }
                           ?>
                        </select>
                     </div>
                     <div class="mb-3 col-md-12 form-group">
                        <label class="form-label">Note</label>
                        <!-- <div class="summernote"></div> -->
                        <textarea class="summernote" id="description1" name="additional_note" style="min-height: 400px;"></textarea>
                     </div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="submit" class="btn btn-primary css_btn">Add
                  </button>
               </div>
            </form>
         </div>
      </div>
   </div>
   <!-- end add btn modal -->
   <div class="modal fade update_spa_modal_change" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-md">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title">Edit Order status</h5>
               <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
            </div>
            <form id="frmupdateblock_spa" method="post" enctype="multipart/form-data">
               <div class="modal-body">
                  <div class="basic-form">
                     <div class="row">
                        <div class="mb-3 col-md-12">
                           <input type="hidden" name="spa_service_request_id" id="spa_service_request_id1">

                           <label class="form-label">Change Order Status</label>
                           <select id="send_user" name="request_status" class="default-select form-control wide" required>
                              <option value="">Choose...</option>
                              <option value="1">Accept</option>
                              <option value="2">Reject</option>
                           </select>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="submit" class="btn btn-primary css_btn">Save</button>
                  <button type="button" class="btn btn-light css_btn" data-dismiss="modal">Close</button>
               </div>
            </form>
         </div>
      </div>
   </div>
   <!-- add btn modal  -->
   <script>
      function spa_change_status(cnt) {
         $(".loader_block").show();
         var base_url = '<?php echo base_url(); ?>';
         var status = $('#spastatus' + cnt).children("option:selected").val();
         var uid = $('#uid' + cnt).val();

         if (status != '') {
            $.ajax({
               url: base_url + "HoteladminController/spa_status",
               method: "POST",
               data: {
                  status: status,
                  uid: uid
               },
               dataType: "json",
               success: function(data) {
                  $.get('<?= base_url('HoteladminController/ajaxspaIconView_v1'); ?>', function(data) {
                     var resu = $(data).find('#arrival2_div1_spa').html();
                     var resu1 = $(data).find('.spa_change_record1').html();
                     var resu2 = $(data).find('.spa_change_record2').html();
                     var resu3 = $(data).find('.spa_change_record3').html();
                     $('#arrival2_div1_spa').html(resu);
                     $('.spa_change_record1').html(resu1);
                     $('.spa_change_record2').html(resu2);
                     $('.spa_change_record3').html(resu3);

                     setTimeout(function() {
                        $(".loader_block").hide();
                        $('.page_header_title_spa').text('Complete Spa Request');
                        $(".status_completed").show();
                        $('#requestOrder_tb_spa').DataTable();
                        $('#acceptedOrder_tb_spa').DataTable();
                        $('#completedOrder_tb_spa').DataTable();
                        $('#rejectedOrder_tb_spa').DataTable();
                        $('a[href="#arrival5_div_spa"]').tab('show');

                        setTimeout(function() {
                           $(".status_completed").hide();
                        }, 4000);
                     }, 2000);
                  });
               }
            });
         }
      }
   </script>
   <script>
      $(document).ready(function() {
         $('#requestOrder_tb_spa').DataTable();
         $('#acceptedOrder_tb_spa').DataTable();
         $('#completedOrder_tb_spa').DataTable();
         $('#rejectedOrder_tb_spa').DataTable();


         $(document).on("click", ".added_spa_request", function() {
            $(".add_spa_request_model").modal('show');
         });
         $(document).unbind('submit').on('submit', '#spa_request', function(e) {
            e.preventDefault();
            $(".loader_block").show();
            var form_data = new FormData(this);
            //  var data_id = $(this).attr('data-id');
            $.ajax({
               url: '<?= base_url('HoteladminController/add_spa_request') ?>',
               method: 'POST',
               data: form_data,
               processData: false,
               contentType: false,
               cache: false,
               success: function(res) {

                  $.get('<?= base_url('HoteladminController/ajaxspaIconView_v1'); ?>', function(data) {
                     var resu = $(data).find('#arrival2_div1_spa').html();
                     $('#arrival2_div1_spa').html(resu);
                     setTimeout(function() {
                        $('#requestOrder_tb_spa').DataTable();
                     }, 2000);
                  });

                  setTimeout(function() {
                     $(".loader_block").hide();
                     $(".add_spa_request_model").modal('hide');
                     $(".add_spa_request_model").on("hidden.bs.modal", function() {
                     $("#spa_request")[0].reset(); 
                     $('#description1').summernote('reset');// reset the form fields
                  });
                 
                     $(".append_data11").html(res);
                     $(".successmessage11").show();
                  }, 2000);
                  setTimeout(function() {
                     $(".successmessage11").hide();
                  }, 4000);

               }
            });
         });



      });
   </script>
   <script>
      $(document).on('click', '#edit_spa_data', function() {
         var id = $(this).attr('data-id1');
         // alert(id);
         $.ajax({
            url: '<?= base_url('HoteladminController/getrequirement') ?>',
            //url: 'https://aartoon.com/control_panel/MainController/delete_home_slider/13',
            type: "post",
            data: {
               id: id
            },
            dataType: "json",
            success: function(data) {
               console.log(data);
               $('#spa_service_request_id1').val(data.spa_request[0].spa_service_request_id);

            }
         });
      })
   </script>
   <script>
      $('#send_user').on('change', function() {

         if (this.value == 1) {
            //   $('#user_list').
            //   $('.assignto').css('display','block');
            //   $('.rejectreasonddd').css('display','none');
            //   $('.demo').prop('required', true);

            //   $('#reason').prop('required', false);
            //   $('#status').prop('required', true);

            //   $('.assignto').css('display','block');

         } else if (this.value == 2) {
            //   $('.assignto').css('display','none');
            //   $('.rejectreasonddd').css('display','block');
            //   $('#reason').prop('required', true);
            //   $('#status').prop('required', false);
            // $('.demo').prop('required', true);

         }
      });
   </script>

   <script>
      $(document).on("click", ".update_spa_modal_btn", function() {
         $(".update_spa_modal_change").modal('show');
      });

      $('#frmupdateblock_spa').submit(function(e) {
         e.preventDefault();
         $(".loader_block").show();
         var form_data = new FormData(this);
         var base_url = '<?php echo base_url() ?>';
         //   console.log(base_url);
         //   return false;
         $.ajax({
            url: base_url + "HoteladminController/change_new_spa_status",
            type: 'POST',
            data: form_data,
            processData: false,
            contentType: false,
            cache: false,
            success: function(res) {
               console.log(res)
               $.get('<?= base_url('HoteladminController/ajaxspaIconView_v1'); ?>', function(data) {
                  var resu = $(data).find('#arrival2_div1_spa').html();
                  var resu1 = $(data).find('#arrival3_div_spa').html();
                  var resu2 = $(data).find('#arrival5_div_spa').html();
                  var resu3 = $(data).find('#arrival4_div_spa').html();


                  $('#arrival2_div1_spa').html(resu);
                  $('#arrival3_div_spa').html(resu1);
                  $('#arrival5_div_spa').html(resu2);
                  $('#arrival4_div_spa').html(resu3);

                  setTimeout(function() {
                     $('#requestOrder_tb_spa').DataTable();
                     $('#acceptedOrder_tb_spa').DataTable();
                     $('#completedOrder_tb_spa').DataTable();
                     $('#rejectedOrder_tb_spa').DataTable();
                  }, 2000);
               });
               setTimeout(function() {
                  $(".loader_block").hide();
                  $(".update_spa_modal_change").modal('hide');
                  $(".update_spa_modal_change").on("hidden.bs.modal", function() {
                     $("#frmupdateblock_spa")[0].reset(); // reset the form fields
                  });
                  $(".updatemessage").show();
                  $(".append_data11").html(res);

                  var request_status = form_data.get('request_status');
                  //  console.log(requestStatus); // Log the requestStatus value to the console

                  if (request_status === "1") {
                     $('a[href="#arrival3_div_spa"]').tab('show');
                     $('.page_header_title_spa').text('Accept Spa Request');
                  } else if (request_status === "2") {
                     $('a[href="#arrival4_div_spa"]').tab('show');
                     $('.page_header_title_spa').text('Reject Spa Request');

                  }

               }, 2000);
               setTimeout(function() {
                  $(".updatemessage").hide();
               }, 4000);
            }

         });
      });
   </script>
<?php } elseif ($sub_icon_id == 3) { ?>
   <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
   <div class="col-md-12">
      <div class="card card-topline-aqua">
         <div class="card-head">
            <header>Pool Information</header>
         </div>
         <div class="card-body ">
            <div class="table-scrollable">
               <table id="example1" class="display full-width">
                  <thead>
                     <tr>
                        <th><strong>Sr. No.</strong></th>
                        <th><strong>Staff Name</strong></th>
                        <th><strong>Contact No.</strong></th>
                        <th><strong>Open Time </strong></th>
                        <th><strong>Break Time</strong></th>
                        <th><strong>Description</strong></th>
                        <th><strong>Terms & Condition</strong></th>
                        <th><strong>Pictures</strong></th>
                        <th><strong>Action</strong></th>
                     </tr>
                  </thead>
                  <tbody id="searchTable" class="pool_new_data">
                     <?php
                     $i = 1;
                     if ($list) {
                        foreach ($list as $p_f_s) {
                           $wh = '(front_ofs_service_id = "' . $p_f_s['front_ofs_service_id'] . '")';

                           $services_img = $this->HotelAdminModel->getData('front_ofs_services_images', $wh);
                     ?>
                           <tr>
                              <td><?php echo $i++ ?></td>
                              <td><?php echo $p_f_s['staff_name'] ?></td>
                              <td><?php echo $p_f_s['contact_no'] ?></td>
                              <td><?php echo date('h:i a', strtotime($p_f_s['open_time'])) . "-" . date('h:i a', strtotime($p_f_s['close_time'])) ?></td>
                              <td><?php echo date('h:i a', strtotime($p_f_s['break_start_time'])) . "-" . date('h:i a', strtotime($p_f_s['break_close_time'])) ?></td>
                         
                        <td>
                              

                              <a href="#" class="btn btn-secondary btn-xs edit_model_click_pool"   data-unic-id3="<?php echo $p_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                           </td>
                              <td>
                              <a href="#" class="btn btn-secondary btn-xs edit_model_click_pool_term"   data-unic-id4="<?php echo $p_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                              </td>
                              <td>
                              <div class="lightgallery" class="room-list-bx d-flex align-items-center">
                                          <a href="<?php echo $services_img['image'] ?>" target="_blank" data-exthumbimage="<?php echo $services_img['image'] ?>" data-src="<?php echo $services_img['image'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                             <img class="me-3 " src="<?php echo $services_img['image'] ?>" alt="" style="width:50px; height:40px;">
                                          </a>
                                       </div>
                                 <!-- <div id="gallery" data-toggle="modal" data-target="#exampleModal">
                                    <img class="me-3 " src="<?php echo $services_img['image'] ?>" alt="" data-bs-toggle="modal" data-bs-target=".bd-example1-modal-md_<?php echo $p_f_s['front_ofs_service_id'] ?>" data-slide-to="0" style="height:30px; width:60px;">
                                 </div> -->
                              </td>
                            
                              <td>
                                 <div class="">
                                    <a href="#" class="btn btn-warning shadow btn-xs sharp me-1" id="edit_pool_data" data-bs-toggle="modal" data-idpool="<?= $p_f_s['front_ofs_service_id'] ?>" data-bs-target=".edit_pool_model"><i class="fa fa-pencil"></i></a>
                                    <!--<a href="#" onclick="delete_data(<?php echo $p_f_s['front_ofs_service_id'] ?>)"
                              class="btn btn-danger shadow btn-xs sharp"><i
                                  class="fa fa-trash"></i></a>-->
                                 </div>
                              </td>
                           </tr>
                         
                           
                        
                     <?php
                        }
                     }

                     ?>
                  </tbody>
               </table>
            </div>

         </div>
      </div>
   </div>

   <div class="modal fade edit_pool_model" tabindex="-1" style="display: none;" aria-hidden="true">
      <div class="modal-dialog modal-lg">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title">Edit schedule</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal">
               </button>
            </div>
            <form id="editpoolCenterForm" method="post" enctype="multipart/form-data">
               <div class="modal-body">
                  <div class="col-lg-12">
                     <div class="basic-form">
                        <input type="hidden" name="front_ofs_service_id" id="front_ofs_service_id2">
                        <input type="hidden" class="form-control" value="3" name="service_name">
                        <div class="row">
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Staff Name</label>
                              <input type="text" name="staff_name" id="staff_name2" class="form-control" value="Amit Sahane" required="">
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Contact Number</label>
                              <input type="text" name="contact_no" maxlength="10" id="contact_no2" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" value="9878675645" required="">
                           </div>
                        </div>
                        <div class="row">
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Open Time</label>
                              <div class="input-group">
                                 <input type="time" name="open_time" id="open_time2" class="form-control">
                                 <input type="time" name="close_time" id="close_time2" class="form-control">
                              </div>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Break Time</label>
                              <div class="input-group">
                                 <input type="time" name="break_start_time" id="break_start_time2" class="form-control">
                                 <input type="time" name="break_close_time" id="break_close_time2" class="form-control">
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Description</label>
                              <textarea class="summernote" name="description" rows="3" id="comment2" required=""></textarea>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Terms & Conditions</label>
                              <textarea class="summernote" name="t_nd_c" rows="3" id="comment3" required=""></textarea>
                           </div>
                        </div>
                        <?php
                        $wh1 = '(front_ofs_service_id = "' . $p_f_s['front_ofs_service_id'] . '")';

                        $services_imgs = $this->MainModel->getAllData('front_ofs_services_images', $wh1);

                        // $j = 0;

                        if ($services_imgs) {

                        ?>
                           <div class="row">
                              <label class="form-label">Pictures of Pool</label>
                              <?php
                              // foreach ($services_imgs as $se_i) {
                              ?>
                                 <div class="mb-3 col-md-4 form-group">
                                 <input type="hidden" name="front_ofs_service_img_id" id="front_ofs_service_image3">
                                          <input type="file" name="pool_img" class="form-control" placeholder="">
                                          <img src="" id="img11" alt="Not Found" height="50" width="50">
                                          <br>
                                          <output id="Filelist"></output>
                                 </div>
                              <?php
                              //    $j++;
                              // }
                              ?>
                           </div>
                        <?php
                        }
                        ?>
                        <div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-info" data-bs-dismiss="modal">Save changes</button>
               </div>
            </form>
         </div>
      </div>
   </div>
   <div class="modal fade" id="pool_names_view_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Description</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model_pool">
       
        </div>
    </div>
    </div>
  </div>
</div>

<div class="modal fade" id="pool_names_view_model_term" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Terms And Conditions</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model_pool_term">
       
        </div>
    </div>
    </div>
  </div>
</div>


   <script>

$(document).on('click','.edit_model_click_pool', function () {
   
   var id = $(this).attr('data-unic-id3');
     
   $('#pool_names_view_model').modal('show');
  
   // $('#set_id_in_model').val($(this).attr('data-unic-id'));
   var base_url = '<?php echo base_url();?>';
   $.ajax({
       // method: "POST",
       // url: base_url+"HoteladminController/get_view_name_data_notification",
       url: '<?= base_url('HoteladminController/get_discri_name_data_pool') ?>',
       type: "post",
       data: {id : id},
       // dataType: "dataType",
       success: function (response) {
       console.log(response);
       $('.get_data_model_pool').html(response);
       }
   });
});

$(document).on('click','.edit_model_click_pool_term', function () {
   
   var id = $(this).attr('data-unic-id4');
     
   $('#pool_names_view_model_term').modal('show');
  
   // $('#set_id_in_model').val($(this).attr('data-unic-id'));
   var base_url = '<?php echo base_url();?>';
   $.ajax({
       // method: "POST",
       // url: base_url+"HoteladminController/get_view_name_data_notification",
       url: '<?= base_url('HoteladminController/get_terms_name_data_pool') ?>',
       type: "post",
       data: {id : id},
       // dataType: "dataType",
       success: function (response) {
       console.log(response);
       $('.get_data_model_pool_term').html(response);
       }
   });
});

      // $(document).ready(function(id) {
         $(document).on('click', '#edit_pool_data', function() {
            var id = $(this).attr('data-idpool');
            // alert(id);
            $.ajax({
               url: '<?= base_url('HoteladminController/geteditpoolData') ?>',
               type: "post",
               data: {
                  id: id
               },
               dataType: "json",
               success: function(data) {

                  console.log(data);
                  $('#front_ofs_service_id2').val(data.data.front_ofs_service_id);
                  $('#staff_name2').val(data.data.staff_name);
                  $('#contact_no2').val(data.data.contact_no);
                  $('#open_time2').val(data.data.open_time);
                  $('#close_time2').val(data.data.close_time);
                  $('#break_start_time2').val(data.data.break_start_time);
                  $('#break_close_time2').val(data.data.break_close_time);
                  // $('#comment1').val(data.comment);
                  $('#comment2').summernote('code', data.data.description);
                  $('#comment3').summernote('code', data.data.t_nd_c);

                  $('#front_ofs_service_image3').val(data.images.front_ofs_service_image_id);
                  
                  $("#img11").attr('src',data.images.image);



               }


            });
         })
      // });
      //  update business center data
      $(document).bind('submit').on('submit', '#editpoolCenterForm', function(e) {
         //   alert('hi');die;
         e.preventDefault();
         $(".loader_block").show();
         var form_data = new FormData(this);
         $.ajax({
            url: '<?= base_url('HoteladminController/edit_front_ofs_services') ?>',
            method: 'POST',
            data: form_data,
            processData: false,
            contentType: false,
            cache: false,
            success: function(res) {

               // $.get( '<?= base_url('HoteladminController/ajaxbusinessIconView_v1'); ?>', function( data ) {
               //         var resu = $(data).find('#business_new_div').html();
               //         $('#business_new_div').html(resu);


               //         setTimeout(function(){
               //          $('#example1').DataTable();

               //         },2000);
               //     });

               setTimeout(function() {
                  $(".loader_block").hide();
                  $(".edit_pool_model").modal('hide');
                  $(".pool_new_data").html(res);
                  $(".updatemessage").show();
               }, 2000);
               setTimeout(function() {
                  $(".updatemessage").hide();
               }, 4000);



            }
         });
      });
   </script>
<?php } elseif ($sub_icon_id == 'n2') { ?>
   <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
   <div class="col-md-12">
      <div class="card card-topline-aqua">
         <div class="card-head">
            <header>All check out Guest</header>
         </div>
         <div class="card-body ">
            <div class="col-md-3">
               <div class="input-group">
                  <input type="text" name="date" class="form-control wide" placeholder="Check-Out Date" onfocus="(this.type = 'date')" id="date">
                  <button type="submit" name="search" class="btn btn-warning  btn-sm "><i class="fa fa-search"></i></button>
               </div>
            </div>
            <div class="table-scrollable">
               <table id="example1" class="display full-width">
                  <thead>
                     <tr>
                        <th><strong>Sr. No.</strong></th>
                        <!-- <th><strong>Room No.</strong></th> -->
                        <th><strong>Guest Name</strong></th>
                        <th><strong>Mobile No</strong></th>
                        <th><strong>Booking ID</strong></th>
                        <th><strong>Check-Out Date</strong></th>
                        <th><strong>Adults</strong></th>
                        <th><strong>Child</strong></th>
                        <th><strong>No. Of Rooms</strong></th>
                        <!-- <th><strong>Room Type</strong></th> -->
                        <th><strong>Total Stay</strong></th>
                        <th><strong>Total Bill</strong></th>
                        <th><strong>Invoice</strong></th>
                     </tr>
                  </thead>
                  <tbody id="searchTable">
                     <?php
                     $i = 1;

                     if ($list) {
                        foreach ($list as $gl) {
                           $date1 = $gl['check_in'];
                           $date2 = $gl['actual_checkout'];

                           $diff = abs(strtotime($date2) - strtotime($date1));

                           $years = floor($diff / (365 * 60 * 60 * 24));
                           $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
                           $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));

                           $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));

                     ?>
                           <tr>
                              <td><strong><?php echo $i++ ?></strong></td>
                              <td><span class="w-space-no"><?php echo $gl['full_name'] ?></span></td>
                              <td><span class="w-space-no"><?php echo $gl['mobile_no'] ?></span></td>
                              <td><?php echo $gl['booking_id'] ?></td>
                              <td><?php echo $gl['actual_checkout'] ?></td>
                              <td><?php echo $gl['total_adults'] ?></td>
                              <td><?php echo $gl['total_child'] ?></td>
                              <td>
                                 <a href="#" class="btn btn-secondary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg_<?php echo $gl['booking_id'] ?>">
                                    <?php echo $gl['no_of_rooms'] ?></a>
                              </td>
                              <td><?php echo $days ?></td>
                              <td>Rs <?php echo $gl['total_bill'] ?></td>
                              <td>
                                 <!-- <a href="#" class="btn btn-primary shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg"><i class="fas fa-pencil-alt"></i></a> -->
                                 <a href="<?php echo base_url('HoteladminController/check_out_view/' . $gl['booking_id'] . '/' . $gl['u_id']) ?>" class="btn btn-success shadow btn-xs sharp ">
                                    <i class="material-icons">receipt</i>
                              </td>
                           </tr>
                        <?php
                        }
                     } else {
                        ?>
                        <tr>
                           <td colspan="9" class="text-center">Data Not Available</td>
                        </tr>
                     <?php
                     }
                     ?>
                  </tbody>
               </table>
            </div>
            <?php
            if ($list) {
               $admin_id = $this->session->userdata('u_id');

               foreach ($list as $gl) {
                  $user_booking_details = $this->MainModel->get_booking_room_details($gl['booking_id']);

            ?>
                  <div class="modal fade bd-example-modal-lg_<?php echo $gl['booking_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                     <div class="modal-dialog modal-lg slideInDown animated">
                        <div class="modal-content">
                           <div class="modal-header">
                              <h5 class="modal-title">Room Related Data</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal">
                              </button>
                           </div>
                           <div class="modal-body">
                              <div class="row mt-4">
                                 <div class="col-xl-12">
                                    <div class="table-responsive">
                                       <table class="table table-responsive-sm">
                                          <thead>
                                             <tr>
                                                <th>Sr. No.</th>
                                                <th>Room Type</th>
                                                <th>Room No</th>
                                                <th>Price</th>
                                             </tr>
                                          </thead>
                                          <tbody>
                                             <?php
                                             $j = 1;
                                             if ($user_booking_details) {
                                                foreach ($user_booking_details as $u_bd) {
                                             ?>
                                                   <tr>
                                                      <td>
                                                         <div>
                                                            <h5 class="text-nowrap"><?php echo $j++ ?> </h5>
                                                         </div>
                                                      </td>
                                                      <td>
                                                         <div>
                                                            <h5 class="text-nowrap">
                                                               <?php echo $u_bd['room_type_name'] ?>
                                                            </h5>
                                                         </div>
                                                      </td>
                                                      <td>
                                                         <div>
                                                            <h5 class="text-nowrap"><?php echo $u_bd['room_no'] ?> </h5>
                                                         </div>
                                                      </td>
                                                      <td>
                                                         <div>
                                                            <h5 class="text-nowrap"><?php echo $u_bd['price'] ?></h5>
                                                         </div>
                                                      </td>
                                                   </tr>
                                             <?php
                                                }
                                             }
                                             ?>
                                          </tbody>
                                       </table>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
            <?php
               }
            }
            ?>
         </div>
      </div>
   </div>
<?php } elseif ($sub_icon_id == 'n1') { ?>
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
<script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>

<div class="col-md-12">
   <div class="card card-topline-aqua">
      <div class="card-head">
         <header><span class="arrival11">Todays Arrival</span></header>
      </div>
      <div class="card-body">
         <div class="row">
            <div class="col-md-12 col-sm-12">
               <div class="panel tab-border card-box">
                  <header class="panel-heading panel-heading-gray custom-tab">
                     <ul class="nav nav-tabs">
                        <li class="nav-item"><a href="#arrival1_div" data-bs-toggle="tab" class="active">Today's Arrival</a>
                        </li>
                        <li class="nav-item"><a href="#arrival2_div" data-bs-toggle="tab">Upcoming Arrival</a>
                        </li>
                     </ul>
                  </header>
               </div>
               <div class="col-md-3">
                  <div class="input-group">
                     <input type="text" class="form-control wide" placeholder="Check-in Date" onfocus="(this.type = 'date')" id="date">
                     <button class="btn btn-warning  btn-sm "><i class="fa fa-search"></i></button>
                  </div>
               </div>
            </div>
         </div>
         <div class="tab-content">
            <div class="tab-pane active" style="background-color:white;" id="arrival1_div">
               <button style="float:right;" type="button" class="btn btn-primary css_btn" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg">Add Walking Guest</button>
               <br>
               <br>
               <div class="modal fade bd-example-modal-lg" tabindex="-1" style="display: none;" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">Add Walking Guest</h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <form action="<?php echo base_url('HoteladminController/add_walking_guest') ?>" method="post" enctype="multipart/form-data">
                           <div class="modal-body">
                              <div class="col-lg-12">
                                 <div class="basic-form">
                                    <div class="row">
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Guest Name</label>
                                          <input type="text" class="form-control" name="full_name" placeholder="Guest Name" required>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Mobile No</label>
                                          <input type="text" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" name="mobile_no" placeholder="Mobile No" required>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Check-In(Date/Time)</label>
                                          <div class="input-group">
                                             <input type="date" class="form-control" name="check_in" placeholder="Date" required>
                                             <input type="time" class="form-control" name="check_in_time" placeholder="time" required>
                                          </div>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Check-Out(Date/Time)</label>
                                          <div class="input-group">
                                             <input type="date" class="form-control" name="check_out" placeholder="Date" required>
                                             <input type="time" class="form-control" name="check_out_time" placeholder="Time" required>
                                          </div>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Id Proof</label>
                                          <input type="file" name="id_proff_img" class="form-control" placeholder="" required>
                                       </div>
                                       <div class="mb-3 col-md-3">
                                          <label class="form-label">Adults</label>
                                          <input type="number" name="total_adults" id="total_adults" class="form-control" onkeyup="add_amt()" placeholder="Adults" required>
                                       </div>
                                       <div class="mb-3 col-md-3">
                                          <label class="form-label">Childs</label>
                                          <input type="number" name="total_child" id="total_child" class="form-control" onkeyup="add_amt()" placeholder="Childs" required>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Guest Type</label>
                                          <select name="guest_type" id="" class="default-select form-control wide">
                                             <option selected="" disabled=""> Choose...</option>
                                             <option value="1">Regular</option>
                                             <option value="2">CHG</option>
                                             <option value="3">VIP</option>
                                             <option value="4">WHG</option>
                                          </select>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">No.of Guest</label>
                                          <input type="number" name="no_of_guests" id="guest" class="form-control" placeholder="No. of Guest " required>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label ">No Of Rooms</label>
                                          <input type="number" name="no_of_rooms" value="1" class="form-control" placeholder="No.of Rooms" readonly>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label"> Room Type</label>
                                          <div class="input-group ">
                                             <select class="default-select form-control wide " name="room_type" id="room_type">
                                                <option>Choose Room type...</option>
                                                <?php
                                                $room_type_list_string = "";

                                                if ($room_type_list) {
                                                   $room_type_list_string = json_encode($room_type_list);
                                                   //  print_r($room_type_list_string);
                                                   //  die;

                                                   foreach ($room_type_list as $r_t) {
                                                ?>
                                                      <option value="<?php echo $r_t['room_type_id'] ?>"><?php echo $r_t['room_type_name'] ?></option>
                                                <?php
                                                   }
                                                }
                                                ?>
                                             </select>
                                             <a class="btn btn-primary btn-sm" id="btnAdd2"><i class="fa fa-plus"></i></a>
                                          </div>
                                       </div>
                                       <!-- <div id="TextBoxContainer2" class="mb-3"></div> -->
                                       <div class="mb-3 col-md-12">
                                          <label class="form-label"> Assign Room</label>
                                          <div class="accordion accordion-rounded-stylish accordion-bordered" id="accordion-eleven">
                                             <div class="row">
                                                <div class="col-xl-12">
                                                   <div class="col-xl-12">
                                                      <!-- <h4>Available Rooms</h4> -->
                                                      <div id="display_rooms_no" style="display:flex;"></div>
                                                      <div class="row row-cols-8 ">
                                                         <!-- <div class="room_card card  p-0" data-bs-toggle="modal"
                                    data-bs-target=".add" class="green">
                                    <input name="plan" class="radio" type="radio"
                                       value="Green" name="clr">
                                    <span
                                       class="room_no m-0 room_card  red colored-div">101</span>
                                    </div> -->
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="TextBoxContainer2" class="mb-3"></div>
                                 </div>
                              </div>
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Check-in</button>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
               <div class="table-scrollable today_arrival_tbl_div">
                  <table id="example1" class="display full-width">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           <th>Booking ID</th>
                           <th>Name</th>
                           <th>Date(C_In)</th>
                           <th>Date(C_Out)</th>
                           <th>Phone</th>
                           <th>Email</th>
                           <th>Rooms</th>
                           <th>Adult</th>
                           <th>Child</th>
                           <th>Assign Room</th>
                        </tr>
                     </thead>
                     <tbody id="searchTable" class="arrival_resat">
                        <?php
                        $j = 1;
                        if ($today_hotel_book_list_by_app) {
                           foreach ($today_hotel_book_list_by_app as $t_h_b) {
                              $user_data = $this->MainModel->get_user_data($t_h_b['u_id']);

                              $full_name = "";
                              $mobile_no = "";

                              if ($user_data) {
                                 $full_name = $user_data['full_name'];
                                 $mobile_no = $user_data['mobile_no'];
                                 $email_id = $user_data['email_id'];
                                 // echo "<pre>";
                                 // print_r($today_hotel_book_list_by_app);
                        ?>
                                 <tr>
                                    <td><?php echo $j++ ?></td>
                                    <td><?php echo $t_h_b['booking_id'] ?> </td>
                                    <td> <?php echo $full_name ?></td>
                                    <td> <?php echo $t_h_b['check_in'] ?></td>
                                    <td><?php echo $t_h_b['check_out'] ?> </td>
                                    <td><?php echo $mobile_no ?></td>
                                    <td><?php echo $email_id ?></td>
                                    <td><?php echo $t_h_b['no_of_rooms'] ?></td>
                                    <td><?php echo $t_h_b['total_adults'] ?></td>
                                    <td><?php echo $t_h_b['total_child'] ?></td>
                                    <td>
                                       <button type="button" style="margin:auto" data-booking-id ="<?php echo $t_h_b['booking_id'] ?>"  data-book-room ="<?php echo $t_h_b['no_of_rooms'] ?>" data-room-type = "<?php echo $t_h_b['room_type'] ?>" class="btn btn-success shadow btn-xs room_assigne_btn">
                                          <i class="fa fa-check"></i>
                                       </button>
                                    </td>
                                 </tr>
                        <?php
                              }
                           }
                        }
                        ?>
                     </tbody>
                  </table>
               </div>
            </div>
            <div class="tab-pane" id="arrival2_div" style="background-color:white;">
               <button style="float:right;" type="button" class="btn btn-primary css_btn" data-bs-toggle="modal" data-bs-target=".bd-example-modal-lg1">Add Walking Guest</button>
               <br>
               <br>
               <div class="modal fade bd-room-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">Room Allocation</h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal">
                           </button>
                        </div>
                        <div class="modal-body">
                           <div class="basic-form">
                              <form>
                                 <div class="col-xl-12">
                                    <h4>Available Rooms</h4>
                                    <div class="row row-cols-8 ">
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add" class="green">
                                          <input name="plan" class="radio" type="checkbox" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div">101</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">106</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">107</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">108</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">109</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">110</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">111</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">112</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">113</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">114</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">115</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">116</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">117</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">118</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">119</span>
                                       </div>
                                       <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add">
                                          <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                          <span class="room_no m-0 room_card  red colored-div ">120</span>
                                       </div>
                                    </div>
                                 </div>
                              </form>
                           </div>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-primary css_btn">Check-in</button>
                           <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                        </div>
                     </div>
                  </div>
               </div> <!-- end of modal  -->
               <div class="modal fade bd-example-modal-lg1" tabindex="-1" style="display: none;" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">Add Walking Guest</h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal">
                           </button>
                        </div>
                        <div class="modal-body">
                           <div class="col-lg-12">
                              <div class="basic-form">
                                 <form>
                                    <div class="row">
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Guest Name</label>
                                          <input type="text" class="form-control" placeholder="">
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Mobile No</label>
                                          <input type="text" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" name="mobile_no" placeholder="Mobile No" required>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Check-In</label>
                                          <div class="input-group">
                                             <input type="date" class="form-control" placeholder="Date">
                                             <input type="time" class="form-control" placeholder="time">
                                          </div>
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label">Check-Out</label>
                                          <div class="input-group">
                                             <input type="date" class="form-control" placeholder="Date">
                                             <input type="time" class="form-control" placeholder="time">
                                          </div>
                                       </div>
                                       <div class="mb-3 col-md-4">
                                          <label class="form-label">Id Proof</label>
                                          <input type="file" class="form-control" placeholder="" multiple="">
                                       </div>
                                       <div class="mb-3 col-md-4">
                                          <label class="form-label">Adults</label>
                                          <input type="number" class="form-control" placeholder="">
                                       </div>
                                       <div class="mb-3 col-md-4">
                                          <label class="form-label">Childs</label>
                                          <input type="number" class="form-control" placeholder="" multiple="">
                                       </div>
                                    </div>
                                    <div class="row ">
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label ">No Of Rooms</label>
                                          <input type="number" class="form-control" placeholder="No.of Rooms ">
                                       </div>
                                       <div class="mb-3 col-md-6">
                                          <label class="form-label"> Room Type</label>
                                          <div class="input-group ">
                                             <select class="default-select form-control wide " name="is_active" id="active2">
                                                <option>Choose Room type...</option>
                                                <option>Single</option>
                                                <option>Double</option>
                                                <option>Twin</option>
                                                <option>King</option>
                                             </select>
                                             <a class="btn btn-primary btn-sm" id="btnAdd2"><i class="fa fa-plus"></i></a>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="TextBoxContainer2" class="mb-3"></div>
                                    <div class="mb-3 col-md-12">
                                       <label class="form-label"> Assign Room</label>
                                       <div class="accordion accordion-rounded-stylish accordion-bordered" id="accordion-eleven">
                                          <div class="row">
                                             <div class="col-xl-12">
                                                <div class="col-xl-12">
                                                   <!-- <h4>Available Rooms</h4> -->
                                                   <div class="row row-cols-8 ">
                                                      <div class="room_card card  p-0" data-bs-target=".add" class="green" for="colored-div">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr" for="colored-div">
                                                         <span class="room_no m-0 room_card  red colored-div">101</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">106</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">107</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">108</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">109</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">110</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">111</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">112</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">113</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">114</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">115</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">116</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">117</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">118</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">119</span>
                                                      </div>
                                                      <div class="room_card card  p-0" data-bs-target=".add">
                                                         <input name="plan" class="radio" type="radio" value="Green" name="clr">
                                                         <span class="room_no m-0 room_card  red colored-div ">120</span>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                           <button type="button" class="btn btn-primary">Check-in</button>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="table-scrollable">
                  <table id="arrival_tbl" class="display full-width">
                     <thead>
                        <tr>
                           <th>Sr.No.</th>
                           <th>Name</th>
                           <th>Date(C_In)</th>
                           <th>Date(C_Out)</th>
                           <th>Phone</th>
                           <th>Email</th>
                           <th>Rooms</th>
                           <th>Adult</th>
                           <th>Child</th>
                        </tr>
                     </thead>
                     <tbody id="searchTable">
                        <?php
                        $j = 1;
                        if ($today_hotel_book_list_by_app1) {
                           foreach ($today_hotel_book_list_by_app1 as $t_h_b) {
                              $user_data = $this->MainModel->get_admin_data($t_h_b['u_id']);
                              //  print_r( $user_data);
                              $full_name = "";
                              $mobile_no = "";

                              if ($user_data) {
                                 $full_name = $user_data['full_name'];
                                 $mobile_no = $user_data['mobile_no'];
                                 $email_id = $user_data['email_id'];
                        ?>
                                 <tr>
                                    <td>
                                       <?php echo $j++ ?>
                                    </td>
                                    <td>
                                       <?php echo $full_name ?>
                                    </td>
                                    <td>
                                       <?php echo $t_h_b['check_in'] ?>
                                    </td>
                                    <td>
                                       <?php echo $t_h_b['check_out'] ?>
                                    </td>
                                    <td>
                                       <?php echo $mobile_no ?>
                                    </td>
                                    <td>
                                       <?php echo $email_id ?>
                                    </td>
                                    <td>
                                       <?php echo $t_h_b['no_of_rooms'] ?>
                                    </td>
                                    <td>
                                       <?php echo $t_h_b['total_adults'] ?>
                                    </td>
                                    <td>
                                       <?php echo $t_h_b['total_child'] ?>
                                    </td>
                                    <!-- Modal -->
                                    <div class="modal fade bd-room-modal-sm_<?php echo $t_h_b['booking_id'] ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                       <div class="modal-dialog modal-lg">
                                          <div class="modal-content">
                                             <div class="modal-header">
                                                <h5 class="modal-title">Room Allocation</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                </button>
                                             </div>
                                             <form action="<?php echo base_url('MainController/assign_rooms') ?>" method="post">
                                                <input type="hidden" name="booking_id" value="<?php echo $t_h_b['booking_id'] ?>">
                                                <div class="modal-body">
                                                   <div class="basic-form">
                                                      <div class="col-xl-12">
                                                         <h4>Available Rooms</h4>
                                                         <div class="row row-cols-8 ">
                                                            <?php
                                                            // $admin_id = $this->session->userdata('admin_id');
                                                            $u_id = $this->session->userdata('u_id');
                                                            $where = '(u_id = "' . $u_id . '")';
                                                            $admin_details = $this->MainModel->getData($tbl = 'register', $where);

                                                            $hotel_enquiry_request_id = '';
                                                            $wh = '(u_id ="' . $admin_details['hotel_id'] . '")';
                                                            $get_hotel_name = $this->MainModel->getData($tbl = 'register', $wh);

                                                            $admin_id = $admin_details['hotel_id'];

                                                            $room_no_data = $this->MainModel->get_room_nos($admin_id, $t_h_b['room_type']);

                                                            if ($t_h_b['no_of_rooms'] == 1) {
                                                               if ($room_no_data) {
                                                                  //print_r($room_no_data);
                                                                  foreach ($room_no_data as $r_no) {
                                                                     $wh_r = '(hotel_id = "' . $admin_id . '" AND room_no = "' . $r_no['room_no'] . '" AND room_status = 3)';

                                                                     $room_avaibility = $this->MainModel->getData('room_status', $wh_r);
                                                                     // print_r($room_avaibility);

                                                                     if ($room_avaibility) {

                                                            ?>
                                                                        <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add" class="green">
                                                                           <input name="room_no" class="radio" type="radio" value="<?php echo $r_no['room_no'] ?>">
                                                                           <span class="room_no m-0 room_card  red colored-div"><?php echo $r_no['room_no'] ?></span>
                                                                           <input name="price" value="<?php echo $r_no['price'] ?>" type="hidden">
                                                                           <input name="room_type" value="<?php echo $t_h_b['room_type'] ?>" type="hidden">
                                                                        </div>
                                                                        <?php
                                                                     }
                                                                  }
                                                               } else {
                                                                  echo "Rooms not available";
                                                               }
                                                            } else {
                                                               if ($t_h_b['no_of_rooms'] >= 2) {
                                                                  if ($room_no_data) {
                                                                     foreach ($room_no_data as $r_no) {
                                                                        $wh_r = '(hotel_id = "' . $admin_id . '" AND room_no = "' . $r_no['room_no'] . '" AND room_status = 3)';

                                                                        $room_avaibility = $this->MainModel->getData('room_status', $wh_r);

                                                                        if ($room_avaibility) {

                                                                        ?>
                                                                           <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add" class="green">
                                                                              <input name="room_no1[]" class="radio" type="checkbox" value="<?php echo $r_no['room_no'] ?>">
                                                                              <span class="room_no m-0 room_card  red colored-div"><?php echo $r_no['room_no'] ?></span>
                                                                              <input name="price1[]" value="<?php echo $r_no['price'] ?>" type="hidden">
                                                                              <input name="room_type" value="<?php echo $t_h_b['room_type'] ?>" type="hidden">
                                                                           </div>
                                                            <?php
                                                                        }
                                                                     }
                                                                  } else {
                                                                     echo "Rooms not available";
                                                                  }
                                                               }
                                                            }
                                                            ?>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="modal-footer">
                                                   <button type="submit" class="btn btn-primary css_btn">Check-in</button>
                                                   <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                </div>
                                             </form>
                                          </div>
                                       </div>
                                    </div>
                                 </tr>
                        <?php
                              }
                           }
                        }

                        ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div>
         </div>
      </div>
   </div>
</div>
<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
<!-- chiragi Start :: modal -->
<div class="modal fade" id="room_assigne_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Room Allocation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body get_rooms_data">
         <!-- <form id="room_assigne_modal_form">
            <input type="hidden" name="booking_id_get" id="booking_id_get" value="">
            <input type="hidden" name="book_room_num" id="book_room_num" value="">
            <input type="hidden" name="room_type" id="room_type_get" value="">
            <div class="basic-form">
               <div class="col-xl-12">
                  <h4>Available Rooms</h4>
                  <div class="row row-cols-8">
                  <?php
                     $admin_id = $this->session->userdata('u_id');
                     $room_no_data = $this->MainModel->get_room_nos($admin_id, $room_type);

                     if(!empty($book_room_num))
                     {
                        if ($book_room_num == 1) 
                        {
                              if ($room_no_data) 
                              {
                                 foreach ($room_no_data as $r_no) 
                                 {
                                    $wh_r = '(hotel_id = "' . $admin_id . '" AND room_no = "' . $r_no['room_no'] . '" AND room_status = 3)';

                                    $room_avaibility = $this->MainModel->getData('room_status', $wh_r);
                                    echo "<pre>";
                                    print_r($room_avaibility);

                                    if ($room_avaibility) 
                                    {
                                    ?>
                                          <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add" class="green">
                                             <input name="room_no" class="radio" type="radio" value="<?php echo $r_no['room_no'] ?>">
                                             <span class="room_no m-0 room_card  red colored-div"><?php echo $r_no['room_no'] ?></span>
                                             <input name="price" value="<?php echo $r_no['price'] ?>" type="hidden">
                                             <input name="room_type" value="<?php echo $room_type; ?>" type="hidden">
                                          </div>
                                    <?php
                                    }
                                    else 
                                    {
                                          echo "Rooms not available";
                                    }
                                 }
                              } 
                              else 
                              {
                                 echo "Rooms not available";
                              }
                        } 
                        else 
                        {
                              if ($book_room_num >= 2) 
                              {
                                 if ($room_no_data) 
                                 {
                                    foreach ($room_no_data as $r_no) 
                                    {
                                          $wh_r = '(hotel_id = "' . $admin_id . '" AND room_no = "' . $r_no['room_no'] . '" AND room_status = 3)';

                                          $room_avaibility = $this->MainModel->getData('room_status', $wh_r);

                                          if ($room_avaibility) 
                                          {
                                          ?>
                                             <div class="room_card card  p-0" data-bs-toggle="modal" data-bs-target=".add" class="green">
                                                <input name="room_no1[]" class="radio" type="checkbox" value="<?php echo $r_no['room_no'] ?>">
                                                <span class="room_no m-0 room_card  red colored-div"><?php echo $r_no['room_no'] ?></span>
                                                <input name="price1[]" value="<?php echo $r_no['price'] ?>" type="hidden">
                                                <input name="room_type" value="<?php echo $room_type; ?>" type="hidden">
                                             </div>
                                          <?php
                                          }
                                    }
                                 } 
                                 else 
                                 {
                                    echo "Rooms not available";
                                 }
                              }
                        }
                     }
                     else
                     {
                        echo "Not geting count of room booking!";
                     }
                  ?>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="submit" class="btn btn-primary css_btn">Check-in</button>
               <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
            </div>
         </form> -->
      </div>
    </div>
  </div>
</div>
<!-- Chiragi End :: modal -->
<script>
   $(document).ready(function () {
      $('#today_arrival_tbl_id').DataTable();
      $(document).on('click','.room_assigne_btn', function () {
         var booking_id_get = $(this).attr('data-booking-id');
         var book_room_num = $(this).attr('data-book-room');
         var room_type_get = $(this).attr('data-room-type');
         // console.log(booking_id_get);
         // console.log(book_room_num);
         // console.log(room_type_get);
         $.ajax({
            url: '<?= base_url('HoteladminController/assign_rooms_modal') ?>',
            method: 'POST',
            data: {
               booking_id_get : booking_id_get,
               book_room_num : book_room_num,
               room_type_get : room_type_get
            },
            // processData: false,
            // contentType: false,
            // cache: false,
            success: function (response) {
               // console.log(response);
               $('.get_rooms_data').html('');
               $('.get_rooms_data').append(response);
               $('#room_assigne_modal').modal('show');
            }
         });
      });

      $(document).unbind('submit').on('submit','#room_assigne_modal_form', function (e) {
         e.preventDefault();
         $(".loader_block").show();
         var form_data = new FormData(this);
         $.ajax({
            url: '<?= base_url('HoteladminController/assign_rooms') ?>',
            method: 'POST',
            data: form_data,
            processData: false,
            contentType: false,
            cache: false,
            success: function (ans) {
               // console.log(ans);
               $.get('<?= base_url('HoteladminController/ajax_resetdata_arrival'); ?>', function(data) {
                     var resu = $(data).find('.today_arrival_tbl_div').html();
                     $('.today_arrival_tbl_div').html(resu);
                     setTimeout(function() {
                        $('#today_arrival_tbl_id').DataTable();
                     }, 2000);
                  });

                  $(".arrival_resat").html(ans);
                  setTimeout(function() {
                     $(".loader_block").hide();
                     $('#room_assigne_modal').modal('hide');
                     $(".updatemessage").show();
                  }, 2000);
                  setTimeout(function() {
                     $(".updatemessage").hide();
                  }, 4000);
               // $('.get_rooms_data').html('');
               // $('.get_rooms_data').append(response);
            }
         });
      });
   });
</script>
   <!-- </div> -->
<?php } elseif ($sub_icon_id == 4) { ?>
   <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
   <div class="col-md-12">
      <div class="card card-topline-aqua">
         <div class="card-head">
            <header>Shuttle Information</header>
         </div>
         <div class="card-body">
            <div class="new_orders_div_service">
               <div class="table-scrollable">
                  <table id="example1" class="display full-width">
                     <thead>
                        <tr>
                           <th>Sr. No.</th>
                           <th><strong>Staff Name</strong></th>
                           <th><strong>Contact Number</strong></th>
                           <th><strong>Description</strong></th>
                           <th><strong>Terms & conditions</strong></th>
                           <th><strong>Picture</strong></th>
                           <th><strong>Action</strong></th>
                        </tr>
                     </thead>
                     <tbody id="searchTable" class="shuttle_new_data">
                        <?php
                        $i = 1;
                        if ($list) {
                           foreach ($list as $sh_f_s) {
                              $wh = '(front_ofs_service_id = "' . $sh_f_s['front_ofs_service_id'] . '")';

                              $services_img = $this->HotelAdminModel->getData('front_ofs_services_images', $wh);
                        ?>
                              <tr>
                                 <td><?php echo $i++ ?></td>
                                 <td><?php echo $sh_f_s['staff_name'] ?></td>
                                 <td><?php echo $sh_f_s['contact_no'] ?></td>
                                 <!-- <td>
                     <button
                         class="btn btn-secondary_<?php echo $sh_f_s['front_ofs_service_id'] ?> shadow btn-xs sharp me-1"><i
                             class="fas fa-eye"></i></button>
                     </td> -->
                     <td>
                              

                              <a href="#" class="btn btn-secondary btn-xs edit_model_click_shuttle"   data-unic-id5="<?php echo $sh_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                           </td>
                           <td>
                           <a href="#" class="btn btn-secondary btn-xs edit_model_click_shuttle_term"   data-unic-id6="<?php echo $sh_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                             
                           </td>
                             
                             
                                 <td>
                                 <div class="lightgallery" class="room-list-bx d-flex align-items-center">
                                          <a href="<?php echo $services_img['image'] ?>" target="_blank" data-exthumbimage="<?php echo $services_img['image'] ?>" data-src="<?php echo $services_img['image'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                             <img class="me-3 " src="<?php echo $services_img['image'] ?>" alt="" style="width:50px; height:40px;">
                                          </a>
                                       </div>
                                    <!-- <div id="gallery" data-toggle="modal" data-target="#exampleModal">
                                       <img class="me-3 " src="<?php echo $services_img['image'] ?>"  alt="" data-bs-toggle="modal" data-bs-target=".bd-example1-modal-md_<?php echo $sh_f_s['front_ofs_service_id'] ?>" data-slide-to="0" style="height:30px; width:60px;">
                                    </div> -->
                                 </td>
                               
                                 <td>
                                    <a href="#" class="btn btn-warning shadow btn-xs sharp me-1" id="edit_shuttle_data" data-bs-toggle="modal" data-idshuttle="<?= $sh_f_s['front_ofs_service_id'] ?>" data-bs-target=".edit_shuttle_model"><i class="fa fa-pencil"></i></a>
                                    <!-- <a href="#" onclick="delete_data(<?php echo $sh_f_s['front_ofs_service_id'] ?>)"
                        class="btn btn-info shadow btn-xs sharp"><i
                            class="fa fa-list"></i></a> -->
                                    <!-- <a  href="#" title="Availability" 
                        class="btn btn-info shadow btn-xs sharp" onclick="orderservice1(<?php echo $sh_f_s['front_ofs_service_id'] ?>)" ><i
                            class="fa fa-list"  ></i></a> -->
                                    <a href="#" class="btn btn-secondary shadow btn-xs sharp me-1 room_id" data-bs-toggle="modal" room-id=<?= $sh_f_s['front_ofs_service_id'] ?> data-bs-target=".bd-view-modal"><i class="fa fa-list"></i>
                                    </a>
                                 </td>
                              </tr>
                             
                        <?php
                           }
                        }

                        ?>
                     </tbody>
                  </table>
               </div>
            </div>

            <div class="modal fade bd-view-modal <?php echo $sh_f_s['front_ofs_service_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
               <div class="modal-dialog modal-lg">
                  <div class="modal-content" style="width:130%;">
                     <form id="frmblock" method="post" enctype="multipart/form-data">
                        <div class="modal-header">
                           <h5 class="modal-title" style="font-weight: bold;font-size: 15px !important;">Shuttle Availability </h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal">
                           </button>
                        </div>
                        <div class="modal-body view_Room_Id" style="margin-bottom:30px;">
                        </div>
                     </form>
                  </div>
               </div>
               <div class="accepted_orders_div_service" style="display: none;">
                  <div class="col-md-12 col-sm-12">
                     <div class="panel tab-border card-box">
                        <header class="panel-heading panel-heading-gray custom-tab">
                           <ul class="nav nav-tabs">
                              <li class="nav-item"><a href="#sunday_div" data-bs-toggle="tab" class="active">Sunday</a>
                              </li>
                              <li class="nav-item"><a href="#monday_div" data-bs-toggle="tab">Monday</a>
                              </li>
                              <li class="nav-item"><a href="#tuesday_div" data-bs-toggle="tab">Tuesday</a>
                              </li>
                              <li class="nav-item"><a href="#wednesday_div" data-bs-toggle="tab">Wednesday</a>
                              </li>
                              <li class="nav-item"><a href="#thursday_div" data-bs-toggle="tab">Thursday</a>
                              </li>
                              <li class="nav-item"><a href="#friday_div" data-bs-toggle="tab">Friday</a>
                              </li>
                              <li class="nav-item"><a href="#saturday_div" data-bs-toggle="tab">Saturday</a>
                              </li>
                           </ul>
                        </header>
                     </div>
                  </div>
                  <div class="tab-content">
                     <div class="tab-pane active" style="background-color:white;" id="sunday_div">
                        <br>
                        <form action="<?php echo base_url('HoteladminController/add_shuttle_service_staff_avaibility') ?>" method="post">
                           <input type="hidden" name="day" value="Sunday">
                           <input type="hidden" name="front_ofs_service_id" value="1">
                           <div class="row ">
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">Start Time</label>
                                 <div class="input-group">
                                    <input type="time" name="start_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">End Time</label>
                                 <div class="input-group">
                                    <input type="time" name="end_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mt-4 col-md-3 form-group">
                                 <button type="submit" class="btn btn-info" style="margin-top: 7px;">Add
                                 </button>
                              </div>
                           </div>
                        </form>
                        <h4 class="card-title"><b>Sunday Availability</b></h4>
                        <div class="table-scrollable">
                           <table id="acceptedOrder_tb5" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Timing</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 if ($sun_list) {
                                    foreach ($sun_list as $sun_l) {
                                 ?>
                                       <tr>
                                          <td><strong><?php echo date('h:i a', strtotime($sun_l['start_time'])) . " - " . date('h:i a', strtotime($sun_l['end_time'])) ?> </strong></td>
                                          <td>
                                             <div class="container">
                                                <label class="switch">
                                                   <?php
                                                   if ($sun_l['available_status'] == 1) {
                                                   ?>
                                                      <input type="checkbox" value="0" name="available_status" id="status_<?php echo $sun_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $sun_l['shuttle_service_avaibility_id'] ?>)" class="switch-input" checked>
                                                      <span class="switch-label" data-on="Available"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   } else {
                                                   ?>
                                                      <input type="checkbox" value="1" name="available_status" id="status_<?php echo $sun_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $sun_l['shuttle_service_avaibility_id'] ?>)" class="switch-input">
                                                      <span class="switch-label" data-off="Unavailable"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   }
                                                   ?>
                                                </label>
                                             </div>
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="monday_div" style="background-color:white;">
                        <br>
                        <form action="<?php echo base_url('HoteladminController/add_shuttle_service_staff_avaibility') ?>" method="post">
                           <input type="hidden" name="day" value="Monday">
                           <input type="hidden" name="front_ofs_service_id" value="1">
                           <div class="row ">
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">Start Time</label>
                                 <div class="input-group">
                                    <input type="time" name="start_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">End Time</label>
                                 <div class="input-group">
                                    <input type="time" name="end_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mt-4 col-md-3 form-group">
                                 <button type="submit" class="btn btn-info" style="margin-top: 7px;">Add
                                 </button>
                              </div>
                           </div>
                        </form>
                        <h4 class="card-title"><b>Monday Availability</b></h4>
                        <div class="table-scrollable">
                           <table id="monday_tbl" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Timing</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 if ($mon_list) {
                                    foreach ($mon_list as $ml) {
                                 ?>
                                       <tr>
                                          <td><strong><?php echo date('h:i a', strtotime($ml['start_time'])) . " - " . date('h:i a', strtotime($ml['end_time'])) ?> </strong></td>
                                          <td>
                                             <div class="container">
                                                <label class="switch">
                                                   <?php
                                                   if ($ml['available_status'] == 1) {
                                                   ?>
                                                      <input type="checkbox" value="0" name="available_status" id="status_<?php echo $ml['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $ml['shuttle_service_avaibility_id'] ?>)" class="switch-input" checked>
                                                      <span class="switch-label" data-on="Available"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   } else {
                                                   ?>
                                                      <input type="checkbox" value="1" name="available_status" id="status_<?php echo $ml['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $ml['shuttle_service_avaibility_id'] ?>)" class="switch-input">
                                                      <span class="switch-label" data-off="Unavailable"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   }
                                                   ?>
                                                </label>
                                             </div>
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="tuesday_div" style="background-color:white;">
                        <br>
                        <form action="<?php echo base_url('HoteladminController/add_shuttle_service_staff_avaibility') ?>" method="post">
                           <input type="hidden" name="day" value="Tuesday">
                           <input type="hidden" name="front_ofs_service_id" value="1">
                           <div class="row ">
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">Start Time</label>
                                 <div class="input-group">
                                    <input type="time" name="start_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">End Time</label>
                                 <div class="input-group">
                                    <input type="time" name="end_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mt-4 col-md-3 form-group">
                                 <button type="submit" class="btn btn-info" style="margin-top: 7px;">Add
                                 </button>
                              </div>
                           </div>
                        </form>
                        <h4 class="card-title"><b>Tuesday Availability</b></h4>
                        <div class="table-scrollable">
                           <table id="tuesday_tbl" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Timing</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 if ($tue_list) {
                                    foreach ($tue_list as $tuel) {
                                 ?>
                                       <tr>
                                          <td><strong><?php echo date('h:i a', strtotime($tuel['start_time'])) . " - " . date('h:i a', strtotime($tuel['end_time'])) ?> </strong></td>
                                          <td>
                                             <div class="container">
                                                <label class="switch">
                                                   <?php
                                                   if ($tuel['available_status'] == 1) {
                                                   ?>
                                                      <input type="checkbox" value="0" name="available_status" id="status_<?php echo $tuel['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $tuel['shuttle_service_avaibility_id'] ?>)" class="switch-input" checked>
                                                      <span class="switch-label" data-on="Available"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   } else {
                                                   ?>
                                                      <input type="checkbox" value="1" name="available_status" id="status_<?php echo $tuel['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $tuel['shuttle_service_avaibility_id'] ?>)" class="switch-input">
                                                      <span class="switch-label" data-off="Unavailable"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   }
                                                   ?>
                                                </label>
                                             </div>
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="wednesday_div" style="background-color:white;">
                        <br>
                        <form action="<?php echo base_url('HoteldaminController/add_shuttle_service_staff_avaibility') ?>" method="post">
                           <input type="hidden" name="day" value="Wednesday">
                           <input type="hidden" name="front_ofs_service_id" value="1">
                           <div class="row ">
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">Start Time</label>
                                 <div class="input-group">
                                    <input type="time" name="start_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">End Time</label>
                                 <div class="input-group">
                                    <input type="time" name="end_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mt-4 col-md-3 form-group">
                                 <button type="submit" class="btn btn-info" style="margin-top: 7px;">Add
                                 </button>
                              </div>
                           </div>
                        </form>
                        <h4 class="card-title"><b>Wednesday Availability</b></h4>
                        <div class="table-scrollable">
                           <table id="wednesday_tbl" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Timing</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 if ($wed_list) {
                                    foreach ($wed_list as $wed_l) {
                                 ?>
                                       <tr>
                                          <td><strong><?php echo date('h:i a', strtotime($wed_l['start_time'])) . " - " . date('h:i a', strtotime($wed_l['end_time'])) ?> </strong></td>
                                          <td>
                                             <div class="container">
                                                <label class="switch">
                                                   <?php
                                                   if ($wed_l['available_status'] == 1) {
                                                   ?>
                                                      <input type="checkbox" value="0" name="available_status" id="status_<?php echo $wed_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $wed_l['shuttle_service_avaibility_id'] ?>)" class="switch-input" checked>
                                                      <span class="switch-label" data-on="Available"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   } else {
                                                   ?>
                                                      <input type="checkbox" value="1" name="available_status" id="status_<?php echo $wed_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $wed_l['shuttle_service_avaibility_id'] ?>)" class="switch-input">
                                                      <span class="switch-label" data-off="Unavailable"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   }
                                                   ?>
                                                </label>
                                             </div>
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="thursday_div" style="background-color:white;">
                        <br>
                        <form action="<?php echo base_url('HoteladminController/add_shuttle_service_staff_avaibility') ?>" method="post">
                           <input type="hidden" name="day" value="Thursday">
                           <input type="hidden" name="front_ofs_service_id" value="1">
                           <div class="row ">
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">Start Time</label>
                                 <div class="input-group">
                                    <input type="time" name="start_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">End Time</label>
                                 <div class="input-group">
                                    <input type="time" name="end_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mt-4 col-md-3 form-group">
                                 <button type="submit" class="btn btn-info" style="margin-top: 7px;">Add
                                 </button>
                              </div>
                           </div>
                        </form>
                        <h4 class="card-title"><b>Thursday Availability</b></h4>
                        <div class="table-scrollable">
                           <table id="thursday_tbl" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Timing</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 if ($thurs_list) {
                                    foreach ($thurs_list as $thu_l) {
                                 ?>
                                       <tr>
                                          <td><strong><?php echo date('h:i a', strtotime($thu_l['start_time'])) . " - " . date('h:i a', strtotime($thu_l['end_time'])) ?> </strong></td>
                                          <td>
                                             <div class="container">
                                                <label class="switch">
                                                   <?php
                                                   if ($thu_l['available_status'] == 1) {
                                                   ?>
                                                      <input type="checkbox" value="0" name="available_status" id="status_<?php echo $thu_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $thu_l['shuttle_service_avaibility_id'] ?>)" class="switch-input" checked>
                                                      <span class="switch-label" data-on="Available"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   } else {
                                                   ?>
                                                      <input type="checkbox" value="1" name="available_status" id="status_<?php echo $wed_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $thu_l['shuttle_service_avaibility_id'] ?>)" class="switch-input">
                                                      <span class="switch-label" data-off="Unavailable"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   }
                                                   ?>
                                                </label>
                                             </div>
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="friday_div" style="background-color:white;">
                        <br>
                        <form action="<?php echo base_url('HoteladminController/add_shuttle_service_staff_avaibility') ?>" method="post">
                           <input type="hidden" name="day" value="Friday">
                           <input type="hidden" name="front_ofs_service_id" value="1">
                           <div class="row ">
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">Start Time</label>
                                 <div class="input-group">
                                    <input type="time" name="start_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">End Time</label>
                                 <div class="input-group">
                                    <input type="time" name="end_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mt-4 col-md-3 form-group">
                                 <button type="submit" class="btn btn-info" style="margin-top: 7px;">Add
                                 </button>
                              </div>
                           </div>
                        </form>
                        <h4 class="card-title"><b>Friday Availability</b></h4>
                        <div class="table-scrollable">
                           <table id="friday_tbl" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Timing</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 if ($fri_list) {
                                    foreach ($fri_list as $fr_l) {
                                 ?>
                                       <tr>
                                          <td><strong><?php echo date('h:i a', strtotime($fr_l['start_time'])) . " - " . date('h:i a', strtotime($fr_l['end_time'])) ?> </strong></td>
                                          <td>
                                             <div class="container">
                                                <label class="switch">
                                                   <?php
                                                   if ($fr_l['available_status'] == 1) {
                                                   ?>
                                                      <input type="checkbox" value="0" name="available_status" id="status_<?php echo $fr_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $fr_l['shuttle_service_avaibility_id'] ?>)" class="switch-input" checked>
                                                      <span class="switch-label" data-on="Available"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   } else {
                                                   ?>
                                                      <input type="checkbox" value="1" name="available_status" id="status_<?php echo $fr_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $fr_l['shuttle_service_avaibility_id'] ?>)" class="switch-input">
                                                      <span class="switch-label" data-off="Unavailable"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   }
                                                   ?>
                                                </label>
                                             </div>
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="saturday_div" style="background-color:white;">
                        <br>
                        <form action="<?php echo base_url('HoteladminController/add_shuttle_service_staff_avaibility') ?>" method="post">
                           <input type="hidden" name="day" value="Saturday">
                           <input type="hidden" name="front_ofs_service_id" value="1">
                           <div class="row ">
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">Start Time</label>
                                 <div class="input-group">
                                    <input type="time" name="start_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mb-3 col-md-3 form-group">
                                 <label class="form-label">End Time</label>
                                 <div class="input-group">
                                    <input type="time" name="end_time" class="form-control" required>
                                 </div>
                              </div>
                              <div class="mt-4 col-md-3 form-group">
                                 <button type="submit" class="btn btn-info" style="margin-top: 7px;">Add
                                 </button>
                              </div>
                           </div>
                        </form>
                        <h4 class="card-title"><b>Saturday Availability</b></h4>
                        <div class="table-scrollable">
                           <table id="saturday_tbl" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Timing</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 if ($sat_list) {
                                    foreach ($sat_list as $sat_l) {
                                 ?>
                                       <tr>
                                          <td><strong><?php echo date('h:i a', strtotime($sat_l['start_time'])) . " - " . date('h:i a', strtotime($sat_l['end_time'])) ?> </strong></td>
                                          <td>
                                             <div class="container">
                                                <label class="switch">
                                                   <?php
                                                   if ($sat_l['available_status'] == 1) {
                                                   ?>
                                                      <input type="checkbox" value="0" name="available_status" id="status_<?php echo $sat_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $sat_l['shuttle_service_avaibility_id'] ?>)" class="switch-input" checked>
                                                      <span class="switch-label" data-on="Available"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   } else {
                                                   ?>
                                                      <input type="checkbox" value="1" name="available_status" id="status_<?php echo $sat_l['shuttle_service_avaibility_id'] ?>" onchange="change_status(<?php echo $sat_l['shuttle_service_avaibility_id'] ?>)" class="switch-input">
                                                      <span class="switch-label" data-off="Unavailable"></span>
                                                      <span class="switch-handle"></span>
                                                   <?php
                                                   }
                                                   ?>
                                                </label>
                                             </div>
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <?php
         if ($list) {
            foreach ($list as $sh_f_s) {
         ?>
               <div class="modal fade edit_shuttle_model" tabindex="-1" style="display: none;" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title">Edit schedule</h5>
                           <button type="button" class="btn-close" data-bs-dismiss="modal">
                           </button>
                        </div>
                        <form id="editshuttleCenterForm" method="post" enctype="multipart/form-data">
                           <div class="modal-body">
                              <div class="col-lg-12">
                                 <div class="basic-form">
                                    <input type="hidden" name="front_ofs_service_id" id="front_ofs_service_id3">
                                    <input type="hidden" class="form-control" value="4" name="service_name">
                                    <div class="row">
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Staff Name</label>
                                          <input type="text" name="staff_name" id="staff_name3" class="form-control" required="">
                                       </div>
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Contact Number</label>
                                          <input type="text" name="contact_no" maxlength="10" id="contact_no3" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control"  required="">
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Description</label>
                                          <textarea class="summernote" name="description" rows="3" id="comment3" required=""></textarea>
                                       </div>
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Terms & Conditions</label>
                                          <textarea class="summernote" name="t_nd_c" rows="3" id="comment4" required=""></textarea>
                                       </div>
                                    </div>
                                    <?php
                                    $wh1 = '(front_ofs_service_id = "' . $sh_f_s['front_ofs_service_id'] . '")';

                                    $services_imgs = $this->MainModel->getData('front_ofs_services_images', $wh1);

                                    // $j = 0;

                                    if ($services_imgs) {

                                    ?>
                                       <div class="mb-3 col-md-6 form-group">
                                          <label class="form-label">Pictures</label>
                                          <?php
                                          // foreach($services_imgs as $se_i)
                                          // {
                                          ?>
                                          
                                          <!-- <input type="file" class="dropify form-control" name="shuttle_img" id="files" accept="image/jpeg, image/png, image/gif," data-default-file="<?php echo $services_imgs['image'] ?>"> -->
                                          <input type="hidden" name="front_ofs_service_img_id" id="front_ofs_service_image">
                                          <input type="file" name="shuttle_img" class="form-control" placeholder="">
                                          <img src="" id="img3" alt="Not Found" height="50" width="50">
                                          <br>
                                          <output id="Filelist"></output>
                                          <?php
                                          //     $j++;
                                          // }
                                          ?>
                                       </div>
                                    <?php
                                    }
                                    ?>
                                    <div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-info" data-bs-dismiss="modal">Save changes</button>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
         <?php
            }
         }
         ?>

<div class="modal fade" id="discription_shuttle_view_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Description</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model_shuttle_dis">
       
        </div>
    </div>
    </div>
  </div>
</div>
<div class="modal fade" id="terms_shuttle_view_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Terms And Conditions</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model_shuttle_term">
       
        </div>
    </div>
    </div>
  </div>
</div>

   <script>
      $(document).on('click','.edit_model_click_shuttle', function () {
   
   var id = $(this).attr('data-unic-id5');
     
   $('#discription_shuttle_view_model').modal('show');
  
   // $('#set_id_in_model').val($(this).attr('data-unic-id'));
   var base_url = '<?php echo base_url();?>';
   $.ajax({
       // method: "POST",
       // url: base_url+"HoteladminController/get_view_name_data_notification",
       url: '<?= base_url('HoteladminController/get_discri_name_data_shuttle') ?>',
       type: "post",
       data: {id : id},
       // dataType: "dataType",
       success: function (response) {
       console.log(response);
       $('.get_data_model_shuttle_dis').html(response);
       }
   });
});

$(document).on('click','.edit_model_click_shuttle_term', function () {

var id = $(this).attr('data-unic-id6');

$('#terms_shuttle_view_model').modal('show');

// $('#set_id_in_model').val($(this).attr('data-unic-id'));
var base_url = '<?php echo base_url();?>';
$.ajax({
  // method: "POST",
  // url: base_url+"HoteladminController/get_view_name_data_notification",
  url: '<?= base_url('HoteladminController/get_terms_name_data_shuttle') ?>',
  type: "post",
  data: {id : id},
  // dataType: "dataType",
  success: function (response) {
  console.log(response);
  $('.get_data_model_shuttle_term').html(response);
  }
});
});

      // $(document).ready(function(id) {
         $(document).on('click', '#edit_shuttle_data', function() {
            var id = $(this).attr('data-idshuttle');
            // alert(id);
            $.ajax({
               url: '<?= base_url('HoteladminController/geteditshuttleData') ?>',
               type: "post",
               data: {
                  id: id
               },
               dataType: "json",
               success: function(data) {

                  console.log(data);
                  $('#front_ofs_service_id3').val(data.data.front_ofs_service_id);
                  $('#staff_name3').val(data.data.staff_name);
                  $('#contact_no3').val(data.data.contact_no);

                  $('#comment3').summernote('code', data.data.description);
                  $('#comment4').summernote('code', data.data.t_nd_c);
                  $('#front_ofs_service_image').val(data.images.front_ofs_service_image_id);
                  
                  $("#img3").attr('src',data.images.image);

               }

            });
         })
      // });

      //  update business center data
      $(document).bind('submit').on('submit', '#editshuttleCenterForm', function(e) {
         //   alert('hi');die;
         e.preventDefault();
         $(".loader_block").show();
         var form_data = new FormData(this);
         $.ajax({
            url: '<?= base_url('HoteladminController/edit_front_ofs_services') ?>',
            method: 'POST',
            data: form_data,
            processData: false,
            contentType: false,
            cache: false,
            success: function(res) {

               // $.get( '<?= base_url('HoteladminController/ajaxbusinessIconView_v1'); ?>', function( data ) {
               //         var resu = $(data).find('#business_new_div').html();
               //         $('#business_new_div').html(resu);


               //         setTimeout(function(){
               //          $('#example1').DataTable();

               //         },2000);
               //     });

               setTimeout(function() {
                  $(".loader_block").hide();
                  $(".edit_shuttle_model").modal('hide');
                  $(".shuttle_new_data").html(res);
                  $(".updatemessage").show();
               }, 2000);
               setTimeout(function() {
                  $(".updatemessage").hide();
               }, 4000);



            }
         });
      });
   </script>
<?php } elseif ($sub_icon_id == 5) { ?>
   <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
         <div class="col-md-12">
            <div class="card card-topline-aqua">
               <div class="card-head">
                  <header>Baby Care Information</header>
               </div>
               <div class="card-body ">
                  <div class="table-scrollable">
                     <table id="example1" class="display full-width">
                        <thead>
                           <tr>
                              <th><strong>Sr. No.</strong></th>
                              <th><strong>Staff Name</strong></th>
                              <th><strong>Contact No.</strong></th>
                              <th><strong>Open Time </strong></th>
                              <th><strong>Break Time</strong></th>
                              <th><strong>Description</strong></th>
                              <th><strong>Terms & Condition</strong></th>
                              <th><strong>Pictures</strong></th>
                              <th><strong>Action</strong></th>
                           </tr>
                        </thead>
                        <tbody id="searchTable" class="baby_new_data">
                           <?php
                           $i = 1;
                           if ($list) {
                              foreach ($list as $baby_f_s) {
                                 $wh = '(front_ofs_service_id = "' . $baby_f_s['front_ofs_service_id'] . '")';

                                 $services_img = $this->HotelAdminModel->getData('front_ofs_services_images', $wh);
                           ?>
                                 <tr>
                                    <td><?php echo $i++ ?></td>
                                    <td><?php echo $baby_f_s['staff_name'] ?></td>
                                    <td><?php echo $baby_f_s['contact_no'] ?></td>
                                    <td><?php echo date('h:i a', strtotime($baby_f_s['open_time'])) . "-" . date('h:i a', strtotime($baby_f_s['close_time'])) ?></td>
                                    <td><?php echo date('h:i a', strtotime($baby_f_s['break_start_time'])) . "-" . date('h:i a', strtotime($baby_f_s['break_close_time'])) ?></td>
                                    <!-- <td>
                        <button class="btn btn-secondary_<?php echo $baby_f_s['front_ofs_service_id'] ?> shadow btn-xs sharp me-1"><i
                            class="fas fa-eye"></i></button>
                        </td>
                        <td>
                        <a href="" data-bs-toggle="modal"
                            data-bs-target="#exampleModalCenter_<?php echo $baby_f_s['front_ofs_service_id'] ?>">
                            <img src="assets/dist/images/term.jpg" alt=""
                                height="40px" width="60px">
                        </a>
                        </td> -->
                        <td>
                              

                              <a href="#" class="btn btn-secondary btn-xs edit_model_click_baby"   data-unic-id7="<?php echo $baby_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                           </td>
                              <td>
                              <a href="#" class="btn btn-secondary btn-xs edit_model_click_baby_term"   data-unic-id8="<?php echo $baby_f_s['front_ofs_service_id']?>"><i class="fa fa-eye"></i></a>
                              </td>
                                    <!-- modal for terms and conditions -->
                                    <td>
                                       <div class="lightgallery" class="room-list-bx d-flex align-items-center">
                                          <a href="<?php echo $services_img['image'] ?>" target="_blank" data-exthumbimage="<?php echo $services_img['image'] ?>" data-src="<?php echo $services_img['image'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                             <img class="me-3 " src="<?php echo $services_img['image'] ?>" alt="" style="width:50px; height:40px;">
                                          </a>
                                       </div>
                                    </td>
                                    <td>
                                       <div class="">
                                          <a href="#" class="btn btn-warning shadow btn-xs sharp me-1" id="edit_baby_data" data-bs-toggle="modal" data-idbaby="<?= $baby_f_s['front_ofs_service_id'] ?>" data-bs-target=".edit_baby_model"><i class="fa fa-pencil"></i></a>
                                          <!--<a href="#" onclick="delete_data(<?php echo $baby_f_s['front_ofs_service_id'] ?>)"
                              class="btn btn-danger shadow btn-xs sharp delete"><i
                                  class="fa fa-trash"></i></a>-->
                                       </div>
                                    </td>
                                 </tr>
                             
                           <?php
                              }
                           }

                           ?>
                        </tbody>
                     </table>
                  </div>

               </div>
            </div>
         </div>

         <div class="modal fade edit_baby_model" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-lg">
               <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title">Edit schedule</h5>
                     <button type="button" class="btn-close" data-bs-dismiss="modal">
                     </button>
                  </div>
                  <form id="editbabyCenterForm" method="post" enctype="multipart/form-data">
                     <div class="modal-body">
                        <div class="col-lg-12">
                           <div class="basic-form">
                              <input type="hidden" name="front_ofs_service_id" id="front_ofs_service_id4">
                              <input type="hidden" class="form-control" value="5" name="service_name">
                              <div class="row">
                                 <div class="mb-3 col-md-6 form-group">
                                    <label class="form-label">Staff Name</label>
                                    <input type="text" name="staff_name" id="staff_name4" class="form-control"  required="">
                                 </div>
                                 <div class="mb-3 col-md-6 form-group">
                                    <label class="form-label">Contact Number</label>
                                    <input type="text" name="contact_no" maxlength="10" id="contact_no4" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" required="">
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="mb-3 col-md-6 form-group">
                                    <label class="form-label">Open Time</label>
                                    <div class="input-group">
                                       <input type="time" name="open_time" id="open_time4" class="form-control">
                                       <input type="time" name="close_time" id="close_time4" class="form-control">
                                    </div>
                                 </div>
                                 <div class="mb-3 col-md-6 form-group">
                                    <label class="form-label">Break Time</label>
                                    <div class="input-group">
                                       <input type="time" name="break_start_time" id="break_start_time4" class="form-control">
                                       <input type="time" name="break_close_time" id="break_close_time4" class="form-control">
                                    </div>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="mb-3 col-md-6 form-group">
                                    <label class="form-label">Description</label>
                                    <textarea class="summernote" name="description" rows="3" id="comment5" required=""></textarea>
                                 </div>
                                 <div class="mb-3 col-md-6 form-group">
                                    <label class="form-label">Terms & Conditions</label>
                                    <textarea class="summernote" name="t_nd_c" rows="3" id="comment6" required=""></textarea>
                                 </div>
                              </div>
                              <?php
                              $wh1 = '(front_ofs_service_id = "' . $baby_f_s['front_ofs_service_id'] . '")';

                              $services_imgs = $this->MainModel->getAllData('front_ofs_services_images', $wh1);

                              // $j = 0;

                              if ($services_imgs) {

                              ?>
                                 <div class="mb-3 col-md-6 form-group">
                                    <label class="form-label">Pictures</label>
                                    <?php
                                    // foreach ($services_imgs as $se_i) {
                                    ?>
                                         <input type="hidden" name="front_ofs_service_img_id" id="front_ofs_service_image4">
                                          <input type="file" name="baby_img" class="form-control" placeholder="">
                                          <img src="" id="img5" alt="Not Found" height="50" width="50">
                                          <br>
                                          <output id="Filelist"></output>
                                       
                                    <?php
                                    //    $j++;
                                    // }
                                    ?>
                                 </div>
                              <?php
                              }
                              ?>
                              <div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-info" data-bs-dismiss="modal">Save changes</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>

         <div class="modal fade" id="baby_names_view_model" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Description</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model_baby">
       
        </div>
    </div>
    </div>
  </div>
</div>

<div class="modal fade" id="baby_names_view_model_term" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Terms And Conditions</b></h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="basic-form get_data_model_baby_term">
       
        </div>
    </div>
    </div>
  </div>
</div>

         <script>


$(document).on('click','.edit_model_click_baby', function () {
   
   var id = $(this).attr('data-unic-id7');
     
   $('#baby_names_view_model').modal('show');
  
   // $('#set_id_in_model').val($(this).attr('data-unic-id'));
   var base_url = '<?php echo base_url();?>';
   $.ajax({
       // method: "POST",
       // url: base_url+"HoteladminController/get_view_name_data_notification",
       url: '<?= base_url('HoteladminController/get_discri_name_data_baby') ?>',
       type: "post",
       data: {id : id},
       // dataType: "dataType",
       success: function (response) {
       console.log(response);
       $('.get_data_model_baby').html(response);
       }
   });
});

$(document).on('click','.edit_model_click_baby_term', function () {
   
   var id = $(this).attr('data-unic-id8');
     
   $('#baby_names_view_model_term').modal('show');
  
   // $('#set_id_in_model').val($(this).attr('data-unic-id'));
   var base_url = '<?php echo base_url();?>';
   $.ajax({
       // method: "POST",
       // url: base_url+"HoteladminController/get_view_name_data_notification",
       url: '<?= base_url('HoteladminController/get_terms_name_data_baby') ?>',
       type: "post",
       data: {id : id},
       // dataType: "dataType",
       success: function (response) {
       console.log(response);
       $('.get_data_model_baby_term').html(response);
       }
   });
});
            // $(document).ready(function(id) {
               $(document).on('click', '#edit_baby_data', function() {
                  var id = $(this).attr('data-idbaby');
                  // alert(id);
                  $.ajax({
                     url: '<?= base_url('HoteladminController/geteditbabyData') ?>',
                     type: "post",
                     data: {
                        id: id
                     },
                     dataType: "json",
                     success: function(data) {

                        console.log(data);
                        $('#front_ofs_service_id4').val(data.data.front_ofs_service_id);
                        $('#staff_name4').val(data.data.staff_name);
                        $('#contact_no4').val(data.data.contact_no);
                        $('#open_time4').val(data.data.open_time);
                        $('#close_time4').val(data.data.close_time);
                        $('#break_start_time4').val(data.data.break_start_time);
                        $('#break_close_time4').val(data.data.break_close_time);
                        // $('#comment1').val(data.comment);
                        $('#comment5').summernote('code', data.data.description);
                        $('#comment6').summernote('code', data.data.t_nd_c);

                        $('#front_ofs_service_image4').val(data.images.front_ofs_service_image_id);
                  
                     $("#img5").attr('src',data.images.image);



                     }


                  });
               })
            // });

            //  update business center data
            $(document).bind('submit').on('submit', '#editbabyCenterForm', function(e) {
               //   alert('hi');die;
               e.preventDefault();
               $(".loader_block").show();
               var form_data = new FormData(this);
               $.ajax({
                  url: '<?= base_url('HoteladminController/edit_front_ofs_services') ?>',
                  method: 'POST',
                  data: form_data,
                  processData: false,
                  contentType: false,
                  cache: false,
                  success: function(res) {

                     // $.get( '<?= base_url('HoteladminController/ajaxbusinessIconView_v1'); ?>', function( data ) {
                     //         var resu = $(data).find('#business_new_div').html();
                     //         $('#business_new_div').html(resu);


                     //         setTimeout(function(){
                     //          $('#example1').DataTable();

                     //         },2000);
                     //     });

                     setTimeout(function() {
                        $(".loader_block").hide();
                        $(".edit_baby_model").modal('hide');
                        $(".baby_new_data").html(res);
                        $(".updatemessage").show();
                     }, 2000);
                     setTimeout(function() {
                        $(".updatemessage").hide();
                     }, 4000);



                  }
               });
            });
         </script>
      <?php } elseif ($sub_icon_id == 6) { ?>
         <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
         <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
         <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
         <div class="col-md-12">
            <div class="card card-topline-aqua">
               <div class="card-head">
                  <header><span class="page_header_title">Car Wash Request</span></header>
               </div>
               <div class="card-body ">
                  <div class="col-md-12 col-sm-12">
                     <div class="panel tab-border card-box">
                        <header class="panel-heading panel-heading-gray custom-tab">
                           <ul class="nav nav-tabs">
                              <li class="nav-item"><a href="#new_orders_div" data-bs-toggle="tab" class="active">Car Wash Request</a>
                              </li>
                              <li class="nav-item"><a href="#accepted_orders_div" data-bs-toggle="tab">Accepted Car Request</a>
                              </li>
                              <li class="nav-item"><a href="#completed_orders_div_new" data-bs-toggle="tab">Completed Car Request</a>
                              </li>
                              <li class="nav-item"><a href="#rejected_orders_div_new" data-bs-toggle="tab">Rejected Car Request</a>
                              </li>
                              <li class="nav-item"><a href="#rejected_orders_div" data-bs-toggle="tab">Washing Charges</a>
                              </li>
                           </ul>
                        </header>
                     </div>
                     <div class="btn-group r-btn add_car_wash">
                        <button style="float:right;" type="button" class="btn btn-primary css_btn added_car_wash" data-bs-toggle="modal">Add Request</button>
                     </div>
                  </div>
                  <div class="tab-content">
                     <div class="tab-pane active" style="background-color:white;" id="new_orders_div">
                        <br>
                        <div class="col-md-6">
                           <div class="input-group">
                              <input type="date" class="form-control" placeholder="2017-06-04">
                              <input type="time" class="form-control" placeholder="2017-06-04">
                              <input type="text" class="form-control" placeholder="Vehicle Name">
                              <button class="btn btn-warning  btn-sm "><i class="fa fa-search"></i></button>
                           </div>
                        </div>
                        <div class="table-scrollable car_change_record">
                           <table id="example1" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Sr. No.</strong></th>
                                    <th><strong>Guest Name</strong></th>
                                    <th><strong>Phone</strong></th>
                                    <!-- <th><strong>Email</strong></th> -->
                                    <th><strong>Select Date</strong></th>
                                    <th><strong>Select Time</strong></th>
                                    <th><strong>Vehicle Name</strong></th>
                                    <th><strong>Vehicle No.</strong></th>
                                    <th><strong>Photo</strong></th>
                                    <th><strong>Note</strong></th>
                                    <!-- <th><strong>Terms</strong></th> -->
                                    <th><strong>Assign</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable" class="append_data12">
                                 <?php
                                 $j = 1;
                                 if ($vehicle_wash_request) {
                                    foreach ($vehicle_wash_request as $v_w_r) {
                                       $wh = '(u_id = "' . $v_w_r['u_id'] . '")';

                                       $user_data = $this->HotelAdminModel->getData('register', $wh);

                                       if ($user_data) {
                                 ?>
                                          <tr>
                                             <td><strong><?php echo $j++ ?></strong></td>
                                             <td><?php echo $user_data['full_name'] ?></td>
                                             <td><?php echo $user_data['mobile_no'] ?></td>
                                             <!--<td><?php echo $v_w_r['date'] ?></td>-->
                                             <td><?php echo $v_w_r['select_date'] ?></td>
                                             <!-- <td>23/12/2022</td> -->
                                             <td><?php echo date('h:i a', strtotime($v_w_r['select_time'])) ?></td>
                                             <!-- <td>07:50 PM</td> -->
                                             <td><?php echo $v_w_r['vehicle_name'] ?></td>
                                             <td><?php echo $v_w_r['vehicle_no'] ?></td>
                                             <td>
                                                <div id="lightgallery" class="room-list-bx  align-items-center">
                                                   <a href="<?php echo $v_w_r['vehicle_img'] ?>" data-exthumbimage="<?php echo $v_w_r['vehicle_img'] ?>" data-src="<?php echo $v_w_r['vehicle_img'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                                      <img class="me-3 " src="<?php echo $v_w_r['vehicle_img'] ?>" alt="" style="width:50px;">
                                                   </a>
                                                </div>
                                             </td>
                                             <!-- <td>
                              <button class="btn btn-secondary_<?php echo $v_w_r['vehicle_wash_request_id'] ?> shadow btn-xs sharp"
                                  data-toggle="popover"><i
                                      class="fa fa-eye"></i></button>
                              
                              </td> -->
                                             <td>
                                                <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $v_w_r['vehicle_wash_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                             </td>

                                             <td>
                                                <div>
                                                   <a href="#" class="btn btn-warning shadow btn-xs sharp update_car_modal_btn" id="edit_car_data" data-id2="<?= $v_w_r['vehicle_wash_request_id'] ?>"><i class="fa fa-share"></i></a>
                                                </div>

                                             </td>

                                          </tr>
                                          <div class="modal fade bd-terms-modal-sm_<?php echo $v_w_r['vehicle_wash_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                             <div class="modal-dialog modal-md">
                                                <div class="modal-content">
                                                   <div class="modal-header">
                                                      <h5 class="modal-title">Description</h5>
                                                      <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                      </button>
                                                   </div>
                                                   <div class="modal-body">
                                                      <div class="col-lg-12">
                                                         <span><?php echo $v_w_r['note'] ?></span>
                                                      </div>
                                                   </div>
                                                   <div class="modal-footer">
                                                      <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                 <?php
                                       }
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="accepted_orders_div" style="background-color:white;">
                        <div class="table-scrollable car_change_record1">
                           <table id="acceptedOrder_tb" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Sr. No.</strong></th>
                                    <th><strong>Guest Name</strong></th>
                                    <th><strong>Phone</strong></th>
                                    <!-- <th><strong>Email</strong></th> -->
                                    <th><strong>Request Date</strong></th>
                                    <th><strong>Request Time</strong></th>
                                    <th><strong>Vehicle Type</strong></th>
                                    <th><strong>Vehicle No.</strong></th>
                                    <th><strong>Photo</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 $j = 1;

                                 if ($vehicle_wash_request1) {
                                    foreach ($vehicle_wash_request1 as $v_w_r) {
                                       $wh = '(u_id = "' . $v_w_r['u_id'] . '")';

                                       $user_data = $this->MainModel->getData('register', $wh);

                                       if ($user_data) {
                                 ?>
                                          <tr>
                                             <td><strong><?php echo $j++ ?></strong></td>
                                             <td><?php echo $user_data['full_name'] ?></td>
                                             <td><?php echo $user_data['mobile_no'] ?></td>
                                             <td><?php echo $v_w_r['select_date'] ?></td>
                                             <td><?php echo date('h:i a', strtotime($v_w_r['select_time'])) ?></td>
                                             <td><?php echo $v_w_r['vehicle_name'] ?></td>
                                             <td><?php echo $v_w_r['vehicle_no'] ?></td>
                                             <td>
                                                <div id="lightgallery" class="room-list-bx  align-items-center">
                                                   <a href="<?php echo $v_w_r['vehicle_img'] ?>" data-exthumbimage="<?php echo $v_w_r['vehicle_img'] ?>" data-src="<?php echo $v_w_r['vehicle_img'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                                      <img class="me-3 " src="<?php echo $v_w_r['vehicle_img'] ?>" alt="" style="width:50px;">
                                                   </a>
                                                </div>
                                             </td>
                                             <input type="hidden" name="user_id" id="uid<?php echo $v_w_r['vehicle_wash_request_id']; ?>" value="<?php echo $v_w_r['vehicle_wash_request_id']; ?>">
                                             <td>
                                                <select class="form-control" name="status" id="carwashstatus<?php echo $v_w_r['vehicle_wash_request_id']; ?>" onchange="car_change_status(<?php echo $v_w_r['vehicle_wash_request_id'] ?>);" style="min-width:85px;text-align:center">
                                                   <?php
                                                   if ($v_w_r['request_status'] == "1") {
                                                   ?>
                                                      <option value="1" selected>Accepted</option>
                                                      <option value="4">Completed</option>
                                                   <?php
                                                   }
                                                   ?>
                                                </select>
                                             </td>
                                          </tr>
                                 <?php
                                       }
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="completed_orders_div_new" style="background-color:white;">
                        <div class="table-scrollable car_change_record2">
                           <table id="completedOrder_tb" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Sr. No.</strong></th>
                                    <th><strong>Guest Name</strong></th>
                                    <th><strong>Phone</strong></th>
                                    <!-- <th><strong>Email</strong></th> -->
                                    <th><strong>Request Date</strong></th>
                                    <th><strong>Request Time</strong></th>
                                    <th><strong>Vehicle Type</strong></th>
                                    <th><strong>Vehicle No.</strong></th>
                                    <th><strong>Photo</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 $j = 1;

                                 if ($vehicle_wash_request7) {
                                    foreach ($vehicle_wash_request7 as $v_w_c) {
                                       $wh = '(u_id = "' . $v_w_c['u_id'] . '")';

                                       $user_data = $this->MainModel->getData('register', $wh);

                                       if ($user_data) {
                                 ?>
                                          <tr>
                                             <td><strong><?php echo $j++ ?></strong></td>
                                             <td><?php echo $user_data['full_name'] ?></td>
                                             <td><?php echo $user_data['mobile_no'] ?></td>
                                             <td><?php echo $v_w_c['select_date'] ?></td>
                                             <td><?php echo date('h:i a', strtotime($v_w_c['select_time'])) ?></td>
                                             <td><?php echo $v_w_c['vehicle_name'] ?></td>
                                             <td><?php echo $v_w_c['vehicle_no'] ?></td>
                                             <td>
                                                <div id="lightgallery" class="room-list-bx  align-items-center">
                                                   <a href="<?php echo $v_w_c['vehicle_img'] ?>" data-exthumbimage="<?php echo $v_w_c['vehicle_img'] ?>" data-src="<?php echo $v_w_c['vehicle_img'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                                      <img class="me-3 " src="<?php echo $v_w_c['vehicle_img'] ?>" alt="" style="width:50px;">
                                                   </a>
                                                </div>
                                             </td>
                                             <td>
                                                <div class="d-flex">
                                                   <a href="#"><span class="badge badge-success" data-bs-toggle="modal" data-bs-target="">Completed</span>
                                                   </a>
                                                </div>
                                             </td>
                                          </tr>
                                 <?php
                                       }
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="rejected_orders_div_new" style="background-color:white;">
                        <div class="table-scrollable car_change_record3">
                           <table id="rejectedOrder_tb_new" class="display full-width">
                              <thead>
                                 <tr>
                                    <th><strong>Sr. No.</strong></th>
                                    <th><strong>Guest Name</strong></th>
                                    <th><strong>Phone</strong></th>
                                    <!-- <th><strong>Email</strong></th> -->
                                    <th><strong>Request Date</strong></th>
                                    <th><strong>Request Time</strong></th>
                                    <th><strong>Vehicle Type</strong></th>
                                    <th><strong>Vehicle No.</strong></th>
                                    <th><strong>Photo</strong></th>
                                    <th><strong>Status</strong></th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 $j = 1;

                                 if ($vehicle_wash_request3) {
                                    foreach ($vehicle_wash_request3 as $v_w_r) {
                                       $wh = '(u_id = "' . $v_w_r['u_id'] . '")';

                                       $user_data = $this->MainModel->getData('register', $wh);

                                       if ($user_data) {
                                 ?>
                                          <tr>
                                             <td><strong><?php echo $j++ ?></strong></td>
                                             <td><?php echo $user_data['full_name'] ?></td>
                                             <td><?php echo $user_data['mobile_no'] ?></td>
                                             <td><?php echo $v_w_r['select_date'] ?></td>
                                             <td><?php echo date('h:i a', strtotime($v_w_r['select_time'])) ?></td>
                                             <td><?php echo $v_w_r['vehicle_name'] ?></td>
                                             <td><?php echo $v_w_r['vehicle_no'] ?></td>
                                             <td>
                                                <div id="lightgallery" class="room-list-bx  align-items-center">
                                                   <a href="<?php echo $v_w_r['vehicle_img'] ?>" data-exthumbimage="<?php echo $v_w_r['vehicle_img'] ?>" data-src="<?php echo $v_w_r['vehicle_img'] ?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
                                                      <img class="me-3 " src="<?php echo $v_w_r['vehicle_img'] ?>" alt="" style="width:50px;">
                                                   </a>
                                                </div>
                                             </td>
                                             <td>
                                                <div class="d-flex">
                                                   <a href="#"><span class="badge badge-danger" data-bs-toggle="modal" data-bs-target="">Rejected</span>
                                                   </a>
                                                </div>
                                             </td>
                                          </tr>
                                 <?php
                                       }
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <div class="tab-pane" id="rejected_orders_div" style="background-color:white;">
                        <div>
                           <button style="float:right" type="button" class="btn btn-primary css_btn" data-bs-toggle="modal" data-bs-target="#exampleModalCenter1">Add Washing
                              Charges</button>
                        </div>
                        <br><br>
                        <!-- add -->
                        <div class="modal fade" id="exampleModalCenter1" style="display: none;" aria-hidden="true">
                           <div class="modal-dialog modal-dialog-centered" role="document">
                              <div class="modal-content">
                                 <div class="modal-header">
                                    <h5 class="modal-title">Add Washing Charges</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                                    </button>
                                 </div>
                                 <form action="<?php echo base_url('HoteladminController/add_vehicle_washing_charges') ?>" method="post">
                                    <div class="modal-body">
                                       <div class="row">
                                          <div class="mb-3 col-md-12 form-group">
                                             <label class="form-label">Vehicle Type</label>
                                             <input type="text" name="vehicle_type" class="form-control" placeholder="Vehicle Type" required="">
                                          </div>
                                          <div class="mb-3 col-md-12 form-group">
                                             <label class="form-label">Charges</label>
                                             <input type="number" name="charges" class="form-control" placeholder="Charges" required="">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="modal-footer text-center">
                                       <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                       <button type="submit" class="btn btn-primary">Add</button>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <div class="table-scrollable">
                           <table id="rejectedOrder_tb" class="display full-width">
                              <thead>
                                 <tr>
                                    <th>Sr. No.</th>
                                    <th>Vehicle Type</th>
                                    <th>Charges</th>
                                    <th>Action</th>
                                 </tr>
                              </thead>
                              <tbody id="searchTable">
                                 <?php
                                 $i = 1;

                                 if ($vehicle_wash_request2) {
                                    foreach ($vehicle_wash_request2 as $v_wash_char) {

                                 ?>
                                       <tr>
                                          <td>
                                             <h5 class="text-nowrap"><?php echo $i++ ?></h5>
                                          </td>
                                          <td>
                                             <h5 class="text-nowrap"><?php echo $v_wash_char['vehicle_type'] ?></h5>
                                          </td>
                                          <td>
                                             <h5> <i class="fa fa-rupees"><?php echo $v_wash_char['charges'] ?></i></h5>
                                          </td>
                                          <td>
                                             <div>
                                                <a href="#" class="btn btn-warning shadow btn-xs sharp me-1" data-bs-toggle="modal" data-bs-target="#exampleModalCenter2_<?php echo $v_wash_char['vehicle_washing_charge_id'] ?>"><i class="fa fa-pencil"></i></a>
                                                <a href="#" onclick="delete_data_car(<?php echo $v_wash_char['vehicle_washing_charge_id'] ?>)" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                             </div>
                                             <!-- edit -->
                                             <div class="modal fade" id="exampleModalCenter2_<?php echo $v_wash_char['vehicle_washing_charge_id'] ?>" style="display: none;" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                   <div class="modal-content">
                                                      <div class="modal-header">
                                                         <h5 class="modal-title">Update Washing Charges</h5>
                                                         <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                         </button>
                                                      </div>
                                                      <form action="<?php echo base_url('HoteladminController/edit_vehicle_washing_charges') ?>" method="post">
                                                         <input type="hidden" name="vehicle_washing_charge_id" value="<?php echo $v_wash_char['vehicle_washing_charge_id'] ?>">
                                                         <div class="modal-body">
                                                            <div class="row">
                                                               <div class="mb-3 col-md-12 form-group">
                                                                  <label class="form-label">Vehicle Type</label>
                                                                  <input type="text" class="form-control" name="vehicle_type" value="<?php echo $v_wash_char['vehicle_type'] ?>">
                                                               </div>
                                                               <div class="mb-3 col-md-12 form-group">
                                                                  <label class="form-label">Charges</label>
                                                                  <input type="number" class="form-control" name="charges" value="<?php echo $v_wash_char['charges'] ?>">
                                                               </div>
                                                            </div>
                                                         </div>
                                                         <div class="modal-footer">
                                                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                                         </div>
                                                      </form>
                                                   </div>
                                                </div>
                                             </div>
                                             <!-- /. edit -->
                                          </td>
                                       </tr>
                                 <?php
                                    }
                                 }
                                 ?>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- add btn modal  -->
         <div class="modal fade bd-add-modal add_facility_modal_car" tabindex="-1" style="display: none;" aria-hidden="true">
            <div class="modal-dialog modal-lg">
               <div class="modal-content">
                  <form id="car_wash_request" method="post" enctype="multipart/form-data">
                     <div class="modal-header">
                        <h5 class="modal-title" style="font-weight: bold;font-size: 15px !important;">Add Car Wash Request</h5>
                        <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
                        </button>
                     </div>
                     <div class="modal-body">
                        <div class="row">
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Contact Number</label>
                              <input type="text" maxlength="10" name="mobile_no" id="mobile_no" onkeyup="add_booking_id()" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" placeholder="Contact Number" required="">
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Booking ID</label>
                              <input type="number" name="booking_id" class="form-control" id="booking_id" placeholder="Booking ID" required="" disable>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Request Date</label>
                              <input type="date" class="form-control minDate" name="request_date" placeholder="Date" required>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Request Time</label>
                              <input type="time" class="form-control minDate" name="request_time" placeholder="time" required>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Vehicle Name</label>
                              <input type="text" class="form-control minDate" name="vehicle_name" placeholder="Vehicle Name" required>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Vehicle No.</label>
                              <input type="text" class="form-control minDate" name="vehicle_no" placeholder="Vehicle No" required>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Vehicle Type</label>
                              <select id="vehicle_washing_charge_id" name="vehicle_washing_charge_id" class="default-select form-control wide  dropdown js-example-disabled-results" required="">
                                 <option selected="">Select... </option>
                                 <?php
                                 $u_id = $this->session->userdata('u_id');
                                 $where = '(u_id = "' . $u_id . '")';
                                 $admin_details = $this->HotelAdminModel->getData($tbl = 'register', $where);
                                 $admin_id = $admin_details['u_id'];
                                 // print_r($admin_id);die;

                                 $vehicle_washing_charges = $this->HotelAdminModel->get_hotel_vehicle_wash_charges($admin_id);

                                 foreach ($vehicle_washing_charges as $s_im) {
                                 ?>
                                    <option value="<?php echo $s_im['vehicle_washing_charge_id'] ?>"><?php echo $s_im['vehicle_type'] ?></option>
                                 <?php
                                 }
                                 ?>
                              </select>
                           </div>
                           <div class="mb-3 col-md-6 form-group">
                              <label class="form-label">Upload image</label>
                              <input type="file" name="image" accept="image/jpeg, image/png," class="form-control" required="">
                           </div>
                           <div class="mb-3 col-md-12 form-group">
                              <label class="form-label">Note</label>
                              <!-- <div class="summernote"></div> -->
                              <textarea class="summernote" id="description1" name="additional_note" style="min-height: 400px;"></textarea>
                           </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                        <button type="submit" class="btn btn-primary css_btn">Add
                        </button>
                     </div>
                  </form>
               </div>
            </div>
         </div>

         <!-- end add btn modal -->
         <div class="modal fade update_car_modal_change" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-md">
               <div class="modal-content">
                  <div class="modal-header">
                     <h5 class="modal-title">Edit Order status</h5>
                     <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
                  </div>
                  <form id="frmupdateblock_car" method="post" enctype="multipart/form-data">
                     <div class="modal-body">
                        <div class="basic-form">
                           <div class="row">
                              <div class="mb-3 col-md-12">
                                 <input type="hidden" name="vehicle_wash_request_id" id="vehicle_wash_request_id1">

                                 <label class="form-label">Change Order Status</label>
                                 <select id="send_user1" name="request_status" class="default-select form-control wide" required>
                                    <option value="">Choose...</option>
                                    <option value="1">Accept</option>
                                    <option value="2">Reject</option>
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="modal-footer">
                        <button type="submit" class="btn btn-primary css_btn">Save</button>
                        <button type="button" class="btn btn-light css_btn" data-dismiss="modal">Close</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
         <!-- add btn modal  -->
         <script>
            function car_change_status(cnt) {
               //alert('hi');
               $(".loader_block").show();
               var base_url = '<?php echo base_url(); ?>';
               var status = $('#carwashstatus' + cnt).children("option:selected").val();
               var uid = $('#uid' + cnt).val();
               //  alert(uid);

               if (status != '') {

                  $.ajax({
                     url: base_url + "HoteladminController/carwash_status",
                     method: "POST",
                     data: {
                        status: status,
                        uid: uid
                     },
                     dataType: "json",
                     success: function(data) {
                        $.get('<?= base_url('HoteladminController/ajaxcarIconView_v1'); ?>', function(data) {
                           var resu = $(data).find('#example1').html();
                           var resu1 = $(data).find('.car_change_record1').html();
                           var resu2 = $(data).find('.car_change_record2').html();
                           var resu3 = $(data).find('.car_change_record3').html();
                           $('#example1').html(resu);
                           $('.car_change_record1').html(resu1);
                           $('.car_change_record2').html(resu2);
                           $('.car_change_record3').html(resu3);

                           setTimeout(function() {
                              $(".loader_block").hide();
                              $('.page_header_title_spa').text('Complete Car Request');
                              $('#example1').DataTable();
                              $('#acceptedOrder_tb').DataTable();
                              $('#completedOrder_tb').DataTable();
                              $('#rejectedOrder_tb_new').DataTable();
                              $(".status_completed2").show();
                              $('a[href="#completed_orders_div_new"]').tab('show');

                              setTimeout(function() {
                                 $(".status_completed2").hide();
                              }, 4000);
                           }, 2000);
                        });
                        //alert(data);

                     }
                  });
               }
            }
         </script>
         <script>
            $(document).ready(function() {
               $('#example1').DataTable();
               $('#acceptedOrder_tb').DataTable();
               $('#completedOrder_tb').DataTable();
               //   $('#completedOrder_tb').DataTable();
               $('#rejectedOrder_tb_new').DataTable();

               $(document).on("click", ".added_car_wash", function() {
                  $(".add_facility_modal_car").modal('show');
               });
               $(document).unbind('submit').on('submit', '#car_wash_request', function(e) {
                  e.preventDefault();
                  $(".loader_block").show();
                  var form_data = new FormData(this);
                  //  var data_id = $(this).attr('data-id');
                  $.ajax({
                     url: '<?= base_url('HoteladminController/add_carwash_request') ?>',
                     method: 'POST',
                     data: form_data,
                     processData: false,
                     contentType: false,
                     cache: false,
                     success: function(res) {

                        $.get('<?= base_url('HoteladminController/ajaxcarIconView_v1'); ?>', function(data) {
                           var resu = $(data).find('.car_change_record').html();
                           $('.car_change_record').html(resu);
                           setTimeout(function() {
                              $('#example1').DataTable();
                           }, 2000);
                        });

                        setTimeout(function() {
                           $(".loader_block").hide();
                           $(".add_facility_modal_car").modal('hide');
                           $(".add_facility_modal_car").on("hidden.bs.modal", function() {
                     $("#car_wash_request")[0].reset(); // reset the form fields
                     $('#description1').summernote('reset');
                  });
                           $(".append_data12").html(res);
                           $(".successmessage12").show();
                        }, 2000);
                        setTimeout(function() {
                           $(".successmessage12").hide();
                        }, 4000);

                     }
                  });
               });

            });
         </script>
         <script>
            $(document).on('click', '#edit_car_data', function() {
               var id = $(this).attr('data-id2');
               // alert(id);
               $.ajax({
                  url: '<?= base_url('HoteladminController/getrequirement_car') ?>',
                  //url: 'https://aartoon.com/control_panel/MainController/delete_home_slider/13',
                  type: "post",
                  data: {
                     id: id
                  },
                  dataType: "json",
                  success: function(data) {
                     console.log(data);
                     $('#vehicle_wash_request_id1').val(data.vehicle_wash_request[0].vehicle_wash_request_id);

                  }
               });
            })
         </script>
         <script>
            $('#send_user1').on('change', function() {

               if (this.value == 1) {
                  //   $('#user_list').
                  //   $('.assignto').css('display','block');
                  //   $('.rejectreasonddd').css('display','none');
                  //   $('.demo').prop('required', true);

                  //   $('#reason').prop('required', false);
                  //   $('#status').prop('required', true);

                  //   $('.assignto').css('display','block');

               } else if (this.value == 2) {
                  //   $('.assignto').css('display','none');
                  //   $('.rejectreasonddd').css('display','block');
                  //   $('#reason').prop('required', true);
                  //   $('#status').prop('required', false);
                  // $('.demo').prop('required', true);

               }
            });
         </script>

         <script>
            $(document).on("click", ".update_car_modal_btn", function() {
               $(".update_car_modal_change").modal('show');
            });

            $('#frmupdateblock_car').submit(function(e) {
               e.preventDefault();
               $(".loader_block").show();
               var form_data = new FormData(this);
               var base_url = '<?php echo base_url() ?>';
               //   console.log(base_url);
               //   return false;
               $.ajax({
                  url: base_url + "HoteladminController/change_new_car_status",
                  type: 'POST',
                  data: form_data,
                  processData: false,
                  contentType: false,
                  cache: false,
                  success: function(res) {
                     console.log(res)
                     $.get('<?= base_url('HoteladminController/ajaxSubIconBlockView1'); ?>', function(data) {
                        var resu = $(data).find('#new_orders_div').html();
                        var resu1 = $(data).find('#accepted_orders_div').html();
                        var resu2 = $(data).find('#completed_orders_div_new').html();
                        var resu3 = $(data).find('#rejected_orders_div_new').html();


                        $('#new_orders_div').html(resu);
                        $('#accepted_orders_div').html(resu1);
                        $('#completed_orders_div_new').html(resu2);
                        $('#rejected_orders_div_new').html(resu3);

                        setTimeout(function() {
                           $('#example1').DataTable();
                           $('#acceptedOrder_tb').DataTable();
                           $('#completedOrder_tb').DataTable();
                           $('#rejectedOrder_tb_new').DataTable();
                        }, 2000);
                     });
                     setTimeout(function() {
                        $(".loader_block").hide();
                        $(".update_car_modal_change").modal('hide');
                        $(".update_car_modal_change").on("hidden.bs.modal", function() {
                           $("#frmupdateblock_car")[0].reset(); // reset the form fields
                        });
                        $(".updatemessage").show();
                        $(".append_data12").html(res);

                        var request_status = form_data.get('request_status');
                        //  console.log(requestStatus); // Log the requestStatus value to the console

                        if (request_status === "1") {
                           $('a[href="#accepted_orders_div"]').tab('show');
                           $('.page_header_title_spa').text('Accept Car Request');
                        } else if (request_status === "2") {
                           $('a[href="#rejected_orders_div_new"]').tab('show');
                           $('.page_header_title_spa').text('Reject Car Request');

                        }

                     }, 2000);
                     setTimeout(function() {
                        $(".updatemessage").hide();
                     }, 4000);
                  }

               });
            });
         </script>
      <?php } elseif ($sub_icon_id == 7) { ?>
         <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
         <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
         <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
         <!-- <div class="col-md-12"> -->
         <div class="card card-topline-aqua">
            <div class="card-head">
               <header><span class="page_header_title1">Luggage Request</span></header>
            </div>
            <div class="card-body">
               <div class="col-md-12 col-sm-12">
                  <div class="panel tab-border card-box">
                     <header class="panel-heading panel-heading-gray custom-tab">
                        <ul class="nav nav-tabs">
                           <li class="nav-item"><a href="#new_orders_div1" data-bs-toggle="tab" class="active">Luggage Request</a>
                           </li>
                           <li class="nav-item"><a href="#accepted_orders_div1" data-bs-toggle="tab">Accepted Request</a>
                           </li>
                           <li class="nav-item"><a href="#completed_orders_div1_new" data-bs-toggle="tab">Luggage Return</a>
                           </li>
                           <li class="nav-item"><a href="#rejected_orders_div1_new" data-bs-toggle="tab">Rejected Request</a>
                           </li>
                        </ul>
                     </header>
                  </div>
               </div>
               <div class="btn-group r-btn add_luggage_item">
                  <button style="float:right;" type="button" class="btn btn-primary css_btn add_luggage" data-bs-toggle="modal">Add Request</button>
               </div>
               <div class="tab-content">
                  <div class="tab-pane active" style="background-color:white;" id="new_orders_div1">
                     <div class="col-md-6">
                        <div class="input-group">
                           <input type="date" class="form-control" placeholder="2017-06-04">
                           <input type="time" class="form-control" placeholder="2017-06-04">
                           <input type="text" class="form-control" placeholder="Luggage Type">
                           <button class="btn btn-warning  btn-sm "><i class="fa fa-search"></i></button>
                        </div>
                     </div>
                     <div class="table-scrollable luggage_change_record">
                        <table id="example1" class="display full-width">
                           <thead>
                              <tr>
                                 <th><strong>Sr. No.</strong></th>
                                 <th><strong>Guest Name</strong></th>
                                 <th><strong>Mobile Number</strong></th>
                                 <th><strong>Date</strong></th>
                                 <th><strong>Time</strong></th>
                                 <th><strong>Type Of Luggage</strong></th>
                                 <!-- <th><strong>Luggage Photo</strong></th> -->
                                 <th><strong>Qty</strong></th>
                                 <th><strong>Note</strong></th>
                                 <th><strong>Action</strong></th>
                              </tr>
                           </thead>
                           <tbody id="searchTable" class="append_data13">
                              <?php
                              $j = 1;

                              if ($luggage_request) {
                                 foreach ($luggage_request as $lug_r) {
                                    $wh = '(u_id = "' . $lug_r['u_id'] . '")';

                                    $user_data = $this->HotelAdminModel->getData('register', $wh);

                                    if ($user_data) {


                              ?>
                                       <tr>
                                          <td><strong><?php echo $j++ ?></strong></td>
                                          <td><?php echo $user_data['full_name'] ?></td>
                                          <td><?php echo $user_data['mobile_no'] ?></td>
                                          <td><?php echo $lug_r['select_date'] ?></td>
                                          <td><?php echo date('h:i a', strtotime($lug_r['select_time'])) ?></td>
                                          <td><?php echo $lug_r['luggage_type'] ?></td>
                                          <td><?php echo $lug_r['quantity'] ?></td>
                                          <!-- <td>
                  <button
                      class="btn btn-secondary_<?php echo $lug_r['luggage_request_id'] ?> shadow btn-xs sharp me-1"><i
                          class="fas fa-eye"></i></button>
                  </td> -->
                                          <td>
                                             <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                          </td>
                                          <td>
                                             <div>
                                                <a href="#" class="btn btn-warning shadow btn-xs sharp me-1 update_luggage_modal_btn" id="edit_luggage_data" data-id3="<?= $lug_r['luggage_request_id'] ?>"><i class="fa fa-share"></i></a>
                                             </div>

                                          </td>
                                       </tr>
                                       <div class="modal fade bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                          <div class="modal-dialog modal-md">
                                             <div class="modal-content">
                                                <div class="modal-header">
                                                   <h5 class="modal-title">Description</h5>
                                                   <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                   </button>
                                                </div>
                                                <div class="modal-body">
                                                   <div class="col-lg-12">
                                                      <span><?php echo $lug_r['note'] ?></span>
                                                   </div>
                                                </div>
                                                <div class="modal-footer">
                                                   <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                              <?php
                                    }
                                 }
                              }
                              ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div class="tab-pane" id="accepted_orders_div1" style="background-color:white;">
                     <div class="table-scrollable luggage_change_record1">
                        <table id="acceptedOrder_tb1" class="display full-width">
                           <thead>
                              <tr>
                                 <th><strong>Sr. No.</strong></th>
                                 <th><strong>Guest Name</strong></th>
                                 <th><strong>Mobile Number</strong></th>
                                 <th><strong>Date</strong></th>
                                 <th><strong>Time</strong></th>
                                 <th><strong>Type Of Luggage</strong></th>
                                 <th><strong>Qty</strong></th>
                                 <th><strong>Note</strong></th>
                                 <th><strong>Status</strong></th>
                              </tr>
                           </thead>
                           <tbody id="searchTable">
                              <?php
                              $j = 1;

                              if ($luggage_request1) {
                                 foreach ($luggage_request1 as $lug_r) {
                                    $wh = '(u_id = "' . $lug_r['u_id'] . '")';

                                    $user_data = $this->MainModel->getData('register', $wh);

                                    if ($user_data) {
                              ?>
                                       <tr>
                                          <td><strong><?php echo $j++ ?></strong></td>
                                          <td><?php echo $user_data['full_name'] ?></td>
                                          <td><?php echo $user_data['mobile_no'] ?></td>
                                          <td><?php echo $lug_r['select_date'] ?></td>
                                          <td><?php echo date('h:i a', strtotime($lug_r['select_time'])) ?></td>
                                          <td><?php echo $lug_r['luggage_type'] ?></td>
                                          <td><?php echo $lug_r['quantity'] ?></td>
                                          <!-- <td>
                  <button
                      class="btn btn-secondary_<?php echo $lug_r['luggage_request_id'] ?> shadow btn-xs sharp me-1"><i
                          class="fas fa-eye"></i></button>
                  </td> -->
                                          <td>
                                             <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                          </td>
                                          <input type="hidden" name="user_id" id="uid<?php echo $lug_r['luggage_request_id']; ?>" value="<?php echo $lug_r['luggage_request_id']; ?>">
                                          <td>
                                             <select class="form-control" name="status" id="luggagestatus<?php echo $lug_r['luggage_request_id']; ?>" onchange="luggage_change_status(<?php echo $lug_r['luggage_request_id'] ?>);" style="min-width:85px;text-align:center">
                                                <?php
                                                if ($lug_r['request_status'] == "1") {
                                                ?>
                                                   <option value="1" selected>Accepted</option>
                                                   <option value="4">Completed</option>
                                                <?php
                                                }
                                                ?>
                                             </select>
                                          </td>
                                       </tr>
                                       <div class="modal fade bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                          <div class="modal-dialog modal-md">
                                             <div class="modal-content">
                                                <div class="modal-header">
                                                   <h5 class="modal-title">Description</h5>
                                                   <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                   </button>
                                                </div>
                                                <div class="modal-body">
                                                   <div class="col-lg-12">
                                                      <span><?php echo $lug_r['note'] ?></span>
                                                   </div>
                                                </div>
                                                <div class="modal-footer">
                                                   <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                              <?php
                                    }
                                 }
                              }
                              ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div class="tab-pane" id="completed_orders_div1_new" style="background-color:white;">
                     <div class="table-scrollable luggage_change_record2">
                        <table id="completedOrder_tb1" class="display full-width">
                           <thead>
                              <tr>
                                 <th><strong>Sr. No.</strong></th>
                                 <th><strong>Guest Name</strong></th>
                                 <th><strong>Mobile Number</strong></th>
                                 <th><strong>Date</strong></th>
                                 <th><strong>Time</strong></th>
                                 <th><strong>Type Of Luggage</strong></th>
                                 <th><strong>Qty</strong></th>
                                 <th><strong>Note</strong></th>
                                 <th><strong>Status</strong></th>
                              </tr>
                           </thead>
                           <tbody id="searchTable">
                              <?php
                              $j = 1;

                              if ($luggage_request4) {
                                 foreach ($luggage_request4 as $lug_c) {
                                    $wh = '(u_id = "' . $lug_c['u_id'] . '")';

                                    $user_data = $this->MainModel->getData('register', $wh);

                                    if ($user_data) {
                              ?>
                                       <tr>
                                          <td><strong><?php echo $j++ ?></strong></td>
                                          <td><?php echo $user_data['full_name'] ?></td>
                                          <td><?php echo $user_data['mobile_no'] ?></td>
                                          <td><?php echo $lug_c['select_date'] ?></td>
                                          <td><?php echo date('h:i a', strtotime($lug_c['select_time'])) ?></td>
                                          <td><?php echo $lug_c['luggage_type'] ?></td>
                                          <td><?php echo $lug_c['quantity'] ?></td>
                                          <!-- <td>
                  <button
                      class="btn btn-secondary_<?php echo $lug_r['luggage_request_id'] ?> shadow btn-xs sharp me-1"><i
                          class="fas fa-eye"></i></button>
                  </td> -->
                                          <td>
                                             <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $lug_c['luggage_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                          </td>
                                          <td>
                                             <a href="#">
                                                <div class="badge badge-primary" data-bs-toggle="modal" data-bs-target="">
                                                   Luggage Return
                                                </div>
                                             </a>
                                          </td>
                                       </tr>
                                       <div class="modal fade bd-terms-modal-sm_<?php echo $lug_c['luggage_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                          <div class="modal-dialog modal-md">
                                             <div class="modal-content">
                                                <div class="modal-header">
                                                   <h5 class="modal-title">Description</h5>
                                                   <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                   </button>
                                                </div>
                                                <div class="modal-body">
                                                   <div class="col-lg-12">
                                                      <span><?php echo $lug_c['note'] ?></span>
                                                   </div>
                                                </div>
                                                <div class="modal-footer">
                                                   <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                              <?php
                                    }
                                 }
                              }
                              ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div class="tab-pane" id="rejected_orders_div1_new" style="background-color:white;">
                     <div class="table-scrollable luggage_change_record3">
                        <table id="rejectedOrder_tb1_new" class="display full-width">
                           <thead>
                              <tr>
                                 <th><strong>Sr.No.</strong></th>
                                 <th><strong>Guest Name</strong></th>
                                 <th><strong>Mobile Number</strong></th>
                                 <th><strong>Date</strong></th>
                                 <th><strong>Time</strong></th>
                                 <th><strong>Type Of Luggage</strong></th>
                                 <th><strong>Qty</strong></th>
                                 <th><strong>Note</strong></th>
                                 <th><strong>Status</strong></th>
                              </tr>
                           </thead>
                           <tbody id="searchTable">
                              <?php
                              $j = 1;

                              if ($luggage_request3) {
                                 foreach ($luggage_request3 as $lug_r) {
                                    $wh = '(u_id = "' . $lug_r['u_id'] . '")';

                                    $user_data = $this->MainModel->getData('register', $wh);

                                    if ($user_data) {
                              ?>
                                       <tr>
                                          <td><strong><?php echo $j++ ?></strong></td>
                                          <td><?php echo $user_data['full_name'] ?></td>
                                          <td><?php echo $user_data['mobile_no'] ?></td>
                                          <td><?php echo $lug_r['select_date'] ?></td>
                                          <td><?php echo date('h:i a', strtotime($lug_r['select_time'])) ?></td>
                                          <td><?php echo $lug_r['luggage_type'] ?></td>
                                          <td><?php echo $lug_r['quantity'] ?></td>
                                          <!-- <td>
                  <button
                      class="btn btn-secondary_<?php echo $lug_r['luggage_request_id'] ?> shadow btn-xs sharp me-1"><i
                          class="fas fa-eye"></i></button>
                  </td> -->
                                          <td>
                                             <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                          </td>
                                          <td>
                                             <a href="#">
                                                <div class="badge badge-danger" data-bs-toggle="modal" data-bs-target="">
                                                   Rejected
                                                </div>
                                             </a>
                                          </td>
                                       </tr>
                                       <div class="modal fade bd-terms-modal-sm_<?php echo $lug_r['luggage_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                          <div class="modal-dialog modal-md">
                                             <div class="modal-content">
                                                <div class="modal-header">
                                                   <h5 class="modal-title">Description</h5>
                                                   <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                   </button>
                                                </div>
                                                <div class="modal-body">
                                                   <div class="col-lg-12">
                                                      <span><?php echo $lug_r['note'] ?></span>
                                                   </div>
                                                </div>
                                                <div class="modal-footer">
                                                   <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                              <?php
                                    }
                                 }
                              }
                              ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <!-- add btn modal  -->
                  <div class="modal fade bd-add-modal add_facility_modal_luggage" tabindex="-1" style="display: none;" aria-hidden="true">
                     <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                           <form id="luggage_request" method="post" enctype="multipart/form-data">
                              <div class="modal-header">
                                 <h5 class="modal-title" style="font-weight: bold;font-size: 15px !important;">Add Luggage Request</h5>
                                 <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
                              </div>
                              <div class="modal-body">
                                 <div class="row">
                                    <!-- <div class="mb-3 col-md-6 form-group">
                     <label class="form-label">Guest Name</label>
                     <input type="text" class="form-control"  name="name" id="name" placeholder="Enter agent name">
                     </div> -->
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Contact Number</label>
                                       <input type="text" maxlength="10" name="mobile_no" id="mobile_no" onkeyup="add_booking_id()" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" placeholder="Contact Number" required="">
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Booking ID</label>
                                       <input type="number" name="booking_id" class="form-control" id="booking_id" placeholder="Booking ID" required="" disable>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Request Date</label>
                                       <input type="date" class="form-control minDate" name="request_date" placeholder="Date" required>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Request Time</label>
                                       <input type="time" class="form-control minDate" name="request_time" placeholder="time" required>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Type Of Luggage</label>
                                       <input type="text" class="form-control minDate" name="luggage_type" placeholder="Luggage" required>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Qty</label>
                                       <input type="number" class="form-control minDate" name="quantity" placeholder="Qty" required>
                                    </div>
                                    <div class="mb-3 col-md-12 form-group">
                                       <label class="form-label">Note</label>
                                       <!-- <div class="summernote"></div> -->
                                       <textarea class="summernote" id="description1" name="additional_note" style="min-height: 400px;"></textarea>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="submit" class="btn btn-primary css_btn">Add
                                 </button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
                  <!-- end add btn modal -->
                  <!-- end add btn modal -->
                  <div class="modal fade update_luggage_modal_change" tabindex="-1" role="dialog" aria-hidden="true">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-header">
                              <h5 class="modal-title">Edit Order status</h5>
                              <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
                           </div>
                           <form id="frmupdateblock_luggage" method="post" enctype="multipart/form-data">
                              <div class="modal-body">
                                 <div class="basic-form">
                                    <div class="row">
                                       <div class="mb-3 col-md-12">
                                          <input type="hidden" name="luggage_request_id" id="luggage_request_id1">

                                          <label class="form-label">Change Order Status</label>
                                          <select id="send_user3" name="request_status" class="default-select form-control wide" required>
                                             <option value="">Choose...</option>
                                             <option value="1">Accept</option>
                                             <option value="2">Reject</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="submit" class="btn btn-primary css_btn">Save</button>
                                 <button type="button" class="btn btn-light css_btn" data-dismiss="modal">Close</button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
                  <!-- add btn modal  -->
                  <script type="text/javascript">
                     function luggage_change_status(cnt) {
                        //alert('hi');
                        $(".loader_block").show();
                        var base_url = '<?php echo base_url(); ?>';
                        var status = $('#luggagestatus' + cnt).children("option:selected").val();
                        var uid = $('#uid' + cnt).val();
                        //  alert(uid);

                        if (status != '') {

                           $.ajax({
                              url: base_url + "HoteladminController/luggage_status",
                              method: "POST",
                              data: {
                                 status: status,
                                 uid: uid
                              },
                              dataType: "json",
                              success: function(data) {
                                 $.get('<?= base_url('HoteladminController/ajaxluggageIconView_v1'); ?>', function(data) {
                                    var resu = $(data).find('#example1').html();
                                    var resu1 = $(data).find('.luggage_change_record1').html();
                                    var resu2 = $(data).find('.luggage_change_record2').html();
                                    var resu3 = $(data).find('.luggage_change_record3').html();
                                    $('#example1').html(resu);
                                    $('.luggage_change_record1').html(resu1);
                                    $('.luggage_change_record2').html(resu2);
                                    $('.luggage_change_record3').html(resu3);

                                    setTimeout(function() {
                                       $(".loader_block").hide();
                                       $('.page_header_title_spa').text('Complete Luggage Request');
                                       $(".status_completed3").show();

                                       $('#example1').DataTable();
                                       $('#acceptedOrder_tb1').DataTable();
                                       $('#completedOrder_tb1').DataTable();
                                       $('#rejectedOrder_tb1_new').DataTable();
                                       $('a[href="#completed_orders_div1_new"]').tab('show');

                                       setTimeout(function() {
                                          $(".status_completed3").hide();
                                       }, 4000);
                                    }, 2000);
                                 });
                                 //alert(data);

                              }
                           });
                        }
                     }
                  </script>
                  <script>
                     $(document).ready(function() {
                        $('#example1').DataTable();
                        $('#acceptedOrder_tb1').DataTable();
                        $('#completedOrder_tb1').DataTable();
                        $('#rejectedOrder_tb1_new').DataTable();

                        $(document).on("click", ".add_luggage", function() {
                           $(".add_facility_modal_luggage").modal('show');
                        });
                        $(document).unbind('submit').on('submit', '#luggage_request', function(e) {
                           e.preventDefault();
                           $(".loader_block").show();
                           var form_data = new FormData(this);
                           //  var data_id = $(this).attr('data-id');
                           $.ajax({
                              url: '<?= base_url('HoteladminController/add_luggage_request') ?>',
                              method: 'POST',
                              data: form_data,
                              processData: false,
                              contentType: false,
                              cache: false,
                              success: function(res) {

                                 $.get('<?= base_url('HoteladminController/ajaxluggageIconView_v1'); ?>', function(data) {
                                    var resu = $(data).find('.luggage_change_record').html();
                                    $('.luggage_change_record').html(resu);
                                    setTimeout(function() {
                                       $('#example1').DataTable();
                                    }, 2000);
                                 });

                                 setTimeout(function() {
                                    $(".loader_block").hide();
                                    $(".add_facility_modal_luggage").modal('hide');
                                    $(".add_facility_modal_luggage").on("hidden.bs.modal", function() {
                     $("#luggage_request")[0].reset(); // reset the form fields
                     $('#description1').summernote('reset');
                  });
                                    $(".append_data13").html(res);
                                    $(".successmessage13").show();
                                 }, 2000);
                                 setTimeout(function() {
                                    $(".successmessage13").hide();
                                 }, 4000);

                              }
                           });
                        });
                     });
                  </script>
                  <script>
                     $(document).on('click', '#edit_luggage_data', function() {
                        var id = $(this).attr('data-id3');
                        // alert(id);
                        $.ajax({
                           url: '<?= base_url('HoteladminController/getrequirement_luggage') ?>',
                           //url: 'https://aartoon.com/control_panel/MainController/delete_home_slider/13',
                           type: "post",
                           data: {
                              id: id
                           },
                           dataType: "json",
                           success: function(data) {
                              console.log(data);
                              $('#luggage_request_id1').val(data.luggage_request[0].luggage_request_id);

                           }
                        });
                     })
                  </script>
                  <script>
                     $('#send_user3').on('change', function() {

                        if (this.value == 1) {
                           //   $('#user_list').
                           //   $('.assignto').css('display','block');
                           //   $('.rejectreasonddd').css('display','none');
                           //   $('.demo').prop('required', true);

                           //   $('#reason').prop('required', false);
                           //   $('#status').prop('required', true);

                           //   $('.assignto').css('display','block');

                        } else if (this.value == 2) {
                           //   $('.assignto').css('display','none');
                           //   $('.rejectreasonddd').css('display','block');
                           //   $('#reason').prop('required', true);
                           //   $('#status').prop('required', false);
                           // $('.demo').prop('required', true);

                        }
                     });
                  </script>

                  <script>
                     $(document).on("click", ".update_luggage_modal_btn", function() {
                        $(".update_luggage_modal_change").modal('show');
                     });

                     $('#frmupdateblock_luggage').submit(function(e) {
                        e.preventDefault();
                        $(".loader_block").show();
                        var form_data = new FormData(this);
                        var base_url = '<?php echo base_url() ?>';
                        //   console.log(base_url);
                        //   return false;
                        $.ajax({
                           url: base_url + "HoteladminController/change_new_luggage_status",
                           type: 'POST',
                           data: form_data,
                           processData: false,
                           contentType: false,
                           cache: false,
                           success: function(res) {
                              console.log(res)
                              $.get('<?= base_url('HoteladminController/ajaxluggageIconView_v1'); ?>', function(data) {
                                 var resu = $(data).find('#new_orders_div1').html();
                                 var resu1 = $(data).find('#accepted_orders_div1').html();
                                 var resu2 = $(data).find('#completed_orders_div1_new').html();
                                 var resu3 = $(data).find('#rejected_orders_div1_new').html();


                                 $('#new_orders_div1').html(resu);
                                 $('#accepted_orders_div1').html(resu1);
                                 $('#completed_orders_div1_new').html(resu2);
                                 $('#rejected_orders_div1_new').html(resu3);

                                 setTimeout(function() {
                                    $('#example1').DataTable();
                                    $('#acceptedOrder_tb1').DataTable();
                                    $('#completedOrder_tb1').DataTable();
                                    $('#rejectedOrder_tb1_new').DataTable();
                                 }, 2000);
                              });
                              setTimeout(function() {
                                 $(".loader_block").hide();
                                 $(".update_luggage_modal_change").modal('hide');
                                 $(".update_luggage_modal_change").on("hidden.bs.modal", function() {
                                    $("#frmupdateblock_luggage")[0].reset(); // reset the form fields
                                 });
                                 $(".updatemessage").show();
                                 $(".append_data13").html(res);

                                 var request_status = form_data.get('request_status');
                                 //  console.log(requestStatus); // Log the requestStatus value to the console

                                 if (request_status === "1") {
                                    $('a[href="#accepted_orders_div1"]').tab('show');
                                    $('.page_header_title_spa').text('Accept Luggage Request');
                                 } else if (request_status === "2") {
                                    $('a[href="#rejected_orders_div1_new"]').tab('show');
                                    $('.page_header_title_spa').text('Reject Luggage Request');

                                 }

                              }, 2000);
                              setTimeout(function() {
                                 $(".updatemessage").hide();
                              }, 4000);
                           }

                        });
                     });
                  </script>

               <?php } elseif ($sub_icon_id == 8) { ?>
                  <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
                  <script src="<?php echo base_url('assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js') ?>"></script>
                  <script src="<?php echo base_url('assets/js/pages/table/table_data.js') ?>"></script>
                  <div class="col-md-12">
                     <div class="card card-topline-aqua">
                        <div class="card-head">
                           <header><span class="page_header_title2">Cab Service Request</span></header>
                        </div>
                        <div class="card-body">
                           <div class="col-md-12 col-sm-12">
                              <div class="panel tab-border card-box">
                                 <header class="panel-heading panel-heading-gray custom-tab">
                                    <ul class="nav nav-tabs">
                                       <li class="nav-item"><a href="#new_orders_div2" data-bs-toggle="tab" class="active">Cab Service Request</a>
                                       </li>
                                       <li class="nav-item"><a href="#accepted_orders_div2" data-bs-toggle="tab">Accepted Cab Request</a>
                                       </li>
                                       <li class="nav-item"><a href="#completed_orders_div2" data-bs-toggle="tab">Completed Cab Request</a>
                                       </li>
                                       <li class="nav-item"><a href="#rejected_orders_div2" data-bs-toggle="tab">Rejected Cab Request</a>
                                       </li>
                                    </ul>
                                 </header>
                              </div>
                           </div>
                           <div class="btn-group r-btn add_cab_feature">
                              <button style="float:right;" type="button" class="btn btn-primary css_btn add_cab" data-bs-toggle="modal">Add Request</button>
                           </div>
                           <div class="tab-content">
                              <div class="tab-pane active" style="background-color:white;" id="new_orders_div2">
                                 <br>
                                 <div class="col-md-6">
                                    <div class="input-group">
                                       <input type="date" class="form-control" placeholder="2017-06-04">
                                       <input type="time" class="form-control" placeholder="">
                                       <input type="text" class="form-control" placeholder="Vehicle Type">
                                       <button class="btn btn-warning  btn-sm "><i class="fa fa-search"></i></button>
                                    </div>
                                 </div>
                                 <div class="table-scrollable cab_change_record">
                                    <table id="example1" class="display full-width">
                                       <thead>
                                          <tr>
                                             <th><strong>Sr. No.</strong></th>
                                             <th><strong>Passengers</strong></th>
                                             <th><strong>Requested Date</strong></th>
                                             <th><strong>Guest Name</strong></th>
                                             <th><Strong>Phone</Strong></th>
                                             <th><strong>Vehicle Type</strong></th>
                                             <th><strong>Destination</strong></th>
                                             <th><strong>Note</strong></th>
                                             <th><strong>Assign</strong></th>
                                             <!-- <th><strong>Status</strong></th> -->
                                          </tr>
                                       </thead>
                                       <tbody id="searchTable append_data14">
                                          <?php
                                          $i = 1;
                                          if ($list) {
                                             foreach ($list as $c_s) {
                                                $user_data = $this->HotelAdminModel->get_user_data($c_s['u_id']);

                                                $full_name = "";
                                                $mobile_no = "";

                                                if ($user_data) {
                                                   $full_name = $user_data['full_name'];
                                                   $mobile_no = $user_data['mobile_no'];
                                                }
                                          ?>
                                                <tr>
                                                   <td><strong><?php echo $i++ ?></strong></td>
                                                   <td><?php echo $c_s['total_passanger'] ?></td>
                                                   <td>
                                                      <?php echo $c_s['request_date'] ?> /<sub> <?php echo date('h:i a', strtotime($c_s['request_time'])) ?></sub>
                                                   </td>
                                                   <td><?php echo $full_name ?></td>
                                                   <td><?php echo $mobile_no ?></td>
                                                   <td><?php echo $c_s['request_vehicle_type'] ?></td>
                                                   <td><?php echo $c_s['destination_name'] ?></td>
                                                   <!-- <td>
                              <button
                                  class="btn btn-secondary_<?php echo $c_s['cab_service_request_id'] ?> shadow btn-xs sharp me-1"><i
                                      class="fas fa-eye"></i></button>
                              </td> -->
                                                   <td>
                                                      <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $c_s['cab_service_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                                   </td>
                                                   <td>
                                                      <a href="#" class="badge badge-rounded badge-warning change_cab" data-bs-toggle="modal" id="edit_data" data-id="<?= $c_s['cab_service_request_id'] ?>">Assign</a>
                                                   </td>
                                                   <!-- assign modal -->
                                                   <!--/.  assign modal  -->
                                                </tr>
                                                <div class="modal fade bd-terms-modal-sm_<?php echo $c_s['cab_service_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                                   <div class="modal-dialog modal-md">
                                                      <div class="modal-content">
                                                         <div class="modal-header">
                                                            <h5 class="modal-title">Note</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                            </button>
                                                         </div>
                                                         <div class="modal-body">
                                                            <div class="col-lg-12">
                                                               <span><?php echo $c_s['description'] ?></span>
                                                            </div>
                                                         </div>
                                                         <div class="modal-footer">
                                                            <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                          <?php
                                             }
                                          }

                                          ?>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane" id="accepted_orders_div2" style="background-color:white;">
                                 <div class="table-scrollable cab_change_record1">
                                    <table id="acceptedOrder_tb2" class="display full-width">
                                       <thead>
                                          <tr>
                                             <th><strong>Sr. No.</strong></th>
                                             <th><strong>Passengers</strong></th>
                                             <th><strong>Requested Date</strong></th>
                                             <th><strong>Guest Name</strong></th>
                                             <th><Strong>Phone</Strong></th>
                                             <th><strong>Vehicle Type</strong></th>
                                             <th><strong>Destination</strong></th>
                                             <th><strong>Note</strong></th>
                                             <th><strong>Driver</strong></th>
                                             <th><strong>Driver Phone</strong></th>
                                             <th><strong>Vehicle Type</strong></th>
                                             <th><strong>Vehicle No.</strong></th>
                                             <th><strong>Status</strong></th>
                                          </tr>
                                       </thead>
                                       <tbody id="searchTable">
                                          <?php
                                          $i = 1;
                                          if ($list1) {
                                             foreach ($list1 as $cb_s) {
                                                $user_data = $this->MainModel->get_user_data($cb_s['u_id']);

                                                $full_name = "";
                                                $mobile_no = "";

                                                if ($user_data) {
                                                   $full_name = $user_data['full_name'];
                                                   $mobile_no = $user_data['mobile_no'];
                                                }
                                          ?>
                                                <tr>
                                                   <td><strong><?php echo $i++ ?></strong></td>
                                                   <td><?php echo $cb_s['total_passanger'] ?></td>
                                                   <td>
                                                      <?php echo $cb_s['request_date'] ?> /<sub> <?php echo date('h:i a', strtotime($cb_s['request_time'])) ?></sub>
                                                   </td>
                                                   <td><?php echo $full_name ?></td>
                                                   <td><?php echo $mobile_no ?></td>
                                                   <td><?php echo $cb_s['request_vehicle_type'] ?></td>
                                                   <td><?php echo $cb_s['destination_name'] ?></td>
                                                   <!-- <td>
                              <button
                                  class="btn btn-secondary_<?php echo $cb_s['cab_service_request_id'] ?> shadow btn-xs sharp me-1"><i
                                      class="fas fa-eye"></i></button>
                              </td> -->
                                                   <td>
                                                      <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $cb_s['cab_service_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                                   </td>
                                                   <td><?php echo $cb_s['driver_name'] ?></td>
                                                   <td><?php echo $cb_s['driver_contact_no'] ?></td>
                                                   <td><?php echo $cb_s['assign_vehicle_type'] ?></td>
                                                   <td><?php echo $cb_s['vehicle_no'] ?></td>
                                                   <input type="hidden" name="user_id" id="uid<?php echo $cb_s['cab_service_request_id']; ?>" value="<?php echo $cb_s['cab_service_request_id']; ?>">
                                                   <td>
                                                      <select class="form-control" name="status" id="cabstatus<?php echo $cb_s['cab_service_request_id']; ?>" onchange="cab_change_status(<?php echo $cb_s['cab_service_request_id'] ?>);" style="min-width:85px;text-align:center">
                                                         <?php
                                                         if ($cb_s['request_status'] == "1") {
                                                         ?>
                                                            <option value="1" selected>Accepted</option>
                                                            <option value="4">Completed</option>
                                                         <?php
                                                         }
                                                         ?>
                                                      </select>
                                                   </td>
                                                </tr>
                                                <div class="modal fade bd-terms-modal-sm_<?php echo $cb_s['cab_service_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                                   <div class="modal-dialog modal-md">
                                                      <div class="modal-content">
                                                         <div class="modal-header">
                                                            <h5 class="modal-title">Note</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                            </button>
                                                         </div>
                                                         <div class="modal-body">
                                                            <div class="col-lg-12">
                                                               <span><?php echo $cb_s['description'] ?></span>
                                                            </div>
                                                         </div>
                                                         <div class="modal-footer">
                                                            <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                          <?php
                                             }
                                          }

                                          ?>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane" id="completed_orders_div2" style="background-color:white;">
                                 <div class="table-scrollable cab_change_record2">
                                    <table id="completedOrder_tb2" class="display full-width">
                                       <thead>
                                          <tr>
                                             <th><strong>Sr. No.</strong></th>
                                             <th><strong>Passengers</strong></th>
                                             <th><strong>Requested Date</strong></th>
                                             <th><strong>Guest Name</strong></th>
                                             <th><Strong>Phone</Strong></th>
                                             <th><strong>Vehicle Type</strong></th>
                                             <th><strong>Destination</strong></th>
                                             <th><strong>Note</strong></th>
                                             <th><strong>Driver</strong></th>
                                             <th><strong>Driver Phone</strong></th>
                                             <th><strong>Vehicle Type</strong></th>
                                             <th><strong>Vehicle No.</strong></th>
                                             <th><strong>Status</strong></th>
                                          </tr>
                                       </thead>
                                       <tbody id="searchTable">
                                          <?php
                                          $i = 1;
                                          if ($list3) {
                                             foreach ($list3 as $cb_c) {
                                                $user_data = $this->MainModel->get_user_data($cb_c['u_id']);

                                                $full_name = "";
                                                $mobile_no = "";

                                                if ($user_data) {
                                                   $full_name = $user_data['full_name'];
                                                   $mobile_no = $user_data['mobile_no'];
                                                }
                                          ?>
                                                <tr>
                                                   <td><strong><?php echo $i++ ?></strong></td>
                                                   <td><?php echo $cb_c['total_passanger'] ?></td>
                                                   <td>
                                                      <?php echo $cb_c['request_date'] ?> /<sub> <?php echo date('h:i a', strtotime($cb_c['request_time'])) ?></sub>
                                                   </td>
                                                   <td><?php echo $full_name ?></td>
                                                   <td><?php echo $mobile_no ?></td>
                                                   <td><?php echo $cb_c['request_vehicle_type'] ?></td>
                                                   <td><?php echo $cb_c['destination_name'] ?></td>
                                                   <!-- <td>
                              <button
                                  class="btn btn-secondary_<?php echo $cb_c['cab_service_request_id'] ?> shadow btn-xs sharp me-1"><i
                                      class="fas fa-eye"></i></button>
                              </td> -->
                                                   <td>
                                                      <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $cb_c['cab_service_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                                   </td>
                                                   <td><?php echo $cb_c['driver_name'] ?></td>
                                                   <td><?php echo $cb_c['driver_contact_no'] ?></td>
                                                   <td><?php echo $cb_c['assign_vehicle_type'] ?></td>
                                                   <td><?php echo $cb_c['vehicle_no'] ?></td>
                                                   <td>
                                                      <div class="d-flex">
                                                         <a href="#"><span class="badge badge-success" data-bs-toggle="modal" data-bs-target="">Completed</span>
                                                         </a>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <div class="modal fade bd-terms-modal-sm_<?php echo $cb_c['cab_service_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                                   <div class="modal-dialog modal-md">
                                                      <div class="modal-content">
                                                         <div class="modal-header">
                                                            <h5 class="modal-title">Note</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                            </button>
                                                         </div>
                                                         <div class="modal-body">
                                                            <div class="col-lg-12">
                                                               <span><?php echo $cb_c['description'] ?></span>
                                                            </div>
                                                         </div>
                                                         <div class="modal-footer">
                                                            <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                          <?php
                                             }
                                          }

                                          ?>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane" id="rejected_orders_div2" style="background-color:white;">
                                 <div class="table-scrollable cab_change_record3">
                                    <table id="rejectedOrder_tb2" class="display full-width">
                                       <thead>
                                          <tr>
                                             <th><strong>Sr. No.</strong></th>
                                             <th><strong>Passengers</strong></th>
                                             <th><strong>Requested Date</strong></th>
                                             <th><strong>Guest Name</strong></th>
                                             <th><Strong>Phone</Strong></th>
                                             <th><strong>Vehicle Type</strong></th>
                                             <th><strong>Destination</strong></th>
                                             <th><strong>Note</strong></th>
                                             <th><strong>Status</strong></th>
                                          </tr>
                                       </thead>
                                       <tbody id="searchTable">
                                          <?php
                                          $i = 1;
                                          if ($list2) {
                                             foreach ($list2 as $cb_s) {
                                                $user_data = $this->MainModel->get_user_data($cb_s['u_id']);

                                                $full_name = "";
                                                $mobile_no = "";

                                                if ($user_data) {
                                                   $full_name = $user_data['full_name'];
                                                   $mobile_no = $user_data['mobile_no'];
                                                }
                                          ?>
                                                <tr>
                                                   <td><strong><?php echo $i++ ?></strong></td>
                                                   <td><?php echo $cb_s['total_passanger'] ?></td>
                                                   <td>
                                                      <?php echo $cb_s['request_date'] ?> /<sub> <?php echo date('h:i a', strtotime($cb_s['request_time'])) ?></sub>
                                                   </td>
                                                   <td><?php echo $full_name ?></td>
                                                   <td><?php echo $mobile_no ?></td>
                                                   <td><?php echo $cb_s['request_vehicle_type'] ?></td>
                                                   <td><?php echo $cb_s['destination_name'] ?></td>
                                                   <!-- <td>
                              <button
                                  class="btn btn-secondary_<?php echo $cb_s['cab_service_request_id'] ?> shadow btn-xs sharp me-1"><i
                                      class="fas fa-eye"></i></button>
                              </td> -->
                                                   <td>
                                                      <a style="margin:auto" data-bs-toggle="modal" data-bs-target=".bd-terms-modal-sm_<?php echo $cb_s['cab_service_request_id'] ?>" class="btn btn-secondary shadow btn-xs sharp"><i class="fa fa-eye"></i></a>
                                                   </td>
                                                   <td>
                                                      <div class="d-flex">
                                                         <a href="#"><span class="badge badge-danger" data-bs-toggle="modal" data-bs-target="">Rejected</span>
                                                         </a>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <div class="modal fade bd-terms-modal-sm_<?php echo $cb_s['cab_service_request_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
                                                   <div class="modal-dialog modal-md">
                                                      <div class="modal-content">
                                                         <div class="modal-header">
                                                            <h5 class="modal-title">Note</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal">
                                                            </button>
                                                         </div>
                                                         <div class="modal-body">
                                                            <div class="col-lg-12">
                                                               <span><?php echo $cb_s['description'] ?></span>
                                                            </div>
                                                         </div>
                                                         <div class="modal-footer">
                                                            <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                          <?php
                                             }
                                          }

                                          ?>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-- add btn modal   -->
                  <div class="modal fade bd-add-modal add_cab_serv_model" tabindex="-1" aria-hidden="true">
                     <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                           <form id="cab_request" method="post" enctype="multipart/form-data">
                              <div class="modal-header">
                                 <h5 class="modal-title" style="font-weight: bold;font-size: 15px !important;">Add Cab Service Request</h5>
                                 <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
                                 </button>
                              </div>
                              <div class="modal-body">
                                 <div class="row">
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Contact Number</label>
                                       <input type="text" maxlength="10" name="mobile_no" id="mobile_no" onkeyup="add_booking_id()" oninput="this.value=this.value.replace(/[^0-9]/g,'');" class="form-control" placeholder="Contact Number" required="">
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Booking ID</label>
                                       <input type="number" name="booking_id" class="form-control" id="booking_id" placeholder="Booking ID" required="" disable>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Request Date</label>
                                       <input type="date" class="form-control minDate" name="request_date" placeholder="Date" required>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Request Time</label>
                                       <input type="time" class="form-control minDate" name="request_time" placeholder="time" required>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Passengers</label>
                                       <input type="number" class="form-control" name="total_passanger" id="name" placeholder="Passengers">
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Vehicle Type</label>
                                       <input type="text" class="form-control minDate" name="vehicle_type" placeholder="Vehicle Type" required>
                                    </div>
                                    <div class="mb-3 col-md-6 form-group">
                                       <label class="form-label">Destination</label>
                                       <input type="text" class="form-control minDate" name="destination" placeholder="Destination" required>
                                    </div>
                                    <div class="mb-3 col-md-12 form-group">
                                       <label class="form-label">Note</label>
                                       <!-- <div class="summernote"></div> -->
                                       <textarea class="summernote" id="description1" name="additional_note" style="min-height: 400px;"></textarea>
                                    </div>
                                 </div>
                              </div>
                              <div class="modal-footer">
                                 <button type="submit" class="btn btn-primary css_btn">Add
                                 </button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
                  <div class="modal fade change_cab_action" tabindex="-1" aria-hidden="true">
                     <div class="modal-dialog modal-md">
                        <div class="modal-content">
                           <div class="modal-header">
                              <h5 class="modal-title">Cab Details</h5>
                              <button type="button" class="btn-close" data-dismiss="modal" aria-hidden="true"></button>
                           </div>
                           <form id="frmupdateblock" method="post" enctype="multipart/form-data">
                              <input type="hidden" name="cab_service_request_id" id="cab_service_request_id">
                              <div class="modal-body">
                                 <div class="row offset-md-1">
                                    <div class="col-md-6">
                                       <label><input type="radio" name="request_status" value="red" required> Accept <img src="assets/dist/images/download.png" alt="" height="26px;"></label>
                                    </div>
                                    <div class="col-md-6">
                                       <label><input type="radio" name="request_status" value="green" required> Reject <img src="assets/dist/images/cross.png" alt="" height="22px;"></label>
                                    </div>
                                 </div>
                                 <div class="red box">
                                    <div class="mb-3 col-md-12">
                                       <label class="form-label">Assign To</label>
                                       <div class="row">
                                          <div class="mb-3 col-md-12">
                                             <label class="form-label">Driver Name</label>
                                             <input type="text" name="driver_name" id="driver_name" class="form-control">
                                          </div>
                                       </div>
                                       <div class="row">
                                          <div class="mb-3 col-md-12">
                                             <label class="form-label">Phone</label>
                                             <input type="text" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');" name="driver_contact_no" id="driver_contact_no" class="form-control">
                                          </div>
                                       </div>
                                       <div class="row">
                                          <div class="mb-3 col-md-12">
                                             <label class="form-label">Vehicle Type</label>
                                             <input type="text" name="assign_vehicle_type" id="assign_vehicle_type" class="form-control">
                                          </div>
                                       </div>
                                       <div class="row">
                                          <div class="mb-3 col-md-12">
                                             <label class="form-label">Vehicle No</label>
                                             <input type="text" name="vehicle_no" id="vehicle_no" class="form-control">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <!-- <div class="green box">Your
                  Request has been Cancelled !</div> -->
                              </div>
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                                 <button type="submit" class="btn btn-primary">Submit</button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
                  <script>
                     function cab_change_status(cnt) {
                        //alert('hi');
                        $(".loader_block").show();
                        var base_url = '<?php echo base_url(); ?>';
                        var status = $('#cabstatus' + cnt).children("option:selected").val();
                        var uid = $('#uid' + cnt).val();
                        //  alert(uid);
                        //  die;

                        if (status != '') {

                           $.ajax({
                              url: base_url + "HoteladminController/cab_status",
                              method: "POST",
                              data: {
                                 status: status,
                                 uid: uid
                              },
                              dataType: "json",
                              success: function(data) {
                                 $.get('<?= base_url('HoteladminController/ajaxcabIconView_v1'); ?>', function(data) {
                                    var resu = $(data).find('#example1').html();
                                    var resu1 = $(data).find('.cab_change_record1').html();
                                    var resu2 = $(data).find('.cab_change_record2').html();
                                    var resu3 = $(data).find('.cab_change_record3').html();
                                    $('#example1').html(resu);
                                    $('.cab_change_record1').html(resu1);
                                    $('.cab_change_record2').html(resu2);
                                    $('.cab_change_record3').html(resu3);
                                    //   $(".append_data14").html(res);

                                    setTimeout(function() {
                                       $(".loader_block").hide();
                                       $('#example1').DataTable();
                                       $('.page_header_title_spa').text('Complete Cab Request');
                                       $(".status_completed4").show();
                                       $('#acceptedOrder_tb2').DataTable();
                                       $('#completedOrder_tb2').DataTable();
                                       $('#rejectedOrder_tb2').DataTable();
                                       // $(".append_data14").html(res);

                                       $('a[href="#completed_orders_div2"]').tab('show');

                                       setTimeout(function() {
                                          $(".status_completed4").hide();
                                       }, 4000);
                                    }, 2000);
                                 });
                                 //alert(data);

                              }
                           });
                        }
                     }
                  </script>
                  <script type="text/javascript">
                     $(document).on("click", ".change_cab", function() {
                        $(".change_cab_action").modal('show');
                     });

                     $(document).ready(function() {
                        $('#example1').DataTable();
                        $('#acceptedOrder_tb2').DataTable();
                        $('#completedOrder_tb2').DataTable();
                        $('#rejectedOrder_tb2').DataTable();


                        $(document).on("click", ".add_cab", function() {
                           $(".add_cab_serv_model").modal('show');
                        });
                        $(document).unbind('submit').on('submit', '#cab_request', function(e) {
                           e.preventDefault();
                           $(".loader_block").show();
                           var form_data = new FormData(this);
                           //  var data_id = $(this).attr('data-id');
                           $.ajax({
                              url: '<?= base_url('HoteladminController/add_cab_request') ?>',
                              method: 'POST',
                              data: form_data,
                              processData: false,
                              contentType: false,
                              cache: false,
                              success: function(res) {

                                 $.get('<?= base_url('HoteladminController/ajaxcabIconView_v1'); ?>', function(data) {
                                    var resu = $(data).find('.cab_change_record').html();
                                    $('.cab_change_record').html(resu);
                                    setTimeout(function() {
                                       $('#example1').DataTable();

                                    }, 2000);
                                 });

                                 setTimeout(function() {
                                    $(".loader_block").hide();
                                    $(".add_cab_serv_model").modal('hide');
                                    $(".add_cab_serv_model").on("hidden.bs.modal", function() {
                     $("#cab_request")[0].reset(); // reset the form fields
                     $('#description1').summernote('reset');
                  });
                  $('.summernote').summernote('reset');
                                    $(".append_data14").html(res);
                                    $(".successmessage14").show();
                                 }, 2000);
                                 setTimeout(function() {
                                    $(".successmessage14").hide();
                                 }, 4000);

                              }
                           });
                        });


                        $(document).on('click', '#edit_data', function() {
                           var id = $(this).attr('data-id');
                           // alert(id);
                           $.ajax({
                              url: '<?= base_url('HoteladminController/getchangecabData') ?>',
                              type: "post",
                              data: {
                                 id: id
                              },
                              dataType: "json",
                              success: function(data) {

                                 console.log(data);
                                 $('#cab_service_request_id').val(data.cab_service_request_id);
                                 $('#driver_name').val(data.driver_name);
                                 $('#driver_contact_no').val(data.driver_contact_no);
                                 $('#assign_vehicle_type').val(data.assign_vehicle_type);
                                 $('#vehicle_no').val(data.vehicle_no);



                              }


                           });
                        })


                        $(document).on('submit', '#frmupdateblock', function(e) {
                           // alert('hi');die;
                           e.preventDefault();
                           $(".loader_block").show();
                           var form_data = new FormData(this);
                           $.ajax({
                              url: '<?= base_url('HoteladminController/change_cab_service_request') ?>',
                              method: 'POST',
                              data: form_data,
                              processData: false,
                              contentType: false,
                              cache: false,
                              success: function(res) {
                                 console.log(res);
                                 $.get('<?= base_url('HoteladminController/ajaxSubIconBlockView3'); ?>', function(data) {
                                    var resu = $(data).find('#new_orders_div2').html();
                                    var resu1 = $(data).find('#accepted_orders_div2').html();
                                    var resu2 = $(data).find('#completed_orders_div2').html();
                                    var resu3 = $(data).find('#rejected_orders_div2').html();

                                    $('#new_orders_div2').html(resu);
                                    $('#accepted_orders_div2').html(resu1);
                                    $('#completed_orders_div2').html(resu2);
                                    $('#rejected_orders_div2').html(resu3);

                                    setTimeout(function() {
                                       $('#example1').DataTable();
                                       $('#acceptedOrder_tb2').DataTable();
                                       $('#completedOrder_tb2').DataTable();
                                       $('#rejectedOrder_tb2').DataTable();
                                    }, 2000);
                                 });



                              }
                           });
                           setTimeout(function() {
                              // debugger;
                              $(".loader_block").hide();
                              //  $(".updateFaq").modal('hide');
                              $(".change_cab_action").modal('hide');
                              // $(".append_data14").html(res);
                              $(".successmessage15").show();
                              var request_status = form_data.get('request_status');
                              //  console.log(requestStatus); // Log the requestStatus value to the console

                              if (request_status === "red") {
                                 $('a[href="#accepted_orders_div2"]').tab('show');
                                 $('.page_header_title_spa').text('Accept Cab Request');
                              } else if (request_status === "green") {
                                 $('a[href="#rejected_orders_div2"]').tab('show');
                                 $('.page_header_title_spa').text('Reject Cab Request');

                              }

                           }, 2000);

                           setTimeout(function() {
                              $(".successmessage15").hide();
                           }, 4000);
                        });
                     });
                  </script>
               <?php } ?>
               <!-- end add btn modal -->
               <div class="loader_block" style="display: none;">
                  <div class="row" style="position: absolute;left: 50%;top: 40%;">
                     <div class="col-sm-6 text-center">
                        <p>loader 3</p>
                        <div class="loader3">
                           <span></span>
                           <span></span>
                        </div>
                     </div>
                  </div>
               </div>
               <script>
                  $(document).ready(function() {
                     // $('#newOrder_tb').DataTable();
                     $('#acceptedOrder_tb').DataTable();
                     $('#rejectedOrder_tb_new').DataTable();
                     $('#rejectedOrder_tb').DataTable();
                     $('#completedOrder_tb').DataTable();
                     $('#requestOrder_tb').DataTable();

                  });
                  var selectedOrderserviceurl = '';
                  $('#orderserviceDropdown').change(function() {
                     var selected_orderservice = $(this).val();
                     if (selected_orderservice == 'new_orders') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView6';
                        $('.page_header_title').text('Car Wash Request');
                        $('.new_orders_div').css('display', 'block');
                        $('.accepted_orders_div').css('display', 'none');
                        $('.rejected_orders_div_new').css('display', 'none');

                        $('.completed_orders_div_new').css('display', 'none');
                        $('.rejected_orders_div').css('display', 'none');
                        $('.add_car_wash').css('display', 'block');

                     }
                     if (selected_orderservice == 'accepted_order') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView6';
                        $('.page_header_title').text('Accepted Car Wash Request ');
                        $('.accepted_orders_div').css('display', 'block');
                        $('.new_orders_div').css('display', 'none');
                        $('.completed_orders_div_new').css('display', 'none');
                        $('.rejected_orders_div_new').css('display', 'none');
                        $('.rejected_orders_div').css('display', 'none');
                        $('.add_car_wash').css('display', 'none');

                     }
                     if (selected_orderservice == 'completed_order') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView6';
                        $('.page_header_title').text('completed Car Wash Request ');
                        $('.accepted_orders_div').css('display', 'none');
                        $('.new_orders_div').css('display', 'none');
                        $('.completed_orders_div_new').css('display', 'block');
                        $('.rejected_orders_div_new').css('display', 'none');
                        $('.rejected_orders_div').css('display', 'none');
                        $('.add_car_wash').css('display', 'none');

                     }
                     if (selected_orderservice == 'rejected_order_new') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView6';
                        $('.page_header_title').text('Rejected Car Wash Request ');
                        $('.accepted_orders_div').css('display', 'none');
                        $('.new_orders_div').css('display', 'none');
                        $('.completed_orders_div_new').css('display', 'none');
                        $('.rejected_orders_div_new').css('display', 'block');
                        $('.rejected_orders_div').css('display', 'none');
                        $('.add_car_wash').css('display', 'none');

                     }
                     if (selected_orderservice == 'rejected_order') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView6';
                        $('.page_header_title').text('Washing Charges');
                        $('.rejected_orders_div').css('display', 'block');
                        $('.new_orders_div').css('display', 'none');
                        $('.completed_orders_div_new').css('display', 'none');
                        $('.rejected_orders_div_new').css('display', 'none');
                        $('.accepted_orders_div').css('display', 'none');
                        $('.add_car_wash').css('display', 'none');

                     }

                     var base_url = '<?php echo base_url(); ?>';
                     $.ajax({
                        method: "GET",
                        url: base_url + selectedOrderserviceurl,
                        success: function(response) {
                           $('.append_data').html(response);
                        }
                     });
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     // $('#newOrder_tb').DataTable();
                     $('#acceptedOrder_tb4').DataTable();
                     $('#rejectedOrder_tb_new4').DataTable();
                     $('#rejectedOrder_tb4').DataTable();
                     $('#completedOrder_tb4').DataTable();
                     $('#requestOrder_tb4').DataTable();

                  });
                  var selectedOrderserviceurl = '';
                  $('#orderserviceDropdown').change(function() {
                     var selected_orderservice = $(this).val();
                     if (selected_orderservice == 'new_orders4') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView4';
                        $('.page_header_title_spa').text('Spa Information');
                        $('.arrival1_div_spa').css('display', 'block');
                        $('.arrival2_div1_spa').css('display', 'none');
                        $('.arrival3_div_spa').css('display', 'none');
                        $('.arrival5_div_spa').css('display', 'none');
                        $('.arrival4_div_spa').css('display', 'none');

                     }
                     if (selected_orderservice == 'accepted_order4') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView4';
                        $('.page_header_title_spa').text('Spa Request ');
                        $('.arrival1_div_spa').css('display', 'none');
                        $('.arrival2_div1_spa').css('display', 'block');
                        $('.arrival3_div_spa').css('display', 'none');
                        $('.arrival5_div_spa').css('display', 'none');
                        $('.arrival4_div_spa').css('display', 'none');

                     }
                     if (selected_orderservice == 'rejected_order_new4') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView4';
                        $('.page_header_title_spa').text('Accept Spa Request ');
                        $('.arrival1_div_spa').css('display', 'none');
                        $('.arrival2_div1_spa').css('display', 'none');
                        $('.arrival3_div_spa').css('display', 'block');
                        $('.arrival5_div_spa').css('display', 'none');
                        $('.arrival4_div_spa').css('display', 'none');

                     }
                     if (selected_orderservice == 'completed_order4') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView4';
                        $('.page_header_title_spa').text('Complete Spa Request');
                        $('.arrival1_div_spa').css('display', 'none');
                        $('.arrival2_div1_spa').css('display', 'none');
                        $('.arrival3_div_spa').css('display', 'none');
                        $('.arrival5_div_spa').css('display', 'block');
                        $('.arrival4_div_spa').css('display', 'none');

                     }
                     if (selected_orderservice == 'rejected_order4') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView4';
                        $('.page_header_title_spa').text('Reject Spa Request');
                        $('.arrival1_div_spa').css('display', 'none');
                        $('.arrival2_div1_spa').css('display', 'none');
                        $('.arrival3_div_spa').css('display', 'none');
                        $('.arrival5_div_spa').css('display', 'none');
                        $('.arrival4_div_spa').css('display', 'block');

                     }

                     var base_url = '<?php echo base_url(); ?>';
                     $.ajax({
                        method: "GET",
                        url: base_url + selectedOrderserviceurl,
                        success: function(response) {
                           $('.append_data').html(response);
                        }
                     });
                  });
               </script>
               <script>
                  // $('.delete').click(function() {
                  function delete_data_car(id) {
                     var id = id;
                     var base_url = '<?php echo base_url() ?>';

                     const swalWithBootstrapButtons = Swal.mixin({
                        customClass: {
                           confirmButton: 'btn btn-danger',
                           cancelButton: 'btn btn-success'
                        },
                        buttonsStyling: false
                     })

                     swalWithBootstrapButtons.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes, delete it!',
                        cancelButtonText: 'No, cancel!',
                        reverseButtons: true
                     }).then((result) => {
                        if (result.isConfirmed) {
                           $.ajax({
                              url: base_url + "HoteladminController/delete_vehicle_washing_charges",
                              method: "post",
                              data: {
                                 id: id
                              },
                              success: function(data) {
                                 // alert(data);
                                 if (data == 1) {
                                    swalWithBootstrapButtons.fire(
                                       'Deleted!',
                                       'Your file has been deleted.',
                                       'success'
                                    ).then((result) => {
                                       location.reload();
                                    })
                                 }
                              }

                           });
                        } else if (
                           /* Read more about handling dismissals below */
                           result.dismiss === Swal.DismissReason.cancel
                        ) {
                           swalWithBootstrapButtons.fire(
                              'Cancelled',
                              'Your imaginary file is safe :)',
                              'error'
                           )
                        }
                     })

                  }
               </script>
               <script>
                  $(document).ready(function() {
                     // $('#newOrder_tb').DataTable();
                     $('#acceptedOrder_tb1').DataTable();
                     $('#rejectedOrder_tb1').DataTable();

                     $('#rejectedOrder_tb1_new').DataTable();

                     $('#completedOrder_tb1').DataTable();
                     $('#spa_tbl').DataTable();
                  });
                  var selectedOrderserviceurl = '';
                  $('#orderserviceDropdown1').change(function() {
                     var selected_orderservice = $(this).val();
                     if (selected_orderservice == 'new_orders1') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView2';
                        $('.page_header_title1').text('Luggage Request');
                        $('.new_orders_div1').css('display', 'block');
                        $('.accepted_orders_div1').css('display', 'none');
                        $('.completed_orders_div1_new').css('display', 'none');
                        $('.rejected_orders_div1_new').css('display', 'none');
                        $('.rejected_orders_div1').css('display', 'none');
                        $('.add_luggage_item').css('display', 'block');

                     }
                     if (selected_orderservice == 'accepted_order1') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView2';
                        $('.page_header_title1').text('Accepted Luggage Request');
                        $('.accepted_orders_div1').css('display', 'block');
                        $('.new_orders_div1').css('display', 'none');
                        $('.completed_orders_div1_new').css('display', 'none');
                        $('.rejected_orders_div1_new').css('display', 'none');
                        $('.rejected_orders_div1').css('display', 'none');
                        $('.add_luggage_item').css('display', 'none');

                     }
                     if (selected_orderservice == 'completed_order1') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView2';
                        $('.page_header_title1').text('Completed Luggage Request');
                        $('.accepted_orders_div1').css('display', 'block');
                        $('.new_orders_div1').css('display', 'none');
                        $('.completed_orders_div1_new').css('display', 'none');
                        $('.rejected_orders_div1_new').css('display', 'none');
                        $('.rejected_orders_div1').css('display', 'none');
                        $('.add_luggage_item').css('display', 'none');

                     }

                     if (selected_orderservice == 'rejected_order3') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView2';
                        $('.page_header_title1').text('Rejected Luggage Request');
                        $('.accepted_orders_div1').css('display', 'none');
                        $('.new_orders_div1').css('display', 'none');
                        $('.rejected_orders_div1_new').css('display', 'block');
                        $('.completed_orders_div1_new').css('display', 'none');
                        $('.rejected_orders_div1').css('display', 'none');
                        $('.add_luggage_item').css('display', 'none');
                     }
                     if (selected_orderservice == 'rejected_order1') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView2';
                        $('.page_header_title1').text('Manage Luggage Charges');
                        $('.rejected_orders_div1').css('display', 'block');
                        $('.new_orders_div1').css('display', 'none');
                        $('.rejected_orders_div1_new').css('display', 'none');
                        $('.completed_orders_div1_new').css('display', 'none');
                        $('.accepted_orders_div1').css('display', 'none');
                        $('.add_luggage_item').css('display', 'none');

                     }

                     var base_url = '<?php echo base_url(); ?>';
                     $.ajax({
                        method: "GET",
                        url: base_url + selectedOrderserviceurl,
                        success: function(response) {
                           $('.append_data').html(response);
                        }
                     });
                  });
               </script>
               <script>
                  // $('.delete').click(function() {
                  function delete_data_luggage(id) {
                     var id = id;
                     var base_url = '<?php echo base_url() ?>';

                     const swalWithBootstrapButtons = Swal.mixin({
                        customClass: {
                           confirmButton: 'btn btn-danger',
                           cancelButton: 'btn btn-success'
                        },
                        buttonsStyling: false
                     })

                     swalWithBootstrapButtons.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes, delete it!',
                        cancelButtonText: 'No, cancel!',
                        reverseButtons: true
                     }).then((result) => {
                        if (result.isConfirmed) {
                           $.ajax({
                              url: base_url + "HoteladminController/delete_luggage_charge",
                              method: "post",
                              data: {
                                 id: id
                              },
                              success: function(data) {
                                 // alert(data);
                                 if (data == 1) {
                                    swalWithBootstrapButtons.fire(
                                       'Deleted!',
                                       'Your file has been deleted.',
                                       'success'
                                    ).then((result) => {
                                       location.reload();
                                    })
                                 }
                              }

                           });
                        } else if (
                           /* Read more about handling dismissals below */
                           result.dismiss === Swal.DismissReason.cancel
                        ) {
                           swalWithBootstrapButtons.fire(
                              'Cancelled',
                              'Your imaginary file is safe :)',
                              'error'
                           )
                        }
                     })

                  }
               </script>
               <script>
                  $(document).ready(function() {
                     // $('#newOrder_tb').DataTable();
                     $('#acceptedOrder_tb2').DataTable();
                     $('#rejectedOrder_tb2').DataTable();
                     $('#completedOrder_tb2').DataTable();
                  });
                  var selectedOrderserviceurl = '';
                  $('#orderserviceDropdown2').change(function() {
                     var selected_orderservice = $(this).val();
                     if (selected_orderservice == 'new_orders2') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView3';
                        $('.page_header_title2').text('Cab Service Request');
                        $('.new_orders_div2').css('display', 'block');
                        $('.accepted_orders_div2').css('display', 'none');
                        $('.rejected_orders_div2').css('display', 'none');
                        $('.completed_orders_div2').css('display', 'none');
                        $('.add_cab_feature').css('display', 'block');

                     }
                     if (selected_orderservice == 'accepted_order2') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView3';
                        $('.page_header_title2').text('Accepted Cab Request');
                        $('.accepted_orders_div2').css('display', 'block');
                        $('.new_orders_div2').css('display', 'none');
                        $('.rejected_orders_div2').css('display', 'none');
                        $('.accepted_orders_div2').css('display', 'none');
                        $('.add_cab_feature').css('display', 'none');

                     }

                     if (selected_orderservice == 'completed_order2') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView3';
                        $('.page_header_title2').text('Completed Cab Request');
                        $('.accepted_orders_div2').css('display', 'none');
                        $('.new_orders_div2').css('display', 'none');
                        $('.rejected_orders_div2').css('display', 'none');
                        $('.completed_orders_div2').css('display', 'block');
                        $('.add_cab_feature').css('display', 'none');

                     }
                     if (selected_orderservice == 'rejected_order2') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView3';
                        $('.page_header_title2').text('Rejected Cab Request');
                        $('.accepted_orders_div2').css('display', 'none');
                        $('.new_orders_div2').css('display', 'none');
                        $('.completed_orders_div2').css('display', 'none');
                        $('.rejected_orders_div2').css('display', 'block');
                        $('.add_cab_feature').css('display', 'none');

                     }

                     var base_url = '<?php echo base_url(); ?>';
                     $.ajax({
                        method: "GET",
                        url: base_url + selectedOrderserviceurl,
                        success: function(response) {
                           $('.append_data').html(response);
                        }
                     });
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     $('input[type="radio"]').click(function() {
                        var inputValue = $(this).attr("value");
                        var targetBox = $("." + inputValue);
                        $(".box").not(targetBox).hide();
                        $(targetBox).show();
                     });
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     // $('#newOrder_tb').DataTable();
                     $('#acceptedOrder_tb5').DataTable();

                  });
                  var selectedOrderserviceurl = '';

                  function orderservice1(clicked) {

                     selectedOrderserviceurl = 'HoteladminContrller/shuttle_availabilty';
                     $('.accepted_orders_div_service').css('display', 'block');
                     $('.new_orders_div_service').css('display', 'none');



                     var base_url = '<?php echo base_url(); ?>';
                     $.ajax({
                        method: "GET",
                        url: base_url + selectedOrderserviceurl,
                        success: function(response) {
                           $('.append_data').html(response);
                        }
                     });
                  };
               </script>
               <script>
                  function change_status(id) {
                     var base_url = '<?php echo base_url() ?>';
                     var status = $('#status_' + id).val();
                     var id = id;

                     // alert(status);
                     if (status != '') {
                        $.ajax({
                           url: base_url + 'HoteladminController/change_available_status',
                           method: "post",
                           data: {
                              status: status,
                              id: id
                           },
                           success: function(data) {
                              if (data == 1) {
                                 alert('Status Changed successfully');
                                 location.reload();
                              } else {
                                 alert('Something went wrong');
                                 location.reload();
                              }
                           }

                        });
                     }
                  }
               </script>
               <script>
                  $(document).ready(function() {
                     // $('#newOrder_tb').DataTable();
                     $('#monday_tbl').DataTable();
                     $('#tuesday_tbl').DataTable();
                     $('#wednesday_tbl').DataTable();
                     $('#thursday_tbl').DataTable();
                     $('#friday_tbl').DataTable();
                     $('#saturday_tbl').DataTable();
                  });
                  var selectedOrderserviceurl = '';
                  $('#days').change(function() {
                     var selected_orderservice = $(this).val();
                     if (selected_orderservice == 'Sunday') {
                        selectedOrderserviceurl = 'HoteladminContrller/ajaxSubIconBlockView1';
                        $('.sunday_div').css('display', 'block');
                        $('.monday_div').css('display', 'none');
                        $('.tuesday_div').css('display', 'none');
                        $('.wednesday_div').css('display', 'none');
                        $('.thursday_div').css('display', 'none');
                        $('.friday_div').css('display', 'none');
                        $('.saturday_div').css('display', 'none');
                     }

                     if (selected_orderservice == 'Monday') {
                        selectedOrderserviceurl = 'HoteladminContrller/shuttle_availabilty';
                        $('.sunday_div').css('display', 'none');
                        $('.monday_div').css('display', 'block');
                        $('.tuesday_div').css('display', 'none');
                        $('.wednesday_div').css('display', 'none');
                        $('.thursday_div').css('display', 'none');
                        $('.friday_div').css('display', 'none');
                        $('.saturday_div').css('display', 'none');
                     }
                     if (selected_orderservice == 'Tuesday') {
                        selectedOrderserviceurl = 'HoteladminContrller/shuttle_availabilty';
                        $('.sunday_div').css('display', 'none');
                        $('.monday_div').css('display', 'none');
                        $('.tuesday_div').css('display', 'block');
                        $('.wednesday_div').css('display', 'none');
                        $('.thursday_div').css('display', 'none');
                        $('.friday_div').css('display', 'none');
                        $('.saturday_div').css('display', 'none');
                     }
                     if (selected_orderservice == 'Wednesday') {
                        selectedOrderserviceurl = 'HoteladminContrller/shuttle_availabilty';
                        $('.sunday_div').css('display', 'none');
                        $('.monday_div').css('display', 'none');
                        $('.tuesday_div').css('display', 'none');
                        $('.wednesday_div').css('display', 'block');
                        $('.thursday_div').css('display', 'none');
                        $('.friday_div').css('display', 'none');
                        $('.saturday_div').css('display', 'none');
                     }
                     if (selected_orderservice == 'Thursday') {
                        selectedOrderserviceurl = 'HoteladminContrller/shuttle_availabilty';
                        $('.sunday_div').css('display', 'none');
                        $('.monday_div').css('display', 'none');
                        $('.tuesday_div').css('display', 'none');
                        $('.wednesday_div').css('display', 'none');
                        $('.thursday_div').css('display', 'block');
                        $('.friday_div').css('display', 'none');
                        $('.saturday_div').css('display', 'none');
                     }
                     if (selected_orderservice == 'Friday') {
                        selectedOrderserviceurl = 'HoteladminContrller/shuttle_availabilty';
                        $('.sunday_div').css('display', 'none');
                        $('.monday_div').css('display', 'none');
                        $('.tuesday_div').css('display', 'none');
                        $('.wednesday_div').css('display', 'none');
                        $('.thursday_div').css('display', 'none');
                        $('.friday_div').css('display', 'block');
                        $('.saturday_div').css('display', 'none');
                     }
                     if (selected_orderservice == 'Saturday') {
                        selectedOrderserviceurl = 'HoteladminContrller/shuttle_availabilty';
                        $('.sunday_div').css('display', 'none');
                        $('.monday_div').css('display', 'none');
                        $('.tuesday_div').css('display', 'none');
                        $('.wednesday_div').css('display', 'none');
                        $('.thursday_div').css('display', 'none');
                        $('.friday_div').css('display', 'none');
                        $('.saturday_div').css('display', 'block');
                     }

                     var base_url = '<?php echo base_url(); ?>';
                     $.ajax({
                        method: "GET",
                        url: base_url + selectedOrderserviceurl,
                        success: function(response) {
                           $('.append_data').html(response);
                        }
                     });
                  });
               </script>
               <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
               <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
               <script>
                  $('.accordion-toggle').click(function() {
                     $('.hiddenRow').hide();
                     $(this).next('tr').find('.hiddenRow').show();
                  });
               </script>
               <script>
                  $('input[type=radio]').on('click', function() {

                     $('input[type=radio]').not(this).closest('label').css('background', 'blue');
                     $(this).closest('label').css('background', 'red');
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     $('.amt_ch input[type="radio"]').click(function() {
                        var inputValue = $(this).attr("value");
                        console.log(inputValue);
                        if (inputValue == "App") {
                           $("#App_Ord").show();
                           $("#Walkin_Ord").hide();

                        } else {
                           $("#Walkin_Ord").show();
                           $("#App_Ord").hide();
                        }

                     });
                     // $('input[type="radio"]').click(function() {
                     //     var inputValue = $(this).attr("value");
                     //     var targetBox = $("." + inputValue);
                     //     $(".walkin_guest").not(targetBox).hide();
                     //     $(targetBox).show();
                     // });
                  });
               </script>
               <!-- automatic hide session data -->
               <script>
                  $(document).ready(function() {
                     $('.alert').delay(4000).fadeOut();
                  });
               </script>
               <!-- automatic hide session data -->
               <!--onchange function on roomtype and display room type  -->
               <script>
                  $(document).ready(function() {

                     $('#room_type').change(function() {

                        var base_url = '<?php echo base_url() ?>';
                        var room_type = $('#room_type').val();

                        // alert(room_type);

                        if (room_type != '') {
                           $.ajax({
                              url: base_url + "HoteladminController/get_room_nos",
                              method: "POST",
                              data: {
                                 room_type: room_type
                              },
                              success: function(data) {
                                 //alert(data);
                                 $('#display_rooms_no').html(data);
                              }

                           });
                        }
                     });

                  });
               </script>
               <script>
                  $(document).ready(function() {
                     // $('#newOrder_tb').DataTable();
                     $('#arrival_tbl').DataTable();
                  });

                  $('#orderserviceArrival').change(function() {
                     var selected_orderservice = $(this).val();
                     if (selected_orderservice == 'arrival1') {
                        $('.arrival1_div').css('display', 'block');
                        $('.arrival2_div').css('display', 'none');

                     }
                     if (selected_orderservice == 'arrival2') {
                        $('.arrival2_div').css('display', 'block');
                        $('.arrival1_div').css('display', 'none');

                     }
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     $('.nav-tabs a').on('click', function() {
                        var tabId = $(this).attr('href');
                        if (tabId === '#arrival1_div') {
                           $('.arrival11').text('Todays Arrival');
                        } else if (tabId === '#arrival2_div') {
                           $('.arrival11').text('Upcoming Arrival');
                        }

                        // $('.headingtitle').text(title);
                     });
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     $('.nav-tabs a').on('click', function() {
                        var tabId = $(this).attr('href'); // Get the ID of the clicked tab
                        // var title = '';

                        // Update the title based on the tab ID
                        if (tabId === '#new_orders_div') {
                           $('.page_header_title').text('Car Wash Request');
                           $('.add_car_wash').css('display', 'block');
                        } else if (tabId === '#accepted_orders_div') {
                           $('.page_header_title').text('Accepted Car Wash Request');
                           $('.add_car_wash').css('display', 'none');
                        } else if (tabId === '#completed_orders_div_new') {
                           $('.page_header_title').text('Completed Car Wash Request');
                           $('.add_car_wash').css('display', 'none');
                        } else if (tabId === '#rejected_orders_div_new') {
                           $('.page_header_title').text('Rejected Car Wash Request');
                           $('.add_car_wash').css('display', 'none');
                        } else if (tabId === '#rejected_orders_div') {
                           $('.page_header_title').text('Washing Charges');
                           $('.add_car_wash').css('display', 'none');
                        }

                        // $('.headingtitle').text(title);
                     });
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     $('.nav-tabs a').on('click', function() {
                        var tabId = $(this).attr('href'); // Get the ID of the clicked tab
                        // var title = '';

                        // Update the title based on the tab ID
                        if (tabId === '#arrival1_div_spa') {
                           $('.page_header_title_spa').text('Spa Information');
                           $('.add_spa_require').css('display', 'none');
                        } else if (tabId === '#arrival2_div1_spa') {
                           $('.page_header_title_spa').text('Spa Request');
                           $('.add_spa_require').css('display', 'block');
                        } else if (tabId === '#arrival3_div_spa') {
                           $('.page_header_title_spa').text('Accept Spa Request');
                           $('.add_spa_require').css('display', 'none');
                        } else if (tabId === '#arrival5_div_spa') {
                           $('.page_header_title_spa').text('Completed Spa Request');
                           $('.add_spa_require').css('display', 'none');
                        } else if (tabId === '#arrival4_div_spa') {
                           $('.page_header_title_spa').text('Reject Spa Request');
                           $('.add_spa_require').css('display', 'none');
                        }

                        // $('.headingtitle').text(title);
                     });
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     $('.nav-tabs a').on('click', function() {
                        var tabId = $(this).attr('href'); // Get the ID of the clicked tab
                        // var title = '';

                        // Update the title based on the tab ID
                        if (tabId === '#new_orders_div1') {
                           $('.page_header_title1').text('Luggage Request');
                           $('.add_luggage_item').css('display', 'block');
                        } else if (tabId === '#accepted_orders_div1') {
                           $('.page_header_title1').text('Accepted Luggage Request');
                           $('.add_luggage_item').css('display', 'none');
                        } else if (tabId === '#completed_orders_div1_new') {
                           $('.page_header_title1').text('Luggage Return');
                           $('.add_luggage_item').css('display', 'none');
                        } else if (tabId === '#rejected_orders_div1_new') {
                           $('.page_header_title1').text('Rejected Luggage Request');
                           $('.add_luggage_item').css('display', 'none');
                        }

                        // $('.headingtitle').text(title);
                     });
                  });
               </script>
               <script>
                  $(document).ready(function() {
                     $('.nav-tabs a').on('click', function() {
                        var tabId = $(this).attr('href');
                        if (tabId === '#new_orders_div2') {
                           $('.page_header_title2').text('Cab Service Request');
                           $('.add_cab_feature').css('display', 'block');
                        } else if (tabId === '#accepted_orders_div2') {
                           $('.page_header_title2').text('Accepted Cab Request');
                           $('.add_cab_feature').css('display', 'none');
                        } else if (tabId === '#completed_orders_div2') {
                           $('.page_header_title2').text('Completed Cab Request');
                           $('.add_cab_feature').css('display', 'none');
                        } else if (tabId === '#rejected_orders_div2') {
                           $('.page_header_title2').text('Rejected Cab Request');
                           $('.add_cab_feature').css('display', 'none');
                        }
                     });
                  });
               </script>
               <script>
                  var appId = 1;
                  $(function() {
                     $("#btnAdd2").bind("click", function() {
                        // alert('hi');
                        var div = $("<div class=''/>");
                        div.html(GetDynamicTextBox1(""));
                        $("#TextBoxContainer2").append(div);
                        appId++;
                     });
                     $("body").on("click", "#DeleteRow", function() {
                        $(this).parents("#row").remove();
                     })
                  });

                  function GetDynamicTextBox1(value) {

                     var room_data = '<?php echo $room_type_list_string; ?>';
                     const obj = JSON.parse(room_data, true);
                     var arr_length = obj.length;
                     var rs_arr = [];

                     for (var i = 0; i < arr_length; i++) {
                        rs_arr.push('<option value="' + obj[i]['room_type_id'] + '">' + obj[i]['room_type_name'] + '</option>');
                     }


                     return '<div id="row" class="row">' +
                        '<div class="mb-3 col-md-6">' +
                        '<input type="number" name="no_of_rooms1[]" value="1" class="form-control" placeholder="No.of Rooms " readonly />' +
                        '</div>' +
                        '<div class="mb-3 col-md-6">' +
                        '<div class="input-group">' +
                        '<select class="default-select form-control wide" id="sel_' + appId + '" name="room_type1[]" onchange="get_room_no(this)" required="">' +
                        '<option value="">---Choose  Room type.--</option>' +
                        rs_arr +
                        '</select>' +
                        '<a type="button" value="Remove" id="DeleteRow" class="remove btn btn-danger btn-sm"><i class="fa fa-times"></i></a>' +
                        '</div>' +
                        '</div>' +
                        '<div class="row">' +
                        '<div class="mb-3 col-md-12">' +
                        '<label class="form-label"> Assign Room</label>' +
                        '<div class="accordion accordion-rounded-stylish accordion-bordered" id="accordion-eleven">' +
                        '<div class="row">' +
                        '<div class="col-xl-12">' +
                        '<div class="col-xl-12">' +
                        '<div class="row row-cols-8 ">' +
                        '<div id="display_rooms_no_sel_' + appId + '" style="display:flex;"></div>' +
                        // php code data fetch here
                        '</div>' +
                        '</div>' +
                        '</div>' +

                        '</div>' +

                        '</div>' +
                        '</div>' +
                        '</div>' +
                        '</div>' +
                        '</div>'
                  }
               </script>
               <script>
                  function add_amt() {
                     var base_url = '<?php echo base_url() ?>';
                     var adult = $('#total_adults').val();
                     var child = $('#total_child').val();

                     // var guest = $('#guest').val();
                     // alert(adult);
                     $.ajax({
                        url: base_url + "HoteladminController/add_guest_count",
                        method: "post",
                        data: {
                           adult: adult,
                           child: child
                        },
                        success: function(data) {
                           $('#guest').val(data)
                        }
                     });
                  }
               </script>
               <script>
                  $(document).on('click', '.room_id', function() {

                     var id = $(this).attr('room-id');
                     console.log(id);
                     $.ajax({
                        url: '<?= base_url('HoteladminController/viewShuttleConfig') ?>',
                        method: 'POST',
                        data: {
                           room_type: id,
                        },

                        success: function(res) {
                           console.log(res);

                           $('.view_Room_Id').html(res);

                        }

                     });
                  });
               </script>
               <script>
                  function add_booking_id() {
                     var base_url = '<?php echo base_url() ?>';
                     var mobile_no = $('#mobile_no').val();

                     $.ajax({
                        url: base_url + "HoteladminController/add_booking_id",
                        method: "post",
                        data: {
                           mobile_no: mobile_no
                        },
                        success: function(data) {
                           $('#booking_id').val(data)
                        }
                     });
                  }
               </script>