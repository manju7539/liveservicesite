<?php 
   $i = 1;
   if($list)
   {
   foreach($list as $off)
   {
   $offer_for = "";
   
   if($off['offer_for'] == 1)
   {
   $offer_for = "Over All";
   }
   else
   {
   if($off['offer_for'] == 2)
   {
   $offer_for = "Front Office Services";
   }
   else
   {
   if($off['offer_for'] == 3)
   {
   $offer_for = "Bar and Restaurant";
   }
   }
   }
   ?>
<tr>
   <td><strong><?php echo $i++ ?></strong></td>
   <td><?php echo $off['offer_name'] ?></td>
   <td><?php echo $offer_for?></td>
   <td><?php echo $off['amt_in_per'] ?> </td>
   <td><?php echo $off['start_date'] ?></td>
   <td><?php echo $off['end_date'] ?></td>
   <td>
      <div class="lightgallery"
         class="room-list-bx d-flex align-items-center">
         <a href="<?php echo $off['image'] ?>"
            data-exthumbimage="<?php echo $off['image'] ?>"
            data-src="<?php echo $off['image'] ?>"
            class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
         <img class="me-2 "
            src="<?php echo $off['image'] ?>"
            alt="" style="width:70px;">
         </a>
      </div>
   </td>
   <!-- <td>Special offer available</td> -->
   <td>
      <div class="">
       
         <a href="#"  class="btn btn-warning shadow btn-xs sharp me-1" data-bs-toggle="modal" id="edit_data" data-id="<?= $off['offer_id']?>" data-bs-target=".update_offer_modal"><i class="fa fa-pencil"></i></a> 

         <a href="#" onclick="delete_data(<?php echo $off['offer_id'] ?>)"
            class="btn btn-danger shadow btn-xs sharp"><i
            class="fa fa-trash"></i></a>
      </div>
   </td>
</tr>

<?php
   }
   }
   
   ?>
   <!-- modal popup for edit  -->
     
 <div class="modal fade update_offer_modal" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" style="font-weight: bold;font-size: 15px !important;">Edit Offers</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal">
    </button>
</div>
<form id="frmupdateblock" method="post" enctype="multipart/form-data">
        <div class="modal-body">
            <div class="col-lg-12">
                <input type="hidden" name="offer_id" id="offer_id">
                <div class="row">
                   
                    <div class="mb-3 col-md-6">
                    <label class="form-label">Offer Name</label>
                    <input type="text" name="offer_name" id="offer_name" class="form-control" placeholder="offer name">
                    </div>
                    <div class="mb-3 col-md-6">
                    <label class="form-label">Offer For</label>
                    <select id="inputState" class="default-select form-control wide" name="offer_for"  data-hotelid="">
                        <?php
                        $hotel_data = $this->HotelAdminModel->getUniqueOfferFromData();
                        foreach($hotel_data as $u) {
                           $id = $u['offer_for'];
                           $name = '';
                           if ($id == '1') {
                                 $name = "Over All";
                           } else if ($id == '2') {
                                 $name = "Front Ofs";
                           } else {
                                 $name = "Bar And Restaurant";
                           }
                           
                           $selected = '';
                           // Check if the current option should be selected
                        //   if ($id == $selected_option_value) {
                        //          $selected = 'selected';
                        //   }
                           
                           echo '<option value="'.$id.'" '.$selected.'>'.$name.'</option>';
                        }
                        ?>
                     </select>



                    </div>
                    <div class="mb-3 col-md-6">
                    <label class="form-label">Amount in Percentage (%)</label>
                    <input type="number" name="amt_in_per" id="amt_in_per" class="form-control" placeholder="percentage">
                    </div>
                    <div class="mb-3 col-md-6">
                    <label class="form-label">Start Date</label>
                    <input type="date" name="start_date" id="start_date" class="form-control" placeholder="date">
                    </div>
                    <div class="mb-3 col-md-6">
                    <label class="form-label">Expiry Date</label>
                    <input type="date" name="end_date" id="end_date" class="form-control" placeholder="date">
                    </div>
                    <div class="mb-3 col-md-12 form-group">
                                        <label class="form-label">Upload photo</label>
                                        <div class="form-file form-control"
                              style="border: 0.0625rem solid #ccc7c7;">
                                        <input type="file" name="image" accept="image/png, image/gif, image/jpeg">
                                        <img src="" id="img" alt="Not Found" height="50" width="50">
                                </div>
                  
                    <div class="mb-3 col-md-12">
                    <label class="form-label">Offer Description</label>
                    <textarea name="description" id="description"  class="summernote" rows="4" id="comment"
                        required=""></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="text-center">
                    <button type="button" class="btn btn-light"
                    data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update Offer</button>
                </div>
            </div>
        </div>
        </form>

    </div>
</div>
</div>
<!-- end of edit modal  -->
<script>
    $(document).ready(function (id) {
            $(document).on('click','#edit_data',function(){
                var id = $(this).attr('data-id');
                // alert(id);
                $.ajax({
                url: '<?= base_url('HoteladminController/getofferdata') ?>',
                type: "post",
                data: {id:id},
                dataType:"json",
                success: function (data) {
                    
                    console.log(data);
                    $('#offer_id').val(data.offer_id);
                    $('#offer_name').val(data.offer_name);
                    $('#inputState option[value="' + data.offer_for + '"]').prop('selected', true);
                    $('#amt_in_per').val(data.amt_in_per);
                    $('#start_date').val(data.start_date);
                    $('#end_date').val(data.end_date);
                    $('#description').summernote('code', data.description);
                    $("#img").attr('src',data.image);
                }
                }); 
            })
        });  
</script>
