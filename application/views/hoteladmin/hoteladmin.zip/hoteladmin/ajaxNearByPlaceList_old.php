<?php

$i = 1;
if($list)
{
foreach($list as $h_ne_pl)
{

$wh = '(hotel_near_by_place_id = "'.$h_ne_pl['hotel_near_by_place_id'].'")';

$hotel_near_by_place_image = $this->HotelAdminModel->getData('hotel_near_by_place_images',$wh);

if(!empty($hotel_near_by_place_image))
{
$hotel_near_img = $hotel_near_by_place_image['images'];
}
else
{
$hotel_near_img = '';
}

?> <tr data-toggle="collapse" data-target="#demo1" class="accordion-toggle">
<td>
<strong> <?php echo $i++ ?> </strong>
</td>
<td> <?php echo $h_ne_pl['places']?> </td>
<td> <?php echo $h_ne_pl['places_name']?> </td>
<td> <?php echo $h_ne_pl['contact_no']?> </td>
<td class="job-desk3">
<p class="mb-0"> <?php echo $h_ne_pl['place_address']?> </p>
</td>
<td>
<div class="lightgallery" class="room-list-bx d-flex align-items-center">
<a href="
<?php echo $hotel_near_img?>" data-exthumbimage="
<?php echo $hotel_near_img?>" data-src="
<?php echo $hotel_near_img?>" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
<img class="me-3" src="
<?php echo $hotel_near_img?>" alt="" style="width:80px;">
</a>
</div>
</td>
<td> <?php echo $h_ne_pl['latitute']?> </td>
<td> <?php echo $h_ne_pl['longitude']?> </td>
<!-- <td>
<a href="#" class="btn btn-secondary shadow btn-xs sharp " data-bs-container="body" data-bs-toggle="popover" data-bs-placement="top" data-bs-content="
<?php echo strip_tags($h_ne_pl['description'])?>" title="" data-bs-original-title="Description">
<i class="fa fa-eye"></i>
</a>
</td> -->
<td>
        <a style="margin:auto" data-bs-toggle="modal"
            data-bs-target=".bd-terms-modal-sm_<?php echo $h_ne_pl['hotel_near_by_place_id'] ?>"
            class="btn btn-secondary shadow btn-xs sharp"><i
                class="fa fa-eye"></i></a>
    </td>
<td> <?php echo $h_ne_pl['website_link']?> </td>
<td>
<div class="d-flex">

<a href="javascript:void(0)" data-id="<?= $h_ne_pl['hotel_near_by_place_id']?>" class="btn btn-tbl-edit btn-xs update_faq_modal"  style="margin-right:5px;">
    <i class="fa fa-pencil"></i>
</a>
<a href="#" onclick="delete_data(<?php echo $h_ne_pl['hotel_near_by_place_id'] ?>)" class="btn btn-danger shadow btn-xs sharp">
<i class="fa fa-trash"></i>
</a>
</div>
</td>
<!-- edit modal -->
<div class="modal fade updateFaq" id="update_faq_<?php echo $h_ne_pl['hotel_near_by_place_id'] ?>" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-xl slideInRight animated">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Update Places</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<form  id="frmupdateblock" method="post" enctype="multipart/form-data">
<input type="hidden" name="hotel_near_by_place_id" value="
<?php echo $h_ne_pl['hotel_near_by_place_id']?>">
<div class="modal-body">
<div class="col-12 ">
<div class="row">
<div class="mb-3 col-md-4 form-group">
<label class="form-label">Must see places</label>
<select name="places" id="inputState" class="default-select form-control wide">
<option selected>Choose...</option>
<option <?php if($h_ne_pl['places'] == "Monuments"){echo "Selected";}?> value="Monuments">Monuments </option>
<option <?php if($h_ne_pl['places'] == "Shopping"){echo "Selected";}?> value="Shopping">Shopping </option>
<option <?php if($h_ne_pl['places'] == "Fun"){echo "Selected";}?> value="Fun">Fun </option>
</select>
</div>
<div class="mb-3 col-md-4 form-group">
<label class="form-label">Place Name</label>
<input type="text" name="places_name" value="
<?php echo $h_ne_pl['places_name']?>" class="form-control" placeholder="" required="">
</div>
<div class="mb-3 col-md-4 form-group">
<label class="form-label">Contact Number</label>
<input type="text" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');" name="contact_no" value="
<?php echo $h_ne_pl['contact_no']?>" class="form-control" placeholder="" required="">
</div>
<div class="mb-3 col-md-12 form-group">
<label class="form-label">Upload Photo</label>
<!-- <input type="file" class="form-control" name="file1" multiple=""> -->
<div class="row">


<?php

$j = 0;

$hotel_near_by_place_images = $this->HotelAdminModel->getAllData('hotel_near_by_place_images',$wh);

if($hotel_near_by_place_images)
{
?> 
<!--<label class="form-label">Upload Photos</label> -->
<?php
foreach($hotel_near_by_place_images as $h_img)
{
?> <input type="hidden" name="id[]" value="
<?php echo $h_img['id']?>">
<div class="col-md-3">


<input name="image[
<?php echo $j?>]" type="file" accept=".jpg,.jpeg,.png,/application" class="dropify" data-default-file="
<?php echo $h_img['images']?>" /> </div>
<?php
$j++;
}
}
?>
</div>
</div>
<div class="mb-3 col-md-6 form-group">
<label class="form-label">Address</label>
<textarea class="summernote" name="place_address" rows="4" id="comment" required="">
            <?php echo $h_ne_pl['place_address']?>
        </textarea>
</div>
<div class="mb-3 col-md-6 form-group">
<label class="form-label">Description</label>
<textarea class="summernote" name="description" rows="4" id="comment" required="">
            <?php echo $h_ne_pl['description']?>
        </textarea>
</div>
<div class="mb-3 col-md-3 form-group">
<label class="form-label">Latitude</label>
<input type="text" class="form-control" name="latitute" value="
            <?php echo $h_ne_pl['latitute']?>" placeholder="">
</div>
<div class="mb-3 col-md-3 form-group">
<label class="form-label">Longtitude</label>
<input type="text" class="form-control" name="longitude" value="
                <?php echo $h_ne_pl['longitude']?>" placeholder="">
</div>
<div class="mb-3 col-md-6 form-group">
<label class="form-label">Website link</label>
<input type="text" class="form-control" name="website_link" value="
                    <?php echo $h_ne_pl['website_link']?>" placeholder="">
</div>
</div>
</div>
</div>
<div class="modal-footer">
<button type="submit" class="btn btn-info">Update Place</button>
<button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
</div>
</form>
</div>
</div>
</div>
<!--/. edit modal  -->
</tr> 
<div class="modal fade bd-terms-modal-sm_<?php echo $h_ne_pl['hotel_near_by_place_id'] ?>" tabindex="-1" style="display: none;" aria-hidden="true">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title">Description</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal">
    </button>
</div>
<div class="modal-body">
    <div class="col-lg-12">
        <span><?php echo $h_ne_pl['description'] ?></span>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-light css_btn" data-bs-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<?php
}
}

?>
