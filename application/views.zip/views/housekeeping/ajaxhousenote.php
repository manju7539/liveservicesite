<?php
                  $i = 1;
                  if ($list) {
                    
                  
                        $wh = '(h_k_order_id = "'. $list['additional_note'] . '")';
                        // print_r($wh);die;
                      
                  ?>
                        
                             

                             <?php echo $list['additional_note']?>
                           
                          
                  <?php
                     }
             
                  ?>