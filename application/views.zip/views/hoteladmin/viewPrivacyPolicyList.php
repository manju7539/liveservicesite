<!-- start page content -->
<div class="page-content-wrapper">
   <div class="page-content">
      <div class="page-bar">
         <div class="page-title-breadcrumb">
            <div class=" pull-left">
               <div class="page-title">Privacy</div>
            </div>
            <ol class="breadcrumb page-breadcrumb pull-right">
               <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item"
                  href="<?php echo base_url('Dashboard')?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i></li>
               <li><a class="parent-item" href="">Manage Menus</a>&nbsp;<i
                  class="fa fa-angle-right"></i></li>
               <li class="active">Privacy</li>
            </ol>
         </div>
      </div>
      <div class="alert alert-success successmessage" role="alert" id="a" style="margin-top:10px; margin-top: 10px;background-color: #4e8759;padding: 4px;border-radius:3px ;display: none;">
         <strong style="color:#fff ;margin-top:10px;" class="status_change">Privacy Created Successfully..!</strong>
         <span style="  float: right;font-size: 29px;line-height: 0.8;top: 9;color: #fff;" aria-hidden="true">&times;</span>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div class="card card-topline-aqua">
               <div class="card-head">
                  <header>List of Privacy</header>
               </div>
               <div class="card-body ">
                  <form id="frmblock" method="post">
                     <div class="row">
                        <div class="col-xl-12 col-xxl-12 append_data">
                           <?php
                              if(!empty($data))
                              {
                                
                                  $content = $data['content'];
                              
                              /*else
                              {
                                  $content = "";
                              }*/
                              ?>
                           <textarea class="summernote" name="content" value="<?php echo $data['content']?>" rows="4" id="comment" required=""><?php echo $data['content'];?></textarea>
                           <?php 
                              }
                              else
                              {
                                ?>
                           <textarea class="summernote" name="content" value="" rows="4" id="comment" required=""></textarea>
                           <?php
                              }
                              ?>
                        </div>
                     </div>
                     <br>
                     <div class="text-center">
                        <button type="submit" class="btn btn-info">Add Privacy</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="loader_block" style="display: none;">
   <div class="row" style="position: absolute;left: 50%;top: 40%;">
      <div class="col-sm-6 text-center">
         <div class="loader3">
            <span></span>
            <span></span>
         </div>
      </div>
   </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
<script>
  $(document).ready(function() {
      $(document).on('submit', '#frmblock', function(e){
      e.preventDefault();
      $(".loader_block").show();
      var form_data = new FormData(this);
      $.ajax({
          url         : '<?= base_url('HoteladminController/add_hotel_privacy_policy') ?>',
          method      : 'POST',
          data        : form_data,
          processData : false,
          contentType : false,
          cache       : false,
          success     : function(res) {
              setTimeout(function(){  
                $(".loader_block").hide();
                $(".add_facility_modal").modal('hide');
              // $(".append_data").html(res);
                $(".successmessage").show();
                }, 2000);
              setTimeout(function(){  
                  $(".successmessage").hide();
                }, 4000);
              
          }
      });
    });
  });
</script>