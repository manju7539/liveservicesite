<?php
                  $i = 1;
                  if ($list) {
                    
                  
                        $wh = '(front_ofs_service_id = "'. $list['description'] . '")';
                        // print_r($wh);die;
                      
                  ?>
                        
                             

                             <?php echo $list['description']?>
                           
                          
                  <?php
                     }
             
                  ?>