<?php
                  $i = 1;
                  if ($list) {
                    
                  
                        $wh = '(front_ofs_service_id = "'. $list['t_nd_c'] . '")';
                        // print_r($wh);die;
                      
                  ?>
                        
                             

                             <?php echo $list['t_nd_c']?>
                           
                          
                  <?php
                     }
             
                  ?>