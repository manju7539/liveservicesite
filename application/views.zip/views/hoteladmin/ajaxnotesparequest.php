<?php
                  $i = 1;
                  if ($list) {
                    
                  
                        $wh = '(spa_service_request_id = "'. $list['note'] . '")';
                        // print_r($wh);die;
                      
                  ?>
                        
                             

                             <?php echo $list['note']?>
                           
                          
                  <?php
                     }
             
                  ?>